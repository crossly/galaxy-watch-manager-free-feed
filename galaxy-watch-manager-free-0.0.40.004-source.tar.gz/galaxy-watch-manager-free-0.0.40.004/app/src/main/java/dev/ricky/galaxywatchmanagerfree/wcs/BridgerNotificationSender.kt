package dev.ricky.galaxywatchmanagerfree.wcs

import dev.ricky.galaxywatchmanagerfree.feature.NotificationIdentity

internal class BridgerNotificationSender(
    private val log: (String) -> Unit = {},
    private val sendFrame: (ByteArray) -> Boolean,
) {
    enum class Result(val queued: Boolean) {
        REJECTED(false),
        TEXT_ONLY(true),
        WITH_ICON(true),
    }

    @Synchronized
    fun send(
        phoneNode: String,
        identity: NotificationIdentity,
        title: String,
        text: String,
        appName: String?,
        whenMillis: Long,
        seqId: Long,
        appIcon: ByteArray?,
        smallIcon: ByteArray? = null,
        isSmallIconVector: Boolean = false,
        allowTextFallback: Boolean = true,
    ): Result? {
        if (phoneNode.isBlank()) return Result.REJECTED

        val validAppIcon = appIcon?.takeIf { it.isNotEmpty() && it.size <= MAX_ICON_BYTES }
        if (appIcon != null && appIcon.size > MAX_ICON_BYTES) {
            log("[通知图标] package=${identity.packageName} appIcon 超出大小上限 bytes=${appIcon.size}")
        }
        val validSmallIcon = smallIcon?.takeIf { it.isNotEmpty() && it.size <= MAX_ICON_BYTES }
        if (smallIcon != null && smallIcon.size > MAX_ICON_BYTES) {
            log("[通知图标] package=${identity.packageName} smallIcon 超出大小上限 bytes=${smallIcon.size}")
        }

        val isSameIcon =
            validSmallIcon == null ||
                (validAppIcon != null && validAppIcon.contentEquals(validSmallIcon))

        val assets = mutableMapOf<String, String>()
        var appIconRef: DataMapEncoder.AssetReference? = null
        var smallIconRef: DataMapEncoder.AssetReference? = null

        if (validAppIcon != null) {
            val digest = WcsFrame.messageDigest(validAppIcon)
            val queued = sendIcon(validAppIcon, digest)
            log(
                "[通知图标] package=${identity.packageName} (app_icon) digest=$digest bytes=${validAppIcon.size} assetQueued=$queued"
            )
            if (queued) {
                assets["0"] = digest
                appIconRef = DataMapEncoder.AssetReference(0)
                if (isSameIcon) {
                    smallIconRef = DataMapEncoder.AssetReference(0)
                }
            }
        }

        if (validSmallIcon != null && !isSameIcon) {
            val digest = WcsFrame.messageDigest(validSmallIcon)
            val queued = sendIcon(validSmallIcon, digest)
            log(
                "[通知图标] package=${identity.packageName} (icon) digest=$digest bytes=${validSmallIcon.size} assetQueued=$queued"
            )
            if (queued) {
                val index = if (appIconRef != null) 1 else 0
                assets[index.toString()] = digest
                smallIconRef = DataMapEncoder.AssetReference(index)
                if (appIconRef == null) {
                    appIconRef = DataMapEncoder.AssetReference(index)
                }
            }
        } else if (validAppIcon == null && validSmallIcon != null) {
            val digest = WcsFrame.messageDigest(validSmallIcon)
            val queued = sendIcon(validSmallIcon, digest)
            log(
                "[通知图标] package=${identity.packageName} (icon only) digest=$digest bytes=${validSmallIcon.size} assetQueued=$queued"
            )
            if (queued) {
                assets["0"] = digest
                appIconRef = DataMapEncoder.AssetReference(0)
                smallIconRef = DataMapEncoder.AssetReference(0)
            }
        }

        val hasIcon = appIconRef != null || smallIconRef != null
        if (!hasIcon && !allowTextFallback) return null

        val data =
            linkedMapOf<String, Any>(
                "R_c,0" to 1L,
                "R_c" to 1L,
                "title_raw" to title,
                "text_raw" to text,
                "priority" to 1,
                "notification_flags" to 0,
                "user_id" to identity.userId,
                "when" to whenMillis,
                "show_when" to true,
                "defaults" to 2,
                "has_sound" to true,
                "app_name" to (appName?.takeIf { it.isNotBlank() } ?: identity.packageName),
                "from" to "phone",
            )
        if (appIconRef != null) data["app_icon"] = appIconRef
        if (smallIconRef != null) {
            data["icon"] = smallIconRef
            if (isSmallIconVector) {
                data["is_small_icon_vector_drawable"] = true
            }
        }

        val queued =
            sendFrame(
                WcsFrame.wearPathFrame(
                    path = "wear://$phoneNode/${identity.bridgerPath(phoneNode)}",
                    dataItems = listOf(DataMapEncoder.encode(data)),
                    senderPkg = SENDER_PACKAGE,
                    nodeId = phoneNode,
                    seqId = seqId,
                    assets = assets,
                )
            )
        return when {
            !queued -> Result.REJECTED
            !hasIcon -> Result.TEXT_ONLY
            else -> Result.WITH_ICON
        }
    }

    private fun sendIcon(bytes: ByteArray, digest: String): Boolean {
        val target = Proto.string(1, SENDER_PACKAGE) + Proto.string(2, WcsPaths.SIGNATURE_PLUGIN)
        val asset = Proto.string(1, digest) + Proto.bytes(2, Proto.bytes(1, target))
        val header = Proto.bytes(4, asset) + Proto.integer(13, 1)
        val messageId = WcsFrame.messageDigest(header)
        val queue = if (bytes.size <= 32768) 5L else 6L
        if (!sendFrame(WcsFrame.envelope(header, messageId, type = queue))) return false
        for (offset in bytes.indices step FILE_PIECE_BYTES) {
            val end = minOf(bytes.size, offset + FILE_PIECE_BYTES)
            val last = end == bytes.size
            val piece =
                Proto.string(1, messageId) +
                    Proto.integer(2, if (last) 1 else 0) +
                    Proto.bytes(3, bytes.copyOfRange(offset, end)) +
                    if (last) Proto.string(4, digest) else byteArrayOf()
            if (!sendFrame(WcsFrame.envelopeNoType(Proto.bytes(12, piece)))) return false
        }
        return true
    }

    companion object {
        const val MAX_ICON_BYTES = 64 * 1024
        private const val FILE_PIECE_BYTES = 12288 - 73
        private const val SENDER_PACKAGE = "com.samsung.android.wcs.extension"
    }
}
