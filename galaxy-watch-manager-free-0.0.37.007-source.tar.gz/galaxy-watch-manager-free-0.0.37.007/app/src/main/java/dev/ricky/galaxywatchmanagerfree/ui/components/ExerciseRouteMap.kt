package dev.ricky.galaxywatchmanagerfree.ui.components

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Map
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import dev.ricky.galaxywatchmanagerfree.BuildConfig
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.feature.ExerciseRoute
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.math.log2
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import org.maplibre.android.MapLibre
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapLibreMapOptions
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style
import org.maplibre.android.module.http.HttpRequestUtil

@Composable
fun ExerciseRouteCard(route: ExerciseRoute.Route, accent: Color) {
    var open by rememberSaveable { mutableStateOf(false) }
    var geometry by remember(route) { mutableStateOf<ExerciseRouteGeometry?>(null) }
    LaunchedEffect(route) {
        geometry = withContext(Dispatchers.Default) { ExerciseRouteGeometry(route) }
    }
    val ready = geometry ?: return
    val plan = remember(ready) { PreviewTilePlan.of(ready) }
    val basemap = rememberPreviewBasemap(plan)
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Column(
            Modifier.fillMaxWidth()
                .clip(MaterialTheme.shapes.medium)
                .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                .clickable(onClickLabel = stringResource(R.string.exercise_route_open)) {
                    open = true
                }
        ) {
            RoutePreview(ready, accent, plan, basemap, Modifier.fillMaxWidth().height(176.dp))
            Row(
                Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Icon(Icons.Default.Map, null, tint = accent)
                Text(
                    stringResource(R.string.exercise_route_preview),
                    Modifier.weight(1f),
                    style = MaterialTheme.typography.titleSmall,
                )
                Text(
                    stringResource(R.string.exercise_route_open),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
        }
        if (basemap != null) RouteNote(R.string.exercise_route_attribution)
        RouteLegend(accent, route.points.size > 1)
        Text(
            stringResource(R.string.exercise_route_points, route.points.size, route.segments.size),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (route.points.size == 1) RouteNote(R.string.exercise_route_single_point)
        RouteNote(R.string.exercise_route_coordinates_unknown)
    }
    if (open) RouteMapDialog(route, ready, accent) { open = false }
}

@Composable
private fun RouteLegend(accent: Color, hasEnd: Boolean) {
    Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
        listOfNotNull(R.string.exercise_route_start, R.string.exercise_route_end.takeIf { hasEnd })
            .forEach { label ->
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Canvas(Modifier.size(16.dp)) {
                        if (label == R.string.exercise_route_start)
                            drawCircle(accent, 6.dp.toPx(), style = Stroke(2.dp.toPx()))
                        else drawCircle(accent, 4.dp.toPx())
                    }
                    Text(stringResource(label), style = MaterialTheme.typography.labelMedium)
                }
            }
    }
}

@Composable
private fun RouteNote(text: Int) {
    Text(
        stringResource(text),
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@Composable
private fun rememberPreviewBasemap(plan: PreviewTilePlan): ImageBitmap? {
    val network = remember { MapTileNetwork() }
    var basemap by remember(plan) { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(plan) {
        basemap =
            withContext(Dispatchers.IO) {
                try {
                    assemblePreviewBitmap(plan, network.client)?.asImageBitmap()
                } catch (error: java.util.concurrent.CancellationException) {
                    throw error
                } catch (_: Exception) {
                    null
                }
            }
    }
    return basemap
}

@Composable
private fun RoutePreview(
    geometry: ExerciseRouteGeometry,
    accent: Color,
    plan: PreviewTilePlan,
    basemap: ImageBitmap?,
    modifier: Modifier,
) {
    if (basemap == null) {
        RouteOutline(geometry, accent, modifier)
        return
    }
    val description = stringResource(R.string.exercise_route_preview)
    val surface = MaterialTheme.colorScheme.surfaceContainerHigh
    Canvas(modifier.semantics { contentDescription = description }) {
        drawRect(surface)
        val scale = min(size.width / basemap.width, size.height / basemap.height)
        val dstWidth = (basemap.width * scale).roundToInt()
        val dstHeight = (basemap.height * scale).roundToInt()
        val left = (size.width - dstWidth) / 2
        val top = (size.height - dstHeight) / 2
        drawImage(
            image = basemap,
            dstOffset = IntOffset(left.roundToInt(), top.roundToInt()),
            dstSize = IntSize(dstWidth, dstHeight),
        )
        fun position(vertex: ExerciseRouteGeometry.Vertex) =
            Offset(
                left + (plan.bitmapX(vertex.x) * scale).toFloat(),
                top + (plan.bitmapY(vertex.y) * scale).toFloat(),
            )
        drawRoute(geometry, accent, surface, ::position)
    }
}

@Composable
private fun RouteOutline(geometry: ExerciseRouteGeometry, accent: Color, modifier: Modifier) {
    val description = stringResource(R.string.exercise_route_preview)
    val surface = MaterialTheme.colorScheme.surfaceContainerHigh
    Canvas(modifier.semantics { contentDescription = description }) {
        val inset = 24.dp.toPx()
        val width = (size.width - inset * 2).coerceAtLeast(1f)
        val height = (size.height - inset * 2).coerceAtLeast(1f)
        val scale =
            min(
                width / max(geometry.maxX - geometry.minX, 0.000001),
                height / max(geometry.maxY - geometry.minY, 0.000001),
            )
        fun position(vertex: ExerciseRouteGeometry.Vertex) =
            Offset(
                (size.width / 2 + (vertex.x - (geometry.minX + geometry.maxX) / 2) * scale)
                    .toFloat(),
                (size.height / 2 + (vertex.y - (geometry.minY + geometry.maxY) / 2) * scale)
                    .toFloat(),
            )
        drawRoute(geometry, accent, surface, ::position)
    }
}

private fun DrawScope.drawRoute(
    geometry: ExerciseRouteGeometry,
    accent: Color,
    surface: Color,
    position: (ExerciseRouteGeometry.Vertex) -> Offset,
) {
    geometry.segments.forEach { segment ->
        val path = Path()
        segment.forEachIndexed { index, vertex ->
            val point = position(vertex)
            if (index == 0) path.moveTo(point.x, point.y) else path.lineTo(point.x, point.y)
        }
        if (segment.size > 1)
            drawPath(path, accent, style = Stroke(3.dp.toPx(), cap = StrokeCap.Round))
        else segment.firstOrNull()?.let { drawCircle(accent, 3.dp.toPx(), position(it)) }
    }
    geometry.segments.firstOrNull()?.firstOrNull()?.let {
        val point = position(it)
        drawCircle(surface, 8.dp.toPx(), point)
        drawCircle(accent, 7.dp.toPx(), point, style = Stroke(3.dp.toPx()))
    }
    if (geometry.segments.sumOf { it.size } > 1)
        geometry.segments.lastOrNull()?.lastOrNull()?.let {
            val point = position(it)
            drawCircle(surface, 5.dp.toPx(), point)
            drawCircle(accent, 4.dp.toPx(), point)
        }
}

@Composable
private fun RouteMapDialog(
    route: ExerciseRoute.Route,
    geometry: ExerciseRouteGeometry,
    accent: Color,
    onDismiss: () -> Unit,
) {
    var attempt by remember { mutableIntStateOf(0) }
    var map by remember(attempt) { mutableStateOf<MapLibreMap?>(null) }
    var viewport by remember(attempt) { mutableStateOf<MapView?>(null) }
    val density = LocalDensity.current.density
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Surface(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize().systemBarsPadding()) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        stringResource(R.string.exercise_route_map),
                        Modifier.weight(1f),
                        style = MaterialTheme.typography.titleLarge,
                    )
                    TextButton(onClick = onDismiss) { Text(stringResource(R.string.close)) }
                }
                key(attempt) {
                    val context = LocalContext.current
                    val network = remember { MapTileNetwork() }
                    val tileState by network.status.collectAsState()
                    var rendererFailed by remember { mutableStateOf(false) }
                    var timedOut by remember { mutableStateOf(false) }
                    LaunchedEffect(Unit) {
                        delay(12_000)
                        timedOut = true
                    }
                    Box(Modifier.fillMaxWidth().weight(1f)) {
                        if (rendererFailed) RouteOutline(geometry, accent, Modifier.fillMaxSize())
                        else
                            NativeRouteMap(
                                context,
                                geometry,
                                accent,
                                network,
                                Modifier.fillMaxSize(),
                                onMap = { readyMap, view ->
                                    map = readyMap
                                    viewport = view
                                },
                                onFailure = { rendererFailed = true },
                            )
                        Text(
                            stringResource(R.string.exercise_route_attribution),
                            Modifier.align(Alignment.BottomStart)
                                .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.95f))
                                .clickable {
                                    androidx.core.content.ContextCompat.startActivity(
                                        context,
                                        android.content.Intent(
                                            android.content.Intent.ACTION_VIEW,
                                            android.net.Uri.parse(
                                                "https://www.openstreetmap.org/copyright"
                                            ),
                                        ),
                                        null,
                                    )
                                }
                                .padding(8.dp),
                            style = MaterialTheme.typography.labelSmall,
                        )
                    }
                    Column(
                        Modifier.fillMaxWidth()
                            .heightIn(max = 200.dp)
                            .verticalScroll(rememberScrollState())
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        @OptIn(ExperimentalLayoutApi::class)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(
                                enabled = map != null && !rendererFailed,
                                onClick = {
                                    map?.let { ready ->
                                        viewport?.let { view ->
                                            fitRoute(
                                                ready,
                                                geometry,
                                                density,
                                                view.width,
                                                view.height,
                                            )
                                        }
                                    }
                                },
                            ) {
                                Text(stringResource(R.string.exercise_route_fit))
                            }
                            TextButton(
                                enabled = map != null && !rendererFailed,
                                onClick = { map?.animateCamera(CameraUpdateFactory.zoomIn()) },
                            ) {
                                Text(stringResource(R.string.exercise_route_zoom_in))
                            }
                            TextButton(
                                enabled = map != null && !rendererFailed,
                                onClick = { map?.animateCamera(CameraUpdateFactory.zoomOut()) },
                            ) {
                                Text(stringResource(R.string.exercise_route_zoom_out))
                            }
                        }
                        if (tileState != MapTileNetwork.Status.READY || rendererFailed) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    stringResource(
                                        if (
                                            rendererFailed ||
                                                timedOut ||
                                                tileState == MapTileNetwork.Status.UNAVAILABLE
                                        )
                                            R.string.exercise_route_basemap_unavailable
                                        else R.string.exercise_route_basemap_loading
                                    ),
                                    Modifier.weight(1f),
                                    style = MaterialTheme.typography.bodySmall,
                                )
                                TextButton(onClick = { attempt++ }) {
                                    Text(stringResource(R.string.exercise_route_retry))
                                }
                            }
                        }
                        RouteLegend(accent, route.points.size > 1)
                        Text(
                            stringResource(
                                R.string.exercise_route_points,
                                route.points.size,
                                route.segments.size,
                            ),
                            style = MaterialTheme.typography.bodySmall,
                        )
                        RouteNote(R.string.exercise_route_coordinates_unknown)
                        RouteNote(R.string.exercise_route_network_notice)
                    }
                }
            }
        }
    }
}

private fun mapTileClient(): OkHttpClient =
    OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.SECONDS)
        .addInterceptor { chain ->
            val request =
                chain
                    .request()
                    .newBuilder()
                    .header(
                        "User-Agent",
                        "GalaxyWatchManagerFree/${BuildConfig.VERSION_NAME} (Android; exercise map)",
                    )
                    .build()
            val response = chain.proceed(request)
            if (
                response.isSuccessful &&
                    response.header("Cache-Control") == null &&
                    response.header("Expires") == null
            )
                response.newBuilder().header("Cache-Control", "public, max-age=604800").build()
            else response
        }
        .build()

private class MapTileNetwork {
    enum class Status {
        LOADING,
        READY,
        UNAVAILABLE,
    }

    val status = MutableStateFlow(Status.LOADING)
    val client =
        mapTileClient()
            .newBuilder()
            .addInterceptor { chain ->
                try {
                    val response = chain.proceed(chain.request())
                    status.value =
                        if (response.isSuccessful || response.code == 304) Status.READY
                        else Status.UNAVAILABLE
                    response
                } catch (error: IOException) {
                    status.value = Status.UNAVAILABLE
                    throw error
                }
            }
            .build()
}

private fun assemblePreviewBitmap(plan: PreviewTilePlan, client: OkHttpClient): Bitmap? {
    val tiles = mutableListOf<Triple<Int, Int, Bitmap>>()
    try {
        for (column in plan.tileXRange) {
            for (row in plan.tileYRange) {
                val bytes =
                    try {
                        client
                            .newCall(Request.Builder().url(plan.tileUrl(column, row)).build())
                            .execute()
                            .use { response ->
                                if (!response.isSuccessful) return null
                                response.body?.bytes() ?: return null
                            }
                    } catch (_: IOException) {
                        return null
                    }
                val tile = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
                tiles += Triple(column, row, tile)
            }
        }
        val bitmap =
            Bitmap.createBitmap(plan.widthPixels, plan.heightPixels, Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(bitmap)
        tiles.forEach { (column, row, tile) ->
            canvas.drawBitmap(
                tile,
                ((column - plan.tileXRange.first) * PreviewTilePlan.TILE_SIZE).toFloat(),
                ((row - plan.tileYRange.first) * PreviewTilePlan.TILE_SIZE).toFloat(),
                null,
            )
        }
        return bitmap
    } finally {
        tiles.forEach { it.third.recycle() }
    }
}

@Composable
private fun NativeRouteMap(
    context: Context,
    geometry: ExerciseRouteGeometry,
    accent: Color,
    network: MapTileNetwork,
    modifier: Modifier,
    onMap: (MapLibreMap?, MapView?) -> Unit,
    onFailure: () -> Unit,
) {
    val background = MaterialTheme.colorScheme.surfaceContainerHigh
    val outline = MaterialTheme.colorScheme.surface
    val style by
        produceState<String?>(null, geometry, accent, background, outline) {
            value =
                withContext(Dispatchers.Default) {
                    routeStyle(geometry, accent, background, outline)
                }
        }
    val json = style ?: return
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val mapView =
        remember(context, json) {
            MapLibre.getInstance(context)
            MapView(
                    context,
                    MapLibreMapOptions.createFromAttributes(context)
                        .textureMode(true)
                        .setPrefetchZoomDelta(0),
                )
                .apply { onCreate(null) }
        }
    val density = LocalDensity.current.density
    DisposableEffect(mapView, lifecycle) {
        HttpRequestUtil.setOkHttpClient(network.client)
        HttpRequestUtil.setLogEnabled(false)
        var started = false
        var resumed = false
        fun sync() {
            val shouldStart = lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)
            val shouldResume = lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)
            if (resumed && !shouldResume) {
                mapView.onPause()
                resumed = false
            }
            if (started && !shouldStart) {
                mapView.onStop()
                started = false
            }
            if (!started && shouldStart) {
                mapView.onStart()
                started = true
            }
            if (!resumed && shouldResume) {
                mapView.onResume()
                resumed = true
            }
        }
        val observer = LifecycleEventObserver { _, _ -> sync() }
        lifecycle.addObserver(observer)
        sync()
        val callbacks =
            object : android.content.ComponentCallbacks2 {
                override fun onConfigurationChanged(newConfig: android.content.res.Configuration) =
                    Unit

                override fun onLowMemory() = mapView.onLowMemory()

                override fun onTrimMemory(level: Int) {
                    if (level >= android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW)
                        mapView.onLowMemory()
                }
            }
        context.registerComponentCallbacks(callbacks)
        onDispose {
            lifecycle.removeObserver(observer)
            context.unregisterComponentCallbacks(callbacks)
            onMap(null, null)
            if (resumed) mapView.onPause()
            if (started) mapView.onStop()
            HttpRequestUtil.setOkHttpClient(null)
            network.client.dispatcher.cancelAll()
            network.client.connectionPool.evictAll()
            // MapLibre's onDestroy blocks the UI thread until the GL render
            // thread exits and runs EGL cleanup. Deferring it until after this
            // composition pass lets the view detach and its surface tear down
            // first, avoiding the main-thread EGL race that killed the process
            // when the full-screen map was closed.
            Handler(Looper.getMainLooper()).post { mapView.onDestroy() }
        }
    }
    AndroidView(
        factory = {
            mapView.apply {
                addOnDidFailLoadingMapListener { onFailure() }
                addOnDidFinishLoadingMapListener {
                    network.status.value = MapTileNetwork.Status.READY
                }
                getMapAsync { map ->
                    if (mapView.isDestroyed) return@getMapAsync
                    map.setPrefetchZoomDelta(0)
                    map.uiSettings.apply {
                        isLogoEnabled = false
                        isAttributionEnabled = false
                        isRotateGesturesEnabled = false
                        isTiltGesturesEnabled = false
                    }
                    map.setStyle(Style.Builder().fromJson(json)) {
                        if (!mapView.isDestroyed) {
                            onMap(map, mapView)
                            mapView.post {
                                if (!mapView.isDestroyed)
                                    fitRoute(map, geometry, density, mapView.width, mapView.height)
                            }
                        }
                    }
                }
            }
        },
        modifier = modifier,
    )
}

private fun fitRoute(
    map: MapLibreMap,
    geometry: ExerciseRouteGeometry,
    density: Float,
    widthPixels: Int,
    heightPixels: Int,
) {
    val width = widthPixels / density
    val height = heightPixels / density
    val zoom =
        min(
                log2(max(width - 64, 1f) / (512 * max(geometry.maxX - geometry.minX, 0.000001))),
                log2(max(height - 80, 1f) / (512 * max(geometry.maxY - geometry.minY, 0.000001))),
            )
            .coerceIn(0.0, 16.0)
    map.moveCamera(
        CameraUpdateFactory.newCameraPosition(
            CameraPosition.Builder()
                .target(LatLng(geometry.centerLatitude, geometry.centerLongitude))
                .zoom(zoom)
                .build()
        )
    )
}

internal fun routeStyle(
    geometry: ExerciseRouteGeometry,
    accent: Color,
    background: Color,
    outline: Color,
): String {
    fun color(value: Color) = "#%06x".format(value.toArgb() and 0xffffff)
    fun coordinate(point: ExerciseRouteGeometry.Vertex) =
        JSONArray().put(point.longitude).put(point.latitude)
    val features = JSONArray()
    geometry.segments.forEach { segment ->
        features.put(
            JSONObject()
                .put("type", "Feature")
                .put("properties", JSONObject().put("kind", "route"))
                .put(
                    "geometry",
                    JSONObject()
                        .put("type", if (segment.size > 1) "LineString" else "Point")
                        .put(
                            "coordinates",
                            if (segment.size > 1) JSONArray(segment.map { coordinate(it) })
                            else coordinate(segment.single()),
                        ),
                )
        )
    }
    listOfNotNull(
            "start" to geometry.segments.first().first(),
            ("end" to geometry.segments.last().last()).takeIf {
                geometry.segments.sumOf { segment -> segment.size } > 1
            },
        )
        .forEach { (kind, point) ->
            features.put(
                JSONObject()
                    .put("type", "Feature")
                    .put("properties", JSONObject().put("kind", kind))
                    .put(
                        "geometry",
                        JSONObject().put("type", "Point").put("coordinates", coordinate(point)),
                    )
            )
        }
    fun filter(kind: String) = JSONArray().put("==").put("kind").put(kind)
    val layers =
        JSONArray()
            .put(
                JSONObject()
                    .put("id", "background")
                    .put("type", "background")
                    .put("paint", JSONObject().put("background-color", color(background)))
            )
            .put(JSONObject().put("id", "basemap").put("type", "raster").put("source", "osm"))
            .put(
                JSONObject()
                    .put("id", "route-halo")
                    .put("type", "line")
                    .put("source", "route")
                    .put("filter", filter("route"))
                    .put(
                        "paint",
                        JSONObject().put("line-color", color(outline)).put("line-width", 7),
                    )
            )
            .put(
                JSONObject()
                    .put("id", "route-line")
                    .put("type", "line")
                    .put("source", "route")
                    .put("filter", filter("route"))
                    .put("layout", JSONObject().put("line-cap", "round").put("line-join", "round"))
                    .put(
                        "paint",
                        JSONObject().put("line-color", color(accent)).put("line-width", 4),
                    )
            )
            .put(
                JSONObject()
                    .put("id", "route-points")
                    .put("type", "circle")
                    .put("source", "route")
                    .put("filter", filter("route"))
                    .put(
                        "paint",
                        JSONObject().put("circle-color", color(accent)).put("circle-radius", 3),
                    )
            )
    listOf("start", "end").forEach { kind ->
        layers.put(
            JSONObject()
                .put("id", kind)
                .put("type", "circle")
                .put("source", "route")
                .put("filter", filter(kind))
                .put(
                    "paint",
                    JSONObject()
                        .put("circle-color", color(if (kind == "start") outline else accent))
                        .put("circle-radius", if (kind == "start") 7 else 4)
                        .put("circle-stroke-width", if (kind == "start") 3 else 2)
                        .put("circle-stroke-color", color(if (kind == "start") accent else outline)),
                )
        )
    }
    return JSONObject()
        .put("version", 8)
        .put(
            "sources",
            JSONObject()
                .put(
                    "osm",
                    JSONObject()
                        .put("type", "raster")
                        .put("tileSize", 256)
                        .put("minzoom", 0)
                        .put("maxzoom", 19)
                        .put(
                            "tiles",
                            JSONArray().put("https://tile.openstreetmap.org/{z}/{x}/{y}.png"),
                        ),
                )
                .put(
                    "route",
                    JSONObject()
                        .put("type", "geojson")
                        .put("tolerance", 0)
                        .put(
                            "data",
                            JSONObject().put("type", "FeatureCollection").put("features", features),
                        ),
                ),
        )
        .put("layers", layers)
        .toString()
}
