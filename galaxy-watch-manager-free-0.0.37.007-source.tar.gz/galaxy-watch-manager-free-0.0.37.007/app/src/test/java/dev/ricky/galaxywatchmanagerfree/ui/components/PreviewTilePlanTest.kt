package dev.ricky.galaxywatchmanagerfree.ui.components

import dev.ricky.galaxywatchmanagerfree.feature.ExerciseRoute
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertTrue
import org.junit.Test

class PreviewTilePlanTest {
    private fun geometry(points: List<Pair<Double, Double>>) =
        ExerciseRouteGeometry(
            ExerciseRoute.parse(
                JSONObject()
                    .put(
                        "location_data",
                        JSONArray().apply {
                            points.forEach { (lat, lon) ->
                                put(JSONObject().put("latitude", lat).put("longitude", lon))
                            }
                        },
                    )
            )
        )

    @Test
    fun `plan keeps every vertex inside the bitmap with a surrounding margin`() {
        val geometry = geometry(listOf(30.0 to 110.0, 30.05 to 110.06, 30.02 to 110.1))
        val plan = PreviewTilePlan.of(geometry)
        assertTrue(plan.zoom in 0..16)
        assertTrue(plan.columns in 1..3)
        assertTrue(plan.rows in 1..3)
        geometry.segments.flatten().forEach { vertex ->
            assertTrue(
                "x ${plan.bitmapX(vertex.x)} outside 0..${plan.widthPixels}",
                plan.bitmapX(vertex.x) in 0.0..plan.widthPixels.toDouble(),
            )
            assertTrue(
                "y ${plan.bitmapY(vertex.y)} outside 0..${plan.heightPixels}",
                plan.bitmapY(vertex.y) in 0.0..plan.heightPixels.toDouble(),
            )
        }
    }

    @Test
    fun `single point still receives a small contextual window around it`() {
        val geometry = geometry(listOf(30.0 to 110.0))
        val plan = PreviewTilePlan.of(geometry)
        val vertex = geometry.segments.single().single()
        val x = plan.bitmapX(vertex.x)
        val y = plan.bitmapY(vertex.y)
        assertTrue(x > 0 && x < plan.widthPixels)
        assertTrue(y > 0 && y < plan.heightPixels)
    }

    @Test
    fun `tile rows and urls stay within the world at the chosen zoom`() {
        val geometry = geometry(listOf(30.0 to 110.0, 30.02 to 110.02))
        val plan = PreviewTilePlan.of(geometry)
        val worldTiles = 1 shl plan.zoom
        for (column in plan.tileXRange) {
            for (row in plan.tileYRange) {
                assertTrue(column in 0 until worldTiles)
                assertTrue(row in 0 until worldTiles)
                assertTrue(plan.tileUrl(column, row).endsWith("/$column/$row.png"))
            }
        }
    }

    @Test
    fun `dateline route uses the unwrapped rendering copy and stays covered`() {
        val geometry = geometry(listOf(30.0 to 179.9, 30.1 to -179.9))
        val plan = PreviewTilePlan.of(geometry)
        assertTrue(geometry.maxX - geometry.minX < 0.001)
        geometry.segments.flatten().forEach { vertex ->
            assertTrue(plan.bitmapX(vertex.x) >= 0)
            assertTrue(plan.bitmapY(vertex.y) in 0.0..plan.heightPixels.toDouble())
        }
    }

    @Test
    fun `route near the pole maps into the topmost tiles without escaping the bitmap`() {
        val geometry = geometry(listOf(85.0 to 110.0, 85.01 to 110.01))
        val plan = PreviewTilePlan.of(geometry)
        geometry.segments.flatten().forEach { vertex ->
            assertTrue(plan.bitmapY(vertex.y) >= 0)
            assertTrue(plan.bitmapX(vertex.x) in 0.0..plan.widthPixels.toDouble())
        }
    }
}
