package dev.ricky.galaxywatchmanagerfree.feature

import dev.ricky.galaxywatchmanagerfree.wcs.CompanionProfile
import dev.ricky.galaxywatchmanagerfree.wcs.DataMapDecoder
import dev.ricky.galaxywatchmanagerfree.wcs.DataMapEncoder
import dev.ricky.galaxywatchmanagerfree.wcs.Proto
import dev.ricky.galaxywatchmanagerfree.wcs.WcsFrame
import dev.ricky.galaxywatchmanagerfree.wcs.WcsPaths
import dev.ricky.galaxywatchmanagerfree.wcs.WearDataSnapshot
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class WatchDndControlTest {
    private val uri = "wear://7e57c0de${WcsPaths.SET_PHONE_DND_TURN_ON}"
    private val original =
        mapOf<String, Any>(
            "from" to "watch",
            "key" to "booleanIsChecked",
            "type" to 0L,
            "booleanIsChecked" to false,
            "time" to 100L,
            "intZenDuration" to 60,
            "longZenDurationEndtime" to 900_000L,
            "priorityCategoryAlarms" to true,
            "priorityCallSenders" to 2,
            "arrayExceptionContacts" to listOf("synthetic-contact"),
        )

    private inner class Fixture(scope: CoroutineScope) {
        var watchNode = "7e57c0de"
        var value: Boolean? = null
        var pending: Boolean? = null
        var readSucceeds = true
        var writeSucceeds = true
        val events = mutableListOf<String>()
        val frames = mutableListOf<ByteArray>()
        val results = mutableListOf<WatchDndControl.Result>()
        val control =
            WatchDndControl(
                scope,
                watchNode = { watchNode },
                requestRead = {
                    events += "read"
                    readSucceeds
                },
                write = { uri, data ->
                    events += "write"
                    frames +=
                        WcsFrame.wearPathFrame(
                            path = uri,
                            dataItems = listOf(DataMapEncoder.encode(data)),
                            senderPkg = CompanionProfile.WATCH7.packageName,
                            nodeId = "c0ffee12",
                            seqId = 42L,
                        )
                    writeSucceeds
                },
                onValue = { value = it },
                onPending = { pending = it },
                onResult = results::add,
                now = { 200L },
            )
    }

    @Test
    fun `toggle rewrites the watch owned item and preserves its policy in the actual frame`() =
        runTest {
            val f = Fixture(this)
            f.control.receive(uri, original)
            f.control.connect()
            f.control.setEnabled(true)

            val item = Proto.parse(f.frames.single().drop(4).toByteArray()).nested(1)!!.nested(9)!!
            assertEquals(uri, item.text(2))
            assertEquals("c0ffee12", item.text(7))
            assertEquals(WcsPaths.SIGNATURE_PLUGIN, item.text(9))
            assertEquals(
                original
                    .minus("longZenDurationEndtime")
                    .plus(
                        mapOf(
                            "booleanIsChecked" to true,
                            "from" to "phone",
                            "time" to 200L,
                            "intZenDuration" to 0,
                        )
                    ),
                DataMapDecoder.decode(item.raw(4)!!),
            )
            assertEquals(listOf("write", "read"), f.events)
            f.control.disconnect()
        }

    @Test
    fun `queued writes and phone echoes never become confirmed watch state`() = runTest {
        val f = Fixture(this)
        f.control.receive(uri, original)
        f.control.connect()
        f.control.setEnabled(true)

        assertEquals(false, f.value)
        assertEquals(true, f.pending)
        f.control.receive(uri, original + mapOf("from" to "phone", "booleanIsChecked" to true))
        assertEquals(false, f.value)
        assertFalse(WatchDndControl.Result.CONFIRMED in f.results)
        f.control.receive(uri, original + ("booleanIsChecked" to true))
        assertEquals(true, f.value)
        assertNull(f.pending)
        assertEquals(WatchDndControl.Result.CONFIRMED, f.results.last())
        f.control.disconnect()
    }

    @Test
    fun `missing template is read before writing even if its value already matches the target`() =
        runTest {
            val f = Fixture(this)
            f.control.connect()
            f.control.setEnabled(false)
            assertEquals(listOf("read"), f.events)
            assertEquals(false, f.pending)
            assertTrue(f.frames.isEmpty())

            f.control.receive(uri, original)
            assertEquals(listOf("read", "write", "read"), f.events)
            val written =
                WcsFrame.decode(f.frames.single().drop(4).toByteArray())
                    as WcsFrame.Incoming.WearPath
            assertEquals(false, written.dataMap["booleanIsChecked"])
            assertFalse(WatchDndControl.Result.CONFIRMED in f.results)
            f.control.receive(uri, original)
            assertEquals(WatchDndControl.Result.CONFIRMED, f.results.last())
            assertNull(f.pending)
            f.control.disconnect()
        }

    @Test
    fun `restored phone echo supplies a watch owned template without confirming its value`() =
        runTest {
            val snapshot = WearDataSnapshot()
            val frame =
                WcsFrame.wearPathFrame(
                    path = uri,
                    dataItems = listOf(DataMapEncoder.encode(original + ("from" to "phone"))),
                    senderPkg = CompanionProfile.WATCH7.packageName,
                    nodeId = "c0ffee12",
                    seqId = 41L,
                )
            assertTrue(snapshot.accept(frame.drop(4).toByteArray()))
            val restored = WearDataSnapshot()
            restored.restore(snapshot.encode())
            val f = Fixture(this)
            restored.envelopes().forEach { envelope ->
                val item = WcsFrame.decode(envelope) as WcsFrame.Incoming.WearPath
                f.control.receive(item.path, item.dataMap)
            }
            assertNull(f.value)
            f.control.connect()
            f.control.setEnabled(true)
            assertEquals(listOf("write", "read"), f.events)
            val written =
                WcsFrame.decode(f.frames.single().drop(4).toByteArray())
                    as WcsFrame.Incoming.WearPath
            assertEquals(uri, written.path)
            assertEquals(true, written.dataMap["booleanIsChecked"])
            assertNull(f.value)
            f.control.disconnect()
        }

    @Test
    fun `wrong owners paths keys and value types cannot supply a template or confirm a command`() =
        runTest {
            val f = Fixture(this)
            f.control.connect()
            f.control.setEnabled(true)
            val invalid =
                listOf(
                    "wear://c0ffee12${WcsPaths.SET_PHONE_DND_TURN_ON}" to original,
                    "wear://deadbeef${WcsPaths.SET_PHONE_DND_TURN_ON}" to original,
                    "wear://7e57c0de${WcsPaths.SET_INFO_WATCH_NAME}" to original,
                    uri to (original + ("key" to "other")),
                    uri to (original + ("booleanIsChecked" to "true")),
                )
            invalid.forEach { (source, data) -> f.control.receive(source, data) }
            assertTrue(f.frames.isEmpty())
            assertNull(f.value)
            assertEquals(true, f.pending)
            f.control.disconnect()
        }

    @Test
    fun `unavailable source times out without a write or a submitted result`() = runTest {
        val f = Fixture(this)
        f.control.connect()
        f.control.setEnabled(true)
        advanceTimeBy(SettingCommands.CONFIRM_TIMEOUT_MS)
        runCurrent()
        assertEquals(WatchDndControl.Result.SOURCE_UNAVAILABLE, f.results.last())
        assertNull(f.pending)
        assertTrue(f.frames.isEmpty())
        f.control.receive(uri, original)
        assertTrue(f.frames.isEmpty())
        f.control.disconnect()
    }

    @Test
    fun `unconfirmed write clears pending and keeps the last confirmed state`() = runTest {
        val f = Fixture(this)
        f.control.receive(uri, original)
        f.control.connect()
        f.control.setEnabled(true)
        f.control.receive(uri, original)
        assertEquals(true, f.pending)
        advanceTimeBy(SettingCommands.CONFIRM_TIMEOUT_MS)
        runCurrent()
        assertEquals(WatchDndControl.Result.SUBMITTED, f.results.last())
        assertNull(f.pending)
        assertEquals(false, f.value)
        assertEquals(1, f.frames.size)
        f.control.receive(uri, original + ("booleanIsChecked" to true))
        assertEquals(true, f.value)
        assertFalse(WatchDndControl.Result.CONFIRMED in f.results)
        f.control.disconnect()
    }

    @Test
    fun `failed reads and writes clear pending without changing confirmed state`() = runTest {
        val readFailure = Fixture(this)
        readFailure.control.connect()
        readFailure.readSucceeds = false
        readFailure.control.setEnabled(true)
        assertEquals(WatchDndControl.Result.SEND_FAILED, readFailure.results.last())
        assertNull(readFailure.pending)
        assertTrue(readFailure.frames.isEmpty())
        readFailure.control.disconnect()

        val writeFailure = Fixture(this)
        writeFailure.control.receive(uri, original)
        writeFailure.control.connect()
        writeFailure.writeSucceeds = false
        writeFailure.control.setEnabled(true)
        assertEquals(WatchDndControl.Result.SEND_FAILED, writeFailure.results.last())
        assertEquals(listOf("write"), writeFailure.events)
        assertNull(writeFailure.pending)
        assertEquals(false, writeFailure.value)
        writeFailure.control.disconnect()
    }

    @Test
    fun `new command replaces the pending target and its timeout`() = runTest {
        val f = Fixture(this)
        f.control.connect()
        f.control.setEnabled(true)
        advanceTimeBy(3_000)
        f.control.setEnabled(false)
        advanceTimeBy(1_000)
        runCurrent()
        assertEquals(false, f.pending)
        f.control.receive(uri, original)
        val written =
            WcsFrame.decode(f.frames.single().drop(4).toByteArray()) as WcsFrame.Incoming.WearPath
        assertEquals(false, written.dataMap["booleanIsChecked"])
        assertFalse(WatchDndControl.Result.CONFIRMED in f.results)
        f.control.receive(uri, original)
        assertEquals(WatchDndControl.Result.CONFIRMED, f.results.last())
        f.control.disconnect()
    }

    @Test
    fun `disconnect cancels commands and reconnect never uses another watch template`() = runTest {
        val f = Fixture(this)
        f.control.receive(uri, original)
        f.control.connect()
        f.control.setEnabled(true)
        f.control.disconnect()
        assertNull(f.pending)
        f.control.receive(uri, original + ("booleanIsChecked" to true))
        advanceTimeBy(SettingCommands.CONFIRM_TIMEOUT_MS)
        runCurrent()
        assertEquals(false, f.value)
        assertEquals(listOf(WatchDndControl.Result.PENDING), f.results)
        f.control.setEnabled(true)
        assertEquals(WatchDndControl.Result.SEND_FAILED, f.results.last())
        assertEquals(1, f.frames.size)

        f.watchNode = "deadbeef"
        f.control.connect()
        f.control.setEnabled(true)
        assertEquals(listOf("write", "read", "read"), f.events)
        f.control.receive(uri, original)
        assertEquals(1, f.frames.size)
        f.control.receive("wear://deadbeef${WcsPaths.SET_PHONE_DND_TURN_ON}", original)
        val written =
            WcsFrame.decode(f.frames.last().drop(4).toByteArray()) as WcsFrame.Incoming.WearPath
        assertEquals("wear://deadbeef${WcsPaths.SET_PHONE_DND_TURN_ON}", written.path)
        f.control.disconnect()
    }
}
