package dev.ricky.galaxywatchmanagerfree.ui.components

import androidx.compose.ui.graphics.Color
import dev.ricky.galaxywatchmanagerfree.feature.ExerciseRoute
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class ExerciseRouteGeometryTest {
    private fun route(vararg points: Pair<Double, Double>) =
        ExerciseRoute.parse(
            JSONObject()
                .put(
                    "location_data",
                    JSONArray().apply {
                        points.forEach { (lat, lon) ->
                            put(JSONObject().put("latitude", lat).put("longitude", lon))
                        }
                    },
                )
        )

    private fun style(route: ExerciseRoute.Route) =
        JSONObject(routeStyle(ExerciseRouteGeometry(route), Color.Blue, Color.White, Color.Black))

    private fun features(style: JSONObject) =
        style
            .getJSONObject("sources")
            .getJSONObject("route")
            .getJSONObject("data")
            .getJSONArray("features")

    @Test
    fun `dateline crossing fits nearby points without rewriting source coordinates`() {
        val route = route(30.0 to 179.9, 30.1 to -179.9)
        val geometry = ExerciseRouteGeometry(route)
        assertTrue(geometry.maxX - geometry.minX < 0.001)
        assertEquals(180.0, geometry.centerLongitude, 0.0001)
        assertEquals(-179.9, route.points.last().longitude, 0.0)
        val coordinates =
            features(style(route))
                .getJSONObject(0)
                .getJSONObject("geometry")
                .getJSONArray("coordinates")
        assertEquals(179.9, coordinates.getJSONArray(0).getDouble(0), 0.0001)
        assertEquals(180.1, coordinates.getJSONArray(1).getDouble(0), 0.0001)
    }

    @Test
    fun `mercator clamps poles only in rendering copy`() {
        val route = route(90.0 to 110.0, -90.0 to 110.0)
        val geometry = ExerciseRouteGeometry(route)
        assertTrue(geometry.minY.isFinite() && geometry.maxY.isFinite())
        assertTrue(geometry.segments.flatten().all { it.latitude in -85.05112878..85.05112878 })
        assertEquals(90.0, route.points.first().latitude, 0.0)
        assertEquals(-90.0, route.points.last().latitude, 0.0)
        assertEquals(0.0, geometry.centerLatitude, 0.00001)
    }

    @Test
    fun `invalid row separates rendered lines and singleton stays a marker`() {
        val route = route(30.0 to 110.0, 30.1 to 110.1, 0.0 to 0.0, 31.0 to 111.0)
        val geometry = ExerciseRouteGeometry(route)
        assertEquals(listOf(2, 1), geometry.segments.map { it.size })
        val features = features(style(route))
        assertEquals(4, features.length())
        assertEquals(
            "LineString",
            features.getJSONObject(0).getJSONObject("geometry").getString("type"),
        )
        assertEquals("Point", features.getJSONObject(1).getJSONObject("geometry").getString("type"))
        assertEquals(
            "start",
            features.getJSONObject(2).getJSONObject("properties").getString("kind"),
        )
        assertEquals("end", features.getJSONObject(3).getJSONObject("properties").getString("kind"))
    }

    @Test
    fun `single point never generates a line or finish marker`() {
        val features = features(style(route(30.0 to 110.0)))
        assertEquals(2, features.length())
        assertEquals("Point", features.getJSONObject(0).getJSONObject("geometry").getString("type"))
        assertEquals(
            "start",
            features.getJSONObject(1).getJSONObject("properties").getString("kind"),
        )
    }

    @Test
    fun `dense track style retains all points and identifies external tile source`() {
        val points = JSONArray()
        repeat(12020) {
            points.put(JSONObject().put("latitude", 30.0 + it * 0.000001).put("longitude", 110.0))
        }
        val route = ExerciseRoute.parse(JSONObject().put("location_data", points))
        val style = style(route)
        assertEquals(
            12020,
            features(style)
                .getJSONObject(0)
                .getJSONObject("geometry")
                .getJSONArray("coordinates")
                .length(),
        )
        assertEquals(
            "raster",
            style.getJSONObject("sources").getJSONObject("osm").getString("type"),
        )
        assertFalse(style.has("glyphs"))
        assertFalse(style.has("sprite"))
    }
}
