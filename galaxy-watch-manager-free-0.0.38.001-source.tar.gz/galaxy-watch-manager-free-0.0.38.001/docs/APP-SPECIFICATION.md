# Galaxy Watch Manager Free 程序架构与功能全景规范

> **状态基线**：v0.0.38.001 Nightly (versionCode: 38001) · 2026-11-17（Flow 联网代理与校时应答的真机联网已验收，校时与耗电边界见验收记录）  
> **维护规则**：本文档为应用实际架构、核心组件与功能实现的真实全景基线。后续有任何新功能接入、协议变动、数据结构修改或界面调整，**必须在同一变更中回补本文档**，保持文档与代码严格一致。

---

## 1. 概述与核心定位

**Galaxy Watch Manager Free** 是一个独立运行于 Android 系统的 Samsung Galaxy Watch（Galaxy Watch 4 / 5 / 6 / 7 / Ultra 系列）手表管理应用。本应用从 `galaxy-watch-tweaker` 实验模块独立拆分而来，采用标准 Android 蓝牙 API，无需 Root、无需修改手表固件即可在任意 Android 设备（包括非三星手机）上完整管理手表。

### 1.1 核心设计哲学

1. **直接连接与协议突破**：使用原生 Android Bluetooth RFCOMM 套接字与手表内置的 WCS（Wearable Communication Service）直接建立双向通信，无需三星官方 Galaxy Wearable、Watch Plugin 介入或转发。
2. **官方功能与身份兼容**：保留手表全部原生特性，通过逆向突破 GMS `OemCompanionVerifier` 鉴权与 WCS `feature_exchange` 身份协商，支持在非三星手机上使用 Samsung Health Monitor（ECG 心电图与血压记录/校准）。
3. **数据主权与离线优先**：健康记录、睡眠分析、诊断日志均保存在手机本地私有存储中。随包附带本地端侧睡眠推理引擎，无需任何第三方云端依赖；地图底图采用天地图标准服务，轨迹绘制完全在端侧完成。
4. **状态真实与解耦校验**：UI 展示与设备确认严格解耦；支持免打扰与核心设置的即时乐观呈现，同时以手表底层状态回传为最终校准基准；未知值和有效零值严格区分，禁止构造虚假占位数据。
5. **无损交接与共存机制**：通过内置的官方连接交接模块（支持 Shizuku 一键启停或系统手动指引），可随时在「本应用直连」与「官方应用接管」之间无损切换，不损坏官方配对与数据。

---

## 2. 全局分层架构与核心数据流

应用采用清晰的单向数据流与分层驱动模型，各层职责明确，线程与锁边界清晰：

```mermaid
flowchart TD
    subgraph UI ["表现层 (Compose UI)"]
        Activity[MainActivity / HomeScreen]
        Tabs[Dashboard / Health / WatchFace / Settings]
        Sheets[Detail Sheets: Step / Sleep / HR / Stress / ECG / BP / Exercise / Vascular]
    end

    subgraph ServiceLayer ["服务与生命周期管理层"]
        Service[WatchConnectionService]
        Controller[WatchController]
        Gate[ConnectionRequestGate]
        NotifService[NotificationBridgeService]
    end

    subgraph DomainLayer ["业务领域与仓储门面层"]
        WatchRepo[WatchRepository]
        HealthRepo[HealthRepository]
        Handover[OfficialAppHandover]
        SyncCoord[HealthSyncCoordinator]
        AutoQuery[AutoQueryCoordinator]
        SettingSchema[WatchSettingSchema / SettingCommands]
    end

    subgraph ProtocolLayer ["协议编排与传输层"]
        Session[WcsSession]
        Assembler[WcsPieceAssembler]
        Transport[RfcommTransport]
        FlowProxy[FlowProxyServer / FlowProxySession]
        TimeSync[PhoneTimeSync]
        BleWake[BleWakeLock]
        Bridger[BridgerNotificationSender]
        MonitorSess[HealthMonitorSession]
    end

    subgraph StorageLayer ["数据存储与导出层"]
        DevPrefs[DevicePreferences / DeviceIdentityStore]
        RecordStore[HealthRecordStore]
        SleepStore[LocalSleepAnalyzer / ManualNapStore]
        LogStore[DiagnosticLogStore]
        Archive[HealthArchive / HealthExportData]
    end

    %% UI to Service & Facade
    Activity --> Controller
    Tabs --> WatchRepo
    Tabs --> HealthRepo
    Sheets --> HealthRepo
    Sheets --> WatchRepo

    %% Lifecycle
    Service --> Controller
    Controller --> Gate
    Controller --> Transport
    Controller --> Session
    Controller --> WatchRepo

    %% Notifications
    NotifService --> Bridger
    Bridger --> Session

    %% Repository dependencies
    WatchRepo --> Session
    WatchRepo --> HealthRepo
    WatchRepo --> SettingSchema
    WatchRepo --> AutoQuery
    HealthRepo --> SyncCoord
    HealthRepo --> MonitorSess
    HealthRepo --> RecordStore
    HealthRepo --> SleepStore
    HealthRepo --> Archive
    Handover --> DevPrefs

    %% Protocol connection
    Session --> Transport
    Session --> TimeSync
    Transport --> FlowProxy
    MonitorSess --> Session
    Session --> WatchRepo
    Transport --> BleWake

    %% State flow back to UI
    WatchRepo -.->|WatchState Flow| Tabs
    HealthRepo -.->|HealthDataProjection| Tabs
```

### 2.1 关键线程模型与并发控制

- **RFCOMM 传输线程**：`RfcommTransport` 内部由读线程驱动阻塞式 `InputStream.read()`，写操作通过独立锁与缓冲队列入队。连接锁 `connectionLock` 与生命周期锁 `lifecycleLock` 严格分离，生命周期回调绝不持有连接锁，避免死锁。
- **协议路由线程**：`WcsSession` 在读线程解包分片与 Protobuf 信封后，通过观察者回调派发至 `WatchRepository.onMessage` 与 `HealthRepository.handleMessage`。
- **Flow 代理线程**：独立 RFCOMM 监听与单会话读取/写入线程负责 Flow 字节流；NIO Selector 负责非阻塞 IPv4 TCP/UDP 转发，有界队列在拥塞时暂停网络读取。手机默认网络回调只发布类型与计费状态，转发不进入主线程。
- **后台计算协程**：健康记录的聚合计算（`HealthDataProjection`）、端侧睡眠分期推理（`LocalSleepAnalyzer`）以及 ZIP 归档导出（`HealthArchive`）均运行在 `Dispatchers.IO` / `Dispatchers.Default` 协程池中，绝不阻塞主线程。
- **状态快照发布**：`WatchRepository` 维护不可变的 `WatchState` 快照，通过 Kotlin `StateFlow` 对 UI 暴露。更新时发布全新快照，严禁原地修改集合或内部状态。

---

## 3. 核心控制器与生命周期管理

### 3.1 WatchController (`core/WatchController.kt`)
- **职责**：维护全局连接状态机、当前设备 MAC、服务启动与停止、以及官方应用交接过渡。
- **连接代次守卫 (`core/ConnectionRequestGate.kt`)**：每次发起连接或身份读取分配单调递增的代次 ID。异步回调返回时检查代次有效性，杜绝过时的连接尝试或失效回调覆盖当前状态。
- **广播接收器 (`core/WatchCommandReceiver.kt`)**：支持系统或外部意图触发的手表控制命令（如后台定时连接、刷新）。

### 3.2 WatchConnectionService (`service/WatchConnectionService.kt`)
- **前台保活服务**：注册为 Android 前台服务，持有系统通知以防止后台被杀。
- **动态状态栏通知 (`feature/ConnectionNotificationSnapshot.kt`)**：通知栏实时展示当前连接状态（连接中、已连接、维持连接），并在已连接时动态刷新今日步数、心率、目标完成百分比与手表电量；当无关数据变动时不引起通知重绘抖动。

---

## 4. 传输层与 WCS 协议栈实现

### 4.1 RFCOMM 直连传输 (`wcs/RfcommTransport.kt`)
- **双向竞争接入**：同时启动 BluetoothServerSocket 监听（等待手表主动连入）与 BluetoothSocket 发起主动连接，先成功者接管通信信道，失败方优雅关闭。
- **重连退避策略 (`wcs/ReconnectPolicy.kt`)**：主动重连实施指数退避限制，并辅以 `BleWakeLock` 控制 BLE 广播唤醒频次，防止手表与手机在低电量下频繁唤醒造成电量损耗。
- **官方按需心跳与低频兜底**：`WcsSession` 在组装出完整消息后，对非心跳消息调用 `RfcommTransport.markInboundNonHeartbeat()`；writer 在发送队列排空时补发一次官方空心跳（`inner=5a00`，摘要由内容计算，不依赖配对凭据），不对心跳回心跳。无任何入站时由 writer 的 60 秒轮询超时发送一次兜底心跳，已移除独立 10 秒心跳线程。

### 4.2 WCS 协议分包与会话管理 (`wcs/WcsFrame.kt`, `wcs/WcsSession.kt`)
- **帧与分片重组**：还原 WCS 底层帧结构，通过 `WcsPieceAssembler` 组装超长分片数据包，校验数据包长度与序列完整性。
- **Generation 重排队列**：完整还原 Google Wearable RPC 的 `generation` 重排队列机制。在连接断开重连、序列号重置时，自动比对并重排代次，彻底消除请求静默丢弃问题。
- **官方协议路径集 (`wcs/WcsPaths.kt`)**：
  - `/wcs_extension/sysui/watchface`：表盘查询、收藏夹排序与切换。
  - `/samsung_health/wearable_message`：三星健康双向 gzip 游标同步信道。
  - `/991`：Samsung Health Monitor (SHM) ECG 与血压传输及校准信道。
  - `/bridger/...`：Wear OS 规范的通知桥接 DataItem 路径。
  - `/remote_intent/rpc`：远程意图拉起通道。

### 4.3 关键身份兼容补丁 (不可删除的兼容基准)
- **GMS Companion 鉴权突破 (`wcs/IdentityProof.kt`)**：携带官方三星可穿戴应用包名与官方证书 SHA-256 签名，通过手表底层 GMS `OemCompanionVerifier` 验证。
- **WCS 状态交换兼容身份 (`wcs/PhoneFeature.kt`)**：在 `feature_exchange` 中模拟三星兼容手机身份（`deviceName="Galaxy S25 Ultra"`, `modelNumber="SM-S938U1"`, `vender="samsung"`, `isTablet="false"`, `csc="XAA"`）。**此项是确保非三星手机能够接收健康监测器 ECG/血压以及手表高级设置的基石，严禁清理或改回宿主手机真实 `Build.*`**。

---

## 5. 核心业务功能与状态机实现全景

### 5.1 设备概览与快速控制 (Dashboard Tab)
- **运行内存管理 (`memory/clean`)**：
  - 手表端当前 RAM 使用量、可用量及活跃后台进程列表查询。
  - 一键清理（`memory/clean` RPC）：向手表下发清理调度请求，有界等待手表底层进程清理完成后自动回读，呈现真实释放后的 RAM 快照。
- **免打扰 (Do Not Disturb / DND)**：
  - **即时乐观交互**：手机端点击开关后立即在界面更新为目标状态（`dndSubmitted ?: dndOn`），无需等待手表网络回传。
  - **连续反向点击支持**：如果在手表确认前再次点击，立即触发反向切换命令并刷新界面目标，避免界面卡死在「已请求/未确认」状态。
  - **定向节点下发**：请求优先解析手表目标节点 ID 下发；无目标节点时不构造空请求。
  - **回声校验**：手表端回传真实状态时，执行一次性覆盖校对，保证最终一致性。
- **快速控制磁贴 (Quick Controls)**：
  - 省电模式 (PSM)：双向状态同步与超时补发。
  - 睡眠模式 (Bedtime) 与影院模式 (Theater)。
  - 屏幕辅助功能：黑白灰度模式 (Grayscale) 与高对比度文字，通过 Tag 9 DataItem 联动 Dalvik ExclusiveTaskManager 实时生效。
- **官方表盘切换 (`WatchFaceScreen.kt`)**：
  - 接入 43 款官方旗舰预设表盘（包含 Galaxy Watch Ultra 独占表盘）。
  - 本地随包提供 43 张逐款高清效果示意图（概览页设备卡片与表盘图库复用同一矢量资源）。
  - 一键下发切换，手表底层 `WallpaperService` 实时响应，手机卡片双向同步当前活跃表盘。
- **手表改名 (Alias Name)**：
  - 通过手表官方 Alias DataItem URI 修改手表蓝牙显示名称，修改后主动回读并在重连及进程重启后正确持久化。

### 5.2 双源健康数据同步体系 (Health Sync)
系统将健康数据通道正交解耦为两个独立子系统，实现双源独立握手与协同管理：

```mermaid
sequenceDiagram
    participant App as 手机应用 (HealthSyncCoordinator)
    participant WCS as 三星健康信道 (/samsung_health)
    participant SHM as 健康监测器信道 (/991)

    Note over App: 触发同步 (定时/下拉刷新/手动点击)
    par 三星健康同步
        App->>WCS: REQUEST_DATA (发送游标)
        WCS-->>App: SYNC_DATA (分块 gzip 记录上报)
        App->>WCS: LOG_DATA (回写持久化确认游标)
    and 健康监测器同步
        App->>SHM: 握手并拉取 ECG / 血压
        SHM-->>App: 回传采样点与测量记录
        App->>SHM: 确认接收完成
    end
    Note over App: 聚合两路结果，独立更新状态并触发数据投影
```

- **通道 1：三星健康通道 (`/samsung_health/wearable_message`)**：
  - 双向三段式 gzip 游标握手协议：`REQUEST_DATA` → `SYNC_DATA` → `LOG_DATA`。
  - 覆盖步数、分时段步数（`pedometer_step_count`）、心率（单次与连续）、压力指数、活动热量等 80+ 模块。
  - 游标在且仅在数据写入本地 `HealthRecordStore` 持久化成功后才向手表回写，保证不丢数据。
- **通道 2：健康监测器通道 (`/991` & `HealthMonitorSession`)**：
  - 专用于 ECG 心电波形（包含采样点、采样率、手表分类）及血压记录的接收。
  - **袖带血压三轮校准编排**：由手机端向导编排三轮袖带测量，录入真实袖带高压/低压读数，合并发送给手表官方算法完成校准；消除了导致手表端闪退的并发 Intent 冲突。
- **双源状态呈现 (`HealthSyncSummary`)**：
  - 两路同步分别维护握手状态与超时保护。
  - UI 精确区分：「全部同步成功」、「仅三星健康已同步」、「仅健康监测器已同步」、「健康数据部分同步」以及错误提示。

### 5.3 运动记录与天地图轨迹地图 (Exercise & Routes)
- **运动类型支持**：完整支持 100+ 种官方运动模式（跑步、健走、户外骑行、徒步、游泳、器械训练等）。
- **轨迹数据还原 (`feature/ExerciseRoute.kt`)**：
  - 自动解算原始运动位置资料中的经纬度序列、时间戳、海拔、分段与距离信息。
  - 无坐标记录如实声明「未收到地图轨迹」，绝不绘制虚假路线。
- **MapLibre 11.8.0 与天地图集成 (`ui/screens/ExerciseTab.kt`)**：
  - 地图底图采用天地图标准 WMTS 瓦片服务（`vec_w` 矢量底图 + `cva_w` 矢量中文注记图层）。
  - 轨迹在手机端本地离线计算并叠加渲染，绘制起点标记、终点标记与轨迹连线。
  - 支持双指缩放、旋转、全程自适应缩放（Fit Bounds）与全屏交互。
  - 声明网络隐私提示：底图经由天地图加载，轨迹在端侧绘制。

### 5.4 端侧离线睡眠分析与小睡记录 (Sleep Subsystem)
- **端侧睡眠推理引擎 (`feature/LocalSleepAnalyzer.kt`)**：
  - 随包内置 ARM64 与 ARMv7 架构 Native 推理运行时与模型，无网络调用，数据纯本地推理。
  - 解析手表睡眠原始传感器数据，还原清醒、浅睡、深睡、REM 快速眼动期四段分期及睡眠呼吸暂停筛查。
- **多段睡眠合并与去重 (`feature/SleepParser.kt`)**：
  - 自动识别同一自然日内的多段睡眠并进行时间线合并与重叠去重。
- **本机小睡记录 (`feature/ManualNapStore.kt`)**：
  - 当手表漏记白天小睡时，支持用户手动补记起止时间。
  - 小睡记录保存在手机本地，按配对设备 MAC 隔离，与夜间睡眠合并计算当日总时长，不篡改手表端原始数据。

### 5.5 通知桥接与应用图标推送 (Notification Bridge)
- **通知监听与筛选 (`feature/NotificationBridgeService.kt`)**：
  - 继承 Android 原生 `NotificationListenerService`。
  - 支持配置全部应用转发或仅白名单应用转发。
  - 支持配置免打扰时间段过滤，过滤常驻通知与系统摘要。
- **Wear OS Bridger DataItem 规范**：
  - 将手机通知格式化为 `wear://<phoneNode>/bridger/stream_item:…` 标准 DataItem 广播至手表。
- **应用高清图标提取与下发**：
  - 实时从手机 PackageManager 提取应用图标并缩放为适配手表端规格的 Bitmap 资产。
  - 采用官方 V1/V2 资产通道编码发送，并严格处理手表回传的 `AckAsset` 确认，确保图标可靠显示在手表通知卡片中。

### 5.6 官方应用连接交接 (Handover Subsystem)
- **无损连接接管与恢复 (`feature/handover/OfficialAppHandover.kt`)**：
  - 解决官方 Wear OS / Galaxy Wearable 与本应用在后台争抢手表 RFCOMM 蓝牙通道的根本冲突。
- **双模操作方案**：
  - **Shizuku 一键操作**：通过 Shizuku 授权，一键安全停用或恢复官方应用包（Galaxy Wearable、Watch4/5/6/7 插件包、Wear OS / Wear OS 中国版），无须 Root。
  - **免 Shizuku 手动方案**：提供系统应用详情页快捷入口与清晰操作向导，支持手动停用与恢复。
- **事务日志保护 (`feature/handover/HandoverJournal.kt`)**：
  - 在改动系统包状态前，将原始启用状态持久化到恢复日志中；交还官方控制权时自动停止本应用自动重连并全量恢复官方应用，杜绝残留竞争。

### 5.7 全量健康数据联动导出 (Health Export v4)
- **导出边界与覆盖范围**：
  - 覆盖当前配对设备在手机中存储的**全部留存历史记录**，不以 UI 当前视图或日历选择窗口为界限。
- **归档格式与文件清单 (ZIP)**：
  - `manifest.json`：导出版本（v4）、设备标识（脱敏处理）、时间范围、各文件记录条数与 SHA-256 校验和。
  - 标准化 JSON：`steps.json`, `heart_rate.json`, `sleep.json`, `workouts.json`, `workout_routes.json`, `ecg.json`, `blood_pressure.json`, `vascular_load.json`。
  - 汇总 CSV：便于数据科学工具及电子表格直接分析。
  - 原始记录：保留未经修改的手表上报原始二进制与字段，保留算法版本与单位。
- **ECG 高清图片导出 (`core/EcgImageRenderer.kt`)**：
  - 将心电波形、采样率、心率值与标准 25mm/s、10mm/mV 医学网格渲染为高分辨率 PNG，保存至系统相册。

### 5.8 升级检测与双通道发布体系
- **发布通道严格隔离**：
  - **稳定版通道**：清单由 `crossly/galaxy-watch-manager-free-feed` 仓库的 `version.json` 维护，APK 托管于 `apk` 分支，采用不可变提交 SHA 访问路径。
  - **Nightly 通道**：清单由 `nightly.json` 维护，APK 托管于 `apk-nightly` 分支，版本号形如 `0.0.X.YYY`。
  - 稳定版客户端不接收测试版更新；稳定版发布不会破坏或覆盖已有的 Nightly 发布。
- **本地三重安全防线**：
  - 强制 HTTPS 传输，防范中间人篡改。
  - 下载文件大小上限校验与 SHA-256 完整性哈希校验。
  - 本地解析 APK 确认包名 `dev.ricky.galaxywatchmanagerfree`、版本号与发布签名证书 SHA-256（`86de4a33245393411b43ad0d4fa99233f0ca6f926cef6f60982eac9eba3f1525`）一致。

### 5.9 设置体系与双轨自诊断日志
- **78+ 项手表设置 Schema (`feature/WatchSettingSchema.kt`)**：
  - 声明式覆盖显示、声音与振动、按钮手势、高级辅助功能、通用等手表设置。
  - 写入操作自动生成重试命令，待手表回读确认后同步 UI。
- **双轨循环日志 (`feature/DiagnosticLogStore.kt`)**：
  - 区分运行日志（Runtime Log，记录业务关键结果与异常）与调试日志（Debug Log，记录协议帧细节）。
  - 本地各保留一份上限 2MB 的循环文件，杜绝无限制膨胀。
  - 敏感字段脱敏：蓝牙 MAC、联系人、通知内容、私钥与敏感标识自动替换为掩码。

---

## 6. 数据存储布局与持久化规范

所有数据存储均严格按照配对设备 MAC 进行命名空间隔离，防止多手表用户数据交织：

```
/data/data/dev.ricky.galaxywatchmanagerfree/
├── shared_prefs/
│   ├── dev_ricky_gwm_prefs.xml             # 全局设置、更新通道、外观、语言
│   ├── device_identity_store.xml          # 已验证设备与候选设备身份映射
│   ├── handover_journal.xml               # 官方应用交接状态日志
│   └── device_data_<MAC_HASH>.xml         # 特定手表的健康目标、偏好、设置缓存
├── files/
│   ├── health/
│   │   ├── records_<MAC_HASH>.bin         # HealthRecordStore 原始数据二进制存储
│   │   ├── naps_<MAC_HASH>.json           # 本机小睡补记存储
│   │   └── sleep_cache_<MAC_HASH>.bin     # 睡眠离线分期推理结果缓存
│   ├── logs/
│   │   ├── runtime.log                    # 关键业务日志 (≤2MB)
│   │   └── debug.log                      # 协议详细调试日志 (≤2MB)
│   └── updates/                           # 增量下载 APK 暂存目录 (校验通过后调起安装)
└── cache/                                 # 临时导出 ZIP、临时图像生成
```

---

## 7. 后续功能变动回补要求 (开发者与智能体必须遵循)

为防止文档与代码实现脱节，项目立下如下强制维护规范：

1. **同变更回补要求**：
   - 任何涉及协议增改、核心控制流重构、健康数据模型更新、地图/轨迹能力变动、通知与交接逻辑变动，**必须在同一个 Commit / PR 中同步更新本文档对应的章节**。
2. **健康导出强联动**：
   - 任何健康字段或持久化结构的增删，必须同时同步更新 `docs/HEALTH-EXPORT.md`、`HealthExportSnapshot`、标准化 JSON 以及导出单元测试。
3. **既有兼容常量保护**：
   - 严禁随意清理 `feature_exchange` 中的三星兼容身份参数；清理任何历史硬编码前必须在文档与测试中完整评估其对非三星手机兼容性的影响。
4. **门禁与测试底线**：
   - 代码提交前必须通过：
     - `./gradlew :app:spotlessCheck`
     - `./gradlew :app:testDebugUnitTest` (774+ 单元测试全部通过)
     - `./gradlew :app:lintDebug` (0 Errors)
     - `python3 scripts/check-i18n.py` (双语 1444 词条全量对应)
     - `python3 -m unittest discover -s scripts/tests -v`
