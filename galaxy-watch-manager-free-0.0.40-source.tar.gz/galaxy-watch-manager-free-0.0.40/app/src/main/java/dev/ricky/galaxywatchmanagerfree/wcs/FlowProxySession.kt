package dev.ricky.galaxywatchmanagerfree.wcs

import java.io.Closeable
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.nio.ByteBuffer
import java.nio.channels.DatagramChannel
import java.nio.channels.SelectableChannel
import java.nio.channels.SelectionKey
import java.nio.channels.Selector
import java.nio.channels.SocketChannel
import java.util.ArrayDeque
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

internal class FlowProxySession(
    private val input: InputStream,
    private val output: OutputStream,
    private val closeTransport: () -> Unit,
    private val log: (String) -> Unit,
    private val nanoTime: () -> Long = System::nanoTime,
) : Closeable {
    private class Connection(
        val channel: SelectableChannel,
        val id: Int? = null,
        val datagram: ByteArray? = null,
        var lastActivity: Long,
    ) {
        val writes = ArrayDeque<ByteBuffer>()
        var queuedBytes = 0
        var peerClosed = false
    }

    private enum class Handshake {
        ACCEPTING,
        ACKNOWLEDGED,
        PASSED,
    }

    private var handshake = Handshake.ACCEPTING
    private val closed = AtomicBoolean(false)
    private val selector = Selector.open()
    private val incoming = ArrayBlockingQueue<ByteArray>(64)
    private val outgoing = ArrayBlockingQueue<ByteArray>(64)
    private val tcp = HashMap<Int, Connection>()
    private val udp = HashMap<List<Byte>, Connection>()
    private var queuedBytes = 0
    private var reader: Thread? = null
    private var writer: Thread? = null

    fun run() {
        try {
            writer =
                thread(name = "flow-writer", isDaemon = true) {
                    try {
                        while (!closed.get()) {
                            val frame = outgoing.take()
                            selector.wakeup()
                            output.write(frame)
                        }
                    } catch (_: InterruptedException) {} catch (error: IOException) {
                        if (!closed.get()) log("writer_failed kind=${error.javaClass.simpleName}")
                    } finally {
                        close()
                    }
                }
            reader =
                thread(name = "flow-reader", isDaemon = true) {
                    try {
                        while (!closed.get()) {
                            val frame = FlowProtocol.read(input) ?: break
                            incoming.put(frame)
                            selector.wakeup()
                        }
                    } catch (_: InterruptedException) {} catch (error: IOException) {
                        if (!closed.get()) log("reader_failed kind=${error.javaClass.simpleName}")
                    } finally {
                        close()
                    }
                }
            while (!closed.get()) {
                repeat(64) { incoming.poll()?.let(::receive) }
                updateInterests()
                selector.select(1000)
                val keys = selector.selectedKeys().iterator()
                while (keys.hasNext() && !closed.get()) {
                    val key = keys.next()
                    keys.remove()
                    if (!key.isValid) continue
                    val connection = key.attachment() as Connection
                    try {
                        if (key.isConnectable) (connection.channel as SocketChannel).finishConnect()
                        if (key.isValid && key.isWritable) write(connection)
                        if (key.isValid && key.isReadable) read(connection)
                    } catch (error: IOException) {
                        log("channel_failed kind=${error.javaClass.simpleName}")
                        remove(connection, notify = true)
                    }
                }
                expire()
            }
        } finally {
            close()
            (tcp.values + udp.values).toList().forEach { remove(it, notify = false) }
            selector.close()
            reader?.join(1000)
            writer?.join(1000)
        }
    }

    fun send(frame: ByteArray) {
        if (closed.get()) return
        if (!outgoing.offer(frame)) {
            log("outgoing_queue_full")
            close()
        }
    }

    override fun close() {
        if (!closed.compareAndSet(false, true)) return
        selector.wakeup()
        closeTransport()
        reader?.interrupt()
        writer?.interrupt()
    }

    private fun receive(frame: ByteArray) {
        val buffer = ByteBuffer.wrap(frame)
        when (buffer.get().toInt() and 0xff) {
            FlowProtocol.TCP_OPEN -> openTcp(buffer)
            FlowProtocol.TCP_CLOSE -> {
                val connection = tcp[buffer.int] ?: return
                connection.peerClosed = true
                if (connection.writes.isEmpty()) remove(connection, notify = false)
            }
            FlowProtocol.TCP_WRITE -> {
                val id = buffer.int
                val connection = tcp[id]
                if (connection == null || connection.peerClosed) {
                    send(FlowProtocol.channel(FlowProtocol.TCP_CLOSE, id))
                    return
                }
                buffer.short
                val payload = ByteArray(buffer.remaining()).also(buffer::get)
                if (!enqueue(connection, payload)) remove(connection, notify = true)
            }
            FlowProtocol.UDP_DATAGRAM,
            FlowProtocol.UDP_V2_DATAGRAM -> sendDatagram(frame)
            FlowProtocol.PING -> send(frame)
            FlowProtocol.PULL_REQUEST -> {
                val id = buffer.int
                var remaining = buffer.int
                if (remaining !in 0..MAX_PROBE_BYTES) throw IOException("Invalid Flow pull size")
                while (remaining > 0) {
                    val size = minOf(remaining, FlowProtocol.MAX_PAYLOAD)
                    send(FlowProtocol.data(FlowProtocol.PULL_DATA, id, ByteArray(size)))
                    remaining -= size
                }
            }
            FlowProtocol.PUSH_REQUEST -> {
                buffer.int
                if (buffer.int !in 0..MAX_PROBE_BYTES) throw IOException("Invalid Flow push size")
            }
            FlowProtocol.HANDSHAKE_START -> {
                if (handshake != Handshake.ACCEPTING) throw IOException("Unexpected Flow handshake")
                handshake = Handshake.ACKNOWLEDGED
                send(FlowProtocol.data(FlowProtocol.HANDSHAKE_ACK, 5, ByteArray(0)))
            }
            FlowProtocol.HANDSHAKE_DONE -> {
                if (handshake != Handshake.ACKNOWLEDGED)
                    throw IOException("Unexpected Flow handshake")
                handshake = Handshake.PASSED
            }
            FlowProtocol.HANDSHAKE_ACK,
            FlowProtocol.ACK,
            FlowProtocol.UDP_FAILURE,
            FlowProtocol.UDP_V2_FAILURE,
            FlowProtocol.PULL_DATA,
            FlowProtocol.PUSH_DATA,
            FlowProtocol.PACKAGE_NAME,
            FlowProtocol.NETWORK_STATE -> Unit
        }
    }

    private fun openTcp(buffer: ByteBuffer) {
        val id = buffer.int
        val address = ByteArray(4).also(buffer::get)
        val port = buffer.short.toInt() and 0xffff
        buffer.short // The final short is the originating watch UID, not a receive window.
        tcp[id]?.let { remove(it, notify = false) }
        if (tcp.size + udp.size >= MAX_CHANNELS) {
            send(FlowProtocol.channel(FlowProtocol.TCP_CLOSE, id))
            return
        }
        val channel = SocketChannel.open()
        try {
            channel.configureBlocking(false)
            val connected =
                channel.connect(InetSocketAddress(InetAddress.getByAddress(address), port))
            val connection = Connection(channel, id = id, lastActivity = nanoTime())
            channel.register(
                selector,
                if (connected) SelectionKey.OP_READ else SelectionKey.OP_CONNECT,
                connection,
            )
            tcp[id] = connection
        } catch (error: IOException) {
            channel.close()
            send(FlowProtocol.channel(FlowProtocol.TCP_CLOSE, id))
            log("tcp_open_failed kind=${error.javaClass.simpleName}")
        }
    }

    private fun sendDatagram(frame: ByteArray) {
        val v2 = frame[0].toInt() == FlowProtocol.UDP_V2_DATAGRAM
        val header = if (v2) 17 else 9
        val key = frame.slice(1 until header - 2)
        var connection = udp[key]
        if (connection == null) {
            if (tcp.size + udp.size >= MAX_CHANNELS) {
                failDatagram(frame)
                return
            }
            val destinationOffset = if (v2) 7 else 1
            val address = frame.copyOfRange(destinationOffset, destinationOffset + 4)
            val port = ByteBuffer.wrap(frame).getShort(destinationOffset + 4).toInt() and 0xffff
            val channel = DatagramChannel.open()
            try {
                channel.configureBlocking(false)
                channel.connect(InetSocketAddress(InetAddress.getByAddress(address), port))
                connection =
                    Connection(channel, datagram = frame.copyOf(header), lastActivity = nanoTime())
                channel.register(selector, SelectionKey.OP_READ, connection)
                udp[key] = connection
            } catch (error: IOException) {
                channel.close()
                failDatagram(frame)
                log("udp_open_failed kind=${error.javaClass.simpleName}")
                return
            }
        }
        if (!enqueue(connection, frame.copyOfRange(header, frame.size))) failDatagram(frame)
    }

    private fun enqueue(connection: Connection, payload: ByteArray): Boolean {
        if (
            connection.queuedBytes + payload.size > MAX_CHANNEL_BYTES ||
                queuedBytes + payload.size > MAX_QUEUED_BYTES ||
                connection.writes.size >= 256
        )
            return false
        connection.writes.add(ByteBuffer.wrap(payload))
        connection.queuedBytes += payload.size
        queuedBytes += payload.size
        connection.lastActivity = nanoTime()
        return true
    }

    private fun write(connection: Connection) {
        val buffer = connection.writes.peek() ?: return
        val count =
            when (val channel = connection.channel) {
                is SocketChannel -> channel.write(buffer)
                is DatagramChannel -> channel.write(buffer)
                else -> error("Unexpected Flow channel")
            }
        connection.queuedBytes -= count
        queuedBytes -= count
        if (!buffer.hasRemaining()) connection.writes.remove()
        if (count > 0) connection.lastActivity = nanoTime()
        if (connection.peerClosed && connection.writes.isEmpty()) remove(connection, notify = false)
    }

    private fun read(connection: Connection) {
        if (outgoing.remainingCapacity() < 4) return
        val channel = connection.channel
        val buffer =
            ByteBuffer.allocate(if (channel is SocketChannel) 4096 else FlowProtocol.MAX_PAYLOAD)
        val count =
            when (channel) {
                is SocketChannel -> channel.read(buffer)
                is DatagramChannel ->
                    if (channel.receive(buffer) != null) buffer.position() else return
                else -> error("Unexpected Flow channel")
            }
        if (count < 0) {
            remove(connection, notify = true)
            return
        }
        if (count == 0 && channel is SocketChannel) return
        connection.lastActivity = nanoTime()
        val payload = buffer.array().copyOf(count)
        val frame =
            when {
                connection.id != null ->
                    FlowProtocol.data(FlowProtocol.TCP_WRITE, connection.id, payload)
                connection.datagram!!.size == 9 -> {
                    val header = ByteBuffer.wrap(connection.datagram)
                    FlowProtocol.datagram(
                        connection.datagram.copyOfRange(1, 5),
                        header.getShort(5).toInt() and 0xffff,
                        payload,
                    )
                }
                else -> {
                    val header = ByteBuffer.wrap(connection.datagram)
                    FlowProtocol.datagramV2(
                        connection.datagram.copyOfRange(1, 5),
                        header.getShort(5).toInt() and 0xffff,
                        connection.datagram.copyOfRange(7, 11),
                        header.getShort(11).toInt() and 0xffff,
                        header.getShort(13).toInt() and 0xffff,
                        payload,
                    )
                }
            }
        send(frame)
    }

    private fun updateInterests() {
        for (connection in tcp.values + udp.values) {
            val key = connection.channel.keyFor(selector) ?: continue
            if (!key.isValid) continue
            val channel = connection.channel
            key.interestOps(
                if (channel is SocketChannel && channel.isConnectionPending) SelectionKey.OP_CONNECT
                else {
                    val read = if (outgoing.remainingCapacity() >= 4) SelectionKey.OP_READ else 0
                    read or if (connection.writes.isNotEmpty()) SelectionKey.OP_WRITE else 0
                }
            )
        }
    }

    private fun expire() {
        val now = nanoTime()
        tcp.values
            .filter {
                (it.channel as SocketChannel).isConnectionPending &&
                    now - it.lastActivity > CONNECT_TIMEOUT_NANOS
            }
            .toList()
            .forEach { remove(it, notify = true) }
        udp.values
            .filter { now - it.lastActivity > UDP_IDLE_NANOS }
            .toList()
            .forEach { remove(it, notify = false) }
    }

    private fun remove(connection: Connection, notify: Boolean) {
        if (connection.id != null) {
            tcp.remove(connection.id)
            if (notify && !connection.peerClosed)
                send(FlowProtocol.channel(FlowProtocol.TCP_CLOSE, connection.id))
        } else {
            udp.values.remove(connection)
        }
        queuedBytes -= connection.queuedBytes
        connection.channel.keyFor(selector)?.cancel()
        runCatching { connection.channel.close() }
    }

    private fun failDatagram(frame: ByteArray) {
        send(
            frame.copyOf().also {
                it[0] =
                    if (frame[0].toInt() == FlowProtocol.UDP_DATAGRAM)
                        FlowProtocol.UDP_FAILURE.toByte()
                    else FlowProtocol.UDP_V2_FAILURE.toByte()
            }
        )
    }

    companion object {
        private const val MAX_CHANNELS = 64
        private const val MAX_CHANNEL_BYTES = 256 * 1024
        private const val MAX_QUEUED_BYTES = 4 * 1024 * 1024
        private const val MAX_PROBE_BYTES = 1024 * 1024
        private const val CONNECT_TIMEOUT_NANOS = 30_000_000_000L
        private const val UDP_IDLE_NANOS = 60_000_000_000L
    }
}
