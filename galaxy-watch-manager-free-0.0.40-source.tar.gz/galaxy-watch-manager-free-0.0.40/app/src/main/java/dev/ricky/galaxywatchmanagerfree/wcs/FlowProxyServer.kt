package dev.ricky.galaxywatchmanagerfree.wcs

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Build
import dev.ricky.galaxywatchmanagerfree.feature.LogBus
import java.io.Closeable
import java.io.IOException
import java.util.concurrent.atomic.AtomicReference
import kotlin.concurrent.thread

internal class FlowProxyServer(private val context: Context, private val device: BluetoothDevice) {
    private var active: Run? = null

    @Synchronized
    fun start() {
        if (active != null) return
        if (
            Build.VERSION.SDK_INT >= 31 &&
                context.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) !=
                    PackageManager.PERMISSION_GRANTED
        )
            return
        val run = Run()
        active = run
        thread(name = "flow-server", isDaemon = true) { run.listen() }
    }

    @Synchronized
    fun stop() {
        active?.close()
        active = null
    }

    private inner class Run : Closeable {
        private val lock = java.lang.Object()
        @Volatile private var closed = false
        private var server: BluetoothServerSocket? = null
        private var socket: BluetoothSocket? = null
        private var session: FlowProxySession? = null
        private val networkState = AtomicReference(FlowProtocol.networkState(-1, false))
        private val connectivity = context.getSystemService(ConnectivityManager::class.java)
        private var defaultNetwork: Network? = null
        private val callback =
            object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    defaultNetwork = network
                }

                override fun onCapabilitiesChanged(
                    network: Network,
                    capabilities: NetworkCapabilities,
                ) {
                    defaultNetwork = network
                    publishNetworkState(capabilities)
                }

                override fun onLost(network: Network) {
                    if (defaultNetwork == network) {
                        defaultNetwork = null
                        publishNetworkState(null)
                    }
                }
            }

        @SuppressLint("MissingPermission")
        fun listen() {
            var registered = false
            try {
                val current = connectivity.activeNetwork
                defaultNetwork = current
                publishNetworkState(current?.let(connectivity::getNetworkCapabilities))
                connectivity.registerDefaultNetworkCallback(callback)
                registered = true
                var delay = 1000L
                while (!closed) {
                    try {
                        val adapter = BluetoothAdapter.getDefaultAdapter() ?: return
                        val listener =
                            adapter.listenUsingRfcommWithServiceRecord("Flow", WcsPaths.FLOW)
                        synchronized(lock) {
                            if (closed) {
                                listener.close()
                                return
                            }
                            server = listener
                        }
                        LogBus.log("[Flow] listening")
                        while (!closed) {
                            val incoming = listener.accept() ?: break
                            if (
                                incoming.remoteDevice.address != device.address ||
                                    incoming.remoteDevice.bondState != BluetoothDevice.BOND_BONDED
                            ) {
                                incoming.close()
                                LogBus.debug { "[Flow] peer_rejected" }
                                continue
                            }
                            val proxy =
                                synchronized(lock) {
                                    if (closed) {
                                        incoming.close()
                                        return
                                    }
                                    socket = incoming
                                    FlowProxySession(
                                            incoming.inputStream,
                                            incoming.outputStream,
                                            closeTransport = {
                                                runCatching { incoming.close() }
                                                Unit
                                            },
                                            log = { message -> LogBus.debug { "[Flow] $message" } },
                                        )
                                        .also {
                                            it.send(networkState.get())
                                            session = it
                                        }
                                }
                            LogBus.log("[Flow] connected")
                            delay = 1000L
                            try {
                                proxy.run()
                            } catch (error: IOException) {
                                LogBus.debug {
                                    "[Flow] session_failed kind=${error.javaClass.simpleName}"
                                }
                            } finally {
                                proxy.close()
                                synchronized(lock) {
                                    session = null
                                    socket = null
                                }
                                LogBus.log("[Flow] disconnected")
                            }
                        }
                    } catch (error: IOException) {
                        if (!closed)
                            LogBus.debug {
                                "[Flow] listener_failed kind=${error.javaClass.simpleName}"
                            }
                    } catch (error: SecurityException) {
                        LogBus.error("[Flow] bluetooth_permission_denied")
                        return
                    } finally {
                        synchronized(lock) {
                            runCatching { socket?.close() }
                            socket = null
                            runCatching { server?.close() }
                            server = null
                        }
                    }
                    synchronized(lock) { if (!closed) lock.wait(delay) }
                    delay = (delay * 2).coerceAtMost(60_000L)
                }
            } catch (_: InterruptedException) {
                Thread.currentThread().interrupt()
            } finally {
                close()
                if (registered) connectivity.unregisterNetworkCallback(callback)
            }
        }

        private fun publishNetworkState(capabilities: NetworkCapabilities?) {
            val type =
                when {
                    capabilities == null ||
                        !capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) ->
                        -1
                    capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> 0
                    capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> 1
                    capabilities.hasTransport(NetworkCapabilities.TRANSPORT_BLUETOOTH) -> 2
                    capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> 3
                    capabilities.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> 4
                    capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI_AWARE) -> 5
                    capabilities.hasTransport(NetworkCapabilities.TRANSPORT_LOWPAN) -> 6
                    else -> Int.MAX_VALUE
                }
            val metered =
                type != -1 &&
                    capabilities?.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED) ==
                        false
            val frame = FlowProtocol.networkState(type, metered)
            synchronized(lock) {
                if (closed || networkState.getAndSet(frame).contentEquals(frame)) return
                session?.send(frame)
            }
            LogBus.debug { "[Flow] network type=$type metered=$metered" }
        }

        override fun close() {
            synchronized(lock) {
                if (closed) return
                closed = true
                session?.close()
                runCatching { socket?.close() }
                runCatching { server?.close() }
                lock.notifyAll()
            }
        }
    }
}
