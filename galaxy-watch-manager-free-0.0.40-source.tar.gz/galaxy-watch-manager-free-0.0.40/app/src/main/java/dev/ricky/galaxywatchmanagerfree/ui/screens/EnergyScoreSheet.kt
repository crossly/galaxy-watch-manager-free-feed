package dev.ricky.galaxywatchmanagerfree.ui.screens

import androidx.annotation.StringRes
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.core.UiNotify
import dev.ricky.galaxywatchmanagerfree.feature.EnergyScoreCalculation
import dev.ricky.galaxywatchmanagerfree.feature.EnergyScoreLog
import dev.ricky.galaxywatchmanagerfree.feature.EnergyScoreSync
import dev.ricky.galaxywatchmanagerfree.feature.LogBus
import dev.ricky.galaxywatchmanagerfree.feature.WatchState
import dev.ricky.galaxywatchmanagerfree.ui.components.AppBottomSheet
import dev.ricky.galaxywatchmanagerfree.ui.components.GroupedCard
import dev.ricky.galaxywatchmanagerfree.ui.components.GroupedCardRow
import dev.ricky.galaxywatchmanagerfree.ui.components.SheetToolbar
import dev.ricky.galaxywatchmanagerfree.ui.theme.HealthSteps
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextPrimary
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextSecondary
import dev.ricky.galaxywatchmanagerfree.ui.theme.tonalSurface
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import kotlin.math.roundToInt
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

@StringRes
private fun energyBand(score: Double): Int =
    when {
        score >= 85 -> R.string.energy_score_excellent
        score >= 75 -> R.string.energy_score_good
        score >= 60 -> R.string.energy_score_fair
        else -> R.string.energy_score_attention
    }

@StringRes
private fun energySyncLabel(status: EnergyScoreSync.Status): Int =
    when (status) {
        EnergyScoreSync.Status.IDLE -> R.string.energy_score_unconfirmed
        EnergyScoreSync.Status.WAITING_ACK -> R.string.energy_score_waiting
        EnergyScoreSync.Status.ACCEPTED -> R.string.energy_score_accepted
        EnergyScoreSync.Status.SEND_FAILED -> R.string.energy_score_send_failed
        EnergyScoreSync.Status.SAVE_FAILED -> R.string.energy_score_ack_save_failed
        EnergyScoreSync.Status.REJECTED -> R.string.energy_score_rejected
        EnergyScoreSync.Status.TIMED_OUT -> R.string.energy_score_timeout
        EnergyScoreSync.Status.DISCONNECTED -> R.string.energy_score_disconnected
    }

@Composable
fun EnergyScoreCard(record: EnergyScoreLog.Record?, wide: Boolean = false, onClick: () -> Unit) {
    HealthSummary(
        title = stringResource(R.string.energy_score),
        value = record?.totalScore?.roundToInt()?.toString() ?: "—",
        unit =
            record?.let { stringResource(energyBand(it.totalScore)) }
                ?: stringResource(R.string.energy_score_local),
        icon = Icons.Default.Bolt,
        accent = HealthSteps,
        modifier = Modifier.fillMaxWidth().testTag("energy_score_card"),
        wide = wide,
        onClick = onClick,
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EnergyScoreSheet(
    state: WatchState,
    onDismiss: () -> Unit,
    onSaveProfile: (Int, Boolean) -> Boolean,
    onCalculate: (Int, Boolean) -> EnergyScoreCalculation?,
    onWrite: (String) -> Boolean,
) {
    val scope = rememberCoroutineScope()
    val resources = LocalContext.current.resources
    val locale = LocalConfiguration.current.locales[0]
    val dateFormat =
        remember(locale) {
            DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM).withLocale(locale)
        }
    var selectedId by rememberSaveable { mutableStateOf<String?>(null) }
    var calculating by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }
    val savedProfile = state.energyProfile
    var ageText by
        rememberSaveable(savedProfile) { mutableStateOf(savedProfile?.age?.toString().orEmpty()) }
    var female by rememberSaveable(savedProfile) { mutableStateOf(savedProfile?.female) }
    val age = ageText.toIntOrNull()?.takeIf { it in 18..99 }
    val dirty =
        savedProfile != null &&
            (age != savedProfile.age || female == null || female != savedProfile.female)
    val busy =
        calculating || saving || state.energyScoreSyncStatus == EnergyScoreSync.Status.WAITING_ACK
    val records = remember(state.energyScores) { state.energyScores.sortedByDescending { it.date } }
    val selected = records.firstOrNull { it.id == selectedId } ?: records.firstOrNull()
    AppBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
    ) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
            SheetToolbar(stringResource(R.string.energy_score), onDismiss)
            LazyColumn(
                Modifier.fillMaxWidth().testTag("energy_score_detail"),
                contentPadding = PaddingValues(top = 8.dp, bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                item {
                    GroupedCard(backgroundColor = tonalSurface(HealthSteps), accent = HealthSteps) {
                        Text(
                            stringResource(R.string.energy_score_local),
                            color = TextSecondary,
                            style = MaterialTheme.typography.labelMedium,
                        )
                        selected?.let { record ->
                            Text(
                                LocalDate.parse(record.date).format(dateFormat),
                                color = TextSecondary,
                                style = MaterialTheme.typography.bodyMedium,
                            )
                            Text(
                                record.totalScore.roundToInt().toString(),
                                color = TextPrimary,
                                style = MaterialTheme.typography.displayMedium,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.testTag("energy_score_value"),
                            )
                            Text(
                                stringResource(energyBand(record.totalScore)),
                                color = TextPrimary,
                                style = MaterialTheme.typography.titleMedium,
                            )
                            Spacer(Modifier.height(8.dp))
                            Text(
                                stringResource(
                                    if (record.acknowledged) R.string.energy_score_accepted
                                    else R.string.energy_score_unconfirmed
                                ),
                                color = TextSecondary,
                                style = MaterialTheme.typography.bodySmall,
                            )
                        }
                            ?: Text(
                                stringResource(R.string.energy_score_empty),
                                color = TextSecondary,
                                style = MaterialTheme.typography.bodyMedium,
                            )
                    }
                }
                item {
                    Text(
                        stringResource(R.string.energy_score_about),
                        color = TextSecondary,
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = ageText,
                        onValueChange = {
                            if (it.length <= 2 && it.all(Char::isDigit)) ageText = it
                        },
                        label = { Text(stringResource(R.string.energy_score_age)) },
                        supportingText = {
                            Text(stringResource(R.string.energy_score_profile_help))
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth().testTag("energy_score_age"),
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(
                                true to R.string.energy_score_female,
                                false to R.string.energy_score_male,
                            )
                            .forEach { (value, label) ->
                                FilterChip(
                                    selected = female == value,
                                    onClick = { female = value },
                                    enabled = !busy,
                                    label = { Text(stringResource(label)) },
                                    modifier =
                                        Modifier.testTag(
                                            if (value) "energy_score_sex_female"
                                            else "energy_score_sex_male"
                                        ),
                                )
                            }
                    }
                    Text(
                        stringResource(
                            when {
                                savedProfile == null -> R.string.energy_score_profile_not_saved
                                dirty -> R.string.energy_score_profile_unsaved_changes
                                else -> R.string.energy_score_profile_saved
                            }
                        ),
                        color = TextSecondary,
                        style = MaterialTheme.typography.bodySmall,
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                saving = true
                                scope.launch {
                                    try {
                                        val saved =
                                            withContext(Dispatchers.IO) {
                                                onSaveProfile(
                                                    requireNotNull(age),
                                                    requireNotNull(female),
                                                )
                                            }
                                        UiNotify.show(
                                            resources.getString(
                                                if (saved) R.string.energy_score_profile_saved_toast
                                                else R.string.energy_score_profile_save_failed
                                            )
                                        )
                                    } catch (cancelled: CancellationException) {
                                        throw cancelled
                                    } catch (error: Exception) {
                                        LogBus.error("[能量] 资料保存异常", error)
                                        UiNotify.show(
                                            resources.getString(
                                                R.string.energy_score_profile_save_failed
                                            )
                                        )
                                    } finally {
                                        saving = false
                                    }
                                }
                            },
                            enabled = age != null && female != null && !busy,
                            modifier = Modifier.weight(1f).testTag("energy_score_profile_save"),
                        ) {
                            Text(
                                stringResource(
                                    if (saving) R.string.energy_score_profile_saving
                                    else R.string.energy_score_profile_save
                                )
                            )
                        }
                        Button(
                            onClick = {
                                calculating = true
                                scope.launch {
                                    try {
                                        val result =
                                            withContext(Dispatchers.IO) {
                                                onCalculate(
                                                    requireNotNull(age),
                                                    requireNotNull(female),
                                                )
                                            }
                                        val message =
                                            when {
                                                result == null ->
                                                    resources.getString(
                                                        R.string.energy_score_calculate_failed
                                                    )
                                                result.calculated == 0 ->
                                                    resources.getString(
                                                        R.string.energy_score_profile_saved_no_data
                                                    )
                                                result.missing > 0 ->
                                                    resources.getQuantityString(
                                                        R.plurals.energy_score_calculated_partial,
                                                        result.calculated,
                                                        result.calculated,
                                                        result.missing,
                                                    )
                                                else ->
                                                    resources.getQuantityString(
                                                        R.plurals.energy_score_calculated,
                                                        result.calculated,
                                                        result.calculated,
                                                    )
                                            }
                                        UiNotify.show(message)
                                    } catch (cancelled: CancellationException) {
                                        throw cancelled
                                    } catch (error: Exception) {
                                        LogBus.error("[能量] 手动计算异常", error)
                                        UiNotify.show(
                                            resources.getString(
                                                R.string.energy_score_calculate_failed
                                            )
                                        )
                                    } finally {
                                        calculating = false
                                    }
                                }
                            },
                            enabled = age != null && female != null && !busy,
                            modifier = Modifier.weight(1f).testTag("energy_score_calculate"),
                        ) {
                            Text(
                                stringResource(
                                    if (calculating) R.string.energy_score_calculating
                                    else R.string.energy_score_calculate
                                )
                            )
                        }
                    }
                    OutlinedButton(
                        onClick = {
                            selected?.id?.let { id ->
                                scope.launch {
                                    if (!withContext(Dispatchers.IO) { onWrite(id) }) {
                                        UiNotify.show(
                                            resources.getString(R.string.energy_score_send_failed)
                                        )
                                    }
                                }
                            }
                        },
                        enabled =
                            state.sessionReady &&
                                selected?.deviceUuid?.isNotBlank() == true &&
                                !busy,
                        modifier = Modifier.fillMaxWidth().testTag("energy_score_write"),
                    ) {
                        Text(stringResource(R.string.energy_score_write))
                    }
                    Text(
                        stringResource(energySyncLabel(state.energyScoreSyncStatus)),
                        color = TextSecondary,
                        style = MaterialTheme.typography.bodySmall,
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        stringResource(R.string.energy_score_ack_help),
                        color = TextSecondary,
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
                selected?.let { record ->
                    item {
                        Text(
                            stringResource(R.string.energy_score_factors),
                            color = TextPrimary,
                            style = MaterialTheme.typography.titleSmall,
                        )
                        val values = JSONObject(record.values)
                        GroupedCard(innerPadding = 0.dp) {
                            listOf(
                                    "sleep_score" to R.string.energy_score_sleep_factor,
                                    "activity_score" to R.string.energy_score_activity_factor,
                                    "shr_score" to R.string.energy_score_hr_factor,
                                    "shrv_score" to R.string.energy_score_hrv_factor,
                                )
                                .forEach { (key, label) ->
                                    GroupedCardRow(
                                        title = stringResource(label),
                                        subtitle =
                                            values
                                                .optDouble(key, Double.NaN)
                                                .takeIf { it.isFinite() }
                                                ?.let { "%.1f".format(locale, it) }
                                                ?: stringResource(R.string.energy_score_unavailable),
                                    )
                                }
                        }
                    }
                }
                if (records.isNotEmpty()) {
                    item {
                        Text(
                            stringResource(R.string.history_2),
                            color = TextPrimary,
                            style = MaterialTheme.typography.titleSmall,
                        )
                    }
                    items(records, key = { it.id }) { record ->
                        GroupedCard(innerPadding = 0.dp) {
                            GroupedCardRow(
                                title = LocalDate.parse(record.date).format(dateFormat),
                                subtitle =
                                    stringResource(energyBand(record.totalScore)) +
                                        " · " +
                                        record.totalScore.roundToInt(),
                                onClick = { selectedId = record.id },
                            )
                        }
                    }
                }
            }
        }
    }
}
