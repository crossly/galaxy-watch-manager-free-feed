package dev.ricky.galaxywatchmanagerfree.feature

import dev.ricky.galaxywatchmanagerfree.wcs.WcsPaths
import java.io.ByteArrayOutputStream
import java.util.Base64
import java.util.concurrent.atomic.AtomicInteger
import java.util.zip.GZIPOutputStream
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

class EnergyScoreSync(
    private val scope: CoroutineScope,
    private val watchNode: () -> String,
    private val deviceModel: () -> String,
    private val send: (JSONObject) -> Boolean,
    private val onStatus: (Status) -> Unit,
    private val onAccepted: (List<JSONObject>, Long) -> Boolean,
    private val clock: () -> Long = System::currentTimeMillis,
    private val timeoutMillis: Long = 30_000L,
) {
    enum class Status {
        IDLE,
        WAITING_ACK,
        ACCEPTED,
        SEND_FAILED,
        SAVE_FAILED,
        REJECTED,
        TIMED_OUT,
        DISCONNECTED,
    }

    private data class Pending(val sequence: Int, val rows: List<JSONObject>, var job: Job? = null)

    private val sequence = AtomicInteger(kotlin.random.Random.nextInt(100_000_000, 200_000_000))
    private var pending: Pending? = null

    @Synchronized
    fun push(rows: List<JSONObject>): Boolean {
        if (rows.isEmpty()) return false
        pending?.job?.cancel()
        val request = Pending(sequence.getAndIncrement(), rows.map { JSONObject(it.toString()) })
        pending = request
        onStatus(Status.WAITING_ACK)
        val sent = send(packet(request))
        if (!sent) {
            if (pending === request) {
                pending = null
                onStatus(Status.SEND_FAILED)
            }
            return false
        }
        if (pending === request) {
            request.job =
                scope.launch {
                    delay(timeoutMillis)
                    synchronized(this@EnergyScoreSync) {
                        if (pending === request) {
                            pending = null
                            onStatus(Status.TIMED_OUT)
                        }
                    }
                }
        }
        return true
    }

    @Synchronized
    fun handleMessage(json: JSONObject): Boolean {
        val request = pending ?: return false
        if (
            json.optString("message") != WcsPaths.HEALTH_MSG_RESPONSE ||
                json.optString("type") != WcsPaths.HEALTH_TYPE_DATA ||
                json.optString("sender") != WcsPaths.HEALTH_WATCH_SYNC ||
                json.optString("receiver") != WcsPaths.HEALTH_PHONE_SYNC ||
                json.optInt("sequence_num") != request.sequence
        )
            return false
        val info =
            runCatching {
                    val entries = HealthJson.entries(json.optString("body"))
                    (0 until entries.length()).firstNotNullOfOrNull {
                        entries.optJSONObject(it)?.optJSONArray("message_info")?.optJSONObject(0)
                    }
                }
                .getOrNull() ?: return true
        if (info.optString("action") != WcsPaths.HEALTH_ACTION_SYNC_DATA) return true
        val result = info.optString("result")
        if (result.isBlank()) return true
        pending = null
        request.job?.cancel()
        if (result.equals("SUCCESS", ignoreCase = true)) {
            onStatus(if (onAccepted(request.rows, clock())) Status.ACCEPTED else Status.SAVE_FAILED)
        } else {
            onStatus(Status.REJECTED)
        }
        return true
    }

    @Synchronized
    fun disconnect() {
        pending?.job?.cancel()
        pending = null
        onStatus(Status.DISCONNECTED)
    }

    private fun packet(request: Pending): JSONObject {
        val body =
            JSONArray()
                .put(
                    JSONObject()
                        .put(
                            "device_info",
                            JSONArray()
                                .put(
                                    JSONObject()
                                        .put("device", deviceModel())
                                        .put("device_type", 10062)
                                        .put("version", 5.03)
                                        .put("last_sync_time", clock())
                                        .put("is_last_chunk", true)
                                ),
                        )
                )
                .put(
                    JSONObject()
                        .put(
                            "message_info",
                            JSONArray()
                                .put(JSONObject().put("action", WcsPaths.HEALTH_ACTION_SYNC_DATA)),
                        )
                )
                .put(JSONObject().put(MODULE, JSONArray(request.rows)))
        val output = ByteArrayOutputStream()
        GZIPOutputStream(output).use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        return JSONObject()
            .put("message", WcsPaths.HEALTH_MSG_REQUEST)
            .put("type", WcsPaths.HEALTH_TYPE_DATA)
            .put("sender", WcsPaths.HEALTH_PHONE_SYNC)
            .put("receiver", WcsPaths.HEALTH_WATCH_SYNC)
            .put("version", 5.03)
            .put("sequence_num", request.sequence)
            .put("source_node", WcsPaths.PKG_SHEALTH)
            .put("destination_node", watchNode())
            .put("body", Base64.getEncoder().encodeToString(output.toByteArray()))
    }

    companion object {
        const val MODULE = "com.samsung.shealth.vitality_score"
    }
}
