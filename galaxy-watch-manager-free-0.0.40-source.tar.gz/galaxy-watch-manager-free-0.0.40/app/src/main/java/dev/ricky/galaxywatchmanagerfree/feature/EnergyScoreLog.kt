package dev.ricky.galaxywatchmanagerfree.feature

import java.time.LocalDate
import java.time.ZoneId
import java.time.ZoneOffset
import java.util.UUID
import org.json.JSONArray
import org.json.JSONObject

object EnergyScoreLog {
    private val REQUIRED_VALUES =
        setOf(
            "total_score",
            "sleep_score",
            "activity_score",
            "shr_score",
            "shrv_score",
            "sleep_duration",
            "sleep_balance",
            "sleep_regularity",
            "sleep_timing",
            "active_time",
            "mvpa_time",
            "mvpa_impulse",
            "shrv_penalty",
            "stable_hr_time_rate",
            "avg_mid_sleep_time",
            "prev_shr_avg",
            "prev_shrv_avg",
            "sleep_duration_scale",
            "sleep_balance_scale",
            "sleep_regularity_scale",
            "sleep_timing_scale",
            "active_time_scale",
            "mvpa_time_scale",
            "mvpa_impulse_scale",
            "shr_balance_scale",
            "shrv_balance_scale",
            "shr_value",
            "shr_baseline_max",
            "shr_baseline_min",
            "shrv_value",
            "shrv_baseline_max",
            "shrv_baseline_min",
            "shr_calculation_index",
            "shrv_calculation_index",
            "main_sleep_wake_up_time",
        )

    data class Record(
        val id: String,
        val date: String,
        val zoneId: String,
        val algorithm: String,
        val createdAt: Long,
        val updatedAt: Long,
        val deviceUuid: String,
        val values: String,
        val inputs: String,
        val acceptedRevision: Long? = null,
        val acceptedAt: Long? = null,
    ) {
        val totalScore: Double
            get() = JSONObject(values).getDouble("total_score")

        val acknowledged: Boolean
            get() = acceptedRevision == updatedAt

        fun protocolRow(): JSONObject =
            JSONObject(values)
                .apply {
                    REQUIRED_VALUES.forEach { key -> if (!has(key) || isNull(key)) put(key, -1) }
                }
                .put("data_version", 4)
                .put(
                    "day_time",
                    LocalDate.parse(date).atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli(),
                )
                .put("datauuid", id)
                .put("deviceuuid", deviceUuid)
                .put("pkg_name", "dev.ricky.galaxywatchmanagerfree")
                .put("create_time", createdAt)
                .put("update_time", updatedAt)

        fun json(): JSONObject =
            JSONObject()
                .put("record_id", id)
                .put("date", date)
                .put("time_zone", zoneId)
                .put("source", "phone_computed")
                .put("algorithm", algorithm)
                .put("created_at_epoch_ms", createdAt)
                .put("updated_at_epoch_ms", updatedAt)
                .put("device_uuid", deviceUuid)
                .put("values", JSONObject(values))
                .put("inputs", JSONObject(inputs))
                .put("watch_accepted_revision_epoch_ms", acceptedRevision ?: JSONObject.NULL)
                .put("watch_accepted_at_epoch_ms", acceptedAt ?: JSONObject.NULL)
                .put("watch_persistence_verified", JSONObject.NULL)
    }

    fun upsert(
        records: List<Record>,
        date: LocalDate,
        zone: ZoneId,
        algorithm: String,
        values: JSONObject,
        inputs: JSONObject,
        deviceUuid: String,
        now: Long,
    ): List<Record> {
        require(
            values.optDouble("total_score", Double.NaN).let { it.isFinite() && it in 0.0..100.0 }
        )
        val old = records.firstOrNull { it.date == date.toString() && it.algorithm == algorithm }
        val nextValues = canonical(values)
        val nextInputs = canonical(inputs)
        val nextDeviceUuid = deviceUuid.ifBlank { old?.deviceUuid.orEmpty() }
        if (
            old != null &&
                old.values == nextValues &&
                old.inputs == nextInputs &&
                old.zoneId == zone.id &&
                old.deviceUuid == nextDeviceUuid
        )
            return records
        val record =
            Record(
                id = old?.id ?: UUID.randomUUID().toString(),
                date = date.toString(),
                zoneId = zone.id,
                algorithm = algorithm,
                createdAt = old?.createdAt ?: now,
                updatedAt = maxOf(now, (old?.updatedAt ?: 0L) + 1L),
                deviceUuid = nextDeviceUuid,
                values = nextValues,
                inputs = nextInputs,
                acceptedRevision = old?.acceptedRevision,
                acceptedAt = old?.acceptedAt,
            )
        return (records.filterNot { it.id == record.id } + record).sortedBy { it.date }
    }

    fun accept(records: List<Record>, rows: List<JSONObject>, now: Long): List<Record> {
        val revisions = rows.associate { it.getString("datauuid") to it.getLong("update_time") }
        return records.map { record ->
            if (revisions[record.id] == record.updatedAt)
                record.copy(acceptedRevision = record.updatedAt, acceptedAt = now)
            else record
        }
    }

    fun encode(records: List<Record>): String = JSONArray(records.map { it.json() }).toString()

    fun decode(raw: String?): List<Record> {
        val array = runCatching { JSONArray(raw ?: "[]") }.getOrNull() ?: return emptyList()
        return (0 until array.length())
            .mapNotNull { index ->
                runCatching {
                        val row = array.getJSONObject(index)
                        LocalDate.parse(row.getString("date"))
                        ZoneId.of(row.getString("time_zone"))
                        val values = row.getJSONObject("values")
                        require(
                            values.getDouble("total_score").let {
                                it.isFinite() && it in 0.0..100.0
                            }
                        )
                        Record(
                            row.getString("record_id"),
                            row.getString("date"),
                            row.getString("time_zone"),
                            row.getString("algorithm"),
                            row.getLong("created_at_epoch_ms"),
                            row.getLong("updated_at_epoch_ms"),
                            row.getString("device_uuid"),
                            canonical(values),
                            canonical(row.getJSONObject("inputs")),
                            row.optLong("watch_accepted_revision_epoch_ms").takeIf { it > 0 },
                            row.optLong("watch_accepted_at_epoch_ms").takeIf { it > 0 },
                        )
                    }
                    .getOrNull()
            }
            .distinctBy { it.id }
            .sortedBy { it.date }
    }

    private fun canonical(value: Any?): String =
        when (value) {
            is JSONObject ->
                value.keys().asSequence().sorted().joinToString(",", "{", "}") {
                    JSONObject.quote(it) + ":" + canonical(value.get(it))
                }
            is JSONArray ->
                (0 until value.length()).joinToString(",", "[", "]") { canonical(value.get(it)) }
            is String -> JSONObject.quote(value)
            is Number -> JSONObject.numberToString(value)
            null,
            JSONObject.NULL -> "null"
            else -> value.toString()
        }
}
