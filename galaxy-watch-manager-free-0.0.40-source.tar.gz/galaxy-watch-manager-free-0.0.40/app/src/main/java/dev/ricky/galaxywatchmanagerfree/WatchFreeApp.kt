package dev.ricky.galaxywatchmanagerfree

import android.app.Application
import dev.ricky.galaxywatchmanagerfree.core.WatchController

class WatchFreeApp : Application() {
    override fun onCreate() {
        super.onCreate()
        dev.ricky.galaxywatchmanagerfree.feature.LogBus.init(this)
        dev.ricky.galaxywatchmanagerfree.core.UiNotify.init(this)
        dev.ricky.galaxywatchmanagerfree.ui.PageLayoutController.init(this)
        dev.ricky.galaxywatchmanagerfree.feature.NotificationFilterPreferences.init(this)
        WatchController.init(this)
        // 应用升级/覆盖安装后系统可能尚未重绑通知监听服务，进程启动时在已授权情况下主动恢复一次。
        dev.ricky.galaxywatchmanagerfree.feature.NotificationListenerRecovery.requestRebindIfNeeded(
            this
        )
        dev.ricky.galaxywatchmanagerfree.core.OnboardingController.initialize(this)
        // 进程启动即尝试从已配对列表里找回手表；首次连接引导显示时不要抢跑。
        if (!dev.ricky.galaxywatchmanagerfree.core.OnboardingController.isVisible) {
            WatchController.resumeAutoConnect(this)
        }
    }
}
