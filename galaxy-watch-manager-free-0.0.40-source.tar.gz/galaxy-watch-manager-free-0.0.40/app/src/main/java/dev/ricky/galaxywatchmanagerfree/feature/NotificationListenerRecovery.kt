package dev.ricky.galaxywatchmanagerfree.feature

import android.content.ComponentName
import android.content.Context
import android.service.notification.NotificationListenerService
import androidx.annotation.VisibleForTesting
import androidx.core.app.NotificationManagerCompat

/**
 * 恢复通知监听服务绑定。
 *
 * 应用升级或覆盖安装会杀掉进程，系统常不会立即重新绑定 NotificationListenerService；冷启动时服务也可能尚未连接。
 * 监听未连接时，通知既不会被系统回调，也不会触发桥接特性同步。这里在已授权但未连接时请求一次重绑，并用节流避免 反复请求。
 */
object NotificationListenerRecovery {
    const val MIN_REBIND_INTERVAL_MS = 2_000L

    @Volatile private var listenerConnected = false
    @Volatile private var lastRebindAttemptAt = 0L

    /** 纯决策接缝：仅在已授权、当前未连接且距上次请求已过节流阈值时请求重绑。 */
    internal fun shouldRequestRebind(
        accessGranted: Boolean,
        connected: Boolean,
        nowMillis: Long,
        lastAttemptAt: Long,
    ): Boolean = accessGranted && !connected && nowMillis - lastAttemptAt >= MIN_REBIND_INTERVAL_MS

    fun onListenerConnected() {
        listenerConnected = true
        lastRebindAttemptAt = 0L
    }

    fun onListenerDisconnected() {
        listenerConnected = false
    }

    fun requestRebindIfNeeded(context: Context, nowMillis: Long = System.currentTimeMillis()) {
        val granted =
            NotificationManagerCompat.getEnabledListenerPackages(context)
                .contains(context.packageName)
        if (!shouldRequestRebind(granted, listenerConnected, nowMillis, lastRebindAttemptAt)) return
        lastRebindAttemptAt = nowMillis
        val component = ComponentName(context, NotificationBridgeService::class.java)
        runCatching { NotificationListenerService.requestRebind(component) }
            .onSuccess { LogBus.log("[通知] 已请求系统重绑通知监听服务") }
            .onFailure { LogBus.log("[通知] 请求重绑通知监听服务失败: ${it.javaClass.simpleName}") }
    }

    @VisibleForTesting
    internal fun resetForTest() {
        listenerConnected = false
        lastRebindAttemptAt = 0L
    }
}
