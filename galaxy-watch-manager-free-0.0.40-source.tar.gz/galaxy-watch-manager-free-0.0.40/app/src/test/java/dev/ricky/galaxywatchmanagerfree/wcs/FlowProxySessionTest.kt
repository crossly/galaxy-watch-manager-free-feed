package dev.ricky.galaxywatchmanagerfree.wcs

import java.io.Closeable
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.nio.ByteBuffer
import java.util.concurrent.CompletableFuture
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread
import org.junit.Assert.*
import org.junit.Test

class FlowProxySessionTest {
    private val localhost = InetAddress.getByAddress(byteArrayOf(127, 0, 0, 1))

    private inner class Harness : Closeable {
        val peer: Socket
        private val proxySocket: Socket
        val session: FlowProxySession
        val finished = CompletableFuture<Unit>()

        init {
            ServerSocket(0, 1, localhost).use { listener ->
                peer = Socket(localhost, listener.localPort).apply { soTimeout = 3000 }
                proxySocket = listener.accept()
            }
            session =
                FlowProxySession(
                    proxySocket.getInputStream(),
                    proxySocket.getOutputStream(),
                    { proxySocket.close() },
                    {},
                )
            session.send(FlowProtocol.networkState(1, false))
            thread(isDaemon = true) {
                try {
                    session.run()
                    finished.complete(Unit)
                } catch (error: Throwable) {
                    finished.completeExceptionally(error)
                }
            }
            assertArrayEquals(FlowProtocol.networkState(1, false), next())
        }

        fun send(frame: ByteArray) {
            peer.getOutputStream().write(frame)
        }

        fun next(): ByteArray? = FlowProtocol.read(peer.getInputStream())

        override fun close() {
            session.close()
            peer.close()
            finished.get(4, TimeUnit.SECONDS)
        }
    }

    private fun open(id: Int, port: Int): ByteArray =
        ByteBuffer.allocate(13)
            .put(1)
            .putInt(id)
            .put(localhost.address)
            .putShort(port.toShort())
            .putShort(1000)
            .array()

    @Test
    fun tcpForwardsBothDirectionsWithoutAckAndReportsEof() {
        val request = "synthetic request".toByteArray()
        val response = "synthetic response".toByteArray()
        ServerSocket(0, 1, localhost).use { echo ->
            val handled = CompletableFuture<Unit>()
            thread(isDaemon = true) {
                try {
                    echo.accept().use { socket ->
                        socket.soTimeout = 3000
                        assertArrayEquals(
                            request,
                            java.io.DataInputStream(socket.getInputStream()).let { input ->
                                ByteArray(request.size).also(input::readFully)
                            },
                        )
                        socket.getOutputStream().write(response)
                    }
                    handled.complete(Unit)
                } catch (error: Throwable) {
                    handled.completeExceptionally(error)
                }
            }
            Harness().use { h ->
                h.send(open(42, echo.localPort) + FlowProtocol.data(3, 42, request))
                val actual = java.io.ByteArrayOutputStream()
                while (actual.size() < response.size) {
                    val frame = h.next()!!
                    assertEquals(3, frame[0].toInt())
                    assertEquals(42, ByteBuffer.wrap(frame).getInt(1))
                    actual.write(frame, 7, frame.size - 7)
                }
                assertArrayEquals(response, actual.toByteArray())
                assertArrayEquals(FlowProtocol.channel(2, 42), h.next())
                handled.get(4, TimeUnit.SECONDS)
            }
        }
    }

    @Test
    fun legacyUdpAndV2ReturnPacketsWithCorrectEndpointDirection() {
        for (v2 in listOf(false, true)) {
            DatagramSocket(0, localhost).use { echo ->
                echo.soTimeout = 3000
                val handled = CompletableFuture<Unit>()
                thread(isDaemon = true) {
                    try {
                        val packet = DatagramPacket(ByteArray(512), 512)
                        echo.receive(packet)
                        echo.send(packet)
                        handled.complete(Unit)
                    } catch (error: Throwable) {
                        handled.completeExceptionally(error)
                    }
                }
                Harness().use { h ->
                    val payload = byteArrayOf(0, 42, 1, 0, 0, 1)
                    val watch = byteArrayOf(10, 0, 0, 2)
                    val request =
                        if (v2)
                            FlowProtocol.datagramV2(
                                watch,
                                50000,
                                localhost.address,
                                echo.localPort,
                                1000,
                                payload,
                            )
                        else FlowProtocol.datagram(localhost.address, echo.localPort, payload)
                    h.send(request)
                    assertArrayEquals(request, h.next())
                    handled.get(4, TimeUnit.SECONDS)
                }
            }
        }
    }

    @Test
    fun failedTcpConnectReturnsCloseAndOtherFramesStillWork() {
        val port = ServerSocket(0, 1, localhost).use { it.localPort }
        Harness().use { h ->
            h.send(open(77, port))
            assertArrayEquals(FlowProtocol.channel(2, 77), h.next())
            val ping = FlowProtocol.channel(5, 12345)
            h.send(ping)
            assertArrayEquals(ping, h.next())
        }
    }

    @Test
    fun peerCloseDrainsPendingWritesAndStopClosesNetworkSockets() {
        ServerSocket(0, 1, localhost).use { remote ->
            remote.soTimeout = 3000
            Harness().use { h ->
                h.send(open(7, remote.localPort))
                remote.accept().use { socket ->
                    socket.soTimeout = 3000
                    val bytes = ByteArray(60000) { it.toByte() }
                    h.send(FlowProtocol.data(3, 7, bytes) + FlowProtocol.channel(2, 7))
                    val input = java.io.DataInputStream(socket.getInputStream())
                    assertArrayEquals(bytes, ByteArray(bytes.size).also(input::readFully))
                    assertEquals(-1, input.read())
                }
                h.send(open(8, remote.localPort))
                remote.accept().use { socket ->
                    socket.soTimeout = 3000
                    h.session.close()
                    assertEquals(-1, socket.getInputStream().read())
                }
            }
        }
    }

    @Test
    fun networkChangesAndProbeRepliesShareTheOrderedWriter() {
        Harness().use { h ->
            val network = FlowProtocol.networkState(-1, false)
            h.session.send(network)
            assertArrayEquals(network, h.next())
            h.send(ByteBuffer.allocate(9).put(8).putInt(9).putInt(70000).array())
            assertArrayEquals(FlowProtocol.data(9, 9, ByteArray(65535)), h.next())
            assertArrayEquals(FlowProtocol.data(9, 9, ByteArray(4465)), h.next())
        }
    }

    @Test
    fun optionalHandshakeAcknowledgesVersionFiveAndKeepsSubsequentFramesAligned() {
        Harness().use { h ->
            h.send(FlowProtocol.data(16, 5, byteArrayOf(1, 2)))
            assertArrayEquals(byteArrayOf(17, 0, 0, 0, 5, 0, 0), h.next())
            val ping = FlowProtocol.channel(5, 12345)
            h.send(FlowProtocol.data(18, 5, byteArrayOf(3)) + ping)
            assertArrayEquals(ping, h.next())
        }
    }

    @Test
    fun unsupportedProtocolClosesOnlyTheProxySession() {
        Harness().use { h ->
            h.send(byteArrayOf(127))
            assertNull(h.next())
            h.finished.get(4, TimeUnit.SECONDS)
        }
    }
}
