package dev.ricky.galaxywatchmanagerfree.feature

import dev.ricky.galaxywatchmanagerfree.wcs.CompanionProfile
import dev.ricky.galaxywatchmanagerfree.wcs.DataMapDecoder
import dev.ricky.galaxywatchmanagerfree.wcs.DataMapEncoder
import dev.ricky.galaxywatchmanagerfree.wcs.Proto
import dev.ricky.galaxywatchmanagerfree.wcs.WcsFrame
import dev.ricky.galaxywatchmanagerfree.wcs.WcsPaths
import dev.ricky.galaxywatchmanagerfree.wcs.WearDataSnapshot
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class WatchDndControlTest {
    private val uri = "wear://7e57c0de${WcsPaths.SET_PHONE_DND_TURN_ON}"
    private val original =
        mapOf<String, Any>(
            "from" to "watch",
            "key" to "booleanIsChecked",
            "type" to 0L,
            "booleanIsChecked" to false,
            "time" to 100L,
            "intZenDuration" to 60,
            "longZenDurationEndtime" to 900_000L,
            "priorityCategoryAlarms" to true,
            "priorityCallSenders" to 2,
            "arrayExceptionContacts" to listOf("synthetic-contact"),
        )

    private inner class Fixture(
        scope: CoroutineScope,
        val saved: MutableMap<String, Boolean> = mutableMapOf(),
    ) {
        var watchNode = "7e57c0de"
        var value: Boolean? = null
        var pending: Boolean? = null
        var submitted: Boolean? = null
        var readSucceeds = true
        var writeSucceeds = true
        var gateSucceeds = true
        val events = mutableListOf<String>()
        val frames = mutableListOf<ByteArray>()
        val gateFrames = mutableListOf<ByteArray>()
        val results = mutableListOf<WatchDndControl.Result>()
        val control =
            WatchDndControl(
                scope,
                watchNode = { watchNode },
                requestRead = {
                    events += "read"
                    readSucceeds
                },
                write = { targetUri, data ->
                    val isDnd =
                        WcsFrame.splitWearPath(targetUri).second == WcsPaths.SET_PHONE_DND_TURN_ON
                    events += if (isDnd) "write" else "gate"
                    val frame =
                        WcsFrame.wearPathFrame(
                            path = targetUri,
                            dataItems = listOf(DataMapEncoder.encode(data)),
                            senderPkg = CompanionProfile.WATCH7.packageName,
                            nodeId = "c0ffee12",
                            seqId = 42L,
                        )
                    if (isDnd) frames += frame else gateFrames += frame
                    if (isDnd) writeSucceeds else gateSucceeds
                },
                onValue = { value = it },
                onPending = { pending = it },
                onSubmitted = { submitted = it },
                loadSubmitted = { saved[watchNode] },
                saveSubmitted = { target ->
                    if (target == null) saved.remove(watchNode) else saved[watchNode] = target
                },
                onResult = results::add,
                now = { 200L },
            )
    }

    @Test
    fun `toggle rewrites the watch owned item and preserves its policy in the actual frame`() =
        runTest {
            val f = Fixture(this)
            f.control.receive(uri, original)
            f.control.connect()
            f.control.setEnabled(true)

            val item = Proto.parse(f.frames.single().drop(4).toByteArray()).nested(1)!!.nested(9)!!
            assertEquals(uri, item.text(2))
            assertEquals("c0ffee12", item.text(7))
            assertEquals(WcsPaths.SIGNATURE_PLUGIN, item.text(9))
            assertEquals(
                original
                    .minus("longZenDurationEndtime")
                    .plus(
                        mapOf(
                            "booleanIsChecked" to true,
                            "from" to "phone",
                            "time" to 200L,
                            "intZenDuration" to 0,
                        )
                    ),
                DataMapDecoder.decode(item.raw(4)!!),
            )
            assertEquals(listOf("gate", "write"), f.events)
            f.control.disconnect()
        }

    @Test
    fun `sync gate write precedes both dnd targets on the watch node`() = runTest {
        for (enabled in listOf(true, false)) {
            val f = Fixture(this)
            f.control.receive(uri, original)
            f.control.connect()
            f.control.setEnabled(enabled)

            assertEquals(listOf("gate", "write"), f.events)
            val gate =
                WcsFrame.decode(f.gateFrames.single().drop(4).toByteArray())
                    as WcsFrame.Incoming.WearPath
            assertEquals("wear://7e57c0de${WcsPaths.SET_PHONE_DND_SYNC_ENABLED}", gate.path)
            assertEquals(
                mapOf("booleanIsChecked" to true, "from" to "phone", "time" to 200L),
                gate.dataMap,
            )
            val dnd =
                WcsFrame.decode(f.frames.single().drop(4).toByteArray())
                    as WcsFrame.Incoming.WearPath
            assertEquals(uri, dnd.path)
            assertEquals(enabled, dnd.dataMap["booleanIsChecked"])
            f.control.disconnect()
        }
    }

    @Test
    fun `failed sync gate cancels a replaced command without writing its dnd target`() = runTest {
        val f = Fixture(this)
        f.control.receive(uri, original)
        f.control.connect()
        f.control.setEnabled(true)
        f.gateSucceeds = false
        f.control.setEnabled(false)

        assertEquals(listOf("gate", "write", "gate"), f.events)
        assertEquals(1, f.frames.size)
        assertEquals(WatchDndControl.Result.SEND_FAILED, f.results.last())
        assertNull(f.pending)
        assertEquals(false, f.value)
        val results = f.results.toList()
        advanceTimeBy(SettingCommands.CONFIRM_TIMEOUT_MS)
        runCurrent()
        f.control.receive(uri, original + ("booleanIsChecked" to true))
        assertEquals(results, f.results)
        assertEquals(true, f.value)
        f.control.disconnect()
    }

    @Test
    fun `queued writes and phone echoes never become confirmed watch state`() = runTest {
        val f = Fixture(this)
        f.control.receive(uri, original)
        f.control.connect()
        f.control.setEnabled(true)

        assertEquals(false, f.value)
        assertNull(f.pending)
        assertEquals(true, f.submitted)
        f.control.receive(uri, original + mapOf("from" to "phone", "booleanIsChecked" to true))
        assertEquals(false, f.value)
        assertFalse(WatchDndControl.Result.CONFIRMED in f.results)
        f.control.receive(uri, original + ("booleanIsChecked" to true))
        assertEquals(true, f.value)
        assertNull(f.pending)
        assertNull(f.submitted)
        assertEquals(WatchDndControl.Result.SUBMITTED, f.results.last())
        f.control.disconnect()
    }

    @Test
    fun `missing template is read before writing even if its value already matches the target`() =
        runTest {
            val f = Fixture(this)
            f.control.connect()
            f.control.setEnabled(false)
            assertEquals(listOf("read"), f.events)
            assertEquals(false, f.pending)
            assertTrue(f.frames.isEmpty())
            assertTrue(f.gateFrames.isEmpty())

            f.control.receive(uri, original)
            assertEquals(listOf("read", "gate", "write"), f.events)
            val written =
                WcsFrame.decode(f.frames.single().drop(4).toByteArray())
                    as WcsFrame.Incoming.WearPath
            assertEquals(false, written.dataMap["booleanIsChecked"])
            assertFalse(WatchDndControl.Result.CONFIRMED in f.results)
            f.control.receive(uri, original)
            assertEquals(WatchDndControl.Result.SUBMITTED, f.results.last())
            assertNull(f.pending)
            f.control.disconnect()
        }

    @Test
    fun `restored phone request stays unconfirmed and the next toggle reverses it`() = runTest {
        for (enabled in listOf(true, false)) {
            val sent = Fixture(this)
            sent.control.receive(uri, original)
            sent.control.connect()
            sent.control.setEnabled(enabled)
            val snapshot = WearDataSnapshot()
            assertTrue(snapshot.accept(sent.frames.single().drop(4).toByteArray()))
            sent.control.disconnect()
            val restored = WearDataSnapshot()
            assertTrue(restored.restore(snapshot.encode()))
            val f = Fixture(this)
            restored.envelopes().forEach { envelope ->
                val item = WcsFrame.decode(envelope) as WcsFrame.Incoming.WearPath
                f.control.receive(item.path, item.dataMap)
            }
            assertNull(f.value)
            assertEquals(enabled, f.submitted)
            assertNull(f.pending)
            assertTrue(f.frames.isEmpty())
            f.control.connect()
            f.control.setEnabled(!(f.submitted ?: f.value ?: false))
            assertEquals(listOf("gate", "write"), f.events)
            val written =
                WcsFrame.decode(f.frames.single().drop(4).toByteArray())
                    as WcsFrame.Incoming.WearPath
            assertEquals(uri, written.path)
            assertEquals(!enabled, written.dataMap["booleanIsChecked"])
            assertNull(f.value)
            assertFalse(WatchDndControl.Result.CONFIRMED in f.results)
            f.control.disconnect()
        }
    }

    @Test
    fun `reconnecting the same watch restores submitted intent without resending it`() = runTest {
        for (enabled in listOf(true, false)) {
            val f = Fixture(this)
            f.control.receive(uri, original)
            f.control.connect()
            f.control.setEnabled(enabled)
            f.control.disconnect()
            assertNull(f.pending)
            assertNull(f.submitted)
            advanceTimeBy(SettingCommands.CONFIRM_TIMEOUT_MS)
            runCurrent()

            f.control.connect()
            assertEquals(enabled, f.submitted)
            assertNull(f.pending)
            assertEquals(1, f.frames.size)
            f.control.setEnabled(!(f.submitted ?: f.value!!))
            val written =
                WcsFrame.decode(f.frames.last().drop(4).toByteArray()) as WcsFrame.Incoming.WearPath
            assertEquals(!enabled, written.dataMap["booleanIsChecked"])
            f.control.disconnect()
            f.watchNode = "deadbeef"
            f.control.connect()
            assertNull(f.submitted)
            assertEquals(2, f.frames.size)
            f.control.disconnect()
        }
    }

    @Test
    fun `delayed phone echoes cannot replace a newer submitted target after reconnecting`() =
        runTest {
            val f = Fixture(this)
            f.control.receive(uri, original)
            f.control.connect()
            f.control.setEnabled(true)
            f.control.setEnabled(false)
            advanceTimeBy(SettingCommands.CONFIRM_TIMEOUT_MS)
            runCurrent()
            f.control.receive(uri, original + mapOf("from" to "phone", "booleanIsChecked" to true))
            assertEquals(false, f.submitted)
            f.control.disconnect()
            f.control.connect()
            assertEquals(false, f.submitted)
            f.control.disconnect()
        }

    @Test
    fun `latest local request survives recreation with an older received snapshot`() = runTest {
        for (enabled in listOf(true, false)) {
            for (from in listOf("phone", "watch")) {
                val sent = Fixture(this)
                val snapshot = WearDataSnapshot()
                val envelope =
                    WcsFrame.wearPathFrame(
                            path = uri,
                            dataItems =
                                listOf(
                                    DataMapEncoder.encode(
                                        original +
                                            mapOf("from" to from, "booleanIsChecked" to !enabled)
                                    )
                                ),
                            senderPkg = CompanionProfile.WATCH7.packageName,
                            nodeId = "7e57c0de",
                            seqId = 41L,
                        )
                        .drop(4)
                        .toByteArray()
                assertTrue(snapshot.accept(envelope))
                sent.control.receive(uri, original)
                sent.control.connect()
                sent.control.setEnabled(enabled)
                sent.control.disconnect()

                val restored = WearDataSnapshot()
                assertTrue(restored.restore(snapshot.encode()))
                val f = Fixture(this, sent.saved)
                restored.envelopes().forEach { itemEnvelope ->
                    val item = WcsFrame.decode(itemEnvelope) as WcsFrame.Incoming.WearPath
                    f.control.receive(item.path, item.dataMap)
                }
                f.control.connect()
                assertEquals(enabled, f.submitted)
                assertEquals(enabled, f.saved[f.watchNode])
                assertTrue(f.frames.isEmpty())
                assertNull(f.pending)
                f.control.setEnabled(!(f.submitted ?: f.value ?: false))
                val written =
                    WcsFrame.decode(f.frames.single().drop(4).toByteArray())
                        as WcsFrame.Incoming.WearPath
                assertEquals(!enabled, written.dataMap["booleanIsChecked"])
                assertFalse(WatchDndControl.Result.CONFIRMED in f.results)
                f.control.disconnect()
            }
        }
    }

    @Test
    fun `live watch feedback clears the remembered request before the next connection`() = runTest {
        val f = Fixture(this)
        f.control.receive(uri, original)
        f.control.connect()
        f.control.setEnabled(true)
        assertEquals(true, f.saved[f.watchNode])
        f.control.receive(uri, original + ("booleanIsChecked" to true))
        assertTrue(f.saved.isEmpty())
        f.control.disconnect()
        f.control.connect()
        assertNull(f.submitted)
        assertEquals(true, f.value)
        f.control.disconnect()
    }

    @Test
    fun `failed replacement cannot replace the remembered request across recreation`() = runTest {
        val sent = Fixture(this)
        sent.control.receive(uri, original)
        sent.control.connect()
        sent.control.setEnabled(true)
        sent.writeSucceeds = false
        sent.control.setEnabled(false)
        assertEquals(WatchDndControl.Result.SEND_FAILED, sent.results.last())
        sent.control.disconnect()

        val f = Fixture(this, sent.saved)
        f.control.receive(uri, original)
        f.control.connect()
        assertEquals(true, f.submitted)
        f.control.disconnect()
        f.watchNode = "deadbeef"
        f.control.connect()
        assertNull(f.submitted)
        assertTrue(f.frames.isEmpty())
        f.control.disconnect()
    }

    @Test
    fun `wrong owners paths keys and value types cannot supply a template or confirm a command`() =
        runTest {
            val f = Fixture(this)
            f.control.connect()
            f.control.setEnabled(true)
            val invalid =
                listOf(
                    "wear://c0ffee12${WcsPaths.SET_PHONE_DND_TURN_ON}" to original,
                    "wear://deadbeef${WcsPaths.SET_PHONE_DND_TURN_ON}" to original,
                    "wear://7e57c0de${WcsPaths.SET_INFO_WATCH_NAME}" to original,
                    uri to (original + ("key" to "other")),
                    uri to (original + ("booleanIsChecked" to "true")),
                )
            invalid.forEach { (source, data) -> f.control.receive(source, data) }
            assertTrue(f.frames.isEmpty())
            assertNull(f.value)
            assertEquals(true, f.pending)
            f.control.disconnect()
        }

    @Test
    fun `unavailable source times out without a write or a submitted result`() = runTest {
        val f = Fixture(this)
        f.control.connect()
        f.control.setEnabled(true)
        advanceTimeBy(SettingCommands.CONFIRM_TIMEOUT_MS)
        runCurrent()
        assertEquals(WatchDndControl.Result.SOURCE_UNAVAILABLE, f.results.last())
        assertNull(f.pending)
        assertTrue(f.frames.isEmpty())
        f.control.receive(uri, original)
        assertTrue(f.frames.isEmpty())
        f.control.disconnect()
    }

    @Test
    fun `sent target permits immediate reverse toggle without waiting for feedback`() = runTest {
        val f = Fixture(this)
        f.control.receive(uri, original)
        f.control.connect()
        f.control.setEnabled(true)
        assertNull(f.pending)
        f.control.receive(uri, original + mapOf("from" to "phone", "booleanIsChecked" to true))

        assertNull(f.pending)
        assertEquals(false, f.value)
        assertEquals(true, f.submitted)
        assertEquals(WatchDndControl.Result.SUBMITTED, f.results.last())
        f.control.setEnabled(!(f.submitted ?: f.value!!))
        advanceTimeBy(SettingCommands.CONFIRM_TIMEOUT_MS)
        runCurrent()
        val targets =
            f.frames.map {
                (WcsFrame.decode(it.drop(4).toByteArray()) as WcsFrame.Incoming.WearPath)
                    .dataMap["booleanIsChecked"]
            }
        assertEquals(listOf(true, false), targets)
        assertEquals(false, f.submitted)
        assertEquals(false, f.value)
        assertFalse(WatchDndControl.Result.CONFIRMED in f.results)
        f.control.disconnect()
        assertNull(f.submitted)
    }

    @Test
    fun `watch feedback clears submitted target while failed replacement keeps it`() = runTest {
        val f = Fixture(this)
        f.control.receive(uri, original)
        f.control.connect()
        f.control.setEnabled(true)
        assertEquals(true, f.submitted)
        f.gateSucceeds = false
        f.control.setEnabled(false)
        assertEquals(WatchDndControl.Result.SEND_FAILED, f.results.last())
        assertEquals(true, f.submitted)
        f.control.receive(uri, original + ("booleanIsChecked" to true))
        assertNull(f.submitted)
        assertEquals(true, f.value)
        f.control.disconnect()
    }

    @Test
    fun `watch feedback overrides a sent target even when it disagrees`() = runTest {
        val f = Fixture(this)
        f.control.receive(uri, original)
        f.control.connect()
        f.control.setEnabled(true)
        assertNull(f.pending)
        assertEquals(true, f.submitted)
        f.control.receive(uri, original)
        assertNull(f.submitted)
        assertEquals(false, f.value)
        assertTrue(f.saved.isEmpty())
        advanceTimeBy(SettingCommands.CONFIRM_TIMEOUT_MS)
        runCurrent()
        assertEquals(WatchDndControl.Result.SUBMITTED, f.results.last())
        assertNull(f.pending)
        assertEquals(1, f.frames.size)
        f.control.receive(uri, original + ("booleanIsChecked" to true))
        assertEquals(true, f.value)
        assertFalse(WatchDndControl.Result.CONFIRMED in f.results)
        f.control.disconnect()
    }

    @Test
    fun `failed reads and writes clear pending without changing confirmed state`() = runTest {
        val readFailure = Fixture(this)
        readFailure.control.connect()
        readFailure.readSucceeds = false
        readFailure.control.setEnabled(true)
        assertEquals(WatchDndControl.Result.SEND_FAILED, readFailure.results.last())
        assertNull(readFailure.pending)
        assertTrue(readFailure.frames.isEmpty())
        readFailure.control.disconnect()

        val writeFailure = Fixture(this)
        writeFailure.control.receive(uri, original)
        writeFailure.control.connect()
        writeFailure.writeSucceeds = false
        writeFailure.control.setEnabled(true)
        assertEquals(WatchDndControl.Result.SEND_FAILED, writeFailure.results.last())
        assertEquals(listOf("gate", "write"), writeFailure.events)
        assertEquals(1, writeFailure.gateFrames.size)
        assertNull(writeFailure.pending)
        assertEquals(false, writeFailure.value)
        writeFailure.control.disconnect()
    }

    @Test
    fun `new command replaces the pending target and its timeout`() = runTest {
        val f = Fixture(this)
        f.control.connect()
        f.control.setEnabled(true)
        advanceTimeBy(3_000)
        f.control.setEnabled(false)
        advanceTimeBy(1_000)
        runCurrent()
        assertEquals(false, f.pending)
        f.control.receive(uri, original)
        val written =
            WcsFrame.decode(f.frames.single().drop(4).toByteArray()) as WcsFrame.Incoming.WearPath
        assertEquals(false, written.dataMap["booleanIsChecked"])
        assertFalse(WatchDndControl.Result.CONFIRMED in f.results)
        f.control.receive(uri, original)
        assertEquals(WatchDndControl.Result.SUBMITTED, f.results.last())
        f.control.disconnect()
    }

    @Test
    fun `disconnect cancels commands and reconnect never uses another watch template`() = runTest {
        val f = Fixture(this)
        f.control.receive(uri, original)
        f.control.connect()
        f.control.setEnabled(true)
        f.control.disconnect()
        assertNull(f.pending)
        f.control.receive(uri, original + ("booleanIsChecked" to true))
        advanceTimeBy(SettingCommands.CONFIRM_TIMEOUT_MS)
        runCurrent()
        assertEquals(false, f.value)
        assertEquals(
            listOf(WatchDndControl.Result.PENDING, WatchDndControl.Result.SUBMITTED),
            f.results,
        )
        f.control.setEnabled(true)
        assertEquals(WatchDndControl.Result.SEND_FAILED, f.results.last())
        assertEquals(1, f.frames.size)

        f.watchNode = "deadbeef"
        f.control.connect()
        f.control.setEnabled(true)
        assertEquals(listOf("gate", "write", "read"), f.events)
        f.control.receive(uri, original)
        assertEquals(1, f.frames.size)
        f.control.receive("wear://deadbeef${WcsPaths.SET_PHONE_DND_TURN_ON}", original)
        val written =
            WcsFrame.decode(f.frames.last().drop(4).toByteArray()) as WcsFrame.Incoming.WearPath
        assertEquals("wear://deadbeef${WcsPaths.SET_PHONE_DND_TURN_ON}", written.path)
        f.control.disconnect()
    }
}
