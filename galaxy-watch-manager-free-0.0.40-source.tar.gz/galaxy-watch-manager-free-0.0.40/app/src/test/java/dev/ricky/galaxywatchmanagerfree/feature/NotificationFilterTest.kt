package dev.ricky.galaxywatchmanagerfree.feature

import java.time.LocalTime
import org.junit.Assert.*
import org.junit.Test

class NotificationFilterTest {
    private val chat = "example.synthetic.chat"
    private val mail = "example.synthetic.mail"

    private fun time(hour: Int, minute: Int = 0) = LocalTime.of(hour, minute)

    @Test
    fun defaultsAllowAllApps() {
        assertTrue(NotificationFilterConfig().allows(chat))
        assertTrue(NotificationFilterConfig().allows(mail))
    }

    @Test
    fun selectedModeMatchesExactPackageNames() {
        val config = NotificationFilterConfig(NotificationFilterMode.SELECTED, setOf(chat))
        assertTrue(config.allows(chat))
        assertFalse(config.allows(mail))
        assertFalse(config.allows("$chat.clone"))
        assertFalse(config.allows(chat.uppercase()))
    }

    @Test
    fun emptySelectionBlocksEveryApp() {
        val config = NotificationFilterConfig(NotificationFilterMode.SELECTED)
        assertFalse(config.allows(chat))
        assertFalse(config.allows(mail))
    }

    @Test
    fun switchingToAllRetainsSelectionButAllowsOtherApps() {
        val selected = NotificationFilterConfig(NotificationFilterMode.SELECTED, setOf(chat))
        val all = selected.copy(mode = NotificationFilterMode.ALL)
        assertTrue(all.allows(mail))
        assertEquals(setOf(chat), all.packages)
        assertFalse(all.copy(mode = NotificationFilterMode.SELECTED).allows(mail))
    }

    @Test
    fun nonemptyLegacyListMigratesToSelectedMode() {
        val config = NotificationFilterConfig.restore(null, emptySet(), setOf(chat))
        assertEquals(NotificationFilterMode.SELECTED, config.mode)
        assertTrue(config.allows(chat))
        assertFalse(config.allows(mail))
    }

    @Test
    fun emptyLegacyListPreservesAllAppsDefault() {
        assertEquals(NotificationFilterConfig(), NotificationFilterConfig.restore(null, emptySet()))
    }

    @Test
    fun savedEmptySelectionDoesNotFallBackToLegacyOrAll() {
        val config = NotificationFilterConfig.restore("SELECTED", emptySet(), setOf(chat))
        assertTrue(config.packages.isEmpty())
        assertFalse(config.allows(chat))
    }

    @Test
    fun savedAllModeIsNotOverwrittenByLegacyList() {
        val config = NotificationFilterConfig.restore("ALL", setOf(chat), setOf(mail))
        assertEquals(setOf(chat), config.packages)
        assertTrue(config.allows(mail))
    }

    @Test
    fun unreadableModeDoesNotEnableUnselectedApps() {
        val config = NotificationFilterConfig.restore("invalid", setOf(chat))
        assertTrue(config.allows(chat))
        assertFalse(config.allows(mail))
    }

    @Test
    fun restoredSelectionDoesNotShareMutableStorageSet() {
        val stored = mutableSetOf(chat)
        val config = NotificationFilterConfig.restore("SELECTED", stored)
        stored.clear()
        assertTrue(config.allows(chat))
    }

    @Test
    fun disabledScheduleAllowsEveryTime() {
        val schedule = NotificationSchedule()
        assertTrue(schedule.allows(time(0)))
        assertTrue(schedule.allows(time(8)))
        assertTrue(schedule.allows(time(23, 59)))
    }

    @Test
    fun defaultWindowIsStartInclusiveAndEndExclusive() {
        val schedule = NotificationSchedule(enabled = true)
        assertFalse(schedule.allows(time(7, 59)))
        assertTrue(schedule.allows(time(8)))
        assertTrue(schedule.allows(time(21, 59)))
        assertFalse(schedule.allows(time(22)))
        assertFalse(schedule.allows(time(0)))
    }

    @Test
    fun overnightWindowWrapsAcrossMidnight() {
        val schedule =
            NotificationSchedule(enabled = true, startMinute = 22 * 60, endMinute = 8 * 60)
        assertFalse(schedule.allows(time(21, 59)))
        assertTrue(schedule.allows(time(22)))
        assertTrue(schedule.allows(time(23, 59)))
        assertTrue(schedule.allows(time(0)))
        assertTrue(schedule.allows(time(7, 59)))
        assertFalse(schedule.allows(time(8)))
        assertFalse(schedule.allows(time(12)))
    }

    @Test
    fun equalStartAndEndMeansAllDay() {
        val schedule =
            NotificationSchedule(enabled = true, startMinute = 8 * 60, endMinute = 8 * 60)
        assertTrue(schedule.allows(time(0)))
        assertTrue(schedule.allows(time(7, 59)))
        assertTrue(schedule.allows(time(8)))
        assertTrue(schedule.allows(time(23, 59)))
    }

    @Test
    fun restoreCoercesOutOfRangeMinutes() {
        val schedule = NotificationSchedule.restore(true, -10, 24 * 60 + 20)
        assertEquals(0, schedule.startMinute)
        assertEquals(NotificationSchedule.MINUTES_PER_DAY - 1, schedule.endMinute)
        assertTrue(schedule.allows(time(0)))
        assertFalse(schedule.allows(time(23, 59)))
    }
}
