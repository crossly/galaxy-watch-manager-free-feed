package dev.ricky.galaxywatchmanagerfree.feature

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class NotificationListenerRecoveryTest {
    @Test
    fun `requires granted access and a disconnected listener`() {
        assertFalse(
            NotificationListenerRecovery.shouldRequestRebind(
                accessGranted = false,
                connected = false,
                nowMillis = 10_000L,
                lastAttemptAt = 0L,
            )
        )
        assertFalse(
            NotificationListenerRecovery.shouldRequestRebind(
                accessGranted = true,
                connected = true,
                nowMillis = 10_000L,
                lastAttemptAt = 0L,
            )
        )
    }

    @Test
    fun `first request for granted disconnected listener is allowed`() {
        assertTrue(
            NotificationListenerRecovery.shouldRequestRebind(
                accessGranted = true,
                connected = false,
                nowMillis = 1_000_000L,
                lastAttemptAt = 0L,
            )
        )
    }

    @Test
    fun `repeated requests are throttled until the interval elapses`() {
        assertFalse(
            NotificationListenerRecovery.shouldRequestRebind(
                accessGranted = true,
                connected = false,
                nowMillis = 10_000L,
                lastAttemptAt = 9_000L,
            )
        )
        assertTrue(
            NotificationListenerRecovery.shouldRequestRebind(
                accessGranted = true,
                connected = false,
                nowMillis = 11_000L,
                lastAttemptAt = 9_000L,
            )
        )
    }
}
