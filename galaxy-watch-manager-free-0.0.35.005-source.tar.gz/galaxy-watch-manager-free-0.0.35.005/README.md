# Galaxy Watch Manager Free

<img src="artwork/icon.png" alt="Galaxy and watch on a white background" width="128" />

独立的三星 Galaxy Watch 管理应用。从 `galaxy-watch-tweaker` 的实验模块拆分而来，使用普通 Android 蓝牙 API 直接与手表通信。

- 产品名：**Galaxy Watch Manager Free**
- Android 包名：`dev.ricky.galaxywatchmanagerfree`
- 初始版本：**0.0.1**；后续按 **0.0.2、0.0.3…** 递增
- Android 8.0+；目前参与真机测试的设备组合：
  - **设备对 1**：荣耀 Magic 8 Pro + Galaxy Watch 7 Ultra
  - **设备对 2**：一加 13 Pro + Galaxy Watch 6
  - 以上记录硬件组合；具体系统、固件与组件版本需随测试日志确认，不能由型号推定。
- **协议规范文档**：详见 [`docs/PROTOCOL-SPEC.md`](docs/PROTOCOL-SPEC.md)（包含传输层、Protobuf 信封、GMS ReorderingQueue、三段式健康同步、表盘控制、80+ 模块字典及调试指令手册。后续解析出更多协议或变更时必须持续同步维护该文档）。
- **逆向研究资料**：原始抓包、特性矩阵、健康枚举等过程资料见 [`research/`](research/README.md)（自 `galaxy-watch-tweaker` 仓库迁移而来；与 SSOT 冲突时以 `docs/PROTOCOL-SPEC.md` 为准）。

## 当前能力与边界

### 已实测可用

- RFCOMM 直连与 WCS 握手，已在开发设备验证连接与消息收发；长期稳定性仍待持续验证。
- **运行内存清理**：支持查询手表当前 RAM 使用情况与后台应用列表，一键清理后台进程（`memory/clean`）并在等待手表调度后自动回读刷新内存状态。已在真机实测有效。
- 电量、充电状态、剩余续航、佩戴状态、内存占用，以及 78 项以上的手表设置同步。
- 省电模式 (PSM) 双向切换，含回执与超时补发。
- **官方表盘切换与状态查询**：完整逆向 Google Wearable RPC 的 `generation` 重排队列机制（解决断开重连后序列号重置导致的静默丢弃问题），打通 `/wcs_extension/sysui/watchface` 通道。支持查询当前生效表盘及收藏夹最近使用排序（`recent` / `custom`），提供 43 款官方预设表盘的一键切换（含 Galaxy Watch Ultra 独占旗舰表盘），切换后手表底层 `WallpaperService` 实时生效，手机卡片 UI 实时双向同步。表盘预览随包保留 43 张逐款效果图，概览、设备图标和表盘列表共用同一资源；不需要额外资产目录。图片来源及许可边界见 [THIRD-PARTY.md](THIRD-PARTY.md)。
- **通知桥接与即时下发**：还原 Wear OS 系统级 Bridger DataItem 通道（`wear://<phoneNode>/bridger/stream_item:…`），支持手机通知与测试通知即时弹窗并常驻手表通知中心。
- **动态常驻通知**：前台连接通知会随健康同步更新今日心率、步数/目标完成度与手表电量，并区分连接中、已连接和维持连接状态；无关状态变化不会反复刷新通知。
- **灰度模式 (Grayscale) 与高对比度文字**：通过 Tag 9 DataItem 正确传递 ASCII 签名凭据，手表底层 `accessibility_display_daltonizer_enabled` 与 Dalvik ExclusiveTaskManager 实时响应，黑白显示完全生效。
- **Samsung Health 独立双向同步**：逆向突破 GMS `OemCompanionVerifier` 鉴权机制（携带官方健康包名与证书指纹），打通 `/samsung_health/wearable_message` 通道。无需安装官方 Samsung Health，独立支持双向 gzip 游标握手（`REQUEST_DATA` → `SYNC_DATA` → `LOG_DATA`），实时解析上报的区间计步（`pedometer_step_count`）、心率、压力等 80+ 个健康数据模块，既有抓包确认手表端游标提交闭环。
- **Samsung Health Monitor（ECG / 血压）结果与校准同步**：接收手表端官方 SHM 生成的 ECG 波形与血压记录，保留采样率和手表分类。血压校准通过现有 WCS `/991` 链路编排三轮采样，在手机录入真实袖带读数，交由手表官方算法合并并保存校准；不再并发发送 `/remote_intent/rpc`，避免手表端跨模块 Activity 冲突闪退。完整三轮流程已在 Galaxy Watch 7 Ultra 真机验证通过，Watch 6 等其余机型仍待对应设备测试；发送成功只表示请求已排队。
- **手表设置即时反馈**：抬腕亮屏、触摸亮屏、AOD 等设置成功进入发送队列后立即更新界面，并主动回读；手机写入的 DataItem 自回声不作为手表确认，真实回报仍会校正显示。
- 亮度等数值设置的写入会被手表数据层接受并回读。
- **启动自动连接**：应用进程启动或回到前台时，从系统已配对列表中识别手表（优先上次成功使用的 MAC，其次 Galaxy Watch / SM-L 型号名）并自动拉起连接；主界面可直接点「连接」重试，设置页可关闭自动连接或手动触发查找。名称匹配只是排序启发式，是否可用仍以 WCS 握手结果为准。
- **应用内更新**：设置页「关于与更新」读取公开更新清单（[`galaxy-watch-manager-free-feed`](https://github.com/crossly/galaxy-watch-manager-free-feed)，包含双通道清单、签名后的 APK 及其完整对应源码归档），发现新版本即**自动下载 APK**，校验 SHA-256 与签名证书后由系统安装器完成安装，不再需要跳到 GitHub。
  - 清单在 feed 仓库 `main` 分支。最新包仍在 `apk` 分支；新发布清单使用被版本标签保留的 commit SHA 直链，旧清单不会因下一次发布失效。保留旧包会增加仓库存储。
  - 双重校验：`sha256` 必须与本地下载结果一致；APK 签名证书必须与本机已安装版本同一把密钥，否则拒绝安装。
  - 启动时最多每 12 小时自动检查一次；整个过程无需任何令牌或登录，应用只增加 `INTERNET` 与 `REQUEST_INSTALL_PACKAGES` 权限。
  - 可在「关于与更新 → 下载镜像」选择 `gh-proxy.com`、`ghproxy.net` 或 `ghfast.top`，同时加速更新检查与 APK 下载；默认不使用镜像。选择会保存，切换后正在进行的检查/下载会重新发起，已校验的安装包仍可安装。第三方镜像不改变包名、版本、大小、SHA-256 与签名校验要求；可用性取决于服务和当前网络，此选项尚待手机交互验收。
  - 首次安装时系统会要求允许「安装未知应用」，授权后即可一键更新。
- 自动查询默认间隔 900 秒（15 分钟），可在「设置 → 设备连接 → 高级选项」关闭或调整。电量只在界面可见时查询，健康同步可在后台继续；内存仅手动刷新。

### 健康数据与本机分析

- **活动与历史**：今日步数、目标进度、活动消耗、步行距离，以及今日/7 天/逐日详情。已知全天汇总优先于局部明细；缺少完整回补时不能宣称是全天数据。
- **心率、压力与身体指标**：心率数据由手表 Samsung Health 官方服务同步；今日曲线支持点按/拖动读取时间与 bpm，近 7 天趋势以当日最低–最高范围胶囊叠加日均线，纵轴不强制从 0 开始。压力曲线使用同款渐变和选点交互，显示原始分数与等级；正念呼吸放松位于压力读数列表之前。血氧、皮温、呼吸频率和 HRV 仅展示真实记录。
- **睡眠**：接收会话与分期；只有检测起止时刻时显示记录区间，不生成假睡眠时长或效率。同一天的多段睡眠（夜间 + 午休）按醒来日期合并：卡片显示当天合计并标注「含小睡」，结构条、图例与分期时间线合并全部真实分期，时间轴空白表示会话之间的清醒间隔。公开版不再内置厂商推理运行时，因此不会从 `sleep_raw_data` 发起新的四阶段推理；手表已上报的分期、旧版本地分析缓存、已有评分计算与导出继续保留。自用构建可用 `-PvendorAssetsDir=private/vendor-assets` 加载用户本地提取的运行时恢复本机推理；模型来源与限制见 [SLEEP-ANALYSIS.md](docs/SLEEP-ANALYSIS.md)，授权边界见 [THIRD-PARTY.md](THIRD-PARTY.md)。
- **运动记录**：展示实际同步的类型、日期、距离、消耗与心率；没有坐标的记录不绘制假地图。
- **后台同步**：连接后自动同步，断线取消、重连恢复。原始记录按修订替换后再计算；健康缓存、覆盖标记与睡眠分析缓存按配对设备隔离。旧缓存只迁给原设备，原文件保留以便恢复。
- 真实设备验证范围为当前开发手机和手表；此前含厂商运行时的本地推理已通过 ARM64 实测，ARMv7 尚未实机验收。本轮资产隔离后的公开版与可选本机构建尚未进行设备验收。
- 独立传感器采集、native 算法回放及实验室模块已移除；相关历史研究不参与应用构建。

### 数据与日志

正常日志不记录通知正文或健康记录原文；日志清空同时删除本地日志文件。Android 云备份与设备迁移仅包含外观设置，健康记录、配对身份、设备标识与诊断日志保持本机私有。协议缓存恢复失败会记录错误类别并保留恢复副本，不把损坏文件当作有效的空数据。

### 未打通（请勿当作可用功能）

- **电池保护**：`dataMapId=206` 不含状态数组，本固件未暴露该设置。

**尚不支持恢复出厂状态下的完整首次配对。** 新用户请先通过官方流程完成手表首次设置，再进入「设置 → 设备连接」选择手表，按页面提示获取连接身份并验证连接。身份自动获取依赖手机上已安装、已启用且可用的 Google Wear 服务；中国版使用 `com.google.android.wearable.app.cn`，应用声明了对应包可见性。若曾为避免连接竞争而停用 Google Wear，应先恢复它再获取身份；`API_UNAVAILABLE` 不能直接解释为“没有安装”。无法获取时保留高级手工配置入口，不把系统蓝牙配对成功当作业务连接成功。换机、新配对及长期稳定性仍需实机验证，不能仅凭蓝牙配对记录保证可用。

取得并验证手机身份后，手机端的直接蓝牙路径无需通过 Galaxy Wearable、Watch Plugin 或 Google Wear 转发，也不需要 Root 或 LSPosed；自动读取身份时仍需可用的 Wear 服务。手表端仍使用固件内置的三星 WCS 服务。保留的 GMS 传输适配器仅供显式开启的诊断使用，默认不启动。

电池保护及导入 Health Connect 尚未验收；收到配置项不代表它可写，也不代表其背后的云端服务已实现。部分固件可能不提供对应功能。

## 健康记录导出与页面排版

打开 ECG/BP 模块可直接查看当日记录和已有图形。ECG 波形区块右上角下载图标将完整记录保存为相册 PNG。
「设置 → 页面排版」可调整概览/健康板块顺序、显示与摘要宽度；「设置 → 导出健康数据」可保存或分享 JSON/CSV ZIP。
数据包包含原始模块、ECG 采样、单位、来源、时间、JSON Schema 和校验值，适合编写迁移程序或供 Agent 分析。
Apple Health 需要获得授权的 iOS 导入器；本项目 ZIP 不能直接导入，ECG 写入还受平台类型限制，详见 [健康导出说明](docs/HEALTH-EXPORT.md)。

## 语言与界面

应用支持简体中文和 English，默认跟随系统语言，也可在「设置 → 语言」单独选择。
Android 13+ 可通过系统应用语言设置切换。两种语言均随包提供，可离线切换。
资源结构与新增语言步骤见 [I18N.md](docs/I18N.md)，界面规范见 [UI-STANDARDS.md](docs/UI-STANDARDS.md)。

「设置 → 外观」可分别选择跟随系统/浅色/深色、壁纸取色或蓝/紫/薄荷强调色，以及漂浮/固定底栏。漂浮底栏保持紧凑悬浮样式；固定底栏采用 Material 3 全宽导航并独立占用底部空间。选择会保存，切换底栏样式保留当前页面，二级设置页继续隐藏主导航。设计依据与 FLClash Android 选项对照见 [UI-FLCLASH-REFERENCE.md](docs/UI-FLCLASH-REFERENCE.md)。

## 构建与测试

需要 JDK 17、Android SDK 36、Build Tools 35.0.0。

```bash
./gradlew :app:spotlessCheck :app:testDebugUnitTest :app:lintDebug :app:assembleDebug
./gradlew :app:assembleRelease
```

调试 APK：`app/build/outputs/apk/debug/app-debug.apk`。正式版使用发布证书签名，调试版与正式版证书不同，切换时 Android 可能要求先卸载原安装。

## 签名与 GitHub 发布

签名复用 `galaxy-watch-tweaker` 的正式发布证书。密钥不进入 Git；新私有仓库使用以下 Actions Secrets：

- `RELEASE_KEYSTORE_BASE64`
- `RELEASE_KEYSTORE_PASSWORD`
- `RELEASE_KEY_ALIAS`
- `RELEASE_KEY_PASSWORD`

版本唯一来源为 [`version.properties`](version.properties)。稳定版为 `0.0.N`，Nightly 为 `0.0.N.MMM`（`001`–`999`）。标签必须与文件版本严格一致；推送对应 `v` 标签后，Release workflow 自动执行单元测试、Android lint、构建、签名验证，并发布 APK、完整对应源码归档及各自的 SHA-256 校验文件。Nightly 标记为 GitHub prerelease，不占用稳定版 Latest。

应用内在「设置 → 关于与更新 → 更新通道」选择，默认稳定版。稳定通道只读取 `version.json`；Nightly 通道读取 `version.json` 和 `nightly.json` 并选择较新版本，因而也能升级到后续稳定版。两个清单与 APK 分支（`apk` / `apk-nightly`）独立发布，APK URL 固定到保留的提交。更新检查和下载使用公开 feed，无需在手机中配置 GitHub token，源码仓库保持私有。

两个通道使用相同包名与正式签名，可覆盖升级并保留数据。切回稳定通道不会降级安装：例如 `0.0.32.002` 会等待 `0.0.33`。新的 Android versionCode 为 `N × 1000 + MMM`，稳定版的 `MMM` 为 `0`；读取旧版本时兼容原先的 `code=N`。

初始发布（仅一次）：

```bash
./scripts/release.sh --initial
```

后续稳定版发布（递增第三段，例如 `0.0.32.002` → `0.0.33`）：

```bash
./scripts/release.sh
```

Nightly 发布（例如 `0.0.32` → `0.0.32.001` → `0.0.32.002`）：

```bash
./scripts/release.sh --nightly
```

脚本要求干净的 main 分支且与远端同步，先验证构建，再更新版本、提交、打标签并原子推送。发布失败可在 Actions 的 Release 页面输入已有标签重试，无需增加版本。

本地正式签名：设置 `RELEASE_KEYSTORE`（证书路径）、`RELEASE_KEYSTORE_PASSWORD`、`RELEASE_KEY_ALIAS` 和 `RELEASE_KEY_PASSWORD` 环境变量，然后运行：

```bash
./gradlew :app:assembleRelease
./scripts/sign-apk.sh
```

输出：`artifacts/galaxy-watch-manager-free-0.0.N.apk`，证书密码通过环境变量交给 apksigner。

## 手机测试

以下脚本仅用于开发设备测试，包名针对当前测试环境，不是适用于全部型号的接管方案。不要把卸载官方应用或恢复出厂当作连接失败的处理步骤；先保留官方设置和连接环境，用于获取身份及必要时恢复。开发测试需要为直接蓝牙连接释放通道时：

```bash
./scripts/phone-test.sh disable-official
```

停止本应用并恢复官方组件：

```bash
./scripts/phone-test.sh restore-official
```

安装后授予蓝牙权限。**首次启动会直接进入全屏连接引导**（已有可用身份的老用户自动跳过）：第 1 步检测系统里的 Google Wear（中国版/国际版，含有效启用状态）、Galaxy Wearable 与已配对手表；检测到 Google Wear 时说明复用已登记的手机身份，并提示官方应用与直连争用蓝牙通道；未检测到时提供安装与官方配对指引。之后依次读取身份、释放官方连接、验证连接与完成；完成/跳过会记住，之后可从「设置 → 设备连接 → 连接指南」重新进入。

「设置 → 设备连接」按 FLClash Android 的状态卡和分组设置组织：当前状态只提供一个主操作；点选表入口打开已配对设备选择面板；官方应用切换默认收起、等待用户处理时展开；自动连接和自动查询直接显示；手输 Node ID、应用权限与诊断日志放入高级折叠区。待验证身份不会显示为验证成功，等待切换不会持续转圈。源码依据与整体 UI 评估见 [UI-FLCLASH-REFERENCE.md](docs/UI-FLCLASH-REFERENCE.md)。官方连接管理器与独立蓝牙连接可能竞争，本应用不会自动冻结、停用或卸载其他应用。

取得并验证手机身份后，连接页提供可选的「释放官方蓝牙应用」：安装并运行 Shizuku 且授权后，可一键停用实际安装的 Google Wear（中国版或国际版）、Galaxy Wearable 与 Watch 4 / 5 / 6 / 7 对应插件这几项明确的连接组件，不删除其数据，也不停用 Samsung Health / SHM；停用前先保存原始启用状态，之后可一键恢复。没有 Shizuku 时，页面列出实际安装的组件并提供各自的应用详情入口，按提示逐项强行停止或停用；卸载仅作为用户自行选择的最后手段，会删除官方应用数据。读取手机身份仍需要可用的 Google Wear，因此应先取身份再释放官方连接。遇到占用提示时按页面说明处理，并保留恢复官方连接的途径。通知转发还需单独授予「通知使用权」。旧实验应用 `dev.ricky.watchfree` 与本产品包名不同，测试时应停止旧应用，避免争用通道。

**多代手表与多品牌手机实机验证状态**：

- **Galaxy Watch 7 Ultra + 荣耀 Magic 8 Pro**：已有连接、健康数据及官方校准等实机使用记录；v0.0.29 手机三轮袖带校准向导已实测通过，手表端启动校准不再崩溃。最新抬腕亮屏等设置开关修复仍需复测。
- **Galaxy Watch 6 + 一加 13 Pro**：用户反馈基础功能基本正常；v0.0.29 已移除并发远程启动并新增手机三轮袖带校准向导，仍待朋友验证完整流程。
- **Watch 4 / 5 / FE 系列**：已加入型号识别、按代选择官方插件身份和交接白名单，完成选定插件的静态对比与回归测试，尚待对应真机验收。路径一致不代表所有固件与功能可用，首次配对仍需官方流程。详见 [Watch 4–6 兼容性调查](docs/WATCH4-6-COMPATIBILITY.md)。
- **手表名称与外观图形**：概览顶部可重命名手表，使用当前手表名称 DataItem 的原始 URI 与元数据，经 WCS 读改写同步到手表，并按设备在本机保存昵称；未自定义时显示手表上报的默认名称。用户已在 `0.0.33.005 Nightly` 确认改名问题解决，该实现纳入 `0.0.34` 正式版；断线重连与手表重启后的名称持久化仍待单独验收。名称左侧按型号渲染 Ultra / Classic / 标准版外观图形。通知入口位于「设置 → 应用 → 通知与下发」。

诊断广播仅允许持有系统 `DUMP` 权限的调用方（例如 adb shell）：

```bash
adb shell am broadcast \
  -n dev.ricky.galaxywatchmanagerfree/.core.WatchCommandReceiver \
  -a dev.ricky.galaxywatchmanagerfree.CMD --es cmd setting_dump

# 协议探针：向任意 path 发送任意消息体
adb shell am broadcast \
  -n dev.ricky.galaxywatchmanagerfree/.core.WatchCommandReceiver \
  -a dev.ricky.galaxywatchmanagerfree.CMD \
  --es cmd probe --es path /w_module_sec_watch_setting/create_dataitem_req \
  --es msgid create_dataitem_req --ei msgType 4 --es b64 <base64(JSON)>
```

`b64` 参数避免 shell 吞掉 JSON 里的引号。`msgType` 必须是 `--ei`（整型），用 `--el` 会被忽略并回落到默认值。

## 开发约定与授权

贡献、测试边界、格式和远程调试见 [CONTRIBUTING.md](CONTRIBUTING.md)。

原创代码采用 **GNU General Public License v3.0** 授权，全文见 [LICENSE](LICENSE)（Copyright (C)
2025–2026 Galaxy Watch Manager Free authors）。简单说：可以自由使用、修改、再分发，但分发修改版时
必须同样以 GPLv3 提供完整源代码并保留声明。

厂商来源组件（睡眠运行时、Samsung JNI、表盘图片等）**不在**这项授权范围内，它们各自遵从上游条款，
详见 [THIRD-PARTY.md](THIRD-PARTY.md)。睡眠运行时仍不进入公开仓库、公开 APK 或源码归档，仅可在忽略的
`private/vendor-assets/` 保留用户本地副本，供显式开启的本机自用构建使用；43 张原有表盘预览恢复随包保留，
仍为厂商来源，不因恢复显示而取得新的再分发授权。
因此「整个仓库的所有文件都是 GPLv3」的说法不成立：GPLv3 覆盖的是本仓库原创的
Kotlin/Compose/脚本代码与原创图形资源。

## 项目结构

- `app/`：独立 Android 应用及协议测试
- `artwork/`：原创白底银河与手表 SVG、1024px PNG
- `scripts/`：版本、发布、签名、图标生成与设备测试脚本
- `.github/workflows/`：CI 和版本标签发布

图标为白底绘图：深色表壳配钢色表圈，银河螺旋落在表盘上。`artwork/icon.svg`、各 DPI PNG 与 Android 自适应矢量均由 `scripts/generate-icons.py` 生成（优先 cairosvg，无 cairosvg 时回退到 headless Chrome）。

协议研究资料已迁入本仓库的 `research/`；反编译 APK、原始蓝牙抓包与反编译目录仅保留于本地忽略目录，私有签名文件不进入版本控制。本项目为非官方实验产品，与 Samsung 无隶属关系。
