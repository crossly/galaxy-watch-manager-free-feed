#!/usr/bin/env python3
"""Verify bundled watch-face previews and exclude local-only sleep runtime assets."""
from __future__ import annotations

import argparse
import hashlib
from pathlib import Path
import re
import sys
import zipfile

SLEEP_DIR = Path("app/src/main/assets/sleep")
WATCHFACE_DIR = Path("app/src/main/res")
PRESETS_FILE = Path("app/src/main/java/dev/ricky/galaxywatchmanagerfree/feature/WatchFacePreset.kt")
SLEEP_PUBLIC_FILES = {"NOTICE.md", "TENSORFLOW-LICENSE.txt"}


def required_previews(root: Path) -> set[str]:
    presets = Path(root) / PRESETS_FILE
    if not presets.is_file():
        return set()
    return {f"wf_{preset}.webp" for preset in re.findall(r'id = "([a-z0-9_]+)"', presets.read_text())}


def source_offenders(root: Path) -> list[str]:
    root = Path(root)
    errors: list[str] = []
    sleep = root / SLEEP_DIR
    if sleep.is_dir():
        for path in sorted(sleep.rglob("*")):
            if not path.is_file():
                continue
            relative = path.relative_to(sleep).as_posix()
            if relative not in SLEEP_PUBLIC_FILES:
                errors.append(f"vendor sleep asset in public source: {path.relative_to(root)}")
    bundled = {path.name for path in (root / WATCHFACE_DIR).glob("drawable*/wf_*.webp")}
    for missing in sorted(required_previews(root) - bundled):
        errors.append(f"missing bundled watch-face preview in public source: {missing}")
    return errors


def apk_offenders(apk: Path, expected_previews: dict[str, str] | None = None) -> list[str]:
    errors: list[str] = []
    with zipfile.ZipFile(apk) as archive:
        names = archive.namelist()
        # AAPT2 shortens resource paths in release APKs; image content stays unchanged.
        bundled_hashes = {
            hashlib.sha256(archive.read(name)).hexdigest()
            for name in names if name.startswith("res/") and name.endswith(".webp")
        }
    for name in names:
        if name.endswith("/"):
            continue
        if name.startswith("assets/sleep/"):
            relative = name[len("assets/sleep/") :]
            if relative not in SLEEP_PUBLIC_FILES:
                errors.append(f"vendor sleep asset in APK: {name}")
    for name, digest in sorted((expected_previews or {}).items()):
        if digest not in bundled_hashes:
            errors.append(f"missing bundled watch-face preview in APK: {name}")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--root",
        type=Path,
        default=Path(__file__).resolve().parents[1],
        help="Repository root to scan (default: the checkout containing this script)",
    )
    parser.add_argument("--apk", type=Path, action="append", default=[], help="APK to scan")
    args = parser.parse_args()

    errors = source_offenders(args.root)
    previews = required_previews(args.root)
    paths = {path.name: path for path in (args.root / WATCHFACE_DIR).glob("drawable*/wf_*.webp")}
    expected_hashes = {
        name: hashlib.sha256(paths[name].read_bytes()).hexdigest()
        for name in previews if name in paths
    }
    for apk in args.apk:
        errors.extend(apk_offenders(apk, expected_hashes))
    if errors:
        for error in errors:
            print(f"ERROR: {error}", file=sys.stderr)
        return 1
    print(f"OK: {len(previews)} watch-face previews complete; no local-only sleep runtime assets")
    return 0


if __name__ == "__main__":
    sys.exit(main())
