import hashlib
import importlib.util
from pathlib import Path
import re
import tempfile
import unittest
import zipfile

SCRIPT = Path(__file__).resolve().parents[1] / "check_public_assets.py"
spec = importlib.util.spec_from_file_location("check_public_assets", SCRIPT)
check_public_assets = importlib.util.module_from_spec(spec)
spec.loader.exec_module(check_public_assets)


class PublicAssetsCheckTest(unittest.TestCase):
    def test_repository_bundles_a_distinct_preview_for_every_preset(self):
        root = SCRIPT.parents[1]
        presets = (root / check_public_assets.PRESETS_FILE).read_text()
        expected = {f"wf_{preset}.webp" for preset in re.findall(r'id = "([a-z0-9]+)"', presets)}
        bundled = {path.name for path in (root / "app/src/main/res/drawable-nodpi").glob("wf_*.webp")}

        self.assertEqual(43, len(expected))
        self.assertEqual(expected, bundled)
        digests = set()
        for name in expected:
            with self.subTest(preview=name):
                image = (root / "app/src/main/res/drawable-nodpi" / name).read_bytes()
                self.assertEqual(b"RIFF", image[:4])
                self.assertEqual(b"WEBP", image[8:12])
                digests.add(hashlib.sha256(image).hexdigest())
        self.assertEqual(len(expected), len(digests))

    def test_repository_source_is_clean(self):
        self.assertEqual([], check_public_assets.source_offenders(SCRIPT.parents[1]))

    def test_source_vendor_runtime_is_reported_but_notices_and_previews_are_allowed(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        root = Path(temporary.name)
        sleep = root / "app/src/main/assets/sleep"
        (sleep / "arm64-v8a").mkdir(parents=True)
        (sleep / "NOTICE.md").write_text("notice")
        (sleep / "TENSORFLOW-LICENSE.txt").write_text("license")
        (sleep / "engine.jar").write_bytes(b"synthetic runtime")
        (sleep / "manifest.json").write_text("{}")
        (sleep / "arm64-v8a/libmobilesleepjni.so").write_bytes(b"synthetic runtime")
        previews = root / "app/src/main/res/drawable-nodpi"
        previews.mkdir(parents=True)
        (previews / "wf_synthetic.webp").write_bytes(b"synthetic preview")

        errors = check_public_assets.source_offenders(root)

        self.assertEqual(3, len(errors))
        self.assertTrue(any("engine.jar" in error for error in errors))
        self.assertTrue(any("manifest.json" in error for error in errors))
        self.assertTrue(any("libmobilesleepjni.so" in error for error in errors))
        self.assertFalse(any("wf_synthetic.webp" in error for error in errors))
        self.assertFalse(any("NOTICE.md" in error for error in errors))

    def test_missing_source_preview_is_reported_and_qualified_resource_satisfies_it(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            presets = root / check_public_assets.PRESETS_FILE
            presets.parent.mkdir(parents=True)
            presets.write_text('WatchFacePreset(id = "synthetic")')

            errors = check_public_assets.source_offenders(root)

            self.assertEqual(["missing bundled watch-face preview in public source: wf_synthetic.webp"], errors)
            previews = root / "app/src/main/res/drawable-hdpi"
            previews.mkdir(parents=True)
            (previews / "wf_synthetic.webp").write_bytes(b"synthetic preview")
            self.assertEqual([], check_public_assets.source_offenders(root))

    def test_nested_sleep_files_do_not_inherit_notice_allowlist(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        root = Path(temporary.name)
        nested = root / "app/src/main/assets/sleep/nested"
        nested.mkdir(parents=True)
        (nested / "NOTICE.md").write_bytes(b"synthetic runtime")

        errors = check_public_assets.source_offenders(root)

        self.assertEqual(1, len(errors))
        self.assertIn("nested/NOTICE.md", errors[0])

    def test_apk_vendor_runtime_is_reported_but_previews_are_allowed(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        apk = Path(temporary.name) / "app.apk"
        with zipfile.ZipFile(apk, "w") as archive:
            archive.writestr("assets/sleep/NOTICE.md", "notice")
            archive.writestr("assets/sleep/TENSORFLOW-LICENSE.txt", "license")
            archive.writestr("assets/sleep/engine.jar", b"synthetic runtime")
            archive.writestr("assets/sleep/arm64-v8a/libmobilesleepjni.so", b"synthetic runtime")
            archive.writestr("res/drawable-nodpi-v4/wf_synthetic.webp", b"synthetic preview")

        errors = check_public_assets.apk_offenders(
            apk, {"wf_synthetic.webp": hashlib.sha256(b"synthetic preview").hexdigest()}
        )

        self.assertEqual(2, len(errors))
        self.assertTrue(any("engine.jar" in error for error in errors))
        self.assertTrue(any("libmobilesleepjni.so" in error for error in errors))

    def test_apk_missing_preview_is_reported(self):
        with tempfile.TemporaryDirectory() as tmp:
            apk = Path(tmp) / "app.apk"
            with zipfile.ZipFile(apk, "w") as archive:
                archive.writestr("res/drawable-nodpi-v4/wf_synthetic.webp", b"synthetic preview")
            errors = check_public_assets.apk_offenders(apk, {
                "wf_synthetic.webp": hashlib.sha256(b"synthetic preview").hexdigest(),
                "wf_other.webp": hashlib.sha256(b"other preview").hexdigest(),
            })

            self.assertEqual(["missing bundled watch-face preview in APK: wf_other.webp"], errors)

    def test_optimized_apk_paths_preserve_previews_by_content(self):
        with tempfile.TemporaryDirectory() as tmp:
            apk = Path(tmp) / "app.apk"
            with zipfile.ZipFile(apk, "w") as archive:
                archive.writestr("res/a.webp", b"synthetic preview")
            errors = check_public_assets.apk_offenders(
                apk, {"wf_synthetic.webp": hashlib.sha256(b"synthetic preview").hexdigest()}
            )

            self.assertEqual([], errors)

    def test_clean_apk_passes(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        apk = Path(temporary.name) / "app.apk"
        with zipfile.ZipFile(apk, "w") as archive:
            archive.writestr("assets/sleep/NOTICE.md", "notice")
            archive.writestr("classes.dex", b"dex")

        self.assertEqual([], check_public_assets.apk_offenders(apk))


if __name__ == "__main__":
    unittest.main()
