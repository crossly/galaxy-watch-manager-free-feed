import hashlib
import importlib.util
import os
from pathlib import Path
import subprocess
import tarfile
import tempfile
import unittest
from unittest.mock import patch
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location("package_source", ROOT / "scripts/package-source.py")
source = importlib.util.module_from_spec(spec)
spec.loader.exec_module(source)


class PackageSourceTests(unittest.TestCase):
    def repository(self, folder):
        repository = folder / "source"
        repository.mkdir()
        for name in ("LICENSE", "THIRD-PARTY.md", "CONTRIBUTING.md", "gradlew", "app/build.gradle"):
            target = repository / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text("synthetic source\n")
        (repository / "version.properties").write_text("VERSION_NAME=0.0.35.004\nVERSION_CODE=35004\n")
        self.git(repository, "init")
        self.git(repository, "add", ".")
        self.git(repository, "commit", "-m", "synthetic release")
        return repository

    def git(self, repository, *args):
        return subprocess.check_output(
            ["git", *args], cwd=repository, stderr=subprocess.DEVNULL,
            env={**os.environ, "GIT_AUTHOR_NAME": "Test", "GIT_AUTHOR_EMAIL": "test@example.invalid",
                 "GIT_COMMITTER_NAME": "Test", "GIT_COMMITTER_EMAIL": "test@example.invalid"},
        )

    def test_packages_exact_committed_tree_with_repeatable_checksum(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            repository = self.repository(folder)
            (repository / "LICENSE").write_text("uncommitted change")
            with patch.object(source, "ROOT", repository):
                archive = source.package(folder / "out")
                original = archive.read_bytes()
                self.assertEqual(archive, source.package(folder / "out"))
                self.assertEqual(original, archive.read_bytes())
            checksum = archive.with_suffix(".gz.sha256").read_text().split()[0]
            self.assertEqual(hashlib.sha256(original).hexdigest(), checksum)
            with tarfile.open(archive) as packed:
                prefix = "galaxy-watch-manager-free-0.0.35.004/"
                self.assertEqual(b"synthetic source\n", packed.extractfile(prefix + "LICENSE").read())
                self.assertIn(prefix + "app/build.gradle", packed.getnames())
                self.assertFalse(any(".git/" in name for name in packed.getnames()))

    def test_rejects_vendor_assets_and_private_material(self):
        for path in ("app/src/main/assets/sleep/engine.jar", "app/src/main/assets/sleep/manifest.json",
                     "app/src/main/assets/sleep/arm64-v8a/libmobilesleepjni.so",
                     "private/evidence.json", "release.jks", "local.properties"):
            with self.subTest(path=path), tempfile.TemporaryDirectory() as tmp:
                folder = Path(tmp)
                repository = self.repository(folder)
                target = repository / path
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(b"synthetic local material")
                self.git(repository, "add", ".")
                self.git(repository, "commit", "-m", "local-only fixture")
                with patch.object(source, "ROOT", repository), self.assertRaisesRegex(SystemExit, "local-only"):
                    source.package(folder / "out")

    def test_keeps_bundled_watchface_previews_in_source_and_allows_them_in_apk(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            repository = self.repository(folder)
            path = "app/src/main/res/drawable-nodpi/wf_synthetic.webp"
            image = repository / path
            image.parent.mkdir(parents=True)
            image.write_bytes(b"synthetic preview")
            self.git(repository, "add", path)
            self.git(repository, "commit", "-m", "bundled preview fixture")
            apk = folder / "synthetic.apk"
            with ZipFile(apk, "w") as packed:
                packed.writestr("res/drawable-nodpi-v4/wf_synthetic.webp", b"synthetic preview")
            with patch.object(source, "ROOT", repository):
                archive = source.package(folder / "out", apk=apk)
            with tarfile.open(archive) as packed:
                prefix = "galaxy-watch-manager-free-0.0.35.004/"
                self.assertEqual(b"synthetic preview", packed.extractfile(prefix + path).read())

    def test_checks_actual_apk_for_vendor_assets(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            repository = self.repository(folder)
            apk = folder / "synthetic.apk"
            with ZipFile(apk, "w") as packed:
                packed.writestr("assets/sleep/engine.jar", b"synthetic runtime")
            with patch.object(source, "ROOT", repository), self.assertRaisesRegex(SystemExit, "Public APK"):
                source.package(folder / "out", apk=apk)

    def test_requires_build_and_license_materials(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            repository = self.repository(folder)
            self.git(repository, "rm", "gradlew")
            self.git(repository, "commit", "-m", "missing build fixture")
            with patch.object(source, "ROOT", repository), self.assertRaisesRegex(SystemExit, "missing gradlew"):
                source.package(folder / "out")


if __name__ == "__main__":
    unittest.main()
