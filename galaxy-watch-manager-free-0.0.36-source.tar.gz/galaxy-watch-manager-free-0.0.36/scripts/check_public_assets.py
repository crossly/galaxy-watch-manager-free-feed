#!/usr/bin/env python3
"""Verify bundled sleep runtime integrity and watch-face preview coverage."""
from __future__ import annotations

import argparse
import hashlib
import io
import json
from pathlib import Path
import re
import sys
import zipfile

SLEEP_DIR = Path("app/src/main/assets/sleep")
WATCHFACE_DIR = Path("app/src/main/res")
PRESETS_FILE = Path("app/src/main/java/dev/ricky/galaxywatchmanagerfree/feature/WatchFacePreset.kt")
SLEEP_SOURCE_SHA256 = "88b0359eaaea6061466df4fdb15754ca8408caf68e1eb796ef58b24374efe312"
SLEEP_RUNTIME_FILES = {
    "engine.jar",
    "arm64-v8a/libmobilesleepjni.so", "arm64-v8a/libtensorflowlite_jni.so",
    "armeabi-v7a/libmobilesleepjni.so", "armeabi-v7a/libtensorflowlite_jni.so",
}
SLEEP_FILES = SLEEP_RUNTIME_FILES | {"manifest.json", "NOTICE.md", "TENSORFLOW-LICENSE.txt"}
SLEEP_ENGINE_FILES = {
    "classes.dex", "assets/quantiles_db6_vertical.txt",
    "assets/tcn_ibi_t2v_stages_sum_214_l8_db6.tflite",
}


def required_previews(root: Path) -> set[str]:
    presets = Path(root) / PRESETS_FILE
    if not presets.is_file():
        return set()
    return {f"wf_{preset}.webp" for preset in re.findall(r'id = "([a-z0-9_]+)"', presets.read_text())}


def sleep_offenders(contents: dict[str, bytes], location: str) -> list[str]:
    errors: list[str] = []
    for name in sorted(SLEEP_FILES - contents.keys()):
        errors.append(f"missing bundled sleep asset in {location}: {name}")
    for name in sorted(contents.keys() - SLEEP_FILES):
        errors.append(f"unexpected bundled sleep asset in {location}: {name}")
    for name in sorted(SLEEP_FILES & contents.keys()):
        if not contents[name]:
            errors.append(f"empty bundled sleep asset in {location}: {name}")
    if "manifest.json" in contents:
        try:
            manifest = json.loads(contents["manifest.json"])
            if manifest["version"] != 1 or manifest["source_apk_sha256"] != SLEEP_SOURCE_SHA256:
                raise ValueError("unsupported version or source APK")
            digests = manifest["files"]
            if not isinstance(digests, dict) or set(digests) != SLEEP_RUNTIME_FILES:
                raise ValueError("runtime file list is incomplete or unexpected")
            for name, digest in sorted(digests.items()):
                if not isinstance(digest, str) or not re.fullmatch(r"[0-9a-f]{64}", digest):
                    raise ValueError(f"invalid SHA-256 for {name}")
                if name in contents and hashlib.sha256(contents[name]).hexdigest() != digest:
                    errors.append(f"sleep asset SHA-256 mismatch in {location}: {name}")
        except (ValueError, KeyError, TypeError) as error:
            errors.append(f"invalid sleep manifest in {location}: {error}")
    if "engine.jar" in contents:
        try:
            with zipfile.ZipFile(io.BytesIO(contents["engine.jar"])) as engine:
                for name in sorted(SLEEP_ENGINE_FILES):
                    if name not in engine.namelist() or engine.getinfo(name).file_size == 0:
                        errors.append(f"missing sleep engine payload in {location}: {name}")
        except zipfile.BadZipFile:
            errors.append(f"invalid sleep engine archive in {location}")
    return errors


def source_offenders(root: Path) -> list[str]:
    root = Path(root)
    sleep = root / SLEEP_DIR
    contents = {
        path.relative_to(sleep).as_posix(): path.read_bytes()
        for path in sorted(sleep.rglob("*")) if path.is_file()
    }
    errors = sleep_offenders(contents, "public source")
    bundled = {path.name for path in (root / WATCHFACE_DIR).glob("drawable*/wf_*.webp")}
    for missing in sorted(required_previews(root) - bundled):
        errors.append(f"missing bundled watch-face preview in public source: {missing}")
    return errors


def apk_offenders(
    apk: Path,
    expected_previews: dict[str, str] | None = None,
    expected_sleep: dict[str, str] | None = None,
) -> list[str]:
    with zipfile.ZipFile(apk) as archive:
        names = archive.namelist()
        contents = {
            name[len("assets/sleep/"):]: archive.read(name)
            for name in names if name.startswith("assets/sleep/") and not name.endswith("/")
        }
        # AAPT2 shortens resource paths in release APKs; image content stays unchanged.
        bundled_hashes = {
            hashlib.sha256(archive.read(name)).hexdigest()
            for name in names if name.startswith("res/") and name.endswith(".webp")
        }
    errors = sleep_offenders(contents, "APK")
    for name, digest in sorted((expected_sleep or {}).items()):
        if name in contents and hashlib.sha256(contents[name]).hexdigest() != digest:
            errors.append(f"bundled sleep asset differs from public source: {name}")
    for name, digest in sorted((expected_previews or {}).items()):
        if digest not in bundled_hashes:
            errors.append(f"missing bundled watch-face preview in APK: {name}")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--root", type=Path, default=Path(__file__).resolve().parents[1],
        help="Repository root to scan (default: the checkout containing this script)",
    )
    parser.add_argument("--apk", type=Path, action="append", default=[], help="APK to scan")
    args = parser.parse_args()

    errors = source_offenders(args.root)
    previews = required_previews(args.root)
    paths = {path.name: path for path in (args.root / WATCHFACE_DIR).glob("drawable*/wf_*.webp")}
    expected_hashes = {
        name: hashlib.sha256(paths[name].read_bytes()).hexdigest()
        for name in previews if name in paths
    }
    expected_sleep = {
        name: hashlib.sha256((args.root / SLEEP_DIR / name).read_bytes()).hexdigest()
        for name in SLEEP_FILES if (args.root / SLEEP_DIR / name).is_file()
    }
    for apk in args.apk:
        errors.extend(apk_offenders(apk, expected_hashes, expected_sleep))
    if errors:
        for error in errors:
            print(f"ERROR: {error}", file=sys.stderr)
        return 1
    print(f"OK: {len(previews)} watch-face previews complete; bundled sleep runtime and model verified")
    return 0


if __name__ == "__main__":
    sys.exit(main())
