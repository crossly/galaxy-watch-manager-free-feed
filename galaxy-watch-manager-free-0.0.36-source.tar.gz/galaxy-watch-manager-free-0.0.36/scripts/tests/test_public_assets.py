import hashlib
import importlib.util
import io
import json
from pathlib import Path
import re
import tempfile
import unittest
import zipfile

SCRIPT = Path(__file__).resolve().parents[1] / "check_public_assets.py"
spec = importlib.util.spec_from_file_location("check_public_assets", SCRIPT)
check_public_assets = importlib.util.module_from_spec(spec)
spec.loader.exec_module(check_public_assets)


class PublicAssetsCheckTest(unittest.TestCase):
    def synthetic_sleep(self, omitted_payload=None):
        engine_bytes = io.BytesIO()
        with zipfile.ZipFile(engine_bytes, "w") as engine:
            for name in sorted(check_public_assets.SLEEP_ENGINE_FILES):
                if name != omitted_payload:
                    engine.writestr(name, b"synthetic model or code")
        contents = {name: b"synthetic runtime" for name in check_public_assets.SLEEP_RUNTIME_FILES}
        contents["engine.jar"] = engine_bytes.getvalue()
        contents["manifest.json"] = json.dumps({
            "version": 1,
            "source_apk_sha256": check_public_assets.SLEEP_SOURCE_SHA256,
            "files": {name: hashlib.sha256(data).hexdigest() for name, data in contents.items()},
        }).encode()
        contents["NOTICE.md"] = b"synthetic provenance"
        contents["TENSORFLOW-LICENSE.txt"] = b"synthetic license"
        return contents

    def write_source(self, root, contents):
        sleep = root / check_public_assets.SLEEP_DIR
        for name, data in contents.items():
            target = sleep / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)

    def write_apk(self, apk, contents, previews=None):
        with zipfile.ZipFile(apk, "w") as archive:
            for name, data in contents.items():
                archive.writestr("assets/sleep/" + name, data)
            for name, data in (previews or {}).items():
                archive.writestr(name, data)

    def test_repository_bundles_a_distinct_preview_for_every_preset(self):
        root = SCRIPT.parents[1]
        presets = (root / check_public_assets.PRESETS_FILE).read_text()
        expected = {f"wf_{preset}.webp" for preset in re.findall(r'id = "([a-z0-9]+)"', presets)}
        bundled = {path.name for path in (root / "app/src/main/res/drawable-nodpi").glob("wf_*.webp")}
        self.assertEqual(43, len(expected))
        self.assertEqual(expected, bundled)
        digests = set()
        for name in expected:
            with self.subTest(preview=name):
                image = (root / "app/src/main/res/drawable-nodpi" / name).read_bytes()
                self.assertEqual(b"RIFF", image[:4])
                self.assertEqual(b"WEBP", image[8:12])
                digests.add(hashlib.sha256(image).hexdigest())
        self.assertEqual(len(expected), len(digests))

    def test_repository_bundles_complete_sleep_runtime(self):
        sleep = SCRIPT.parents[1] / check_public_assets.SLEEP_DIR
        required = {
            "engine.jar", "manifest.json", "NOTICE.md", "TENSORFLOW-LICENSE.txt",
            "arm64-v8a/libmobilesleepjni.so", "arm64-v8a/libtensorflowlite_jni.so",
            "armeabi-v7a/libmobilesleepjni.so", "armeabi-v7a/libtensorflowlite_jni.so",
        }
        self.assertEqual(required, {p.relative_to(sleep).as_posix() for p in sleep.rglob("*") if p.is_file()})
        with zipfile.ZipFile(sleep / "engine.jar") as engine:
            self.assertEqual({
                "classes.dex", "assets/quantiles_db6_vertical.txt",
                "assets/tcn_ibi_t2v_stages_sum_214_l8_db6.tflite",
            }, set(engine.namelist()))

    def test_repository_source_is_complete_and_matches_manifest(self):
        self.assertEqual([], check_public_assets.source_offenders(SCRIPT.parents[1]))

    def test_missing_source_runtime_is_reported(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            contents = self.synthetic_sleep()
            del contents["arm64-v8a/libmobilesleepjni.so"]
            self.write_source(root, contents)
            self.assertEqual([
                "missing bundled sleep asset in public source: arm64-v8a/libmobilesleepjni.so",
            ], check_public_assets.source_offenders(root))

    def test_source_hash_mismatch_is_reported(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            contents = self.synthetic_sleep()
            contents["armeabi-v7a/libtensorflowlite_jni.so"] = b"changed runtime"
            self.write_source(root, contents)
            self.assertEqual([
                "sleep asset SHA-256 mismatch in public source: armeabi-v7a/libtensorflowlite_jni.so",
            ], check_public_assets.source_offenders(root))

    def test_nested_sleep_files_do_not_inherit_notice_allowlist(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            contents = self.synthetic_sleep()
            contents["nested/NOTICE.md"] = b"synthetic extra file"
            self.write_source(root, contents)
            self.assertEqual([
                "unexpected bundled sleep asset in public source: nested/NOTICE.md",
            ], check_public_assets.source_offenders(root))

    def test_missing_source_preview_is_reported_and_qualified_resource_satisfies_it(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            self.write_source(root, self.synthetic_sleep())
            presets = root / check_public_assets.PRESETS_FILE
            presets.parent.mkdir(parents=True)
            presets.write_text('WatchFacePreset(id = "synthetic")')
            self.assertEqual([
                "missing bundled watch-face preview in public source: wf_synthetic.webp",
            ], check_public_assets.source_offenders(root))
            previews = root / "app/src/main/res/drawable-hdpi"
            previews.mkdir(parents=True)
            (previews / "wf_synthetic.webp").write_bytes(b"synthetic preview")
            self.assertEqual([], check_public_assets.source_offenders(root))

    def test_empty_sleep_assets_are_rejected(self):
        contents = self.synthetic_sleep()
        contents["NOTICE.md"] = b""
        self.assertEqual([
            "empty bundled sleep asset in APK: NOTICE.md",
        ], check_public_assets.sleep_offenders(contents, "APK"))

    def test_invalid_manifest_and_missing_runtime_digest_are_rejected(self):
        valid = json.loads(self.synthetic_sleep()["manifest.json"])
        missing_file = {**valid, "files": {"engine.jar": "0" * 64}}
        invalid_source = {**valid, "source_apk_sha256": "0" * 64}
        invalid_digest = {**valid, "files": {**valid["files"], "engine.jar": "invalid"}}
        for manifest in (b"not JSON", b"null", b"[]", json.dumps(missing_file).encode(),
                         json.dumps(invalid_source).encode(), json.dumps(invalid_digest).encode()):
            with self.subTest(manifest=manifest):
                contents = self.synthetic_sleep()
                contents["manifest.json"] = manifest
                errors = check_public_assets.sleep_offenders(contents, "APK")
                self.assertEqual(1, len(errors))
                self.assertIn("invalid sleep manifest", errors[0])

    def test_engine_requires_embedded_model_quantiles_and_code(self):
        for name in sorted(check_public_assets.SLEEP_ENGINE_FILES):
            with self.subTest(payload=name):
                self.assertEqual([
                    f"missing sleep engine payload in APK: {name}",
                ], check_public_assets.sleep_offenders(self.synthetic_sleep(omitted_payload=name), "APK"))

    def test_invalid_engine_archive_is_reported(self):
        contents = self.synthetic_sleep()
        contents["engine.jar"] = b"invalid jar"
        errors = check_public_assets.sleep_offenders(contents, "APK")
        self.assertIn("invalid sleep engine archive in APK", errors)

    def test_apk_requires_both_abi_runtime_sets(self):
        with tempfile.TemporaryDirectory() as tmp:
            apk = Path(tmp) / "app.apk"
            contents = self.synthetic_sleep()
            del contents["armeabi-v7a/libtensorflowlite_jni.so"]
            self.write_apk(apk, contents)
            self.assertEqual([
                "missing bundled sleep asset in APK: armeabi-v7a/libtensorflowlite_jni.so",
            ], check_public_assets.apk_offenders(apk))

    def test_apk_hash_mismatch_is_reported(self):
        with tempfile.TemporaryDirectory() as tmp:
            apk = Path(tmp) / "app.apk"
            contents = self.synthetic_sleep()
            contents["arm64-v8a/libmobilesleepjni.so"] = b"changed runtime"
            self.write_apk(apk, contents)
            self.assertEqual([
                "sleep asset SHA-256 mismatch in APK: arm64-v8a/libmobilesleepjni.so",
            ], check_public_assets.apk_offenders(apk))

    def test_apk_must_match_source_even_when_its_manifest_is_consistent(self):
        with tempfile.TemporaryDirectory() as tmp:
            apk = Path(tmp) / "app.apk"
            contents = self.synthetic_sleep()
            self.write_apk(apk, contents)
            expected = {name: hashlib.sha256(data).hexdigest() for name, data in contents.items()}
            expected["engine.jar"] = "0" * 64
            self.assertEqual([
                "bundled sleep asset differs from public source: engine.jar",
            ], check_public_assets.apk_offenders(apk, expected_sleep=expected))

    def test_apk_missing_preview_is_reported(self):
        with tempfile.TemporaryDirectory() as tmp:
            apk = Path(tmp) / "app.apk"
            self.write_apk(apk, self.synthetic_sleep(), {"res/a.webp": b"synthetic preview"})
            self.assertEqual([
                "missing bundled watch-face preview in APK: wf_other.webp",
            ], check_public_assets.apk_offenders(apk, {
                "wf_synthetic.webp": hashlib.sha256(b"synthetic preview").hexdigest(),
                "wf_other.webp": hashlib.sha256(b"other preview").hexdigest(),
            }))

    def test_optimized_apk_paths_preserve_previews_by_content(self):
        with tempfile.TemporaryDirectory() as tmp:
            apk = Path(tmp) / "app.apk"
            self.write_apk(apk, self.synthetic_sleep(), {"res/a.webp": b"synthetic preview"})
            self.assertEqual([], check_public_assets.apk_offenders(apk, {
                "wf_synthetic.webp": hashlib.sha256(b"synthetic preview").hexdigest(),
            }))

    def test_apk_without_runtime_fails(self):
        with tempfile.TemporaryDirectory() as tmp:
            apk = Path(tmp) / "app.apk"
            self.write_apk(apk, {})
            self.assertEqual(8, len(check_public_assets.apk_offenders(apk)))

    def test_complete_apk_passes(self):
        with tempfile.TemporaryDirectory() as tmp:
            apk = Path(tmp) / "app.apk"
            self.write_apk(apk, self.synthetic_sleep())
            self.assertEqual([], check_public_assets.apk_offenders(apk))


if __name__ == "__main__":
    unittest.main()
