package dev.ricky.galaxywatchmanagerfree.wcs

import dev.ricky.galaxywatchmanagerfree.feature.NotificationIdentity

internal class BridgerNotificationSender(private val sendFrame: (ByteArray) -> Boolean) {
    @Synchronized
    fun send(
        phoneNode: String,
        identity: NotificationIdentity,
        title: String,
        text: String,
        appName: String?,
        whenMillis: Long,
        seqId: Long,
        appIcon: ByteArray?,
    ): Boolean {
        if (phoneNode.isBlank()) return false
        val icon = appIcon?.takeIf { it.isNotEmpty() && it.size <= MAX_ICON_BYTES }
        val digest = icon?.let { if (sendIcon(it)) WcsFrame.messageDigest(it) else null }
        val data =
            linkedMapOf<String, Any>(
                "R_c,0" to 1L,
                "R_c" to 1L,
                "title_raw" to title,
                "text_raw" to text,
                "priority" to 1,
                "notification_flags" to 0,
                "user_id" to identity.userId,
                "when" to whenMillis,
                "show_when" to true,
                "defaults" to 2,
                "has_sound" to true,
                "app_name" to (appName ?: identity.packageName),
                "from" to "phone",
            )
        if (digest != null) data["app_icon"] = DataMapEncoder.AssetReference(0)
        return sendFrame(
            WcsFrame.wearPathFrame(
                path = "wear://$phoneNode/${identity.bridgerPath(phoneNode)}",
                dataItems = listOf(DataMapEncoder.encode(data)),
                senderPkg = SENDER_PACKAGE,
                nodeId = phoneNode,
                seqId = seqId,
                assets = if (digest == null) emptyMap() else mapOf("0" to digest),
            )
        )
    }

    private fun sendIcon(bytes: ByteArray): Boolean {
        val target = Proto.string(1, SENDER_PACKAGE) + Proto.string(2, WcsPaths.SIGNATURE_PLUGIN)
        val asset =
            Proto.string(1, WcsFrame.messageDigest(bytes)) +
                Proto.bytes(2, bytes) +
                Proto.bytes(3, Proto.bytes(1, target))
        val inner = Proto.bytes(4, asset)
        val digest = WcsFrame.messageDigest(inner)
        val count = (inner.size + 1023) / 1024
        // Keep inline assets below the transport MTU using the official Envelope piece numbering.
        for (index in 0 until count) {
            val piece = inner.copyOfRange(index * 1024, minOf(inner.size, (index + 1) * 1024))
            if (
                !sendFrame(
                    WcsFrame.envelope(piece, digest, type = 7, f3 = index + 1L, f4 = count.toLong())
                )
            )
                return false
        }
        return true
    }

    companion object {
        const val MAX_ICON_BYTES = 64 * 1024
        private const val SENDER_PACKAGE = "com.samsung.android.wcs.extension"
    }
}
