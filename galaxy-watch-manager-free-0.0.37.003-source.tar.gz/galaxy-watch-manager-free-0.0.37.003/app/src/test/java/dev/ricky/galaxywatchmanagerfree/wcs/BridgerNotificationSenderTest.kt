package dev.ricky.galaxywatchmanagerfree.wcs

import dev.ricky.galaxywatchmanagerfree.feature.NotificationIdentity
import org.junit.Assert.*
import org.junit.Test

class BridgerNotificationSenderTest {
    private val identity = NotificationIdentity("test.app.one", 7, "synthetic", 0, 10001)
    private val icon =
        java.util.Base64.getDecoder()
            .decode(
                "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRZkAAAAASUVORK5CYII="
            )

    private fun send(
        frames: MutableList<ByteArray>,
        bytes: ByteArray? = icon,
        id: NotificationIdentity = identity,
        phoneNode: String = "c0ffee12",
        accept: (ByteArray) -> Boolean = { true },
    ): Boolean =
        BridgerNotificationSender { frame ->
                frames += frame
                accept(frame)
            }
            .send(
                phoneNode,
                id,
                "Synthetic title",
                "Synthetic body",
                "Synthetic app",
                1234L,
                42L,
                bytes,
            )

    private fun inner(frame: ByteArray): Proto.Message =
        Proto.parse(Proto.parse(frame.copyOfRange(4, frame.size)).raw(1)!!)

    private fun data(frames: List<ByteArray>): WcsFrame.Incoming.WearPath =
        WcsFrame.decode(frames.last().let { it.copyOfRange(4, it.size) })
            as WcsFrame.Incoming.WearPath

    @Test
    fun `icon bytes and indexed asset reference resolve to the same digest`() {
        val frames = mutableListOf<ByteArray>()
        assertTrue(send(frames))
        val asset = inner(frames.first()).nested(4)!!
        val digest = WcsFrame.messageDigest(icon)
        assertEquals(digest, asset.text(1))
        assertArrayEquals(icon, asset.raw(2))
        val target = asset.nested(3)!!.nested(1)!!
        assertEquals("com.samsung.android.wcs.extension", target.text(1))
        assertEquals(WcsPaths.SIGNATURE_PLUGIN, target.text(2))
        val reference = inner(frames.last()).nested(9)!!.nested(8)!!
        assertEquals("0", reference.text(1))
        assertEquals(digest, reference.nested(2)!!.text(4))
        assertEquals(4L, reference.num(3))
        val notification = data(frames)
        assertEquals(0, notification.dataMap["app_icon"])
        val entry =
            Proto.parse(notification.dataItems.single())
                .fields[1]!!
                .map { Proto.parse(it as ByteArray) }
                .single { it.text(1) == "app_icon" }
        assertEquals(13L, entry.nested(2)!!.num(1))
        assertEquals(0L, entry.nested(2)!!.nested(2)!!.num(13))
        assertEquals("Synthetic title", notification.dataMap["title_raw"])
        assertEquals("Synthetic body", notification.dataMap["text_raw"])
        assertEquals("Synthetic app", notification.dataMap["app_name"])
        assertEquals(1234L, notification.dataMap["when"])
        assertEquals("wear://c0ffee12/${identity.bridgerPath("c0ffee12")}", notification.path)
    }

    @Test
    fun `fragmented inline asset reassembles persists and acknowledges before notification`() {
        val bytes = ByteArray(4097) { (it * 31).toByte() }
        val frames = mutableListOf<ByteArray>()
        assertTrue(send(frames, bytes))
        assertTrue(frames.size > 2)
        val assembler = WcsPieceAssembler()
        val stored = mutableMapOf<String, ByteArray>()
        val acknowledgements = mutableListOf<ByteArray>()
        val receiver =
            WearAssetReceiver(
                persist = { digest, content ->
                    stored[digest] = content
                    true
                },
                contains = stored::containsKey,
                send = {
                    acknowledgements += it
                    true
                },
            )
        frames.dropLast(1).forEachIndexed { index, frame ->
            assertEquals(frame.size - 4, LengthPrefix.readLength(frame))
            val envelope = Proto.parse(frame.copyOfRange(4, frame.size))
            assertEquals(7L, envelope.num(5))
            assertEquals(index + 1L, envelope.num(3))
            assertEquals(frames.size - 1L, envelope.num(4))
            assertTrue(envelope.raw(1)!!.size <= 1024)
            assembler.accept(frame.copyOfRange(4, frame.size))?.let {
                assertTrue(receiver.receive(Proto.parse(it).raw(1)!!))
            }
        }
        val digest = WcsFrame.messageDigest(bytes)
        assertArrayEquals(bytes, stored[digest])
        assertEquals(digest, Proto.parse(acknowledgements.single()).nested(5)!!.text(1))
        assertEquals(digest, inner(frames.last()).nested(9)!!.nested(8)!!.nested(2)!!.text(4))
    }

    @Test
    fun `different applications and updated icons carry their own assets`() {
        val first = mutableListOf<ByteArray>()
        val second = mutableListOf<ByteArray>()
        val updated = mutableListOf<ByteArray>()
        val otherIcon = byteArrayOf(1, 2, 3)
        assertTrue(send(first))
        assertTrue(send(second, otherIcon, identity.copy(packageName = "test.app.two")))
        assertTrue(send(updated, otherIcon))
        assertNotEquals(data(first).path, data(second).path)
        assertEquals(data(first).path, data(updated).path)
        assertNotEquals(
            inner(first.first()).nested(4)!!.text(1),
            inner(second.first()).nested(4)!!.text(1),
        )
        assertEquals(
            inner(second.first()).nested(4)!!.text(1),
            inner(updated.first()).nested(4)!!.text(1),
        )
    }

    @Test
    fun `missing empty or oversized icons keep text without dangling references`() {
        for (bytes in listOf(null, byteArrayOf(), ByteArray(64 * 1024 + 1))) {
            val frames = mutableListOf<ByteArray>()
            assertTrue(send(frames, bytes))
            assertEquals(1, frames.size)
            assertFalse(data(frames).dataMap.containsKey("app_icon"))
            assertFalse(inner(frames.single()).nested(9)!!.has(8))
            assertEquals("Synthetic body", data(frames).dataMap["text_raw"])
        }
    }

    @Test
    fun `rejected asset piece falls back to text without marking notification failed`() {
        val frames = mutableListOf<ByteArray>()
        assertTrue(send(frames, ByteArray(4097)) { frames.size != 2 })
        assertEquals(3, frames.size)
        assertFalse(data(frames).dataMap.containsKey("app_icon"))
        assertFalse(inner(frames.last()).nested(9)!!.has(8))
    }

    @Test
    fun `notification queue rejection is returned to caller`() {
        val frames = mutableListOf<ByteArray>()
        assertFalse(send(frames) { !inner(it).has(9) })
    }

    @Test
    fun `missing phone identity sends no frame`() {
        val frames = mutableListOf<ByteArray>()
        assertFalse(send(frames, phoneNode = ""))
        assertTrue(frames.isEmpty())
    }

    @Test
    fun `new connection resends asset rather than trusting previous peer state`() {
        val first = mutableListOf<ByteArray>()
        val reconnected = mutableListOf<ByteArray>()
        assertTrue(send(first))
        assertTrue(send(reconnected))
        assertTrue(inner(first.first()).has(4))
        assertTrue(inner(reconnected.first()).has(4))
    }
}
