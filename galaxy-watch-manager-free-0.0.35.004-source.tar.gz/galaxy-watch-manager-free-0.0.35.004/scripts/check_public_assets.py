#!/usr/bin/env python3
"""Reject vendor-derived sleep and watch-face assets in the public source tree or an APK."""
from __future__ import annotations

import argparse
from pathlib import Path
import sys
import zipfile

SLEEP_DIR = Path("app/src/main/assets/sleep")
WATCHFACE_DIR = Path("app/src/main/res")
SLEEP_PUBLIC_FILES = {"NOTICE.md", "TENSORFLOW-LICENSE.txt"}


def source_offenders(root: Path) -> list[str]:
    root = Path(root)
    errors: list[str] = []
    sleep = root / SLEEP_DIR
    if sleep.is_dir():
        for path in sorted(sleep.rglob("*")):
            if not path.is_file():
                continue
            relative = path.relative_to(sleep).as_posix()
            if relative not in SLEEP_PUBLIC_FILES:
                errors.append(f"vendor sleep asset in public source: {path.relative_to(root)}")
    previews = root / WATCHFACE_DIR
    if previews.is_dir():
        for path in sorted(previews.glob("drawable*/wf_*.webp")):
            errors.append(f"vendor watch-face preview in public source: {path.relative_to(root)}")
    return errors


def apk_offenders(apk: Path) -> list[str]:
    errors: list[str] = []
    with zipfile.ZipFile(apk) as archive:
        names = archive.namelist()
    for name in names:
        if name.endswith("/"):
            continue
        if name.startswith("assets/sleep/"):
            relative = name[len("assets/sleep/") :]
            if relative not in SLEEP_PUBLIC_FILES:
                errors.append(f"vendor sleep asset in APK: {name}")
        if name.startswith("res/") and name.endswith(".webp"):
            errors.append(f"vendor watch-face preview in APK: {name}")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--root",
        type=Path,
        default=Path(__file__).resolve().parents[1],
        help="Repository root to scan (default: the checkout containing this script)",
    )
    parser.add_argument("--apk", type=Path, action="append", default=[], help="APK to scan")
    args = parser.parse_args()

    errors = source_offenders(args.root)
    for apk in args.apk:
        errors.extend(apk_offenders(apk))
    if errors:
        for error in errors:
            print(f"ERROR: {error}", file=sys.stderr)
        return 1
    print("OK: no vendor-derived sleep or watch-face assets found")
    return 0


if __name__ == "__main__":
    sys.exit(main())
