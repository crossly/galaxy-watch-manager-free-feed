#!/usr/bin/env bash
# Run from any directory: ./scripts/release.sh [--nightly|--initial|--current|--republish]
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ "$#" -gt 1 || ( "$#" -eq 1 && "$1" != "--nightly" && "$1" != "--initial" && "$1" != "--current" && "$1" != "--republish" ) ]]; then
  echo "Usage: $0 [--nightly|--initial|--current|--republish]" >&2
  exit 1
fi
if [[ -n "$(git status --porcelain)" ]]; then
  echo "Commit or stash changes before releasing." >&2
  exit 1
fi
if [[ "$(git branch --show-current)" != "main" ]]; then
  echo "Release from main only." >&2
  exit 1
fi
git fetch origin main --tags
if [[ "$(git rev-parse HEAD)" != "$(git rev-parse origin/main)" ]]; then
  echo "Local main must match origin/main before releasing." >&2
  exit 1
fi
current="$(python3 scripts/version.py show)"
channel=stable
if [[ "${1:-}" == "--nightly" ]]; then channel=nightly; fi
if [[ "${1:-}" == "--initial" ]]; then
  [[ "$current" == "0.0.1" ]] || { echo "--initial requires version 0.0.1" >&2; exit 1; }
  next="$current"
elif [[ "${1:-}" == "--current" || "${1:-}" == "--republish" ]]; then
  next="$current"
else
  next="$(python3 scripts/version.py next --channel "$channel")"
fi
previous_tag=""
if [[ "${1:-}" == "--republish" ]]; then
  previous_tag="$(git ls-remote --refs origin "refs/tags/v${next}" | awk '{print $1}')"
  [[ -n "$previous_tag" ]] || { echo "Cannot republish missing remote tag v${next}." >&2; exit 1; }
elif git show-ref --verify --quiet "refs/tags/v${next}"; then
  echo "Tag v${next} already exists." >&2
  exit 1
fi
python3 scripts/check-i18n.py
./gradlew :app:spotlessCheck :app:testDebugUnitTest :app:lintDebug :app:assembleRelease
if [[ "$#" == 0 || "${1:-}" == "--nightly" ]]; then
  python3 scripts/version.py bump --channel "$channel"
  git add version.properties
  commit_message="chore: release v${next}"
  if [[ -n "${RELEASE_CO_AUTHOR:-}" ]]; then
    commit_message+=$'\n\nCo-Authored-By: '"$RELEASE_CO_AUTHOR"
  fi
  git commit -F - <<EOF
$commit_message
EOF
fi
# Main and tag advance together; a failed push never publishes only half the release.
if [[ "${1:-}" == "--republish" ]]; then
  git tag -f -a "v${next}" -m "Galaxy Watch Manager Free ${next} (republished)"
  git push --atomic --force-with-lease="refs/tags/v${next}:${previous_tag}" origin main "v${next}"
else
  git tag -a "v${next}" -m "Galaxy Watch Manager Free ${next}"
  git push --atomic origin main "v${next}"
fi
printf 'Release v%s queued in GitHub Actions.\n' "$next"
