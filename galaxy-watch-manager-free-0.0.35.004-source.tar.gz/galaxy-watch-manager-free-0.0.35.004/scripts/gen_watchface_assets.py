#!/usr/bin/env python3
"""从 Galaxy Wearable 插件（com.samsung.wearable.watch7plugin）内置的表盘预览图，
生成本地可选的表盘预览资源 + WatchFacePreset.kt 元数据。

预览图只作为用户本机自用构建的可选资源，默认写入被忽略的
private/vendor-assets/res/drawable-nodpi，不进入公开仓库或公开构建。
公开版表盘预览使用原创通用示意图（app/src/main/res/drawable/watch_face_illustration.xml）。

预览图来源：插件 APK 内 assets/Category_watchface/<packageName>.<SimpleServiceName>.webp
（360x360 RGBA）。三星手表在 Display 层设了 FLAG_SECURE，screencap 抓不到表盘画面，
因此这份插件内置预览是唯一可靠的「使用效果图」来源。

用法:
  # 1) 从手机把插件 APK 拉下来
  adb -s <serial> pull $(adb -s <serial> shell pm path com.samsung.wearable.watch7plugin | sed 's/package://') /tmp/watch7plugin.apk
  # 2) 解出预览图
  unzip -j -q /tmp/watch7plugin.apk "assets/Category_watchface/*.webp" -d /tmp/wfprev
  # 3) 生成资源（可再传入手表上实际安装的包名清单，只保留已安装的）
  adb -s <watch> shell "pm list packages | grep watch.watchface" | sed 's/package://' > /tmp/wf_installed.txt
  python3 scripts/gen_watchface_assets.py /tmp/wfprev /tmp/wf_installed.txt
  # 可选第三个参数是包含 assets/ 与 res/ 的输出根目录，默认 private/vendor-assets
"""
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_OUTPUT = os.path.join(ROOT, "private/vendor-assets")
KT_PATH = os.path.join(ROOT, "app/src/main/java/dev/ricky/galaxywatchmanagerfree/feature/WatchFacePreset.kt")

# pkg 后缀 -> (中文名, 英文名, 分类, 描述)
META = {
    # Ultra 专属
    "ultraanalog": ("极限指针", "Ultra Analog", "Ultra 专属", "Galaxy Watch Ultra 旗舰专属指南针罗盘表盘，支持夜间模式与极限运动数据"),
    "ultrainfoboard": ("极限信息板", "Ultra Info Board", "Ultra 专属", "多维度健康与运动数据聚合仪表，高度可定制的模块化面板"),
    "simpleultra": ("极简极限", "Simple Ultra", "Ultra 专属", "简约纯粹的 Ultra 高对比度设计，兼顾极致省电与强光辨识度"),
    # 运动健康
    "activitynumber": ("每日活动次数", "Activity Number", "运动健康", "醒目大数字步数与卡路里三环进度，时刻激励达成健康目标"),
    "healthmodular": ("健康模块板", "Health Modular", "运动健康", "心率、步数、压力与卡路里直观环形图表，全天候健康监控"),
    "sleepcoaching": ("睡眠指导", "Sleep Coaching", "运动健康", "根据专属睡眠动物符号展示昨夜睡眠评分与作息规律度"),
    # 多功能
    "infomodular": ("信息模块板", "Info Modular", "多功能", "经典全能数字表盘，多个高密度数据插槽自由配置"),
    "basicdashboard": ("基础仪表板", "Basic Dashboard", "多功能", "清晰明了的电量、日期与快捷小组件聚合设计"),
    "weather": ("动态天气", "Weather", "多功能", "根据当下天气自动变换背景光影与气象小组件"),
    "simplecomplication": ("简约复杂功能", "Simple Complication", "多功能", "极简底子叠加多个复杂功能插槽，信息密度与美感兼顾"),
    "livewallpaper": ("动态壁纸", "Live Wallpaper", "多功能", "可动态变化的壁纸式表盘，随场景与时间流转"),
    # 经典指针
    "analogmodular": ("模块化指针", "Analog Modular", "经典指针", "传统瑞士机械腕表质感，内嵌三颗高自定义小表盘"),
    "premiumanalog": ("高级指针", "Premium Analog", "经典指针", "奢华尊贵腕表外观，细腻的金属放射拉丝刻度与立体指针"),
    "perpetual": ("万年历", "Perpetual", "经典指针", "月相、星期、日历与天文规律典雅排布的传世之作"),
    "simpleanalogue": ("简约指针", "Simple Analogue", "经典指针", "干净利落的指针表盘，去掉一切冗余只留时间本身"),
    "simpleclassic": ("简约经典", "Simple Classic", "经典指针", "经典罗马刻度风格，稳重耐看的日常通勤之选"),
    "boldindex": ("粗体刻度", "Bold Index", "经典指针", "粗犷大刻度与强对比指针，一眼看清时间"),
    "stretchindex": ("拉伸刻度", "Stretch Index", "经典指针", "拉伸变形的刻度设计，运动感与设计感兼具"),
    "dualwatch": ("双时区", "Dual Watch", "经典指针", "双表盘设计，一眼同时掌握本地与异国时间"),
    # 简约个性
    "basicclock": ("基础时钟", "Basic Clock", "简约个性", "极简大刻度易读表盘，大方得体且低功耗"),
    "digitalmodular": ("数字模块板", "Digital Modular", "简约个性", "现代数码几何字体，多颜色与渐变主题组合"),
    "digitalfont": ("数字字体", "Digital Font", "简约个性", "以字体设计为核心的数字表盘，多种字重与配色"),
    "gradientfont": ("渐变字体", "Gradient Font", "简约个性", "字体随时间渲染彩色渐变，年轻有活力"),
    "analoguefont": ("指针字体", "Analogue Font", "简约个性", "把指针与字体融合的艺术化设计"),
    "dynamicfont": ("动态字体", "Dynamic Font", "简约个性", "字体随动作与时间动态流动变化"),
    "large": ("大字时间", "Large", "简约个性", "超大字号时间，远看近看都清晰"),
    "spatialnumber": ("立体数字", "Spatial Number", "简约个性", "悬浮立体数字，营造空间纵深感"),
    "spherenumber": ("球形数字", "Sphere Number", "简约个性", "数字环绕球体的三维视觉表盘"),
    "superfiction": ("未来幻境", "Superfiction", "简约个性", "赛博未来风格插画表盘，个性张扬"),
    "together": ("同行", "Together", "简约个性", "以陪伴为主题的双人互动表盘"),
    "typography": ("字体排版", "Typography", "简约个性", "杂志级排版设计，信息层级分明"),
    "bespoke": ("定制表盘", "Bespoke", "简约个性", "自由调配表盘背景材质与撞色设计，随心搭配穿搭"),
    "mystyle": ("我的风格", "My Style", "简约个性", "由你的穿搭与照片自动生成风格化表盘"),
    "myphoto": ("我的照片", "My Photo", "简约个性", "把喜欢的照片变成表盘背景"),
    "photosticker": ("照片贴纸", "Photo Sticker", "简约个性", "照片 + 贴纸拼贴的趣味表盘"),
    "aremoji": ("AR 表情", "AR Emoji", "简约个性", "你的 AR 虚拟形象替你报时"),
    "bitmoji": ("Bitmoji", "Bitmoji", "简约个性", "Bitmoji 卡通形象动态表盘"),
    "face": ("表情表盘", "Face", "简约个性", "以表情符号为主视觉的活泼表盘"),
    "animal": ("动物", "Animal", "简约个性", "可爱动物形象随心情变化"),
    "endangeredanimal": ("濒危动物", "Endangered Animal", "简约个性", "每看一眼都为濒危物种发声的公益表盘"),
    "flowergarden": ("花漾花园", "Flower Garden", "简约个性", "随季节与时间绽放的花园场景"),
    "mypebble": ("我的卵石", "My Pebble", "简约个性", "鹅卵石质感极简表盘，宁静治愈"),
}

SKIP = {"companionhelper", "complicationhelper", "emergency", "tickingsound"}

CAT_ORDER = ["Ultra 专属", "运动健康", "多功能", "经典指针", "简约个性"]


def camel(simple: str) -> str:
    return simple


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    prev_dir = sys.argv[1]
    installed_file = sys.argv[2] if len(sys.argv) > 2 else None
    output = sys.argv[3] if len(sys.argv) > 3 else DEFAULT_OUTPUT
    res_dir = os.path.join(output, "res/drawable-nodpi")

    installed = None
    if installed_file and os.path.exists(installed_file):
        installed = {l.strip() for l in open(installed_file) if l.strip()}

    entries = []
    for fn in sorted(os.listdir(prev_dir)):
        if not fn.endswith(".webp"):
            continue
        base = fn[:-5]                      # pkg.SimpleService
        m = re.match(r"^(com\.samsung\.android\.watch\.watchface\.[a-z0-9_]+)\.([A-Za-z0-9_]+)$", base)
        if not m:
            continue
        pkg, simple = m.group(1), m.group(2)
        suffix = pkg.rsplit(".", 1)[-1]
        if suffix in SKIP:
            continue
        if installed is not None and pkg not in installed:
            continue
        name, en, cat, desc = META.get(suffix, (suffix, suffix, "简约个性", ""))
        entries.append(dict(id=suffix, pkg=pkg, simple=simple, name=name, en=en, cat=cat, desc=desc, src=os.path.join(prev_dir, fn)))

    if not entries:
        sys.exit("No matching watch-face preview files found; refusing to rewrite WatchFacePreset.kt")

    entries.sort(key=lambda e: (CAT_ORDER.index(e["cat"]) if e["cat"] in CAT_ORDER else 99,
                                list(META).index(e["id"]) if e["id"] in META else 999))

    os.makedirs(os.path.join(output, "assets"), exist_ok=True)
    os.makedirs(res_dir, exist_ok=True)
    for e in entries:
        res_name = "wf_" + e["id"]
        e["res"] = res_name
        out = os.path.join(res_dir, res_name + ".webp")
        from PIL import Image
        im = Image.open(e["src"]).convert("RGBA")
        im = im.resize((300, 300), Image.LANCZOS)
        im.save(out, "WEBP", quality=88, method=6)

    CAT_ENUM_MAP = {
        "Ultra 专属": "ULTRA",
        "运动健康": "FITNESS",
        "多功能": "INFORMATION",
        "经典指针": "ANALOG",
        "简约个性": "PERSONAL",
    }

    # ---- 生成 Kotlin ----
    lines = []
    A = lines.append
    A("package dev.ricky.galaxywatchmanagerfree.feature")
    A("")
    A("import androidx.annotation.StringRes")
    A("import dev.ricky.galaxywatchmanagerfree.R")
    A("")
    A("/** Localizable metadata; package and service identifiers are protocol values. */")
    A("data class WatchFacePreset(")
    A("    val id: String,")
    A("    @StringRes val nameRes: Int,")
    A("    val enName: String,")
    A("    val packageName: String,")
    A("    val className: String,")
    A("    val category: WatchFaceCategory,")
    A(") {")
    A("    val isUltraExclusive: Boolean")
    A("        get() = category == WatchFaceCategory.ULTRA")
    A("}")
    A("")
    A("enum class WatchFaceCategory(@StringRes val labelRes: Int) {")
    A("    ULTRA(R.string.watch_face_category_ultra),")
    A("    FITNESS(R.string.watch_face_category_fitness),")
    A("    INFORMATION(R.string.watch_face_category_information),")
    A("    ANALOG(R.string.watch_face_category_analog),")
    A("    PERSONAL(R.string.watch_face_category_personal),")
    A("}")
    A("")
    A("object WatchFacePresets {")
    A("    val ALL: List<WatchFacePreset> =")
    A("        listOf(")
    for e in entries:
        cat_enum = CAT_ENUM_MAP.get(e["cat"], "PERSONAL")
        A("            WatchFacePreset(")
        A(f'                id = "{e["id"]}",')
        A(f'                nameRes = R.string.watch_face_{e["id"]},')
        A(f'                enName = "{e["en"]}",')
        A(f'                packageName = "{e["pkg"]}",')
        A(f'                className = "{e["pkg"]}.{e["simple"]}",')
        A(f'                category = WatchFaceCategory.{cat_enum},')
        A("            ),")
    A("        )")
    A("")
    A("    fun byId(id: String): WatchFacePreset? {")
    A("        val key = id.lowercase(java.util.Locale.ROOT).replace(\"_\", \"\")")
    A("        return ALL.firstOrNull { it.id == key }")
    A("    }")
    A("")
    A("    fun find(packageName: String?, className: String?): WatchFacePreset? =")
    A("        ALL.firstOrNull { preset ->")
    A("            (packageName != null && preset.packageName == packageName) ||")
    A("                (className != null && preset.className == className)")
    A("        }")
    A("}")
    A("")
    open(KT_PATH, "w", encoding="utf-8").write("\n".join(lines))
    print(f"生成 {len(entries)} 个可选表盘预览 -> {res_dir}")
    print(f"生成 Kotlin -> {KT_PATH}")


if __name__ == "__main__":
    main()
