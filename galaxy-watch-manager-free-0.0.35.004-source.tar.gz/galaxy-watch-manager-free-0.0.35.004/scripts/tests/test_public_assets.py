import importlib.util
from pathlib import Path
import tempfile
import unittest
import zipfile

SCRIPT = Path(__file__).resolve().parents[1] / "check_public_assets.py"
spec = importlib.util.spec_from_file_location("check_public_assets", SCRIPT)
check_public_assets = importlib.util.module_from_spec(spec)
spec.loader.exec_module(check_public_assets)


class PublicAssetsCheckTest(unittest.TestCase):
    def test_repository_source_is_clean(self):
        self.assertEqual([], check_public_assets.source_offenders(SCRIPT.parents[1]))

    def test_source_vendor_assets_are_reported_but_notices_are_allowed(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        root = Path(temporary.name)
        sleep = root / "app/src/main/assets/sleep"
        (sleep / "arm64-v8a").mkdir(parents=True)
        (sleep / "NOTICE.md").write_text("notice")
        (sleep / "TENSORFLOW-LICENSE.txt").write_text("license")
        (sleep / "engine.jar").write_bytes(b"vendor")
        (sleep / "manifest.json").write_text("{}")
        (sleep / "arm64-v8a/libmobilesleepjni.so").write_bytes(b"vendor")
        previews = root / "app/src/main/res/drawable-nodpi"
        previews.mkdir(parents=True)
        (previews / "wf_ultraanalog.webp").write_bytes(b"vendor")

        errors = check_public_assets.source_offenders(root)

        self.assertEqual(4, len(errors))
        self.assertTrue(any("engine.jar" in error for error in errors))
        self.assertTrue(any("manifest.json" in error for error in errors))
        self.assertTrue(any("libmobilesleepjni.so" in error for error in errors))
        self.assertTrue(any("wf_ultraanalog.webp" in error for error in errors))
        self.assertFalse(any("NOTICE.md" in error for error in errors))

    def test_source_previews_in_other_drawable_qualifiers_are_reported(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        root = Path(temporary.name)
        previews = root / "app/src/main/res/drawable-hdpi"
        previews.mkdir(parents=True)
        (previews / "wf_ultraanalog.webp").write_bytes(b"vendor")

        errors = check_public_assets.source_offenders(root)

        self.assertEqual(1, len(errors))
        self.assertIn("wf_ultraanalog.webp", errors[0])

    def test_nested_sleep_files_do_not_inherit_notice_allowlist(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        root = Path(temporary.name)
        nested = root / "app/src/main/assets/sleep/nested"
        nested.mkdir(parents=True)
        (nested / "NOTICE.md").write_bytes(b"vendor")

        errors = check_public_assets.source_offenders(root)

        self.assertEqual(1, len(errors))
        self.assertIn("nested/NOTICE.md", errors[0])

    def test_apk_vendor_entries_are_reported(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        apk = Path(temporary.name) / "app.apk"
        with zipfile.ZipFile(apk, "w") as archive:
            archive.writestr("assets/sleep/NOTICE.md", "notice")
            archive.writestr("assets/sleep/TENSORFLOW-LICENSE.txt", "license")
            archive.writestr("assets/sleep/engine.jar", b"vendor")
            archive.writestr("assets/sleep/arm64-v8a/libmobilesleepjni.so", b"vendor")
            archive.writestr("res/drawable-nodpi/wf_ultraanalog.webp", b"preview")

        errors = check_public_assets.apk_offenders(apk)

        self.assertEqual(3, len(errors))
        self.assertTrue(any("engine.jar" in error for error in errors))
        self.assertTrue(any("libmobilesleepjni.so" in error for error in errors))
        self.assertTrue(any("wf_ultraanalog.webp" in error for error in errors))

    def test_clean_apk_passes(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        apk = Path(temporary.name) / "app.apk"
        with zipfile.ZipFile(apk, "w") as archive:
            archive.writestr("assets/sleep/NOTICE.md", "notice")
            archive.writestr("classes.dex", b"dex")

        self.assertEqual([], check_public_assets.apk_offenders(apk))


if __name__ == "__main__":
    unittest.main()
