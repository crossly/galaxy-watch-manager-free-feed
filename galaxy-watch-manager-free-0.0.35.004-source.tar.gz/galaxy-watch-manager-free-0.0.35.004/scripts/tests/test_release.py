import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[2]


class ReleaseRepublishTests(unittest.TestCase):
    def _create_fixture(
        self, folder, version_name="0.0.11", version_code=11, initial_tag=True, gradlew_body="exit 0\n"
    ):
        origin = folder / "origin.git"
        clone = folder / "clone"

        def git(cmd, cwd):
            return subprocess.check_output(
                ["git", *cmd], cwd=cwd, text=True, stderr=subprocess.DEVNULL
            ).strip()

        subprocess.check_call(["git", "init", "--bare", str(origin)], stdout=subprocess.DEVNULL)
        subprocess.check_call(["git", "clone", str(origin), str(clone)], stdout=subprocess.DEVNULL)

        git(["checkout", "-b", "main"], clone)
        git(["config", "user.name", "Test"], clone)
        git(["config", "user.email", "test@example.invalid"], clone)

        (clone / "version.properties").write_text(
            f"VERSION_NAME={version_name}\nVERSION_CODE={version_code}\n"
        )
        (clone / "scripts").mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT / "scripts/release.sh", clone / "scripts/release.sh")
        shutil.copy2(ROOT / "scripts/version.py", clone / "scripts/version.py")
        (clone / "scripts/check-i18n.py").write_text("#!/usr/bin/env python3\n")
        (clone / "gradlew").write_text(f"#!/bin/sh\n{gradlew_body}")
        (clone / "gradlew").chmod(0o755)
        (clone / "scripts/release.sh").chmod(0o755)

        git(["add", "."], clone)
        git(["commit", "-m", f"initial {version_name}"], clone)
        if initial_tag:
            git(["tag", "-a", f"v{version_name}", "-m", f"tag v{version_name}"], clone)
            git(["push", "-u", "origin", "main", f"v{version_name}"], clone)
        else:
            git(["push", "-u", "origin", "main"], clone)

        subprocess.check_call(["git", "symbolic-ref", "HEAD", "refs/heads/main"], cwd=origin)
        return origin, clone

    def test_current_publishes_prepared_version_without_new_commit(self):
        with tempfile.TemporaryDirectory() as tmp:
            origin, clone = self._create_fixture(
                Path(tmp), version_name="0.0.32", version_code=32, initial_tag=False
            )
            head = subprocess.check_output(
                ["git", "rev-parse", "HEAD"], cwd=clone, text=True
            ).strip()
            version_text = (clone / "version.properties").read_text()

            res = subprocess.run(
                [str(clone / "scripts/release.sh"), "--current"],
                cwd=clone,
                capture_output=True,
                text=True,
            )
            self.assertEqual(0, res.returncode, res.stdout + res.stderr)
            self.assertIn("Release v0.0.32 queued in GitHub Actions.", res.stdout)
            self.assertEqual(version_text, (clone / "version.properties").read_text())
            for ref in ("refs/heads/main", "refs/tags/v0.0.32^{commit}"):
                remote_commit = subprocess.check_output(
                    ["git", "rev-parse", ref], cwd=origin, text=True
                ).strip()
                self.assertEqual(head, remote_commit)

    def test_current_refuses_existing_tag_without_overwriting_it(self):
        with tempfile.TemporaryDirectory() as tmp:
            origin, clone = self._create_fixture(Path(tmp))
            tag_before = subprocess.check_output(
                ["git", "rev-parse", "refs/tags/v0.0.11"], cwd=origin, text=True
            ).strip()
            res = subprocess.run(
                [str(clone / "scripts/release.sh"), "--current"],
                cwd=clone,
                capture_output=True,
                text=True,
            )
            self.assertNotEqual(0, res.returncode)
            self.assertIn("Tag v0.0.11 already exists.", res.stderr)
            tag_after = subprocess.check_output(
                ["git", "rev-parse", "refs/tags/v0.0.11"], cwd=origin, text=True
            ).strip()
            self.assertEqual(tag_before, tag_after)

    def test_current_does_not_publish_when_build_checks_fail(self):
        with tempfile.TemporaryDirectory() as tmp:
            origin, clone = self._create_fixture(
                Path(tmp),
                initial_tag=False,
                gradlew_body="printf 'fixture-build-failed\\n' >&2\nexit 1\n",
            )
            res = subprocess.run(
                [str(clone / "scripts/release.sh"), "--current"],
                cwd=clone,
                capture_output=True,
                text=True,
            )
            self.assertNotEqual(0, res.returncode)
            self.assertIn("fixture-build-failed", res.stderr)
            remote_tags = subprocess.check_output(
                ["git", "ls-remote", "--tags", str(origin)], cwd=clone, text=True
            ).strip()
            self.assertEqual("", remote_tags)

    def test_republish_moves_existing_tag_to_current_main_without_version_increment(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            origin, clone = self._create_fixture(
                folder, version_name="0.0.11", version_code=11, initial_tag=True
            )

            def git(cmd, cwd):
                return subprocess.check_output(
                    ["git", *cmd], cwd=cwd, text=True, stderr=subprocess.DEVNULL
                ).strip()

            initial_commit = git(["rev-parse", "HEAD"], clone)

            # Advance main with a new commit
            (clone / "update.txt").write_text("republished change\n")
            git(["add", "."], clone)
            git(["commit", "-m", "advance main"], clone)
            git(["push", "origin", "main"], clone)
            head_commit = git(["rev-parse", "HEAD"], clone)
            self.assertNotEqual(initial_commit, head_commit)

            res = subprocess.run(
                [str(clone / "scripts/release.sh"), "--republish"],
                cwd=clone,
                capture_output=True,
                text=True,
            )
            self.assertEqual(0, res.returncode, res.stdout + res.stderr)
            self.assertIn("Release v0.0.11 queued in GitHub Actions.", res.stdout)

            # Version remains unchanged
            version_text = (clone / "version.properties").read_text()
            self.assertIn("VERSION_NAME=0.0.11", version_text)
            self.assertIn("VERSION_CODE=11", version_text)

            # Remote tag now points to the new main commit
            origin_tag_commit = git(["rev-parse", "refs/tags/v0.0.11^{commit}"], origin)
            self.assertEqual(head_commit, origin_tag_commit)

            # Tag message notes republication
            tag_object = git(["cat-file", "-p", "refs/tags/v0.0.11"], origin)
            self.assertIn("(republished)", tag_object)

    def test_republish_refuses_when_remote_tag_missing(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            origin, clone = self._create_fixture(
                folder, version_name="0.0.11", version_code=11, initial_tag=False
            )

            def git(cmd, cwd):
                return subprocess.check_output(
                    ["git", *cmd], cwd=cwd, text=True, stderr=subprocess.DEVNULL
                ).strip()

            res = subprocess.run(
                [str(clone / "scripts/release.sh"), "--republish"],
                cwd=clone,
                capture_output=True,
                text=True,
            )
            self.assertNotEqual(0, res.returncode)
            self.assertIn("Cannot republish missing remote tag v0.0.11.", res.stderr)

            # Version remains unchanged and no remote tag was pushed
            version_text = (clone / "version.properties").read_text()
            self.assertIn("VERSION_NAME=0.0.11", version_text)
            remote_tags = git(["ls-remote", "--tags", str(origin)], clone)
            self.assertEqual("", remote_tags)

    def test_republish_rejects_and_does_not_overwrite_when_remote_tag_concurrently_updated(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            concurrent = folder / "concurrent"

            def git(cmd, cwd):
                return subprocess.check_output(
                    ["git", *cmd], cwd=cwd, text=True, stderr=subprocess.DEVNULL
                ).strip()

            # gradlew stub that simulates a concurrent push to origin's tag while checks run
            gradlew_hook = f"""
if [ -n "$CONCURRENT_REPO" ]; then
    git -C "$CONCURRENT_REPO" tag -f -a v0.0.11 -m "concurrent update"
    git -C "$CONCURRENT_REPO" push -f origin v0.0.11
fi
exit 0
"""
            origin, clone = self._create_fixture(
                folder,
                version_name="0.0.11",
                version_code=11,
                initial_tag=True,
                gradlew_body=gradlew_hook,
            )

            # Set up concurrent clone
            subprocess.check_call(
                ["git", "clone", str(origin), str(concurrent)], stdout=subprocess.DEVNULL
            )
            git(["config", "user.name", "Concurrent"], concurrent)
            git(["config", "user.email", "concurrent@example.invalid"], concurrent)
            (concurrent / "concurrent.txt").write_text("concurrent branch commit\n")
            git(["add", "."], concurrent)
            git(["commit", "-m", "concurrent commit"], concurrent)
            concurrent_commit = git(["rev-parse", "HEAD"], concurrent)

            # Advance main in clone
            (clone / "local.txt").write_text("local work on main\n")
            git(["add", "."], clone)
            git(["commit", "-m", "advance local main"], clone)
            git(["push", "origin", "main"], clone)

            env = {**os.environ, "CONCURRENT_REPO": str(concurrent)}
            res = subprocess.run(
                [str(clone / "scripts/release.sh"), "--republish"],
                cwd=clone,
                env=env,
                capture_output=True,
                text=True,
            )

            self.assertNotEqual(0, res.returncode)
            self.assertTrue("stale info" in res.stderr or "rejected" in res.stderr)

            # Tag on origin remains at concurrent update and was NOT overwritten by local republish
            origin_tag_commit = git(["rev-parse", "refs/tags/v0.0.11^{commit}"], origin)
            self.assertEqual(concurrent_commit, origin_tag_commit)
            tag_object = git(["cat-file", "-p", "refs/tags/v0.0.11"], origin)
            self.assertIn("concurrent update", tag_object)
            self.assertNotIn("(republished)", tag_object)

    def test_nightly_releases_increment_suffix_and_stable_resets_it(self):
        with tempfile.TemporaryDirectory() as tmp:
            origin, clone = self._create_fixture(Path(tmp), version_name="0.0.32", version_code=32)
            for option, name, code in (("--nightly", "0.0.32.001", 32001),
                                       ("--nightly", "0.0.32.002", 32002),
                                       (None, "0.0.33", 33000),
                                       ("--nightly", "0.0.33.001", 33001)):
                args = [str(clone / "scripts/release.sh")] + ([option] if option else [])
                result = subprocess.run(args, cwd=clone, capture_output=True, text=True)
                self.assertEqual(0, result.returncode, result.stdout + result.stderr)
                self.assertEqual(f"VERSION_NAME={name}\nVERSION_CODE={code}\n", (clone / "version.properties").read_text())
                remote_commit = subprocess.check_output(
                    ["git", "rev-parse", f"refs/tags/v{name}^{{commit}}"], cwd=origin, text=True
                ).strip()
                self.assertEqual(remote_commit, subprocess.check_output(
                    ["git", "rev-parse", "HEAD"], cwd=clone, text=True
                ).strip())

    def test_version_next_does_not_change_version_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            _, clone = self._create_fixture(Path(tmp))
            before = (clone / "version.properties").read_text()
            result = subprocess.run(["python3", "scripts/version.py", "next", "--channel", "nightly"],
                                    cwd=clone, capture_output=True, text=True)
            self.assertEqual(0, result.returncode, result.stderr)
            self.assertEqual("0.0.11.001", result.stdout.strip())
            self.assertEqual(before, (clone / "version.properties").read_text())


class ReleaseWorkflowChannelTests(unittest.TestCase):
    def test_release_step_sets_prerelease_and_latest_for_create_and_edit(self):
        import json
        import sys
        import textwrap

        workflow = (ROOT / ".github/workflows/release.yml").read_text()
        step = workflow.split("      - name: Publish release\n", 1)[1].split("      # A published release", 1)[0]
        command = textwrap.dedent(step.split("        run: |\n", 1)[1])
        for name, code, nightly, newer in (("0.0.32", 32000, False, False),
                                          ("0.0.32", 32000, False, True),
                                          ("0.0.32.001", 32001, True, True)):
            for existing in (True, False):
                with self.subTest(name=name, existing=existing), tempfile.TemporaryDirectory() as tmp:
                    folder = Path(tmp)
                    (folder / "scripts").mkdir()
                    (folder / "bin").mkdir()
                    (folder / "artifacts").mkdir()
                    (folder / "artifacts/app.apk").write_bytes(b"synthetic apk")
                    (folder / "artifacts/app-source.tar.gz").write_bytes(b"synthetic source")
                    (folder / "artifacts/app.sha256").write_text("synthetic digest")
                    shutil.copy2(ROOT / "scripts/version.py", folder / "scripts/version.py")
                    (folder / "version.properties").write_text(f"VERSION_NAME={name}\nVERSION_CODE={code}\n")
                    gh = folder / "bin/gh"
                    gh.write_text(f"#!{sys.executable}\n" + textwrap.dedent('''\
                        import json, os, pathlib, sys
                        path = pathlib.Path(os.environ["TEST_GH_LOG"])
                        calls = json.loads(path.read_text()) if path.exists() else []
                        calls.append(sys.argv[1:])
                        path.write_text(json.dumps(calls))
                        if sys.argv[1] == "api":
                            print(os.environ["TEST_PUBLISHED_TAGS"])
                        if sys.argv[1:3] == ["release", "view"]:
                            sys.exit(0 if os.environ["TEST_RELEASE_EXISTS"] == "true" else 1)
                        '''))
                    gh.chmod(0o755)
                    result = subprocess.run(["bash", "-e", "-c", command], cwd=folder, capture_output=True, text=True,
                                            env={**os.environ, "PATH": str(folder / "bin") + os.pathsep + os.environ["PATH"],
                                                 "RELEASE_TAG": "v" + name, "TEST_RELEASE_EXISTS": str(existing).lower(),
                                                 "GITHUB_REPOSITORY": "example/synthetic",
                                                 "TEST_PUBLISHED_TAGS": "v0.0.33" if newer else "v0.0.31",
                                                 "TEST_GH_LOG": str(folder / "calls.json")})
                    self.assertEqual(0, result.returncode, result.stdout + result.stderr)
                    calls = json.loads((folder / "calls.json").read_text())
                    release = calls[-1]
                    self.assertEqual(["release", "edit" if existing else "create"], release[:2])
                    self.assertIn("--prerelease=" + str(nightly).lower(), release)
                    self.assertIn("--latest=" + str(not nightly and not newer).lower(), release)
                    self.assertIn("artifacts/app-source.tar.gz", release if not existing else calls[-2])

    def test_requested_tag_validation_accepts_only_valid_channel_names(self):
        import textwrap

        workflow = (ROOT / ".github/workflows/release.yml").read_text()
        step = workflow.split("      - name: Validate requested tag\n", 1)[1].split("      - uses: actions/checkout", 1)[0]
        command = textwrap.dedent(step.split("        run: |\n", 1)[1])
        for tag, valid in (("v0.0.32", True), ("v0.0.32.001", True), ("v0.0.32.999", True),
                           ("v0.0.32.000", False), ("v0.0.32.1", False), ("v0.0.032", False),
                           ("v0.0.32.1000", False), ("v1.0.32", False)):
            with self.subTest(tag=tag):
                result = subprocess.run(["bash", "-c", command], env={**os.environ, "RELEASE_TAG": tag}, capture_output=True)
                self.assertEqual(valid, result.returncode == 0)


if __name__ == "__main__":
    unittest.main()
