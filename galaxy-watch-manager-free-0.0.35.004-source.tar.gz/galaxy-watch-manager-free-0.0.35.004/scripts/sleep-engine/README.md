# Sleep runtime reconstruction profile

`build.py` rebuilds the vendor-derived sleep runtime from one pinned local APK. The output is
**not part of the public repository or public builds**: it is written to the ignored local
`private/vendor-assets/assets/sleep/` and can be loaded into a self-use build with
`-PvendorAssetsDir=private/vendor-assets`.

The script requires a JDK, Android platform `android.jar`, Android build-tools R8/D8 JAR,
dexlib2 plus Guava on a classpath, and dex2jar 2.4 on a classpath. Tools are caller supplied;
the script does not install them, download anything, or upload anything. You must supply your
own local APK.

```sh
python3 scripts/sleep-engine/build.py /absolute/path/to/shealth.apk \
  --dexlib-cp '/path/to/dexlib2.jar:/path/to/guava.jar:/path/to/failureaccess.jar' \
  --dex2jar-cp '/path/to/dex-tools-v2.4/lib/*' \
  --r8 '/path/to/android/build-tools/35.0.0/lib/d8.jar' \
  --android-jar '/path/to/android/platforms/android-36/android.jar'
```

The default output root is `private/vendor-assets`; the runtime lands in
`private/vendor-assets/assets/sleep/`. An explicit second positional argument overrides that
root and gets the same `assets/sleep/` layout. Never copy the result into
`app/src/main/assets/sleep/`: `verifyNoVendorAssets` rejects it and public CI must not contain it.

The input digest is checked before processing. `SleepDexSubset.java` selects the inference
classes, removes unrelated merged interfaces/entry points, and restores default constructors
whose calls were elided in the optimized DEX. `SleepConstructorPatch.java` retargets those
constructor calls for JVM conversion and replaces only the Gson row reader and monotonic
position check with small explicit implementations in `GalaxySleepEngine.java`. The actual
feature preprocessing, TensorFlow model, and stage alignment/postprocessing are preserved.
`rules.pro` keeps the dynamic entry point, JNI class names, and required generic metadata.
Only the bridge class, not its compilation stubs, enters the runtime.

The output includes `engine.jar`, the two ARM native runtime sets, and a SHA-256 manifest.
Rebuilt output was replayed on the phone against both the latest sensor record and a known
record: 636 / 728 final half-minute epochs exactly matched the full-source APK execution;
the known record also matched all 728 previously synchronized stage epochs. That device
validation used a local self-use build containing these vendor assets; the public build does
not execute this inference.

This profile is deliberately pinned. Do not apply it to another vendor APK by changing only
the digest: class names, merged types, model versions, fields and JNI contracts can change.
See `docs/SLEEP-ANALYSIS.md` and the asset notice for provenance and current limitations.

## Loading local assets into a self-use build

```sh
./gradlew :app:assembleDebug -PvendorAssetsDir=private/vendor-assets
```

The directory must contain `assets/` and `res/` (the sleep runtime above plus optional watch-face
previews under `res/drawable-nodpi/`). The property is opt-in, is rejected when CI is detected,
and sets `BuildConfig.VENDOR_ASSETS_ENABLED=true`. Without it, the public build contains only
the original generic watch-face illustration and no vendor sleep runtime. Redistribution
rights for the vendor files are not established by this local workflow; see `THIRD-PARTY.md`.
