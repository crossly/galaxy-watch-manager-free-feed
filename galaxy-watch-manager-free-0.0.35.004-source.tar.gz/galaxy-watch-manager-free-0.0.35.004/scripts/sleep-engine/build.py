#!/usr/bin/env python3
"""Rebuild the pinned offline sleep runtime; analysis tools and vendor APK are caller supplied.

The positional output defaults to private/vendor-assets; the runtime is written to
<output>/assets/sleep, which is ignored by Git and can be loaded into a local personal build
with -PvendorAssetsDir=private/vendor-assets. Public builds never include this vendor-derived
runtime.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile
from zipfile import ZipFile, ZIP_STORED

SOURCE_SHA256 = '88b0359eaaea6061466df4fdb15754ca8408caf68e1eb796ef58b24374efe312'
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
DEFAULT_OUTPUT = ROOT / 'private/vendor-assets'

def run(*args):
    subprocess.run([str(a) for a in args], check=True)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('apk', type=Path)
    parser.add_argument('output', nargs='?', type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument('--dexlib-cp', default=os.environ.get('DEXLIB_CP'))
    parser.add_argument('--dex2jar-cp', default=os.environ.get('DEX2JAR_CP'))
    parser.add_argument('--r8', type=Path, default=os.environ.get('R8_JAR'))
    parser.add_argument('--android-jar', type=Path, default=os.environ.get('ANDROID_JAR'))
    args = parser.parse_args()
    if not all([args.dexlib_cp, args.dex2jar_cp, args.r8, args.android_jar]):
        parser.error('Supply DEXLIB_CP, DEX2JAR_CP, R8_JAR and ANDROID_JAR, or their CLI options')
    if hashlib.sha256(args.apk.read_bytes()).hexdigest() != SOURCE_SHA256:
        parser.error('This extraction profile only supports the documented Samsung Health APK digest')
    runtime = args.output / 'assets' / 'sleep'
    runtime.mkdir(parents=True, exist_ok=True)
    (args.output / 'res').mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='sleep-engine-build-') as temporary:
        work = Path(temporary)
        classes = work/'classes'; classes.mkdir()
        bridge = work/'bridge'; bridge.mkdir()
        stubs = work/'stubs'; stubs.mkdir()
        stub_sources = {
            'tk.java': 'public class tk { public tk(byte a,int b) {} public yd0 o(long a,long b,long c,long d,org.json.JSONObject j,android.content.Context x,int v){return null;} }',
            'yd0.java': 'public class yd0 { public int a,b; public long d,e; public java.util.List<com.samsung.msleepstagelib.StageInfo> c; }',
            'l7c0.java': 'public class l7c0 { public double[] a; public java.util.ArrayList b; }',
            'h7c0.java': 'public class h7c0 { public int a,b,c; public h7c0(int a,int b,int c) {} }',
            'com/samsung/msleepstagelib/StageInfo.java': 'package com.samsung.msleepstagelib; public class StageInfo { public long timeStamp; public int data; }',
        }
        sources = []
        for name, content in stub_sources.items():
            target = stubs/name; target.parent.mkdir(parents=True, exist_ok=True); target.write_text(content); sources.append(target)
        run('javac', '-cp', args.dexlib_cp, '-d', classes, HERE/'SleepDexSubset.java', HERE/'SleepConstructorPatch.java')
        tool_cp = str(classes) + os.pathsep + args.dexlib_cp
        run('java', '-Xmx2g', '-cp', tool_cp, 'SleepDexSubset', args.apk, work/'subset.dex')
        run('java', '-Xmx2g', '-cp', tool_cp, 'SleepConstructorPatch', work/'subset.dex', work/'patched.dex')
        run('java', '-Xmx2g', '-cp', args.dex2jar_cp, 'com.googlecode.dex2jar.tools.Dex2jarCmd',
            '-f', '-e', work/'conversion-errors.zip', '-o', work/'input.jar', work/'patched.dex')
        run('javac', '-source', '8', '-target', '8', '-cp', args.android_jar, '-d', bridge, *sources, HERE/'GalaxySleepEngine.java')
        run('java', '-Xmx3g', '-cp', args.r8, 'com.android.tools.r8.R8', '--release', '--min-api', '26',
            '--lib', args.android_jar, '--pg-conf', HERE/'rules.pro', '--output', work/'engine.zip',
            work/'input.jar', bridge/'GalaxySleepEngine.class')
        with ZipFile(args.apk) as apk, ZipFile(work/'engine.zip') as dex, ZipFile(runtime/'engine.jar', 'w', ZIP_STORED) as engine:
            engine.writestr('classes.dex', dex.read('classes.dex'))
            for name in ['quantiles_db6_vertical.txt', 'tcn_ibi_t2v_stages_sum_214_l8_db6.tflite']:
                engine.writestr('assets/'+name, apk.read('assets/'+name))
            for abi in ['arm64-v8a', 'armeabi-v7a']:
                (runtime/abi).mkdir(exist_ok=True)
                for name in ['libmobilesleepjni.so', 'libtensorflowlite_jni.so']:
                    (runtime/abi/name).write_bytes(apk.read('lib/'+abi+'/'+name))
        files = {str(p.relative_to(runtime)): hashlib.sha256(p.read_bytes()).hexdigest()
                 for p in runtime.rglob('*') if p.is_file() and p.suffix in ['.jar', '.so']}
        (runtime/'manifest.json').write_text(json.dumps({'version': 1,
            'origin': 'Samsung Health 7.1.0.053 local sleep inference assets',
            'source_apk_sha256': SOURCE_SHA256, 'files': files}, indent=2)+'\n')
        print('Runtime written to', runtime)

if __name__ == '__main__':
    main()
