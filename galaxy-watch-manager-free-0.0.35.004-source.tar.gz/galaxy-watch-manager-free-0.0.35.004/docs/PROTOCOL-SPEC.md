# Samsung Galaxy Watch 独立直连协议全景技术规范 (Protocol Specification)

> **版本**：v1.9 (2026-11)
> **兼容与实测范围**：
> - **实测设备对 1**：Galaxy Watch 7 Ultra + 荣耀 Magic 8 Pro；v0.0.29 手机三轮袖带校准向导已由用户真机确认完整可用，手表端不再崩溃。
> - **实测设备对 2**：Galaxy Watch 6 + 一加 13 Pro；用户反馈基础功能基本正常，v0.0.29 手机血压校准向导及启动修复尚未在该设备对复测。
> - **静态适配**：Watch 4 / 5 / FE 已完成选定官方插件的静态对比与回归测试，尚待真机验证。具体系统和固件版本不能由型号推定。详见 [兼容性调查](WATCH4-6-COMPATIBILITY.md)。
>
> **手机环境**：应用最低 Android 8.0，无需 Root 或 LSPosed；首次设置仍走官方流程，自动读取已登记身份需要可用的 Google Wear 服务。取得并验证身份后可使用手机端蓝牙直连。
> **维护规则**：**本文档为该项目协议的唯一定义源（Single Source of Truth）。后续逆向解析出新子系统、通信通道、字段定义或握手时序变更时，必须第一时间同步维护并更新本文档。**

---

## 目录
1. [体系架构与协议栈全景](#1-体系架构与协议栈全景)
2. [物理与传输链路层规范](#2-物理与传输链路层规范)
3. [消息信封与帧序列化协议](#3-消息信封与帧序列化协议)
4. [会话生命周期与核心握手状态机](#4-会话生命周期与核心握手状态机)
5. [三大业务通信通道](#5-三大业务通信通道)
   - [5.1 WCS JSON RPC 通道](#51-wcs-json-rpc-通道)
   - [5.2 Wear OS DataItem 状态同步通道](#52-wear-os-dataitem-状态同步通道)
   - [5.3 Samsung Health 双向健康数据通道](#53-samsung-health-双向健康数据通道)
6. [核心业务子系统协议详解](#6-核心业务子系统协议详解)
   - [6.1 系统与基础状态交换 (Internal / Status)](#61-系统与基础状态交换)
   - [6.2 设备护理与电池管理 (DeviceCare / Battery)](#62-设备护理与电池管理)
   - [6.3 官方表盘控制与排序协议 (Watchface)](#63-官方表盘控制与排序协议)
   - [6.4 通知桥接与即时下发协议 (Notification Bridger)](#64-通知桥接与即时下发协议)
   - [6.5 辅助功能与系统设置 (Settings / Accessibility)](#65-辅助功能与系统设置)
   - [6.6 Samsung Health 80+ 模块字典与数据结构](#66-samsung-health-80-模块字典与数据结构)
   - [6.7 媒体控制与桥接协议 (Media Bridging)](#67-媒体控制与桥接协议)
   - [6.8 查找手表协议 (Find My Watch)](#68-查找手表协议)
7. [全局常量、UUID、包名与白名单速查表](#7-全局常量uuid包名与白名单速查表)
8. [调试命令与权威复核诊断手册](#8-调试命令与权威复核诊断手册)
9. [协议演进与维护规范](#9-协议演进与维护规范)

---

## 1. 体系架构与协议栈全景

### 1.1 协议分层模型

```
┌────────────────────────────────────────────────────────────────────────┐
│                          业务子系统 (Subsystems)                        │
│  表盘切换 │ 设备护理/PSM │ 80+健康同步 │ 通知桥接 │ 系统设置 │ 查找手表  │
├────────────────────────────────────────────────────────────────────────┤
│                       多路复用信道 (Multiplexing)                       │
│  WCS JSON RPC (/wcs_extension/...) │ DataItem (Tag 9) │ Health (GZIP) │
├────────────────────────────────────────────────────────────────────────┤
│                    Wearable RPC 信封层 (Protobuf Tag 10)               │
│  Generation 代数重排队列 │ SHA-1 Base64URL 摘要校验 │ 节点与包名鉴权     │
├────────────────────────────────────────────────────────────────────────┤
│                     帧分界层 (Framing & Delimitation)                  │
│               [4-byte Big-Endian Length] + [Protobuf Payload]          │
├────────────────────────────────────────────────────────────────────────┤
│                     传输层 (Bluetooth Transport Layer)                 │
│              Classic Bluetooth (BR/EDR) RFCOMM SCN 5/8 ( ch8 )         │
└────────────────────────────────────────────────────────────────────────┘
```

### 1.2 关键架构定论
1. **纯标准 API 直连**：手机端仅需调用标准 `BluetoothDevice.createRfcommSocketToServiceRecord(UUID)`，无需系统签名、无需 Root、无需厂商私有权限（如 HFP AT 命令或三星自定义蓝牙驱动）。
2. **连接归属与互斥**：本项目已验证的设备在官方组件与本应用同时争用 Wear 数据连接时会出现拒绝连接或反复断线。交接须检查对应型号插件（Watch4=Water、Watch5=Heart、Watch6/7=各自插件）、Galaxy Wearable 与 Google Wear 的实际状态，并保留恢复点；不能只停用 Watch7 插件。SCN 来自 SDP，不由手表代数固定。
3. **两端节点身份拓扑**：
   - **手机节点 ID (`phoneNode`)**：当前手机在 Wear OS 拓扑中的唯一 7~8 位十六进制 ID（如 `<phoneNode>`）。
   - **手表节点 ID (`watchNode`)**：手表端分配的十六进制节点 ID（如 `<watchNode>`）。
   - **发送应用签名摘要**：40 位 SHA-1 Hex，用于标识发送包的签名；Watch7 插件的取值见 `WcsPaths.SIGNATURE_PLUGIN`。

文档中的设备标识使用占位值。当前构建已移除历史 NodeInfo 抓包和回放资产；正常连接使用已登记的手机节点生成 NodeInfo，并重新计算内容摘要。LAB 入口不再发送历史实验帧，REPLAY 需要开发者自行提供本地夹具。

---

## 2. 物理与传输链路层规范

### 2.1 蓝牙服务定义
* **服务 UUID**：`5e8945b0-9525-11e3-a5e2-0800200c9a66`（Google Wear OS 原生 RFCOMM 服务标识）。
* **物理协议**：Bluetooth BR/EDR (Classic Bluetooth) RFCOMM。
* **信道号 (SCN)**：手表 SDP 记录中广播的动态通道，默认实测为 **Channel 8**（部分固件偶见 Channel 5）。

### 2.2 链路帧分界 (Framing)
所有通过 RFCOMM 套接字发送和接收的数据单元均使用**显式长度前缀**分界：
```
 0                   1                   2                   3
 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|                  4-Byte Big-Endian Payload Length             |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|                      Protobuf MessagePiece                    |
|                        (Length bytes)                         |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
```

---

## 3. 消息信封与帧序列化协议

### 3.1 外层信封 (Protobuf `MessagePiece`)
外层 Protocol Buffer 协议结构定义如下：

| Tag 序号 | Wire Type | 字段含义 | 说明 |
|:---:|:---:|:---|:---|
| **1** | Length-delimited | `messageBytes` | 完整 inner，或多片中的当前分片 |
| **2** | Length-delimited | `digest` | 内层载荷的摘要签名（**不可省略**） |
| **3** | Varint | `pieceIndex` | 分片序号，从 1 开始 |
| **4** | Varint | `pieceCount` | 总分片数 |
| **5** | Varint | `queueId` | 队列编号；当前实现的 DataItem 为 `3`，应用消息为 `4` |

DataItem 的 tag9 与应用消息的 tag10 属于 `messageBytes` 内部的消息，
不属于外层 MessagePiece。当前实现分别使用 queue 3 / 4；queue 不是 JSON 请求/响应类型。

### 3.2 Field 2 摘要签名算法（权威公式）
手表端的 WearableService 会严格校验 Field 2 的校验和。若校验失败，帧会被底层直接丢弃，不予分发：
$$\text{Digest} = \text{Base64URL\_NoPadding}\Big(\text{SHA-1}\big(\text{InnerMessageBytes}\big)\Big)$$
* 取内层序列化后的字节数组 `inner`。
* 计算标准 SHA-1 哈希（20 字节）。
* 执行 **Base64URL** 编码（替换 `+` 为 `-`，`/` 为 `_`，并省略末尾的 `=` 填充符）。

### 3.3 内层信封 (Protobuf `WearableMessage` - Tag 10)
Tag 10 内部包含路由与调度元数据：

| Tag 序号 | Wire Type | 字段名 | 含义与取值 |
|:---:|:---:|:---|:---|
| **1** | Varint | `code` | 消息序号，对应内层 MessageId（每次发送自增） |
| **2** | Length-delimited | `senderPkg` | WCS 由 `CompanionProfile` 选择对应代插件；健康使用各自应用身份 |
| **3** | Length-delimited | `signatureDigest` | 发送应用证书 SHA-1；插件共用 `WcsPaths.SIGNATURE_PLUGIN`，不是会话 token |
| **4** | Length-delimited | `destNode` | 目的节点 ID |
| **5** | Varint | 保留字段 | 当前编码为 `0` |
| **6** | Length-delimited | `path` | 业务路径 URI（如 `/wcs_extension/sysui/watchface`） |
| **7** | Length-delimited | `payload` | 业务数据体（UTF-8 JSON 或二进制数据） |
| **8** | Length-delimited | `sourceNode` | 来源节点 ID |
| **10** | Varint | `generation` | **会话代数（重要）**，用于 GMS 乱序与重连排队机制 |
| **13** | Varint | MessageOptions 枚举 | 当前编码为 `1` |

### 3.4 GMS `ReorderingQueue` 与 `Generation` 代数机制
* **丢帧根因分析**：Wear OS GMS 的 `hay.java` / `hbg.java` 为每个 peerNode 维护一个按 `(generation, sequence)` 重排的优先级队列。当发生蓝牙断开重连时，如果客户端的 `sequence` 重置（从 2 开始计数），但 `generation` 保持不变，GMS 会判定所有 sequence 小于上一次会话最大序列号的帧均为**过期历史帧**并执行 `DROPPED` 静默丢弃。
* **规约要求**：
  1. 手机端连接建立（收到 `SyncStart` 时），必须令 `generation = generation + 1`。
  2. 初始 generation 可基于当前时间戳生成：`((System.currentTimeMillis() / 1000) % 80000) + 10`。
  3. GMS 收到新 generation 后，日志会输出 `generation changed, resetting`，重置 `expectedSequence`，确保后续指令秒级执行。

---

## 4. 会话生命周期与核心握手状态机

### 4.1 状态机模型

```
[DISCONNECTED]
      │  BluetoothSocket.connect()
      ▼
[RFCOMM_ESTABLISHED]
      │  TX: Connect (inner tag7，携带已登记手机节点与 wire 版本范围)
      ▼
[CONNECT_SENT]
      │  RX: Connect Response (学习 watchNode；phoneNode 须预先登记)
      │  TX: SyncStart (inner tag8，携带持久复制游标；不是 Message generation)
      ▼
[SYNC_STARTED]
      │  RX: SyncStart Ack & DataItem Dump
      │  TX: Feature Exchange & Set Device Activation
      ▼
[SESSION_READY] (双向可用，心跳维持，自动查询按全局间隔调度，默认 900s)
```

### 4.2 握手消息时序
1. **Connect / NodeInfo**：RFCOMM 成功后发送 inner tag 7 的手机 NodeInfo。已有用户可保留原设备历史身份兼容帧；显式配置的已登记节点由字段重新编码并计算内容摘要。
2. **学习 Node ID**：对端 NodeInfo 用来学习手表节点。手机节点必须是该手表已登记的身份，不能把“本应用生成任意 ID”当成首次登记协议。设备连接引导尝试通过 Google Wear `NodeClient.localNode` 读取本机手机节点；`connectedNodes` 返回远端手表，不能用作手机身份。读取结果和手动输入均为候选，需实际 WCS 业务响应验证后才按配对地址保存。SyncStart 的节点是复制游标来源，不带手机/手表角色，禁止按列表位置更新任一身份。服务不可用、无节点或验证失败必须提供可重试的提示，不把查询成功或 RFCOMM 接通称为接管成功。此查询路径的跨设备兼容性仍待真机验收，首次登记协议仍未实现。
3. **业务初始化与 SyncStart**：确认对端 NodeInfo 后优先初始化业务、更新 Message API generation，并发送带真实本地游标的 SyncStart。两者不能混成同一序号机制。
4. **激活宣告 (Activation)**：发送 `/wcs_extension/internal/connection` 的 `set_device_activation`。握手与手动刷新使用同一手机状态构造器，Locale、时区和系统版本来自当前设备，不使用开发手机的地区、固件或运营商样本。

### 4.3 DataItem 增量游标与启动查询

`SyncStart` 的同步版本与 Message API 的 `generation` 是两套机制。Message 的代数变化只解决消息重排，并不代替 DataItem 复制游标。

- `inner tag 8`：f1 为 V1 对端序号（没有本地副本时为 `-1`），f2 为 repeated `{f1: sourceNode, f2: sequence}`，f3 为版本 `2`。V2 分支依据 f2 的每来源游标查询增量。
- f2 可为空、仅含一项、反序或包含第三个历史来源；它是游标表，不能解释为 local/remote 两个身份。Connect 的 f5 / f6 分别为 peer 最高 / 最低 wire 版本，本应用目前发送 `1 / 0`，并记录实际 peer 范围；该范围与 SyncStart 的版本 `2` 不同。
- 收到的 `inner tag 9`：f5 为来源序号，f6 为删除标志，f7 为来源节点字符串，f9 为发送应用签名。原先将 f7 按嵌套消息解析是不正确的。
- `WearDataSnapshot` schema 2 保存接收到的 DataItem 信封（含删除记录）、每来源完整游标与不完整标记，通过 AtomicFile 整体写入，避免持久化游标领先于数据。文件按手机节点、手表节点隔离；最多保留 10,000 条、累计 8 MiB 信封，编码文件读取上限 16 MiB。淘汰有效条目或单条超限后，省略该来源的游标，其他完整来源仍可增量；删除记录淘汰后保留其序号保护。缺失来源游标表示该来源需全量下发，不能据已淘汰记录的最高序号跳过恢复。来源元数据超限时持久化全量同步标记。
- 旧 schema 1 没有完整性证明，迁移时只恢复预算内条目并清空全部游标；损坏或超预算快照清空后回到全量同步。不完整来源后续重连继续请求全量，可能增加启动流量；不会在同一同步过程中循环请求。
- 禁止继续使用历史抓包中的固定 `589500 / 382268 / 2311` 作为当前复制进度，也禁止用当前时间代替收到的来源序号；两者均不能描述手机已保存的数据。
- 已登记对端的 NodeInfo 到达后即初始化 WCS RPC，再启动 DataItem 同步；不把关键 RPC 挂在可能被文件流延后的 SyncStart 回包之后。`onSessionReady` 主动查询当前表盘、设备资料、电池和表盘排序；对未收到有效响应的项在 2 / 6 / 14 秒进行有限重试。不能依赖用户点击主页刷新按钮才发起这些查询。
- 最近确认的设备资料与表盘另存 `DeviceSnapshot`，重启时先展示；无身份字段的空 ACK 不得清空已知表盘。界面区分缓存展示与本轮刷新。

静态依据：已解包 Wear APK 的 `gyo.b` 构造同步向量、`gyo.e` 选择 V2 分支、`gyn.run` 按节点读取增量、`gyo.f / gyp` 对称写入/读取 DataItem 来源字段。REA `gyo.b` Evidence：`ev_5f782265d75510bba18217c9c6ae3038f61bdc16ad6c86248d2c23605f58bc11`，完整证据位于 `private/startup-investigation/rea-gyo-syncstart.json`。

本地缓存保存 DataItem 元数据，不等于完整 Google Wear 数据库。Asset 文件的接收与确认见 §4.4；首次安装、缓存缺失时仍需完整下发。

### 4.4 Asset 文件流与确认（启动重传根因）

该文件流与 Envelope 分片、健康 Channel API 是三种不同机制：

| inner 字段 | 内容 |
| --- | --- |
| tag 4 `SetAsset` | f1=文件内容的 SHA1 Base64URL 摘要；f2=可选内联文件内容；f3=应用访问元数据 |
| tag 13=true | 原始消息关联一个随后到达的文件流 |
| tag 12 `FilePiece` | f1=原始消息的 SHA1 Base64URL 摘要；f2=是否末块；f3=该块字节；f4=末块携带的整个文件摘要 |
| tag 5 `AckAsset` | f1=已接收文件内容的摘要 |

- `WearAssetReceiver` 以原始消息摘要关联文件块，在末块核对内容摘要、SetAsset 摘要和末块摘要；文件写入 AtomicFile 成功后才回 AckAsset。内联文件同样校验后落盘；仅有元数据时，只在本地存在并校验通过的文件上确认。
- 未完成、摘要不匹配、落盘失败均不确认。每文件 8MiB、接收总内存 32MiB、最多 16 个待完成文件、60 秒空闲超时；换传输连接清掉旧半包。
- 官方 `gty.a / gub` 维护并在重连重发 outstanding SetAsset；`gko.run` 的分支 17 收到 AckAsset 才删除该摘要。此前把 tag 4 / 12 / 13 当未知消息忽略，会导致每次重启再次接收同一批文件，即使 DataItem 游标已更新也仍然慢。
- 接收校验及确认依据：`gze.b`、`yl.run` 分支 9；REA Evidence `ev_8cd7480210b0f6c9fb89fb123838e153e1d4f1fcbe88e958e1fc459d7e62de68`，完整证据位于 `private/startup-investigation/rea-setasset-ack.json`。
- 实机首次保存并确认 23 个文件、总计 1,359,247 字节；下一轮连接的当前表盘 RPC 响应约 108ms、再下一轮约 114ms，旧的 20–30 秒重传不再出现于这两轮。首次/新增文件仍需传输。

已实现文件保存与传输确认；健康 DataItem 的 Asset 引用尚未接到健康 JSON 业务投影，正常健康大包仍走已实现的 Channel API。完整时序记录见 `docs/STARTUP-AND-UI-FIXES.md`。

---

## 5. 三大业务通信通道

### 5.1 WCS JSON RPC 通道
* **路径特征**：`/wcs_extension/...`
* **目标组件**：`com.samsung.android.wcs.extension`（手表端常驻常开服务）。
* **信封格式 (JSON)**：
```json
{
  "msgId": "string",
  "msgType": 0,
  "deviceId": "<watchNode>",
  "sender": "phone",
  "reason": 0,
  "result": 0,
  "data": {}
}
```
* **`msgType` 规范**：
  * `0`：**Query / Get**（查询请求，如获取表盘列表、电量详情）
  * `1`：**Set / Command**（配置写入，如切换表盘、设置灰度）
  * `2`：**Event / Broadcast**（单向通知事件）
  * `3`：**Response / Ack**（应答回执，手表处理完毕后返回）
  * `4`：**State Notice**（系统状态主动推送）

### 5.2 Wear OS DataItem 状态同步通道
* **协议位置**：Protobuf Tag 9（`dataItem`）。
* **URI 规范**：`wear://<phoneNode>/<subsystem>/<item_key>`
* **数据格式**：包含 DataItem 路径、操作类型（`1` = Put / Sync，`2` = Delete）、时间戳以及二进制 DataMap 键值序列。
* **签名凭据要求**：针对特定受保护系统配置（如辅助功能），必须在 DataItem 内层包含正确的签名上下文，否则手表端 `ExclusiveTaskManager` 拒绝应用。

### 5.3 Samsung Health 双向健康数据通道
* **路径**：`/samsung_health/wearable_message`（手表上行常带 `/{seq}` 路由后缀）。
* **GMS 白名单鉴权规则**：
  * **发送包名 (`senderPkg`)**：`com.sec.android.app.shealth`
  * **签名指纹 (`senderNode`)**：`9741a0f330dc2e8619b76a2597f308c37dbe30a2`
* **外层信封结构**：
```json
{
  "message": "REQUEST" | "RESPONSE",
  "type": "DATA",
  "sender": "com.samsung.android.app.shealth.wearable.syncmanager",
  "receiver": "com.samsung.android.wear.shealth.wearable.syncmanager",
  "version": 5.03,
  "sequence_num": 10114,
  "source_node": "com.sec.android.app.shealth",
  "destination_node": "<watchNode>",
  "body": "<Base64 encoded gzip JSON>"
}
```
* **解密算法**：`Base64.decode(body) -> GZIPInputStream -> UTF-8 String -> JSON Array`。
* **三段式握手与游标闭环**：
  1. 手机发起：`message="REQUEST"`, `action="REQUEST_DATA"`。
  2. 手表回传：`message="REQUEST"`, `action="SYNC_DATA"`, sequence=N，携带具体模块数据变更。
  3. 手机应答：`message="RESPONSE"`, `action="SYNC_DATA"`, `result="SUCCESS"`, sequence=N。
  4. 手表上报：`message="REQUEST"`, `action="LOG_DATA"`, sequence=M。
  5. 手机应答：`message="RESPONSE"`, `action="LOG_DATA"`, `result="SUCCESS"`, sequence=M。
  6. 手表本地固化：执行 `HealthDataResolver.insertOrUpdateSync`，提交 `_last_modified_time` 游标。

#### 5.3.1 `device_info` 字段定义
```jsonc
{"device": "BKQ-AN90",        // 手机侧填写本机 Build.MODEL
 "device_type": 10062,         // 10062 = Wear OS 手表能力档（手机侧声明对端能力）
 "version": 4.51,              // 能力协议版本
 "last_sync_time": 1793052221768,
 "start_time": 0,              // 本次同步窗口起点
 "end_time": 1793052221768,    // 本次同步窗口终点
 "is_last_chunk": true}        // 分块传输的末块标记
```

| `device_type` | 设备 | 能力协议版本 |
|:---:|:---|:---|
| 10019 / 10020 / 10022 / 10023 | Gear Fit / Gear1 / Gear2 / Activity Tracker | 1.01 |
| 10024 / 10030 | Tizen Gear1 / Gear S | 2.01 / 3.01 |
| **10062** | **Wear OS 手表（Watch4 及以上）** | **4.51** |
| 0 | 未分类 / 手机侧默认 | — |

#### 5.3.2 游标语义（实测定论）
* 同步游标由**手表端**持有（存于手表 Shealth DB 的 `_last_modified_time`），手机侧无法直接复位。
* 实测把 `start_time` 置 `0`、`last_sync_time` 置当前时间，**并不会**触发手表回补全量历史；手表仍只下发“自上次成功固化以来有变更”的行。
* 因此客户端必须自行持久化最近一次同步到的指标值（步数 / 心率 / 压力），否则重启后会丢失展示数据。
* 少数“活体”表（如 `com.samsung.shealth.stress.histogram`、`com.samsung.health.movement`）每次同步都会因其 `update_time` 被刷新而重发；其 `histogram` / `binning_data` 字段本身是 **Base64(gzip(二进制分箱数组))**。

#### 5.3.3 客户端自动同步策略（0.0.3 新增，待真机复核）

这是手机端调度策略，不是新发现的手表协议能力；沿用上文已验证的 `REQUEST_DATA → SYNC_DATA → LOG_DATA` 载荷。

* RFCOMM 会话就绪后延迟 3 秒发起首次健康请求，此后按全局自动查询间隔请求，默认 900 秒，可选 30 / 60 / 120 / 300 / 600 / 900 秒。关闭自动查询仍保留首次读取与显式手动请求。调度由连接 Repository 持有，不依赖页面可见性；后台与锁屏可继续调度，实际时刻仍受 Android 深度休眠调度影响，不承诺精确闹钟。
* 自动请求、手动按钮和全量刷新共用一个防重入入口。收到手表主动 `SYNC_DATA` 也进入同步中，避免与自动请求重叠。
* 每次 `SYNC_DATA` 分块延长 60 秒等待期限；收到 `LOG_DATA` 请求并排队应答后解除同步中。超时解除占用，可手动重试，也可等待下次自动请求；断线取消任务，重连重新调度。
* 仅对 `message="REQUEST"` 应答 SUCCESS；不对 RESPONSE 再次应答。请求排队与握手进度均不能证明手表最终固化游标，仍需手表日志交叉验证。
* `start_time` 使用本地持久化的最近接收 `SYNC_DATA` 时间；不提供“全量回补成功”的保证。
* 自动全量回补使用独立限频：缺少完整步数覆盖或睡眠原始数据时，成功入队的全量请求至少间隔 1 小时，同一设备重建 Repository 后仍保留该期限；跨本地日期或时钟回拨允许重新尝试。等待期间继续发送增量请求；尚无接收游标时仅查询当天。手动全量补数可立即发起，定向历史查询保留显式窗口，并使用 `last_sync_time=0` 绕过手表的增量游标，不能把指定 48 小时的 `start_time` 改成 `0`。
* 无记录表的控制回包只更新握手与诊断列表，不重算健康历史或重写档案。显式空记录表、真实 `SYNC_DATA` 及此前落盘失败的待重试数据仍走持久化路径，保留持久化成功后 ACK 的次序。
* RFCOMM 的空闲 writer 阻塞等待队列；被动接通后 Client 线程等待断线信号。主动重试从 500 毫秒指数退避至最多 60 秒，连接稳定 30 秒才重置失败计数；BLE 唤醒至少间隔 2 分钟。10 秒协议心跳保持原值，不与用户的数据查询间隔混淆。

#### 5.3.4 手机端健康指标归并（0.0.3 修订，待真机数值交叉验证）

* `pedometer_step_count.count` 是区间步数；按 `datauuid` 去重累计，按测量 `start_time` 归属自然日，缺失时退回更新时间。今天更新的历史区间不能计入今天。
* `pedometer_day_summary` 是全天汇总：优先 `step_count`，其次 `run_step_count + walk_step_count`，再次按 JSON 数组形式的 `binning_data[].steps` 求和。明确的 0 步有效；只有昨日汇总时不作为今日值展示。
* 汇总与区间可能同批到达。客户端用汇总的 `update_time` 作为覆盖边界：区间 `end_time <= 边界` 时只记去重身份，不再次累加；之后的区间继续增加。缺失时间戳时使用兼容兜底，边界假设仍需真机全天数值复核。边界和去重身份随健康缓存持久化，保留当日身份集合，不因 500 条上限淘汰而重复累计。
* 跨天清空步数、热量、距离及当日累计器；连接期间每分钟检查一次，接收健康包与重连时也检查。离线重启只恢复同日缓存。
* 今日热量、距离只采用全天汇总，不能用最新一条区间的热量/距离覆盖当天总量。收到 `SYNC_DATA` 即更新时间，即使指标没有变化也持久化去重信息；这表示收到同步数据，不表示手表游标提交已核实。
* 基础健康通道的既有实机证据不等于本次调度和归并策略已在真机验证；本次自动化验证记录见 `docs/REVIEW-0.0.3.md`。

---

## 6. 核心业务子系统协议详解

### 6.1 系统与基础状态交换
* **`/wcs_extension/internal/connection`**
  * 指令：`set_device_activation`（`msgType=1`）
  * 作用：宣告手机应用已在线，激活手表侧所有子系统的 EventListener。
* **`/wcs_extension/internal/feature`**
  * 指令：`feature_exchange`（`msgType=0` 查询，`msgType=3` 响应）
  * 作用：交换双方固件支持的特性集（包含 736 项系统能力掩码）。
* **`/wcs_extension/internal/status`**
  * 指令：`status_exchange`
  * 作用：上报手表国家码（`countryCode`，如 `"CN"`）、eSIM 识别码（`eid`）、Google Play Services 版本等关键系统指纹。
* **`/wcs_extension/internal/p2p`**
  * 指令：`wifi_p2p_feature`
  * 作用：Wi-Fi Direct 高速直连信道协商。

### 6.2 设备护理与电池管理
* **`/c_devicecare/battery/base`**
  * 下发查询：`msgType=0`
  * 响应字段：
    * `level` / `battery_level` (int)：当前电量百分比（0~100）。
    * `status` (int)：充电状态（1=充电中, 2=放电中, 3=已充满）。
    * `time_remaining` (long)：充至 100% 预计剩余毫秒数。
    * `rut_psm_off` (int)：常规模式下电池预估可用分钟数。
    * `rut_psm_on` (int)：省电模式开启下预估可用分钟数。
* **`/c_devicecare/battery/psm` (省电模式切换)**
  * 指令：`msgType=1`，`data={"enable": true|false}`
  * 异步回执通道：`/c_devicecare/battery/psm`，`extraData=1` (已开启) 或 `0` (已关闭)。
  * 注意事项：PSM 切换涉及手表多核调频与显示重载，回执通常在 1~25 秒内异步返回。
* **`/c_devicecare/memory/usage` (运行内存)**
  * 响应字段：
    * `mem_total`：RAM 总量字节数（如 1,846,980,608 B ≈ 1.76 GB）。
    * `mem_available`：可用内存字节数。

### 6.3 官方表盘控制与排序协议
* **通信路径**：`/wcs_extension/sysui/watchface`
* **手表端处理宿主**：`com.samsung.android.wcs.extension.application.gms.WatchfaceApiStub`

#### 6.3.1 核心指令与格式

1. **查询当前表盘与收藏列表 (`watchface_order`)**
```json
// TX: 手机请求
{"msgId":"watchface_order","msgType":0,"deviceId":"<watchNode>","data":{}}

// RX: 手表应答 (msgType=3)
{
  "msgId": "watchface_order",
  "msgType": 3,
  "result": 0,
  "data": {
    "WatchFaceOrderType": "recent",
    "favoriteIdOrderList": [5, 1, 4, 3]
  }
}
```

2. **切换活跃表盘 (`change_active_watchface`)**
```json
// TX: 手机写入请求 (msgType=1)
{
  "msgId": "change_active_watchface",
  "msgType": 1,
  "deviceId": "<watchNode>",
  "data": {
    "packageName": "com.samsung.android.watch.watchface.ultrainfoboard",
    "className": "com.samsung.android.watch.watchface.ultrainfoboard.UltraInfoBoardWatchFaceService"
  }
}

// RX: 手表应答 (msgType=3)
{"msgId":"change_active_watchface","msgType":3,"result":0,"data":{}}
```

#### 6.3.2 官方表盘库映射字典 (Watch Face Presets)

| 表盘名称 (中文) | 表盘预设 ID | 包名 (`packageName`) | Service 类名 (`className`) |
|:---|:---|:---|:---|
| **极限信息板** | `ultra_info_board` | `com.samsung.android.watch.watchface.ultrainfoboard` | `...ultrainfoboard.UltraInfoBoardWatchFaceService` |
| **极限指针** | `ultra_analog` | `com.samsung.android.watch.watchface.ultraanalog` | `...ultraanalog.UltraAnalogWatchFaceService` |
| **模块化指针** | `analog_modular` | `com.samsung.android.watch.watchface.analogmodular` | `...analogmodular.AnalogModularWatchFaceService` |
| **经典指针** | `classic_adventurer` | `com.samsung.android.watch.watchface.classicadventurer` | `...classicadventurer.ClassicAdventurerWatchFaceService` |
| **数字画板** | `digital_board` | `com.samsung.android.watch.watchface.digitalboard` | `...digitalboard.DigitalBoardWatchFaceService` |
| **信息指针** | `info_modular` | `com.samsung.android.watch.watchface.infomodular` | `...infomodular.InfoModularWatchFaceService` |
| **运动健康面板** | `activity_tracker` | `com.samsung.android.watch.watchface.activitytracker` | `...activitytracker.ActivityTrackerWatchFaceService` |
| **极简数字** | `simple_classic` | `com.samsung.android.watch.watchface.simpleclassic` | `...simpleclassic.SimpleClassicWatchFaceService` |
| **经典高级** | `premium_analog` | `com.samsung.android.watch.watchface.premiumanalog` | `...premiumanalog.PremiumAnalogWatchFaceService` |
| **动态天气** | `weather_center` | `com.samsung.android.watch.watchface.weathercenter` | `...weathercenter.WeatherCenterWatchFaceService` |
| **世界时钟** | `world_clock` | `com.samsung.android.watch.watchface.worldclock` | `...worldclock.WorldClockWatchFaceService` |
| **呼吸与舒缓** | `breathing` | `com.samsung.android.watch.watchface.breathing` | `...breathing.BreathingWatchFaceService` |
| **渐变流光** | `gradient_modular` | `com.samsung.android.watch.watchface.gradientmodular` | `...gradientmodular.GradientModularWatchFaceService` |
| **活力条纹** | `stripe_digital` | `com.samsung.android.watch.watchface.stripedigital` | `...stripedigital.StripeDigitalWatchFaceService` |
| **大字时间** | `large_digits` | `com.samsung.android.watch.watchface.largedigits` | `...largedigits.LargeDigitsWatchFaceService` |

#### 6.3.3 推荐表盘推送通道（手表 → 手机）
* **路径**：`/w_watchface_home/watchface/msg`
* **方向**：手表主动下发（手机侧 `type=4` 收到）
* **载荷**：
```jsonc
{
  "msgId": "watchface_recommend_list_send",
  "watchface_recommend_list": ["com.samsung.android.watch.watchface.ultrainfoboard_0"]
}
```
* 该通道用于推送三星运营位推荐的表盘（末尾 `_N` 为数据层里的配置序号），可与 `addable_watchface_info` 配合做「推荐表盘」展示。

#### 6.3.4 表盘效果图的获取方式（重要限制）
* 手表 Display 带 **`FLAG_SECURE`**，`adb shell screencap` 只能拿到黑色/纯色画面（实测 UI 层级里有真实内容但截图为空），**无法用截屏生成表盘预览图**。
* 可靠来源：Galaxy Wearable 插件（`com.samsung.wearable.watch7plugin`）内置的官方表盘效果图：
  `assets/Category_watchface/<packageName>.<ServiceSimpleName>.webp`（360×360 RGBA）。
* 由此还能反推出每个表盘的准确 Service 类名 —— 文件名前缀即包名，后缀即类名。
* 本项目用 `scripts/gen_watchface_assets.py` 把这些 webp 转成 `drawable-nodpi/wf_<id>.webp` 并自动生成 `WatchFacePreset.kt`。

#### 6.3.5 表盘排序方式写入（已实机验证）
* **msgId**：`watchface_order_type`，**msgType=1 为写请求**、`3` 为回执。
* **载荷映射**（对应手表端 `WatchfaceApiStub.setWatchfaceOrderTypeWithSync(type)`）：

| `type` | `WatchFaceOrderType` | `isWatchSortByRecentsEnabled` | 含义 |
|:---:|:---|:---:|:---|
| 0 | `custom` | `false` | 自定义顺序 |
| 1 | `recent` | `true` | 最近使用优先 |
| 2 | `alphabetic` | `false` | 字母序 |

* 实机回执：`{"msgId":"watchface_order_type","msgType":3,"result":0,"reason":0,"data":{}}`，
  随后 `watchface_order` 的 `favoriteIdOrderList` 会按新模式重排。

#### 6.3.5.1 表盘「数据位 / 复杂功能」配置能力边界（重要结论）

**结论：三星 WCS 直连协议不提供表盘数据位的远程读/写能力。**

证据一 —— 手表端只接受 5 个 msgId（`WatchfaceApiStub.onMsgRecvListener` 反编译，`default` 分支直接抛 `unknown msg id`）：

| 常量 | msgId | 可选 msgType |
|:---|:---|:---|
| `MSG_ID_WATCHFACE_ORDER` | `watchface_order` | 0 查询 / 1 变更通知 |
| `MSG_ID_WATCHFACE_ORDER_TYPE` | `watchface_order_type` | 0 查询 / 1 写入 |
| `MSG_ID_WATCHFACE_ACTIVE` | `change_active_watchface` | 0 查询 / 1 写入 |
| `MSG_ID_ADDABLE_WATCHFACE_INFO` | `addable_watchface_info` | 0 查询 / 1 推送 |
| `MSG_ID_WATCHFACE_LAUNCH` | `watchface_launch` | **仅 3（回执）** |

证据二 —— `watchface_setting` 只是**手表本地 SharedPreferences 的名字**（`WatchfaceSettingProvider`，authority `com.samsung.android.wcs.extension.provider.watchface`，唯一 path `order_type`），不是远程配置通道。

证据三 —— `watchface_launch` 实测：手机 → 手表发 `msgType=1` 直接失败：
```json
{"msgId":"watchface_launch","msgType":3,"result":-1,"reason":-1,"data":{}}
```
因为 `handleWatchfaceLaunchMessage` 只处理 `msgType==3`，说明它的真实方向是 **手表 → 手机**：
用户在手表上点「在手机上编辑表盘」时，手表发 `watchface_launch` 请求，手机侧伴侣 App 打开编辑器后回 `msgType=3`。

证据四 —— `addable_watchface_info` 实测只返回角标：
```json
{"msgId":"addable_watchface_info","msgType":1,"data":{"watchfaceBadgeList":"[]"}}
```
不含数据位定义。

**真正的数据位编辑链路在哪？** 在 Google 的 Wear OS 伴侣 SDK（Galaxy Wearable 插件内嵌）：
* `com.google.android.libraries.wear.companion.watchfaces.editor.LiveWatchFaceEditor`
  （`startEditing` / `getComplicationSlots` / `setComplication` / `setStyle` / `saveChanges` / `getPreview`）
* 实现体在 GMS 私有包 `com.google.android.gms.internal.wear_companion.*`，走独立的 GMS Wearable RPC
  （相关路径串：`/wearservices/watchface/resync`、`/wearservices/sync/available_watchface`），
  而不是三星 WCS 通道；GMS 侧按调用方包名做门控。

因此本项目**不再尝试伪造该链路**，而是：
1. 表盘选择 / 收藏排序 / 排序方式 走 WCS（已全部打通）；
2. 数据位与配色样式引导用户在手表上「长按表盘 → 编辑」完成；
3. 监听手表侧 `watchface_launch` 请求并给出对应引导。

> 若要继续攻这条线，下一步应做：在装有官方 Galaxy Wearable 的手机上抓 HCI Snoop，过滤
> `/wearservices/watchface/`，反解 `startEditing`/`setComplication` 的 protobuf 字段号，
> 再用本项目 RFCOMM 通道复刻 —— 属于独立的大工程，需单独立项。

#### 6.3.5.2 GMS Wearable 路线实测结论（2026-10-27）

按「复刻 Google 伴侣编辑器」这条线做了一轮真机探测，记录如下（负结果同样重要）。

**探测手段**：本项目内置 `WearApiTransport`（`com.google.android.gms.wearable.MessageClient`），
诊断广播：

```bash
adb shell am broadcast -n dev.ricky.galaxywatchmanagerfree/.core.WatchCommandReceiver \
  -a dev.ricky.galaxywatchmanagerfree.CMD --es cmd wearapi_start
adb shell am broadcast ... --es cmd wearapi_send --es path /wearservices/sync/available_watchface \
  --es b64 <Base64(payload)>
```

| 步骤 | 现象 | 结论 |
|---|---|---|
| 1 | 官方三件套全部 `enabled=3`（DISABLED_USER）时调用 Wearable API | `ApiException 17: Wearable.API is not available on this device` |
| 2 | `pm enable com.google.android.wearable.app.cn` 后重试 | **成功**：`已连接的 Wear 节点: 1 / id=<watchNode> name=Galaxy Watch Ultra (<watchSuffix>)` |
| 3 | 向 `/wearservices/sync/available_watchface` 发送 `{"version":1,"type":"available_watchface"}` | 手机侧 `ok=true`；手表侧 GMS 日志：`WearableService: Failed to deliver message to AppKey[...]; Event[onMessageReceived, action=/wearservices/sync/available_watchface, dataSize=42, source=<phoneNode>]` |
| 4 | 再次重启后重试 | 又回到 `API_UNAVAILABLE`，不可稳定复现 |

**要点解读**

1. **第三方 App 确实能用同一条 GMS 传输**（步骤 2/3 证明了），前提是本机存在可用的 Wear 伴侣后端。
2. 消息**上行成功但投递失败**：手表端 GMS 收到了 `/wearservices/sync/available_watchface`，但手表上没有任何应用注册这个路径前缀，所以 GMS 无处投递 → 这条 MessageApi 路径在这台手表上是死路。
3. CN 版 Wear OS 应用（2.68.201 CN）会明确把三星手表引导回 Galaxy Wearable：
   `Wear3WatchActivity` 显示「您有 Samsung 手表吗？您可以使用 Galaxy Wearable 应用管理自己的手表」，
   即 CN 固件上 Google 伴侣**不承担**三星手表的表盘管理职责。
4. 海外 GMS 设备上的伴侣编辑器由 GMS 私有库承载
   （`com.google.android.gms.internal.wear_companion`，4414 个混淆类，无可用字符串常量，
   请求走 `IWearableService` + 私有 protobuf，非 MessageApi 路径），
   且要求官方 Wear 伴侣完成配对。

**结论**：在 CN 固件 + 非三星手机的既有形态下，**远程数据位/样式配置没有可用的技术路径**。
表盘数据位仍须在手表上完成编辑；本项目保留上述诊断广播，便于将来换到海外 GMS 设备后继续探测。

### 6.4 通知桥接与即时下发协议
* **通道规范**：Wear OS 原生 Bridger DataItem
* **URI 格式**：`wear://<phoneNode>/bridger/stream_item:<notification_key_hash>`
* **数据结构 (DataMap Payload)**：
  * `title` (String)：通知标题。
  * `content` / `text` (String)：通知正文内容。
  * `package_name` (String)：发起源应用包名（如 `com.tencent.mm`）。
  * `app_name` (String)：应用友好显示名（如 `"微信"`）。
  * `post_time` (long)：发信时间戳。
  * `id` (int)：通知 ID。
  * `icon` (byte[])：应用图标 PNG/WebP 压缩二进制字节流。
  * `vibrate` (boolean)：是否触发手表马达震动。
  * `actions` (DataMap[])：快速回复或操作按钮列表。

### 6.5 辅助功能与系统设置
* **灰度模式 (Grayscale / Daltonizer)**
  * 通道：Tag 9 DataItem
  * Key：`accessibility_display_daltonizer_enabled`
  * 取值：`0` = 关闭（彩色显示）；`1` = 开启（全局黑白灰度显示）。
  * 生效验证：手表底层 SurfaceFlinger 与 Dalvik ExclusiveTaskManager 实时套用灰度着色矩阵。
* **高对比度文字 (High Contrast Text)**
  * Key：`high_contrast_font` (0/1)。
* **亮度调节 (Brightness)**
  * 路径：`/w_module_sec_watch_setting/screen_brightness`
  * 取值：`0 ~ 255`。
* **息屏显示 (AOD)**
  * Key：`aod_mode` (boolean)。
* **抬腕亮屏 (Wake on Wrist)**
  * 路径：`/w_module_sec_watch_setting/display/wake_on_wrist_raised` (int / boolean)。
* **触摸灵敏度 (Touch Sensitivity)**
  * 路径：`/w_module_sec_watch_setting/display/touch_sensitivity`。

#### 6.5.1 设置写入与界面反馈

手机通过 Tag 9 DataItem 写入设置；常规新建设置使用 `wear://<phoneNode>/w_module_sec_watch_setting/...`，名称条目的读改写保留下文所述的原始 URI。来源为手机的 DataItem 自回声不能作为手表确认；部分设置修改后未观察到独立确认回包。

当前客户端在常规设置成功进入发送队列后乐观更新显示，并通过 `dataitem_value_req` 请求回读。真实手表回报仍会校正显示；排队成功和界面变化均不证明手表已经执行。最新抬腕亮屏修复仍需实机复测，不能把该行为概括成所有 Wear OS 版本均不回包。

手表名称使用 `/w_module_sec_watch_setting/info/setting_info/watch_name` 的 `stringName`。已逆向的 Watch7 Plugin `WatchStatusMessageSender.sendWatchName` 以手表 `peerId` 为 authority，通过 `DataClient.getDataItem` 查询手机端的本地 DataItem 数据库，再由 `sendWatchName$lambda$9` 通过 `F.c(v.a(item))` 保留返回条目的完整 URI 和 DataMap，仅修改 `stringName` 和 `from=phone`；原有 `key`、`type`、`time` 及其他字段保留。Wear 服务 `hnf.a` 保留显式 URI host，`gyg.e` 按 host 和 path 查找或创建条目，URI 所属节点不能与发送节点混同。

客户端保留从持久化快照恢复或在会话中收到的当前手表名称条目；重命名直接用该条目读改写，只有尚无模板时才请求 `dataitem_value_req`。名称条目的 URI owner 与 DataMap 的 `from` 是不同维度：只要 URI 属于当前手表且 `stringName` 有效，`from=phone` 的最近写入条目也能提供读改写模板，但不能更新已确认的手表名称或确认写入。仓库在通用设置的手机自回声过滤之前把完整名称条目交给 `WatchNameSync`；通用设置仍拒绝手机自回声。不能依赖读取请求重新产生内容相同的条目：手机 Wear 服务 `gyi.e` 会丢弃 payload 和 assets 相同的更新，且已逆向的请求没有强制刷新参数。模板必须属于当前手表节点，手机节点或其他节点的同路径数据不能成为模板；DataItem URI owner 不参与会话对端身份学习，仅 NodeInfo 更新对端节点。完整原 URI 在接收、状态处理及 WCS 发包中保留，帧的 sourceNode 仍为手机节点。写入后才请求回读，只有原 URI 上匹配目标名称的非手机自回声才能确认；首次读取或缓存名称即使匹配也不直接提示成功。

本机显式保存的昵称与手表上报名称分开：已有本机昵称优先于蓝牙缓存，旧回包不覆盖昵称或其持久化值；未设置本机昵称时仍可展示手表名称。断线取消未完成操作及待确认 URI，保留按手表节点验证的本地名称条目，以支持同一 WCS 会话自动重连；换节点时拒绝旧模板。新会话可在就绪前接收当前配对快照，连接就绪后重新同步本机昵称。未取得模板超时明确提示尚未发送改名；写入进入发送队列后，若 4 秒内没有匹配回读则返回 `SUBMITTED`，中性提示“改名请求已提交，请在手表上查看名称”，不要求重试，也不将排队成功作为设备执行确认。只有匹配回读才返回 `CONFIRMED` 并提示手表已重命名。

`0.0.33.001` 和 `0.0.33.002` 均收到真机未改名反馈；`0.0.33.003` 用户确认应用改名成功、手表系统名称也已变化，但 Toast 仍提示手表未确认，表明改名生效与本地确认超时可以同时发生。`0.0.33.004` 仅修正该超时反馈，随后用户反馈无法改名，实际提示为“未取得手表原始名称数据”，对应尚未写入的 `SOURCE_UNAVAILABLE`。两版源码及实际 APK 的名称接收、读取与写入逻辑一致；合成快照回放复现了 `from=phone` 最近名称条目被两层过滤、重启后零写入的既有缺陷，`0.0.33.005 Nightly` 修正允许其提供模板，用户随后反馈改名问题已解决，并要求发布正式版，该实现纳入 `0.0.34`。合成回放不是用户本次真机数据，仍未取得本次回包，不能据此断定真机触发前提已完全确认；重连与重启后的持久化仍待单独验收。现有 `research/decompiled/wear` 是手机 Wear 服务，尚无手表名称接收组件 APK，不能据此确认最终调用的系统改名 API。

#### 6.5.2 远程 Intent RPC 通道 (`/remote_intent/rpc`)

发送端的通用远程 Activity 请求通过 Google Wear DataMap 编码以下字段；v0.0.27–0.0.28 曾将其用于血压入口：

| 字段 | 编码值 |
| --- | --- |
| `action` | Intent action；旧血压入口使用 `android.intent.action.MAIN` |
| `package_name` | 目标应用包名：`com.samsung.android.shealthmonitor` |
| `class_name` | 旧血压入口填写 `com.samsung.android.shealthmonitor.bp.ui.activity.BpMainActivity` |
| `component_name` | `<package_name>/<class_name>` |
| `categories` | 字符串数组；旧血压入口使用 `android.intent.category.LAUNCHER` |
| `start_mode` | 整型 `0`（Activity） |
| `com.google.android.clockwork.actions.RpcWithCallback.invocation_id` | 每次请求生成的 UUID |
| `extras` | 非空时编码为嵌套 DataMap |

对已检查接收端的静态分析表明，`class_name` 不参与目标 Activity 选择；`MAIN` 会打开应用根入口，不能保证进入 `BpMainActivity`。与 `/991` 同时启动 SHM 不同模块 Activity，可能触发其跨模块 `finishAffinity()` 退出任务栈。用户日志包含这两条并发路径，但没有手表 crash 堆栈；这一因果判断来自静态分析。2026-11-04 真机确认：v0.0.29 移除该并发路径后，手表端不再闪退，完整三轮袖带校准可正常走完。

v0.0.29 的 BP 校准与测量已移除远程 Intent 启动，仅使用 `/991` measuring 通道。三轮校准时序及参数见下文「BP 官方校准 / 测量控制动作」。

### 6.6 Samsung Health 80+ 模块字典与数据结构

手表端 `com.samsung.android.wear.shealth` 导出的完整健康数据模块索引表（均支持增量游标同步）：

| 序号 | 模块名称 (Module Key) | 业务含义 | 关键数据字段 |
|:---:|:---|:---|:---|
| 1 | `com.samsung.shealth.tracker.pedometer_step_count` | 计步**区间增量**明细（非全天总数） | `count`, `calorie`, `distance`, `speed`, `walk_step`, `run_step`, `datauuid` |
| 1b | `com.samsung.shealth.tracker.pedometer_day_summary` | 计步**全天汇总**（当日总步数以此为准） | `step_count`, `run_step_count`, `walk_step_count`, `calorie`, `distance`, `binning_data`, `day_time` |
| 2 | `com.samsung.shealth.tracker.heart_rate` | 连续心率测量 | `heart_rate`, `max_heart_rate`, `min_heart_rate`, `status` |
| 3 | `com.samsung.shealth.stress` | 压力测量 | `score` (0-100), `status`, `start_time`, `end_time` |
| 4 | `com.samsung.shealth.stress.histogram` | 压力区间柱状分布 | `histogram_data`, `binning_data` |
| 5 | `com.samsung.shealth.oxygen_saturation` | 实时与睡眠血氧饱和度 | `spo2` (百分比), `heart_rate` |
| 6 | `com.samsung.shealth.skin_temperature` | 手腕皮肤温度监测 | `temperature` (摄氏度) |
| 7 | `com.samsung.shealth.respiratory_rate` | 呼吸频率监测 | `breath_rate` (次/分) |
| 8 | `com.samsung.shealth.sleep` | 睡眠记录主表 | `start_time`, `end_time`, `quality_score`, `duration` |
| 9 | `com.samsung.shealth.sleep_stage` | 睡眠分期详情 | `stage` (清醒/浅睡/深睡/REM), `start_time` |
| 10 | `com.samsung.shealth.exercise` | 运动健身记录 | `exercise_type`, `duration`, `calorie`, `distance` |
| 11 | `com.samsung.shealth.floors_climbed` | 爬楼层数统计 | `floor_count`, `calorie` |
| 12 | `com.samsung.shealth.best_records` | 运动最佳成就 | `record_type`, `record_value`, `achieve_time` |
| 13 | `com.samsung.shealth.badge` | 获得勋章与里程碑 | `badge_id`, `badge_type`, `issue_time` |
| 14 | `com.samsung.shealth.service_preferences` | 健康服务用户偏好 | `target_steps`, `unit_system`, `alert_configs` |
| 15 | `com.samsung.health.hrv` | 心率变异性 | `rmssd`, `sdnn` |
| 16 | `com.samsung.shealth.body_composition_goal` | 身体成分目标 (体脂/骨骼肌) | `target_fat_mass`, `target_skeletal_muscle` |

#### 6.6.1 计步语义陷阱：`step_count` ≠ 全天总步数（实测坑）

**已完成实机对齐**：2026-10-27 手表 4269 步、App 原为 3270 步。补齐大包通道后取得
完整 100 条原始记录，排除昨日 18 步，今日 99 条合计 4269；App 已据此自动重建为 4269。

| 模块 | 语义 | 正确用法 |
|---|---|---|
| `tracker.pedometer_step_count` | 计步区间记录，不能把最新一条当成全天总数 | 按 `datauuid` 保存 count / update_time；同 UUID 修订以差额替换旧贡献，重复包不重算 |
| `tracker.pedometer_day_summary` | 全天汇总的数据类型定义；本轮未观察到该手表上行该类型 | 若收到当日汇总，可用 `step_count` 或 `run_step_count + walk_step_count`；不能假定此固件必发 |

**曾经的错误实现**：取 `pedometer_step_count` 里 `update_time` 最新的一条，把它的 `count`
当成「今天走了多少步」。因为手表给手机的增量游标只推送**最近这一段**的记录，
这个值实际等于「最近一个区间的步数」，表现出来就是「App 只统计连接之后走的步数」。

**当前实现**（`HealthStepParser`，新增 7 条记录修订回归测试）：

1. 优先取 `pedometer_day_summary` 的当日总步数（`step_count` → `run+walk` → `binning_data` 求和兜底）；
2. 收到汇总时用它**校准累加器**（`seedAccumulator`），否则汇总之后走的步数会被展示上限吞掉；
3. 没有汇总时合并区间记录；对同一 UUID 的新版本只应用 `新 count - 旧 count`，拒绝过期版本，持久化每条贡献；
4. 过滤非今日记录，避免手表补发的历史数据污染今日；
5. 通常使用 `max(汇总, 累计, 已显示值)`；明确的区间向下修订允许纠正展示值，避免旧错误值永久锁定；
6. 跨自然日自动归零（长驻前台运行时也生效）。

> **实机验证后的修正**：当前固件可通过 `REQUEST_DATA.last_sync_time=0` 重置手表发送
> 标记表并回补历史记录；此前的“不能全量回补”结论错误，根因是大包改走 GMS Channel API。
> 官方手表 APK 在序列化消息 >= 92160 字符时走该通道，小消息才走 MessageClient。
> 这次无需 `pedometer_day_summary`，直接按今天的完整区间记录求和即为 4269。
>
> 旧缓存没有每条 count，单靠 UUID 增量合并不足以纠正旧基线。现在显式请求冷同步，
> 汇集 `start_time=0` 开始的数据窗，等 `is_last_chunk=true` 才按今日记录最新版本重建总数。
> 完整覆盖标志和区间贡献持久化后恢复普通增量；不能把任何未经请求的零起点包当成完整快照。
> 全部证据、REA Evidence ID 和实机夹具见 [步数缺口调查](../research/STEP-COUNT-INVESTIGATION.md)。

#### 6.6.1.1 健康大包：Wear Channel API（实机验证）

- Channel RPC 使用 `inner tag 16`；其内部 WearableMessage 的 **f9** 是 ChannelRequest，
  与普通 `inner tag 10 / f7` 的业务 JSON 不同。
- ChannelRequest：f2=control、f3=data、f4=data_ack、f6=minimum_version、f7=origin。
- control：f1 类型（1=open / 2=open_ack / 3=close）、**f2=fixed64 channelId**、
  f3=from_channel_opener、f4=package、f5=signature、f6=path、f8=allow_over_metered。
- data：f1=header、f2=payload、f3=final_message；header 的 f1 是 fixed64 channelId，
  f2 是发送方是否为 opener，f3 是从 0 开始的块序号。
- data_ack：f1=header、f2=final_message。接收方 ACK 的 from_channel_opener=false，
  序号回显当前数据块序号（不是字节偏移），重传块不重复拼入。
- 回传 Channel RPC 必须保留原通道的 AppKey：此固件为
  `com.samsung.android.wear.shealth` / `9ca5170f381919dfe0446fcdab18b19a143b3163`。
  用手机健康包与证书身份发送普通业务消息的规则不适用于该 Channel ACK。
- 大块仍受外层 Envelope 分片：实机每片最多 12288 字节，f3=片序号（从 1 开始）、
  f4=总片数。先拼接全部 f1，再核验 f2 的 Base64URL(SHA1(inner))，最后解析 inner。
- 完整通道流承载的是健康外层 JSON（body 仍为 Base64(gzip(JSON))），走同一健康解析与
  SYNC_DATA/LOG_DATA SUCCESS 回执；无需安装官方手机伴侣，不依赖手表 ADB。
- 实机收到 581344 字节、10 个 Channel 数据块。片段接收/通道累计均有容量和超时限制。


#### 6.6.3 大包中其他健康模块的真实字段与映射

从真机捕获的 581 KB 大包（`channel-features.json`）解出的真实记录结构与兼容规则：

| 模块 | 关键字段 | 兼容处理 |
|---|---|---|
| `com.samsung.health.respiratory_rate` | `average`、`upper_limit`、`lower_limit`、`binning_data` | 顶层 `average` 为整段均值；`binning_data` 包含逐分钟 `respiratory_rate` |
| `com.samsung.health.skin_temperature` | `temperature`、`mean`、`min`、`max`、`binning_data` | `temperature` 与 `mean` 等价；`binning_data` 包含逐分钟采样 |
| `com.samsung.shealth.tracker.oxygen_saturation` | `spo2`、`min`、`max`、`binning` | `binning` 为逐分钟血氧分箱 |
| `com.samsung.health.hrv` | `binning_data`（无顶层值） | 必须解包 Base64(gzip(JSON)) 获取逐段 `rmssd` 与 `sdnn` |
| `com.samsung.health.floors_climbed` | `floor`、`start_time`、`end_time` | 字段名为 `floor`（浮点或整数），不是 `floor_count` |
| `com.samsung.shealth.sleep` / `com.samsung.health.sleep_stage` | `sleep_id`、`sleep_uuid`、`datauuid` | 手表端分期记录用 `sleep_id` 关联主会话，与旧版 `sleep_uuid` 兼容 |
| `com.samsung.shealth.exercise` | `exercise_type`、`duration`、`calorie`、`distance`、`mean_heart_rate` | 已结束运动记录，直接解析 |
| `deleted_data` | `delete_time`、`data_type` | 手表端物理删除通知，本轮暂不参与求和 |

#### 6.6.4 通道无关的统一记录仓储架构

为避免 Message API、Channel API、分片重组及未来可能的 DataItem 载体各自维护派生状态，
健康子系统采用**两层架构**：

1. **`HealthRecordStore`（记录层）**：只按 `datauuid` + `update_time` 保存原始记录条目，
   支持修订替换、跨日自动清理与容量上限，不直接保存预聚合的统计数字。
2. **`HealthDataProjection`（投影层）**：在完整记录集合上单向推导心率曲线、睡眠分期、
   指标采样、活动分布与日统计。重发报文只刷新原始条目，不破坏已推导统计的正确性。


| 字段 | 位置 | 含义 | 处理方式 |
|---|---|---|---|
| `recommendation` | `pedometer_day_summary` | 手表给出的每日步数建议值（实机样本 `6000`） | 作为默认目标；长名 `com.samsung.health.step_count.recommendation` 兼容 |
| `target_steps` | `com.samsung.shealth.service_preferences` | 用户在三星健康里设置的步数目标 | 优先于 `recommendation`；长名 `com.samsung.health.service_preferences.target_steps` 兼容 |
| `binning_data[].index` | `pedometer_day_summary` | 当天第 N 个 **10 分钟桶**（0–143） | `hour = index * 10 / 60`，聚合成 24 小时分布 |
| `binning_data[].steps` | 同上 | 该桶新增步数 | 缺失时退化为 `run_steps + walk_steps`，再退化为 `count` |

目标优先级（应用侧 `HealthGoals`）：**本机设定 → 手表 `target_steps` → 手表 `recommendation` → 6000**。
取值范围与官方目标选择器一致：1,000–50,000 步、100 步进；应用内调整只影响本机展示，不回写手表。

`binning_data` 与其他模块不同：计步的 `binning_data` 是 **JSON 数组**（字段见上表），
不是 Base64(gzip) 二进制，因此可以直接解析，无需解包。
若同一批报文同时带分桶与区间明细，两者描述同一批步数，**逐小时取最大值而非相加**，避免重复计数。

里程碑与连续达标阈值取自 Samsung Health 步数奖励规则（`RewardConstants.RewardKey`，
见 `research/decompiled/shealth/sources/com/samsung/android/app/shealth/constant/RewardConstants.java`）：

* 单日里程碑：`10K / 20K / 30K / 40K` 步（`step_milestone_*_steps`）；
* 连续达标徽章：`7 / 14 / 21 / 28` 天（`step_streak_*_week_streak`）。

应用自行用本地逐日历史计算连续达标（手表不下发历史汇总），今日未达标不算断链；缺失日期视为断链。

#### 6.6.4 心率采样与历史口径

| 字段 | 位置 | 含义 |
|---|---|---|
| `start_time` | `tracker.heart_rate` 记录 | 本次测量（或该段均值）的起点，作为采样点时间 |
| `heart_rate` | 同上 | 该次测量值；长名 `com.samsung.health.heart_rate.heart_rate` 兼容 |
| `min` / `max` | 同上 | 连续测量区间最低/最高值，不能由区间均值代替 |
| `binning_data` | 同上 | 本固件实测为 Base64(gzip(JSON 数组))，每项含 `heart_rate`、`heart_rate_min`、`heart_rate_max`、`start_time`、`end_time`；原始顺序可为倒序 |

处理口径（`HeartRateLog`）：

1. 有有效 `binning_data` / `binning` 时展开明细并跳过外层汇总；无有效明细时保留真实外层记录。点保留 `(start_time, heart_rate, minBpm, maxBpm)`；缺少测量 `start_time` 时丢弃，不用记录创建或更新时间伪造测量时间；
2. 心率值不在 `30–240` 的记录丢弃（传感器噪声与占位 0 值）；
3. 保留既有最近 24 小时/最多 600 点的导出接口，详情另从留存记录展开最多 30 天/20000 点的逐日历史；曲线仅传入所选自然日的点，避免跨午夜混入昨天；
4. 逐日最低/最高使用明细范围，平均为有效读数的算术平均、次数为读数点数；从保留记录重新投影，不对已聚合统计再次增量累加；
5. 「今日曲线」横轴固定 0–24 时，纵轴取当日范围并保证至少 20 bpm 跨度；
6. 「近 7 天」柱子为日均值，须线为当日最低–最高；无记录的日期留空，不插值。

官方手机 `7.1.0.053` 的 `DailyHeartRate`、`HeartRateMainViewModel` 与 `HeartRateLog` 进一步区分区间汇总、连续分箱和单次测量：日最低/最高使用记录区间极值；最新值可来自最新分箱，最新时间使用分箱结束时间（无分箱时使用记录结束时间）。首页最近三条是非连续记录的分组摘要，“查看全部读数”再呈现历史。测量 epoch 时间通过相应时区格式化；不得先加 `time_offset` 再用同一时区重复偏移。上述分组规则不意味着只有三条记录已同步。

本次真实记录验证：一段 39 个分箱的心率记录中，分箱最低 76、最高 106、分箱均值合计 3432，外层 `heart_rate=88` 恰为 `3432 / 39`；`heart_beat_count=1` 不能用作采样数量。心率图区间、逐条数字与记录时间应使用同一组真实数据，不能同时把外层汇总和其子分箱当成独立测量累计。

本应用 `lastHeartRateReportTime` 只在真实 FROM_WATCH `SYNC_DATA` 含非空心率记录且持久化成功后更新；随缓存保存，旧缓存未知时显示未知。该字段表示最近一批心率数据的手机接收时间，回补旧记录也会更新，不能当作每条记录各自的上传时间。

#### 6.6.3 睡眠监测与分期数据结构（逆向自 Samsung Health）

手表端睡眠同步涉及三个互相关联的模块，逆向自官方 `WearableSleepDataSetter`、`WearableBackwardData.SleepSub` 与 `SleepConstants`：

| 模块 | 关键字段 | 作用 |
|---|---|---|
| `com.samsung.shealth.sleep`<br>（旧名 `com.samsung.health.sleep`） | `start_time`, `end_time`, `efficiency`, `quality` (或 `rating`), `datauuid` | **睡眠会话主表**：整夜起止时间、睡眠效率（百分比）与睡眠评分（`quality` 0–100） |
| `com.samsung.shealth.sleep_data` | `sleep_uuid`, `json_version`, `sleep_status` | **睡眠分期时序 Blob**：`sleep_status` 为 **Base64(gzip(JSON 数组))** |
| `com.samsung.shealth.sleep_stage`<br>（旧名 `com.samsung.health.sleep_stage`） | `start_time`, `end_time`, `status` (或 `stage`), `sleep_uuid` | **睡眠分期离散记录**：单条分期起止区间 |

##### 分期编码表（`SleepStageItem.SleepStageType`）

| 状态码 | 枚举名 | 业务含义 | 界面呈现 |
|:---:|:---|:---|:---|
| `40001` | `SLEEP_STAGE_TYPE_WAKE` | 清醒 (Awake) | 琥珀色，时序图最顶行 |
| `40004` | `SLEEP_STAGE_TYPE_REM` | 快速眼动 (REM) | 紫色，时序图第二行 |
| `40002` | `SLEEP_STAGE_TYPE_LIGHT` | 浅睡 (Light) | 柔和蓝（50% alpha），时序图第三行 |
| `40003` | `SLEEP_STAGE_TYPE_DEEP` | 深睡 (Deep) | 饱和品牌蓝，时序图最底行 |
| `40005` | `SLEEP_STAGE_TYPE_LATENCY` | 入睡潜伏期 | 过渡阶段，不单独入图 |
| `40006` | `SLEEP_STAGE_TYPE_GAP` | 缺测间断 | 传感器脱落/断连，不计入睡眠 |

##### `sleep_status` Blob 内部格式

解压 Base64(gzip) 后的 JSON 数组形如：

```json
[
  {"startTime": 1793039280000, "status": 40001},
  {"startTime": 1793040120000, "status": 40002},
  {"startTime": 1793042400000, "status": 40003},
  {"startTime": 1793046000000, "status": 40004}
]
```

每个样本表示该时刻**切换**至指定分期，区间由相邻两样本构成：`[sample[i].startTime, sample[i+1].startTime)`。
同一分期的相邻样本合并，最后一个样本不单独生成区间。必须先用完整样本序列确定区间终点，再排除 GAP、LATENCY 和未知阶段；不能先过滤这些样本，否则会错误延长前一个有效分期。嵌套 `sleep_status` 解压后上限为 8 MiB。

##### 多报文归并与展示口径

1. **会话与分期关联**：优先用 `sleep_uuid == datauuid`；缺失 uuid 时按时间包含关系（`sample ∈ [start_time, end_time]`）归入。
2. **跨包记录归并**：先按 `datauuid` 和 `update_time` 替换 RecordStore 中的完整修订，再按 `sleep_id` / `sleep_uuid` 与会话关联；不以“起点相差 6 小时”强行合并。旧的 `SleepParser.merge` 辅助函数只合并真实重叠区间，不是当前投影主入口。
3. **入睡时间判定**：总在床时长 = `end_time - start_time`；实际睡眠时长 = 浅睡 + 深睡 + REM（扣除清醒）。
4. **效率计算**：优先使用手表给出的 `efficiency`；有有效分期或 `sleep_duration` 时，才可按 `(实际睡眠时长 / 分析区间时长) × 100%` 推算并四舍五入。只有起止时刻时，区间时长已知，但实际睡眠和效率未知；不能报 0% 或 100%。
5. **睡眠评分**：`quality`（0–100）是手表官方评分，保留为导出 `score`，可用时优先展示。本机 `SleepScore` 根据 REA 核查的 ARM64 `libsleepscore.so` **1.4.24 夜间总分路径**计算：总睡眠时长 34 / 安稳度 6 / 身体恢复（深睡）18 / 精神恢复（REM）26 / 入睡耗时 16；不是旧的周期近似。使用原库 sigmoid/高斯曲线、效率、连续清醒和逐项截断规则，最终 1–99；只对完整连续的 30 秒整数倍分期计算。算法标识为 `computed_shealth_1_4_24`，导出 v3 同时保留 `computed_score`、`computed_score_algorithm` 与展示来源 `score_source`；手表原始值、分期模型版本与本机评分版本分开。公式、346 组合成原指令对照和适用边界见 `docs/SLEEP-ANALYSIS.md`；不据此宣称手表评分或其他官方版本必然相同。
6. **历史归纳**：以**醒来时刻所在日期**为准归纳至逐日历史，供「近 7 天睡眠时长」图表使用。手表未下发睡眠数据时卡片提示等待，不伪造数据。

### 6.6.8 睡眠原始数据与手机本地四分期（2026-10-28 实机验证）

- 当前手表固件可先发仅含起止时刻的检测记录：`com.samsung.shealth.sleep`、`has_sleep_data=-1`，没有 duration / efficiency / score。这个状态不是零时长睡眠。
- 对应 `com.samsung.shealth.sleep_raw_data` 记录通过 `sleep_uuid` 关联会话，`data` 为 Base64(gzip(JSON))：`{"version":2,"data":[{"acc":[8 个特征],"rri_info":[[flag,index,ibi],…]},…]}`。深浅睡分类不在这个 blob 里，需在手机本地执行模型。
- 每个原始采样窗为 30 秒。模型包含加速度/心跳特征预处理、分位归一化、TensorFlow Lite 四分类、时间边界对齐与尾部清醒裁剪；因此原始窗数与最终分期窗数可以不同。
- 模型内部输出码 `0=深睡、1=浅睡、2=清醒、3=REM`，与同步表的 `40001…40004` 编码区分。结果统一转为 SleepParser.Session。
- 公开构建不包含再分发授权未确认的厂商睡眠 DEX、模型与 JNI，不从 raw 数据生成新分期，也不为该推理触发原始数据回补。`LocalSleepAnalyzer` 仅在显式本地 `-PvendorAssetsDir` 构建中使用校验摘要的离线组件，后台串行计算、按输入修订缓存；CI 拒绝该选项。已接收分期、旧本机分析缓存、有效分期上的评分与完整导出继续保留。组件来源、构建与 CPU 边界见 `app/src/main/assets/sleep/NOTICE.md`、`scripts/sleep-engine/README.md`。
- 缺失原始数据的最近睡眠可通过一次 `REQUEST_DATA.last_sync_time=0` 冷同步补回；正常步数回补仍采用原有显式快照保护。原始数据与 combined 会话作为记录保留，不在解析层伪造阶段。
- 原始记录优先于本机结果：已有有效的 received sleep_stage 时不覆盖。只有 received 分期缺失时使用可用的本地分析结果，UI 标明“本机离线分析”。
- 实机最新 626 个原始窗得到 636 个最终半分钟窗、61 段；分析区间 02:24–07:42，实际睡眠 301 分钟，浅睡 130 / 深睡 86 / REM 85 / 清醒 17 分钟，效率四舍五入为 95%。原始检测醒来 07:49 单独保留。
- 已有结果的旧记录对照：728/728 半分钟窗与完整参考实现及已同步的分期完全一致。完整证据范围、JNI 整数效率截断差异及测试说明见 `docs/SLEEP-ANALYSIS.md`。

### 6.6.9 血管负荷（Vascular Load，2026-11-06 静态核对）

- **能力协商**：使用 `/samsung_health/capability` 的 REQUEST/RESPONSE 报文。连接就绪后主动请求手表能力；仅当 `category=40001` 且 `tracker_feature.vascular_load_feature.version >= 1000`、`vascular_load_support=true` 才显示卡片及编辑入口，不按型号推测。支持状态按配对设备缓存，收到新能力声明后替换。手机声明该特性 `version=1002`、`vascular_load_support=true`，沿用官方值；当前不提供手机发起的基线重置操作。
- **采集开关**：健康测量 → 自动测量中的血管负荷采集使用官方 Labs 偏好 `datauuid=72-lab.enable.vascular_load`、`service_id=app.settings`，`int_value=1` 开、`0` 关；区别于 `tracker.vascular_load` 的 `45-vascular.load.onboarding`（引导完成标志），不修改引导或基线。手机 `wwi` 将 tracker 映射至该设置，`vwi.c` 在 Labs 服务可用时缺行默认开；手表 `Zi1.n → TT0.a → VascularLoadSetting → V11.c → Gm2.b` 将其用于睡眠采集准入，仍受支持能力、引导及省电条件限制，不保证切换后立即启停传感器。通过 `com.samsung.shealth.preferences` 写入；已有行仅改值和单调修订，无目标行时只借已同步 `app.settings` 行的 `pkg_name/deviceuuid` 新建目标偏好，不复制其他设置的值。同步分包或增量中缺行不证明默认已生效，界面保留未确认；收到成功 ACK 及同设置、同设备、修订不旧于请求的回读后才确认。入口沿用上述手表能力门槛。
- **同步结果表**：`com.samsung.shealth.mean_arterial_pressure`，字段为 `datauuid/start_time/end_time/time_offset/type/measurement/deviceuuid`；时间和偏移均为毫秒，`measurement` 可空。`VASCULAR_LOAD` 是合法的 RequestModule 标识，但已检查手表 `FO2.t → LK1 → NR.d` 接收路径只记录 `request_module_list`，随后以 `MOBILE` 发起公共同步，不能据此声称只查询血管表，也不能保证请求窗口构成数据库过滤条件。首次确认支持后排队零游标历史回补，等待当前同步结束再发送；使用现有完整冷同步入口，发送 `last_sync_time=0/start_time=0`，同时启用步数快照保护，允许其他健康表一并回传。仅在该次同步收到完成闭环后按设备保存首次回补完成标记；此标记表示一次零游标同步闭环，不证明所有数据库历史都已导出，不能仅凭近期测量行判定历史已补齐。记录先按身份、修订时间完整替换；该表不使用普通指标的 30 天裁剪，以保留长期有效的基线及重置事件，仍受 8,000 条上限约束。
- **完成语义**：手表 `LOG_DATA` 的请求体只声明 `action`，手机持久化成功后回复 `result=SUCCESS` 并等待 ACK 入队成功才结束本轮；不能等待手表未提供的 `LOG_DATA.result=SUCCESS`。官方公共同步对单表查询异常会捕获后继续，因此闭环不保证每张表都成功或历史完整。
- **类型**：`1=RESET_BASELINE`，`2=BASELINE`，`3=MEASUREMENT`。空值基线表示已采集一夜但尚未完成；有值基线表示手表完成标定。测量值已经是相对于基线的差值，不能再次减去基线，也不能作为收缩压或舒张压显示。空测量保持“数据不足”。
- **分级**：`[-12.5,-7.5)` 较高、`[-7.5,-2.5)` 略高、`[-2.5,2.5]` 平稳、`(2.5,7.5]` 略低、`(7.5,12.5]` 较低；范围外为未知。图表坐标为 `2.5 - 0.2 × measurement`，范围 0–5；有值基线按官方 `COMPLETE_BASELINE` 映射落在 2.5，并标为“基线已建立”，不套用测量分级；缺失值不连线。
- **基线进度**：按最新优先的 BASELINE/RESET 行处理，最新 RESET 归零，最新有值 BASELINE 完成；未完成时依官方 12/13 天有效窗口取连续的一或两条基线行。有效窗口参考日期在手机本地 13:30 切至次日，不从睡眠条数推断完成。重置后旧测量不再作为当前结果。
- **日期归属**：依记录的 `time_offset` 计算日期；非 RESET 行的结束时刻达到 20:30 时归次日，RESET 保持原日期。与普通健康指标直接使用手机当前时区的规则不同。
- **日志**：沿用全局 `LogBus`。普通日志只记录能力支持标记、同步模块、接收/可解析/拒绝条数及回补排队、完成、失败或取消状态；不输出血管读数、基线值或记录原文。解码失败仅记录错误类别、报文序号、输入长度和耗时，不将可能含健康原文的异常消息带入普通日志。记录样本和异常堆栈仅在用户显式开启全局调试日志后输出，受日志页现有隐私提示及脱敏规则约束。
- **依据与边界**：手机端 `hoa0`（能力）、`po80`（分级）、`qq2/rba0`（进度）、`egh`（日期）；手表端 `YO2`（能力）、`C2857aP2`（结果生成）、`C5785lN/C5441k4`（同步表）。手表 Samsung Health 6.30.7.008 的 `FO2.x` 经 APK 重新反编译，确认零游标会复位发送标记；研究目录旧 Java 在重复分支处存在反编译缺失，不能单独据此判定复位行为。本应用消费手表已生成结果，未移植厂商 `libmap.so` 的原始信号估计及趋势通知算法。此项静态核对及自动化测试不能替代不同型号和固件的真机验收。

### 6.7 媒体控制与桥接协议
* **通信路径**：`/adaptive_media_bridging/rpc/media_update`
* **协议格式**：Protobuf 二进制查询。
* **特性**：手机可查询手表端正在播放的音频元数据（歌名、艺术家、播放状态、进度条），亦可向手表分发手机端的 MediaSession 控制事件（上一曲、下一曲、暂停、播放、音量）。

### 6.8 查找手表协议
* **通信路径**：`/wcs_extension/internal/findmywatch`
* **指令**：`start_find_watch` / `stop_find_watch`
* **行为**：手表立刻开启最高音量响铃、屏幕最大亮度闪烁、线性马达最大震动，直到手机端发送 `stop` 或手表屏幕被滑动确认。

---

## 7. 全局常量、UUID、包名与白名单速查表

### 7.1 蓝牙与服务 UUID
* **Wear OS RFCOMM UUID**：`5e8945b0-9525-11e3-a5e2-0800200c9a66`
* **历史样本信道 (SCN)**：`8`；连接时由 SDP 查询，不按型号固定

### 7.2 包名常量表
* Watch4 / Classic / FE 插件：`com.samsung.android.waterplugin`
* Watch5 / Pro 插件：`com.samsung.android.heartplugin`
* Watch6 / Classic 插件：`com.samsung.wearable.watch6plugin`
* Watch7 / Ultra 插件：`com.samsung.wearable.watch7plugin`
* 官方手表管理：`com.samsung.android.app.watchmanager`
* 官方健康手机端：`com.sec.android.app.shealth`
* 官方健康手表端：`com.samsung.android.wear.shealth`
* 手表 WCS 扩展服务：`com.samsung.android.wcs.extension`
* 手表 SystemUI 宿主：`com.samsung.android.wearable.sysui`
* 手表设置管理：`com.google.android.apps.wearable.settings`
* 本独立直连管理应用：`dev.ricky.galaxywatchmanagerfree`

### 7.3 证书指纹白名单 (SHA-1)
* **Samsung Health 官方证书指纹**：`9741a0f330dc2e8619b76a2597f308c37dbe30a2`
* **Galaxy Watch 官方平台签名指纹**：`9ca5170f381919dfe0446fcdab18b19a143b3163`

---

## 8. 调试命令与权威复核诊断手册

在开发调试与实机验证过程中，可使用以下 Shell 命令进行协议与系统状态的权威复核：

### 8.1 表盘切换生效复核 (手表端)
```bash
adb -s <WATCH_IP>:<PORT> shell dumpsys wallpaper | grep mWallpaperComponent
# 期望输出：
# mWallpaperComponent=ComponentInfo{com.samsung.android.watch.watchface.<id>/...WatchFaceService}
```

### 8.2 GMS Wearable 消息流转监控 (手表端)
```bash
adb -s <WATCH_IP>:<PORT> shell dumpsys activity service com.google.android.gms/.wearable.service.WearableService
# 检查：
# 1. Inbound 接收流：[lo:<generation>:<seq>] 格式
# 2. ReorderingQueue 状态：确认 generation changed 时触发 reset
# 3. receive 行：确认目标系统组件已真正消费本帧
```

### 8.3 Samsung Health 数据游标监控 (手表端)
```bash
adb -s <WATCH_IP>:<PORT> logcat -v time | grep -iE "SHWCOM|SHW -|HealthDataResolver"
# 观察：
# 1. onMessageReceived(): path /samsung_health/wearable_message
# 2. getUpdatedDataCursor: 打开指定健康表的游标
# 3. insertOrUpdateSync: 手机回执 SUCCESS 后本地更新时间戳
```

### 8.4 手机端调试广播指令集
```bash
# 查询当前表盘
adb shell am broadcast -n dev.ricky.galaxywatchmanagerfree/.core.WatchCommandReceiver -a dev.ricky.galaxywatchmanagerfree.CMD --es cmd watchface_get

# 切换为指定预设表盘
adb shell am broadcast -n dev.ricky.galaxywatchmanagerfree/.core.WatchCommandReceiver -a dev.ricky.galaxywatchmanagerfree.CMD --es cmd watchface_set --es id ultra_analog

# 主动请求健康增量同步（回补另用 health_recover）
adb shell am broadcast -n dev.ricky.galaxywatchmanagerfree/.core.WatchCommandReceiver -a dev.ricky.galaxywatchmanagerfree.CMD --es cmd health

# 查看/写入原生测量偏好（需先回补一次以取得基线记录），以及远程打开测量界面
adb shell am broadcast -n dev.ricky.galaxywatchmanagerfree/.core.WatchCommandReceiver -a dev.ricky.galaxywatchmanagerfree.CMD --es cmd health_settings_dump
adb shell am broadcast -n dev.ricky.galaxywatchmanagerfree/.core.WatchCommandReceiver -a dev.ricky.galaxywatchmanagerfree.CMD --es cmd health_settings_set --es target spo2 --ez on true
adb shell am broadcast -n dev.ricky.galaxywatchmanagerfree/.core.WatchCommandReceiver -a dev.ricky.galaxywatchmanagerfree.CMD --es cmd health_measure --es target stress

# 触发省电模式 (PSM) 切换
adb shell am broadcast -n dev.ricky.galaxywatchmanagerfree/.core.WatchCommandReceiver -a dev.ricky.galaxywatchmanagerfree.CMD --es cmd psm --ei state 1
```

---

## 9. 协议演进与维护规范

为保证项目的长期工业级可靠性，所有参与本项目的开发者与协作 AI 代理必须严格遵守以下维护准则：

1. **唯一真相源 (SSOT)**：本项目所有与三星手表蓝牙通信、信封打包、编解码算法、业务路径、字段定义有关的代码，均以本文档为规范基准。
2. **变更实时同步**：
   - 当通过抓包（HCI Snoop / Wireshark）、反编译（JADX）或代码调试解析出新的 WCS 路径时，必须在本文档对应章节增补路径格式、请求/响应载荷示例。
   - 当发现新表盘、新健康模块或新的 DataItem 键时，必须同步追加到字典速查表中。
3. **实机验证前置**：
   - 任何协议条目在标记为“可用/已打通”之前，必须经过双设备实机验证（真机日志 + dumpsys 交叉复核）。未经验证或失败的路径必须明确标记限制边界。
4. **版本同步维护**：
   - 当协议发生重大扩充（如新增运动模式控制、心电 ECG / 血压通道破解等），文档版本号按 `v1.x` 向上递增，并在修订记录中详细陈述变更日志。

## 修订记录

- **v1.9**：记录 v0.0.29 手机三轮袖带校准向导的真机验收结果（2026-11-04）。移除并发 `/remote_intent/rpc` 后手表端不再崩溃，`prepare_calibration` → `start_calibration` → `update_calibration` → `initial_calibration` 三轮流程完整走通；Watch 4 / 5 / 6 与 FE 仍待各自设备验证。

- **v1.8**：记录 v0.0.29 移除血压并发远程 Intent 启动的根因分析，以及手机侧 `prepare_calibration` / `start_calibration` / `update_calibration` / `initial_calibration` / `cancel_calibration` 的完整 measuring 时序。

- **v1.7**：纠正 0.0.22 将血压校准交给手机版 SHM 的错误路线。确认 Watch SHM 的 `do_calibration` 直接进入手表本地校准 Activity，三轮袖带与算法合并不需要手机 SHM；应用改为 WCS 直连、结果落盘后回查手表状态，并保留非空校准配置归档。

- **v1.6**：补充 Health Monitor 明文传输握手、ECG Channel 分帧/zlib 与二进制 report，先落盘再按任务 id 业务确认；ECG 实机回读 3 条且手表确认完成，BP 尚仅空队列验收。

- **v1.1**：补充 0.0.3 手机端后台健康同步调度、REQUEST 应答边界和健康指标归并规则；明确自动化验证与真机验收的区别。未新增手表协议能力声明。
- **v1.0**：汇总 RFCOMM / WCS、健康同步、表盘与设备设置的既有研究结果。

---
*(End of Specification - Galaxy Watch Manager Free Protocol Engineering Team)*

### 6.6.5 身体指标（血氧 / 皮肤温度 / 呼吸频率 / HRV）

通过 `wearable_message` 通道增量同步。三星健康内部定义见 `com.samsung.android.app.shealth.tracker.*`。

| 指标 | 模块名（兼容量/短名） | 取值字段 | 有效范围 | 说明 |
|---|---|---|---|---|
| 血氧 SpO₂ | `com.samsung.shealth.tracker.oxygen_saturation`<br>`com.samsung.health.oxygen_saturation` | `spo2` | 50.0–100.0 % | 睡眠期间或手动单次测量，通常为整型百分比 |
| 皮肤温度 | `com.samsung.shealth.skin_temperature`<br>`com.samsung.health.skin_temperature` | `temperature`、`mean` | 20.0–42.0 °C | 睡眠区间统计与分钟明细，浮点数 |
| 呼吸频率 | `com.samsung.shealth.respiratory_rate`<br>`com.samsung.health.respiratory_rate` | `breath_rate`、`respiratory_rate`、`average` | 4.0–60.0 次/分 | 顶层均值与分箱明细分开解析 |
| 心率变异性 HRV | `com.samsung.shealth.hrv`<br>`com.samsung.health.hrv` | `rmssd`（优先）、`sdnn`（后备） | 1.0–300.0 ms | 当前回补记录通过 `binning_data` 提供明细，不能仅检查顶层数值 |

时间优先使用明细 `start_time`（兼容模块长名）；缺失时使用记录 `create_time` / `update_time`。`end_time` 是区间结束时间，不能充当每个分钟采样的时间戳。
本应用保留最近 7 天、最多 6000 个采样点，按时间戳保留后到值；单日提供最低 / 平均 / 最高汇总，近 7 天提供日均值柱状图。

#### 6.6.5.1 历史同步、测量与时间口径（2026-10-30 实机复核）

核对版本：手机 Samsung Health `7.1.0.053`、手表 `6.30.7.008`；已将设备 APK 的 SHA-256 与本地逆向目标逐一匹配。运行证据保存在被 Git 忽略的 `private/health-heart-sync-20261030/`。

- 手机经 WCS RFCOMM 发送 `REQUEST_DATA` 后，手表日志显示 `DataSyncHelper → ProcessSyncRequest → WearableDataGetter.queryCommonSyncData → getUpdatedDataCursor`。`last_sync_time=0` 重置的是发送标记表，并查询可回补的既有记录，不能据此宣称读取了手表全部数据库。
- 实测 `request_module_list=SLEEP` 仍查询 82 个数据类型，回传含心率、压力、血氧、皮肤温度、呼吸频率及 HRV。此字段在该路径不能当作仅返回某指标的过滤器，也不能当作启动测量命令。
- 同步广播可触发心率/压力连续数据的 flush；日志中的 `flushContinuousData` 表示刷新已有连续采集数据，不能等同于启动一次新的血氧、温度或呼吸测量。
- 本次回补返回血氧/皮肤温度/呼吸频率各 15 条、HRV 16 条；前三项最新区间结束于 10 月 29 日 07:10，HRV 最新区间结束于 10 月 29 日 14:54:52。手表原生血氧页同时显示“昨天、94%、睡眠平均”，并提供独立“测量”按钮。日期未更新与当前手表页面一致；这不证明昨夜脱腕、充电或传感器未工作。
- 区间均值与最后一笔采样必须区分：最新睡眠血氧区间均值为 94%，最后有效分箱为 10 月 29 日 07:07:59 的 96%。皮肤温度/呼吸频率也同时存在整段统计与分钟明细。不能将区间结束时间配上最后一笔采样值，或将旧记录收到手机的时间写成测量时间。
- `start_time` / `end_time` 是测量区间，`create_time` / `update_time` 是记录元数据；手机接收时间必须来自真实接收事件。整体健康同步成功时间不能替代某项指标的测量时间或某条记录的接收时间。

#### 6.6.5.2 官方远程血氧测量入口

静态逆向确认手机 `Spo2MainActivity.F1 → x1x.U/T → eva0.f/l` 通过健康消息路径发送独立远程深链接。与 DATA/syncmanager 历史同步不同，外层为 `message="REQUEST"`、`type="MESSAGE"`，发送者 `com.samsung.mobile.app.shealth.tracker.spo2`，接收者 `com.samsung.android.wear.shealth.message_handler.remote_deep_link`；`body` 是下列普通 JSON 字符串，而不是健康 DATA 的 Base64(gzip(JSON))：

```json
{"action":"android.intent.action.VIEW","deepLinkUri":"samsunghealth://shealth.samsung.com/wear/deepLink?sc_id=tracker.spo2&destination=measure"}
```

手表 `C7556s8` 的远程处理分支解析 `action/deepLinkUri` 并启动 Intent，`EnumC8412vP → DO.a` 校验锁屏与地区支持后进入 `VIEW_SPO2_MEASURE`，设置 `EXTRA_NEED_RESULT_SCREEN=true`。因此官方存在“显式让手表进入血氧测量”的能力；不能据此声称每次打开指标页或每次同步都会自动采集。

本次仅以 ADB 向手表提交完全相同的 VIEW URI，实际进入 `Spo2GuidePagerActivity` 并显示“将手腕靠近心脏”。随后退出，未产生或伪造测量结果。已验证手表侧路由与前置指南；本应用尚未实现该独立远程 MESSAGE，不能将这次 ADB 启动记为本应用经蓝牙远程测量成功。手机发送关键方法认证证据：`ev_76f034f5dd72bd71ca2aab96eacccc127617324aeb108229a599b8d6a54fa6a7`。

#### 6.6.5.3 皮肤温度、呼吸频率与 HRV 的记录来源

以下为已匹配手表 APK 的静态调用链，结合本次同步数据形状核对；不将反编译调用关系当作昨夜已执行的证据。

| 指标 | 采集与落库路径 | 与手机同步的区别 |
|---|---|---|
| 睡眠皮肤温度 | `C0251Ca2 → C3559cs1.emit(case 19)` 收集睡眠状态；`SLEEP` 时在非省电、功能开启及能力支持条件下调用 `C2018Ta2.c` 启动连续皮温；`GET_UP → C0459Ea2.c → C1810Ra2` 按床/醒窗口写入 `com.samsung.health.skin_temperature`，含 `binning_data`、均值、基线与极值 | 睡眠事件驱动采集和会话统计；`REQUEST_DATA` 负责传输已落库记录 |
| 睡眠呼吸频率 | `C1618Pe2.a(SLEEP)` 在非省电及传感器可用条件下经 `C9212yS1` 启动 type 55；`GET_UP` 停止传感器并按睡眠窗口经 `AS1 → C5807lS1 → C1934Sf2.b` 写入 `com.samsung.health.respiratory_rate` | 由睡眠结束生成会话记录；不能把睡眠分析算法或同步广播泛称为新测量的来源 |
| HRV | `C9120y61` 从 `SemHRVariabilitySensorEvent` 读取 SDNN/RMSSD；`HrvDao`（`provider/hrv/b.d`）将 `HrvBinningData` 写入 `com.samsung.health.hrv` | 证明传感器事件与分箱记录来源；不据此断言日间每次压力测量都会产生独立 HRV，或与手机请求一一对应 |

本次已明确的远程即时测量链是上节血氧路径。对这三项已追踪的睡眠/传感器流程，没有证据支持“发送普通健康同步就立即生成新读数”；这不是对整个 APK 所有动态路径不存在远程能力的证明。皮温时间守卫部分反编译不完整，不能从中推定某个缺失会话的实际原因。

#### 6.6.5.4 原生健康测量设置与压力分级

手机 `7.1.0.053` 与手表 `6.30.7.008` 的设置枚举和实际回补记录确认：

| 设置 | `com.samsung.shealth.preferences` 身份 | `service_id` | `int_value` |
|---|---|---|---|
| 睡眠期间血氧 | `10-measure.period` | `tracker.spo2` | 0 开启、1 关闭 |
| 压力采样模式 | `08-measure.period` | `tracker.stress` | 0 连续、1 仅手动 |

这两项设置不提供任意分钟间隔的单次测量定时器。血氧 `destination=measure` 会进入手表单次测量界面，不能用反复远程启动替代睡眠期间自动采集。手动压力测量可使用相同远程 MESSAGE 格式，将发送者和深链接服务改为 `tracker.stress`。原生压力设置深链接为 `sc_id=app.settings&destination=main&target=stress`；血氧可进入 `target=main` 的原生设置首页。

官方手机 `pga0/oga0 → HealthDataResolver.InsertRequest → HOME sync` 将偏好作为双向健康同步记录传输，而不是 `/w_module_sec_watch_setting` 的 DataMap 设置。手表 `AbstractC4743hO → C7468ro0 → R42.a` 按 `datauuid` 更新，再通知原生设置观察者。`datauuid/create_time/update_time/pkg_name/deviceuuid` 均为必填；更新应保留真实回读记录的元数据，仅改变目标 `int_value` 与单调递增的 `update_time`，不伪造来源身份。

`SYNC_DATA` 的匹配 `SUCCESS` 仅证明数据库操作完成；旧修订被忽略也可能返回 SUCCESS。界面只有再次收到 FROM_WATCH 偏好记录且身份、数值和修订均匹配时才能显示已确认；发送失败、验证错误、超时与确认状态必须分开。源码认证：`pga0 ev_377f8651471d0334a93cf5559bcadfd3a2b5d5fca70307910191ee5ec2035d7e`、`oga0 ev_d572036e6457df6578bee91bb3b81e64526c8d1b837a0720bb35262b1b803eb7`。

压力同步记录的原始 `score` 分级为 0–10 放松、11–20 低、21–80 中等、81–100 高（`EnumC5133it2`、`QF1`）。官方另有显示缩放范围 0–25 / 26–50 / 51–75 / 76–100；不得将等分四段阈值直接应用于原始 score。连续记录 `binning_data` 中的 `score/score_min/score_max/start_time/end_time` 与外层区间统计应区分，不把汇总和其明细重复计数。

### 6.6.6 爬楼层数（Floors Climbed）

- 模块：`com.samsung.shealth.floors_climbed` / `com.samsung.health.floors_climbed`
- 关键字段：`floor_count`、`datauuid`、`start_time`
- 聚合规则：
  - 手表上报的是区间记录（一次爬楼 1–N 层）；
  - 本应用按 `datauuid`（缺失时为 `fl_<start_time>_<count>`）去重；
  - 仅累加本地同一自然日的记录，跨自然日自动归零；
  - 已见集合保留最近 300 条防重复。

### 6.6.7 运动记录（Exercise Sessions）

- 模块：`com.samsung.shealth.exercise` / `com.samsung.health.exercise`
- 关键字段：
  - `exercise_type`：运动类型编码（整型），定义见 `SportTypeConstants`（如 1001 健走、1002 跑步、1006 爬楼梯、14001 游泳、15005 跑步机，共收录 45 种常用中文映射，其余展示「运动 {code}」）；
  - `start_time` / `end_time`：毫秒时间戳；
  - `duration`：有效运动时间（毫秒，优先于 `end - start`，不等同于起止时刻的间隔）；
  - `calorie`：消耗千卡（浮点或整型）；
  - `distance`：移动距离（米，浮点或整型）；保留 Double 精度，汇总后才格式化；不得逐点累加 `live_data` 中的累计距离；
  - `source_type=4`：自动识别运动（Samsung Health `SportSharedConstants.WORKOUT_SOURCE_TYPE_AUTO`）；
  - `count_type=30001` 时 `count` 为步数；
  - `location_data` / `location_data_internal`：运动定位明细载体，与独立保存的 `com.samsung.shealth.exercise.route` 模块区分；没有实际定位点不得绘制路线；
  - `mean_heart_rate` / `max_heart_rate`：心率均值与峰值（bpm）；
  - `datauuid`：唯一标识。
- 聚合规则：
  - 按 `datauuid` 去重，同一条目以最新到达内容为准；
  - 最多保留最近 40 条运动记录；
  - 当天多次运动自动汇总结算「今日运动次数、总时长、总消耗」。
- 2026-10 实机复核：8 条自动识别健走合计 8732.66015625 米，逐条 `mean_speed × duration / 1000` 与 distance 一致，误差小于 0.001 米。展开 `live_data` 和 `live_data_internal` 均无经纬度，本批记录无地图轨迹。范围与证据见 `docs/EXERCISE-DISTANCE-AND-ROUTES.md`。


## 7. 应用内更新流程（非手表协议，但属于发布链路的一部分）

1. 私有仓库打标签 → Actions 构建、签名 → 上传 APK、完整对应源码 `.tar.gz` 和各自 SHA-256；公开产物不含厂商睡眠运行时或官方表盘预览。
2. 同一次运行里把签名 APK 和对应源码推送到公开 feed 仓库 `crossly/galaxy-watch-manager-free-feed` 的通道分支（稳定版 `apk`，Nightly 为 `apk-nightly`）：
   - 每个产物 commit 另由版本与 APK/源码摘要标签保留，清单使用固定 commit SHA 直链；重复运行先复用并核验已有标签，不重新生成同名标签的不同提交。
   - 通道产物 ref、保留标签和 `main` 清单使用一次原子 push 更新；所有版本共用发布锁，运行中任务不中断，等待任务保留排队，并拒绝较旧 versionCode 回退清单。
   - APK 文件名固定为 `galaxy-watch-manager-free-<version>.apk`；源码与 APK 一同留存，便于按版本取得完整对应源码。
3. `main` 分支的 `version.json` / `nightly.json` 写入 `version_name`/`version_code`/`apk_url`/`apk_size`/`sha256`/`page_url`/`notes`，并提供 `source_name`/`source_size`/`source_sha256`/`source_url`。Nightly 标为 prerelease 且不替换稳定 Latest；旧稳定版重跑也不能替换更新的稳定 Latest。
4. 应用侧（`UpdateChecker` + `ApkUpdater`）：
   - `GET version.json`（无认证），`version_code` 优先比较；
   - 「关于与更新」可保存下载镜像选择，默认直连；选用 `gh-proxy.com`、`ghproxy.net` 或 `ghfast.top` 时，仅对 `github.com` 与 `raw.githubusercontent.com` 的 HTTP(S) 地址添加镜像前缀，同时作用于稳定/Nightly 清单与 APK；切换会重启进行中的检查或下载，已校验的安装包不受影响，下述所有校验仍必须通过；
   - 有新版本则后台下载到 `cacheDir/updates/`，边下边报进度；
   - 校验字节数与 `sha256`；
   - 核对实际 APK 包名与本应用相同，versionCode 与清单相符且高于已安装版；大小和 SHA-256 必须存在并一致；
   - 用 `GET_SIGNING_CERTIFICATES` 读取下载包及已安装包的签名证书摘要，二者非空且集合相同，否则拒绝；任何读取失败都不跳过校验；
   - 点击安装时在 IO 线程重验文件，避免仅凭缓存路径存在就信任；
   - 通过后由界面调用 `FileProvider` + `ACTION_VIEW(application/vnd.android.package-archive)` 交给系统安装器。
5. 任一校验失败都不安装，只在卡片与诊断日志里给出原因；`apk_url` 缺失时退回打开发布页。


## 审查后实现约束（v0.0.9 之后，未发布）

Health Monitor 与普通三星健康是独立链路，详见 [HEALTH-MONITOR-INVESTIGATION.md](HEALTH-MONITOR-INVESTIGATION.md)。Message/Control/Channel 路径分别为 BP `/991`、`/991c`、`/991d`，ECG `/992`、`/992c`、`/992d`。`request_connection` 不能当成已连接，须完成 `/plain_connection` 握手。Message 信封 body 使用 gzip/Base64；Channel 每任务为 `[4 字节大端长度][zlib JSON]`，同步动作/id/result 位于 `message_info`。ECG `report=Base64(zlib(大端 double[]))`，从实际 `sample_rate` 解释时长。保存成功后才回复 `type=DATA`、`message_info.type=RESPONSE/id=<原任务>/result=SUCCESS`。2026-10-28 实机确认 3 条 ECG（各 500 Hz / 15000 点 / 30 s）保存、手表 `onSyncCompleted`、手机重启恢复及空队列去重；BP 官方桥接与非空记录同步亦经用户完成官方袖带校准流程后实机验证闭环；手机侧三轮袖带向导已于 2026-11-04 真机走通，28 天到期切换仍未逐日观测。心率数据来自 Samsung Health 官方同步；独立底层传感器采集与自研算法已彻底移除，无独立运行时残留。重连不再发送虚构生日或自动完成条款。

### BP 官方校准 / 测量控制动作

- `/991` 的 sender/receiver 使用 `com.samsung.mobile.app.health.samd.bp.measuring` / `com.samsung.wearable.app.health.samd.bp.measuring`。
- 官方手机 `BloodPressureController` 的分支为：已有有效校准时发送 `do_measure`；没有有效校准时发送 `do_calibration`。
- Wear SHM 将 `do_calibration` 路由到 `BpMainActivity`，由它根据手表本地条款、profile 和校准有效期显示官方 calibration / expired-calibration 步骤；`do_measure` 则直接启动要求已有 `shealth_monitor_bp_calibration_last_feature` 的 `BpMeasureRunActivity`。
- 测量侧信息包含 `tnc`、可选 `calibration_time`、`is_service_available`；有效期按本地日历 28 天判断。已检查版本的 `need_to_recal` 固定为 false，但当前应用在收到 true 时优先判为需要重新校准，不能把该版本未发送 true 当成永远无需重校准。
- 历史真机曾通过手机版 SHM 向导完成一次校准；该实验依赖官方手机 `Wearable.API`、Wearable/Watch Manager 组件和手机端机型/环境检查，只用于观察结果同步，不是 WatchFree 的生产架构，也不能作为非三星手机兼容依据。
- WatchFree 的 BP 控制使用现有 WCS 会话：有效校准后的测量发送 `do_measure`；v0.0.29 的校准向导在手机编排 `prepare_calibration` → `start_calibration` → `update_calibration`，三轮后发送 `initial_calibration` 或 `re_calibration`。不要求 Google Wear 节点、手机版 SHM 安装或 Shizuku 启停。`capability_bp` DataItem 只表示手机侧具备该业务能力；采样与校准计算仍在手表端 SHM。
- 同时运行官方连接管理器与独立 RFCOMM 时，真机日志在 19:51:43–19:51:51 出现 5 次断开；连接状态变化使测量/刷新控件反复可用、禁用。按用户要求停用手机 Google Wearable / Watch Manager / Watch7 plugin / SHM 后，19:52:01 后观察约 6 分钟未再断开。手表 SHM 未停用。用户完成官方流程后，本 App 已收到并显示真实非空 BP 结果及校准有效状态；当时的手机自建校准向导尚未实现，v0.0.29 的三轮向导已于 2026-11-04 真机验证完成。
- `do_calibration` 是手表端入口动作，不能替代手机逐轮编排。v0.0.29 已实现以下 measuring 消息交互（各步以手表 `result=success` 回包推进；2026-11-04 已在真机完成三轮全流程）：
  - `prepare_calibration`：请求手表显示准备指引。
  - `start_calibration`：请求约 30 秒 PPG 采样；成功回包 `data` 包含 `hr` 与 `datauuid`，不包含原始特征。
  - `update_calibration`：提交用户在手机录入的真实 `ref_systolic`、`ref_diastolic`，以及 `nth`（1–3）和对应采样的 `datauuid`。前两轮成功后请求下一轮准备。
  - 第三轮更新成功后，发送 `initial_calibration` 或 `re_calibration`，`data.status="complete"`；由手表合并三轮本地配置并保存校准。成功回包可含 `calibration_time`，手机随后查询 `information` 并同步记录。
  - `cancel_calibration`：取消当前流程。手机向导提供失败提示、重试和关闭入口。
- 本地 Room 配置、三轮特征合并及 `shm-bp.so` 计算仍由手表官方实现。手机仅传递控制动作和用户实际输入的袖带读数，不生成替代特征或虚构参考值。
- 非空 `com.samsung.health.bp.configuration` 不再阻塞同批 BP 记录：当前分支按设备、`datauuid` 和修订时间归档配置原文，配置或任一测量写入失败都不发 SUCCESS，全部落盘后才确认整批任务。真实 Watch 4 / 5 / 6 配置重传仍需真机验证。
- 本 App 不自动完成条款或写入个人生日；袖带读数由用户实际测量后手动录入。只有 `tnc=true`、服务可用且校准未过期时发 `do_measure`；需要校准时使用手机三轮向导。手表主动上传校准/血压数据并确认 ACK 后，应用再查询 `information` 刷新手表拥有的校准状态。



### 应用状态与显示边界（全项目审查）

- 语言资源只用于 UI、Toast、通知与错误提示；协议路径、字段、包名、签名和缓存身份维持原值，不能按翻译后标签路由。
- GMS Wear 适配器是显式诊断通路。节点可见不等于 RFCOMM/WCS 会话就绪，不修改主会话的 `connected`、`sessionReady` 或配对身份。
- 设置请求先记录 pending，再调用发送；发送回调可立即确认，或查询 pending 决定是否实际发出设备护理命令。失败、替换、断线取消不能留下旧重试。
- 本轮未改变手表测量、健康 ACK、DataItem 或 Channel 的 wire 格式。ECG/BP 仍先持久化真实记录，再确认同步。
- 本地健康导出格式为 `galaxy-watch-manager-free.health.v3`：覆盖当前设备手机中全部留存的可解析历史，包括独立手动小睡及本机睡眠分析缓存；`manifest.json` 保存导出 UTC/时区、每文件 SHA-256、数据集数量、时间范围和留存/同步边界，`schema.json` 描述记录结构。规范、单位、来源、算法、完整 ECG 采样及平台迁移边界见 [HEALTH-EXPORT.md](HEALTH-EXPORT.md)。导出不额外发送手表指令或回写数据。

### BP 原生计算链（静态 Ghidra，2026-10-28）

- Wear OS APK 内 `libshm-bp.so`（SHA-256 `d6f69fe504d21ceefcc184797e57f64ba2133b889ad875483aa05c0387b07b20`）只是 JNI 包装；主体为 ARM32 `libbp_v3_06_10.so`（SHA-256 `9b30c1de424e77b110a8be14bc4152e3b212349af3ca9c564da82e190538d4a9`）。Ghidra 当前加载地址见下文，不当作 ELF 文件偏移。
- JNI `estBpProc` 调用 `est_bp_proc`；后者调用 `estimateBP`（`0x1cec0`），再将结果正数按 `+0.5` 转整数返回。`cal_bp_proc` 使用同一计算入口的校准模式；`averageMcal` 固定合并三组校准记录。
- Java `pl/sl/rl/fl/zl`：手表类型 28 的 green_raw → 4096 点环形缓冲；积累 >200 点后，从写位置前 100 点开始，10ms 消费一点，每 20 点调 JNI。显示用 `DmcFirFilter` 的 71 抽头系数数组只在 `vl.a` 给波形视图调用，不能误认为 JNI 的前置滤波。
- `estimateBP` 静态代码把 60 点窗口以间隔 `100/250` 的目标坐标调用 `spline1_c`，即该算法按 100Hz 输入/250Hz 内部网格设计；插值不等于提升真实采样信息。它继续调用 `PPG_main`（取反、预热、IIR 预处理、代表脉搏筛选）、`CCD_main` 与 `ccd_feat_extract`（逐次差分至四阶、形态特征提取）。不使用 ECG R 峰作为该函数的输入，不能称为已实现双点 PTT 测量。
- `CCD_main` 产出 16 项：前两项是离散状态，2–14 为波形形态/比率/位置类量，15 为 `15000/周期长度`（与 250Hz 换算心率一致）。具体生理名仍须逐项核对。`multi_cal` 对第 2–15 项取算术平均，第 0/1 项按计数选择状态，并平均参考收缩/舒张压。
- `recal_BP`（`0x1c6a8`）是基于当前/校准特征比值的分段修正公式，最终结构为 `SBP=参考SBP+权重×增益×收缩修正−校正项`、`DBP=参考DBP+权重×增益×舒张修正−校正项`。不是已观察到的端到端神经网络推理；APK 中其他模型不能按文件存在就归为 BP 模型。个人参考血压直接进入最终计算，不能用标准正常值替代。
- 证据：`estimateBP ev_0ed0e5f2538d8d56b9ea1e3108e06427f21baae3b94482d146274fce04360f45`；`recal_BP ev_e86934b1b2e427619da5d59d39a8fe86aa0f4ec1baf56fbccbf71d628730b416`；`multi_cal ev_747268050b97ffdcd9d877c29e35ad1d78e58bb465105fb35bcaa86a663f3a61`；`CCD_main ev_a9a598a42fec6e5abfde70890478f280859d5ae7e8301af18aaf530d88a41d82`。完整保存的反编译/证据在私有 `private/shm-investigation/bp-native/`，分层分析与公式整理见 [BP-ALGORITHM-ANALYSIS.md](BP-ALGORITHM-ANALYSIS.md)。大函数 `ccd_feat_extract` 的值流记录有截断限制；已分页保存完整伪代码，不代表原始源码或数值验证。

### BP 校准状态检查边界

- Watch SHM `do_measure` 前检查手表本地 `shealth_monitor_bp_calibration_last_feature`；缺失时测量控制器不启动计算。该个人特征由手表自己的官方校准过程生成。
- `.common/information` 可上报 `tnc`、`calibration_time`、`is_service_available` 和 `need_to_recal`；校准有效期按本地日历 28 天检查。当前应用优先处理 `need_to_recal=true`，并在本地到期时刻或页面恢复时重新计算状态；已检查版本的该字段固定 false，不能据此省略其他状态检查。
- `start_calibration` 成功回复仅含心率及 `datauuid`，不能据此假定手机拿到了校准特征或能独立计算 BP。
- 本 App 按官方状态决定是否允许测量；v0.0.29 新增的手机三轮校准向导通过 `/991` 编排手表官方采样与特征合并，并提交用户真实袖带读数。历史官方校准后的结果同步与状态闭环已有实测记录；v0.0.29 的 Wizard、启动崩溃修复与完整三轮流程已于 2026-11-04 由用户真机确认可用。独立传感器采集与自研血压重算已放弃，不保留独立运行链路。

- **健康元数据归一化**：长字段名的 UUID、测量时间和修订时间在进入 RecordStore 时归一化；不同记录不能因短字段缺失共用空身份。恢复失败返回错误并保留原输入副本，不能据此声明完整回补。
- **活动来源优先级**：全天 summary 的步数、热量和距离优先于不完整区间明细；字段缺失保持未知，不能用 0 覆盖已知汇总。小时图先读取 summary 分桶，再与区间逐小时取较大值。
- **日期**：身体指标“今日”只使用选定本地日期内的采样；周趋势使用完整最近 7 天集合。无有效日期的楼层记录不参与今日统计。
- **运动类型核对**：11007=骑行、12001=有氧健身、14002=水中有氧、14004=帆船、14007=皮划艇、16002=滑雪、16007=单板滑雪、9014001=户外游泳。来源为 SportTypeConstants，不按编号区段猜测类型。
- **设置写入**：confirmed 值仅由手表回包更新；请求值进入 pending，新请求替换旧重试。断线/关闭取消 pending，超时报告未确认。发送排队成功不等于设备已应用。
- **通知身份**：转发保留原 package/user/id/tag/uid，更新复用同一路径。路径中的动态片段进行 URI 编码，不再以时间取模生成主键。when 使用原通知时间；手机端通知清除回传仍未实现。
- **缓存作用域**：健康记录、覆盖标记、推理结果和节点配置按配对蓝牙地址分区，旧缓存仅复制给升级时保存的原设备；旧文件保持可恢复。
- **隐私与资源**：普通日志不含通知正文或原始健康 JSON；系统备份仅包含外观设置。回放资源只进入 debug 包，原始睡眠 blob 有界解压。
