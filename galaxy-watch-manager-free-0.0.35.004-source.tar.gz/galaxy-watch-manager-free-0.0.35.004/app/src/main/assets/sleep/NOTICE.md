# Offline sleep analysis runtime (local optional assets)

This folder documents the **vendor-derived** local inference runtime and model used to analyze
Galaxy Watch sleep sensor records. It is not an independently trained model.

Source: the locally retained Samsung Health 7.1.0.053 APK, SHA-256
`88b0359eaaea6061466df4fdb15754ca8408caf68e1eb796ef58b24374efe312`.
The APK itself is not included in the repository.

**The runtime binaries, model and manifest are not part of the public repository or public
builds.** They are kept only in the ignored local directory
`private/vendor-assets/assets/sleep/`, generated from the user's own APK by
`scripts/sleep-engine/build.py`. A self-use build may opt in with
`-PvendorAssetsDir=private/vendor-assets`; public CI rejects that property. Public builds do
not load or execute this runtime, do not perform new inference from `sleep_raw_data`, and
continue to preserve received stage data, previously cached local analysis results, existing
score calculations and exports.

- `engine.jar`: reduced DEX inference bridge, 30-second stage model and quantile table.
- `libmobilesleepjni.so`: Samsung feature preprocessing / inference support.
- `libtensorflowlite_jni.so`: TensorFlow Lite runtime distributed with that APK.
- `manifest.json`: input provenance and SHA-256 digests verified before runtime extraction.

The local directory contains only the user's own extracted copies; it is never uploaded by
this project's tooling. Samsung's model and feature library retain their original ownership.
TensorFlow Lite is an upstream Google/TensorFlow component under Apache-2.0; the upstream
license text is retained as `TENSORFLOW-LICENSE.txt`. This does not establish the
redistribution rights or full notice requirements of Samsung's specific bundled binary; see
the repository's `THIRD-PARTY.md`. Extraction and repackaging do not change those components'
ownership or grant new rights.

Reconstruction source and tooling profile: `scripts/sleep-engine/`. Behavior and validation
scope: `docs/SLEEP-ANALYSIS.md`. When enabled in a local self-use build, the app executes this
bundle from its own private code cache; it does not load code from, launch, or require the
Samsung Health app installed on the phone.

ARM64 was tested on the user's Honor phone with a local build containing these assets. ARMv7
files can be generated but were not tested on an ARMv7 device in this change. Other CPU
architectures keep received session data and show analysis as unavailable rather than
fabricating stages.
