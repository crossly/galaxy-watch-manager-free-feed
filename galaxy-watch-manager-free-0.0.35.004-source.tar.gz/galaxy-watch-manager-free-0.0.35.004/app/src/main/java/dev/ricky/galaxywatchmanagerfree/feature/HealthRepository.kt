package dev.ricky.galaxywatchmanagerfree.feature

import android.content.Context
import android.util.Base64
import dev.ricky.galaxywatchmanagerfree.BuildConfig
import dev.ricky.galaxywatchmanagerfree.feature.monitor.BpCalibrationConfigStore
import dev.ricky.galaxywatchmanagerfree.feature.monitor.BpLog
import dev.ricky.galaxywatchmanagerfree.feature.monitor.BpRecord
import dev.ricky.galaxywatchmanagerfree.feature.monitor.EcgLog
import dev.ricky.galaxywatchmanagerfree.feature.monitor.EcgRecord
import dev.ricky.galaxywatchmanagerfree.wcs.WcsPaths
import dev.ricky.galaxywatchmanagerfree.wcs.WcsSession
import java.io.ByteArrayOutputStream
import java.util.zip.GZIPOutputStream
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

/** Health data pipeline: parsing, local persistence, projection, and Samsung Health sync. */
class HealthRepository(
    context: Context,
    private val session: WcsSession,
    private val scope: CoroutineScope,
    private val state: MutableStateFlow<WatchState>,
    private val isActive: () -> Boolean,
    /** Receives only watch-originated measurement preference chunks after a durable sync. */
    private val onMeasurementPreferences: (List<JSONObject>) -> Unit,
    private val onSyncStatus: (HealthSyncCoordinator.Status) -> Unit = {},
) {

    private val _packets = MutableStateFlow<List<HealthPacket>>(emptyList())
    val packets: StateFlow<List<HealthPacket>> = _packets.asStateFlow()

    private val healthPrefs =
        DevicePreferences.open(context, "watchfree_health", session.peerAddress)
    private val bpCalibrationConfigs =
        BpCalibrationConfigStore(
            read = { healthPrefs.getString("bp_calibration_configs", null) },
            write = { healthPrefs.edit().putString("bp_calibration_configs", it).commit() },
        )
    private val syncRequestPolicy =
        HealthSyncRequestPolicy(healthPrefs.getLong("last_recovery_attempt_at", 0L))

    private var stepsAccumulator: Int = 0
    private val stepsSeenRecords = LinkedHashSet<String>()
    private val stepContributions = linkedMapOf<String, HealthStepParser.StepContribution>()
    private val stepSnapshot = HealthStepSnapshot()
    private val healthRecords = HealthRecordStore { LogBus.log("[健康] $it") }
    private val sleepAnalyzer = LocalSleepAnalyzer(context, session.peerAddress)
    private val manualNapStore = ManualNapStore(context, session.peerAddress)
    @Volatile private var manualNapList: List<SleepParser.ManualNap> = manualNapStore.load()
    private var sleepAnalysisJob: Job? = null
    private var vascularLoadBackfillJob: Job? = null
    private val messagePipeline =
        HealthMessagePipeline(
            isActive = isActive,
            mergeAndProject = ::mergeAndProjectPacket,
            persist = { reportTime ->
                persistHealthCache(durable = true, heartRateReportTime = reportTime)
            },
            onDecoded = ::logHealthPacket,
        )
    @Volatile private var sleepMissingRawId: String? = null
    @Volatile private var sleepRecoveryRequestedFor: String? = null
    @Volatile private var stepsCoverageComplete = false
    private var stepsSummaryThrough: Long = 0L
    @Volatile private var healthDay: String = todayKey()
    private var localStepGoal: Int = 0
    private var watchStepGoal: Int = 0
    private var recommendedStepGoal: Int = 0
    private var todayHours: List<Int> = HealthTimeline.emptyHours()
    private val dailyHistory = mutableMapOf<String, HealthTimeline.Day>()
    private val sleepHistory = mutableMapOf<String, Int>()
    private var heartRatePoints: List<HeartRateLog.Point> = emptyList()
    private var heartRateHistory: Map<String, List<HeartRateLog.Point>> = emptyMap()
    private val heartRateDays = mutableMapOf<String, HeartRateLog.Stats>()
    private var latestHeartRate: HeartRateLog.Point? = null
    private var stressHistory: Map<String, List<StressLog.Point>> = emptyMap()
    private val stressDays = mutableMapOf<String, StressLog.Stats>()
    private var latestStress: StressLog.Point? = null
    private val metricSamples = mutableMapOf<HealthMetric, List<HealthMetricLog.Sample>>()
    private var todayFloors: Int = -1
    private val floorsSeen = LinkedHashSet<String>()
    private var exercises: List<ExerciseLog.Session> = emptyList()
    private var ecgRecords: List<EcgRecord> = emptyList()
    /** 血压记录 */
    private var bpRecords: List<BpRecord> = emptyList()
    private val healthSync =
        HealthSyncCoordinator(
            scope = scope,
            sendRequest = { sendHealthSyncRequest() },
            onStatus = { status ->
                state.update { it.copy(healthSyncStatus = status) }
                onSyncStatus(status)
            },
            onLog = LogBus::log,
        )

    private fun projectedHealth(now: Long): HealthDataProjection.Result {
        val raw =
            healthRecords.records(SleepParser.MODULE_SLEEP_RAW).associateBy {
                it.optString("sleep_uuid")
            }
        val cached =
            healthRecords
                .records(SleepParser.MODULE_SLEEP, SleepParser.MODULE_SLEEP_LEGACY)
                .mapNotNull { record ->
                    val id = record.optString("datauuid")
                    raw[id]?.let { sleepAnalyzer.cached(record, it) }?.let { id to it }
                }
                .toMap()
        val base = HealthDataProjection.build(healthRecords, now, localSleep = cached)
        val naps = manualNapList
        if (naps.isEmpty()) return base
        val sessions = SleepParser.mergeSessions(base.sleepSessions, naps)
        return base.copy(
            sleepSessions = sessions,
            sleepHistory = SleepParser.historyByDay(sessions),
        )
    }

    @Synchronized
    fun scheduleSleepAnalysis() {
        if (!BuildConfig.VENDOR_ASSETS_ENABLED) {
            sleepMissingRawId = null
            return
        }
        if (sleepAnalysisJob?.isActive == true) return
        val now = System.currentTimeMillis()
        val raw =
            healthRecords.records(SleepParser.MODULE_SLEEP_RAW).associateBy {
                it.optString("sleep_uuid")
            }
        val sessions =
            SleepParser.sessions(
                    healthRecords.records(
                        SleepParser.MODULE_SLEEP,
                        SleepParser.MODULE_SLEEP_LEGACY,
                    ),
                    healthRecords.records(SleepParser.MODULE_SLEEP_DATA),
                    healthRecords.records(
                        SleepParser.MODULE_SLEEP_STAGE,
                        SleepParser.MODULE_SLEEP_STAGE_LEGACY,
                    ),
                )
                .associateBy { it.id }
        sleepMissingRawId =
            sessions.values
                .filter {
                    !it.hasSleepDuration && it.endMillis >= now - 36 * 3_600_000L && it.id !in raw
                }
                .maxByOrNull { it.endMillis }
                ?.id
        val targets =
            healthRecords
                .records(SleepParser.MODULE_SLEEP, SleepParser.MODULE_SLEEP_LEGACY)
                .mapNotNull { record ->
                    val id = record.optString("datauuid")
                    val session = sessions[id]
                    val sensor = raw[id]
                    if (
                        session == null ||
                            session.segments.isNotEmpty() ||
                            sensor == null ||
                            session.endMillis < now - 30L * 24 * 3_600_000L ||
                            !sleepAnalyzer.needsAnalysis(record, sensor)
                    )
                        null
                    else JSONObject(record.toString()) to JSONObject(sensor.toString())
                }
        if (targets.isEmpty()) return
        state.update { it.copy(sleepAnalysisRunning = true) }
        sleepAnalysisJob =
            scope.launch {
                try {
                    var changed = false
                    targets.forEach { (record, sensor) ->
                        kotlinx.coroutines.currentCoroutineContext().ensureActive()
                        if (sleepAnalyzer.analyze(record, sensor) != null) changed = true
                    }
                    kotlinx.coroutines.currentCoroutineContext().ensureActive()
                    if (!changed) return@launch
                    synchronized(this@HealthRepository) {
                        if (!isActive()) return@launch
                        val projected = projectedHealth(System.currentTimeMillis())
                        sleepHistory.clear()
                        sleepHistory.putAll(projected.sleepHistory)
                        publishSleepDay(projected.sleepSessions, System.currentTimeMillis())
                        publishHealthSummary()
                        persistHealthCache()
                    }
                } finally {
                    state.update { it.copy(sleepAnalysisRunning = false) }
                }
            }
    }

    // Local persistence
    private fun todayKey(): String =
        java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.US).format(java.util.Date())

    /** 启动时恢复上一次同步到的健康指标，避免重启后界面归零 */
    @android.annotation.SuppressLint(
        "ApplySharedPref"
    ) // Preserve a corrupt cache before replacement.
    @Synchronized
    fun restore() {
        val now = System.currentTimeMillis()
        val savedDay = healthPrefs.getString("day", null)
        val sameDay = savedDay == todayKey()
        stepsAccumulator = if (sameDay) healthPrefs.getInt("steps_accum", 0) else 0
        val recordsCurrent =
            healthPrefs.getInt("health_records_schema", 0) == HealthRecordStore.SCHEMA_VERSION
        val rawRecords = healthPrefs.getString("health_records", null)
        val restored = healthRecords.restore(rawRecords, now)
        if (!restored && rawRecords != null) {
            // Retain the unreadable input even when a later cold sync replaces the active cache.
            healthPrefs.edit().putString("health_records_recovery", rawRecords).commit()
        }
        stepsCoverageComplete =
            sameDay &&
                recordsCurrent &&
                restored &&
                healthPrefs.getBoolean("steps_coverage_complete", false)
        stepsSummaryThrough = if (sameDay) healthPrefs.getLong("summary_through", 0) else 0
        stepsSeenRecords.clear()
        stepContributions.clear()
        if (sameDay) {
            stepContributions.putAll(
                HealthStepParser.decodeContributions(healthPrefs.getString("steps_records", null))
            )
            healthPrefs
                .getString("steps_seen", null)
                ?.split('\u0001')
                ?.filter { it.isNotBlank() }
                ?.let { stepsSeenRecords.addAll(it) }
        }
        val cachedHeartPoints =
            HeartRateLog.merge(
                emptyList(),
                HeartRateLog.decodePoints(healthPrefs.getString("hr_points", null)),
                now,
            )
        val cachedHeartDays = HeartRateLog.decodeDays(healthPrefs.getString("hr_days", null))
        if (healthRecords.records(HeartRateLog.MODULE).isNotEmpty()) {
            val heart = HealthDataProjection.heart(healthRecords, now)
            heartRatePoints = heart.points24h
            heartRateHistory = heart.history
            heartRateDays.clear()
            heartRateDays.putAll(heart.days)
            latestHeartRate = heart.latest
        } else {
            heartRatePoints = cachedHeartPoints
            heartRateHistory = HeartRateLog.byDay(cachedHeartPoints)
            heartRateDays.clear()
            heartRateDays.putAll(cachedHeartDays)
            latestHeartRate = cachedHeartPoints.lastOrNull()
        }
        val cachedStressPoints =
            StressLog.decodePoints(healthPrefs.getString("stress_points", null))
        val cachedStressDays = StressLog.decodeDays(healthPrefs.getString("stress_days", null))
        if (healthRecords.records(StressLog.MODULE).isNotEmpty()) {
            val stress = HealthDataProjection.stress(healthRecords, now)
            stressHistory = stress.history
            stressDays.clear()
            stressDays.putAll(stress.days)
            latestStress = stress.latest
        } else {
            latestStress = cachedStressPoints.lastOrNull()
            stressHistory = StressLog.byDay(cachedStressPoints)
            stressDays.clear()
            stressDays.putAll(cachedStressDays)
        }
        val legacyStressScore = healthPrefs.getInt("stress", -1)
        state.update { state ->
            state.copy(
                todaySteps = if (sameDay) healthPrefs.getInt("steps", -1) else -1,
                todayCalories = if (sameDay) healthPrefs.getFloat("cal", -1f) else -1f,
                todayDistanceMeters = if (sameDay) healthPrefs.getFloat("dist", -1f) else -1f,
                lastHeartRate = latestHeartRate?.bpm ?: -1,
                latestHeartRate = latestHeartRate,
                heartRateHistory = heartRateHistory,
                heartRateDays = heartRateDays.toMap(),
                lastHeartRateReportTime = healthPrefs.getLong("hr_received_at", 0L),
                lastStressScore =
                    latestStress?.let { StressLog.roundedScore(it) }
                        ?: if (healthRecords.records(StressLog.MODULE).isEmpty()) legacyStressScore
                        else -1,
                latestStress = latestStress,
                stressHistory = stressHistory,
                stressDays = stressDays.toMap(),
                lastHealthSyncTime = healthPrefs.getLong("synced_at", 0L),
            )
        }
        localStepGoal = healthPrefs.getInt("goal_local", 0)
        watchStepGoal = healthPrefs.getInt("goal_watch", 0)
        recommendedStepGoal = healthPrefs.getInt("goal_reco", 0)
        if (sameDay) todayHours = HealthTimeline.decodeHours(healthPrefs.getString("hours", null))
        dailyHistory.clear()
        dailyHistory.putAll(HealthTimeline.decodeHistory(healthPrefs.getString("history", null)))
        sleepHistory.clear()
        sleepHistory.putAll(SleepParser.decodeHistory(healthPrefs.getString("sleep_history", null)))
        if (
            healthRecords
                .records(SleepParser.MODULE_SLEEP, SleepParser.MODULE_SLEEP_LEGACY)
                .isNotEmpty()
        ) {
            val projected = projectedHealth(now)
            sleepHistory.clear()
            sleepHistory.putAll(projected.sleepHistory)
            publishSleepDay(projected.sleepSessions, now)
        } else {
            val savedSleep = SleepParser.decode(healthPrefs.getString("sleep_json", null))
            val savedSessions =
                SleepParser.decodeSessions(healthPrefs.getString("sleep_sessions_json", null))
            val restoredSessions = savedSessions.ifEmpty { listOfNotNull(savedSleep) }
            if (restoredSessions.isNotEmpty()) {
                val allDays =
                    restoredSessions
                        .groupBy { SleepParser.nightKey(it) }
                        .mapValues { (_, s) -> s.sortedBy { it.startMillis } }
                state.update {
                    it.copy(
                        sleep =
                            restoredSessions.maxByOrNull { session -> session.displayMinutes }
                                ?: savedSleep,
                        sleepSessions = restoredSessions,
                        allSleepSessions = restoredSessions,
                        sleepDays = allDays,
                    )
                }
            }
        }
        // Heart history is rebuilt above from the retained record store; cached 24h points
        // are only the fallback when an older cache has no health record store.
        metricSamples.clear()
        HealthMetric.entries.forEach { metric ->
            metricSamples[metric] =
                HealthMetricLog.decode(healthPrefs.getString("metric_" + metric.name, null))
        }
        val floorsDay = healthPrefs.getString("floors_day", null)
        todayFloors = if (floorsDay == todayKey()) healthPrefs.getInt("floors", -1) else -1
        floorsSeen.clear()
        if (floorsDay == todayKey()) {
            healthPrefs
                .getString("floors_seen", null)
                ?.split('\u0001')
                ?.filter { it.isNotBlank() }
                ?.let { floorsSeen.addAll(it) }
        }
        exercises = ExerciseLog.decode(healthPrefs.getString("exercises", null))
        ecgRecords = EcgLog.decode(healthPrefs.getString("ecg_records", null))
        bpRecords = BpLog.decode(healthPrefs.getString("bp_records", null))
        state.update {
            it.copy(
                vascularLoadSupported = healthPrefs.getBoolean("vascular_load_supported", false)
            )
        }
        publishHealthSummary()
    }

    /** 最近睡眠日的主睡眠与全部会话（夜间 + 午休）统一写回状态。 */
    private fun publishSleepDay(sessions: List<SleepParser.Session>, now: Long) {
        val allDays =
            sessions
                .groupBy { SleepParser.nightKey(it) }
                .mapValues { (_, s) -> s.sortedBy { it.startMillis } }
        val recentDay = SleepParser.latestDaySessions(sessions, now - 36 * 3_600_000L)
        val latestDay = SleepParser.latestDaySessions(sessions, 0L)
        val displaySessions = recentDay.ifEmpty { latestDay }
        state.update {
            it.copy(
                sleep = displaySessions.maxByOrNull { session -> session.displayMinutes },
                sleepSessions = displaySessions,
                allSleepSessions = sessions,
                sleepDays = allDays,
            )
        }
    }

    /** 目标、小时分布、连续达标与近 7 天数据统一写回状态 */
    private fun publishHealthSummary() {
        val current = state.value
        val resolved = HealthGoals.resolve(localStepGoal, watchStepGoal, recommendedStepGoal)
        val today = java.time.LocalDate.now()
        val steps = current.todaySteps.coerceAtLeast(0)
        HealthTimeline.upsertDay(
            dailyHistory,
            HealthTimeline.dayKey(today),
            steps = steps,
            calories = current.todayCalories.coerceAtLeast(0f).toInt(),
            distanceMeters = current.todayDistanceMeters.coerceAtLeast(0f).toInt(),
            replace = true,
        )
        HealthTimeline.trimHistory(dailyHistory)
        val vascularLoad = VascularLoadLog.project(healthRecords.records(VascularLoadLog.MODULE))
        state.update {
            it.copy(
                stepGoal = resolved.goal,
                stepGoalSource = resolved.source,
                todayHours = todayHours,
                streakDays = HealthTimeline.streak(dailyHistory, resolved.goal, today, steps),
                weekSteps =
                    HealthTimeline.lastWeek(dailyHistory, today, steps).map { day -> day.second },
                dailyHistory = dailyHistory.toMap(),
                sleepHistory = sleepHistory.toMap(),
                weekSleep = SleepParser.lastWeek(sleepHistory, today),
                heartRatePoints = heartRatePoints,
                heartRateHistory = heartRateHistory,
                heartRateDays = heartRateDays.toMap(),
                latestHeartRate = latestHeartRate,
                latestStress = latestStress,
                stressHistory = stressHistory,
                stressDays = stressDays.toMap(),
                lastStressScore =
                    latestStress?.let { StressLog.roundedScore(it) } ?: current.lastStressScore,
                heartRateWeek = HeartRateLog.lastWeek(heartRateDays, today),
                metricSamples = metricSamples.toMap(),
                todayFloors = todayFloors,
                exercises = exercises,
                ecgRecords = ecgRecords,
                bpRecords = bpRecords,
                vascularLoad = vascularLoad,
            )
        }
    }

    /**
     * Capture before writing the ZIP; no pairing credentials or notification content is included.
     */
    @Synchronized
    fun exportSnapshot(): HealthExportSnapshot {
        val cache = JSONObject()
        healthPrefs.all.toSortedMap().forEach { (key, value) ->
            cache.put(key, JSONObject.wrap(value))
        }
        return HealthExportSnapshot(
            state = state.value,
            sourceRecords = JSONObject(healthRecords.encode()),
            retainedCache = cache,
            manualNaps = manualNapList.toList(),
            localSleepResults = sleepAnalyzer.exportResults(),
            dataLocalDate = healthDay,
        )
    }

    /** 用户在设置里调整每日步数目标（仅本机展示，不写回手表） */
    @Synchronized
    fun setStepGoal(value: Int?) {
        localStepGoal = if (value == null) 0 else HealthGoals.normalize(value)
        healthPrefs.edit().putInt("goal_local", localStepGoal).apply()
        publishHealthSummary()
        persistHealthCache()
    }

    @Synchronized fun manualNaps(): List<SleepParser.ManualNap> = manualNapList.toList()

    /** 用户显式补记午休。只接受合法区间且不与已有会话重叠，避免重复计时； 补记成功后立即重新投影并持久化，与夜间睡眠合并展示。 */
    @Synchronized
    fun addManualNap(startMillis: Long, endMillis: Long): Boolean {
        if (endMillis <= startMillis) return false
        val minutes = (endMillis - startMillis) / 60_000L
        if (minutes < MIN_MANUAL_NAP_MINUTES || minutes > MAX_MANUAL_NAP_MINUTES) return false
        val existing = projectedHealth(System.currentTimeMillis()).sleepSessions
        if (existing.any { startMillis < it.endMillis && endMillis > it.startMillis }) return false
        if (!manualNapStore.add(SleepParser.ManualNap(startMillis, endMillis))) return false
        manualNapList = manualNapStore.load()
        refreshAfterManualNap()
        return true
    }

    @Synchronized
    fun removeManualNap(startMillis: Long, endMillis: Long): Boolean {
        if (!manualNapStore.remove(startMillis, endMillis)) return false
        manualNapList = manualNapStore.load()
        refreshAfterManualNap()
        return true
    }

    private fun refreshAfterManualNap() {
        val now = System.currentTimeMillis()
        val projected = projectedHealth(now)
        sleepHistory.clear()
        sleepHistory.putAll(projected.sleepHistory)
        publishSleepDay(projected.sleepSessions, now)
        publishHealthSummary()
        persistHealthCache(durable = false)
        LogBus.log("[睡眠] 手动补记午休，当前共 ${manualNapList.size} 条")
    }

    @android.annotation.SuppressLint(
        "ApplySharedPref"
    ) // Protocol ACK requires durable persistence.
    private fun persistHealthCache(
        durable: Boolean = false,
        heartRateReportTime: Long? = null,
    ): Boolean {
        if (!isActive()) return false
        val s = state.value
        val editor =
            healthPrefs
                .edit()
                .putInt("health_records_schema", HealthRecordStore.SCHEMA_VERSION)
                .putString("health_records", healthRecords.encode())
                .putString("day", todayKey())
                .putInt("steps", s.todaySteps)
                .putInt("steps_accum", stepsAccumulator)
                .putBoolean("steps_coverage_complete", stepsCoverageComplete)
                .putLong("summary_through", stepsSummaryThrough)
                .putString("steps_seen", stepsSeenRecords.joinToString("\u0001"))
                .putString("steps_records", HealthStepParser.encodeContributions(stepContributions))
                .putFloat("cal", s.todayCalories)
                .putFloat("dist", s.todayDistanceMeters)
                .putInt("hr", s.lastHeartRate)
                .putInt("stress", s.lastStressScore)
                .putLong("synced_at", s.lastHealthSyncTime)
                .putLong("hr_received_at", heartRateReportTime ?: s.lastHeartRateReportTime)
                .putInt("goal_local", localStepGoal)
                .putInt("goal_watch", watchStepGoal)
                .putInt("goal_reco", recommendedStepGoal)
                .putString("hours", HealthTimeline.encodeHours(todayHours))
                .putString("history", HealthTimeline.encodeHistory(dailyHistory))
                .putString("sleep_history", SleepParser.encodeHistory(sleepHistory))
                .putString("sleep_json", s.sleep?.let(SleepParser::encode))
                .putString(
                    "sleep_sessions_json",
                    SleepParser.encodeSessions(s.sleepSessions.ifEmpty { listOfNotNull(s.sleep) }),
                )
                .putString("hr_points", HeartRateLog.encodePoints(heartRatePoints))
                .putString("hr_days", HeartRateLog.encodeDays(heartRateDays))
                .putString(
                    "stress_points",
                    StressLog.encodePoints(stressHistory.values.flatten().sortedBy { it.ts }),
                )
                .putString("stress_days", StressLog.encodeDays(stressDays))
                .putString("exercises", ExerciseLog.encode(exercises))
                .putString("ecg_records", EcgLog.encode(ecgRecords))
                .putString("bp_records", BpLog.encode(bpRecords))
                .putInt("floors", todayFloors)
                .putString("floors_day", todayKey())
                .putString("floors_seen", floorsSeen.joinToString("\u0001"))
        HealthMetric.entries.forEach { metric ->
            editor.putString(
                "metric_" + metric.name,
                HealthMetricLog.encode(metricSamples[metric].orEmpty()),
            )
        }
        if (!isActive()) return false
        return if (durable) editor.commit()
        else {
            editor.apply()
            true
        }
    }

    @Synchronized
    fun resetDayIfNeeded() {
        val day = todayKey()
        if (healthDay == day) return
        healthDay = day
        stepsAccumulator = 0
        stepsCoverageComplete = false
        stepsSummaryThrough = 0L
        stepsSeenRecords.clear()
        stepContributions.clear()
        todayHours = HealthTimeline.emptyHours()
        todayFloors = -1
        floorsSeen.clear()
        state.update { it.copy(todaySteps = -1, todayCalories = -1f, todayDistanceMeters = -1f) }
        publishHealthSummary()
        persistHealthCache()
    }

    @Synchronized
    fun handleMessage(json: JSONObject, dir: HealthPacket.Direction) {
        if (!isActive() || json.optString("body").isEmpty()) return
        resetDayIfNeeded()
        val now = System.currentTimeMillis()
        when (val result = messagePipeline.process(json, dir, now)) {
            is HealthMessagePipeline.Result.DecodeFailed -> {
                val error = result.error
                LogBus.error(
                    "[健康] 数据包解码失败 category=${error.javaClass.simpleName} seq=${json.optInt("sequence_num")} bodyChars=${json.optString("body").length} elapsed=${System.currentTimeMillis() - now}ms，未确认游标"
                )
                LogBus.debug { "[健康] 解码异常详情：${error.stackTraceToString()}" }
            }
            HealthMessagePipeline.Result.PersistenceFailed -> {
                if (isActive()) LogBus.log("[健康] 本地保存失败，保留重试，不确认同步游标")
            }
            HealthMessagePipeline.Result.Skipped -> Unit
            is HealthMessagePipeline.Result.Completed -> {
                if (!isActive()) return
                if (result.persisted) {
                    onPacketPersisted(result.packet, json, now)
                }
                finishPacket(result, json)
                if (result.persisted) scheduleSleepAnalysis()
                LogBus.debug { "[健康] 数据包处理完成 (耗时 ${System.currentTimeMillis() - now}ms)" }
            }
        }
    }

    private fun logHealthPacket(packet: HealthPacket) {
        LogBus.debug {
            "[健康] 收到数据包 seq=${packet.sequenceNum} action=${packet.action} modules=${packet.moduleList} chunks=${packet.chunks.keys.joinToString()}"
        }
        for ((key, rows) in packet.chunks) {
            if (rows.isEmpty()) continue
            LogBus.debug { "[健康数据] seq=${packet.sequenceNum} module=$key records=${rows.size}" }
            LogBus.debug {
                val samples = rows.take(2).map { LogBus.describe(it) }.joinToString(" | ")
                "[健康数据样本] $key (共${rows.size}条, 抽样前2条): $samples"
            }
        }
    }

    private fun mergeAndProjectPacket(
        packet: HealthPacket,
        receivedSync: Boolean,
        now: Long,
    ): Boolean {
        val chunks = packet.chunks
        val entries = packet.raw
        // 提取步数、心率、压力等指标
        var newSteps = state.value.todaySteps
        var newCal = state.value.todayCalories
        var newDist = state.value.todayDistanceMeters
        var newHr = state.value.lastHeartRate
        var newStress = state.value.lastStressScore

        // Step counts: prefer day_summary, fall back to interval increments
        healthRecords.merge(chunks, now)
        val syncDevice =
            entries.firstNotNullOfOrNull { it.optJSONArray("device_info")?.optJSONObject(0) }
        val recovered =
            if (receivedSync) {
                stepSnapshot.accept(syncDevice, chunks[HealthStepParser.MODULE_STEP_COUNT], now)
            } else null
        if (recovered != null) {
            stepsAccumulator = recovered.total
            healthRecords.replaceTodaySteps(recovered.records, now)
            stepsSeenRecords.clear()
            stepContributions.clear()
            recovered.records.forEach { record ->
                val id = HealthStepParser.recordIdentity(record)
                stepsSeenRecords.add(id)
                stepContributions[id] =
                    HealthStepParser.StepContribution(
                        HealthStepParser.recordSteps(record),
                        HealthStepParser.recordUpdateTime(record),
                    )
            }
            stepsSummaryThrough = 0L
            stepsCoverageComplete = true
            newSteps = recovered.total
            todayHours = HealthTimeline.emptyHours()
            todayHours =
                HealthTimeline.resolveTodayHours(
                    todayHours,
                    null,
                    recovered.records,
                    nowMillis = now,
                )
            LogBus.log("[健康] 完整回补校准：今日 ${recovered.records.size} 条记录，共 ${recovered.total} 步")
        }
        val summary =
            HealthStepParser.latestDaySummary(
                chunks[HealthStepParser.MODULE_DAY_SUMMARY].orEmpty(),
                now,
            )
        val summarySteps = summary?.let(HealthStepParser::daySummarySteps) ?: -1
        val stepBatch =
            HealthStepParser.mergeBatch(
                stepsAccumulator,
                stepsSeenRecords,
                chunks[HealthStepParser.MODULE_STEP_COUNT].orEmpty(),
                summary,
                stepsSummaryThrough,
                now,
                contributions = stepContributions,
            )
        stepsAccumulator = stepBatch.total
        stepsSummaryThrough = stepBatch.summaryThroughMillis
        if (summary != null) {
            val cal = summary.optDouble("calorie", -1.0).toFloat()
            if (cal >= 0f) newCal = cal
            val dist = summary.optDouble("distance", -1.0).toFloat()
            if (dist >= 0f) newDist = dist
            if (summarySteps >= 0) {
                LogBus.log(
                    "[健康] 全天步数汇总：$summarySteps 步（run=${summary.optInt("run_step_count")} walk=${summary.optInt("walk_step_count")}）"
                )
            }
        }
        if (chunks.containsKey(HealthStepParser.MODULE_STEP_COUNT)) {
            LogBus.log("[健康] 区间步数：新增 ${stepBatch.added} 步，当日累计 $stepsAccumulator 步")
        }

        // 全天汇总优先；无汇总时用增量累计；两者都取较大值，且不允许相对已显示值倒退
        val resolved = HealthStepParser.resolveSteps(summarySteps, stepsAccumulator, newSteps)
        if (resolved >= 0) newSteps = if (stepBatch.added < 0) stepsAccumulator else resolved

        // All transports and business chunks share retained records before projection.
        if (!isActive()) return false
        val projected = projectedHealth(now)
        if (!isActive()) return false
        if (healthRecords.hasModule(HeartRateLog.MODULE)) {
            heartRatePoints = projected.heartRatePoints
            heartRateHistory = projected.heartRateHistory
            heartRateDays.clear()
            heartRateDays.putAll(projected.heartRateDays)
            latestHeartRate = projected.latestHeartRate
            newHr = latestHeartRate?.bpm ?: -1
        }
        if (healthRecords.hasModule(StressLog.MODULE)) {
            stressHistory = projected.stressHistory
            stressDays.clear()
            stressDays.putAll(projected.stressDays)
            latestStress = projected.latestStress
            projected.latestStress?.let { newStress = StressLog.roundedScore(it) }
        }
        projected.calories?.let { newCal = it }
        projected.distanceMeters?.let { newDist = it }
        if (projected.watchGoal > 0) watchStepGoal = projected.watchGoal
        if (projected.recommendedGoal in HealthGoals.MIN_STEP_GOAL..HealthGoals.MAX_STEP_GOAL) {
            recommendedStepGoal = projected.recommendedGoal
        }
        summary?.let { record ->
            val recommendation = record.optInt("recommendation", 0)
            if (recommendation in HealthGoals.MIN_STEP_GOAL..HealthGoals.MAX_STEP_GOAL) {
                recommendedStepGoal = recommendation
            }
        }
        metricSamples.clear()
        metricSamples.putAll(projected.metrics)
        todayFloors = projected.floors
        exercises = projected.exercises
        sleepHistory.clear()
        sleepHistory.putAll(projected.sleepHistory)
        publishSleepDay(projected.sleepSessions, now)
        projected.activityHistory.forEach { (day, activity) -> dailyHistory[day] = activity }
        todayHours = projected.hours
        if (stepsCoverageComplete && healthRecords.hasModule(HealthStepParser.MODULE_STEP_COUNT)) {
            newSteps = healthRecords.todaySteps(now).sumOf(HealthStepParser::recordSteps)
            stepsAccumulator = newSteps
        }
        LogBus.log(
            "[健康汇总] 心率24h=${heartRatePoints.size} 点/历史 ${heartRateDays.size} 天；" +
                "压力读数=${stressHistory.values.sumOf { it.size}} 点/历史 ${stressDays.size} 天；" +
                "睡眠=${projected.sleepSessions.size} 条，运动=${exercises.size} 条，今日楼层=$todayFloors"
        )

        if (
            chunks.keys.any {
                it in
                    setOf(ExerciseLog.MODULE, ExerciseLog.MODULE_ALIAS, ExerciseLog.MODULE_ROUTINE)
            }
        ) {
            val retained =
                healthRecords
                    .records(
                        ExerciseLog.MODULE,
                        ExerciseLog.MODULE_ALIAS,
                        ExerciseLog.MODULE_ROUTINE,
                    )
                    .size
            LogBus.log(
                "[运动] 已保留=$retained 已解析=${exercises.size} 独立训练=${ExerciseLog.topLevel(exercises).size} 类型=${exercises.groupingBy { it.typeCode }.eachCount()}"
            )
        }
        state.update {
            it.copy(
                todaySteps = newSteps,
                todayCalories = newCal,
                todayDistanceMeters = newDist,
                lastHeartRate = newHr,
                latestHeartRate = latestHeartRate,
                latestStress = latestStress,
                stressHistory = stressHistory,
                stressDays = stressDays.toMap(),
                lastStressScore = newStress,
                lastHealthSyncTime = if (receivedSync) now else it.lastHealthSyncTime,
            )
        }
        publishHealthSummary()
        return true
    }

    private fun onPacketPersisted(packet: HealthPacket, request: JSONObject, now: Long) {
        val chunks = packet.chunks
        val receivedSync =
            packet.direction == HealthPacket.Direction.FROM_WATCH &&
                request.optString("message") == WcsPaths.HEALTH_MSG_REQUEST &&
                packet.action == WcsPaths.HEALTH_ACTION_SYNC_DATA
        val receivedHeart = receivedSync && chunks[HeartRateLog.MODULE].orEmpty().isNotEmpty()
        if (receivedHeart) {
            state.update { it.copy(lastHeartRateReportTime = now) }
        }
        if (receivedSync) {
            chunks[VascularLoadLog.MODULE]?.let { rows ->
                val parsed = rows.count { VascularLoadLog.parse(it) != null }
                LogBus.log("[血管负荷] 数据已保存 received=${rows.size} parsed=$parsed")
                if (parsed < rows.size) {
                    LogBus.error(
                        "[血管负荷] 部分记录无法投影 category=invalid_record ignored=${rows.size - parsed}"
                    )
                }
            }
            val preferences = chunks["com.samsung.shealth.preferences"].orEmpty()
            if (preferences.isNotEmpty()) onMeasurementPreferences(preferences)
        }
    }

    private fun finishPacket(result: HealthMessagePipeline.Result.Completed, request: JSONObject) {
        if (!isActive()) return
        result.ackCursor?.let { cursor ->
            if (respondHealth(cursor.sequenceNum, cursor.action, request))
                healthSync.onWatchRequest(cursor.action)
        }
        _packets.update { (it + result.packet).takeLast(25) }
    }

    /** 回 RESPONSE {action, result:"SUCCESS"} */
    private fun respondHealth(seq: Int, action: String, request: JSONObject): Boolean {
        val reply =
            JSONObject()
                .put("message", WcsPaths.HEALTH_MSG_RESPONSE)
                .put("type", WcsPaths.HEALTH_TYPE_DATA)
                .put("sender", request.optString("receiver", WcsPaths.HEALTH_PHONE_SYNC))
                .put("receiver", request.optString("sender", WcsPaths.HEALTH_WATCH_SYNC))
                .put("version", request.optDouble("version", 5.03))
                .put("sequence_num", seq)
                .put("source_node", request.optString("destination_node", session.watchNode))
                .put("destination_node", request.optString("source_node", ""))

        val payload =
            JSONArray()
                .put(
                    JSONObject()
                        .put(
                            "device_info",
                            JSONArray()
                                .put(
                                    JSONObject()
                                        .put("device", android.os.Build.MODEL ?: "Android")
                                        .put("device_type", 10062)
                                        .put("version", 4.51)
                                        .put("last_sync_time", System.currentTimeMillis())
                                ),
                        )
                )
                .put(
                    JSONObject()
                        .put(
                            "message_info",
                            JSONArray()
                                .put(JSONObject().put("action", action).put("result", "SUCCESS")),
                        )
                )

        reply.put("body", encodeHealthBody(payload.toString()))
        val queued =
            session.sendRawJson(
                path = WcsPaths.HEALTH_MESSAGE,
                obj = reply,
                senderPkg = WcsPaths.PKG_SHEALTH,
                senderNode = WcsPaths.SIGNATURE_SHEALTH,
            )
        LogBus.debug {
            "[健康→] ACK seq=$seq action=$action queued=$queued payload=${LogBus.describe(payload)}"
        }
        if (!queued) LogBus.error("[健康] ACK 入队失败 seq=$seq action=$action")
        return queued
    }

    /**
     * 处理手表与手机间的 Samsung Health 能力协商 (/samsung_health/capability)。
     *
     * Wear OS 4/5 (Galaxy Watch6/7/Ultra) 在健康同步时强制执行 HealthNode 握手： 手表在收到 REQUEST_DATA 时若未就绪，会向手机下发
     * com.samsung.shealth.REQUEST_CAPABILITY； 手机必须响应
     * com.samsung.shealth.RESPONSE_CAPABILITY，手表接收后创建 HealthNode 并刷新同步队列。
     */
    @Synchronized
    fun handleCapability(json: JSONObject): Boolean {
        if (
            !isActive() || (!HealthCapability.isRequest(json) && !HealthCapability.isResponse(json))
        )
            return false
        val supported = HealthCapability.vascularLoadSupported(json)
        healthPrefs.edit().putBoolean("vascular_load_supported", supported).apply()
        state.update { it.copy(vascularLoadSupported = supported) }
        LogBus.log("[血管负荷] 手表能力确认 supported=$supported")
        val type = json.optString("capability_type")
        val model = json.optString("model_name", "Wearable")
        return when (type) {
            HealthCapability.REQUEST_CAPABILITY -> {
                LogBus.log("[健康] 收到手表能力协商请求 REQUEST_CAPABILITY (model=$model)")
                respondCapability()
            }
            HealthCapability.RESPONSE_CAPABILITY -> {
                LogBus.log("[健康] 收到手表能力协商响应 RESPONSE_CAPABILITY (model=$model)")
                true
            }
            else -> false
        }.also {
            if (supported) scheduleVascularLoadBackfill()
            else {
                vascularLoadBackfillJob?.cancel()
                vascularLoadBackfillJob = null
            }
        }
    }

    /** 回复能力协商响应 RESPONSE_CAPABILITY，在手表端建立 HealthNode 并刷新同步队列。 */
    fun respondCapability(): Boolean {
        if (!isActive()) return false
        val phoneId =
            if (session.phoneNode.isNotEmpty()) session.phoneNode else WcsPaths.FALLBACK_NODE
        val response =
            HealthCapability.buildResponse(
                deviceId = phoneId,
                modelName = android.os.Build.MODEL ?: "Android",
            )
        LogBus.log("[健康→] 回复能力协商响应 RESPONSE_CAPABILITY")
        return session.sendRawJson(
            path = WcsPaths.HEALTH_CAPABILITY,
            obj = response,
            senderPkg = WcsPaths.PKG_SHEALTH,
            senderNode = WcsPaths.SIGNATURE_SHEALTH,
        )
    }

    /** 手动和自动同步共用防重入入口；缺少当天完整覆盖时自动发起冷同步回补。 */
    fun requestSync() = healthSync.request()

    /**
     * 按模块定向请求（诊断 / 补数）。
     *
     * `request_module_list` 用的是 RequestModule 枚举名（PEDOMETER / PEDOMETER_RECOMMENDATION /
     * DAILY_ACTIVITY …），不是数据类型名。配合 `fromStartOfDay` 把窗口拉到今天 00:00， 可以用来验证「手表能否在增量游标之外，按模块补发历史数据」。
     * [hours] > 0 时改为固定回溯窗口，例如 `SLEEP` + 48 小时可核对午休。
     */
    fun requestModule(module: String, fromStartOfDay: Boolean = true, hours: Int = 0): Boolean {
        val now = System.currentTimeMillis()
        val start =
            when {
                hours > 0 -> now - hours.coerceAtMost(24 * 30) * 3600_000L
                fromStartOfDay ->
                    runCatching {
                            java.time.LocalDate.now()
                                .atStartOfDay(java.time.ZoneId.systemDefault())
                                .toInstant()
                                .toEpochMilli()
                        }
                        .getOrDefault(now - 24 * 3600_000L)
                else -> state.value.lastHealthSyncTime
            }
        LogBus.log("[健康→] 定向请求模块 $module（窗口 $start .. $now）")
        // An explicit window is a historical pull: send last_sync_time=0 so the watch does not
        // skip records older than the phone cursor (the reason a nap query could look empty).
        return healthSync.request {
            sendHealthSyncRequest(module = module, windowStart = start, forceRecovery = hours > 0)
        }
    }

    fun requestRecovery(): Boolean =
        healthSync.request { sendHealthSyncRequest(forceRecovery = true) }

    @Synchronized
    private fun scheduleVascularLoadBackfill() {
        if (
            !state.value.vascularLoadSupported ||
                healthPrefs.getBoolean("vascular_load_history_recovered", false) ||
                vascularLoadBackfillJob?.isActive == true
        )
            return
        vascularLoadBackfillJob =
            scope.launch {
                LogBus.log("[血管负荷] 首次历史回补已排队，等待同步通道空闲")
                try {
                    val recovered = syncVascularLoadHistory(state, ::requestVascularLoadSync)
                    if (!isActive()) return@launch
                    if (recovered) {
                        healthPrefs
                            .edit()
                            .putBoolean("vascular_load_history_recovered", true)
                            .apply()
                        LogBus.log("[血管负荷] 首次历史回补完成，已登记完成标记")
                    } else {
                        LogBus.error(
                            "[血管负荷] 首次历史回补未完成 status=${state.value.healthSyncStatus} supported=${state.value.vascularLoadSupported}，保留重试资格"
                        )
                    }
                } catch (cancelled: kotlinx.coroutines.CancellationException) {
                    LogBus.log(
                        "[血管负荷] 首次历史回补已取消 status=${state.value.healthSyncStatus} supported=${state.value.vascularLoadSupported}，保留重试资格"
                    )
                    throw cancelled
                }
            }
    }

    fun requestVascularLoadSync(): Boolean {
        if (!state.value.vascularLoadSupported) return false
        return healthSync.request {
            LogBus.log("[血管负荷→] 请求零游标历史回补 scope=all_health_modules")
            sendHealthSyncRequest(forceRecovery = true)
        }
    }

    private fun sendHealthSyncRequest(
        module: String? = null,
        windowStart: Long? = null,
        forceRecovery: Boolean = false,
    ): Boolean {
        val now = System.currentTimeMillis()
        // Called under HealthSyncCoordinator's lock: do not acquire the repository monitor
        // here (handleHealth holds it while completing coordinator callbacks).
        val sleepRecovery =
            sleepMissingRawId?.takeIf { it.isNotBlank() && it != sleepRecoveryRequestedFor }
        val plan =
            syncRequestPolicy.plan(
                now = now,
                lastSyncTime = state.value.lastHealthSyncTime,
                needsRecovery =
                    healthDay != todayKey() || !stepsCoverageComplete || sleepRecovery != null,
                forceRecovery = forceRecovery,
                windowStart = windowStart,
            )
        if (plan.recovery) stepSnapshot.begin() else stepSnapshot.reset()

        val messageInfo = JSONObject().put("action", WcsPaths.HEALTH_ACTION_REQUEST_DATA)
        if (!module.isNullOrBlank()) messageInfo.put("request_module_list", module)

        val deviceInfo =
            JSONObject()
                .put("device", android.os.Build.MODEL ?: "Android")
                .put("device_type", 10062)
                .put("version", 4.51)
                .put("last_sync_time", plan.lastSyncTime)
                .put("start_time", plan.startTime)
                .put("end_time", now)
                .put("is_last_chunk", true)
        val payload =
            JSONArray()
                .put(JSONObject().put("message_info", JSONArray().put(messageInfo)))
                .put(JSONObject().put("device_info", JSONArray().put(deviceInfo)))

        val msg =
            JSONObject()
                .put("message", WcsPaths.HEALTH_MSG_REQUEST)
                .put("type", WcsPaths.HEALTH_TYPE_DATA)
                .put("sender", WcsPaths.HEALTH_PHONE_SYNC)
                .put("receiver", WcsPaths.HEALTH_WATCH_SYNC)
                .put("version", 5.03)
                .put("sequence_num", (seqCounter++ % 1000) + 1)
                .put("source_node", WcsPaths.PKG_SHEALTH)
                .put("destination_node", session.watchNode)
                .put("body", encodeHealthBody(payload.toString()))

        LogBus.log(
            "[健康→] 发起健康同步 REQUEST_DATA recovery=${plan.recovery}" +
                (if (module.isNullOrBlank()) "" else " module=$module")
        )
        LogBus.debug {
            "[健康→] 同步计划详情: recovery=${plan.recovery} lastSyncTime=${plan.lastSyncTime} startTime=${plan.startTime} windowStart=$windowStart forceRecovery=$forceRecovery"
        }
        val sent =
            session.sendRawJson(
                path = WcsPaths.HEALTH_MESSAGE,
                obj = msg,
                senderPkg = WcsPaths.PKG_SHEALTH,
                senderNode = WcsPaths.SIGNATURE_SHEALTH,
            )
        if (sent && plan.recovery) {
            syncRequestPolicy.onSent(plan, now)
            healthPrefs.edit().putLong("last_recovery_attempt_at", now).apply()
            LogBus.debug { "[健康→] 冷同步/回补计划已登记确认" }
        }
        if (sent && plan.recovery && sleepRecovery != null) {
            sleepRecoveryRequestedFor = sleepRecovery
            LogBus.log("[睡眠分析] 为缺少原始传感器数据的睡眠请求一次历史回补")
        }
        return sent
    }

    private var seqCounter = 1

    // Lifecycle
    fun startSyncPhases() {
        if (!isActive()) return
        healthSync.start()
        val phoneId = session.phoneNode.ifEmpty { WcsPaths.FALLBACK_NODE }
        session.sendRawJson(
            path = WcsPaths.HEALTH_CAPABILITY,
            obj = HealthCapability.buildRequest(phoneId, android.os.Build.MODEL ?: "Android"),
            senderPkg = WcsPaths.PKG_SHEALTH,
            senderNode = WcsPaths.SIGNATURE_SHEALTH,
        )
        scheduleVascularLoadBackfill()
    }

    /**
     * Waits for an in-flight health write; new writes stop because the repository is closed first.
     */
    @Synchronized
    fun stopSyncPhases() {
        vascularLoadBackfillJob?.cancel()
        vascularLoadBackfillJob = null
        healthSync.stop()
        stepSnapshot.reset()
    }

    /** ECG 入库；持久化失败时回滚，避免 ACK 一份只存在于内存的记录。 */
    @Synchronized
    fun onEcgReceived(ecg: EcgRecord): Boolean {
        if (!isActive()) return false
        val previous = ecgRecords
        ecgRecords = EcgLog.merge(previous, listOf(ecg))
        if (persistHealthCache(durable = true)) {
            publishHealthSummary()
            return true
        }
        ecgRecords = previous
        return false
    }

    /** 血压入库；持久化失败时回滚。 */
    @Synchronized
    fun onBpReceived(bp: BpRecord): Boolean {
        if (!isActive()) return false
        val previous = bpRecords
        bpRecords = BpLog.merge(previous, listOf(bp))
        if (persistHealthCache(durable = true)) {
            publishHealthSummary()
            return true
        }
        bpRecords = previous
        return false
    }

    fun onBpConfigurationsReceived(rows: List<JSONObject>): Boolean =
        isActive() && bpCalibrationConfigs.persist(rows)

    companion object {
        private const val MIN_MANUAL_NAP_MINUTES = 5L
        private const val MAX_MANUAL_NAP_MINUTES = 12L * 60L

        fun encodeHealthBody(json: String): String =
            Base64.encodeToString(gzip(json.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)

        /** 解出健康 body（type=DATA 是数组，type=MESSAGE 是单个对象，统一成数组）。 */
        fun decodeHealthBody(b64: String): JSONArray = HealthJson.entries(b64)

        private fun gzip(data: ByteArray): ByteArray {
            val bos = ByteArrayOutputStream()
            GZIPOutputStream(bos).use { it.write(data) }
            return bos.toByteArray()
        }
    }
}
