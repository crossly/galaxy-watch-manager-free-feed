package dev.ricky.galaxywatchmanagerfree.feature

import org.json.JSONArray
import org.json.JSONObject

/** JSON Schema definitions referenced by filenames, shipped inside every archive. */
object HealthExportSchema {
    val document: JSONObject
        get() {
            val definitions = JSONObject()
            fun define(name: String, schema: JSONObject): JSONObject {
                definitions.put(name, schema)
                return ref(name)
            }
            val string = field("string")
            val nullableString = field("string", nullable = true)
            val integer = field("integer")
            val count = field("integer", minimum = 0)
            val nullableCount = field("integer", nullable = true, minimum = 0)
            val number = field("number")
            val nullableAmount = field("number", nullable = true, minimum = 0)
            val boolean = field("boolean")
            val nullableBoolean = field("boolean", nullable = true)
            val instant = field("string").put("format", "date-time")
            val nullableInstant = field("string", nullable = true).put("format", "date-time")
            val date = field("string").put("format", "date")
            val nullableDate = field("string", nullable = true).put("format", "date")
            val provenance =
                linkedMapOf(
                    "source" to
                        choices("watch", "retained_app_cache", "watch_samsung_health_monitor"),
                    "source_module" to nullableString,
                    "source_record_id" to string,
                    "source_revision_epoch_ms" to nullableCount,
                )
            val timed =
                linkedMapOf(
                    "record_id" to string,
                    "start_time" to instant,
                    "start_time_epoch_ms" to field("integer", minimum = 1),
                )
            define(
                "measurement",
                objectOf(
                        timed +
                            provenance +
                            linkedMapOf(
                                "type" to
                                    choices(
                                        "heart_rate",
                                        "oxygen_saturation",
                                        "skin_temperature",
                                        "respiratory_rate",
                                        "heart_rate_variability",
                                        "stress",
                                        "blood_pressure_systolic",
                                        "blood_pressure_diastolic",
                                        "pulse",
                                    ),
                                "value" to number,
                                "unit" to
                                    choices("count/min", "%", "Cel", "ms", "{score}", "mm[Hg]"),
                                "source_field" to nullableString,
                                "method" to
                                    choices("rmssd", "sdnn", "unknown", "samsung_raw_score", null),
                                "minimum_value" to number,
                                "maximum_value" to number,
                            ),
                        required = timed.keys + setOf("source", "type", "value", "unit"),
                    )
                    .put(
                        "allOf",
                        JSONArray(
                            listOf(
                                unitRule(
                                    listOf("heart_rate", "respiratory_rate", "pulse"),
                                    "count/min",
                                ),
                                unitRule(listOf("oxygen_saturation"), "%"),
                                unitRule(listOf("skin_temperature"), "Cel"),
                                unitRule(
                                    listOf("heart_rate_variability"),
                                    "ms",
                                    listOf("rmssd", "sdnn", "unknown"),
                                ),
                                unitRule(listOf("stress"), "{score}", listOf("samsung_raw_score")),
                                unitRule(
                                    listOf("blood_pressure_systolic", "blood_pressure_diastolic"),
                                    "mm[Hg]",
                                ),
                            )
                        ),
                    ),
            )
            define("measurements", arrayOf(ref("measurement")))
            define(
                "activity_interval",
                objectOf(
                    timed +
                        provenance +
                        linkedMapOf(
                            "end_time" to nullableInstant,
                            "steps" to nullableCount,
                            "active_energy_kcal" to nullableAmount,
                            "distance_m" to nullableAmount,
                        )
                ),
            )
            define("activity_intervals", arrayOf(ref("activity_interval")))
            define(
                "daily_activity",
                arrayOf(
                    objectOf(
                        linkedMapOf(
                            "local_date" to date,
                            "source" to constant("app_daily_projection"),
                            "steps" to nullableCount,
                            "active_energy_kcal" to nullableAmount,
                            "distance_m" to nullableAmount,
                            "coverage" to
                                choices(
                                    "watch_day_summary",
                                    "retained_intervals_partial",
                                    "legacy_unknown",
                                ),
                        )
                    )
                ),
            )
            define(
                "floors",
                arrayOf(
                    objectOf(
                        timed +
                            provenance +
                            linkedMapOf(
                                "end_time" to nullableInstant,
                                "floors" to nullableAmount,
                                "unit" to constant("{floor}"),
                            )
                    )
                ),
            )
            define(
                "vascular_load",
                arrayOf(
                    objectOf(
                        timed +
                            provenance +
                            linkedMapOf(
                                "end_time" to instant,
                                "samsung_type_code" to choices(1, 2, 3),
                                "type" to choices("reset", "baseline", "measurement"),
                                "measurement" to field("number", nullable = true),
                                "time_offset_ms" to
                                    field("integer")
                                        .put("minimum", -64_800_000)
                                        .put("maximum", 64_800_000),
                                "tracking_local_date" to date,
                                "band" to
                                    choices(
                                        "higher",
                                        "slightly_higher",
                                        "steady",
                                        "slightly_lower",
                                        "lower",
                                        "out_of_range_unknown",
                                        "not_enough_data",
                                    ),
                            ),
                        required =
                            timed.keys +
                                setOf(
                                    "source",
                                    "source_revision_epoch_ms",
                                    "end_time",
                                    "samsung_type_code",
                                    "type",
                                    "measurement",
                                    "time_offset_ms",
                                    "tracking_local_date",
                                    "band",
                                ),
                    )
                ),
            )
            define(
                "workouts",
                arrayOf(
                    objectOf(
                        timed +
                            linkedMapOf(
                                "samsung_type_code" to integer,
                                "end_time" to instant,
                                "active_duration_ms" to count,
                                "distance_m" to nullableAmount,
                                "energy_kcal" to nullableCount,
                                "average_heart_rate_bpm" to
                                    field("integer", nullable = true, minimum = 1),
                                "max_heart_rate_bpm" to
                                    field("integer", nullable = true, minimum = 1),
                                "min_heart_rate_bpm" to
                                    field("integer", nullable = true, minimum = 1),
                                "steps" to nullableCount,
                                "auto_detected" to nullableBoolean,
                                "source_type" to nullableCount,
                                "title" to nullableString,
                                "count" to nullableCount,
                                "count_type" to nullableCount,
                                "mean_speed_m_per_s" to nullableAmount,
                                "max_speed_m_per_s" to nullableAmount,
                                "altitude_gain_m" to nullableAmount,
                                "altitude_loss_m" to nullableAmount,
                                "routine_id" to nullableString,
                                "is_top_level" to boolean,
                                "location_payload_present" to boolean,
                                "location_point_count" to count,
                                "source" to choices("watch", "retained_app_cache"),
                                "source_module" to nullableString,
                                "source_revision_epoch_ms" to nullableCount,
                            )
                    )
                ),
            )
            define(
                "blood_pressure",
                arrayOf(
                    objectOf(
                        linkedMapOf(
                            "record_id" to string,
                            "start_time" to instant,
                            "systolic_mmHg" to field("integer", minimum = 1),
                            "diastolic_mmHg" to field("integer", minimum = 1),
                            "pulse_bpm" to field("integer", nullable = true, minimum = 1),
                        )
                    )
                ),
            )
            val stage =
                define(
                    "sleep_stage",
                    objectOf(
                        linkedMapOf(
                            "start_time" to instant,
                            "end_time" to instant,
                            "stage" to choices("awake", "rem", "light", "deep"),
                        )
                    ),
                )
            define(
                "sleep_session",
                objectOf(
                    timed +
                        linkedMapOf(
                            "end_time" to instant,
                            "source" to string,
                            "recorded_end_time" to nullableInstant,
                            "time_asleep_minutes" to nullableCount,
                            "reported_sleep_minutes" to nullableCount,
                            "efficiency_percent" to
                                field("integer", nullable = true, minimum = 0).put("maximum", 100),
                            "reported_efficiency_percent" to field("integer", nullable = true),
                            "score" to
                                field("integer", nullable = true, minimum = 0).put("maximum", 100),
                            "computed_score" to
                                field("integer", nullable = true, minimum = 1).put("maximum", 99),
                            "computed_score_algorithm" to choices(SleepScore.SOURCE, null),
                            "score_source" to choices("watch", SleepScore.SOURCE, null),
                            "stages" to arrayOf(stage),
                        )
                ),
            )
            define("sleep_sessions", arrayOf(ref("sleep_session")))
            define(
                "manual_naps",
                arrayOf(
                    JSONObject()
                        .put(
                            "allOf",
                            JSONArray(
                                listOf(
                                    ref("sleep_session"),
                                    JSONObject()
                                        .put(
                                            "properties",
                                            JSONObject().put("source", constant("manual")),
                                        ),
                                )
                            ),
                        )
                ),
            )
            define(
                "local_sleep_analysis",
                arrayOf(
                    objectOf(
                        linkedMapOf(
                            "cache_key" to string,
                            "retained_result" to
                                field("object")
                                    .put(
                                        "description",
                                        "Exact retained inference result; source-specific fields are preserved without validation.",
                                    ),
                            "session" to
                                JSONObject()
                                    .put(
                                        "anyOf",
                                        JSONArray(listOf(ref("sleep_session"), field("null"))),
                                    ),
                        )
                    )
                ),
            )
            define(
                "sleep_history",
                field("object").put("propertyNames", date).put("additionalProperties", count),
            )
            define(
                "heart_rate_daily",
                arrayOf(
                    objectOf(
                        linkedMapOf(
                            "local_date" to date,
                            "minimum_bpm" to integer,
                            "average_bpm" to integer,
                            "maximum_bpm" to integer,
                            "sample_count" to count,
                        )
                    )
                ),
            )
            define(
                "stress_daily",
                arrayOf(
                    objectOf(
                        linkedMapOf(
                            "local_date" to date,
                            "minimum_score" to number,
                            "average_score" to number,
                            "maximum_score" to number,
                            "sample_count" to count,
                        )
                    )
                ),
            )
            define(
                "ecg",
                arrayOf(
                    objectOf(
                        timed +
                            linkedMapOf(
                                "average_heart_rate_bpm" to
                                    field("integer", nullable = true, minimum = 1),
                                "samsung_classification_code" to integer,
                                "sample_rate_hz" to field("number").put("exclusiveMinimum", 0),
                                "sample_count" to count,
                                "voltage_unit" to constant("mV"),
                                "waveform_file" to nullableString,
                                "source" to constant("watch_samsung_health_monitor"),
                            )
                    )
                ),
            )
            define(
                "snapshot",
                objectOf(
                    linkedMapOf(
                        "last_health_sync_epoch_ms" to count,
                        "today_local_date" to date,
                        "data_local_date" to nullableDate,
                        "data_day_steps" to nullableCount,
                        "data_day_floors" to nullableCount,
                        "floors_local_date" to nullableDate,
                        "today_steps" to nullableCount,
                        "today_floors" to nullableCount,
                        "last_stress_time" to nullableInstant,
                        "last_stress_score" to nullableCount,
                        "step_goal" to count,
                        "step_goal_source" to choices("LOCAL", "WATCH", "DEFAULT"),
                    )
                ),
            )
            define(
                "collection_setting",
                objectOf(
                    linkedMapOf(
                        "enabled" to nullableBoolean,
                        "desired" to nullableBoolean,
                        "status" to
                            choices("UNKNOWN", "CONFIRMED", "PENDING", "UNCONFIRMED", "FAILED"),
                        "can_write" to boolean,
                        "last_received_enabled" to nullableBoolean,
                        "last_received_revision_epoch_ms" to nullableCount,
                        "pending_revision_epoch_ms" to nullableCount,
                    )
                ),
            )
            define(
                "collection_settings",
                objectOf(
                        linkedMapOf(
                            "sleep_oxygen" to ref("collection_setting"),
                            "stress_continuous" to ref("collection_setting"),
                            "vascular_load" to ref("collection_setting"),
                        ),
                        required = emptySet(),
                    )
                    .put("minProperties", 0)
                    .put("maxProperties", 3),
            )
            define(
                "dataset",
                objectOf(
                    linkedMapOf(
                        "record_count" to count,
                        "first_start_time" to nullableInstant,
                        "last_end_time" to nullableInstant,
                        "first_local_date" to nullableDate,
                        "last_local_date" to nullableDate,
                        "coverage" to constant("retained_only"),
                    )
                ),
            )
            define(
                "source_module",
                objectOf(
                    linkedMapOf(
                        "record_count" to count,
                        "first_time" to nullableInstant,
                        "last_time" to nullableInstant,
                        "retention_days" to nullableCount,
                        "record_limit" to count,
                        "previously_truncated" to constant("unknown"),
                    )
                ),
            )
            define(
                "retention",
                objectOf(
                    linkedMapOf(
                        "raw_default_days" to count,
                        "ecg_record_limit" to count,
                        "bp_record_limit" to count,
                        "export_applies_additional_trimming" to constant(false),
                        "previously_deleted_data" to constant("unavailable"),
                        "manual_naps" to constant("all_retained"),
                        "local_sleep_analysis" to constant("all_retained_versions"),
                    )
                ),
            )
            define(
                "sync",
                objectOf(
                    linkedMapOf(
                        "status" to
                            choices("DISCONNECTED", "WAITING", "SYNCING", "IDLE", "TIMED_OUT"),
                        "last_health_sync_epoch_ms" to nullableCount,
                        "historical_completeness" to constant("unknown"),
                    )
                ),
            )
            define(
                "manifest",
                objectOf(
                    linkedMapOf(
                        "schema" to constant(HealthArchive.SCHEMA),
                        "exported_at" to instant,
                        "time_zone" to string,
                        "watch_model" to string,
                        "measurement_count" to count,
                        "ecg_count" to count,
                        "bp_count" to count,
                        "files" to
                            arrayOf(
                                objectOf(
                                    linkedMapOf(
                                        "path" to string,
                                        "sha256" to field("string").put("pattern", "^[a-f0-9]{64}$"),
                                    )
                                )
                            ),
                        "scope" to constant("retained_local_current_device"),
                        "datasets" to field("object").put("additionalProperties", ref("dataset")),
                        "source_modules" to
                            field("object").put("additionalProperties", ref("source_module")),
                        "retention" to ref("retention"),
                        "sync" to ref("sync"),
                    )
                ),
            )
            define(
                "source_records",
                field("object")
                    .put(
                        "description",
                        "Retained vendor modules, identity and revisions. Raw fields are preserved without validating vendor payloads.",
                    ),
            )
            define(
                "retained_cache",
                field("object")
                    .put(
                        "description",
                        "Device-scoped retained cache, including legacy encodings. Dynamic cache fields are preserved without validation.",
                    ),
            )
            val files =
                linkedMapOf(
                    "measurements.json" to "measurements",
                    "activity_intervals.json" to "activity_intervals",
                    "daily_activity.json" to "daily_activity",
                    "floors.json" to "floors",
                    "vascular_load.json" to "vascular_load",
                    "workouts.json" to "workouts",
                    "blood_pressure.json" to "blood_pressure",
                    "latest_sleep.json" to "sleep_sessions",
                    "latest_sleep_sessions.json" to "sleep_sessions",
                    "sleep_sessions.json" to "sleep_sessions",
                    "manual_naps.json" to "manual_naps",
                    "local_sleep_analysis.json" to "local_sleep_analysis",
                    "sleep_history.json" to "sleep_history",
                    "heart_rate_daily.json" to "heart_rate_daily",
                    "stress_daily.json" to "stress_daily",
                    "ecg.json" to "ecg",
                    "snapshot.json" to "snapshot",
                    "collection_settings.json" to "collection_settings",
                    "source_records.json" to "source_records",
                    "retained_cache.json" to "retained_cache",
                    "manifest.json" to "manifest",
                )
            return JSONObject()
                .put("\$schema", "https://json-schema.org/draft/2020-12/schema")
                .put("\$id", "urn:galaxy-watch-manager-free:health:v3")
                .put("title", "Health archive v3 records")
                .put(
                    "description",
                    "Apply the files mapping to each JSON file. CSV uses the same field semantics; empty CSV cells represent null or absent optional fields. Only retained local data is covered.",
                )
                .put("files", JSONObject(files.mapValues { (_, name) -> "#/\$defs/$name" }))
                .put("\$defs", definitions)
        }

    private fun field(
        type: String,
        nullable: Boolean = false,
        minimum: Number? = null,
    ): JSONObject =
        JSONObject().put("type", if (nullable) JSONArray(listOf(type, "null")) else type).apply {
            if (minimum != null) put("minimum", minimum)
        }

    private fun choices(vararg values: Any?): JSONObject =
        JSONObject().put("enum", JSONArray(values.map { it ?: JSONObject.NULL }))

    private fun constant(value: Any): JSONObject = JSONObject().put("const", value)

    private fun ref(name: String): JSONObject = JSONObject().put("\$ref", "#/\$defs/$name")

    private fun arrayOf(items: JSONObject): JSONObject = field("array").put("items", items)

    private fun objectOf(
        properties: Map<String, JSONObject>,
        required: Set<String> = properties.keys,
    ): JSONObject =
        field("object")
            .put("properties", JSONObject(properties))
            .put("required", JSONArray(required.toList()))
            .put("additionalProperties", false)

    private fun unitRule(
        types: List<String>,
        unit: String,
        methods: List<String>? = null,
    ): JSONObject =
        JSONObject()
            .put(
                "if",
                JSONObject()
                    .put(
                        "properties",
                        JSONObject().put("type", JSONObject().put("enum", JSONArray(types))),
                    ),
            )
            .put(
                "then",
                JSONObject()
                    .put(
                        "properties",
                        JSONObject().put("unit", constant(unit)).apply {
                            if (methods != null)
                                put("method", JSONObject().put("enum", JSONArray(methods)))
                        },
                    )
                    .apply { if (methods != null) put("required", JSONArray(listOf("method"))) },
            )
}
