package dev.ricky.galaxywatchmanagerfree.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.EnterExitState
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.Easing
import androidx.compose.animation.core.PathEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.feature.WatchRepository
import dev.ricky.galaxywatchmanagerfree.feature.WatchState
import dev.ricky.galaxywatchmanagerfree.ui.components.*
import dev.ricky.galaxywatchmanagerfree.ui.theme.*

private val SettingsSlideEasing =
    PathEasing(
        Path().apply {
            moveTo(0f, 0f)
            cubicTo(0.05f, 0f, 0.133333f, 0.06f, 0.166666f, 0.4f)
            cubicTo(0.208333f, 0.82f, 0.25f, 1f, 1f, 1f)
        }
    )
private val SettingsFadeCurve = CubicBezierEasing(0.215f, 0.61f, 0.355f, 1f)
private val SettingsFadeIn = Easing { fraction ->
    if (fraction < 0.2f) 0f
    else SettingsFadeCurve.transform(((fraction - 0.15f) / 0.4f).coerceIn(0f, 1f))
}
private val SettingsFadeOut = Easing { fraction -> if (fraction < 0.2f) fraction / 0.3f else 1f }

@Composable
fun SettingsTab(
    state: WatchState,
    repo: WatchRepository,
    modifier: Modifier = Modifier,
    onDetailChanged: (Boolean) -> Unit = {},
) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources
    val healthMeasurementState by repo.healthMeasurements.state.collectAsState()

    var route by rememberSaveable { mutableStateOf<String?>(null) }
    val onDetail by rememberUpdatedState(onDetailChanged)
    SideEffect { onDetail(route != null) }
    val rootScroll = androidx.compose.foundation.lazy.rememberLazyListState()
    fun navigate(next: String?) {
        onDetail(next != null)
        route = next
    }
    DisposableEffect(Unit) { onDispose { onDetail(false) } }
    BackHandler(route != null) { navigate(null) }
    val context = LocalContext.current
    val language = androidx.appcompat.app.AppCompatDelegate.getApplicationLocales().toLanguageTags()
    val languageOptions =
        listOf(
            "" to strings.getString(R.string.language_system),
            "zh-CN" to strings.getString(R.string.language_chinese),
            "en" to strings.getString(R.string.language_english),
        )
    val languageLabel =
        languageOptions.firstOrNull { it.first == language }?.second
            ?: strings.getString(R.string.language_system)
    val mode by ThemeController.mode.collectAsState()
    val accent by ThemeController.color.collectAsState()
    val navigationStyle by ThemeController.navigationStyle.collectAsState()
    val glassEffect by ThemeController.glassEffect.collectAsState()
    val modeTitle =
        when (mode) {
            ThemeController.MODE_LIGHT -> strings.getString(R.string.light)
            ThemeController.MODE_DARK -> strings.getString(R.string.dark)
            else -> strings.getString(R.string.system_default)
        }
    AnimatedContent(
        targetState = route,
        modifier = modifier.fillMaxSize(),
        label = "SettingsRoute",
        transitionSpec = {
            val direction = if (targetState != null) 1 else -1
            (slideInHorizontally(tween(450, easing = SettingsSlideEasing)) {
                    direction * it / 4
                } togetherWith
                    slideOutHorizontally(tween(450, easing = SettingsSlideEasing)) {
                        -direction * it / 4
                    })
                .apply { targetContentZIndex = direction.toFloat() }
                .using(null)
        },
    ) { page ->
        val pageOpacity =
            transition.animateFloat(
                transitionSpec = {
                    tween(
                        450,
                        easing =
                            if (targetState == EnterExitState.Visible) SettingsFadeIn
                            else SettingsFadeOut,
                    )
                },
                label = "SettingsPageFade",
            ) {
                if (it == EnterExitState.Visible) 1f else 0f
            }
        val surface = DeepCanvas
        val pageModifier =
            Modifier.fillMaxSize()
                .drawWithContent {
                    val opacity = pageOpacity.value
                    if (opacity > 0f) {
                        drawRect(surface)
                        drawContent()
                        drawRect(surface.copy(alpha = 1f - opacity))
                    }
                }
                .background(surface)
        if (page == null) {
            Column(pageModifier) {
                PageToolbar(strings.getString(R.string.settings))
                LazyColumn(
                    state = rootScroll,
                    contentPadding =
                        PaddingValues(
                            start = 16.dp,
                            end = 16.dp,
                            top = 4.dp,
                            bottom = LocalRootPageBottomPadding.current,
                        ),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                ) {
                    item {
                        SectionHeader(strings.getString(R.string.app))
                        GroupedCard(innerPadding = 0.dp) {
                            GroupedCardRow(
                                strings.getString(R.string.appearance),
                                subtitle = modeTitle,
                                icon = Icons.Default.Palette,
                                showChevron = true,
                                onClick = { navigate("appearance") },
                            )
                            GroupedDivider()
                            GroupedCardRow(
                                strings.getString(R.string.language),
                                subtitle = languageLabel,
                                icon = Icons.Default.Language,
                                showChevron = true,
                                onClick = { navigate("language") },
                            )
                            GroupedDivider()
                            GroupedCardRow(
                                strings.getString(R.string.export_health_data),
                                icon = Icons.Default.FileDownload,
                                showChevron = true,
                                onClick = { navigate("export") },
                            )
                            GroupedDivider()
                            GroupedCardRow(
                                strings.getString(R.string.notification_and_forwarding),
                                subtitle =
                                    strings.getString(R.string.notification_forwarding_subtitle),
                                icon = Icons.Default.Notifications,
                                showChevron = true,
                                onClick = { navigate("notifications") },
                            )
                            GroupedDivider()
                            GroupedCardRow(
                                strings.getString(R.string.notification_bar_settings),
                                subtitle =
                                    strings.getString(R.string.notification_bar_settings_subtitle),
                                icon = Icons.Default.NotificationsActive,
                                showChevron = true,
                                onClick = { navigate("notification-bar") },
                            )
                            GroupedDivider()
                            GroupedCardRow(
                                strings.getString(R.string.about_and_updates),
                                subtitle = strings.getString(R.string.version_and_app_updates),
                                icon = Icons.Default.Info,
                                showChevron = true,
                                onClick = { navigate("about") },
                            )
                        }
                    }
                    item {
                        SectionHeader(strings.getString(R.string.health))
                        GroupedCard(innerPadding = 0.dp) {
                            GroupedCardRow(
                                strings.getString(R.string.health_measurement_settings_title),
                                icon = Icons.Default.MonitorHeart,
                                showChevron = true,
                                onClick = { navigate("health-measurements") },
                            )
                        }
                    }
                    item {
                        SectionHeader(strings.getString(R.string.watch))
                        GroupedCard(innerPadding = 0.dp) {
                            val entries =
                                listOf(
                                    Triple(
                                        SettingCategory.DEVICE,
                                        Icons.Default.Bluetooth,
                                        strings.getString(R.string.paired_devices_and_auto_connect),
                                    ),
                                    Triple(
                                        SettingCategory.DISPLAY,
                                        Icons.Default.BrightnessMedium,
                                        strings.getString(
                                            R.string.brightness_always_on_display_and_wake_options
                                        ),
                                    ),
                                    Triple(
                                        SettingCategory.SOUND,
                                        Icons.AutoMirrored.Filled.VolumeUp,
                                        strings.getString(R.string.sound_and_volume),
                                    ),
                                    Triple(
                                        SettingCategory.BATTERY,
                                        Icons.Default.BatterySaver,
                                        strings.getString(
                                            R.string.power_saving_and_battery_protection
                                        ),
                                    ),
                                    Triple(
                                        SettingCategory.BUTTONS,
                                        Icons.Default.Gesture,
                                        strings.getString(
                                            R.string.buttons_gestures_and_wrist_preference
                                        ),
                                    ),
                                    Triple(
                                        SettingCategory.ACCESSIBILITY,
                                        Icons.Default.Accessibility,
                                        strings.getString(
                                            R.string.display_and_interaction_accessibility
                                        ),
                                    ),
                                )
                            entries.forEachIndexed { index, (category, icon, subtitle) ->
                                if (index > 0) GroupedDivider()
                                GroupedCardRow(
                                    strings.getString(category.titleRes),
                                    subtitle = subtitle,
                                    icon = icon,
                                    showChevron = true,
                                    onClick = { navigate(category.name) },
                                )
                            }
                        }
                    }
                    item {
                        SectionHeader(strings.getString(R.string.advanced))
                        GroupedCard(innerPadding = 0.dp) {
                            GroupedCardRow(
                                strings.getString(R.string.all_settings),
                                subtitle =
                                    strings.getString(
                                        R.string.view_settings_synced_from_your_watch
                                    ),
                                icon = Icons.Default.Tune,
                                showChevron = true,
                                onClick = { navigate(SettingCategory.RAW.name) },
                            )
                            GroupedDivider()
                            GroupedCardRow(
                                strings.getString(R.string.logs_and_diagnostics),
                                subtitle =
                                    strings.getString(R.string.logs_and_diagnostics_description),
                                icon = Icons.Default.BugReport,
                                showChevron = true,
                                onClick = { navigate("logs") },
                            )
                        }
                    }
                    item { Spacer(Modifier.height(16.dp)) }
                }
            }
        } else {
            val category = SettingCategory.entries.firstOrNull { it.name == page }
            Column(pageModifier) {
                PageToolbar(
                    category?.let { strings.getString(it.titleRes) }
                        ?: when (page) {
                            "appearance" -> strings.getString(R.string.appearance)
                            "language" -> strings.getString(R.string.language)
                            "notifications" ->
                                strings.getString(R.string.notification_and_forwarding)
                            "notification-bar" ->
                                strings.getString(R.string.notification_bar_settings)
                            "health-measurements" ->
                                strings.getString(R.string.health_measurement_settings_title)
                            "logs" -> strings.getString(R.string.logs_and_diagnostics)
                            "export" -> strings.getString(R.string.export_health_data)
                            else -> strings.getString(R.string.about_and_updates)
                        },
                    onBack = { navigate(null) },
                )
                when (page) {
                    "notifications" -> NotificationsSettings(state, repo)
                    "notification-bar" -> NotificationBarSettingsScreen(state)
                    "health-measurements" -> {
                        LaunchedEffect(state.sessionReady) {
                            if (state.sessionReady) repo.requestHealthSync()
                        }
                        HealthMeasurementSettings(
                            state = healthMeasurementState,
                            connected = state.connected && state.sessionReady,
                            vascularLoadSupported = state.vascularLoadSupported,
                            onSleepOxygen = { repo.healthMeasurements.setSleepOxygen(it) },
                            onStressContinuous = {
                                repo.healthMeasurements.setStressContinuous(it)
                            },
                            onVascularLoad = { repo.healthMeasurements.setVascularLoad(it) },
                            onMeasure = { repo.healthMeasurements.openMeasurement(it) },
                            onOpenWatchSettings = { repo.healthMeasurements.openSettings(it) },
                            onRefresh = { repo.requestHealthRecovery() },
                        )
                    }
                    "logs" -> LogSettingsScreen()
                    "export" -> HealthExportSettings(repo)
                    "language" ->
                        LazyColumn(contentPadding = PaddingValues(16.dp)) {
                            item {
                                GroupedCard(innerPadding = 0.dp) {
                                    languageOptions.forEachIndexed { index, (tag, label) ->
                                        if (index > 0) GroupedDivider(startIndent = 16.dp)
                                        GroupedCardRow(
                                            title = label,
                                            onClick = {
                                                dev.ricky.galaxywatchmanagerfree.core.AppLanguage
                                                    .select(tag)
                                            },
                                            trailing = {
                                                RadioButton(
                                                    selected = language == tag,
                                                    onClick = null,
                                                )
                                            },
                                        )
                                    }
                                }
                            }
                        }
                    "appearance" ->
                        LazyColumn(contentPadding = PaddingValues(16.dp)) {
                            item {
                                SectionHeader(strings.getString(R.string.color_mode))
                                GroupedCard(innerPadding = 0.dp) {
                                    listOf(
                                            ThemeController.MODE_SYSTEM to
                                                strings.getString(R.string.system_default),
                                            ThemeController.MODE_LIGHT to
                                                strings.getString(R.string.light),
                                            ThemeController.MODE_DARK to
                                                strings.getString(R.string.dark),
                                        )
                                        .forEachIndexed { index, (value, label) ->
                                            if (index > 0) GroupedDivider(startIndent = 16.dp)
                                            GroupedCardRow(
                                                label,
                                                modifier =
                                                    Modifier.semantics(mergeDescendants = true) {
                                                        role = Role.RadioButton
                                                        selected = mode == value
                                                    },
                                                onClick = {
                                                    ThemeController.setMode(context, value)
                                                },
                                                trailing = {
                                                    RadioButton(
                                                        selected = mode == value,
                                                        onClick = null,
                                                    )
                                                },
                                            )
                                        }
                                }
                                Text(
                                    strings.getString(R.string.appearance_color_explanation),
                                    style =
                                        androidx.compose.material3.MaterialTheme.typography
                                            .bodySmall,
                                    color = TextSecondary,
                                    modifier = Modifier.padding(16.dp),
                                )
                            }
                            item {
                                SectionHeader(strings.getString(R.string.accent_color))
                                val swatchDark =
                                    MaterialTheme.colorScheme.surface.luminance() < 0.5f
                                @Composable
                                fun swatchColor(value: Int) =
                                    if (value == ThemeController.COLOR_SYSTEM) {
                                        MaterialTheme.colorScheme.primary
                                    } else {
                                        accentSwatchColor(
                                            AccentFamily.fromPreference(value),
                                            swatchDark,
                                        )
                                    }
                                GroupedCard(innerPadding = 0.dp) {
                                    listOf(
                                            Triple(
                                                ThemeController.COLOR_SYSTEM,
                                                strings.getString(R.string.wallpaper_colors),
                                                swatchColor(ThemeController.COLOR_SYSTEM),
                                            ),
                                            Triple(
                                                ThemeController.COLOR_BLUE,
                                                strings.getString(R.string.blue),
                                                swatchColor(ThemeController.COLOR_BLUE),
                                            ),
                                            Triple(
                                                ThemeController.COLOR_VIOLET,
                                                strings.getString(R.string.violet),
                                                swatchColor(ThemeController.COLOR_VIOLET),
                                            ),
                                            Triple(
                                                ThemeController.COLOR_MINT,
                                                strings.getString(R.string.mint),
                                                swatchColor(ThemeController.COLOR_MINT),
                                            ),
                                        )
                                        .forEachIndexed { index, (value, label, color) ->
                                            if (index > 0) GroupedDivider()
                                            GroupedCardRow(
                                                label,
                                                modifier =
                                                    Modifier.semantics(mergeDescendants = true) {
                                                        role = Role.RadioButton
                                                        selected = accent == value
                                                    },
                                                icon = Icons.Default.Palette,
                                                iconTint = color,
                                                iconBackground = color.copy(alpha = 0.12f),
                                                onClick = {
                                                    ThemeController.setColor(context, value)
                                                },
                                                trailing = {
                                                    RadioButton(accent == value, onClick = null)
                                                },
                                            )
                                        }
                                }
                            }
                            item {
                                SectionHeader(strings.getString(R.string.navigation_bar_style))
                                GroupedCard(innerPadding = 0.dp) {
                                    listOf(
                                            Triple(
                                                ThemeController.NAVIGATION_FLOATING,
                                                R.string.navigation_bar_floating,
                                                R.string.navigation_bar_floating_description,
                                            ),
                                            Triple(
                                                ThemeController.NAVIGATION_FIXED,
                                                R.string.navigation_bar_fixed,
                                                R.string.navigation_bar_fixed_description,
                                            ),
                                        )
                                        .forEachIndexed { index, (value, title, description) ->
                                            if (index > 0) GroupedDivider(startIndent = 16.dp)
                                            GroupedCardRow(
                                                title = strings.getString(title),
                                                subtitle = strings.getString(description),
                                                modifier =
                                                    Modifier.testTag(
                                                            if (
                                                                value ==
                                                                    ThemeController.NAVIGATION_FIXED
                                                            )
                                                                "tag_navigation_style_fixed"
                                                            else "tag_navigation_style_floating"
                                                        )
                                                        .semantics(mergeDescendants = true) {
                                                            role = Role.RadioButton
                                                            selected = navigationStyle == value
                                                        },
                                                onClick = {
                                                    ThemeController.setNavigationStyle(
                                                        context,
                                                        value,
                                                    )
                                                },
                                                trailing = {
                                                    RadioButton(
                                                        navigationStyle == value,
                                                        onClick = null,
                                                    )
                                                },
                                            )
                                        }
                                    GroupedDivider(startIndent = 16.dp)
                                    SettingSwitchRow(
                                        title = strings.getString(R.string.liquid_glass),
                                        subtitle =
                                            strings.getString(
                                                if (
                                                    navigationStyle ==
                                                        ThemeController.NAVIGATION_FLOATING
                                                ) {
                                                    R.string.liquid_glass_description
                                                } else {
                                                    R.string.liquid_glass_requires_floating
                                                }
                                            ),
                                        checked = glassEffect,
                                        enabled =
                                            navigationStyle == ThemeController.NAVIGATION_FLOATING,
                                        modifier =
                                            Modifier.padding(horizontal = 16.dp)
                                                .testTag("tag_glass_effect"),
                                        onCheckedChange = {
                                            ThemeController.setGlassEffect(context, it)
                                        },
                                    )
                                }
                            }
                        }
                    "about" ->
                        LazyColumn(
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                        ) {
                            item { UpdateCard(context) }
                        }
                    else -> if (category != null) SettingsCategoryContent(state, repo, category)
                }
            }
        }
    }
}
