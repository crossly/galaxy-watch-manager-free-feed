package dev.ricky.galaxywatchmanagerfree.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.TextAutoSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.feature.*
import dev.ricky.galaxywatchmanagerfree.ui.components.*
import dev.ricky.galaxywatchmanagerfree.ui.theme.*
import kotlinx.coroutines.launch

private sealed interface HealthPane {
    data object Closed : HealthPane

    data object MeasurementSettings : HealthPane

    data object Steps : HealthPane

    data object Sleep : HealthPane

    data object Stress : HealthPane

    data object Goal : HealthPane

    data object Heart : HealthPane

    data object Ecg : HealthPane

    data object Bp : HealthPane

    data object VascularLoad : HealthPane

    data object Exercise : HealthPane

    data class Metric(val metric: HealthMetric) : HealthPane

    companion object {
        fun encode(pane: HealthPane): String =
            when (pane) {
                Closed -> "closed"
                MeasurementSettings -> "settings"
                Steps -> "steps"
                Sleep -> "sleep"
                Stress -> "stress"
                Goal -> "goal"
                Heart -> "heart"
                Ecg -> "ecg"
                Bp -> "bp"
                VascularLoad -> "vascular"
                Exercise -> "exercise"
                is Metric -> "metric:${pane.metric.name}"
            }

        fun decode(value: String): HealthPane =
            when {
                value.startsWith("metric:") ->
                    HealthMetric.entries
                        .find { it.name == value.substringAfter("metric:") }
                        ?.let { Metric(it) } ?: Closed
                else ->
                    when (value) {
                        "closed" -> Closed
                        "settings" -> MeasurementSettings
                        "steps" -> Steps
                        "sleep" -> Sleep
                        "stress" -> Stress
                        "goal" -> Goal
                        "heart" -> Heart
                        "ecg" -> Ecg
                        "bp" -> Bp
                        "vascular" -> VascularLoad
                        "exercise" -> Exercise
                        else -> Closed
                    }
            }
    }
}

private val HealthPaneSaver =
    Saver<HealthPane, String>(save = { HealthPane.encode(it) }, restore = { HealthPane.decode(it) })

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HealthTab(
    state: WatchState,
    repo: WatchRepository,
    modifier: Modifier = Modifier,
    editing: Boolean = false,
) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources
    val scope = rememberCoroutineScope()
    val measurementState by repo.healthMeasurements.state.collectAsState()
    var pane by rememberSaveable(stateSaver = HealthPaneSaver) { mutableStateOf(HealthPane.Closed) }
    LaunchedEffect(pane, state.sessionReady, state.vascularLoadSupported) {
        when (pane) {
            HealthPane.MeasurementSettings -> if (state.sessionReady) repo.requestHealthSync()
            HealthPane.VascularLoad -> {
                if (!state.vascularLoadSupported) pane = HealthPane.Closed
                else if (state.sessionReady) repo.requestVascularLoadSync()
            }
            else -> Unit
        }
    }
    val syncing = state.healthSyncStatus == HealthSyncCoordinator.Status.SYNCING

    when (val currentPane = pane) {
        HealthPane.Steps ->
            StepDetailSheet(
                state,
                onDismiss = { pane = HealthPane.Closed },
                onAdjustGoal = { pane = HealthPane.Goal },
            )
        HealthPane.Sleep ->
            SleepDetailSheet(
                state,
                onDismiss = { pane = HealthPane.Closed },
                onAddNap = repo::addManualNap,
                onDeleteNap = { start, end ->
                    scope.launch(kotlinx.coroutines.Dispatchers.IO) {
                        repo.removeManualNap(start, end)
                    }
                    true
                },
            )
        HealthPane.Stress ->
            StressDetailSheet(
                state,
                onDismiss = { pane = HealthPane.Closed },
                onMeasure = {
                    val sent =
                        repo.healthMeasurements.openMeasurement(HealthMeasurements.Kind.STRESS)
                    dev.ricky.galaxywatchmanagerfree.core.UiNotify.show(
                        if (sent) R.string.measurement_requested_check_your_watch
                        else R.string.settings_send_failed
                    )
                },
                onOpenMeasurementSettings = { pane = HealthPane.MeasurementSettings },
            )
        HealthPane.Heart -> HeartRateSheet(state, onDismiss = { pane = HealthPane.Closed })
        HealthPane.Ecg -> EcgDetailSheet(state, repo, onDismiss = { pane = HealthPane.Closed })
        HealthPane.Bp -> BpDetailSheet(state, repo, onDismiss = { pane = HealthPane.Closed })
        HealthPane.VascularLoad ->
            if (state.vascularLoadSupported)
                VascularLoadSheet(
                    state.vascularLoad,
                    onDismiss = { pane = HealthPane.Closed },
                    onRefresh =
                        if (state.sessionReady) ({ repo.requestVascularLoadSync() }) else null,
                    syncing = syncing,
                )
        HealthPane.Exercise ->
            ExerciseSheet(
                state.exercises,
                onDismiss = { pane = HealthPane.Closed },
                onRefresh = if (state.sessionReady) ({ repo.requestHealthRecovery() }) else null,
                syncing = syncing,
            )
        HealthPane.Goal ->
            StepGoalSheet(
                current = state.stepGoal,
                canReset = state.stepGoalSource == HealthGoals.Source.LOCAL,
                onDismiss = { pane = HealthPane.Closed },
                onConfirm = {
                    repo.setStepGoal(it)
                    pane = HealthPane.Closed
                },
                onReset = {
                    repo.setStepGoal(null)
                    pane = HealthPane.Closed
                },
            )
        is HealthPane.Metric ->
            MetricSheet(
                currentPane.metric,
                state.metricSamples[currentPane.metric].orEmpty(),
                onDismiss = { pane = HealthPane.Closed },
            )
        HealthPane.MeasurementSettings ->
            AppBottomSheet(
                onDismissRequest = { pane = HealthPane.Closed },
                sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            ) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
                    SheetToolbar(
                        strings.getString(R.string.health_measurement_settings_title),
                        { pane = HealthPane.Closed },
                    )
                }
                HealthMeasurementSettings(
                    state = measurementState,
                    connected = state.connected && state.sessionReady,
                    vascularLoadSupported = state.vascularLoadSupported,
                    onSleepOxygen = { repo.healthMeasurements.setSleepOxygen(it) },
                    onStressContinuous = { repo.healthMeasurements.setStressContinuous(it) },
                    onVascularLoad = { repo.healthMeasurements.setVascularLoad(it) },
                    onMeasure = { repo.healthMeasurements.openMeasurement(it) },
                    onOpenWatchSettings = { repo.healthMeasurements.openSettings(it) },
                    onRefresh = { repo.requestHealthRecovery() },
                    bottomPadding = 32.dp,
                )
            }
        HealthPane.Closed -> Unit
    }

    EditableBlockGrid(
        page = LayoutPage.HEALTH,
        editing = editing,
        modifier = modifier,
        unavailableBlocks =
            if (state.vascularLoadSupported) emptySet() else setOf(PageBlock.VASCULAR_LOAD),
    ) { placement ->
        when (placement.block) {
            dev.ricky.galaxywatchmanagerfree.feature.PageBlock.HEALTH_SYNC -> {
                Column(Modifier.fillMaxWidth()) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                when (state.healthSyncStatus) {
                                    HealthSyncCoordinator.Status.SYNCING ->
                                        strings.getString(R.string.syncing_health_data)
                                    HealthSyncCoordinator.Status.IDLE ->
                                        strings.getString(R.string.health_data_synced)
                                    HealthSyncCoordinator.Status.WAITING ->
                                        strings.getString(R.string.waiting_for_watch_sync)
                                    HealthSyncCoordinator.Status.TIMED_OUT ->
                                        strings.getString(R.string.sync_timed_out_try_again)
                                    else -> strings.getString(R.string.connect_your_watch_to_sync)
                                },
                                style =
                                    androidx.compose.material3.MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                            )
                            if (state.lastHealthSyncTime > 0)
                                Text(
                                    strings.getString(
                                        R.string.last_sync_time,
                                        formatClock(state.lastHealthSyncTime),
                                    ),
                                    style =
                                        androidx.compose.material3.MaterialTheme.typography
                                            .labelMedium,
                                    color = TextTertiary,
                                )
                        }
                        TextButton(
                            onClick = { repo.requestHealthSync() },
                            enabled = state.sessionReady && !syncing,
                        ) {
                            if (syncing) {
                                CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                                Spacer(Modifier.width(8.dp))
                            }
                            Text(
                                if (syncing) strings.getString(R.string.syncing)
                                else strings.getString(R.string.sync)
                            )
                        }
                        TextButton(onClick = { pane = HealthPane.MeasurementSettings }) {
                            Icon(
                                Icons.Default.Settings,
                                contentDescription =
                                    strings.getString(R.string.health_measurement_settings_title),
                                modifier = Modifier.size(18.dp),
                            )
                            Spacer(Modifier.width(4.dp))
                            Text(strings.getString(R.string.settings))
                        }
                    }
                }
            }
            dev.ricky.galaxywatchmanagerfree.feature.PageBlock.STEPS -> {
                Column(Modifier.fillMaxWidth()) {
                    GroupedCard(
                        modifier = Modifier.pressFeedback { pane = HealthPane.Steps },
                        cornerRadius = 34.dp,
                        innerPadding = 16.dp,
                        backgroundColor = tonalSurface(HealthSteps),
                        accent = HealthSteps,
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                strings.getString(R.string.today_s_steps),
                                modifier = Modifier.weight(1f),
                                style =
                                    androidx.compose.material3.MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold,
                                color = TextSecondary,
                            )
                            Icon(
                                Icons.Default.ChevronRight,
                                strings.getString(R.string.step_history),
                                tint = TextSecondary,
                                modifier = Modifier.size(18.dp),
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(
                                if (state.todaySteps >= 0) "%,d".format(state.todaySteps) else "—",
                                fontSize = 34.sp,
                                lineHeight = 38.sp,
                                letterSpacing = (-0.6).sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                            )
                            Text(
                                strings.getString(R.string.step_goal_suffix).format(state.stepGoal),
                                style =
                                    androidx.compose.material3.MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                                modifier = Modifier.padding(start = 4.dp, bottom = 4.dp),
                            )
                        }
                        Spacer(Modifier.height(10.dp))
                        LinearProgressIndicator(
                            progress = {
                                (state.todaySteps.coerceAtLeast(0).toFloat() /
                                        state.stepGoal.coerceAtLeast(1))
                                    .coerceIn(0f, 1f)
                            },
                            modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape),
                            color = HealthSteps,
                            trackColor = CardSurfaceElevated,
                        )
                        Spacer(Modifier.height(12.dp))
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            ActivityValue(
                                strings.getString(R.string.active_energy),
                                if (state.todayCalories >= 0) "${state.todayCalories.toInt()} kcal"
                                else "—",
                                Modifier.weight(1f),
                            )
                            ActivityValue(
                                strings.getString(R.string.walking_distance),
                                if (state.todayDistanceMeters >= 0)
                                    "%.2f km".format(state.todayDistanceMeters / 1000f)
                                else "—",
                                Modifier.weight(1f),
                            )
                        }
                        if (state.weekSteps.any { it > 0 }) {
                            Spacer(Modifier.height(12.dp))
                            Text(
                                strings.getString(R.string.past_7_days_2),
                                style =
                                    androidx.compose.material3.MaterialTheme.typography.labelSmall,
                                color = TextSecondary,
                            )
                            Spacer(Modifier.height(8.dp))
                            WeekStepBars(state.weekSteps, state.stepGoal, barHeight = 52.dp)
                        }
                    }
                }
            }
            dev.ricky.galaxywatchmanagerfree.feature.PageBlock.HEART_RATE -> {
                Column(Modifier.fillMaxWidth()) {
                    HealthSummary(
                        title = strings.getString(R.string.heart_rate),
                        value = if (state.lastHeartRate > 0) "${state.lastHeartRate}" else "—",
                        unit = strings.getString(R.string.bpm_2),
                        icon = Icons.Default.Favorite,
                        accent = HealthHeart,
                        modifier = Modifier.fillMaxWidth(),
                        wide = placement.wide,
                    ) {
                        pane = HealthPane.Heart
                    }
                }
            }
            dev.ricky.galaxywatchmanagerfree.feature.PageBlock.STRESS -> {
                Column(Modifier.fillMaxWidth()) {
                    HealthSummary(
                        strings.getString(R.string.stress),
                        if (state.lastStressScore >= 0) "${state.lastStressScore}" else "—",
                        strings.getString(R.string.score),
                        Icons.Default.Spa,
                        HealthStress,
                        Modifier.fillMaxWidth(),
                        wide = placement.wide,
                    ) {
                        pane = HealthPane.Stress
                    }
                }
            }
            PageBlock.VASCULAR_LOAD -> {
                VascularLoadCard(
                    state.vascularLoad,
                    wide = placement.wide,
                    onClick = { pane = HealthPane.VascularLoad },
                )
            }
            dev.ricky.galaxywatchmanagerfree.feature.PageBlock.ECG -> {
                Column(Modifier.fillMaxWidth()) {
                    val lastEcg = state.ecgRecords.firstOrNull()
                    HealthSummary(
                        title = strings.getString(R.string.ecg),
                        value = if (lastEcg != null) "${lastEcg.heartRate}" else "—",
                        unit =
                            if (lastEcg != null)
                                "bpm · ${strings.getString(lastEcg.classificationRes)}"
                            else strings.getString(R.string.ecg),
                        icon = Icons.Default.MonitorHeart,
                        accent = HealthHeart,
                        modifier = Modifier.fillMaxWidth(),
                        wide = placement.wide,
                    ) {
                        pane = HealthPane.Ecg
                    }
                }
            }
            dev.ricky.galaxywatchmanagerfree.feature.PageBlock.BP -> {
                Column(Modifier.fillMaxWidth()) {
                    val lastBp = state.bpRecords.firstOrNull()
                    HealthSummary(
                        title = strings.getString(R.string.blood_pressure),
                        value =
                            if (lastBp != null) "${lastBp.systolic}/${lastBp.diastolic}" else "—",
                        unit =
                            if (lastBp != null)
                                "mmHg · ${strings.getString(lastBp.classification.labelRes)}"
                            else strings.getString(R.string.blood_pressure),
                        icon = Icons.Default.Speed,
                        accent = HealthBloodPressure,
                        modifier = Modifier.fillMaxWidth(),
                        wide = placement.wide,
                    ) {
                        pane = HealthPane.Bp
                    }
                }
            }
            dev.ricky.galaxywatchmanagerfree.feature.PageBlock.SLEEP -> {
                Column(Modifier.fillMaxWidth()) {
                    val sessions = state.sleepSessions.ifEmpty { listOfNotNull(state.sleep) }
                    val session = state.sleep ?: sessions.maxByOrNull { it.displayMinutes }
                    val totalMinutes = sessions.sumOf { it.displayMinutes }
                    val napMinutes = sessions.filter { it != session }.sumOf { it.displayMinutes }
                    val isRecent =
                        session != null &&
                            session.endMillis >= System.currentTimeMillis() - 36 * 3_600_000L
                    GroupedCard(
                        modifier = Modifier.pressFeedback { pane = HealthPane.Sleep },
                        cornerRadius = 34.dp,
                        innerPadding = 22.dp,
                        backgroundColor = tonalSurface(HealthSleep),
                        accent = HealthSleep,
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.Bedtime,
                                null,
                                tint = HealthSleep,
                                modifier = Modifier.size(20.dp),
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                strings.getString(R.string.sleep),
                                modifier = Modifier.weight(1f),
                                style =
                                    androidx.compose.material3.MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = TextSecondary,
                            )
                            Icon(
                                Icons.Default.ChevronRight,
                                strings.getString(R.string.sleep_history),
                                tint = TextSecondary,
                                modifier = Modifier.size(20.dp),
                            )
                        }
                        Spacer(Modifier.height(16.dp))
                        Text(
                            if (session == null) strings.getString(R.string.no_sleep_data)
                            else sleepDurationText(totalMinutes, strings),
                            fontSize = if (session == null) 20.sp else 34.sp,
                            lineHeight = 41.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                        )
                        if (session != null) {
                            if (!isRecent) {
                                Text(
                                    strings.getString(R.string.latest_measurement_2),
                                    style =
                                        androidx.compose.material3.MaterialTheme.typography
                                            .labelSmall,
                                    color = TextTertiary,
                                )
                                Spacer(Modifier.height(2.dp))
                            }
                            Text(
                                dev.ricky.galaxywatchmanagerfree.ui.components.formatRecordTime(
                                    session.startMillis
                                ) +
                                    " – " +
                                    dev.ricky.galaxywatchmanagerfree.ui.components.formatRecordTime(
                                        session.endMillis
                                    ),
                                style =
                                    androidx.compose.material3.MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                            )
                            if (napMinutes > 0) {
                                Text(
                                    strings.getString(
                                        R.string.sleep_includes_nap,
                                        sleepDurationText(napMinutes, strings),
                                    ),
                                    style =
                                        androidx.compose.material3.MaterialTheme.typography
                                            .bodySmall,
                                    color = TextSecondary,
                                )
                            }
                            Spacer(Modifier.height(18.dp))
                            if (session.stageMinutes.isNotEmpty()) SleepStageBar(session)
                            else
                                Text(
                                    if (state.sleepAnalysisRunning)
                                        strings.getString(
                                            R.string.analyzing_sleep_stages_on_this_phone
                                        )
                                    else strings.getString(R.string.sleep_interval_synced),
                                    style =
                                        androidx.compose.material3.MaterialTheme.typography
                                            .bodySmall,
                                    color = TextSecondary,
                                )
                            if (session.analysisSource != null) {
                                Spacer(Modifier.height(10.dp))
                                Text(
                                    strings.getString(
                                        R.string.on_device_analysis_efficiency,
                                        session.efficiencyPercent,
                                    ),
                                    style =
                                        androidx.compose.material3.MaterialTheme.typography
                                            .bodySmall,
                                    color = TextSecondary,
                                )
                            }
                        } else
                            Text(
                                strings.getString(R.string.sleep_auto_sync_guidance),
                                style =
                                    androidx.compose.material3.MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                            )
                    }
                }
            }
            dev.ricky.galaxywatchmanagerfree.feature.PageBlock.METRICS -> {
                Column(Modifier.fillMaxWidth()) {
                    SectionHeader(strings.getString(R.string.body_measurements))
                    GroupedCard(innerPadding = 0.dp) {
                        HealthMetric.entries.forEachIndexed { index, current ->
                            if (index > 0) GroupedDivider()
                            val latest =
                                HealthMetricLog.latest(state.metricSamples[current].orEmpty())
                            GroupedCardRow(
                                strings.getString(current.labelRes),
                                subtitle =
                                    latest?.let {
                                        strings.getString(
                                            R.string.metric_measured_at,
                                            dev.ricky.galaxywatchmanagerfree.ui.components
                                                .formatRecordTime(it.ts),
                                        )
                                    },
                                icon = metricIcon(current),
                                iconTint = metricColor(current),
                                iconBackground = metricColor(current).copy(alpha = 0.12f),
                                showChevron = true,
                                onClick = { pane = HealthPane.Metric(current) },
                                trailing = {
                                    Text(
                                        latest?.let {
                                            current.format(it.value) +
                                                " " +
                                                strings.getString(current.unitRes)
                                        } ?: "—",
                                        style =
                                            androidx.compose.material3.MaterialTheme.typography
                                                .bodyMedium,
                                        color = TextSecondary,
                                    )
                                },
                            )
                        }
                        GroupedDivider()
                        GroupedCardRow(
                            strings.getString(R.string.floors_climbed),
                            icon = stairsIcon(),
                            showChevron = true,
                            onClick = { pane = HealthPane.Steps },
                            trailing = {
                                Text(
                                    if (state.todayFloors >= 0)
                                        strings.getQuantityString(
                                            R.plurals.floors_count,
                                            state.todayFloors,
                                            state.todayFloors,
                                        )
                                    else "—",
                                    style =
                                        androidx.compose.material3.MaterialTheme.typography
                                            .bodyMedium,
                                    color = TextSecondary,
                                )
                            },
                        )
                    }
                }
            }
            dev.ricky.galaxywatchmanagerfree.feature.PageBlock.WORKOUTS -> {
                Column(Modifier.fillMaxWidth()) {
                    val workouts =
                        ExerciseLog.topLevel(state.exercises).sortedByDescending { it.startMillis }
                    val totalCount = workouts.size
                    SectionHeader(
                        strings.getString(R.string.workouts_2),
                        actionText =
                            if (totalCount > 0) strings.getString(R.string.view_all_workouts)
                            else null,
                        onAction = if (totalCount > 0) ({ pane = HealthPane.Exercise }) else null,
                    )
                    WorkoutOverviewCard(
                        workouts = workouts,
                        onClick = { pane = HealthPane.Exercise },
                    )
                }
            }
            else -> Unit
        }
    }
}

@Composable
private fun WorkoutOverviewCard(
    workouts: List<ExerciseLog.Session>,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources
    val latest = workouts.firstOrNull()
    if (latest == null) {
        GroupedCard(innerPadding = 0.dp, modifier = modifier) {
            GroupedCardRow(
                title = strings.getString(R.string.workout_records),
                subtitle = strings.getString(R.string.completed_workouts_sync_from_your_watch_2),
                icon = Icons.Default.SportsScore,
                iconTint = TextSecondary,
                iconBackground = CardSurfaceElevated,
                showChevron = true,
                onClick = onClick,
            )
        }
        return
    }

    val totalCount = workouts.size
    val accent = latest.accentColor
    val zone = java.time.ZoneId.systemDefault()
    val start = java.time.Instant.ofEpochMilli(latest.startMillis).atZone(zone)
    val end = java.time.Instant.ofEpochMilli(latest.endMillis).atZone(zone)
    val datePattern = strings.getString(R.string.mmm_d_hh_mm)
    val dateText =
        start.format(
            java.time.format.DateTimeFormatter.ofPattern(
                datePattern,
                strings.configuration.locales[0],
            )
        )
    val endPattern = if (start.toLocalDate() == end.toLocalDate()) "HH:mm" else datePattern
    val endText =
        end.format(
            java.time.format.DateTimeFormatter.ofPattern(
                endPattern,
                strings.configuration.locales[0],
            )
        )

    GroupedCard(
        modifier = modifier.pressFeedback(onClick = onClick),
        cornerRadius = 24.dp,
        innerPadding = 16.dp,
        backgroundColor = tonalSurface(accent, 0.05f),
        accent = accent,
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Box(
                Modifier.size(42.dp).clip(CircleShape).background(accent.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(latest.icon, null, tint = accent, modifier = Modifier.size(22.dp))
            }
            Column(Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Text(
                        latest.title.ifBlank {
                            strings.getString(latest.typeNameRes, latest.typeCode)
                        },
                        style = androidx.compose.material3.MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary,
                    )
                    if (latest.autoDetected) {
                        Box(
                            Modifier.clip(CircleShape)
                                .background(CardSurfaceElevated)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                strings.getString(R.string.auto_detected),
                                style =
                                    androidx.compose.material3.MaterialTheme.typography.labelSmall,
                                color = TextSecondary,
                            )
                        }
                    }
                }
                Spacer(Modifier.height(2.dp))
                Text(
                    "$dateText – $endText",
                    style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                )
            }
            Icon(
                Icons.Default.ChevronRight,
                strings.getString(R.string.view_all_workouts),
                tint = TextTertiary,
                modifier = Modifier.size(18.dp),
            )
        }
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ActivityValue(
                label = strings.getString(R.string.setting_duration),
                value =
                    strings.getString(
                        R.string.workout_duration,
                        latest.durationMillis / 60_000,
                        latest.durationMillis % 60_000 / 1000,
                    ),
                modifier = Modifier.weight(1f),
            )
            if (latest.distanceMeters > 0) {
                ActivityValue(
                    label = strings.getString(R.string.exercise_distance_label),
                    value = "%.2f km".format(latest.distanceMeters / 1000.0),
                    modifier = Modifier.weight(1f),
                )
            } else if (latest.count >= 0) {
                ActivityValue(
                    label =
                        strings.getString(
                            when (latest.countType) {
                                30002 -> R.string.exercise_strokes_label
                                30003 -> R.string.exercise_swings_label
                                else -> R.string.exercise_repetitions_label
                            }
                        ),
                    value = "${latest.count}",
                    modifier = Modifier.weight(1f),
                )
            }
            if (latest.calories >= 0) {
                ActivityValue(
                    label = strings.getString(R.string.active_energy),
                    value = "${latest.calories} kcal",
                    modifier = Modifier.weight(1f),
                )
            }
        }
        if (totalCount > 1) {
            Spacer(Modifier.height(10.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    strings.getQuantityString(
                        R.plurals.synced_record_count,
                        totalCount,
                        totalCount,
                    ),
                    style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                    color = TextTertiary,
                )
            }
        }
    }
}

@Composable
private fun ActivityValue(label: String, value: String, modifier: Modifier) {
    Column(
        modifier
            .clip(androidx.compose.foundation.shape.RoundedCornerShape(18.dp))
            .background(CardSurfaceElevated)
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Text(
            label,
            style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
            color = TextSecondary,
        )
        Spacer(Modifier.height(2.dp))
        Text(
            value,
            style = androidx.compose.material3.MaterialTheme.typography.titleSmall,
            color = TextPrimary,
        )
    }
}

@Composable
internal fun HealthSummary(
    title: String,
    value: String,
    unit: String,
    icon: ImageVector,
    accent: androidx.compose.ui.graphics.Color,
    modifier: Modifier,
    wide: Boolean = false,
    wrapValue: Boolean = false,
    indicator: (@Composable () -> Unit)? = null,
    onClick: () -> Unit,
) {
    GroupedCard(
        modifier = modifier.pressFeedback(onClick = onClick),
        cornerRadius = 24.dp,
        innerPadding = 14.dp,
        backgroundColor = tonalSurface(accent),
        accent = accent,
    ) {
        BoxWithConstraints {
            if (
                wide &&
                    maxWidth / androidx.compose.ui.platform.LocalDensity.current.fontScale >= 300.dp
            ) {
                Column {
                    Row(verticalAlignment = Alignment.Top) {
                        SummaryMarker(icon, accent)
                        Spacer(Modifier.width(10.dp))
                        Text(
                            title,
                            modifier = Modifier.weight(1f),
                            style = androidx.compose.material3.MaterialTheme.typography.labelMedium,
                            color = TextSecondary,
                        )
                        Spacer(Modifier.width(12.dp))
                        SummaryValue(value, Modifier.weight(1f), wrap = wrapValue)
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        unit,
                        modifier = Modifier.fillMaxWidth(),
                        style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                        color = TextSecondary,
                    )
                }
            } else {
                Column {
                    SummaryMarker(icon, accent)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        title,
                        modifier = Modifier.fillMaxWidth(),
                        style = androidx.compose.material3.MaterialTheme.typography.labelMedium,
                        color = TextSecondary,
                    )
                    Spacer(Modifier.height(6.dp))
                    SummaryValue(value, Modifier.fillMaxWidth(), wrap = wrapValue)
                    Spacer(Modifier.height(2.dp))
                    Text(
                        unit,
                        modifier = Modifier.fillMaxWidth(),
                        style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                        color = TextSecondary,
                    )
                }
            }
        }
        indicator?.let {
            Spacer(Modifier.height(12.dp))
            it()
        }
    }
}

@Composable
private fun SummaryMarker(icon: ImageVector, accent: androidx.compose.ui.graphics.Color) {
    Box(
        Modifier.size(24.dp).clip(CircleShape).background(accent.copy(alpha = 0.14f)),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, null, tint = accent, modifier = Modifier.size(15.dp))
    }
}

@Composable
private fun SummaryValue(value: String, modifier: Modifier = Modifier, wrap: Boolean = false) {
    if (wrap) {
        Text(
            value,
            modifier = modifier,
            style = MaterialTheme.typography.headlineSmall,
            color = TextPrimary,
        )
        return
    }
    BasicText(
        text = value,
        modifier = modifier,
        style = MaterialTheme.typography.headlineMedium.copy(color = TextPrimary),
        maxLines = 1,
        softWrap = false,
        autoSize =
            TextAutoSize.StepBased(
                minFontSize = 12.sp,
                maxFontSize = MaterialTheme.typography.headlineMedium.fontSize,
            ),
    )
}
