package dev.ricky.galaxywatchmanagerfree.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.ui.theme.*

/** A small spring response, retaining clickable's keyboard and accessibility support. */
@Composable
fun Modifier.pressFeedback(
    enabled: Boolean = true,
    pressedScale: Float = 0.985f,
    onClick: (() -> Unit)? = null,
): Modifier {
    if (onClick == null) return this
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by
        animateFloatAsState(
            if (pressed && enabled) pressedScale else 1f,
            spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessMedium),
            label = "Press",
        )
    return graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .then(
            if (onClick != null)
                Modifier.clickable(
                    interactionSource = source,
                    indication = null,
                    enabled = enabled,
                    onClick = onClick,
                )
            else Modifier
        )
}

/** Surfaces separate through tone; outlines are reserved for focus and explicit status. */
@Composable
fun GroupedCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 24.dp,
    backgroundColor: Color = CardSurface,
    borderColor: Color = Color.Transparent,
    innerPadding: Dp = 16.dp,
    accent: Color? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val currentPalette = WfColors
    // Keep inset blocks in the same hue as their parent. A warm card must not
    // inherit the app-wide cool gray block surface in light mode.
    val contextual =
        if (backgroundColor != CardSurface || accent != null)
            currentPalette.copy(
                cardSurfaceElevated =
                    androidx.compose.ui.graphics.lerp(
                        backgroundColor,
                        TextPrimary,
                        if (backgroundColor.luminance() < 0.5f) 0.055f else 0.035f,
                    ),
                electricBlue = accent ?: currentPalette.electricBlue,
            )
        else currentPalette
    val shape =
        when (cornerRadius) {
            16.dp -> MaterialTheme.shapes.medium
            24.dp -> MaterialTheme.shapes.large
            34.dp -> MaterialTheme.shapes.extraLarge
            else -> ContinuousCornerShape(cornerRadius)
        }
    Column(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(backgroundColor)
            .then(
                if (borderColor.alpha > 0f) Modifier.border(0.5.dp, borderColor, shape)
                else Modifier
            )
            .padding(innerPadding)
    ) {
        CompositionLocalProvider(
            LocalWfPalette provides contextual,
            LocalContentColor provides contextual.textPrimary,
        ) {
            Column(content = content)
        }
    }
}

@Composable
fun GroupedCardRow(
    title: String,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    icon: ImageVector? = null,
    iconTint: Color = ElectricBlue,
    iconBackground: Color? = null,
    enabled: Boolean = true,
    showChevron: Boolean = false,
    onClick: (() -> Unit)? = null,
    titleMaxLines: Int = Int.MAX_VALUE,
    trailing: @Composable (() -> Unit)? = null,
) {
    Row(
        modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .pressFeedback(enabled = enabled, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        if (icon != null) {
            Box(
                Modifier.size(32.dp)
                    .clip(CircleShape)
                    .background(iconBackground ?: Color.Transparent),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    icon,
                    null,
                    tint = if (enabled) iconTint else TextDisabled,
                    modifier = Modifier.size(23.dp),
                )
            }
        }
        Column(Modifier.weight(1f)) {
            Text(
                title,
                style = androidx.compose.material3.MaterialTheme.typography.bodyLarge,
                lineHeight = 22.sp,
                color = if (enabled) TextPrimary else TextDisabled,
                maxLines = titleMaxLines,
                overflow = TextOverflow.Ellipsis,
            )
            if (!subtitle.isNullOrEmpty()) {
                Text(
                    subtitle,
                    style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                    lineHeight = 18.sp,
                    color = TextSecondary,
                )
            }
        }
        trailing?.invoke()
        if (showChevron)
            Icon(
                Icons.Default.ChevronRight,
                null,
                tint = TextTertiary,
                modifier = Modifier.size(18.dp),
            )
    }
}

@Composable
fun GroupedDivider(modifier: Modifier = Modifier, startIndent: Dp = 64.dp) {
    HorizontalDivider(
        modifier.padding(start = startIndent, end = 16.dp),
        thickness = 0.5.dp,
        color = CardBorder.copy(alpha = 0.45f),
    )
}

@Composable
fun <T> SegmentedTabs(
    items: List<T>,
    selectedItem: T,
    onItemSelected: (T) -> Unit,
    modifier: Modifier = Modifier,
    labelOf: (T) -> String,
) {
    Row(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(50))
            .background(CardSurfaceElevated)
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        items.forEach { item ->
            val selected = item == selectedItem
            val background by
                animateColorAsState(
                    if (selected) MaterialTheme.colorScheme.primary else Color.Transparent,
                    label = "Segment",
                )
            Box(
                Modifier.weight(1f)
                    .clip(RoundedCornerShape(50))
                    .background(background)
                    .pressFeedback { onItemSelected(item) }
                    .semantics(mergeDescendants = true) {
                        this.selected = selected
                        role = Role.Tab
                    }
                    .padding(horizontal = 8.dp, vertical = 10.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    labelOf(item),
                    style = androidx.compose.material3.MaterialTheme.typography.bodyMedium,
                    lineHeight = 20.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (selected) MaterialTheme.colorScheme.onPrimary else TextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                )
            }
        }
    }
}

/** Shared heading and close action for detail sheets. */
@Composable
fun SheetToolbar(
    title: String,
    onDismiss: () -> Unit,
    actions: @Composable RowScope.() -> Unit = {},
) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources

    Row(
        Modifier.fillMaxWidth().heightIn(min = 56.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(
            title,
            style = androidx.compose.material3.MaterialTheme.typography.headlineSmall,
            lineHeight = 30.sp,
            fontWeight = FontWeight.SemiBold,
            color = TextPrimary,
            modifier = Modifier.weight(1f),
        )
        actions()
        FilledTonalIconButton(onClick = onDismiss) {
            Icon(
                androidx.compose.material.icons.Icons.Default.Close,
                strings.getString(R.string.close),
            )
        }
    }
}

@Composable
fun PageToolbar(
    title: String,
    onBack: (() -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {},
) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources

    Row(
        Modifier.fillMaxWidth().heightIn(min = 72.dp).padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        if (onBack != null) {
            FilledTonalIconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, strings.getString(R.string.back))
            }
        }
        Text(
            title,
            style = androidx.compose.material3.MaterialTheme.typography.headlineSmall,
            lineHeight = 30.sp,
            fontWeight = FontWeight.SemiBold,
            color = TextPrimary,
            modifier = Modifier.weight(1f),
        )
        actions()
    }
}

@Composable
fun SectionHeader(
    title: String,
    modifier: Modifier = Modifier,
    actionText: String? = null,
    onAction: (() -> Unit)? = null,
) {
    Row(
        modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(
            title,
            modifier = Modifier.weight(1f),
            style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
            lineHeight = 18.sp,
            fontWeight = FontWeight.SemiBold,
            color = TextSecondary,
        )
        if (actionText != null && onAction != null)
            TextButton(onClick = onAction) {
                Text(
                    actionText,
                    style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                    color = ElectricBlue,
                )
            }
    }
}

@Composable
fun MemoryProgressCard(
    usedMb: Long,
    totalMb: Long,
    availableMb: Long,
    onClean: (() -> Unit)?,
    modifier: Modifier = Modifier,
) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources

    val progress = if (totalMb > 0) (usedMb.toFloat() / totalMb).coerceIn(0f, 1f) else 0f
    GroupedCard(modifier, cornerRadius = 34.dp, innerPadding = 20.dp) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                strings.getString(R.string.memory),
                modifier = Modifier.weight(1f),
                style = androidx.compose.material3.MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
                color = TextSecondary,
            )
            if (onClean != null)
                TextButton(onClick = onClean) { Text(strings.getString(R.string.clean)) }
        }
        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                if (totalMb > 0) "$usedMb" else "—",
                style = androidx.compose.material3.MaterialTheme.typography.headlineLarge,
                lineHeight = 41.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
            )
            Text(
                " MB",
                modifier = Modifier.padding(bottom = 4.dp),
                style = androidx.compose.material3.MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
            )
        }
        Spacer(Modifier.height(16.dp))
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape),
            color = ElectricBlue,
            trackColor = CardSurfaceElevated,
        )
        Spacer(Modifier.height(12.dp))
        Text(
            if (totalMb > 0) strings.getString(R.string.total_mb_available_mb, totalMb, availableMb)
            else strings.getString(R.string.connect_to_read_memory_usage),
            style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
            color = TextSecondary,
        )
    }
}

/** 详情面板的日期选择胶囊：心率与压力共用，只由 accent 区分指标。 */
@Composable
fun DetailDayChip(day: String, selected: Boolean, accent: Color, onClick: () -> Unit) {
    Box(
        modifier =
            Modifier.clip(RoundedCornerShape(999.dp))
                .background(if (selected) accent.copy(alpha = 0.18f) else CardSurfaceElevated)
                .pressFeedback(onClick = onClick)
                .padding(horizontal = 12.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = day,
            style = androidx.compose.material3.MaterialTheme.typography.labelMedium,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            color = if (selected) accent else TextSecondary,
            maxLines = 1,
            softWrap = false,
        )
    }
}

/** 详情面板的统计格：最低 / 平均 / 最高 / 读数次数共用。 */
@Composable
fun DetailStatCell(label: String, value: String, modifier: Modifier = Modifier) {
    Box(
        modifier =
            modifier
                .clip(RoundedCornerShape(12.dp))
                .background(CardSurfaceElevated)
                .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = value,
                style = androidx.compose.material3.MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                fontFamily = FontFamily.Monospace,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(2.dp))
            Text(
                label,
                style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                color = TextTertiary,
                textAlign = TextAlign.Center,
            )
        }
    }
}
