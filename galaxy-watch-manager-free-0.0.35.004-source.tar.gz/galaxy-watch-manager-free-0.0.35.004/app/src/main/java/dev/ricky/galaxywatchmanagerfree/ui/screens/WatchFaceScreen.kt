package dev.ricky.galaxywatchmanagerfree.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.ricky.galaxywatchmanagerfree.BuildConfig
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.core.UiNotify
import dev.ricky.galaxywatchmanagerfree.feature.*
import dev.ricky.galaxywatchmanagerfree.ui.components.*
import dev.ricky.galaxywatchmanagerfree.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WatchFaceScreen(
    state: WatchState,
    repo: WatchRepository,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources

    var category by remember { mutableStateOf<WatchFaceCategory?>(null) }
    var preview by remember { mutableStateOf<WatchFacePreset?>(null) }
    val current = WatchFacePresets.find(state.activeWatchfacePkg, state.activeWatchfaceCls)
    val currentName =
        current?.let { strings.getString(it.nameRes) }
            ?: state.activeWatchfacePkg?.substringAfterLast('.')
            ?: strings.getString(R.string.unknown_watch_face)
    val presets =
        remember(category) {
            if (category == null) WatchFacePresets.ALL
            else WatchFacePresets.ALL.filter { it.category == category }
        }
    Column(modifier.fillMaxSize()) {
        PageToolbar(strings.getString(R.string.watch_faces), onBack) {
            FilledTonalIconButton(
                onClick = {
                    repo.requestActiveWatchface()
                    repo.requestWatchfaceOrder()
                },
                enabled = state.sessionReady,
            ) {
                Icon(Icons.Default.Refresh, strings.getString(R.string.refresh_watch_faces))
            }
        }
        LazyColumn(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item {
                GroupedCard(cornerRadius = 34.dp, innerPadding = 20.dp) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(20.dp),
                    ) {
                        WatchFacePreview(
                            current,
                            size = 88.dp,
                            previewPath = state.activeWatchfacePreviewPath,
                        )
                        Column(Modifier.weight(1f)) {
                            Text(
                                strings.getString(R.string.current_watch_face),
                                style =
                                    androidx.compose.material3.MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                            )
                            Spacer(Modifier.height(6.dp))
                            Text(
                                currentName,
                                style =
                                    androidx.compose.material3.MaterialTheme.typography.titleLarge,
                                lineHeight = 25.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary,
                            )
                        }
                    }
                }
            }
            if (!BuildConfig.VENDOR_ASSETS_ENABLED) {
                item {
                    Text(
                        strings.getString(R.string.watch_face_illustration_notice),
                        style = MaterialTheme.typography.bodySmall,
                        lineHeight = 18.sp,
                        color = TextSecondary,
                        modifier = Modifier.padding(horizontal = 4.dp),
                    )
                }
            }
            item {
                GroupedCard(innerPadding = 0.dp) {
                    val orders = listOf("recent", "custom", "alphabetic")
                    SettingChoiceRow(
                        strings.getString(R.string.sort_order),
                        listOf(
                            strings.getString(R.string.recently_used),
                            strings.getString(R.string.custom),
                            strings.getString(R.string.alphabetical),
                        ),
                        orders.indexOf(state.watchfaceOrderType),
                        enabled = state.sessionReady,
                        onSelect = { repo.setWatchfaceOrderType(orders[it]) },
                    )
                }
            }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(listOf(null) + WatchFaceCategory.entries, key = { it?.name ?: "all" }) {
                        value ->
                        FilterChip(
                            selected = value == category,
                            onClick = { category = value },
                            label = {
                                Text(
                                    value?.let { strings.getString(it.labelRes) }
                                        ?: strings.getString(R.string.all)
                                )
                            },
                        )
                    }
                }
            }
            items(presets.chunked(3), key = { row -> row.joinToString(",") { it.id } }) { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    row.forEach { preset ->
                        Column(
                            Modifier.weight(1f)
                                .clip(ContinuousCornerShape(20.dp))
                                .background(
                                    if (current?.id == preset.id) PrimaryContainer else CardSurface
                                )
                                .pressFeedback { preview = preset }
                                .padding(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            WatchFacePresetImage(
                                preset = preset,
                                modifier =
                                    Modifier.fillMaxWidth().aspectRatio(1f).clip(CircleShape),
                                contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                            )
                            Spacer(Modifier.height(10.dp))
                            Text(
                                strings.getString(preset.nameRes),
                                style =
                                    androidx.compose.material3.MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Medium,
                                color =
                                    if (current?.id == preset.id) OnPrimaryContainer
                                    else TextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            )
                            if (current?.id == preset.id)
                                Text(
                                    strings.getString(R.string.active),
                                    style =
                                        androidx.compose.material3.MaterialTheme.typography
                                            .labelSmall,
                                    color = OnPrimaryContainer,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                )
                        }
                    }
                    repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
            item {
                Text(
                    strings.getString(R.string.touch_and_hold_the_watch_face_on_your_watch),
                    style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                    lineHeight = 18.sp,
                    color = TextSecondary,
                    modifier = Modifier.padding(16.dp),
                )
            }
        }
    }
    preview?.let { preset ->
        AppBottomSheet(onDismissRequest = { preview = null }) {
            Column(
                modifier =
                    Modifier.fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 24.dp, vertical = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                Text(
                    strings.getString(preset.nameRes),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                )
                val actualPreviewPath =
                    state.activeWatchfacePreviewPath.takeIf { current?.id == preset.id }
                WatchFacePreview(preset, size = 180.dp, previewPath = actualPreviewPath)
                if (actualPreviewPath == null && rememberWatchFacePreviewRes(preset) == null) {
                    Text(
                        strings.getString(R.string.watch_face_illustration_notice),
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        textAlign = TextAlign.Center,
                    )
                }
                Text(
                    strings.getString(preset.category.labelRes),
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    textAlign = TextAlign.Center,
                )
                if (preset.isUltraExclusive) {
                    Text(
                        strings.getString(R.string.galaxy_watch_ultra_only),
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        textAlign = TextAlign.Center,
                    )
                }
                Button(
                    modifier = Modifier.fillMaxWidth(),
                    enabled = state.sessionReady && current?.id != preset.id,
                    onClick = {
                        val success = repo.setActiveWatchface(preset)
                        UiNotify.show(
                            if (success)
                                strings.getString(
                                    R.string.switching_to,
                                    strings.getString(preset.nameRes),
                                )
                            else strings.getString(R.string.request_send_failed)
                        )
                        if (success) preview = null
                    },
                ) {
                    Text(
                        if (current?.id == preset.id) strings.getString(R.string.currently_active)
                        else strings.getString(R.string.apply_to_watch),
                        textAlign = TextAlign.Center,
                    )
                }
                TextButton(modifier = Modifier.fillMaxWidth(), onClick = { preview = null }) {
                    Text(strings.getString(R.string.close))
                }
            }
        }
    }
    if (state.watchfaceEditRequested) {
        AlertDialog(
            onDismissRequest = { repo.clearWatchfaceEditRequest() },
            title = { Text(strings.getString(R.string.edit_on_watch)) },
            text = { Text(strings.getString(R.string.watch_face_edit_guidance)) },
            confirmButton = {
                TextButton(onClick = { repo.clearWatchfaceEditRequest() }) {
                    Text(strings.getString(R.string.got_it))
                }
            },
        )
    }
}
