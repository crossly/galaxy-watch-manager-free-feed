package dev.ricky.galaxywatchmanagerfree.feature

import android.content.Context
import android.content.res.AssetManager
import android.os.Build
import dalvik.system.DexClassLoader
import dev.ricky.galaxywatchmanagerfree.BuildConfig
import java.io.File
import java.security.MessageDigest
import org.json.JSONObject

internal fun sleepAnalysisLog(status: String, elapsedMs: Long, error: Throwable? = null): String =
    "[睡眠分析] 状态=$status" +
        (error?.let { " 类别=${it.javaClass.simpleName}" } ?: "") +
        " 耗时=${elapsedMs}ms"

/**
 * Offline inference runs on the repository's IO scope. No account, network, root or external app.
 */
class LocalSleepAnalyzer(private val context: Context, peerAddress: String? = null) {
    private val prefs = DevicePreferences.open(context, "watchfree_sleep_analysis", peerAddress)
    private val tried = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()

    private fun key(record: JSONObject, raw: JSONObject): String =
        sha256((record.toString() + raw.toString() + SleepAnalysisResult.SOURCE).toByteArray())

    fun cached(record: JSONObject, raw: JSONObject): SleepParser.Session? =
        SleepParser.decode(prefs.getString(key(record, raw), null))

    fun exportResults(): JSONObject = synchronized(INFERENCE_LOCK) { retainedResults(prefs.all) }

    fun needsAnalysis(record: JSONObject, raw: JSONObject): Boolean {
        if (!BuildConfig.VENDOR_ASSETS_ENABLED) return false
        val cacheKey = key(record, raw)
        return cacheKey !in tried && SleepParser.decode(prefs.getString(cacheKey, null)) == null
    }

    fun analyze(record: JSONObject, raw: JSONObject): SleepParser.Session? =
        synchronized(INFERENCE_LOCK) {
            val cacheKey = key(record, raw)
            SleepParser.decode(prefs.getString(cacheKey, null))?.let {
                return it
            }
            if (!BuildConfig.VENDOR_ASSETS_ENABLED) return null
            if (!tried.add(cacheKey)) return null
            val began = System.nanoTime()
            runCatching {
                    val source = SleepParser.sessions(listOf(record)).single()
                    val encoded = raw.optString("data")
                    require(encoded.isNotBlank()) { "Sleep raw payload is missing" }
                    val body = HealthJson.inflateJson(encoded, 8 * 1024 * 1024)
                    require(JSONObject(body).optInt("version") == 2) {
                        "Unsupported sleep sensor version"
                    }
                    val (engineContext, method) = loadEngine()
                    val result =
                        method.invoke(null, engineContext, record.toString(), body) as String
                    val session = SleepAnalysisResult.apply(source, JSONObject(result))
                    check(prefs.edit().putString(cacheKey, SleepParser.encode(session)).commit()) {
                        "Sleep analysis cache write failed"
                    }
                    LogBus.log(sleepAnalysisLog("完成", (System.nanoTime() - began) / 1_000_000))
                    session
                }
                .onFailure {
                    val reason =
                        (it as? java.lang.reflect.InvocationTargetException)?.targetException ?: it
                    LogBus.log(
                        sleepAnalysisLog("暂不可用", (System.nanoTime() - began) / 1_000_000, reason)
                    )
                }
                .getOrNull()
        }

    private fun loadEngine(): Pair<Context, java.lang.reflect.Method> =
        synchronized(ENGINE_LOCK) {
            sharedEngine?.let {
                return it
            }
            val manifest =
                JSONObject(
                    context.assets.open("sleep/manifest.json").bufferedReader().use {
                        it.readText()
                    }
                )
            val files = manifest.getJSONObject("files")
            val abi =
                Build.SUPPORTED_ABIS.firstOrNull { files.has("$it/libmobilesleepjni.so") }
                    ?: error("This CPU has no sleep inference runtime")
            val root =
                File(context.codeCacheDir, "sleep-engine-${files.getString("engine.jar").take(16)}")
                    .apply { mkdirs() }
            fun extract(name: String): File {
                val target = File(root, name.substringAfterLast('/'))
                if (target.isFile && sha256(target.readBytes()) == files.getString(name))
                    return target
                val bytes = context.assets.open("sleep/$name").use { it.readBytes() }
                check(sha256(bytes) == files.getString(name)) { "Sleep engine integrity mismatch" }
                val temporary = File(root, target.name + ".tmp")
                temporary.delete()
                temporary.outputStream().use { out ->
                    check(temporary.setReadOnly())
                    out.write(bytes)
                    out.fd.sync()
                }
                check(temporary.renameTo(target))
                return target
            }
            val jar = extract("engine.jar")
            extract("$abi/libmobilesleepjni.so")
            extract("$abi/libtensorflowlite_jni.so")
            val loader = DexClassLoader(jar.path, root.path, root.path, context.classLoader)
            val type = loader.loadClass("GalaxySleepEngine")
            val assets = AssetManager::class.java.getDeclaredConstructor().newInstance()
            val cookie =
                AssetManager::class
                    .java
                    .getMethod("addAssetPath", String::class.java)
                    .invoke(assets, jar.path) as Int
            check(cookie != 0) { "Sleep model assets could not be opened" }
            val engineContext =
                object : android.content.ContextWrapper(context) {
                    override fun getAssets(): AssetManager = assets
                }
            val method =
                type.getMethod(
                    "analyze",
                    Context::class.java,
                    String::class.java,
                    String::class.java,
                )
            (engineContext to method).also { sharedEngine = it }
        }

    companion object {
        private val ENGINE_LOCK = Any()
        private val INFERENCE_LOCK = Any()
        @Volatile private var sharedEngine: Pair<Context, java.lang.reflect.Method>? = null

        internal fun retainedResults(values: Map<String, *>): JSONObject =
            JSONObject().apply {
                values.toSortedMap().forEach { (key, value) ->
                    val encoded = value as? String ?: return@forEach
                    val parsed = runCatching { JSONObject(encoded) }.getOrNull() ?: return@forEach
                    put(key, parsed)
                }
            }

        private fun sha256(bytes: ByteArray): String =
            MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") {
                "%02x".format(it.toInt() and 255)
            }
    }
}
