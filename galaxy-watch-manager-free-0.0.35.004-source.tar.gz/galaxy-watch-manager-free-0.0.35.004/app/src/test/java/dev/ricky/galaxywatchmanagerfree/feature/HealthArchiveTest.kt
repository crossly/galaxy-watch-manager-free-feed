package dev.ricky.galaxywatchmanagerfree.feature

import dev.ricky.galaxywatchmanagerfree.feature.monitor.BpRecord
import dev.ricky.galaxywatchmanagerfree.feature.monitor.EcgRecord
import java.io.ByteArrayOutputStream
import java.security.MessageDigest
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.Locale
import java.util.zip.ZipInputStream
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class HealthArchiveTest {
    private fun archive(
        snapshot: HealthExportSnapshot,
        exportedAt: Long = 1_790_000_000_000,
        zone: ZoneId = ZoneId.of("Asia/Shanghai"),
    ): Map<String, ByteArray> {
        val output = ByteArrayOutputStream()
        HealthArchive.write(output, snapshot, exportedAt, zone)
        return buildMap {
            ZipInputStream(output.toByteArray().inputStream()).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    put(entry.name, zip.readBytes())
                }
            }
        }
    }

    @Test
    fun `archive exports every ECG sample and independent records with checksums`() {
        val ecg =
            EcgRecord(
                "ecg,\"id",
                1_790_000_000_000,
                75,
                1,
                waveform = floatArrayOf(.125f, -.25f, .5f),
            )
        val state =
            WatchState(
                ecgRecords = listOf(ecg),
                bpRecords = listOf(BpRecord("bp", ecg.startTime, 120, 80, 65)),
            )
        val files =
            archive(
                HealthExportSnapshot(
                    state,
                    JSONObject()
                        .put(
                            "modules",
                            JSONObject()
                                .put("stress", JSONArray().put(JSONObject().put("value", 30))),
                        ),
                )
            )
        val manifest = JSONObject(files.getValue("manifest.json").decodeToString())
        assertEquals(HealthArchive.SCHEMA, manifest.getString("schema"))
        assertEquals("Asia/Shanghai", manifest.getString("time_zone"))
        val listed = manifest.getJSONArray("files")
        assertEquals(files.size - 1, listed.length())
        for (i in 0 until listed.length()) {
            val row = listed.getJSONObject(i)
            val digest =
                MessageDigest.getInstance("SHA-256")
                    .digest(files.getValue(row.getString("path")))
                    .joinToString("") { "%02x".format(it) }
            assertEquals(digest, row.getString("sha256"))
        }
        val metadata = JSONArray(files.getValue("ecg.json").decodeToString()).getJSONObject(0)
        assertEquals(ecg.id, metadata.getString("record_id"))
        assertEquals(3, metadata.getInt("sample_count"))
        val csv =
            files.getValue(metadata.getString("waveform_file")).decodeToString().trim().lines()
        assertEquals(4, csv.size)
        assertTrue(csv.last().contains("0.004"))
        assertTrue(csv.last().contains("0.5"))
        val readings = JSONArray(files.getValue("measurements.json").decodeToString())
        assertEquals(3, readings.length())
        assertEquals("mm[Hg]", readings.getJSONObject(0).getString("unit"))
        assertEquals("bp", readings.getJSONObject(1).getString("record_id"))
        assertTrue(files.getValue("source_records.json").decodeToString().contains("stress"))
    }

    @Test
    fun `numeric exports use dots independently of UI locale and unknowns remain null`() {
        val previous = Locale.getDefault()
        try {
            Locale.setDefault(Locale.GERMAN)
            val ecg = EcgRecord("id", 1_790_000_000_000, -1, 3, waveform = floatArrayOf(.125f))
            val files =
                archive(HealthExportSnapshot(WatchState(ecgRecords = listOf(ecg)), JSONObject()))
            assertTrue(files.getValue("ecg/record-1.csv").decodeToString().contains("0.125"))
            assertTrue(
                JSONObject(files.getValue("snapshot.json").decodeToString()).isNull("today_steps")
            )
            assertTrue(
                JSONArray(files.getValue("ecg.json").decodeToString())
                    .getJSONObject(0)
                    .isNull("average_heart_rate_bpm")
            )
        } finally {
            Locale.setDefault(previous)
        }
    }

    @Test
    fun `historical sleep and manual naps are exported beyond the latest displayed day`() {
        val old =
            SleepParser.manualSession(SleepParser.ManualNap(1_788_000_000_000, 1_788_003_600_000))
        val recent =
            SleepParser.manualSession(SleepParser.ManualNap(1_789_000_000_000, 1_789_003_600_000))
        val files =
            archive(
                HealthExportSnapshot(
                    WatchState(
                        sleep = recent,
                        sleepSessions = listOf(recent),
                        allSleepSessions = listOf(old, recent),
                    ),
                    JSONObject(),
                )
            )
        val sessions = JSONArray(files.getValue("sleep_sessions.json").decodeToString())
        assertEquals(2, sessions.length())
        assertEquals(old.id, sessions.getJSONObject(0).getString("record_id"))
        assertEquals("manual", sessions.getJSONObject(0).getString("source"))
    }

    @Test
    fun `normalization includes retained history outside display windows and preserves both HRV algorithms`() {
        val ts = 1_788_000_000_000L
        val modules =
            JSONObject()
                .put(
                    HeartRateLog.MODULE,
                    JSONArray()
                        .put(
                            JSONObject()
                                .put("datauuid", "heart-old")
                                .put("start_time", ts)
                                .put("heart_rate", 67)
                        ),
                )
                .put(
                    HealthMetric.HRV.moduleKeys.first(),
                    JSONArray()
                        .put(
                            JSONObject()
                                .put("datauuid", "hrv-old")
                                .put("start_time", ts)
                                .put("update_time", ts + 100)
                                .put("rmssd", 28.5)
                                .put("sdnn", 42.5)
                        ),
                )
        val files =
            archive(HealthExportSnapshot(WatchState(), JSONObject().put("modules", modules)))
        val rows = JSONArray(files.getValue("measurements.json").decodeToString())
        assertEquals(3, rows.length())
        val hrv =
            (0 until rows.length()).map(rows::getJSONObject).filter {
                it.getString("type") == "heart_rate_variability"
            }
        assertEquals(setOf("rmssd", "sdnn"), hrv.map { it.getString("method") }.toSet())
        assertEquals(2, hrv.map { it.getString("record_id") }.toSet().size)
        assertEquals(setOf(28.5, 42.5), hrv.map { it.getDouble("value") }.toSet())
        assertTrue(hrv.all { it.getLong("source_revision_epoch_ms") == ts + 100 })
    }

    @Test
    fun `alias revisions replace whole records before projecting samples and workouts`() {
        val ts = 1_700_000_000_000L
        val oldMetric =
            JSONObject()
                .put("datauuid", "revised-hrv")
                .put("start_time", ts)
                .put("update_time", ts + 1)
                .put(
                    "binning_data",
                    JSONArray()
                        .put(JSONObject().put("start_time", ts).put("rmssd", 20).put("sdnn", 40)),
                )
        val newMetric =
            JSONObject(oldMetric.toString())
                .put("update_time", ts + 2)
                .put(
                    "binning_data",
                    JSONArray().put(JSONObject().put("start_time", ts + 60_000).put("rmssd", 30)),
                )
        val oldWorkout =
            JSONObject()
                .put("datauuid", "revised-workout")
                .put("start_time", ts)
                .put("end_time", ts + 3_600_000)
                .put("update_time", ts + 1)
                .put("exercise_type", 1001)
                .put("calorie", 90)
        val newWorkout =
            JSONObject(oldWorkout.toString()).put("update_time", ts + 2).put("calorie", 100)
        val modules =
            JSONObject()
                .put(HealthMetric.HRV.moduleKeys[0], JSONArray().put(newMetric))
                .put(HealthMetric.HRV.moduleKeys[1], JSONArray().put(oldMetric))
                .put(ExerciseLog.MODULE, JSONArray().put(newWorkout))
                .put(ExerciseLog.MODULE_ALIAS, JSONArray().put(oldWorkout))
        val files =
            archive(HealthExportSnapshot(WatchState(), JSONObject().put("modules", modules)))
        val rows = JSONArray(files.getValue("measurements.json").decodeToString())
        assertEquals(1, rows.length())
        assertEquals(ts + 60_000, rows.getJSONObject(0).getLong("start_time_epoch_ms"))
        val workout = JSONArray(files.getValue("workouts.json").decodeToString()).getJSONObject(0)
        assertEquals(100, workout.getInt("energy_kcal"))
        assertEquals(ts + 2, workout.getLong("source_revision_epoch_ms"))
        assertEquals(ExerciseLog.MODULE, workout.getString("source_module"))
        val rawModules =
            JSONObject(files.getValue("source_records.json").decodeToString())
                .getJSONObject("modules")
        assertTrue(rawModules.has(HealthMetric.HRV.moduleKeys[1]))
        assertTrue(rawModules.has(ExerciseLog.MODULE_ALIAS))
    }

    @Test
    fun `actual store archive keeps alias revisions real dates unknown floors and long history`() {
        val zone = ZoneId.of("Asia/Shanghai")
        val exportedAt = Instant.parse("2026-11-10T12:00:00Z").toEpochMilli()
        fun at(day: String, hour: Int): Long =
            ZonedDateTime.of(LocalDate.parse(day), java.time.LocalTime.of(hour, 0), zone)
                .toInstant()
                .toEpochMilli()

        val oldMetric =
            JSONObject()
                .put("com.samsung.health.hrv.datauuid", "archive-revised")
                .put("com.samsung.health.hrv.start_time", at("2026-10-20", 8))
                .put("com.samsung.health.hrv.update_time", at("2026-10-20", 8) + 1)
                .put(
                    "binning_data",
                    JSONArray()
                        .put(JSONObject().put("start_time", at("2026-10-20", 8)).put("rmssd", 20))
                        .put(
                            JSONObject()
                                .put("start_time", at("2026-10-20", 8) + 600_000)
                                .put("rmssd", 25)
                        ),
                )
        val newMetric =
            JSONObject()
                .put("datauuid", "archive-revised")
                .put("start_time", at("2026-10-20", 8))
                .put("update_time", at("2026-10-20", 8) + 2)
                .put(
                    "binning_data",
                    JSONArray()
                        .put(
                            JSONObject()
                                .put("start_time", at("2026-10-20", 8) + 600_000)
                                .put("rmssd", 30)
                        ),
                )
        val oldHeart =
            JSONObject()
                .put("datauuid", "archive-old-heart")
                .put("start_time", at("2026-10-21", 9))
                .put("heart_rate", 67)
        val yesterdaySummary =
            JSONObject()
                .put("datauuid", "archive-yesterday")
                .put("day_time", 20261108)
                .put("update_time", exportedAt - 3_600_000)
                .put("step_count", 1111)
        val todaySummary =
            JSONObject()
                .put("datauuid", "archive-today")
                .put("day_time", 20261109)
                .put("update_time", exportedAt - 1_800_000)
                .put("step_count", 2222)
                .put("calorie", 100)
                .put("distance", 1400)
        val floors =
            JSONArray()
                .put(
                    JSONObject()
                        .put("datauuid", "archive-floors-zero")
                        .put("start_time", at("2026-11-09", 10))
                        .put("floor_count", 0)
                )
                .put(
                    JSONObject()
                        .put("datauuid", "archive-floors-unknown")
                        .put("start_time", at("2026-11-09", 11))
                )
        val store = HealthRecordStore()
        store.merge(
            mapOf(
                HealthMetric.HRV.moduleKeys[0] to listOf(newMetric),
                HealthMetric.HRV.moduleKeys[1] to listOf(oldMetric),
                HeartRateLog.MODULE to listOf(oldHeart),
                HealthStepParser.MODULE_DAY_SUMMARY to listOf(yesterdaySummary, todaySummary),
                "com.samsung.shealth.floors_climbed" to
                    listOf(floors.getJSONObject(0), floors.getJSONObject(1)),
            ),
            exportedAt,
        )

        val files =
            archive(
                HealthExportSnapshot(WatchState(), JSONObject(store.encode())),
                exportedAt,
                zone,
            )
        val measurements = JSONArray(files.getValue("measurements.json").decodeToString())
        val hrv =
            (0 until measurements.length()).map(measurements::getJSONObject).filter {
                it.getString("type") == "heart_rate_variability"
            }
        assertEquals(1, hrv.size)
        assertEquals(30.0, hrv.single().getDouble("value"), 0.0)
        assertEquals("archive-revised", hrv.single().getString("source_record_id"))
        assertEquals(HealthMetric.HRV.moduleKeys[0], hrv.single().getString("source_module"))
        assertEquals(at("2026-10-20", 8) + 2, hrv.single().getLong("source_revision_epoch_ms"))
        assertEquals(at("2026-10-20", 8) + 600_000, hrv.single().getLong("start_time_epoch_ms"))
        assertTrue(
            (0 until measurements.length()).map(measurements::getJSONObject).any {
                it.getString("type") == "heart_rate" && it.getInt("value") == 67
            }
        )
        val daily =
            JSONArray(files.getValue("daily_activity.json").decodeToString()).let { rows ->
                (0 until rows.length()).associate {
                    rows.getJSONObject(it).getString("local_date") to rows.getJSONObject(it)
                }
            }
        assertEquals(1111, daily.getValue("2026-11-08").getInt("steps"))
        assertEquals(2222, daily.getValue("2026-11-09").getInt("steps"))
        val exportedFloors = JSONArray(files.getValue("floors.json").decodeToString())
        assertEquals(0, exportedFloors.getJSONObject(0).getInt("floors"))
        assertTrue(exportedFloors.getJSONObject(1).isNull("floors"))
        val rawModules =
            JSONObject(files.getValue("source_records.json").decodeToString())
                .getJSONObject("modules")
        val rawOld = rawModules.getJSONArray(HealthMetric.HRV.moduleKeys[1]).getJSONObject(0)
        assertEquals(2, rawOld.getJSONArray("binning_data").length())
        assertTrue(rawOld.has("com.samsung.health.hrv.update_time"))
        assertEquals(1, rawModules.getJSONArray(HealthMetric.HRV.moduleKeys[0]).length())
        val manifest = JSONObject(files.getValue("manifest.json").decodeToString())
        assertEquals(HealthArchive.SCHEMA, manifest.getString("schema"))
        val datasets = manifest.getJSONObject("datasets")
        assertEquals(7, datasets.getJSONObject("source_records.json").getInt("record_count"))
        assertEquals(2, datasets.getJSONObject("measurements.json").getInt("record_count"))
        assertEquals(
            "2026-11-08",
            datasets.getJSONObject("daily_activity.json").getString("first_local_date"),
        )
        assertEquals(
            "2026-11-09",
            datasets.getJSONObject("daily_activity.json").getString("last_local_date"),
        )
    }

    @Test
    fun `long form HRV fields preserve both algorithms`() {
        val row =
            JSONObject()
                .put("datauuid", "long-hrv")
                .put("start_time", 1_700_000_000_000L)
                .put("com.samsung.health.hrv.rmssd", 25)
                .put("com.samsung.health.hrv.sdnn", 40)
        val modules = JSONObject().put(HealthMetric.HRV.moduleKeys.first(), JSONArray().put(row))
        val files =
            archive(HealthExportSnapshot(WatchState(), JSONObject().put("modules", modules)))
        val rows = JSONArray(files.getValue("measurements.json").decodeToString())
        assertEquals(
            setOf("rmssd", "sdnn"),
            (0 until rows.length()).map { rows.getJSONObject(it).getString("method") }.toSet(),
        )
    }

    @Test
    fun `daily heart statistics keep the measured date across a disconnected midnight`() {
        val stats = HeartRateLog.Stats(60, 100, 80, 5)
        val state =
            WatchState(
                heartRateDays = mapOf("2026-11-08" to stats),
                heartRateWeek = List(6) { null } + stats,
                todaySteps = 1234,
            )
        val cache = JSONObject().put("day", "2026-11-08")
        val files =
            archive(
                HealthExportSnapshot(state, JSONObject(), cache),
                java.time.Instant.parse("2026-11-09T12:00:00Z").toEpochMilli(),
                ZoneId.of("UTC"),
            )
        val rows = JSONArray(files.getValue("heart_rate_daily.json").decodeToString())
        assertEquals("2026-11-08", rows.getJSONObject(0).getString("local_date"))
        val snapshot = JSONObject(files.getValue("snapshot.json").decodeToString())
        assertEquals("2026-11-08", snapshot.getString("data_local_date"))
        assertTrue(snapshot.isNull("today_steps"))
        assertEquals(1234, snapshot.getInt("data_day_steps"))
    }

    @Test
    fun `workout unknowns stay null and routine children keep full details`() {
        val parent =
            ExerciseLog.Session(
                "routine",
                51005,
                1_789_000_000_000,
                1_789_003_600_000,
                60,
                -1,
                -1.0,
                -1,
                -1,
            )
        val child =
            parent.copy(
                id = "child",
                typeCode = 1001,
                routineId = "routine",
                title = "Synthetic workout",
                count = 12,
                countType = 30002,
                minHeartRate = 60,
                meanSpeed = 2.5,
                maxSpeed = 3.5,
                altitudeGain = 0.0,
                altitudeLoss = 2.0,
            )
        val files =
            archive(
                HealthExportSnapshot(WatchState(exercises = listOf(parent, child)), JSONObject())
            )
        val rows = JSONArray(files.getValue("workouts.json").decodeToString())
        val missing = rows.getJSONObject(0)
        assertTrue(missing.isNull("distance_m"))
        assertTrue(missing.isNull("energy_kcal"))
        val row = rows.getJSONObject(1)
        assertEquals("routine", row.getString("routine_id"))
        assertEquals(12, row.getInt("count"))
        assertEquals(60, row.getInt("min_heart_rate_bpm"))
        assertEquals(2.5, row.getDouble("mean_speed_m_per_s"), 0.0)
        assertEquals(0.0, row.getDouble("altitude_gain_m"), 0.0)
        assertFalse(row.getBoolean("is_top_level"))
    }

    @Test
    fun `independent stores keep detached manual naps and all local analysis revisions`() {
        val nap = SleepParser.ManualNap(1_700_000_000_000, 1_700_003_600_000)
        val inferred =
            SleepParser.manualSession(nap).copy(id = "inferred", analysisSource = "local-model/v1")
        val original = JSONObject(SleepParser.encode(inferred)).put("future_model_field", 123)
        val revised = inferred.copy(analysisSource = "local-model/v2", reportedSleepMinutes = 45)
        val settings =
            JSONObject()
                .put(
                    "vascular_load",
                    JSONObject().put("enabled", true).put("desired", JSONObject.NULL),
                )
        val files =
            archive(
                HealthExportSnapshot(
                    WatchState(),
                    JSONObject(),
                    manualNaps = listOf(nap),
                    localSleepResults =
                        JSONObject()
                            .put("v1-cache", original)
                            .put("v2-cache", JSONObject(SleepParser.encode(revised))),
                    collectionSettings = settings,
                )
            )
        val sessions = JSONArray(files.getValue("sleep_sessions.json").decodeToString())
        assertEquals(1, sessions.length())
        assertEquals(
            SleepParser.manualSession(nap).id,
            sessions.getJSONObject(0).getString("record_id"),
        )
        assertEquals(1, JSONArray(files.getValue("manual_naps.json").decodeToString()).length())
        val analysis = JSONArray(files.getValue("local_sleep_analysis.json").decodeToString())
        assertEquals(2, analysis.length())
        assertEquals(
            123,
            analysis.getJSONObject(0).getJSONObject("retained_result").getInt("future_model_field"),
        )
        assertEquals(
            setOf("local-model/v1", "local-model/v2"),
            (0 until analysis.length())
                .map { analysis.getJSONObject(it).getJSONObject("session").getString("source") }
                .toSet(),
        )
        assertTrue(
            JSONObject(files.getValue("collection_settings.json").decodeToString())
                .getJSONObject("vascular_load")
                .getBoolean("enabled")
        )
    }

    @Test
    fun `interval without end time keeps null metadata and exports`() {
        val ts = 1_700_000_000_000L
        val modules =
            JSONObject()
                .put(
                    HealthStepParser.MODULE_STEP_COUNT,
                    JSONArray()
                        .put(
                            JSONObject()
                                .put("datauuid", "steps-1")
                                .put("start_time", ts)
                                .put("count", 10)
                        ),
                )
        val files =
            archive(HealthExportSnapshot(WatchState(), JSONObject().put("modules", modules)))
        val row =
            JSONArray(files.getValue("activity_intervals.json").decodeToString()).getJSONObject(0)
        assertTrue(row.isNull("end_time"))
        val metadata =
            JSONObject(files.getValue("manifest.json").decodeToString())
                .getJSONObject("datasets")
                .getJSONObject("activity_intervals.json")
        assertEquals(HealthExportData.time(ts), metadata.getString("first_start_time"))
        assertEquals(HealthExportData.time(ts), metadata.getString("last_end_time"))
    }

    @Test
    fun `explicitly null dataset text never becomes the spelling null`() {
        val android =
            object : JSONObject() {
                override fun optString(name: String): String =
                    if (has(name) && isNull(name)) "null" else super.optString(name)
            }
        android.put("record_id", "steps-1").put("end_time", JSONObject.NULL)
        assertNull(HealthArchive.datasetText(android, "end_time"))
        assertEquals("steps-1", HealthArchive.datasetText(android, "record_id"))
    }

    @Test
    fun `local analysis stages survive normalized sleep export after bound trimming`() {
        val start = 1_700_000_000_000L
        val end = start + 8 * 3_600_000L
        val analyzed =
            SleepParser.Session(
                startMillis = start + 10 * 60_000L,
                endMillis = end - 5 * 60_000L,
                segments =
                    listOf(
                        SleepParser.Segment(
                            start + 10 * 60_000L,
                            end - 5 * 60_000L,
                            SleepParser.Stage.LIGHT,
                        )
                    ),
                efficiency = null,
                score = null,
                id = "analyzed-night",
                analysisSource = SleepAnalysisResult.SOURCE,
                recordedEndMillis = end,
            )
        val files =
            archive(
                HealthExportSnapshot(
                    WatchState(sleep = analyzed, sleepSessions = listOf(analyzed)),
                    JSONObject()
                        .put(
                            "modules",
                            JSONObject()
                                .put(
                                    SleepParser.MODULE_SLEEP,
                                    JSONArray()
                                        .put(
                                            JSONObject()
                                                .put("datauuid", "analyzed-night")
                                                .put("start_time", start)
                                                .put("end_time", end)
                                        ),
                                ),
                        ),
                    JSONObject()
                        .put("sleep_sessions_json", SleepParser.encodeSessions(listOf(analyzed))),
                    localSleepResults =
                        JSONObject().put("analyzed-cache", JSONObject(SleepParser.encode(analyzed))),
                )
            )
        val sessions = JSONArray(files.getValue("sleep_sessions.json").decodeToString())
        assertEquals(1, sessions.length())
        val session = sessions.getJSONObject(0)
        assertEquals(SleepAnalysisResult.SOURCE, session.getString("source"))
        assertEquals(1, session.getJSONArray("stages").length())
        assertEquals(465, session.getInt("time_asleep_minutes"))
        val retainedAnalysis =
            JSONArray(files.getValue("local_sleep_analysis.json").decodeToString()).getJSONObject(0)
        val normalizedViews =
            listOf(session, retainedAnalysis.getJSONObject("session")) +
                listOf("latest_sleep.json", "latest_sleep_sessions.json").map { path ->
                    JSONArray(files.getValue(path).decodeToString()).getJSONObject(0)
                }
        normalizedViews.forEach { view ->
            assertEquals(58, view.getInt("computed_score"))
            assertEquals(SleepScore.SOURCE, view.getString("computed_score_algorithm"))
            assertEquals(SleepScore.SOURCE, view.getString("score_source"))
            assertTrue(view.isNull("score"))
        }
        assertFalse(retainedAnalysis.getJSONObject("retained_result").has("computed_score"))
        val manifest = JSONObject(files.getValue("manifest.json").decodeToString())
        assertEquals("galaxy-watch-manager-free.health.v3", manifest.getString("schema"))
        assertEquals(
            1,
            manifest
                .getJSONObject("datasets")
                .getJSONObject("sleep_sessions.json")
                .getInt("record_count"),
        )
    }

    @Test
    fun `raw binning exceeds UI caps without duplicating aggregate or alias revisions`() {
        val ts = 1_700_000_000_000L
        val bins =
            JSONArray(
                (0..700).map { i ->
                    JSONObject().put("start_time", ts + i * 60_000L).put("heart_rate", 60 + i % 10)
                }
            )
        val old =
            JSONObject()
                .put("datauuid", "same-hrv")
                .put("start_time", ts)
                .put("rmssd", 21)
                .put("update_time", ts + 1)
        val latest = JSONObject(old.toString()).put("rmssd", 30).put("update_time", ts + 2)
        val modules =
            JSONObject()
                .put(
                    HeartRateLog.MODULE,
                    JSONArray()
                        .put(
                            JSONObject()
                                .put("datauuid", "bins")
                                .put("start_time", ts)
                                .put("heart_rate", 150)
                                .put("binning_data", bins)
                        ),
                )
                .put(HealthMetric.HRV.moduleKeys[0], JSONArray().put(old))
                .put(HealthMetric.HRV.moduleKeys[1], JSONArray().put(latest))
        val state =
            WatchState(
                heartRatePoints = listOf(HeartRateLog.Point(ts, 70)),
                metricSamples =
                    mapOf(
                        HealthMetric.HRV to
                            listOf(
                                HealthMetricLog.Sample(ts, 21f),
                                HealthMetricLog.Sample(ts - 60_000, 25f),
                            )
                    ),
            )
        val rows =
            JSONArray(
                archive(HealthExportSnapshot(state, JSONObject().put("modules", modules)))
                    .getValue("measurements.json")
                    .decodeToString()
            )
        val heart =
            (0 until rows.length()).map(rows::getJSONObject).filter {
                it.getString("type") == "heart_rate"
            }
        assertEquals(701, heart.size)
        assertFalse(heart.any { it.getInt("value") == 150 })
        val hrv =
            (0 until rows.length()).map(rows::getJSONObject).filter {
                it.getString("type") == "heart_rate_variability"
            }
        assertEquals(2, hrv.size)
        assertEquals(30.0, hrv.first { it.getString("method") == "rmssd" }.getDouble("value"), 0.0)
        assertEquals(
            "unknown",
            hrv.first { it.getLong("start_time_epoch_ms") == ts - 60_000 }.getString("method"),
        )
    }

    @Test
    fun `stress floors vascular load and activity retain zero and distinguish missing values`() {
        val ts = 1_700_000_000_000L
        val modules =
            JSONObject()
                .put(
                    StressLog.MODULE,
                    JSONArray()
                        .put(
                            JSONObject()
                                .put("datauuid", "stress-zero")
                                .put("start_time", ts)
                                .put("score", 0)
                        ),
                )
                .put(
                    "com.samsung.shealth.floors_climbed",
                    JSONArray()
                        .put(
                            JSONObject()
                                .put("datauuid", "floors-zero")
                                .put("start_time", ts)
                                .put("floor_count", 0)
                        )
                        .put(
                            JSONObject().put("datauuid", "floors-unknown").put("start_time", ts + 1)
                        ),
                )
                .put(
                    VascularLoadLog.MODULE,
                    JSONArray()
                        .put(
                            JSONObject()
                                .put("datauuid", "reset")
                                .put("start_time", ts)
                                .put("type", 1)
                        )
                        .put(
                            JSONObject()
                                .put("datauuid", "baseline")
                                .put("start_time", ts + 1)
                                .put("type", 2)
                                .put("measurement", 0)
                        )
                        .put(
                            JSONObject()
                                .put("datauuid", "load")
                                .put("start_time", ts + 2)
                                .put("type", 3)
                                .put("measurement", -5.5)
                        ),
                )
                .put(
                    HealthStepParser.MODULE_STEP_COUNT,
                    JSONArray()
                        .put(
                            JSONObject()
                                .put("datauuid", "steps-zero")
                                .put("start_time", ts)
                                .put("count", 0)
                        )
                        .put(
                            JSONObject()
                                .put("datauuid", "steps-unknown")
                                .put("start_time", ts + 86_400_000L)
                        ),
                )
        val files =
            archive(HealthExportSnapshot(WatchState(), JSONObject().put("modules", modules)))
        val stress =
            JSONArray(files.getValue("measurements.json").decodeToString()).getJSONObject(0)
        assertEquals("stress", stress.getString("type"))
        assertEquals(0.0, stress.getDouble("value"), 0.0)
        val floors = JSONArray(files.getValue("floors.json").decodeToString())
        assertEquals(0, floors.getJSONObject(0).getInt("floors"))
        assertTrue(floors.getJSONObject(1).isNull("floors"))
        val load = JSONArray(files.getValue("vascular_load.json").decodeToString())
        assertEquals(3, load.length())
        assertTrue(load.getJSONObject(0).isNull("measurement"))
        assertEquals(-5.5, load.getJSONObject(2).getDouble("measurement"), 0.0)
        val activity = JSONArray(files.getValue("daily_activity.json").decodeToString())
        assertEquals(0, activity.getJSONObject(0).getInt("steps"))
        assertTrue(activity.getJSONObject(0).isNull("active_energy_kcal"))
        assertTrue(activity.getJSONObject(1).isNull("steps"))
    }

    @Test
    fun `manifest counts and schema mappings cover every JSON dataset`() {
        val files = archive(HealthExportSnapshot(WatchState(), JSONObject()))
        val manifest = JSONObject(files.getValue("manifest.json").decodeToString())
        val schema = JSONObject(files.getValue("schema.json").decodeToString())
        val datasets = manifest.getJSONObject("datasets")
        files
            .filterKeys { it.endsWith(".json") && it !in setOf("schema.json", "manifest.json") }
            .forEach { (path, bytes) ->
                assertTrue("schema mapping missing: $path", schema.getJSONObject("files").has(path))
                assertTrue("dataset missing: $path", datasets.has(path))
                if (bytes.decodeToString().startsWith("["))
                    assertEquals(
                        JSONArray(bytes.decodeToString()).length(),
                        datasets.getJSONObject(path).getInt("record_count"),
                    )
            }
        assertEquals("unknown", manifest.getJSONObject("sync").getString("historical_completeness"))
        assertFalse(
            manifest.getJSONObject("retention").getBoolean("export_applies_additional_trimming")
        )
    }

    @Test
    fun `empty data exports a valid documented empty dataset`() {
        val files = archive(HealthExportSnapshot(WatchState(), JSONObject()))
        assertEquals(0, JSONArray(files.getValue("ecg.json").decodeToString()).length())
        assertEquals(0, JSONArray(files.getValue("measurements.json").decodeToString()).length())
        assertTrue(
            files.getValue("README.md").decodeToString().contains("NOT an Apple Health import")
        )
        assertFalse(files.keys.any { it.endsWith(".apk") || it.contains("credential") })
    }
}
