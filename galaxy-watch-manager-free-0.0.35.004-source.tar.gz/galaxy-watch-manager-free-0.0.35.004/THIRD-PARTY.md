# 第三方组件与授权边界

本仓库原创代码采用 GNU GPL v3.0（根目录 `LICENSE`）。此文件记录不适用该许可的来源与待办事项：
它不授予新的权利，也不把厂商二进制重新声明为原创或开源模型。

| 内容 | 来源/版本 | 当前说明 |
|---|---|---|
| Android/Kotlin 应用与自写协议代码、原创图形 | 本仓库 | GNU GPL v3.0（`LICENSE`）；厂商来源资产除外 |
| 睡眠 DEX 桥、模型、分位表、Samsung JNI | Samsung Health 7.1.0.053，输入摘要见资产 NOTICE | 厂商来源；**公开仓库与公开构建不包含**。仅由用户本地 APK 提取到被忽略的 `private/vendor-assets/assets/sleep/`，供显式 `-PvendorAssetsDir` 的自用构建使用。未在仓库提供再分发许可依据，不能被根许可证覆盖，也不能因改为可选本地构建而声称已获授权 |
| TensorFlow Lite JNI | 同一 APK 附带的运行时 | 上游 Apache-2.0 文本保留于 `app/src/main/assets/sleep/TENSORFLOW-LICENSE.txt`；公开版不再分发该二进制，本地可选构建若包含它仍需确认该特定二进制的完整 notice/依赖清单 |
| 表盘预览图 | 历史厂商资源提取脚本 `scripts/gen_watchface_assets.py` | **公开版使用原创通用表盘示意** `app/src/main/res/drawable/watch_face_illustration.xml`，不是官方截图；原始厂商预览仅保存于被忽略的 `private/vendor-assets/res/drawable-nodpi/`，不随公开版分发，再分发授权仍未确认。协议组件名和原始图片不是同一授权问题 |
| UI 布局参考与液态玻璃移植 | FLClash `7fd417fb9a9a277c6a9339a8ac87f907df7c25f7`；见 `docs/UI-FLCLASH-REFERENCE.md` | 漂浮底栏移植其 pill/lens/lensContent 着色与按压拖动逻辑，适配 Compose/AGSL；GNU GPL v3，许可与来源随包保留于 `app/src/main/assets/licenses/FLCLASH-LICENSE.txt`、`FLCLASH-NOTICE.txt` |
| AndroidX/Material/Coroutines/GMS 等依赖 | `app/build.gradle` / Gradle 依赖解析 | 各自遵从其许可证；不能因本仓库许可证而改变 |
| Shizuku API / Provider | `dev.rikka.shizuku:api:13.1.5`、`provider:13.1.5`；[上游](https://github.com/RikkaApps/Shizuku-API) | MIT；许可随包保留于 `app/src/main/assets/licenses/SHIZUKU-LICENSE.txt`。仅在 Shizuku 可用且用户授权后停用/恢复限定的官方连接组件；普通连接不要求安装 Shizuku |

睡眠组件的输入来源与每个文件 SHA-256：本地生成的
`private/vendor-assets/assets/sleep/manifest.json`（被 Git 忽略，不在公开仓库或源码归档中）。
重建流程：`scripts/sleep-engine/README.md`。完整来源声明：
`app/src/main/assets/sleep/NOTICE.md`。ARM64 实机验收与 ARMv7 未验收的边界继续适用。

## 资产隔离

- `private/` 已被 `.gitignore` 忽略；厂商 jar/so/manifest 和 `wf_*.webp` 只保留在
  `private/vendor-assets/{assets/sleep,res/drawable-nodpi}`，不在公开 Git 树、公开 APK 或
  `git archive` 源码包中。
- `app/build.gradle` 的 `-PvendorAssetsDir=<含 assets/ 与 res/ 的目录>` 仅供本机自用构建，
  检测到 CI 环境会直接失败；默认构建 `BuildConfig.VENDOR_ASSETS_ENABLED=false`。
- `scripts/check_public_assets.py` 可在发布前检查源码树与 APK；`verifyNoVendorAssets` Gradle
  任务在构建前拒绝重新落入 `app/src/main` 的厂商资产。

## 尚待维护者决定

1. ~~选择原创代码的根许可证~~：已选定 GPLv3（`LICENSE`）。仍需逐项确认上表中哪些资源明确不包含在该授权中。
2. 厂商组件和表盘图片的可分发依据仍未确认；当前公开交付已改为不含这些资产的默认构建，
   但这是降低分发风险，不等于取得授权。若未来要公开分发含厂商资产的版本，必须先取得明确许可。
3. Git 历史、真实抓包和截图的去标识化检查：实机截图、抓包回放与设备标识已从当前版本移除，源码仓库以该快照重建历史并撤下旧 Release 与标签。包含旧历史的恢复备份仅保留在被忽略的本地 `private/`；公开前仍需复核现有文件，并检查 GitHub 缓存及其他副本。

厂商组件来源与本地提取路径继续保留，公开版停止新的厂商 raw 睡眠分期推理，已接收分期、
旧分析缓存及评分和导出仍可使用。原有历史文件的授权不会因资产隔离而变化。
