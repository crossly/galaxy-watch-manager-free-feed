# 参与开发

当前支持范围、协议事实与限制以 README 和 `docs/PROTOCOL-SPEC.md` 为准。请先阅读
`docs/REVIEW-0.0.9.md`，并在修复时更新 `docs/OPTIMIZATION-PROGRESS.md` 中对应项目。

## 本地验证

需要 JDK 17、Android SDK 36、Build Tools 35.0.0。

```sh
./gradlew :app:spotlessApply
./gradlew :app:spotlessCheck :app:testDebugUnitTest :app:lintDebug :app:assembleRelease
python3 scripts/check-i18n.py
python3 -m unittest discover -s scripts/tests -v
```

CI 仅运行单元测试、Lint 和编译构建，不包含模拟器测试。界面效果与真机行为在明确选定的
真实手机上验证；需要运行真机设备测试时，通过 `adb devices -l` 确认目标并设置
`ANDROID_SERIAL`，再本地执行 `./gradlew :app:connectedDebugAndroidTest`。

Spotless 使用 ktfmt Kotlin style，以当前 Git 历史的首父链根提交为增量格式化基线；未修改的
历史文件不要求为格式单独改动。CI 需要完整提交历史（checkout `fetch-depth: 0`）。不要为了
通过检查关闭新发现的 Lint 规则；确需抑制时在局部说明原因。

## 代码约定

- 用公开业务接口测试行为。数据修复先加入能复现错误的测试，时区、日期和时钟显式传入。
- 原始健康记录先按身份和修订时间替换，再统一投影。不要对已经聚合的均值再次累加。
- 未知值和有效零值分开；没有收到的睡眠阶段、地图、设备能力不能构造占位数据。
- 设备确认值和等待确认的目标值分开；新命令取消旧命令重试，断线取消未完成任务。
- 协议 UUID、字段名、官方包名和签名摘要保留真实取值与来源，不做成任意用户配置。
- 不要提交真实设备标识：EID、IMEI、蓝牙或 Wi-Fi MAC、手机与手表 node ID、通知正文、联系人、健康读数截图，以及从真机抓取的帧回放。示例和测试统一使用合成值（如 `AA:BB:CC:DD:EE:FF`、`00000000`），确需真机证据时放在被忽略的 `private/`。
- 设备身份必须按配对设备持久化；首次登记尚未实现，不得宣传为任意设备开箱即用。
- 网络、磁盘和推理移出 UI 线程；明确大小限制、任务所有者、取消和失败处理。
- 正常日志不包含通知正文、原始健康记录或密码。异常日志记录类别和上下文，不吞错。
- UI 与交互约定见 [docs/UI-STANDARDS.md](docs/UI-STANDARDS.md)；优先复用页面、详情面板、卡片、Typography 和 palette。
- 本地化约定见 [docs/I18N.md](docs/I18N.md)。用户文案必须提供默认英文和简体中文 strings/plurals；资源 ID 与协议标识分开。运行 `python3 scripts/check-i18n.py` 校验键、引用与参数。
- 新增页面/组件验证英文长文案、大字号、明暗主题及状态恢复。避免为单个局部尺寸建立全局常量。
- 厂商组件和实验抓包与原创代码分开说明。正式构建不包含 debug 回放资源。

## 健康数据与导出联动

健康模块、模型/字段、持久化、派生统计、留存策略及采集设置变更，必须在同一变更中核对
[健康导出说明](docs/HEALTH-EXPORT.md)，并同步受影响的导出代码、格式说明和回归测试：

- 快照须覆盖所有当前设备的独立健康存储，包括原始记录、健康缓存、手动小睡、本机睡眠分析及安全投影后的采集设置；不能只读取首页或图表窗口。
- 同步检查 `HealthExportSnapshot`、原始/标准化归档、`HealthExportSchema`、manifest 的数量/时间范围/留存与同步边界、嵌入 README 和 `docs/HEALTH-EXPORT.md`。结构或语义变化时明确 schema 版本，不能静默改变既有契约。
- 保留官方记录身份与修订、来源、单位和算法；RMSSD 与 SDNN、皮温与核心体温、原始读数与派生汇总不能混同。未知值保持 null/缺失，有效零值保留；手动和推理数据必须标明来源，不能补造分期或测量。
- 回归测试通过实际归档入口验证新增数据及较早留存历史、修订/去重、未知值、父子关系、实际日期、schema/manifest 一致性和逐文件校验和。日期与时区显式传入，跨日导出不能把旧日快照改标成今天。
- 原始记录、标准化序列、日汇总、睡眠/运动父子记录是相关表示；文档必须说明其关系，避免导入或分析时重复累加。对留存删除和未同步范围不明的数据如实标为未知。

验证结果分开记录本地测试/构建、系统文件保存/分享、远端平台执行及设备重启后持久化；
没有设备或平台权限时，不以单元测试替代实机验收。没有导出影响的健康改动也应说明检查结果。

## 真机与远程调试

不要假定唯一连接设备或固定序列号。使用 `adb devices -l` 选择明确目标；远程 ADB 必须指定
主机、端口和序列号，不要更换本地默认 ADB server。远程隧道示例（在手机所在电脑执行）：

```sh
adb start-server
ssh -N -o ExitOnForwardFailure=yes \
  -R 127.0.0.1:15037:127.0.0.1:5037 <user>@<development-host>
```

开发机随后运行 `adb -H 127.0.0.1 -P 15037 devices -l`。手机需要授权 USB 调试；不要把 5037
绑定到公网。数据迁移前先保留可恢复副本，备份、日志与截图放在被 Git 忽略的 `private/`。

## 提交与发布

一个提交围绕一个可评审的目标；协议变化同步更新 SSOT，功能状态与验收证据同步更新文档。
统一通过 `./scripts/release.sh` 发布，未获得发布指令不自行打标签。发布后分别核验 Release、
公开清单、匿名下载、APK 版本及签名，不能仅根据工作流总状态断言镜像成功。
更新源发布失败必须使 Release job 失败，已上传的 Release 资产保留。SSH 探测保留错误输出并限定
连接等待和重试次数；GitHub 5xx 推送错误最多尝试三次，权限错误和并发写入冲突立即失败。

仅在明确要求覆盖当前版本时使用 `./scripts/release.sh --republish`：保留版本号，通过远端标签
校验与 `--force-with-lease` 更新当前标签，重新触发构建并替换 Release 附件及说明。常规发布仍
使用无参数命令递增稳定版第三段，`--nightly` 则在当前稳定版本后递增第四段（`001`–`999`）。
Nightly 使用同一正式签名并标为 prerelease，只更新 `nightly.json` 和 `apk-nightly`；稳定版只更新
`version.json` 和 `apk`。两通道均保留 APK 的不可变提交 URL，分别检查清单防回滚。
同版本重发不会让已安装相同版本号的客户端再次弹出更新提示。
版本号已预先递增且尚未创建标签时，使用 `./scripts/release.sh --current` 完成检查并发布该版本；
该选项拒绝覆盖已有标签。

原创代码以 GNU GPL v3.0 授权（见根目录 `LICENSE`）：提交即表示同意以自己的名义按该许可发布。
厂商来源组件不属于该授权范围，详情见 `THIRD-PARTY.md`；不要把整个仓库标为「所有文件均为 GPLv3」。
分发修改版时必须随附完整对应源码（GPLv3 §6），并且不得对下游追加额外限制（§10）。
