# 运动距离与健走地图核查

本文前半部分保留 2026-10 的无定位样本结论；2026-11-16 的定位数据链路核对、MapLibre 首版实现和验收边界见后半部分。

数据来源：当前手机 `watchfree_health` 持久化的 `HealthRecordStore`，共 8 条 `com.samsung.shealth.exercise` 记录。原始副本及展开后的明细位于未跟踪目录 `private/exercise-investigation/`。自动测试夹具 `app/src/test/resources/health/exercise-history.json` 仅保留核查所需字段，并替换记录 ID。

## 距离

每次运动的 `distance` 单位为米，是该次运动的汇总距离。8 条数据分别为：

| 起始记录日期（上海时区） | 距离（米，四舍五入） |
| --- | ---: |
| 10 月 14 日 | 760.14 |
| 10 月 14 日 | 1137.62 |
| 10 月 15 日 | 765.32 |
| 10 月 15 日 | 1075.80 |
| 10 月 15 日 | 1463.15 |
| 10 月 15 日 | 1075.15 |
| 10 月 21 日 | 627.32 |
| 10 月 22 日 | 1828.16 |

合计原始值为 **8732.66015625 米**，显示为 **8.73 公里**。每条 `mean_speed × duration / 1000` 都与该条 distance 一致（误差小于 0.001 米）。因此没有发现千倍的米/公里单位错误，也不应把 `live_data` 中可能存在的累计距离再逐点相加。

原解析把 distance 提前转成 Int，会丢失不足 1 米的小数。已改为 Double，持久化亦保留小数；UI 汇总后再格式化。此问题只能解释几米的舍入差，不能解释大幅距离差异。

`duration` 是有效运动毫秒数，与 `end_time - start_time` 不一定相同。列表原来只展示整数分钟和一天内的时刻，容易混淆不同日期及有效时长。现已显示日期、起止时间、有效运动时长的分秒，详情显示精确米数、步数、平均/最高心率和平均速度。

## 地图信息

- 8 条记录的 `source_type` 都为 **4**。已解包 Samsung Health `SportSharedConstants.WORKOUT_SOURCE_TYPE_AUTO = 4`，因此是自动识别运动。
- 逐条展开 `live_data` 后，字段全集为 cadence、distance、heart_rate、speed、start_time。
- 逐条展开 `live_data_internal` 后，字段全集为 elapsed_time、interval、segment、source_type、start_time。
- 本批记录无 latitude / longitude、`location_data`、`location_data_internal`；当前 RecordStore 也没有保存的 exercise.route 记录。
- 官方模型 `JExercise` 确有 location 字段，`SportDataConstants.ExerciseEx` 定义了 `location_data` / `location_data_internal`。`com.samsung.shealth.exercise.route` 是另一个保存路线的数据类型，不能仅凭它的名字就把它当成本次健走的 GPS 明细。

结论仅限本批实际收到的记录：**没有可绘制真实地图的定位点**。不能根据步数、速度或距离编造路线，也不能据此断言所有健走都不支持地图。界面明确显示“未收到地图轨迹”。以后若运动包实际带有定位资料，会区分“已收到定位点”和“收到但格式尚未解析”，避免错误地声称不存在数据。

## 复核

`ExerciseLogTest` 使用这批真机数值验证合计、逐条速度/有效时间关系、来源类型、无地图载体状态；另验证小数距离与秒级时长的持久化、位置资料存在时的状态区分。旧整数实现已在实际夹具的精度断言上失败，修复后通过。

## 已收到定位点时的数据链路（2026-11-16）

用户反馈截图显示“已收到定位点”，但详情没有地图。该状态与上面的无定位样本属于不同记录，
不能沿用“没有 GPS 数据”的结论。截图只证明界面状态，未取得这批记录的原始载荷，
尚未验证其时间顺序、分段、精度或坐标系；截图和实际健康载荷不放入 Git。

接入前的断点可以从源码确认，现已由下文的按需解析与地图实现补齐：

- `ExerciseLog` 原先从 `location_data`、`location_data_internal`、`location` 中选首个非空载体，
  `HealthJson.array` 支持 JSON 数组及 Base64/gzip 内容。
- 已展开数组并校验经纬度范围，排除 `(0, 0)` 后计入 `locationPointCount`；
  所以提示来自实际可解析的经纬度项，但不代表已通过轨迹连续性和坐标系验证。
- `Session` 仅保存载体存在性与点数，没有点序列交给地图绘制；现在仍保留轻量摘要，
  由 `ExerciseRoute` 供摘要、后台详情加载和导出共用解析规则。
- `HealthRecordStore.kt:17` 对运动模块不按天裁剪，仍受每模块 8000 条记录上限约束；
  `HealthRepository` 将原始记录持久化在 `health_records`，其中的定位负载可以再次解析。
  这允许恢复手机仍留存的历史，不能承诺恢复未同步、已删除或被容量裁剪的数据。

## 三星健康如何绘制

本次静态证据来自本机 Samsung Health 反编译源码，位于被忽略的
`research/decompiled/shealth/sources/`，只借鉴协议和行为，不复制厂商实现进应用。

| 环节 | 官方实现证据 |
| --- | --- |
| 定位载体 | `com/samsung/android/service/health/data/phd/handler/ExerciseHandlerHelper.java:387` 的 `getExerciseRoute` 读取 `location_data` BLOB |
| 点字段 | `com/samsung/android/app/shealth/sport/api/data/ExerciseLocationData.java:22` 声明 `start_time`、`latitude`、`longitude`、`altitude`、`accuracy`、`elapsed_time`、`segment`、`version`、`interval`、`source_type` |
| 底图 | `com/samsung/android/app/shealth/tracker/sport/workout/common/fragment/ExerciseWorkoutRouteMapFragment.java:49` 继承 Google Maps `SupportMapFragment` |
| 画线 | `defpackage/cab.java:144` 将经纬度点转换成 `LatLng` 和 `PolylineOptions`；`defpackage/jda.java:113` 调用 `GoogleMap.addPolyline` |
| 视野 | `defpackage/cab.java:175` 用 `LatLngBounds` 包含轨迹，再调用 `newLatLngBounds` |
| 分段着色 | `defpackage/e0b.java:524` 按强度区间合并相邻同色段并保留所有点，构造独立折线 |

已确认的主链是“定位序列 → 分段折线 → 底图叠加 → 自动适配视野”，并非由距离反推道路。
所查 AMap 路线文件详情 Activity 为空实现，不能据此推定所有中国区页面的地图方案。
`com/sec/maplib` 实际用于血压算法，与运动地图无关。

还有一个必须保留的条件：`ExerciseLocationData.java:122` 根据 Google 服务可用性、点的
`version` 和设备类型决定是否调用 `ks3.e`；`defpackage/ks3.java:664` 有中国区域坐标偏移公式，
`defpackage/lmt.java:80` 的服务可用性判断也包含中国区判断。
这证明存在有条件的坐标转换，不能把所有记录都直接当作 WGS84，也不能把 `version=2`
单独解释成一个对所有设备通用的坐标系标识。

## MapLibre 首版实现（2026-11-16，未发布）

已接入 **MapLibre Native Android 11.8.0 + OpenStreetMap Standard 栅格底图**，
无需 Google Play Services。MapLibre 是本机渲染器，底图由独立服务在线提供；
中国大陆的加载速度和道路对齐效果仍待用户实际网络与原始记录验收，首版不承诺服务可达性。

### 1. 按需解析与原始存储

- `ExerciseRoute` 共用于运动摘要、详情和导出，依次尝试短名/长名定位载体，优先选择
  含有效点的载体；前一载体不可解码或无有效点时继续检查后续载体，不拼接不同载体。
- `HealthRepository.exerciseRoute` 在后台从当前设备的最新整条运动修订解析点序列；
  页面只在展开详情时请求，随记录或仓库修订重新加载，取消旧请求并丢弃旧显示状态。
- 每个仓库独立拥有 SHA-256 内容缓存，最多 4 条且累计不超过 50,000 点；超限轨迹
  仍完整解析但不缓存。不新增轨迹数据库，不把点序列放进首页 `Session` 摘要或独立持久化。
- 点保留原始索引、经纬度及可选的时间、高程、精度、分段、版本、间隔和来源类型。
  无效或缺失值不补造；负高程、单轴零坐标与有效零精度/耗时保留。

### 2. 分段与坐标语义

- `source_continuity_v1` 按来源索引缺口、原始 `segment` 变化、`start_time` 或
  `elapsed_time` 回退断段，不重排点，不跨无效点连线；没有时间戳时保留来源顺序。
  首版不按长间隔或猜测速度过滤跳点，也不宣称能识别所有暂停。
- 路线使用单色与不同形状的起终点，一个点只显示标记。保留全部有效点，不做道路吸附，
  不从距离/速度反推路线，距离和有效时长继续使用运动汇总。
- 跨日期变更线的经度展开与 Web Mercator 极区纬度限制只作用于绘制副本，
  原始及导出坐标不变。坐标系始终标为未知，不根据 `version`、手机地区或兼容身份猜测
  WGS84/GCJ-02，不作地区偏移转换；界面明确提示可能与道路偏移。

### 3. 地图与详情排版

- 展开运动先显示 176dp 高的本地轨迹预览，底下依次放起终点图例、有效点/分段数量和
  必要说明；明确标注“无底图”，展开列表不会发起底图请求。
- 点击“查看地图”打开全屏地图，可拖动、缩放、查看全程；只有当前全屏视图创建
  `MapView`，随页面生命周期启动/暂停/销毁，关闭或重试时取消旧瓦片请求并释放连接。
- 加载、底图不可用、渲染失败分别处理；等待超时或瓦片失败提供重试，原生渲染失败
  回退 Canvas 轮廓。未收到载体、格式无法解析、无有效点及单点均有独立说明。
- 地图下方的距离与速度、心率、海拔变化分为三组卡片；窄屏或大字号使用单列，
  宽窗口可两列。原始运动时间/消耗、步数/划水次数/重复次数及例程子项保留。
- 开启 OSM 底图时始终显示可点击署名，说明服务方可获知浏览区域；轨迹在本机绘制，
  不通过静态地图 URL 上传完整点序列。应用提供版本化 User-Agent，保留服务端缓存头，
  无 `Cache-Control`/`Expires` 时提供 7 天缓存有效期；MapLibre 原生缓存消费这些响应头。
  关闭瓦片预取，不提供批量下载或离线地图包，HTTP 请求日志关闭。
- MapLibre 与 OkHttp 的固定版本许可证已随包加入，OSM 数据与瓦片政策记录在 `THIRD-PARTY.md`。

### 4. 健康导出 v4

- `HealthExportSnapshot` 已含当前设备所有留存原始运动记录，无需增加独立快照字段；
  手动小睡和本机睡眠分析缓存仍独立采集，留存策略不变。
- 新增 `workout_routes.json`，从全部留存原始记录解析，按 `record_id` 关联父运动，
  不受最多 40 条的显示窗口限制。保留模块、修订、载体、点序、分段算法及未知坐标系，
  原始定位负载仍完整留在 `source_records.json`。
- 同步 JSON Schema v4、manifest 的轨迹/点/段数量与留存覆盖说明、逐文件校验和、
  嵌入 README 和 [健康导出说明](HEALTH-EXPORT.md)。轨迹是父运动的明细表示，不能重复累计
  距离、时间或热量；未同步或已裁剪的原始历史无法恢复。

### 5. 验证与验收边界

合成 JVM 回归覆盖数组/压缩载体、载体选择、缺值/有效零、无效坐标、单点、断段、
时间回退、跨日期变更线、极区、12,020 点绘制数据及来源坐标不变；实际归档入口回归
覆盖较早留存历史、别名修订、状态、父运动关联、schema、manifest 与校验和。
新增 Compose 回归验证按展开加载与修订刷新，仅完成编译，未在设备执行。

本地完整门禁通过：Spotless、747 项 JVM（0 失败/错误/跳过）、Lint（0 错误、143 警告）、
Release 构建和 Android 测试源码编译；i18n 1433 项双语资源与 91 项脚本回归通过。
最终未签名 APK 的既有资源检查通过，MapLibre 四组 ABI 与两份新增许可证均已核对。

本轮没有可用 Android 设备，未验收地图实际渲染、拖动缩放、断网重试、明暗主题/大字号、
系统保存/分享或设备重启持久化，也未回放用户原始轨迹。国内底图性能和坐标对齐留待实测；
Watch 4～6 勿扰执行结果与地图功能的本地测试独立记录。

官方资料：

- [MapLibre Native Android 文档](https://maplibre.org/maplibre-native/docs/book/platforms/android/)
- [OSM Standard 瓦片使用政策](https://operations.osmfoundation.org/policies/tiles/)
