# iOS 适配与首次配对可行性调研

调研日期：2026-10-30。基于 Apple 官方开发者文档、Samsung / Google 官方支持说明、开源项目源码与现有逆向资料。

---

## 核心结论

1. **iOS 官方生态没有可用的 Watch7 初始化配对通路。**
   - 三星官方在 Wear OS 3 之后（Watch4 及更新型号）明确不再支持 iOS，必须使用 Android 手机。App Store 上的「Samsung Galaxy Watch (Gear S)」自 2022 年后未再更新，仅支持 Tizen 时代的手表（Watch3 及更早）。
   - Google 的「Wear OS by Google」iOS 客户端仅支持 Wear OS 2.x；官方文档明确声明 Wear OS 3+ 手表与该 iOS 应用不兼容。
   - 所有能连接 iPhone 的商业产品（如 Merge、Lynio）与开源项目（如 `wear-ios-bridge`、`WearBridge`），**无一例外都需要先借用一台 Android 手机完成手表的开机激活、登录 Google 账号，并在手表端安装配合使用的独立 App 后**，才能通过 BLE 连回 iPhone。没有能够在出厂状态下完全脱离 Android 完成初始化的先例。

2. **不能通过纯 iOS 应用自研逆向打通完整的出厂首次配对。**
   - **蓝牙 API 封锁**：当前手表的标准通信使用的是经典蓝牙 **RFCOMM (SPP)** 接口（UUID `5e8945b0-...`）。iOS 的公共 API（`CoreBluetooth`）仅开放 BLE GATT 与 LE L2CAP，**没有向普通开发者开放任意经典蓝牙 RFCOMM Socket 接口**；`ExternalAccessory` 仅限通过 MFi 认证的硬件；可用的 `IOBluetoothRFCOMMChannel` 仅存在于 macOS。
   - **设备激活与身份授权**：手表的首次激活与初始化涉及 GMS 伴侣协议、证书链校验、FRP 锁及 Google 账号绑定。这些流程由手表内部的系统级组件处理，无法在没有 GMS 的 iOS 端被纯应用模拟。

3. **可行的 iOS 方案：辅助激活 + 自建 Watch 独立 App。**
   - 必须通过一次性 Android 辅助完成激活并侧载手表端 App；
   - 随后在手表端运行自研伴侣，通过 **BLE GATT 与 iPhone 通信**，并通过 **ANCS (Apple Notification Center Service)** 接收 iPhone 推送；
   - 无法使用原有的三星健康监测器（ECG / 血压）私有通道，也无法在 iOS 端实现官方级的无感知直连。

---

## 1. 详细调查结果

### 1.1 官方生态与现存第三方应用调研

| 对象 | iOS 状态 | 详细事实与来源 |
|---|---|---|
| **Samsung 官方** | 明确不支持 | 三星官方支持说明（`ANS10004668`、`ANS10003406`）明确标明：Wear OS 手表不兼容 iOS，必须使用 Android 11+ 设备配合 Galaxy Wearable 初始设置。App Store 客户端 `id1117310635` 上次更新停留在 2022-02-18，仅覆盖 Tizen 旧手表。 |
| **Google Wear OS 官方** | 明确不支持 | Google 官方说明指出 Wear OS 3+ 不再支持 iOS 端 Wear OS 应用。 |
| **开源项目 `wear-ios-bridge`** | 需要 Android 辅助 | [hnkabraham/wear-ios-bridge](https://github.com/hnkabraham/wear-ios-bridge)（MIT，Swift + Kotlin）：文档明确声明手表必须先完成官方开机设置并能够安装伴侣 APK。通信走自建的 BLE GATT 特征与 ANCS，不模拟 Google Play Services。 |
| **商业应用 (Merge 等)** | 需要 Android 辅助 | 实际帮助文档明确要求先找一台 Android 手机完成 Galaxy Wearable 配对和 Play Store 登录，并在手表上安装应用后才能断开 Android 并转连 iPhone。其宣称的“无线安装”多指针对已开机设备通过 Wi-Fi ADB 或应用商店下载，无法脱离先期设置。 |

### 1.2 iOS 蓝牙能力与协议层鸿沟

| 协议层 | Watch7 原生要求 | iOS 开放能力 | 结论 |
|---|---|---|---|
| **底层传输** | 经典蓝牙 (BR/EDR) RFCOMM SCN 8 (`5e8945b0-...`) | `CoreBluetooth` 仅支持 BLE GATT 与 LE L2CAP Channel；WWDC19 增加的 BR/EDR 仅允许透明访问标准 GATT，不提供 RFCOMM Socket。`ExternalAccessory` 仅限 MFi。 | **直接阻断**：iOS 应用无法直接连接该 RFCOMM 通道。 |
| **GATT 换机流程** | `eed6d5cc-...` 服务下的 TLV 明文交换 | `CoreBluetooth` 可以作为 Central 发现并读写 Characteristic。 | 仅能用于已开机手表的局部的换机状态查询，无法替代完整初始化。 |
| **节点信任体系** | 依赖 Google Wear 的 `localNode` 登记和 WCS 会话认证 | iOS 无对应系统组件或登记接口。 | 无法在未经授权时凭空注册合法的受信任手机节点。 |
| **通知桥接** | 原生使用 Google DataItem 协议 | iOS 仅支持外设作为 Client 订阅系统的 **ANCS (7905F431-...)**。 | 必须由手表端运行 App 主动订阅 ANCS，无法通过手机直接向手表原生推送通道写入。 |
| **心电与血压** | 依托 Samsung Health Monitor 私有握手与 Channel | 无法在非三星手机/iOS 运行官方监测器流程；HealthKit 不允许第三方直接写入 Apple Watch 专用心电波形。 | **不可用**。 |

---

## 2. 如果一定要在 iOS 上做，可行的替代技术路线

如果未来需要服务 iOS 用户，唯一的工程实现路径是放弃复用官方 WCS 传输通道，改为自建专用通信协议：

```
┌────────────────┐      BLE GATT (自定义私有协议)      ┌─────────────────────────┐
│                │ <────────────────────────────────> │                         │
│  iOS Swift App │                                    │  Watch7 独立伴侣 App     │
│  (Central)     │ ─── ANCS (系统通知订阅，可选) ───> │  (需预先侧载或商店安装)  │
└────────────────┘                                    └─────────────────────────┘
```

1. **先期准备**：用户需先在 Android 设备上开机并配对一次，开启手表的开发者模式或通过手表端应用商店安装自研的 Wear OS 伴侣程序。
2. **连接建立**：手表端伴侣作为 BLE Peripheral 广播，iOS App 作为 Central 连接；或者手表端作为 Central 订阅 iOS 系统的 ANCS 服务以接收系统通知。
3. **数据同步**：步数、心率等基础生理数据由手表端直接通过 Android 的 Health Services API 读取，再经自定义 BLE 数据包发给 iOS App 写入 HealthKit。
4. **功能损失**：官方表盘设置、三星原装表盘切换、官方心电图与血压校准/测量、以及系统级设置调节均无法通过此通道生效。

**综合建议**：
如果目标是让出厂重置的手表“开箱即用直接连 iPhone”，目前在技术和系统权限上无法闭环；如果是为已有手表的 iPhone 用户提供基础数据同步和通知，可以通过“Android 一次性初始化 + 独立手表 App”的轻量桥接方案实现。
