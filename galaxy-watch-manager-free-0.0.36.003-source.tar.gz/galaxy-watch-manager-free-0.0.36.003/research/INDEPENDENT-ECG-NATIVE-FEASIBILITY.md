# 独立 ECG 应用与 SHM native：采集通路可行性

> **已归档（2026-10-30）**：独立传感器路线已放弃，采集与 native 探针模块、手机实验室入口已移除。本文保留上游源码与厂商库的历史研究，不作为产品实现计划。当前测量与校准继续使用官方流程，见 [Health Monitor 验收记录](../docs/HEALTH-MONITOR-INVESTIGATION.md)。

研究日期：2026-10-29；固定上游提交 [`5d0fb143c092622d4509655f311c26f76f66c1a1`](https://github.com/LibreStatic/LibreWrist/commit/5d0fb143c092622d4509655f311c26f76f66c1a1)，已核对克隆 HEAD。上下文见[既有研究](./LIBREWRIST-REVIEW.md)。采集部分静态阅读源码、catalogue及一手项目文档；native部分复核既有REA函数证据，并以只读脚本解析现有SO的ELF元数据。未执行第三方项目脚本、厂商native、构建、安装或设备命令；没有修改应用代码。

## 1. 结论与证据等级

**LibreWrist 绕开的是改签 SHM 原 ECG 特权采集入口，改用 Health Platform ECG tracker；没有授予普通应用 Samsung `SSENSOR`，也没有在客户端伪造 Samsung 包名或签名。**catalogue 把 sensor27 的 availability/feature 强制 true，把 register/unregister 重定向到自己的 adapter；adapter 再把 tracker 数据包装成 SHM 消费的 Sem event。[实际 hook](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/catalogue/catalogue.json#L843-L947)、[adapter 契约](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/watch-mod/src/shminterop/ecg/EcgAdapter.java#L21-L37)。

**独立包名、自签名 watch app 采集 ECG 波形有可实现的源码基础；本次尚不能宣布“任意独立包已证明可用”。**客户端传自身 `context.getPackageName()`，不携带 Samsung 签名或 SDK token。上游作者报告改签 SHM 在 SM-R920 上完成过完整 ECG 分类和同步。开发模式跳过服务端 package/signature policy 的细节，则来自作者对 Health Platform APK 的静态分析文档，仓库客户端源码不包含服务实现。本次没有直接复核服务源码，更没有做独立包/签名对照实验。[真实包名及请求](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/watch-mod/src/shminterop/hsdk/HealthClient.java#L55-L62)、[请求使用自身身份](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/watch-mod/src/shminterop/hsdk/HealthClient.java#L118-L145)、[作者设备验证](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/docs/health-sdk.md#L30-L32)、[服务研究的来源声明](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/docs/health-tracking-protocol.md#L11-L14)。

采样、把采样送入 SHM 算法、得到与官方等价的分类/报告，是三个独立验收项。独立采集可以先验证，不必等 native SO 独立化；native 静态接口、ABI 与依赖结果见第5节，独立宿主运行仍待验证。

## 2. 权限链：普通权限与 bypass 不是一回事

| 层次 | 精确行为 | 证据边界 |
|---|---|---|
| 原 SemSensorManager / sem_sensor | 改签应用原 ECG 被 SSENSOR 拒绝；换入口而非获取特权 | adapter 注释与实际 catalogue hook；没有 SSENSOR grant |
| Health Platform runtime permission | 注册和每批数据交付检查实际 Binder caller pid/uid 权限 | 作者服务分析：OS 与 app target 同时 >=36 用 Samsung `READ_ADDITIONAL_HEALTH_DATA`，否则 `BODY_SENSORS` |
| Health Platform SDK policy | dev off：blocklist、appId 对应服务器 policy、签名 credential、有效期、`ecg` / SDK `T` / access type1 | 作者服务分析；dev on 跳过这一层，保留 runtime permission |
| SHM event hidden API | 构造 `SemEcgSensorEvent` 受 ART 限制 | 完整 SHM adapter 需要 prefix exemption；纯 Binder 波形 app 不构造 Sem event，无源码依据要求也设置它 |

来源：[权限与 policy 规则](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/docs/health-tracking-protocol.md#L75-L118)、[hidden API 失败点](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/watch-mod/src/shminterop/ecg/EcgAdapter.java#L226-L241)、[全局 exemption](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/docs/patches.md#L295-L325)。

用户以前独立 app 被拒绝，需要原 API 与完整错误才能归因：原 sensor 路径可能是 SSENSOR；Health Platform callback 0 是 runtime `PERMISSION_ERROR`，1 是 `SDK_POLICY_ERROR`。开发模式不能解决缺失 runtime grant。仅有“ECG permission denied”不能证明独立 app 不可行。[错误码及恢复行为](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/docs/health-tracking-protocol.md#L437-L451)。

### 2.1 Connect / create / register

- `HealthClient.connect()` 用 action `com.samsung.android.service.health.wear.sts.ACTION_SERVICE`、package `com.samsung.android.service.health`、`BIND_AUTO_CREATE`，处理 false、SecurityException、null binding、binding died、20秒超时。连上不代表授权。[源码](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/watch-mod/src/shminterop/hsdk/HealthClient.java#L64-L85)。
- `EcgTracker.doArm()` 顺序 code5 查询 capability 包含 `ECG`、code1 create、code2 set listener；重连重新 arm，stop 先 code3 unset 再 unbind。[源码](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/watch-mod/src/shminterop/hsdk/EcgTracker.java#L37-L99)。
- Parcel 写 interface token、自身 appId、`ECG`、null profile/null exerciseType；直接 `IBinder.transact(...,0)` 再 readException，无 vendor SDK 或 native SDK 握手。[payload](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/watch-mod/src/shminterop/hsdk/ServiceProtocol.java#L85-L113)、[transact](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/watch-mod/src/shminterop/hsdk/HealthClient.java#L168-L182)。
- 作者记录服务 exported 且 bind 无 permission，仍需 manifest package visibility query；code1 不检查权限，code2 同步检查 runtime、异步检查 policy。code2 返回仅是接受处理。客户端随即 `onArmed()`，此时可能已嵌套收到 permission0，或 policy1 尚未返回。首批真实数据才是成功依据。[服务入口记录](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/docs/health-tracking-protocol.md#L37-L79)、[create/register 时序](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/docs/health-tracking-protocol.md#L191-L215)。

### 2.2 Developer mode 与 caller 身份

客户端源码直接证明传真实自身包名、未修改 Binder UID、无签名冒充；**没有证明“服务端已普遍绕过 package/signature”**。作者文档称服务 private preference `common_developer_mode` 每次注册读取，on 时跳过整个 policy，不跳过 permission。dev off 时 server path 为 `sdp/policies?serviceId=<appId>`，检查包签名等。新包/新key在 dev on 可用是有文档依据的待验证推断。[policy 分支记录](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/docs/health-tracking-protocol.md#L95-L118)、[开关记录](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/docs/health-tracking-protocol.md#L496-L519)。

activation 的 Kotlin 实现只是通过 watch ADB 打开 settings，读 dumpsys 视图，未显示 dev subtitle 时点击 title，再读回；不是直接写私有 preference，也不能单凭 UI 自动化证明服务分支。作者称手动10连击 title 切换，当前设备显示 `[Dev mode]`。协议仍把“改签 SHM 在 dev off 是否 policy失败、原包是否有policy”列待测。[UI 实现](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/patcher-app/app/src/main/kotlin/io/openshm/patcher/device/HealthPlatformDevMode.kt#L7-L74)、[未决项](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/docs/health-tracking-protocol.md#L523-L548)。

## 3. Catalogue activation grants

mandatory manifest query 加入 `com.samsung.android.service.health`。[query patch](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/catalogue/catalogue.json#L731-L743)。完整 `shm-watch` grants 如下，不能全部等同 ECG 必需条件：

| grant | 整套 SHM 用途 / 独立前台 ECG 判断 |
|---|---|
| `BODY_SENSORS` | 旧 OS/target ECG 分支需要 |
| `BODY_SENSORS_BACKGROUND` | 先有 BODY_SENSORS；不能推定前台采集必须 |
| `health.READ_HEART_RATE`、`health.READ_OXYGEN_SATURATION` | 完整健康功能；协议未列为 ECG 鉴权条件 |
| `ACTIVITY_RECOGNITION` | 完整 SHM；不是已证明的 ECG Binder 条件 |
| `BLUETOOTH_CONNECT`、`POST_NOTIFICATIONS` | 通信/通知；按产品行为决定 |
| Samsung `READ_ADDITIONAL_HEALTH_DATA` optional | OS/target同时>=36的ECG需要；optional兼容旧系统 unknown permission，不表示新系统可不授予 |
| appop `SCHEDULE_EXACT_ALARM=allow` | SHM闹钟，不等于采集权限 |
| global `hidden_api_blacklist_exemptions += Lcom/samsung/android/hardware/sensormanager/` | adapter构造Sem event；对全设备所有app生效、重启进程生效，纯Binder采集没有该依赖的源码依据 |
| deviceIdleWhitelist | IHRN后台，不等于前台ECG条件 |
| appop `SYSTEM_ALERT_WINDOW=allow` | IHRN alert后台启动，不等于ECG条件 |

来源：[完整 grants](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/catalogue/catalogue.json#L3830-L3894)、[exemption 范围/撤销](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/docs/patches.md#L295-L325)。

最小独立采集依赖推导：具有 ECG capability 的手表 Health Platform、manifest query、相应 runtime grant、developer mode 或有效 policy、自有 Binder client与生命周期。代码没有要求原始采集携带 SHM APK/SO、手机 GMS 或 LibreWrist bridge；算法和同步是另一层。

## 4. 数据、采样、滤波与质量

wire 每个 point 六个值：pos0 integer=offset-removed ADC、float=mV；pos1 PPG green；pos2 lead；pos3 sequence；pos4/5 thresholds。lead/sequence/threshold只在index0有效，其余点通常-1；PPG最多index0/5有效。[wire layout](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/docs/health-tracking-protocol.md#L300-L345)。

**当前 Java parser 不是无损 raw recorder**：最终只保存 timestamp/mV、批级lead/sequence/mV thresholds；丢ADC integer和PPG。`-9999.0f`转NaN。作者记录 legacy path可能只有ADC，mV恒为-9999；当前model没有ADC fallback，不能承诺旧平台可直接用。独立验证应保存原字段及unavailable状态。[parser](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/watch-mod/src/shminterop/hsdk/ServiceProtocol.java#L278-L316)、[sample model](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/watch-mod/src/shminterop/hsdk/EcgSample.java#L3-L16)、[legacy语义](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/docs/health-tracking-protocol.md#L330-L345)。

整批timestamp相同，为服务收到事件时wall-clock毫秒，含交付抖动，不是逐点采样时刻。服务未设置sample rate，adapter假设500Hz；上游仍将rate/批N列待测，不能直接由timestamp或每批10点推定频率。[timing](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/docs/health-tracking-protocol.md#L347-L363)、[rate待测](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/docs/health-tracking-protocol.md#L523-L538)。

adapter 的 SHM compatibility 转换：

- `round(0x200000 + mv / 2.6614e-4)`量化；缺失mV替换ADC_CENTER。换回mV后执行 `ema += 0.001*(v-ema)`、`f=v-ema`，再量化回ADC。500Hz下时间常数约2秒；不等于已证明官方前端等价。[转换/EMA](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/watch-mod/src/shminterop/ecg/EcgAdapter.java#L156-L200)。
- 注释称首批均值设置electrode baseline，但当前delivery没有执行该逻辑；实际raw[25/26]使用初始化的中心±5mV，未使用收到的threshold。应以代码为准。[fields/comment](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/watch-mod/src/shminterop/ecg/EcgAdapter.java#L48-L60)、[实际push](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/watch-mod/src/shminterop/ecg/EcgAdapter.java#L204-L223)。
- lead只有5算off，其他值包括absent=-1归0；0→5须连续4批，5→0立即。约80ms依赖10点/批、500Hz。此处改变contact语义。[normalization](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/watch-mod/src/shminterop/ecg/EcgAdapter.java#L167-L175)、[debounce](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/watch-mod/src/shminterop/ecg/LeadDebouncer.java#L19-L61)。
- 每10点组成int[27]：raw[4..13]波形，raw[14] lead<<16，raw[15] count<<8|自生成8位sequence，raw[25/26]固定阈值。非10倍数batch尾点直接丢弃，无跨批余数缓存；输入timestamp/sequence不原样保留。[emit/push](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/watch-mod/src/shminterop/ecg/EcgAdapter.java#L204-L233)。
- 真实数据前每100ms发零波形lead5 synthetic keepalive维持watchdog；拿不到Context或连接失败仍可start=true。首批真实batch后keepalive停止。不能把占位event、armed、start=true当实际采集成功。[start](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/watch-mod/src/shminterop/ecg/EcgAdapter.java#L80-L107)、[keepalive](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/watch-mod/src/shminterop/ecg/EcgAdapter.java#L244-L267)。

lead-off、mV缺失、阈值、sequence/timing仅是质量线索，不是验证过的全局质量分数或诊断结果。BeatMonitor和统计日志也不等于SHM分类。固定提交仍报告ECG失败/心率跳变。[Known issues](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/README.md#L461-L469)。协议327–328行仍说adapter取最后一点lead，当前parser/adapter实际已取index0/batch，此处以代码为准。

## 5. SHM native 独立复用：本轮补充

本节基于本地手表 SHM **1.5.1.022** 的反编译 Java、既有 REA/Ghidra 函数 Evidence 和本轮只读 ELF 元数据解析；未在独立 APK 中加载或执行厂商 native。本次复用了已有函数分析，没有重新启动 native 分析会话。REA 的 `inspect_binary_layout` 在本机返回只支持 Linux x64 的 provider 限制，故 ELF 架构与 DT_NEEDED 由有界 Python `struct` 解析 ELF32 header、PT_LOAD、PT_DYNAMIC 得到，明确不是 REA Evidence 或运行时结果。

### 5.1 结论

**复用原有 ECG/BP SO 是有明确 JNI 与输入接口依据的候选路线。**它可以避免从零重写全部算法，但传感器授权、输入等价性和独立 native 宿主是三项不同工作。SO 不授予 ECG 特权，也不证明 Health Platform 会放行新包。当前未验证独立 APK 的加载、初始化、测量或分类结果等价。

原始证据及完整签名见[私有 native 研究](../private/shm-investigation/NATIVE-REUSE-FEASIBILITY.md#L14-L90)。厂商 SO 保留在原有私有研究目录，没有复制到公开源代码或发布产物。

### 5.2 ECG 算法入口与 JNI 兼容层

v2 加载 `shm-ecg-2.0`，有 annotator 初始化、逐段处理、在线/离线滤波、强制报告、最终心律分类与 reset/free。关键签名如下；嵌套类型属于原 v2 命名空间：

```java
private native long nativeAnnotator_Init(int i, int i2, int i3, FilterMode filterMode, int i4, int i5, int i6, int i7, int i8, int i9, int i10);
private native Report nativeAnnotator_Process(long j, EcgRecord ecgRecord, ProcessingMode processingMode, int i);
public native ClassificationType getFinalClassificationResult();
```

来源：[v2 声明](./decompiled/watch-shealthmonitor/sources/com/samsung/android/shealthmonitor/ecg/library/v2/EcgLibrary.java#L326-L379)、[初始化与报告周期](./decompiled/watch-shealthmonitor/sources/com/samsung/android/shealthmonitor/ecg/library/v2/EcgLibrary.java#L382-L436)。本地反编译 manifest [版本](./decompiled/watch-shealthmonitor/resources/AndroidManifest.xml#L3-L4)为 1.5.1.022，与 LibreWrist 当前 watch 输入版本一致；不能将 v1/v2 的 wrapper 和 SO 混搭。

JNI 硬编码 `com/samsung/android/shealthmonitor/ecg/library/data/EcgRecord`、嵌套 EcgSample、`samples`、`timeStamp`、`value`，以及 v2 FilterMode/ProcessingMode 的 `getValue()`、Report 及其嵌套类型。只更改 Java 包名后复制 SO 会破坏此协议。**最小宿主可以尝试使用自己的 applicationId，同时保留内部兼容类的原 Java 全限定名与成员，并保护其免于 R8 改名。**这属于待运行验证的设计，不要求冒用原应用的安装包身份；也不证明整个 SO 没有额外身份检查。

Native 证据：[init 伪代码](../private/shm-investigation/ecg-native/ecg-annotator-init.c#L14-L25)，Evidence `ev_c4c26b003825ec25f72dee56ffda631217da1e780ad5c0b941f6b10c520695c7`；[process 伪代码](../private/shm-investigation/ecg-native/ecg-annotator-process.c#L81-L153)，Evidence `ev_88b3d0a67a8685b111dee1b617fa53c5c2149951adb7a3f7897b757da4503f7f`。本轮 REA 投影 `ev_17e597398e05f3b788e69c99b110cb7f4e959d61ea6daf9001a1d913945936c0` 枚举 process 的13个已记录 callees，其中有 external `Annotator_Process`；该投影不能证明所有间接调用或全库行为。

输入不是随意 double 数组：原 Java 先将 ADC 转换为 `((raw - 2097152) * 2.6614E-4 * wristSign)`，有分段记录、接触控制、序号及15000点缓冲；离线一条 wrapper 固定15000点输出，而另一条过滤入口传500参数。core 初始化另有250，内部采样转换仍未完全追踪。**不能从“500Hz”注释推导任意波形可直接喂入。**先保留真实原始数据、时间基准和质量标志，再单独实现输入适配。[输入转换](./decompiled/watch-shealthmonitor/sources/defpackage/pl.java#L44)、[离线 wrapper](../private/shm-investigation/ecg-native/ecg-offline-wrapper.c#L8)、[native 输入边界研究](../private/shm-investigation/NATIVE-REUSE-FEASIBILITY.md#L51-L56)。

### 5.3 血压算法与校准

```java
public native BpLibraryResult.MultiCalResult averageMcal(short[][] sArr, double[][] dArr);
public native BpLibraryResult.EstimateResult calBpProc(int[] iArr, short s);
public native BpLibraryResult.EstimateResult estBpProc(int[] iArr, short s, short[] sArr, double[] dArr);
public native void reset();
```

来源：[BP wrapper](./decompiled/watch-shealthmonitor/sources/com/samsung/android/shealthmonitor/bp/library/BpLibrary.java#L6-L43)。原测量每20个 PPG 整数样本调用一次，带 short[3] bpCal 与 double[16] featCal；20是块大小。Java 调度每10ms消费一点，native中有100→250插值的依据，但独立采集时钟与光学信号等价仍需实测。JNI 构造 `BpLibraryResult$EstimateResult` 的 `(SISSS)V`，并调用外部 `est_bp_proc`。Evidence `ev_1af44fb2bdb23f9da328a566e88ce28adb878683efa480793aed251db2cfaa50`，详见[BP 研究](../private/shm-investigation/NATIVE-REUSE-FEASIBILITY.md#L60-L75)。

这比“只有最终血压结果解析”更进一步：已有校准特征提取、合并及估计入口，可以研究在我们自己的界面中组织三轮袖带流程。**SO 提供计算入口，不替代真实袖带参考值与个人校准。**必须复原参考值如何进入合并、特征如何保存、校准有效期及失败状态；原库有全局状态，先按单会话串行使用并 reset。Health Platform PPG 的幅度、AGC、滤波与原 Sem green_raw 是否等价未验证，不能直接套用旧校准。

### 5.4 本轮确认的 ABI 与链接依赖

对现有13个 ECG/BP SO 逐个检查：均为 ELF32 little-endian、e_machine=40（ARM）。这只覆盖现有样本，不能推出其他固件没有 ARM64 版本。结果、SHA-256与方法保存在[依赖清单](../private/shm-investigation/native-elf-dependencies.json)。

| 主库 | DT_NEEDED 中的配套算法库 | 进程条件 |
|---|---|---|
| ECG v2 `libshm-ecg-2.0.so` | `libcalctruefs_v2_0.so`、`liboffline_filter_v2_0.so`、`libfinalrhythmclassification_v2_0_1.so`、`libsamsung_ecgannotator_v2_0.so` | 兼容 ARM32 的 Android 进程 |
| ECG v1 `libshm-ecg.so` | `libcalctruefs.so`、`liboffline_filter.so`、`libfinalrhythmclassification.so`、`libsamsung_ecgannotator.so` | 兼容 ARM32 的 Android 进程 |
| BP `libshm-bp.so` | `libbp_v3_06_10.so` | 兼容 ARM32 的 Android 进程 |

这些主库还依赖 Android 的 `liblog.so`、`libm.so`、`libdl.so`、`libc.so`；配套库的完整直接依赖见清单。**32位SO不能直接装入64位进程。**把计算放在手机并不自动解决兼容性，手机也必须支持对应进程 ABI；仅64位设备需另找兼容算法构建或另一条实现路线。

DT_NEEDED 不覆盖运行时 dlopen、全部资产/模型、签名/设备检查，也不证明只复制表中库就可运行。所见 JNI 入口没有 Context/AssetManager/token 参数，是有利线索；全库初始化及间接调用尚未穷尽，不能宣称没有这些依赖。

### 5.5 两个独立验证闭环（历史设计）

1. **采集验证**：独立包名/签名，直接 Binder ECG，无SHM native；保存完整原字段、单调接收时钟、批序号和缺失状态，确认真实连续数据。服务连接、onArmed 和 synthetic keepalive 都不算通过。
2. **算法验证**：在匹配ABI的最小Android宿主中放置完整依赖与JNI兼容层，先读版本/初始化/释放，再回放同一条已知官方输入，与原流程逐阶段比较。ECG比较滤波、HR、质量及分类；BP比较特征、校准合并和估计。之后才连接新采集器，以免把权限问题、标度错误和算法装载错误混在一起。

上述两条验证闭环属于此前独立路线的探索设想。随着独立路线彻底放弃，相关实验模块已全量移除，本项目不将 SHM 测量迁移为自研手表 App。产品维持接收 watch 官方 SHM 测量结果与校准状态桥接，见[本地调查](../docs/HEALTH-MONITOR-INVESTIGATION.md#L92-L126)及[解码器](../app/src/main/java/dev/ricky/galaxywatchmanagerfree/feature/monitor/EcgLog.kt#L97-L108)。复用LibreWrist自有代码需保留[MIT notice](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/LICENSE#L1-L21)，不等于获得官方APK/SO权利。

## 6. 历史设计的实验矩阵（已废弃/不再执行）

| 实验 | 控制/记录 | 通过标准与目的 |
|---|---|---|
| 复原旧拒绝 | 原API、完整异常/回调码、manifest/grants、OS/target/服务版本 | 区分SSENSOR、permission0、policy1、bind失败 |
| 最小独立app | 全新package/key、自身appId，无SHM/native/vendorSDK；query+runtime grant，前台 | 首批连续非synthetic真实样本；armed不算 |
| dev mode × grant 2×2 | 同一app，dev off/on、grant absent/present，每次重新注册 | dev on无grant仍失败；dev on有grant能否出数据；dev off有grant实测policy结果，不预判必败 |
| package/key对照 | 至少两个新包，同包不同key干净安装；记录网络/policy缓存 | 排除原SHM身份、特殊key或缓存policy特例；验证泛化 |
| 字段/时基 | 保存完整六字段ADC/mV/sentinel、N、批timestamp、接收monotonic、sequence | parsed/legacy、真实rate/N、丢包/重复/顺序、wallclock跳变；不可静默丢尾点 |
| contact/质量 | 静止/运动、接触/抬指/短断触，同时存未归一lead/原mV | 确认0/5与其他状态，比较EMA/debounce改变，缺失不算接触 |
| 生命周期/平台矩阵 | unset/unbind、撤销恢复权限、进程/服务重启、冷启离线、stockSHM并发 | rearm、无null-bind死局/资源遗留、无传感器冲突；验证目标版本 |
| native接入 | 最小宿主、初始化依赖、固定离线输入与官方pipeline对照 | 分别验证加载/API、单位时基、结果；采集成功不能替代算法验证 |

**历史判定与现状**：上述设计属于独立路线探索期间的实验构想。随着用户决定放弃独立传感器自研路线，这些实验已不再执行，相关代码及模块已彻底移除。产品功能聚焦于稳定的官方 Samsung Health 心率同步与官方 SHM ECG/血压桥接。

## 7. 本地原始来源

- [HealthClient](/tmp/librewrist-review-20261029/watch-mod/src/shminterop/hsdk/HealthClient.java#L60-L178)、[ServiceProtocol](/tmp/librewrist-review-20261029/watch-mod/src/shminterop/hsdk/ServiceProtocol.java#L278-L316)、[EcgTracker](/tmp/librewrist-review-20261029/watch-mod/src/shminterop/hsdk/EcgTracker.java#L79-L99)。
- [EcgAdapter](/tmp/librewrist-review-20261029/watch-mod/src/shminterop/ecg/EcgAdapter.java#L156-L267)、[LeadDebouncer](/tmp/librewrist-review-20261029/watch-mod/src/shminterop/ecg/LeadDebouncer.java#L19-L61)、[catalogue](/tmp/librewrist-review-20261029/catalogue/catalogue.json#L3830-L3894)。
- [协议与来源声明](/tmp/librewrist-review-20261029/docs/health-tracking-protocol.md#L11-L14)、[dev-mode UI实现](/tmp/librewrist-review-20261029/patcher-app/app/src/main/kotlin/io/openshm/patcher/device/HealthPlatformDevMode.kt#L57-L74)。
