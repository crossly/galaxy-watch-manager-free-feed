# 今日步数缺口调查（2026-10-27，已完成真机对齐）

## 已复现的用户问题

同一时段用户读取手表为 **4269 步**，手机 App 为 **3270 步**，缺口 **999 步**。
不能把手机的区间累计值当成已经核实的全天总数；本报告没有通过手动加上 999 来修正数据。

手机缓存、现有日志、诊断原始报文的本地快照位于 `private/step-investigation/`（不入库）。
调查保留了原来的健康缓存，不清空 App 数据、不改变配对身份。

## 已确定并修复的代码缺陷

`HealthStepParser.accumulate` 原来只持久化 UUID 集合：一条计步区间记录第一次到达后，
同一 UUID 的任何后续修订都会被跳过。

复现命令：

```sh
./gradlew testDebugUnitTest --tests '*HealthStepRevisionTest'
```

修复前，合成的两包输入（同一 UUID，count 10 → 25，update_time 递增）失败：
`expected:<25> but was:<10>`。

修复后在实际 Repository 调用处传入并持久化 `steps_records`：按 UUID 保存上一次的 count / update_time，
收到新修订时应用差额；过期修订不覆盖新值；重复修订不再重复计入；支持向下修订。
同日的状态会跨重启恢复，跨日清空；被汇总覆盖的区间不重复加到汇总上。

迁移旧缓存时，UUID 集合没有对应 count，无法反推出旧计入值。对这种条目只记录首次重新看到的
count 作为未来修订的基线，保留旧总数，避免把整条记录再次加上去。**这不能恢复已丢失的 999 步。**

测试共 7 条新增回归，全套 151 条通过。尚不能证明 UUID 修订是本次全部缺口的来源。

## REA 静态证据

目标是手机端官方 Samsung Health APK，**不是手表端 APK**：

- APK SHA-256：`88b0359eaaea6061466df4fdb15754ca8408caf68e1eb796ef58b24374efe312`
- 引擎：REA 6.4.0 / JADX headless 0.7.1
- 当前 MCP 实例缺少 `REA_JADX_MCP_JAR`，改用已安装 REA CLI，显式指定本机现成引擎；未改客户端配置。

| Evidence ID | 方法 | 观察 |
|---|---|---|
| `ev_7a139a9584db80858b5088684b81a89d5fbcb901a60b438e115cf62cf848b77b` | `WearableDeviceSyncTestActivity.E1()` | 官方测试请求包含 `REQUEST_DATA`、`device_type=0`、`last_sync_time=0`，没有 start/end/is_last_chunk |
| `ev_8bb4f073bcea9393e67a2b136fc145bb1fe98ffcfd740b826fcfa2cf6c119316` | `wearable.sync.m.b()` | 手机端解析 REQUEST_DATA/SYNC_DATA 的 last_sync_time；0 会设置首次同步标志并调用重置逻辑 |
| `ev_71a3144a55042f6c2baa4d3969ac52914b35bd7e9cd1293a640ec3e8acaeac68` | `wearable.sync.m.h()` | 官方发送端按数据清单/标记表查询，再构造同步数据 |
| `ev_4ff120ef777734d1fe109b7b6acb207e289940ffe4a36b3e6b123d31c374c8cb` | `wearable.sync.m.handleMessage()` | Java 反编译失败后返回 smali；可见 REQUEST_DATA 的 SUCCESS 应答与后续调度 |
| `ev_8ec08b4f146c2593ebe68d7c7c855f0208457ef4a7facc10188798a9c14b197c` | `defpackage.zfb.a()` | 官方导出器构造 `export_watch_db` 请求 |

这些是手机端的静态观察，不能当成手表端代码相同或手表一定执行相同重置流程的证明。
完整 REA JSON 存放在上述本机私有快照目录中。

## 真机实验（手机 RFCOMM 可用）

1. `request_module_list` 分别为 `PEDOMETER`、`PEDOMETER_RECOMMENDATION`、
   `WEARABLE_REQUEST_DATA`、`DAILY_ACTIVITY`、`PEDOMETER_TRACK`：收到 REQUEST_DATA SUCCESS，
   部分请求紧随 SYNC_DATA；没有观察到全天汇总或缺失历史记录。不能仅据此断言该字段永远被忽略。
2. 仅把 REQUEST_DATA 的 `last_sync_time` 改为 0：收到 SUCCESS，没有观察到历史回补。
3. 按 E1 形态使用 `device_type=0` / `last_sync_time=0`，省略 start/end/is_last_chunk：
   收到 SUCCESS，仍没有观察到历史回补。
4. 手机发送不携带用户记录的 `SYNC_DATA`（last_sync_time=0）：收到 SUCCESS，未观察到回补。
5. 依据官方 framework 发送 `export_watch_db`：在本轮有界观察期间没有收到导出内容；
   未验证手表固件是否声明该能力。

原先只测 start_time=0 就宣称“无法全量回补”的结论证据不足。
这轮增加了 last_sync_time=0 的测试，但仍只能说明**这些已测试报文未得到历史记录**，
不是所有回补路径都不可用。临时冷同步/导出命令与原始健康报文持续落盘探针已撤出产品代码。
模块请求命令 `health_module` 保留为诊断工具，不由常规同步自动调用。

## 最终实机结论：4269 步已对齐

手表无线 ADB 连接恢复后（SM-L7050，`<watch-adb-endpoint>`），直接拉取手表端
Samsung Health **6.30.7.008**，SHA-256 为
`2b4b6a7cd446032ff71b6e49dee1dd0c7620ac96d15a6f58705521944faee763`。

手表日志显示它查询出 100 条计步记录、构造约 581 KB 的报文，然后调用 GMS Channel API，
`openChannel()` 超时。之前 App 只实现了 Message API，对 Channel 的 `inner tag 16` 一直
记作“未知握手”。回补并非不可用，而是**回补报文切换到了尚未实现的传输通道**。

修复 Channel 接收与 Envelope 分片重组后：

```text
22:47:01 [HealthChannel] COMPLETE bytes=581344 chunks=10
22:47:01 [健康] 区间步数：新增 642 步，当日累计 3912 步
22:53:38 [健康] 完整回补校准：今日 99 条记录，共 4269 步
22:53:38 [健康] 区间步数：新增 0 步，当日累计 4269 步
```

解码原始大包：100 条计步记录共 4287 步，其中昨日 1 条为 18 步，今日 99 条合计
**4269 步**，与用户实读手表一致。首次只按旧 UUID 缓存合并时为 3912，仍差 357；
完整记录快照重建后恢复 4269。999 的总缺口在本轮数据恢复中表现为 642 条目贡献补入
加 357 旧基线修正，不能把它全归为 UUID 修订。

产品修复：

- 新增只接收 Samsung Health 路径的 Wear Channel：OPEN_ACK、按序接收、逐块 DATA_ACK、
  final_message、重传去重、有限大小/并发/超时；ACK 使用原 Channel 的 AppKey，
  即 `com.samsung.android.wear.shealth` + 三星统一签名摘要，而非手机健康包身份。
- 增加 fixed64 编解码，保留 channelId 的全部位；Envelope 按内容摘要重组全部片段后再解析，
  以 SHA-1 Base64URL 校验重组结果。
- 当天缓存没有完整覆盖标志时，用 `REQUEST_DATA.last_sync_time=0` 请求冷同步；只有
  显式请求后的 `start_time=0` 数据窗及 `is_last_chunk=true` 闭环，才按今天的记录重建总数。
  多个业务分块先汇集，完整快照按 UUID 保留最新修订。未请求的零起点或普通增量不覆盖基线。
- 重建后持久化完整覆盖标志、每条记录计入值和今日总数，后续恢复普通增量，不每次全量重传。
- 不向产品硬编码 4269，也不手工填加 999；0 步同样是有效值。

新增脱敏的 100 条实机计步夹具（只保留时间、count、合成 UUID），测试直接验证排除昨日
18 步后为 4269。全套 166 条测试通过。

重复增量与重启复验：22:58:19、22:58:44、23:00:28 三轮均为新增 0 步、累计 4269；
两次覆盖安装/进程重启后，`steps=4269`、`steps_accum=4269`、
`steps_coverage_complete=true`、贡献账本 99 条。最终测试包已覆盖安装，配对与原健康数据保留。
原始大包落盘与逐片 hex 调试输出已移除，ChannelManager / ChannelStateMachine 日志属性已还原。


### 手表端 REA 证据

| Evidence ID | 方法 / 目标 | 结论 |
|---|---|---|
| `ev_4a10eebfb81e4ac26ccdb69c3d44927e0b23e8c55573e8a86580a28d7c289674` | 手表 APK package | 6.30.7.008，18496 个类 |
| `ev_a3996b591cf3291df0ef98d918d98216da45da8cf5b743d9c008086805d4c302` | `defpackage.oX2.c` | 序列化消息长度 >= 92160 时切换 Channel 分支，短消息使用 MessageClient |
| `ev_65fe6a9bf2c27ef2fff014188f35e5e840cc3898bbe7ef5add88234d407bb515` | `defpackage.nX2.invokeSuspend` | 打开 Channel 并将消息 UTF-8 字节写到输出流；失败报告同步错误 |
| `ev_03548ef60394b68689bb5ac8a3e3bae5d25243532427c5b7db0b315953a9f5a9` | `defpackage.FO2.x` | 手表收到 REQUEST_DATA/SYNC_DATA/CHECK_STATUS 的 last_sync_time=0 时重置发送标记表 |

底层 protobuf 字段与 ACK 语义交叉参考官方 Wear APK 的 `hjo/hjv/hiu/hip/hir/his/hiq`、
`gur/gui/guj/gvh/guz`。本机离线输出是静态辅助材料，以上 REA Evidence 与手表日志分别
证明静态分支和实际执行结果。

## 早期调查时的连接阻塞（已解除）

以下是上半轮留下的历史状态，当前已通过无线 ADB 解除；不再需要用户提供端点。

手机 ADB 与 RFCOMM 正常；手表只有 WiFi 连接，尚未建立可用的无线 ADB 连接。
旧端点 `<watch-adb-endpoint>` 不可用，ADB mDNS 未发现手表。

需要用户提供手表“开发者选项 → 无线调试”页面当前显示的 **IP 地址和端口**，才能：

1. 读取手表同步日志、确认 REQUEST_DATA=0 到底进入了哪条分支；
2. 拉取并用 REA 分析当前手表 `com.samsung.android.wear.shealth` 的实际 APK；
3. 核对本地计步记录、发送标记表及同 UUID 的修订语义；
4. 确定可重复的历史恢复方式，并把 App 与手表当日总数对齐。

不要清除手表健康数据、重置配对或伪造计步基线来绕过问题。
