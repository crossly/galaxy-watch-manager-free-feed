# Research — Galaxy Watch 协议逆向资料库

本目录是 Galaxy Watch 协议逆向的原始研究资料，**从 `galaxy-watch-tweaker` 仓库迁移而来**
（该仓库只保留 LSPosed 模块本身，与本 App 无代码依赖）。

## 与 `docs/PROTOCOL-SPEC.md` 的关系

- **`docs/PROTOCOL-SPEC.md` 是唯一真相源（SSOT）**：结构化的完整协议规范，随每次逆向发现持续更新。
- 本目录保存的是**过程资料**：早期静态分析、逐条抓包、自动生成的特性矩阵、枚举表。
  内容更原始、更冗长，用于交叉验证与追溯，不保证与 SSOT 同步。
- 两者冲突时，以 `docs/PROTOCOL-SPEC.md` 为准；若本目录出现 SSOT 未收录的有效发现，
  应把它提炼进 SSOT，而不是反过来。

## 文件索引

| 文件 | 内容 |
|---|---|
| [`WEAR-TRANSPORT.md`](WEAR-TRANSPORT.md) | RFCOMM 分帧、protobuf 信封、UUID 表、节点协商、连接约束 |
| [`FEATURES.md`](FEATURES.md) | 736 条 WCS 特性路径，按 30 个子系统分组，附真实抓包 payload |
| [`FEATURE-MATRIX.md`](FEATURE-MATRIX.md) | 自动生成的逐路径矩阵（常量名、JSON key、源码文件） |
| [`STEP-COUNT-INVESTIGATION.md`](STEP-COUNT-INVESTIGATION.md) | 4269/3270 步数缺口定位：手表端 REA、Wear Channel 大包与历史快照恢复 |
| [`HEALTH-PROTOCOL.md`](HEALTH-PROTOCOL.md) | Samsung Health 穿戴同步协议与解码后的真实报文 |
| [`HEALTH-ENUMS.md`](HEALTH-ENUMS.md) | 同步模块、结果码、同步阶段、128 种数据类型 |
| [`LIVE-VERIFICATION.md`](LIVE-VERIFICATION.md) | 实机验证报告（SDP 记录、分帧时序、通道映射） |
| [`PROTOCOL.md`](PROTOCOL.md) | 早期静态分析（配对、SAK、GATT 引导） |
| [`health-modules.txt`](health-modules.txt) / [`health-types.txt`](health-types.txt) | 健康模块与数据类型清单（纯文本，便于 grep） |
| [`gen_matrix.py`](gen_matrix.py) / [`extract_features.py`](extract_features.py) | 生成特性矩阵与提取特性的脚本 |
| [`restore-samsung-packages.sh`](restore-samsung-packages.sh) | 调试后恢复手机端官方三星组件 |
| [`lab-nodeinfo.sh`](lab-nodeinfo.sh) | 从实机提取节点/会话身份信息 |
| [`IOS-FEASIBILITY.md`](IOS-FEASIBILITY.md) | iOS 适配可行性调研：首次配对、蓝牙 API 约束与第三方方案边界 |

## 未纳入版本管理的重体量产物

以下目录/文件是逆向的中间产物，体积巨大（合计约 1.5 GB），已被 `.gitignore` 排除，
只保留在本机，不进入仓库：

```
research/apks/            # 官方 APK 原件
research/decompiled/      # jadx 反编译输出（watch7plugin / watchmanager / shealth / wear）
research/strings/         # APK 字符串全量导出
research/snoop/           # HCI snoop 抓包与解析脚本
research/*.log            # 实机日志
research/feature_matrix.json
```

需要重新生成时，参考 `extract_features.py` / `gen_matrix.py` 与
`docs/PROTOCOL-SPEC.md` 第 9 章「调试手册」。
