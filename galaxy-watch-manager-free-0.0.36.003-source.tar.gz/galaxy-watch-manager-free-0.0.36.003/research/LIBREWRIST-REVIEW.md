# LibreWrist：SHM 补丁架构、限制变更与集成边界

> **已归档（2026-10-30）**：本文保留对 LibreWrist 上游的历史研究。本项目的独立传感器实验模块已移除，当前心率同步、ECG/BP 测量与校准继续使用官方链路，见 [Health Monitor 验收记录](../docs/HEALTH-MONITOR-INVESTIGATION.md)。

研究日期：2026-10-29。审查上游固定提交：[`5d0fb143c092622d4509655f311c26f76f66c1a1`](https://github.com/LibreStatic/LibreWrist/commit/5d0fb143c092622d4509655f311c26f76f66c1a1)（2026-10-25，`Update the known issues for 0.10.9`）。下文上游链接全部固定到该提交。

方法：独立临时浅克隆，只读 catalogue、Kotlin patcher、Java watch adapters、许可证及一手文档；未执行上游脚本、构建、安装或设备命令。“实现”指源码存在，不代表本次运行时或医学验证。上游不提交官方 APK，本次没有独立核对补丁后的厂商二进制。

## 1. 结论

**LibreWrist 不只是去除品牌/地区 gate，也不是独立重写 SHM。**它修改用户自行取得的官方手机/手表 SHM，改包、重新签名；由于改签 watch app 失去特权传感器通路，再注入自研 ECG、BP、SpO2、IHRN adapters，把 Health Tracking 输出转换成原 SHM 消费的事件。UI、业务控制、原生库和健康结果同步仍依赖官方输入。[上游定位/输入边界](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/README.md#L5-L39)、[组件架构](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/docs/architecture.md#L5-L30)、[watch adapters/注入](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/docs/patches.md#L283-L331)。

对本项目主要价值是限制清单、改签成本和固定输入/锚点失败即停止的工程设计。**不能把它视为现有 WCS 结果同步的直接替换，也不能视为已开源重写手机三轮袖带校准向导。**上游继续让用户在改版官方手机 SHM 做三次袖带输入；本项目仍需自己的 prepare/ready/start/update 状态机和设备验收。[上游校准步骤](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/README.md#L436-L459)、[本地校准边界](/Users/ricky/Documents/GitHub/galaxy-watch-manager-free/docs/HEALTH-MONITOR-INVESTIGATION.md#L104-L115)。

上游明确声明 proof of concept、读数未验证，尚无临床或与原版 Samsung 组合的对比验证。此处只讨论源码行为、互操作和维护，不据此作准确性、诊断、地区获批或适用年龄声明。[上游警示](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/README.md#L19-L39)。

## 2. 补丁与通信架构

### 2.1 Catalogue 与两套解释器

Catalogue 是 schema 2、serial 62 的 JSON，定义输入、family、顺序 profile、命名 ops、注入集、安装/授权/停用 stock apps。Python CLI 和 Android Kotlin engine 解释同一数据。SHM `gms` profile 固定 phone **1.4.6.001**、watch **1.5.1.022**，不同于本项目调查的 phone 1.5.2.002。[目录/输入定义](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/docs/patches.md#L3-L37)、[profile 源码](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/catalogue/catalogue.json#L140-L199)。

实际 Kotlin 管线在 `Patcher`：验证请求及输入 SHA-256，读 manifest/dex/resources，按 family 应用 pattern，确认注入集，重建 dex、签名，再自检签名、包/资源包名、注入类与 applied-mode anchors；自检失败删除已签输出。analyze 只在内存操作。[请求/输入校验](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/patcher-app/engine/src/main/kotlin/io/openshm/patcher/engine/Patcher.kt#L92-L191)、[修改/签名/清理](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/patcher-app/engine/src/main/kotlin/io/openshm/patcher/engine/Patcher.kt#L218-L310)、[输出自检](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/patcher-app/engine/src/main/kotlin/io/openshm/patcher/engine/Patcher.kt#L328-L382)。

Pattern 有语义字符串/方法签名锚点，也有指定混淆类与精确 smali；`expect` 可为精确数、atLeastOne 或有意放宽的 any。因此不能声称可适配任意新版。optional 是用户可跳过；选中后仍须匹配。minimum-age、sleep-apnea 成组控制 phone/watch；通常 optional 默认开启，offByDefault 是另一机制。[执行规则](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/docs/patches.md#L135-L178)。

目录用 ECDSA P-256/SHA-256 签名原始 JSON；验证器遇到非法输入返回 false。更新设计规定 bundled 公钥、递增 serial/minAppVersion；数据更新不自动提供新注入实现或新 op。签名证明来源/完整性，不证明功能正确。[验证代码](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/patcher-app/engine/src/main/kotlin/io/openshm/patcher/engine/CatalogueVerifier.kt#L11-L59)、[更新规则](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/docs/patches.md#L207-L224)。

### 2.2 三种链路

| 链路 | 实现 | 边界 |
|---|---|---|
| SHM phone ⇄ watch | stock Galaxy Wearable 配对/GMS Data Layer；两端 `com.samsung.android.shealthmonitors`、同一用户证书；移除 stock trusted-peer metadata | 仍依赖官方配对与 GMS，不是替代 Watch Manager 配对实现 |
| bridge phone ⇄ watch | 自有 RFCOMM，只接受 `/__bridge__/*`，镜像通知/闹钟/通话 | 不是 SHM `/991`、`/992` 的 relay；不承载 SHM 健康同步 |
| watch adapter ⇄ Health Tracking | 自有 Binder client，bindService 后 IBinder.transact 请求 tracker | 解决改签后的传感器输入，不是手机接收结果协议 |

来源：[通信架构/白名单](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/docs/architecture.md#L5-L39)、[改包源码](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/catalogue/catalogue.json#L641-L729)、[trusted peers/能力资源修正](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/docs/patches.md#L274-L277)、[Binder 实现](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/watch-mod/src/shminterop/hsdk/HealthClient.java#L64-L178)。

## 3. Phone SHM：限制变更清单

范围只针对固定 APK，不是 Samsung 所有系统/服务限制全集。

| 项目 | 确切行为与源码 |
|---|---|
| 厂商/SDK vendor | `samsung` 字符串 contains/equals 类比较变 auto-true，排除 androidx/google 等；另处理 `Samsung` compareToIgnoreCase。不是修改系统品牌。[catalogue 269–301](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/catalogue/catalogue.json#L269-L301) |
| 最低年龄 | `MIN_AGE` 22 (`0x16`) →16 (`0x10`)，optional minimum-age 组；不构成适用性证据。[303–320](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/catalogue/catalogue.json#L303-L320) |
| 通用地区/MCC/CSC/无 SIM | SupportedType 拒绝 ordinals 1–4 置 0；地区返回 `.a`；含 BH 锚点布尔国家检查 true。[322–393](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/catalogue/catalogue.json#L322-L393) |
| PackageValidator/root/certificate | 两个按日志/字节数组锚定的 boolean 方法 false；不是得到 Samsung 签名或全面解除 Knox。[394–442](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/catalogue/catalogue.json#L394-L442) |
| 强制更新 | responseFailed/updateNeeded false；versionName 固定 1.5.1.022、versionCode 字符串 1501022；required-version pref getter false。可能掩盖真实版本差异。[443–516](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/catalogue/catalogue.json#L443-L516) |
| 主界面 system/version/screen-lock | checkSystem/updateVersionCheck 提前 return；isScreenLockEnabled 返回 success singleton。[517–555](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/catalogue/catalogue.json#L517-L555) |
| 设置阶段网络 gate | checkNoNetworkError 提前 return，optional；没有补出网络服务。[556–576](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/catalogue/catalogue.json#L556-L576) |
| Sleep/apnea | phone-support 结果 true；共享国家 lookup 收到 sleep list 时 true；与 watch 两项同属 optional sleep-apnea 组。[577–608](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/catalogue/catalogue.json#L577-L608)、[组说明](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/docs/patches.md#L156-L161) |
| IHRN | ECG-only 列表 CN/MO/NZ/LI/TR/RS/UA/PE 也通过 ECG2 检查；home 跳过旧 EcgController。此项不是所有国家一律 IHRN true。[3414–3493](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/catalogue/catalogue.json#L3414-L3493) |
| BP 国家 | 共享 util/r.o(country,list) 收到 BP list h 时 true，影响 home、sync、通知、onboarding module-disable；包括 US/未列出国家。[3495–3539](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/catalogue/catalogue.json#L3495-L3539) |
| home tabs | 缺 BP controller 补入；无 ECG controller 补 Ecg2Controller；空 tabs 隐藏，避免无 SIM/未列出国家零 tab 除零。[patches 257–259](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/docs/patches.md#L257-L259) |
| Samsung Health 衔接 | Sleep/BP provider caller 改为 `${PKG_PREFIX}.shealth`，保留 signature permission；optional 关闭 stock Health SDK permission popup，apnea onboarding 跳过该请求。并没有让 stock Health 信任改签 SHM。[3541–3629](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/catalogue/catalogue.json#L3541-L3629) |

## 4. Watch SHM：gate、平台与采集变化

- **品牌/手机状态**：generic manufacturer；WearCoreServiceRepository 的 samsung match true，READ_COMPANION_INFO 拒绝路径 FALSE→TRUE；application_installed_in_mobile getter true。这些不证明真实配对、安装或连接成功。[companion/installed 源码](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/catalogue/catalogue.json#L745-L811)。
- **年龄/国家**：DOB feature minimum age 覆盖为16（原22，apnea2.0可能18）；apnea 国家 true，重新评估缓存 NOT_SUPPORTED。[年龄源码](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/catalogue/catalogue.json#L813-L841)、[apnea 补丁](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/docs/patches.md#L292-L293)。
- **GMS identity/capability**：改包末尾多一个 s，移除 stock peer metadata；定义首个 resource ID 0x7f010000，修复 GMS 定位 android_wear_capabilities 数组。不是变回 Samsung 原签名。[watch 2–2c](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/docs/patches.md#L274-L277)。
- **非 system app 兼容**：改名反射 setExactAlarmForSystemApp 使其落到 setAlarmClock；unregister 兼容反射；BP SemHrSensorAttribute 反射构造失败跳过后续属性/注册调用；IHRN/apnea startService/FGS fallback，配合 Doze 白名单；IHRN alert 加 overlay/BAL 权限。[平台改造表](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/docs/patches.md#L280-L291)。
- **hidden API**：追加 Settings.Global.hidden_api_blacklist_exemptions=`Lcom/samsung/android/hardware/sensormanager/`，**设备上所有 app 对此前缀均获例外，不是单 app grant**。上游说明保留其他 entries、进程重启生效和撤销方式。仍需 BODY_SENSORS、后台传感器、heart rate/oxygen 等权限，较新 SDK 还有 READ_ADDITIONAL_HEALTH_DATA。[grant 本体](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/catalogue/catalogue.json#L3830-L3894)、[全局范围/撤销](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/docs/patches.md#L295-L325)。

### 4.1 传感器 adapters 做了什么

| adapter | 实际行为 | 没实现/未证明 |
|---|---|---|
| ECG 27/0x1b | Health Tracking→SemEcgSensorEvent；10点/批；ADC=0x200000+mV/2.6614e-4；EMA alpha .001 去基线和 contact debounce；真实输入前 lead=5 合成 keepalive | 不是纯 gate 补丁；start 返回 true 不证明 tracker 成功；未证明等价原 front-end |
| BP 28/0x1c | green ADC 每点封成 green_raw，交原 SHM BP pipeline；测量/校准共用 hook；sensor24 HR/motion gate 保留；真实输入前100ms一次零值 keepalive | 没有重写 libbp 或免校准模型；格式一致不证明物理 AFE gain/最终读数等价 |
| IHRN 37/0x25 | green PPG+accelerometer→SHM event；单点后250点 batch；不可信 sample 打 agc flag，设备 warm-up 策略 | 不是保留原 privileged sensor 路径，不证明本项目支持 IHRN |
| Sleep SpO2 49/0x31 | raw red/IR PPG 过夜记录，自算每秒值；回应 version/mode/getData；窗口、质量 gate、二次多项式映射 | 不是转发官方已算 SpO2；无 apnea 检出性能验证 |

依据：[ECG 契约/start](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/watch-mod/src/shminterop/ecg/EcgAdapter.java#L21-L107)、[ECG 处理](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/watch-mod/src/shminterop/ecg/EcgAdapter.java#L156-L200)、[BP 契约](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/watch-mod/src/shminterop/bp/BpAdapter.java#L20-L40)、[BP delivery/keepalive](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/watch-mod/src/shminterop/bp/BpAdapter.java#L145-L207)、[IHRN 契约](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/watch-mod/src/shminterop/ihrn/IhrnAdapter.java#L32-L70)、[SpO2 hook](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/docs/patches.md#L287-L288)、[SpO2 公式](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/watch-mod/src/shminterop/spo2/Spo2Estimator.java#L3-L39)。

上游 BP 研究保留 physical AFE gain、真实 runtime calibration 值等未确认项；“software format/scale equivalent”不能升级为测量等价。本项目原生算法研究是另一组证据，不能靠相同库名替代交叉验证。[上游未确认项/verdict](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/docs/bp-calibration.md#L130-L155)、[本地分析边界](/Users/ricky/Documents/GitHub/galaxy-watch-manager-free/docs/HEALTH-MONITOR-INVESTIGATION.md#L118-L126)。

## 5. 与本项目 SHM 对照

| 方面 | 本项目当前事实 | 采用上游的影响 |
|---|---|---|
| identity | 原 shealthmonitor package+固定 signature；enum 有四通道，session supported 仅 ECG/BP | 上游 shealthmonitors+用户 key；换 watch APK 会改变 peer/capability 身份，当前常量/白名单不能假定兼容 |
| transport | 真 /plain_connection 回复后 READY；request_connection 触发重握手 | 上游 SHM 是 GMS，私有 bridge 不能修复 WCS/Channel |
| result sync | 任务4字节大端长度+zlib JSON；report Base64(zlib大端double[])；保存成功才 ACK 原 task id | 上游保留官方 sync，不提供替换本地 decoder/persistence 的独立模块 |
| consent/profile | reconnect 不虚构信息；显式 ECG activation 才发条款/手腕 | 修改资格判断不授权本项目自动写生日/条款/校准 |
| BP | do_measure/do_calibration；tnc/calibration_time 与本地日历28天检查 | 上游改版官方 phone wizard 不填补本项目三轮袖带向导 |
| acquisition | 读取 watch SHM 已算结果；独立传感器/自算模块已撤下 | 上游替换采集输入，扩大实现与验证范围 |
| evidence | ECG三条、重启恢复、去重；后续非空BP/有效状态；完整三轮/到期未验收 | 上游设备报告不等于本项目设备验收 |

本地源码定位：[identity/path](/Users/ricky/Documents/GitHub/galaxy-watch-manager-free/app/src/main/java/dev/ricky/galaxywatchmanagerfree/feature/monitor/HealthMonitorProtocol.kt#L16-L44)、[supported/handshake](/Users/ricky/Documents/GitHub/galaxy-watch-manager-free/app/src/main/java/dev/ricky/galaxywatchmanagerfree/feature/monitor/HealthMonitorSession.kt#L48-L83)、[activation/READY](/Users/ricky/Documents/GitHub/galaxy-watch-manager-free/app/src/main/java/dev/ricky/galaxywatchmanagerfree/feature/monitor/HealthMonitorSession.kt#L94-L149)、[保存后ACK](/Users/ricky/Documents/GitHub/galaxy-watch-manager-free/app/src/main/java/dev/ricky/galaxywatchmanagerfree/feature/monitor/HealthMonitorSession.kt#L212-L257)、[Channel](/Users/ricky/Documents/GitHub/galaxy-watch-manager-free/app/src/main/java/dev/ricky/galaxywatchmanagerfree/feature/monitor/MonitorChannelFrames.kt#L7-L26)、[report](/Users/ricky/Documents/GitHub/galaxy-watch-manager-free/app/src/main/java/dev/ricky/galaxywatchmanagerfree/feature/monitor/EcgLog.kt#L97-L108)、[28天parser](/Users/ricky/Documents/GitHub/galaxy-watch-manager-free/app/src/main/java/dev/ricky/galaxywatchmanagerfree/feature/monitor/BpCalibrationStatus.kt#L17-L45)、[实机与待验收](/Users/ricky/Documents/GitHub/galaxy-watch-manager-free/docs/HEALTH-MONITOR-INVESTIGATION.md#L92-L126)。

**本地文档定位与时效差异**：当前协议规范没有 `6.6.9` 标题；指定 SHM 主题实际在[905–917](/Users/ricky/Documents/GitHub/galaxy-watch-manager-free/docs/PROTOCOL-SPEC.md#L903-L917)和[939–944](/Users/ricky/Documents/GitHub/galaxy-watch-manager-free/docs/PROTOCOL-SPEC.md#L939-L944)。经用户完成官方袖带校准流程后，非空 BP 记录与有效校准状态已在实机成功接收并闭环；三次袖带分步过程未由单会话直接观测，属于历史观测边界。独立传感器采集与自研算法已彻底放弃并完成代码移除，应用内不保留任何独立运行链路。

## 6. 许可证与维护风险

1. **MIT 范围**：自有代码/文档 MIT，复制实质内容须保留 notice；无保证。它不授予 Samsung APK/native library/商标/服务的再分发权。上游要求用户自备输入、本地签名、个人使用、不分发成品；发布集成产物需要另核权利来源，不能把根 MIT 当作所有输入开源。[LICENSE](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/LICENSE#L1-L21)、[输入/分发边界](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/README.md#L10-L17)。此处不判断具体司法辖区合法性。
2. **依赖不全 MIT**：上游清单含 libadb Apache/GPL 双许可选择、spake2-android LGPL-3.0 动态 native lib、Play services SDK 条款；engine 使用 smali BSD、ARSCLib/apksig Apache。借鉴思路与整包嵌入 patcher 义务不同。本次未下载依赖逐文件审计。[依赖清单](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/patcher-app/THIRD_PARTY.md#L8-L52)。
3. **版本/firmware 耦合**：上游测试组合是 Watch5 Pro / One UI8 API36、Health Platform1.7.00.05、watch SHM1.5.1.022、phone SHM1.4.6.001、Motorola；旧系统未测。识别多 watch family 不等于全机型测量验收。锚点、event布局、Binder、权限/hidden API 均可能升级变更。[矩阵](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/README.md#L36-L51)。
4. **密钥/目录信任**：GMS AppKey、provider signature permission 和升级连续性依赖同 key/package，丢 key 不是无状态重装。目录签名不能排除 maintainer key 泄露或错误补丁；输入 hash 证明与目录一致，不独立证明原始发布者。[key 连续性](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/README.md#L83-L92)、[输入信任设计](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/docs/architecture.md#L102-L121)。
5. **设备设置成本**：全局 hidden API 例外、Health Platform developer mode、后台传感器/Doze/overlay 是实际要求；不能描述成无副作用普通权限部署。[grants](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/catalogue/catalogue.json#L3876-L3894)、[developer mode](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/README.md#L474-L481)。
6. **维护状态**：固定提交记录 ECG失败/心率跳变、apnea无数据和过夜耗电，部分修复等待用户反馈；另有 Health+ cloud sync 问题。提交活跃不证明稳定；没有足够证据量化 bus factor 或长期承诺。[固定 Known issues](https://github.com/LibreStatic/LibreWrist/blob/5d0fb143c092622d4509655f311c26f76f66c1a1/README.md#L461-L470)。

## 7. 本项目边界与结论

- 借鉴逐层 gate 排查与固定输入/自检设计，保留真实握手、落盘后 ACK 和显式用户操作边界。
- 上游整套改签 watch app 及传感器 adapter 路线已被本项目明确放弃，相关独立实验模块已从仓库彻底移除；本项目不接管底层传感器采样，亦不自行实现 native 算法。
- 血压与心电图完全依赖手表端官方 SHM 测量、官方校准及结果通道，心率由 Samsung Health 官方服务同步，保持纯净的官方协议桥接。
- 不从 protocol enum/capability 或上游 adapter 推导本项目 IHRN/apnea 已支持；需本项目接收、存储、UI 和设备验证。[本地支持范围](/Users/ricky/Documents/GitHub/galaxy-watch-manager-free/app/src/main/java/dev/ricky/galaxywatchmanagerfree/feature/monitor/HealthMonitorSession.kt#L48-L49)、[调查范围](/Users/ricky/Documents/GitHub/galaxy-watch-manager-free/docs/HEALTH-MONITOR-INVESTIGATION.md#L16-L33)。
