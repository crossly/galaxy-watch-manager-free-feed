# 第三方组件与授权边界

本仓库原创代码采用 GNU GPL v3.0（根目录 `LICENSE`）。此文件记录不适用该许可的来源与待办事项：
它不授予新的权利，也不把厂商二进制重新声明为原创或开源模型。

| 内容 | 来源/版本 | 当前说明 |
|---|---|---|
| Android/Kotlin 应用与自写协议代码、原创图形 | 本仓库 | GNU GPL v3.0（`LICENSE`）；厂商来源资产除外 |
| 睡眠 DEX 桥、模型、分位表、Samsung JNI | Samsung Health 7.1.0.053，输入摘要见资产 NOTICE | 默认随公开 APK 与对应源码归档保留，以支持本机四阶段分析。厂商模型和二进制不属于根目录 GPLv3 授权，再分发许可依据仍未确认；随包提供不改变其权利归属 |
| TensorFlow Lite JNI | 同一 APK 附带的运行时 | ARM64/ARMv7 二进制随包保留；上游 Apache-2.0 文本位于 `app/src/main/assets/sleep/TENSORFLOW-LICENSE.txt`，该特定二进制的完整 notice/依赖清单仍需核对 |
| 表盘预览图 | Galaxy Wearable Watch7 插件 `assets/Category_watchface/`，由 `scripts/gen_watchface_assets.py` 转换 | 默认资源保留 `app/src/main/res/drawable-nodpi/wf_*.webp` 的 43 张逐款预览，并随 APK 和对应源码归档保留。图片为厂商来源，不属于本仓库原创 GPLv3 授权，再分发许可依据仍待确认 |
| UI 布局参考与液态玻璃移植 | FLClash `7fd417fb9a9a277c6a9339a8ac87f907df7c25f7`；见 `docs/UI-FLCLASH-REFERENCE.md` | 漂浮底栏移植其 pill/lens/lensContent 着色与按压拖动逻辑，适配 Compose/AGSL；GNU GPL v3，许可与来源随包保留于 `app/src/main/assets/licenses/FLCLASH-LICENSE.txt`、`FLCLASH-NOTICE.txt` |
| AndroidX/Material/Coroutines/GMS 等依赖 | `app/build.gradle` / Gradle 依赖解析 | 各自遵从其许可证；不能因本仓库许可证而改变 |
| Shizuku API / Provider | `dev.rikka.shizuku:api:13.1.5`、`provider:13.1.5`；[上游](https://github.com/RikkaApps/Shizuku-API) | MIT；许可随包保留于 `app/src/main/assets/licenses/SHIZUKU-LICENSE.txt`。仅在 Shizuku 可用且用户授权后停用/恢复限定的官方连接组件；普通连接不要求安装 Shizuku |

睡眠组件的输入来源与每个文件 SHA-256：`app/src/main/assets/sleep/manifest.json`。
重建流程：`scripts/sleep-engine/README.md`。完整来源声明：`app/src/main/assets/sleep/NOTICE.md`。
ARM64 实机验收与 ARMv7 未验收的边界继续适用。

## 随包资产与私有证据

- 睡眠运行时与模型位于 `app/src/main/assets/sleep/`，默认构建直接打包，不需要额外构建参数或私有目录。
- 43 张表盘预览位于 `app/src/main/res/drawable-nodpi/`；原创通用示意仅作为缺失预览的兜底。
- `scripts/check_public_assets.py` 校验源码与 APK 的运行时文件、双 ABI JNI、清单摘要、JAR 内模型/分位表/DEX，以及表盘图片覆盖。`verifyBundledAssets` Gradle 任务在构建前执行同一检查，缺件或摘要不符会失败。
- 对应源码归档保留随包运行时、模型、来源说明及重建脚本；`private/`、真实设备证据、原始 APK 和密钥继续排除。

## 尚待核对

1. 厂商睡眠组件和表盘图片的可分发依据及完整 notice 清单仍未确认，随包提供不等于取得新的上游授权。
2. Git 历史、真实抓包和截图的去标识化检查：实机截图、抓包回放与设备标识已从当前版本移除，源码仓库以该快照重建历史并撤下旧 Release 与标签。包含旧历史的恢复备份仅保留在被忽略的本地 `private/`；公开前仍需复核现有文件，并检查 GitHub 缓存及其他副本。
