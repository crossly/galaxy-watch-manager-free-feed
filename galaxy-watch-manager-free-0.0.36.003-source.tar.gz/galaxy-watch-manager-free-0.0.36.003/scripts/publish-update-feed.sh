#!/usr/bin/env bash
# Publish metadata and a retained APK revision atomically; accepts SSH or local git remotes.
set -euo pipefail
[[ "$#" == 3 || "$#" == 4 ]] || { echo "Usage: $0 <feed-remote> <signed-apk> <tag> [source.tar.gz]" >&2; exit 1; }
project_root="$(cd "$(dirname "$0")/.." && pwd)"
remote="$1"
apk="$(python3 -c 'from pathlib import Path; import sys; print(Path(sys.argv[1]).resolve())' "$2")"
release_tag="$3"
artifact_options=(--apk "$apk")
if [[ "$#" == 4 ]]; then
  source_archive="$(python3 -c 'from pathlib import Path; import sys; print(Path(sys.argv[1]).resolve())' "$4")"
  artifact_options+=(--source "$source_archive")
fi
work="$(mktemp -d "${TMPDIR:-/tmp}/watchfree-feed.XXXXXX")"
trap 'rm -rf "$work"' EXIT

python3 "$project_root/scripts/write-update-feed.py" "$work/metadata.json" "$release_tag" "${artifact_options[@]}"
channel="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["channel"])' "$work/metadata.json")"
if [[ "$channel" == nightly ]]; then
  feed_file=nightly.json
  apk_branch=apk-nightly
else
  feed_file=version.json
  apk_branch=apk
fi
git clone --depth 1 --branch main "$remote" "$work/feed"
# Re-running an older release must not roll back its channel's feed or APK branch.
python3 - "$work/metadata.json" "$work/feed/$feed_file" <<'PY' > "$work/decision"
import json, sys
from pathlib import Path
incoming = json.loads(Path(sys.argv[1]).read_text())
previous_path = Path(sys.argv[2])
previous = json.loads(previous_path.read_text()) if previous_path.exists() else {}
print('skip' if int(previous.get('version_code', 0)) > incoming['version_code'] else 'publish')
PY
if [[ "$(<"$work/decision")" == skip ]]; then
  echo "Public feed already has a newer version; leaving all refs unchanged."
  exit 0
fi
public_name="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["apk_name"])' "$work/metadata.json")"
digest="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["sha256"])' "$work/metadata.json")"
retained_tag="apk-${release_tag}-${digest}"
if [[ -n "${source_archive:-}" ]]; then
  source_name="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["source_name"])' "$work/metadata.json")"
  source_digest="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["source_sha256"])' "$work/metadata.json")"
  retained_tag+="-${source_digest}"
fi
cd "$work/feed"
retained_ref="$(git ls-remote "$remote" "refs/tags/$retained_tag")"
if [[ -n "$retained_ref" ]]; then
  git fetch "$remote" "refs/tags/$retained_tag:refs/tags/$retained_tag"
  revision="$(git rev-parse "refs/tags/${retained_tag}^{commit}")"
  actual_digest="$(git show "$revision:$public_name" | python3 -c 'import hashlib,sys; print(hashlib.sha256(sys.stdin.buffer.read()).hexdigest())')"
  [[ "$actual_digest" == "$digest" ]] || { echo "Retained APK digest mismatch." >&2; exit 1; }
  if [[ -n "${source_archive:-}" ]]; then
    actual_source_digest="$(git show "$revision:$source_name" | python3 -c 'import hashlib,sys; print(hashlib.sha256(sys.stdin.buffer.read()).hexdigest())')"
    [[ "$actual_source_digest" == "$source_digest" ]] || { echo "Retained source digest mismatch." >&2; exit 1; }
  fi
  git switch --create "$apk_branch" "$revision"
else
  source_ref=HEAD
  if git -C "$project_root" rev-parse --verify "${release_tag}^{commit}" >/dev/null 2>&1; then
    source_ref="${release_tag}^{commit}"
  fi
  source_epoch="$(git -C "$project_root" show -s --format=%ct "$source_ref")"
  git switch --orphan "$apk_branch"
  cp "$apk" "$public_name"
  git add -- "$public_name"
  if [[ -n "${source_archive:-}" ]]; then
    cp "$source_archive" "$source_name"
    git add -- "$source_name"
  fi
  GIT_AUTHOR_DATE="@$source_epoch +0000" GIT_COMMITTER_DATE="@$source_epoch +0000" \
    git -c user.name="github-actions[bot]" -c user.email="41898282+github-actions[bot]@users.noreply.github.com" \
      commit -m "chore: publish $release_tag artifacts"
  revision="$(git rev-parse HEAD)"
  git tag "$retained_tag"
fi
git switch main
python3 "$project_root/scripts/write-update-feed.py" "$feed_file" "$release_tag" \
  --apk-revision "$revision" "${artifact_options[@]}"
git add "$feed_file"
if ! git diff --cached --quiet; then
  git -c user.name="github-actions[bot]" -c user.email="41898282+github-actions[bot]@users.noreply.github.com" \
    commit -m "chore: update feed for $release_tag"
fi
# Updating main must remain a fast-forward. A concurrent writer rejects all three ref updates.
for attempt in 1 2 3; do
  if git push --atomic "$remote" HEAD:refs/heads/main "+refs/heads/$apk_branch:refs/heads/$apk_branch" "refs/tags/$retained_tag" \
      2>&1 | tee "$work/push.log"; then
    break
  fi
  if [[ "$attempt" == 3 ]] || ! grep -Eq 'Internal Server Error|requested URL returned error: (500|502|503|504)' "$work/push.log"; then
    exit 1
  fi
  echo "Transient server error publishing update feed; retrying ($attempt/3)." >&2
  sleep "$attempt"
done
echo "Published $release_tag; APK commit $revision retained by $retained_tag."
