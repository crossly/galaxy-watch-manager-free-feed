#!/usr/bin/env bash
set -euo pipefail
# Set ANDROID_SERIAL when more than one phone is attached.
PACKAGES=(
  com.samsung.android.waterplugin
  com.samsung.android.heartplugin
  com.samsung.wearable.watch6plugin
  com.samsung.wearable.watch7plugin
  com.samsung.android.app.watchmanager
  com.google.android.wearable.app.cn
  com.google.android.wearable.app
)
adb get-state >/dev/null
installed_packages=$(adb shell pm list packages --user 0 | tr -d '\r')
case "${1:-}" in
  disable-official)
    adb shell am force-stop dev.ricky.galaxywatchmanagerfree
    for package in "${PACKAGES[@]}"; do
      if grep -Fxq "package:$package" <<< "$installed_packages"; then
        adb shell pm disable-user --user 0 "$package"
      fi
    done
    ;;
  restore-official)
    adb shell am force-stop dev.ricky.galaxywatchmanagerfree
    for package in "${PACKAGES[@]}"; do
      if grep -Fxq "package:$package" <<< "$installed_packages"; then
        adb shell pm enable --user 0 "$package"
      fi
    done
    ;;
  *) echo "Usage: $0 disable-official|restore-official" >&2; exit 1 ;;
esac
