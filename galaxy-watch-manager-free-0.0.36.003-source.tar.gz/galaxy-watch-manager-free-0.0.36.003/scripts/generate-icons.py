#!/usr/bin/env python3
"""Generate matching SVG, PNG and Android vector icons.

Rendering prefers cairosvg; when it is absent, headless Chrome rasterizes the SVG
so the same artwork can still be regenerated on a plain macOS checkout.
"""
from pathlib import Path
import shutil
import subprocess
import tempfile
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / 'app/src/main/res'
ART = ROOT / 'artwork'
ANDROID = 'http://schemas.android.com/apk/res/android'
ET.register_namespace('android', ANDROID)

# Minimalist modern smartwatch icon:
# - Centered at (54, 54), footprint is ~38 x 45dp (compact, ample margin/white space).
# - Sleek matte silicone straps with soft rounded caps.
# - Galaxy Watch signature dual flat buttons on the right with Electric Blue accent.
# - Dark titanium case with deep AMOLED dial.
# - Bauhaus 10:10 minimalist hands (White hour hand, Electric Blue minute hand), crisp pivot and subtle dots.
STRAP = '#1E2638'
STRAP_GROOVE = '#334155'
BUTTON_TOP = '#2F80ED'
BUTTON_BOT = '#475569'
CASE_BODY = '#0F172A'
BEZEL_RING = '#2F80ED'
SCREEN_BG = '#070B14'
TICK_12 = '#94A3B8'
TICK_DOTS = '#475569'
HAND_HOUR = '#FFFFFF'
HAND_MIN = '#2F80ED'
PIVOT_OUTER = '#FFFFFF'
PIVOT_INNER = '#070B14'
CYAN_ACCENT = '#00D2D3'

PATHS = [
    # Top strap (rounded cap, width 16, y: 31..43)
    ('M 49.5,31 H 58.5 A 3.5,3.5 0 0 1 62,34.5 V 43 H 46 V 34.5 A 3.5,3.5 0 0 1 49.5,31 Z', STRAP, None, 0),
    # Bottom strap (rounded cap, width 16, y: 65..76)
    ('M 46,65 H 62 V 72.5 A 3.5,3.5 0 0 1 58.5,76 H 49.5 A 3.5,3.5 0 0 1 46,72.5 Z', STRAP, None, 0),
    # Strap vertical groove accents
    ('M 54,32 L 54,36', 'none', STRAP_GROOVE, 1.0),
    ('M 54,71.5 L 54,75', 'none', STRAP_GROOVE, 1.0),
    # Side buttons (Galaxy Watch signature dual flat buttons at 2 and 4 o'clock)
    ('M 71.5,45.5 H 72.5 A 1,1 0 0 1 73.5,46.5 V 48.5 A 1,1 0 0 1 72.5,49.5 H 71.5 Z', BUTTON_TOP, None, 0),
    ('M 71.5,58.5 H 72.5 A 1,1 0 0 1 73.5,59.5 V 61.5 A 1,1 0 0 1 72.5,62.5 H 71.5 Z', BUTTON_BOT, None, 0),
    # Watch Case (radius 18.5)
    ('M 54,35.5 A 18.5,18.5 0 1,1 53.99,35.5 Z', CASE_BODY, None, 0),
    # Inner Bezel Accent Halo
    ('M 54,37.5 A 16.5,16.5 0 1,1 53.99,37.5 Z', 'none', BEZEL_RING, 0.8),
    # AMOLED Screen (radius 15.0)
    ('M 54,39 A 15,15 0 1,1 53.99,39 Z', SCREEN_BG, None, 0),
    # Dial 12 o'clock tick
    ('M 54,41.2 L 54,43.5', 'none', TICK_12, 1.2),
    # Dial 3, 6, 9 o'clock subtle dots
    ('M 66.8,54 A 0.7,0.7 0 1,1 65.4,54 A 0.7,0.7 0 1,1 66.8,54 Z', TICK_DOTS, None, 0),
    ('M 54,66.8 A 0.7,0.7 0 1,1 52.6,66.8 A 0.7,0.7 0 1,1 54,66.8 Z', TICK_DOTS, None, 0),
    ('M 42.6,54 A 0.7,0.7 0 1,1 41.2,54 A 0.7,0.7 0 1,1 42.6,54 Z', TICK_DOTS, None, 0),
    # Hour hand (10:10, white, rounded cap)
    ('M 54,54 L 48.5,47.0', 'none', HAND_HOUR, 2.0),
    # Minute hand (2:08, Electric Blue, rounded cap)
    ('M 54,54 L 62.5,45.5', 'none', HAND_MIN, 1.6),
    # Center pivot
    ('M 55.6,54 A 1.6,1.6 0 1,1 52.4,54 A 1.6,1.6 0 1,1 55.6,54 Z', PIVOT_OUTER, None, 0),
    ('M 54.7,54 A 0.7,0.7 0 1,1 53.3,54 A 0.7,0.7 0 1,1 54.7,54 Z', PIVOT_INNER, None, 0),
    # Cyan accent spark near minute hand
    ('M 64.5,43.5 A 0.9,0.9 0 1,1 62.7,43.5 A 0.9,0.9 0 1,1 64.5,43.5 Z', CYAN_ACCENT, None, 0),
]

# Monochrome turns every colour to one hue, so the dial becomes an outline and
# the watch outline and hands stay visible on transparent/themed backgrounds.
MONO_PATHS = [
    # Straps
    ('M 49.5,31 H 58.5 A 3.5,3.5 0 0 1 62,34.5 V 43 H 46 V 34.5 A 3.5,3.5 0 0 1 49.5,31 Z', '#000000', None, 0),
    ('M 46,65 H 62 V 72.5 A 3.5,3.5 0 0 1 58.5,76 H 49.5 A 3.5,3.5 0 0 1 46,72.5 Z', '#000000', None, 0),
    # Buttons
    ('M 71.5,45.5 H 72.5 A 1,1 0 0 1 73.5,46.5 V 48.5 A 1,1 0 0 1 72.5,49.5 H 71.5 Z', '#000000', None, 0),
    ('M 71.5,58.5 H 72.5 A 1,1 0 0 1 73.5,59.5 V 61.5 A 1,1 0 0 1 72.5,62.5 H 71.5 Z', '#000000', None, 0),
    # Case outline
    ('M 54,35.5 A 18.5,18.5 0 1,1 53.99,35.5 Z', 'none', '#000000', 2.4),
    # Inner Bezel outline
    ('M 54,37.5 A 16.5,16.5 0 1,1 53.99,37.5 Z', 'none', '#000000', 1.0),
    # Dial markers & hands
    ('M 54,41.2 L 54,43.5', 'none', '#000000', 1.4),
    ('M 66.8,54 A 0.7,0.7 0 1,1 65.4,54 A 0.7,0.7 0 1,1 66.8,54 Z', '#000000', None, 0),
    ('M 54,66.8 A 0.7,0.7 0 1,1 52.6,66.8 A 0.7,0.7 0 1,1 54,66.8 Z', '#000000', None, 0),
    ('M 42.6,54 A 0.7,0.7 0 1,1 41.2,54 A 0.7,0.7 0 1,1 42.6,54 Z', '#000000', None, 0),
    ('M 54,54 L 48.5,47.0', 'none', '#000000', 2.2),
    ('M 54,54 L 62.5,45.5', 'none', '#000000', 1.8),
    ('M 55.6,54 A 1.6,1.6 0 1,1 52.4,54 A 1.6,1.6 0 1,1 55.6,54 Z', '#000000', None, 0),
]


def vector(paths, background=False):
    root = ET.Element('vector', {f'{{{ANDROID}}}{k}': v for k, v in {
        'width': '108dp', 'height': '108dp', 'viewportWidth': '108', 'viewportHeight': '108'
    }.items()})
    items = ([('M0,0 H108 V108 H0 Z', '#FFFFFF', None, 0)] if background else []) + paths
    for d, fill, stroke, width in items:
        attr = {'pathData': d, 'fillColor': '#00000000' if fill == 'none' else fill}
        if stroke:
            attr.update(strokeColor=stroke, strokeWidth=str(width),
                        strokeLineCap='round', strokeLineJoin='round')
        ET.SubElement(root, 'path', {f'{{{ANDROID}}}{k}': v for k, v in attr.items()})
    ET.indent(root)
    return ET.tostring(root, encoding='unicode') + '\n'


def svg_document(paths):
    body = ['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 108" '
            'width="1024" height="1024">',
            '<rect width="108" height="108" fill="#FFFFFF"/>']
    for d, fill, stroke, width in paths:
        body.append(f'<path d="{d}" fill="{fill}"')
        if stroke:
            body.append(f' stroke="{stroke}" stroke-width="{width}" '
                        f'stroke-linecap="round" stroke-linejoin="round"')
        body.append('/>')
    body.append('</svg>')
    return '\n'.join(body) + '\n'


def render(svg_text, png_path, size):
    """Rasterize an SVG at size x size, preferring cairosvg."""
    try:
        import cairosvg
    except ImportError:
        pass
    else:
        cairosvg.svg2png(bytestring=svg_text.encode(), write_to=str(png_path),
                         output_width=size, output_height=size)
        return

    chrome = shutil.which('google-chrome') or shutil.which('chromium') or (
        '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
        if Path('/Applications/Google Chrome.app').exists() else None)
    if not chrome:
        raise SystemExit('Install cairosvg or Google Chrome to rasterize the icon SVG.')

    with tempfile.TemporaryDirectory() as tmp:
        html = Path(tmp) / 'icon.html'
        html.write_text(
            '<html><body style="margin:0;background:#fff">'
            f'<img src="data:image/svg+xml;base64,{__import__("base64").b64encode(svg_text.encode()).decode()}"'
            f' width="{size}" height="{size}" style="display:block"></body></html>'
        )
        subprocess.run([
            chrome, '--headless=new', '--disable-gpu', '--hide-scrollbars',
            '--force-device-scale-factor=1', f'--screenshot={png_path}',
            f'--window-size={size},{size}', str(html),
        ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def main():
    ART.mkdir(exist_ok=True)
    svg = svg_document(PATHS)
    (ART / 'icon.svg').write_text(svg)
    render(svg, ART / 'icon.png', 1024)
    for density, size in [('mdpi', 48), ('hdpi', 72), ('xhdpi', 96), ('xxhdpi', 144), ('xxxhdpi', 192)]:
        target = RES / f'mipmap-{density}'
        target.mkdir(exist_ok=True)
        for name in ['ic_launcher.png', 'ic_launcher_round.png']:
            render(svg, target / name, size)
    (RES / 'drawable/ic_launcher_foreground.xml').write_text(vector(PATHS))
    (RES / 'drawable/ic_launcher_monochrome.xml').write_text(vector(MONO_PATHS))
    (RES / 'drawable/ic_launcher_background.xml').write_text(
        '<shape xmlns:android="http://schemas.android.com/apk/res/android" android:shape="rectangle">'
        '<solid android:color="#FFFFFF"/></shape>\n')
    for name in ['ic_launcher.xml', 'ic_launcher_round.xml']:
        (RES / 'mipmap-anydpi-v26'/name).write_text('''<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@drawable/ic_launcher_background" />
    <foreground android:drawable="@drawable/ic_launcher_foreground" />
    <monochrome android:drawable="@drawable/ic_launcher_monochrome" />
</adaptive-icon>
''')
    print('Generated SVG, 1024px preview, density PNGs and adaptive vectors.')


if __name__ == '__main__':
    main()
