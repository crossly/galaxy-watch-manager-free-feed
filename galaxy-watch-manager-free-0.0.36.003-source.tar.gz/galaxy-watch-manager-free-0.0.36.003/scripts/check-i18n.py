#!/usr/bin/env python3
"""Validate app-language catalogs and resource references without Android tooling."""
from __future__ import annotations

import re
import sys
from pathlib import Path
import xml.etree.ElementTree as ET

FORMAT = re.compile(r"%%|%(?:(\d+)\$)?[-#+ 0,(]*\d*(?:\.\d+)?([sdfoxXeEgGcCbBhH])")
REFERENCE = re.compile(r"\bR\s*\.\s*(string|plurals)\s*\.\s*(\w+)")


def format_signature(text: str) -> tuple[tuple[int, str], ...]:
    result = []
    next_index = 1
    for match in FORMAT.finditer(text):
        if match.group() == "%%":
            continue
        index = int(match[1]) if match[1] else next_index
        result.append((index, match[2].lower()))
        next_index = index + 1
    return tuple(sorted(set(result)))


def read_catalog(directory: Path) -> tuple[dict[tuple[str, str], dict[str, str]], list[str]]:
    catalog = {}
    errors = []
    for path in sorted(directory.glob("*.xml")):
        for entry in ET.parse(path).getroot():
            if entry.tag not in {"string", "plurals"}:
                continue
            key = (entry.tag, entry.attrib["name"])
            if key in catalog:
                errors.append(f"{directory.name}: duplicate {key[0]}/{key[1]}")
            if entry.tag == "string":
                catalog[key] = {"other": "".join(entry.itertext())}
            else:
                quantities = [item.attrib["quantity"] for item in entry]
                if "other" not in quantities or len(set(quantities)) != len(quantities):
                    errors.append(f"{directory.name}: invalid quantities for {key[1]}")
                catalog[key] = {
                    item.attrib["quantity"]: "".join(item.itertext()) for item in entry
                }
            for quantity, text in catalog[key].items():
                if format_signature(text) and "%" in FORMAT.sub("", text):
                    errors.append(f"{directory.name}: unescaped percent in {key[1]} ({quantity})")
    return catalog, errors


def check(root: Path) -> tuple[list[str], int, int]:
    res = root / "app/src/main/res"
    default, errors = read_catalog(res / "values")
    # Require all shipped languages to translate the same keys as the fallback catalog.
    locales = ET.parse(res / "xml/locales_config.xml").getroot()
    tags = [item.attrib["{http://schemas.android.com/apk/res/android}name"] for item in locales]
    directories = {"en": "values", "zh-CN": "values-zh-rCN"}
    for tag in tags:
        directory = directories.get(tag)
        if directory is None:
            parts = tag.split("-")
            candidates = ["values-b+" + "+".join(parts)]
            if len(parts) == 1:
                candidates.insert(0, "values-" + tag)
            elif len(parts) == 2 and len(parts[1]) == 2:
                candidates.insert(0, "values-" + parts[0] + "-r" + parts[1])
            directory = next((name for name in candidates if (res / name).is_dir()), candidates[0])
        if directory == "values":
            continue
        translated, issues = read_catalog(res / directory)
        errors.extend(issues)
        for key in sorted(default.keys() - translated.keys()):
            errors.append(f"{tag}: missing {key[0]}/{key[1]}")
        for key in sorted(translated.keys() - default.keys()):
            errors.append(f"{tag}: unknown {key[0]}/{key[1]}")
        for key in default.keys() & translated.keys():
            reference = format_signature(default[key]["other"])
            for quantity, text in translated[key].items():
                if format_signature(text) != reference:
                    errors.append(f"{tag}: format arguments differ for {key[1]} ({quantity})")
    for key, quantities in default.items():
        reference = format_signature(quantities["other"])
        for quantity, text in quantities.items():
            if format_signature(text) != reference:
                errors.append(f"en: format arguments differ for {key[1]} ({quantity})")
    for path in sorted((root / "app/src/main/java").rglob("*.kt")):
        for kind, name in REFERENCE.findall(path.read_text()):
            if (kind, name) not in default:
                errors.append(f"{path.relative_to(root)}: missing {kind}/{name}")
    return errors, len(default), len(tags)


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    errors, count, languages = check(root)
    if errors:
        print("\n".join(errors), file=sys.stderr)
        return 1
    print(f"i18n: {count} resources, {languages} languages; keys and format arguments match")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
