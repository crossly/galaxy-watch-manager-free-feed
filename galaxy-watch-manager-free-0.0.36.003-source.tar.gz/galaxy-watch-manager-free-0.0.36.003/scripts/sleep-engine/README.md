# Sleep runtime reconstruction profile

Default app builds include the vendor-derived runtime in `app/src/main/assets/sleep/`.
`engine.jar` embeds the stage model and quantile table; the bundle also contains the two
ARM native runtime sets, provenance notice, license text and SHA-256 manifest. The same files
are retained in corresponding source archives. Ordinary builds need no vendor APK or
additional Gradle property.

`build.py` reconstructs the runtime from one pinned local APK. It requires a JDK, Android
platform `android.jar`, Android build-tools R8/D8 JAR, dexlib2 plus Guava on a classpath,
and dex2jar 2.4 on a classpath. Tools and the input APK are caller supplied; the script
does not install, download or upload anything.

```sh
python3 scripts/sleep-engine/build.py /absolute/path/to/shealth.apk app/src/main \
  --dexlib-cp '/path/to/dexlib2.jar:/path/to/guava.jar:/path/to/failureaccess.jar' \
  --dex2jar-cp '/path/to/dex-tools-v2.4/lib/*' \
  --r8 '/path/to/android/build-tools/35.0.0/lib/d8.jar' \
  --android-jar '/path/to/android/platforms/android-36/android.jar'
python3 scripts/check_public_assets.py
```

The second positional argument is the output root, with the runtime written below its
`assets/sleep/`. If omitted, it defaults to the ignored `private/vendor-assets/` staging
area; app builds use the checked-in bundle regardless of that staging area's presence.
Keep `NOTICE.md` and `TENSORFLOW-LICENSE.txt` alongside the reconstructed files.

The input digest is checked before processing. `SleepDexSubset.java` selects the inference
classes, removes unrelated merged interfaces/entry points, and restores default constructors
whose calls were elided in the optimized DEX. `SleepConstructorPatch.java` retargets those
constructor calls for JVM conversion and replaces only the Gson row reader and monotonic
position check with small explicit implementations in `GalaxySleepEngine.java`. The actual
feature preprocessing, TensorFlow model, and stage alignment/postprocessing are preserved.
`rules.pro` keeps the dynamic entry point, JNI class names, and required generic metadata.
Only the bridge class, not its compilation stubs, enters the runtime.

Rebuilt output was replayed on an ARM64 phone against both the latest sensor record and a
known record: 636 / 728 final half-minute epochs exactly matched the full-source APK execution;
the known record also matched all 728 previously synchronized stage epochs. ARMv7 binaries
are included but have not been validated on an ARMv7 device.

This profile is deliberately pinned. Do not apply it to another vendor APK by changing only
the digest: class names, merged types, model versions, fields and JNI contracts can change.
Repackaging does not grant new redistribution rights or change ownership. See
`THIRD-PARTY.md`, `docs/SLEEP-ANALYSIS.md` and the asset notice for provenance and limitations.
