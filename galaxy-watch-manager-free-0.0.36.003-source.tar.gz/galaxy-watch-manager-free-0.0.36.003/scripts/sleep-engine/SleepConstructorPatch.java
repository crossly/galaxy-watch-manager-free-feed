import java.io.*;import java.util.*;import org.jf.dexlib2.*;import org.jf.dexlib2.iface.*;import org.jf.dexlib2.iface.instruction.*;import org.jf.dexlib2.iface.reference.*;import org.jf.dexlib2.immutable.*;import org.jf.dexlib2.immutable.instruction.*;import org.jf.dexlib2.immutable.reference.*;import org.jf.dexlib2.writer.pool.*;import org.jf.dexlib2.writer.io.*;
public class SleepConstructorPatch{
 public static void main(String[] a)throws Exception{
  DexFile f=DexFileFactory.loadDexFile(new File(a[0]),Opcodes.forApi(26));
  DexPool out=new DexPool(Opcodes.forApi(26));
  for(ClassDef c:f.getClasses()){
   List<Method> ms=new ArrayList<>();
   for(Method m:c.getMethods()){
    MethodImplementation impl=m.getImplementation();
    if(impl!=null){
     List<Instruction> is=new ArrayList<>();Map<Integer,String> types=new HashMap<>();boolean changed=false;
     for(Instruction i:impl.getInstructions()){
      if(i.getOpcode()==Opcode.NEW_INSTANCE){org.jf.dexlib2.iface.instruction.formats.Instruction21c x=(org.jf.dexlib2.iface.instruction.formats.Instruction21c)i;types.put(x.getRegisterA(),((TypeReference)x.getReference()).getType());}
      if(i.getOpcode()==Opcode.MOVE_OBJECT||i.getOpcode()==Opcode.MOVE_OBJECT_FROM16||i.getOpcode()==Opcode.MOVE_OBJECT_16){TwoRegisterInstruction x=(TwoRegisterInstruction)i;if(types.containsKey(x.getRegisterB()))types.put(x.getRegisterA(),types.get(x.getRegisterB()));}
      if(!m.getName().equals("<init>")&&i.getOpcode()==Opcode.INVOKE_DIRECT&&i instanceof org.jf.dexlib2.iface.instruction.formats.Instruction35c){
       org.jf.dexlib2.iface.instruction.formats.Instruction35c x=(org.jf.dexlib2.iface.instruction.formats.Instruction35c)i;Reference r=x.getReference();
       if(r instanceof MethodReference){MethodReference ref=(MethodReference)r;String type=types.get(x.getRegisterC());
        if(type!=null&&!type.equals("Ljava/lang/Object;")&&ref.getDefiningClass().equals("Ljava/lang/Object;")&&ref.getName().equals("<init>")&&x.getRegisterCount()==1){
         i=new ImmutableInstruction35c(Opcode.INVOKE_DIRECT,1,x.getRegisterC(),0,0,0,0,new ImmutableMethodReference(type,"<init>",Collections.emptyList(),"V"));changed=true;
        }
       }
      }
      if(i.getOpcode()==Opcode.INVOKE_STATIC&&i instanceof org.jf.dexlib2.iface.instruction.formats.Instruction35c){
       org.jf.dexlib2.iface.instruction.formats.Instruction35c x=(org.jf.dexlib2.iface.instruction.formats.Instruction35c)i;Reference r=x.getReference();
       if(r instanceof MethodReference){MethodReference ref=(MethodReference)r;
        if(ref.getDefiningClass().equals("Lli7;")&&ref.getName().equals("b")&&x.getRegisterCount()==1){
         i=new ImmutableInstruction35c(Opcode.INVOKE_STATIC,1,x.getRegisterC(),0,0,0,0,new ImmutableMethodReference("LGalaxySleepEngine;","rows",Collections.singletonList("Lorg/json/JSONObject;"),"Ljava/util/List;"));changed=true;
        }
       }
      }
      if(i.getOpcode()==Opcode.INVOKE_STATIC_RANGE&&i instanceof org.jf.dexlib2.iface.instruction.formats.Instruction3rc){
       org.jf.dexlib2.iface.instruction.formats.Instruction3rc x=(org.jf.dexlib2.iface.instruction.formats.Instruction3rc)i;Reference r=x.getReference();
       if(r instanceof MethodReference){MethodReference ref=(MethodReference)r;
        if(ref.getDefiningClass().equals("Lli7;")&&ref.getName().equals("b")&&x.getRegisterCount()==1){
         i=new ImmutableInstruction3rc(Opcode.INVOKE_STATIC_RANGE,x.getStartRegister(),1,new ImmutableMethodReference("LGalaxySleepEngine;","rows",Collections.singletonList("Lorg/json/JSONObject;"),"Ljava/util/List;"));changed=true;
        }
       }
      }
      if(i.getOpcode()==Opcode.INVOKE_STATIC&&i instanceof org.jf.dexlib2.iface.instruction.formats.Instruction35c){
       org.jf.dexlib2.iface.instruction.formats.Instruction35c x=(org.jf.dexlib2.iface.instruction.formats.Instruction35c)i;Reference r=x.getReference();
       if(r instanceof MethodReference){MethodReference ref=(MethodReference)r;
        if(ref.getDefiningClass().equals("Lazp;")&&ref.getName().equals("j")&&x.getRegisterCount()==1){
         i=new ImmutableInstruction35c(Opcode.INVOKE_STATIC,1,x.getRegisterC(),0,0,0,0,new ImmutableMethodReference("LGalaxySleepEngine;","monotonic",Collections.singletonList("[D"),"V"));changed=true;
        }
       }
      }
      is.add(i);
     }
     if(changed)impl=new ImmutableMethodImplementation(impl.getRegisterCount(),is,impl.getTryBlocks(),impl.getDebugItems());
    }
    ms.add(new ImmutableMethod(m.getDefiningClass(),m.getName(),m.getParameters(),m.getReturnType(),m.getAccessFlags(),m.getAnnotations(),m.getHiddenApiRestrictions(),impl));
   }
   out.internClass(new ImmutableClassDef(c.getType(),c.getAccessFlags(),c.getSuperclass(),c.getInterfaces(),c.getSourceFile(),c.getAnnotations(),c.getFields(),ms));
  }
  out.writeTo(new FileDataStore(new File(a[1])));
 }
}
