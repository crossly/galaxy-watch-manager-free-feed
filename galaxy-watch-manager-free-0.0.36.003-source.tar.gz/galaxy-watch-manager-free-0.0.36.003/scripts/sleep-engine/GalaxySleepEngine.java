import android.content.Context;
import java.util.*;
import org.json.*;
import com.samsung.msleepstagelib.StageInfo;

public final class GalaxySleepEngine {
    public static void monotonic(double[] values) {
        if(values.length==0)throw new IllegalArgumentException("Empty RRI positions");
        for(int i=1;i<values.length;i++)if(values[i]<=values[i-1])throw new IllegalArgumentException("RRI positions are not increasing");
    }
    public static List<l7c0> rows(JSONObject raw) throws Exception {
        JSONArray data=raw.getJSONArray("data");ArrayList<l7c0> rows=new ArrayList<>();
        for(int i=0;i<data.length();i++){
            JSONObject point=data.getJSONObject(i);JSONArray acc=point.getJSONArray("acc"),rr=point.getJSONArray("rri_info");
            l7c0 row=new l7c0();row.a=new double[acc.length()];row.b=new ArrayList<>();
            for(int j=0;j<acc.length();j++)row.a[j]=acc.getDouble(j);
            for(int j=0;j<rr.length();j++){JSONArray r=rr.getJSONArray(j);row.b.add(new h7c0(r.getInt(0),r.getInt(1),r.getInt(2)));}
            rows.add(row);
        }
        return rows;
    }
    public static String analyze(Context context, String sessionJson, String rawJson) throws Exception {
        JSONObject session=new JSONObject(sessionJson),raw=new JSONObject(rawJson);
        if(raw.getInt("version")!=2)throw new IllegalArgumentException("Unsupported sleep sensor version");
        int count=raw.getJSONArray("data").length();
        if(count<1||count>2880)throw new IllegalArgumentException("Invalid sleep epoch count");
        long start=session.optLong("original_bed_time",session.getLong("start_time"));
        long end=session.optLong("original_wake_up_time",session.getLong("end_time"));
        yd0 result=new tk((byte)0,26).o(start,session.optLong("bedtime_detection_delay"),end,
            session.optLong("wakeup_time_detection_delay"),raw,context,1);
        if(result.b!=1||result.c==null||result.c.isEmpty())throw new IllegalStateException("Sleep inference returned no four-stage result");
        JSONArray stages=new JSONArray();for(StageInfo point:result.c)stages.put(new JSONArray().put(point.timeStamp).put(point.data));
        return new JSONObject().put("native_efficiency",result.a).put("stages",stages).toString();
    }
}
