import java.io.*;
import java.util.*;
import org.jf.dexlib2.*;
import org.jf.dexlib2.iface.*;
import org.jf.dexlib2.iface.instruction.*;
import org.jf.dexlib2.iface.reference.*;
import org.jf.dexlib2.immutable.ImmutableClassDef;
import org.jf.dexlib2.writer.pool.DexPool;

public class SleepDexSubset {
 public static void main(String[] args) throws Exception {
  MultiDexContainer<?> container=DexFileFactory.loadDexContainer(new File(args[0]),Opcodes.forApi(26));
  Map<String,ClassDef> all=new HashMap<>();
  for(String entry:container.getDexEntryNames())for(ClassDef c:container.getEntry(entry).getDexFile().getClasses())all.put(c.getType(),c);
  Set<String> names=new HashSet<>(Arrays.asList("tk","g7y","yd0","q7c0","s7c0","u7c0","k7c0","g7c0","f7c0","j470","tn70","n7c0","t7c0","mfh","d72","jz10","hv50","li7","l7c0","h7c0","azp","dtz","j190","l6i","sgj","ce30","f7y"));
  List<ClassDef> selected=new ArrayList<>();
  for(ClassDef c:all.values()) {
   String n=c.getType();boolean root=n.equals("Ltk;");boolean parser=n.equals("Lhv50;")||n.equals("Lli7;");boolean helper=n.equals("Lazp;");
   if(!names.contains(n.substring(1,n.length()-1))&&!n.startsWith("Lorg/tensorflow/lite/")&&!n.startsWith("Lcom/google/gson/")&&!n.startsWith("Lcom/samsung/msleepstagelib/")&&!n.startsWith("Lcom/samsung/MultiDeviceSleep/stages/")&&!n.startsWith("Lmerge/"))continue;
   if(root||parser||helper){
    List<Method> methods=new ArrayList<>();
    for(Method m:c.getMethods()) {
     boolean keep=root?(m.getName().equals("o")||m.getName().equals("j")||m.getName().equals("d")||m.getName().equals("<init>")&&m.getParameterTypes().toString().equals("[B, I]")):helper?m.getName().equals("j"):(m.getName().equals("J")||m.getName().equals("b")&&m.getParameterTypes().toString().equals("[Lorg/json/JSONObject;]"));
     if(keep)methods.add(m);
    }
    c=new ImmutableClassDef(n,c.getAccessFlags(),c.getSuperclass(),Collections.emptyList(),c.getSourceFile(),c.getAnnotations(),c.getFields(),methods);
   }
   selected.add(c);
  }
  // Include direct references used by these selected classes without expanding their unrelated merged helpers.
  Set<String> refs=new TreeSet<>();
  for(ClassDef c:selected)for(Method m:c.getMethods())if(m.getImplementation()!=null)for(Instruction i:m.getImplementation().getInstructions())if(i instanceof ReferenceInstruction){
   Reference r=((ReferenceInstruction)i).getReference();
   if(r instanceof TypeReference)refs.add(((TypeReference)r).getType());
   if(r instanceof MethodReference)refs.add(((MethodReference)r).getDefiningClass());
   if(r instanceof FieldReference)refs.add(((FieldReference)r).getDefiningClass());
  }
  Set<String> present=new HashSet<>();for(ClassDef c:selected)present.add(c.getType());
  for(String name:refs)if(!present.contains(name)&&all.containsKey(name)){
   if(name.startsWith("Lj$/")||name.startsWith("Lkotlin/")||name.equals("Lcom/google/android/material/snackbar/a;")||name.equals("La;"))selected.add(all.get(name));
  }
  Set<String> constructible=new HashSet<>(Arrays.asList("Lj470;","Lyd0;","Lg7y;","Lf7c0;","Lk7c0;","Ll7c0;","Lu7c0;","Ltn70;"));
  List<ClassDef> patched=new ArrayList<>();
  for(ClassDef c:selected){
   List<Method> methods=new ArrayList<>();for(Method m:c.getMethods())methods.add(m);
   if(constructible.contains(c.getType())&&methods.stream().noneMatch(m->m.getName().equals("<init>"))){
    org.jf.dexlib2.builder.MutableMethodImplementation code=new org.jf.dexlib2.builder.MutableMethodImplementation(1);
    code.addInstruction(new org.jf.dexlib2.builder.instruction.BuilderInstruction35c(org.jf.dexlib2.Opcode.INVOKE_DIRECT,1,0,0,0,0,0,new org.jf.dexlib2.immutable.reference.ImmutableMethodReference("Ljava/lang/Object;","<init>",Collections.emptyList(),"V")));
    code.addInstruction(new org.jf.dexlib2.builder.instruction.BuilderInstruction10x(org.jf.dexlib2.Opcode.RETURN_VOID));
    methods.add(new org.jf.dexlib2.immutable.ImmutableMethod(c.getType(),"<init>",Collections.emptyList(),"V",0x10001,Collections.emptySet(),Collections.emptySet(),code));
    c=new ImmutableClassDef(c.getType(),c.getAccessFlags(),c.getSuperclass(),Collections.emptyList(),c.getSourceFile(),c.getAnnotations(),c.getFields(),methods);
   }
   patched.add(c);
  }
  DexPool pool=new DexPool(Opcodes.forApi(26));for(ClassDef c:patched)pool.internClass(c);pool.writeTo(new org.jf.dexlib2.writer.io.FileDataStore(new File(args[1])));
  System.out.println("selected="+selected.size());
  System.out.println("missing-direct="+refs.stream().filter(n->all.containsKey(n)&&!present.contains(n)).toList());
 }
}
