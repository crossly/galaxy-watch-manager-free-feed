#!/usr/bin/env python3
"""Package the exact release tree, including bundled runtime assets, without private material."""
import argparse
import gzip
import hashlib
from pathlib import Path
import re
import shutil
import subprocess
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[1]


def forbidden(path):
    parts = Path(path).parts
    return (
        any(part in {"private", ".git", ".env", "local.properties"} for part in parts)
        or path.endswith((".keystore", ".jks", ".apk"))
    )


def package(output, ref="HEAD", apk=None):
    revision = subprocess.check_output(
        ["git", "rev-parse", "--verify", f"{ref}^{{commit}}"], cwd=ROOT, text=True
    ).strip()
    paths = subprocess.check_output(
        ["git", "ls-tree", "-r", "--name-only", revision], cwd=ROOT, text=True
    ).splitlines()
    rejected = [path for path in paths if forbidden(path)]
    if rejected:
        raise SystemExit("Public source contains local-only assets: " + ", ".join(rejected))
    for required in ("LICENSE", "THIRD-PARTY.md", "CONTRIBUTING.md", "gradlew", "app/build.gradle"):
        if required not in paths:
            raise SystemExit(f"Corresponding source is missing {required}")
    if apk is not None:
        with ZipFile(apk) as archive:
            rejected = [path for path in archive.namelist() if forbidden(path)]
        if rejected:
            raise SystemExit("Public APK contains local-only assets: " + ", ".join(rejected))
    version = subprocess.check_output(
        ["git", "show", f"{revision}:version.properties"], cwd=ROOT, text=True
    )
    name = dict(line.split("=", 1) for line in version.splitlines())["VERSION_NAME"]
    if not re.fullmatch(r"0\.0\.[1-9][0-9]*(?:\.[0-9]{3})?", name):
        raise SystemExit("Invalid source version")
    prefix = f"galaxy-watch-manager-free-{name}"
    output.mkdir(parents=True, exist_ok=True)
    target = output / f"{prefix}-source.tar.gz"
    with target.open("wb") as handle:
        with gzip.GzipFile(fileobj=handle, mode="wb", filename="", mtime=0) as compressed:
            with subprocess.Popen(
                ["git", "archive", "--format=tar", f"--prefix={prefix}/", revision],
                cwd=ROOT, stdout=subprocess.PIPE,
            ) as process:
                shutil.copyfileobj(process.stdout, compressed)
                if process.wait() != 0:
                    raise SystemExit("git archive failed")
    checksum = hashlib.sha256(target.read_bytes()).hexdigest()
    target.with_suffix(target.suffix + ".sha256").write_text(f"{checksum}  {target.name}\n")
    print(f"Packaged source {revision}: {target}")
    return target


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    parser.add_argument("--ref", default="HEAD")
    parser.add_argument("--apk", type=Path)
    args = parser.parse_args()
    package(args.output, args.ref, args.apk)


if __name__ == "__main__":
    main()
