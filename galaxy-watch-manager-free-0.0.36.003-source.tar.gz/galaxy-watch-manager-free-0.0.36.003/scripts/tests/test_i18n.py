import importlib.util
from pathlib import Path
import tempfile
import unittest

SCRIPT = Path(__file__).resolve().parents[1] / "check-i18n.py"
spec = importlib.util.spec_from_file_location("check_i18n", SCRIPT)
check_i18n = importlib.util.module_from_spec(spec)
spec.loader.exec_module(check_i18n)


class I18nCheckTest(unittest.TestCase):
    def project(self, default, chinese, kotlin=""):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        root = Path(temporary.name)
        res = root / "app/src/main/res"
        for directory, content in [("values", default), ("values-zh-rCN", chinese)]:
            path = res / directory / "strings.xml"
            path.parent.mkdir(parents=True)
            path.write_text("<resources>" + content + "</resources>")
        config = res / "xml/locales_config.xml"
        config.parent.mkdir()
        config.write_text('<locale-config xmlns:android="http://schemas.android.com/apk/res/android">'
                          '<locale android:name="en"/><locale android:name="zh-CN"/></locale-config>')
        source = root / "app/src/main/java/Screen.kt"
        source.parent.mkdir(parents=True)
        source.write_text(kotlin)
        return root

    def test_shipped_catalogs_are_complete(self):
        errors, count, languages = check_i18n.check(SCRIPT.parents[1])
        self.assertEqual([], errors)
        self.assertGreater(count, 100)
        self.assertEqual(2, languages)

    def test_missing_translation_is_rejected(self):
        root = self.project('<string name="title">Title</string>', '')
        self.assertTrue(any('missing string/title' in e for e in check_i18n.check(root)[0]))

    def test_argument_type_mismatch_is_rejected(self):
        root = self.project('<string name="count">%1$d records</string>',
                            '<string name="count">%1$s 条记录</string>')
        self.assertTrue(any('format arguments differ' in e for e in check_i18n.check(root)[0]))

    def test_plural_forms_can_reorder_arguments_but_cannot_drop_them(self):
        default = '<plurals name="count"><item quantity="one">%1$d %2$s</item>' \
                  '<item quantity="other">%2$s %1$d</item></plurals>'
        chinese = '<plurals name="count"><item quantity="other">%2$s %1$d</item></plurals>'
        self.assertEqual([], check_i18n.check(self.project(default, chinese))[0])
        bad = chinese.replace('%1$d', '')
        self.assertTrue(check_i18n.check(self.project(default, bad))[0])

    def test_duplicate_resource_and_missing_reference_are_rejected(self):
        default = '<string name="title">Title</string>' * 2
        errors = check_i18n.check(self.project(default, default, 'R.string\n    .missing'))[0]
        self.assertTrue(any('duplicate' in e for e in errors))
        self.assertTrue(any('missing string/missing' in e for e in errors))

    def test_formatted_percent_must_be_escaped(self):
        default = '<string name="value">%1$d%</string>'
        self.assertTrue(any('unescaped percent' in e
                            for e in check_i18n.check(self.project(default, default))[0]))
        escaped = default.replace('%1$d%', '%1$d%%')
        self.assertEqual([], check_i18n.check(self.project(escaped, escaped))[0])


if __name__ == '__main__':
    unittest.main()
