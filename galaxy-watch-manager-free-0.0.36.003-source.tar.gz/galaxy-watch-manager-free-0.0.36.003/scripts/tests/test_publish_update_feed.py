import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
import tempfile
import textwrap
import unittest

ROOT = Path(__file__).resolve().parents[2]


class PublishUpdateFeedTests(unittest.TestCase):
    def test_published_apk_is_immutable_and_old_release_cannot_roll_back_feed(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            remote = folder / "feed.git"
            seed = folder / "seed"

            def git(*args, cwd=None):
                return subprocess.check_output(["git", *args], cwd=cwd, text=True, stderr=subprocess.DEVNULL).strip()

            git("init", "--bare", str(remote))
            git("clone", str(remote), str(seed))
            git("checkout", "-b", "main", cwd=seed)
            git("config", "user.name", "Test", cwd=seed)
            git("config", "user.email", "test@example.invalid", cwd=seed)
            (seed / "version.json").write_text('{"version_code":1}')
            (seed / "README.md").write_text("feed")
            git("add", ".", cwd=seed)
            git("commit", "-m", "seed", cwd=seed)
            git("push", "origin", "main", cwd=seed)
            git("symbolic-ref", "HEAD", "refs/heads/main", cwd=remote)
            version = dict(line.split("=", 1) for line in (ROOT / "version.properties").read_text().splitlines())
            tag = "v" + version["VERSION_NAME"]
            feed_file = "nightly.json" if version["VERSION_NAME"].count(".") == 3 else "version.json"
            apk_branch = "apk-nightly" if feed_file == "nightly.json" else "apk"
            apk = folder / "signed.apk"
            apk.write_bytes(b"signed release fixture")
            source_archive = folder / "fixture-source.tar.gz"
            source_archive.write_bytes(b"synthetic corresponding source")
            command = [str(ROOT / "scripts/publish-update-feed.sh"), str(remote), str(apk), tag, str(source_archive)]
            def publish():
                result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True,
                                        env={**os.environ, "GH_TOKEN": ""})
                self.assertEqual(0, result.returncode, result.stdout + result.stderr)

            publish()
            entry = json.loads(git("show", f"main:{feed_file}", cwd=remote))
            revision = git("rev-parse", apk_branch, cwd=remote)
            self.assertIn("/" + revision + "/", entry["apk_url"])
            self.assertEqual(hashlib.sha256(apk.read_bytes()).hexdigest(), entry["sha256"])
            self.assertIn("/" + revision + "/", entry["source_url"])
            self.assertEqual(hashlib.sha256(source_archive.read_bytes()).hexdigest(), entry["source_sha256"])
            self.assertEqual(source_archive.read_text(), git("show", f"{revision}:{entry['source_name']}", cwd=remote))
            self.assertEqual("feed", git("show", "main:README.md", cwd=remote))
            # Force-moving the latest branch must not make the advertised commit unreachable.
            self.assertTrue(git("tag", "--contains", revision, cwd=remote).startswith("apk-v"))
            publish()
            self.assertEqual(revision, git("rev-parse", apk_branch, cwd=remote))
            # A rebuilt package gets a new immutable URL while the original still resolves.
            apk.write_bytes(b"rebuilt signed release fixture")
            publish()
            self.assertEqual("signed release fixture", git("show", f"{revision}:{entry['apk_name']}", cwd=remote))
            revision = git("rev-parse", apk_branch, cwd=remote)
            newer = folder / "newer"
            git("clone", str(remote), str(newer))
            git("config", "user.name", "Test", cwd=newer)
            git("config", "user.email", "test@example.invalid", cwd=newer)
            entry["version_code"] += 1
            (newer / feed_file).write_text(json.dumps(entry))
            git("add", ".", cwd=newer)
            git("commit", "-m", "newer version", cwd=newer)
            git("push", "origin", "main", cwd=newer)
            main_before = git("rev-parse", "main", cwd=remote)
            publish()
            self.assertEqual(main_before, git("rev-parse", "main", cwd=remote))
            self.assertEqual(revision, git("rev-parse", apk_branch, cwd=remote))

    def test_channels_publish_independently_and_keep_old_apk_revisions(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            remote, seed, source = folder / "feed.git", folder / "seed", folder / "source"

            def git(*args, cwd=None):
                return subprocess.check_output(["git", *args], cwd=cwd, text=True, stderr=subprocess.DEVNULL).strip()

            git("init", "--bare", str(remote))
            git("clone", str(remote), str(seed))
            git("checkout", "-b", "main", cwd=seed)
            git("config", "user.name", "Test", cwd=seed)
            git("config", "user.email", "test@example.invalid", cwd=seed)
            (seed / "version.json").write_text('{"version_name":"0.0.32","version_code":32}')
            git("add", ".", cwd=seed)
            git("commit", "-m", "seed", cwd=seed)
            git("push", "origin", "main", cwd=seed)
            git("symbolic-ref", "HEAD", "refs/heads/main", cwd=remote)
            source.mkdir()
            (source / "scripts").mkdir()
            for name in ("version.py", "write-update-feed.py", "publish-update-feed.sh"):
                shutil.copy2(ROOT / "scripts" / name, source / "scripts" / name)
            git("init", cwd=source)
            git("config", "user.name", "Test", cwd=source)
            git("config", "user.email", "test@example.invalid", cwd=source)
            apk = folder / "signed.apk"
            apk.write_bytes(b"synthetic signed apk")

            def publish(name, code):
                (source / "version.properties").write_text(f"VERSION_NAME={name}\nVERSION_CODE={code}\n")
                git("add", "scripts", "version.properties", cwd=source)
                git("commit", "-m", name, cwd=source)
                result = subprocess.run([str(source / "scripts/publish-update-feed.sh"), str(remote), str(apk), "v" + name],
                                        cwd=source, capture_output=True, text=True,
                                        env={**os.environ, "GH_TOKEN": ""})
                self.assertEqual(0, result.returncode, result.stdout + result.stderr)
                return result

            publish("0.0.32", 32)
            stable_json = git("show", "main:version.json", cwd=remote)
            stable_revision = git("rev-parse", "apk", cwd=remote)
            # A later source commit with the same version and artifact must reuse the retained commit.
            subprocess.run(["git", "commit", "--allow-empty", "-m", "source metadata changed"],
                           cwd=source, check=True, capture_output=True,
                           env={**os.environ, "GIT_COMMITTER_DATE": "2001-01-01T00:00:00Z"})
            result = subprocess.run(
                [str(source / "scripts/publish-update-feed.sh"), str(remote), str(apk), "v0.0.32"],
                cwd=source, capture_output=True, text=True, env={**os.environ, "GH_TOKEN": ""},
            )
            self.assertEqual(0, result.returncode, result.stdout + result.stderr)
            self.assertEqual(stable_revision, git("rev-parse", "apk", cwd=remote))
            publish("0.0.32.001", 32001)
            first_nightly = json.loads(git("show", "main:nightly.json", cwd=remote))
            first_revision = git("rev-parse", "apk-nightly", cwd=remote)
            self.assertEqual("nightly", first_nightly["channel"])
            self.assertIn("/" + first_revision + "/", first_nightly["apk_url"])
            self.assertEqual(stable_json, git("show", "main:version.json", cwd=remote))
            self.assertEqual(stable_revision, git("rev-parse", "apk", cwd=remote))
            publish("0.0.32.002", 32002)
            nightly_json = git("show", "main:nightly.json", cwd=remote)
            nightly_revision = git("rev-parse", "apk-nightly", cwd=remote)
            self.assertEqual("synthetic signed apk", git("show", f"{first_revision}:{first_nightly['apk_name']}", cwd=remote))
            self.assertTrue(git("tag", "--contains", first_revision, cwd=remote))
            previous_refs = git("show-ref", cwd=remote)
            self.assertIn("newer version", publish("0.0.32.001", 32001).stdout)
            self.assertEqual(previous_refs, git("show-ref", cwd=remote))
            publish("0.0.33", 33000)
            self.assertEqual("0.0.33", json.loads(git("show", "main:version.json", cwd=remote))["version_name"])
            self.assertEqual(nightly_json, git("show", "main:nightly.json", cwd=remote))
            self.assertEqual(nightly_revision, git("rev-parse", "apk-nightly", cwd=remote))
            previous_refs = git("show-ref", cwd=remote)
            self.assertIn("newer version", publish("0.0.32", 32).stdout)
            self.assertEqual(previous_refs, git("show-ref", cwd=remote))
            # A newer stable must not prevent an independent Nightly feed update.
            publish("0.0.32.003", 32003)
            self.assertEqual("0.0.33", json.loads(git("show", "main:version.json", cwd=remote))["version_name"])
            self.assertEqual("0.0.32.003", json.loads(git("show", "main:nightly.json", cwd=remote))["version_name"])

    def test_only_transient_server_push_errors_are_retried(self):
        cases = [
            ("remote: Internal Server Error", 1, 2, True),
            ("fatal: unable to access remote: The requested URL returned error: 503", 3, 3, False),
            ("! [rejected] HEAD -> main (non-fast-forward)", 1, 1, False),
            ("Authentication failed (publickey).", 1, 1, False),
        ]
        for message, failures, attempts, success in cases:
            with self.subTest(message=message), tempfile.TemporaryDirectory() as tmp:
                folder = Path(tmp)
                remote = folder / "feed.git"
                seed = folder / "seed"
                real_git = shutil.which("git")

                def git(*args, cwd=None):
                    return subprocess.check_output(
                        [real_git, *args], cwd=cwd, text=True, stderr=subprocess.DEVNULL
                    ).strip()

                git("init", "--bare", str(remote))
                git("clone", str(remote), str(seed))
                git("checkout", "-b", "main", cwd=seed)
                git("config", "user.name", "Test", cwd=seed)
                git("config", "user.email", "test@example.invalid", cwd=seed)
                (seed / "version.json").write_text('{"version_code":1}')
                git("add", "version.json", cwd=seed)
                git("commit", "-m", "seed", cwd=seed)
                git("push", "origin", "main", cwd=seed)
                git("symbolic-ref", "HEAD", "refs/heads/main", cwd=remote)
                previous = git("rev-parse", "main", cwd=remote)
                tools = folder / "bin"
                tools.mkdir()
                counter = folder / "push-count"
                wrapper = tools / "git"
                wrapper.write_text(f"#!{sys.executable}\n" + textwrap.dedent('''\
                    import os, pathlib, sys
                    if sys.argv[1] == "push":
                        counter = pathlib.Path(os.environ["TEST_PUSH_COUNT"])
                        count = int(counter.read_text()) + 1 if counter.exists() else 1
                        counter.write_text(str(count))
                        if count <= int(os.environ["TEST_PUSH_FAILURES"]):
                            print(os.environ["TEST_PUSH_ERROR"], file=sys.stderr)
                            sys.exit(128)
                    os.execv(os.environ["TEST_REAL_GIT"], ["git", *sys.argv[1:]])
                    '''))
                wrapper.chmod(0o755)
                apk = folder / "signed.apk"
                apk.write_bytes(b"signed release fixture")
                version = dict(line.split("=", 1) for line in (ROOT / "version.properties").read_text().splitlines())
                feed_file = "nightly.json" if version["VERSION_NAME"].count(".") == 3 else "version.json"
                result = subprocess.run(
                    [str(ROOT / "scripts/publish-update-feed.sh"), str(remote), str(apk), "v" + version["VERSION_NAME"]],
                    cwd=ROOT, capture_output=True, text=True,
                    env={**os.environ, "GH_TOKEN": "", "PATH": str(tools) + os.pathsep + os.environ["PATH"],
                         "TEST_REAL_GIT": real_git, "TEST_PUSH_COUNT": str(counter),
                         "TEST_PUSH_FAILURES": str(failures), "TEST_PUSH_ERROR": message},
                )
                self.assertEqual(success, result.returncode == 0, result.stdout + result.stderr)
                self.assertEqual(attempts, int(counter.read_text()))
                self.assertIn(message, result.stdout + result.stderr)
                if success:
                    entry = json.loads(git("show", f"main:{feed_file}", cwd=remote))
                    self.assertEqual(version["VERSION_NAME"], entry["version_name"])
                else:
                    self.assertEqual(previous, git("rev-parse", "main", cwd=remote))
                    self.assertEqual("", git("tag", cwd=remote))


class FeedSshWorkflowTests(unittest.TestCase):
    def run_feed_step(self, probe_failures=0, publish_status=0):
        workflow = (ROOT / ".github/workflows/release.yml").read_text()
        step = workflow.split("      - name: Publish update feed\n", 1)[1].split(
            "      - name: Remove feed deploy key file\n", 1
        )[0]
        command = textwrap.dedent(step.split("        run: |\n", 1)[1])
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            tools = folder / "bin"
            tools.mkdir()
            (folder / "scripts").mkdir()
            (folder / "artifacts").mkdir()
            (folder / "artifacts/signed.apk").write_bytes(b"signed fixture")
            (folder / "artifacts/fixture-source.tar.gz").write_bytes(b"source fixture")
            git = tools / "git"
            git.write_text(f"#!{sys.executable}\n" + textwrap.dedent('''\
                import json, os, pathlib, sys
                log = pathlib.Path(os.environ["TEST_PROBE_LOG"])
                calls = json.loads(log.read_text()) if log.exists() else []
                calls.append({"args": sys.argv[1:], "ssh": os.environ.get("GIT_SSH_COMMAND", "")})
                log.write_text(json.dumps(calls))
                if len(calls) <= int(os.environ["TEST_PROBE_FAILURES"]):
                    print("fixture: SSH remote unavailable", file=sys.stderr)
                    sys.exit(128)
                '''))
            git.chmod(0o755)
            publisher = folder / "scripts/publish-update-feed.sh"
            publisher.write_text(f"#!{sys.executable}\n" + textwrap.dedent('''\
                import json, os, pathlib, sys
                pathlib.Path(os.environ["TEST_PUBLISH_LOG"]).write_text(json.dumps({
                    "args": sys.argv[1:], "ssh": os.environ.get("GIT_SSH_COMMAND", "")
                }))
                sys.exit(int(os.environ["TEST_PUBLISH_STATUS"]))
                '''))
            publisher.chmod(0o755)
            result = subprocess.run(
                ["bash", "-c", command], cwd=folder, capture_output=True, text=True,
                env={**os.environ, "PATH": str(tools) + os.pathsep + os.environ["PATH"],
                     "RUNNER_TEMP": str(folder / "runner temp"), "FEED_DEPLOY_KEY": "private key fixture",
                     "RELEASE_TAG": "v0.0.30", "TEST_PROBE_LOG": str(folder / "probes.json"),
                     "TEST_PROBE_FAILURES": str(probe_failures), "TEST_PUBLISH_LOG": str(folder / "publish.json"),
                     "TEST_PUBLISH_STATUS": str(publish_status)},
            )
            probes = json.loads((folder / "probes.json").read_text())
            published = folder / "publish.json"
            return result, probes, json.loads(published.read_text()) if published.exists() else None

    def test_primary_ssh_has_bounded_noninteractive_options_and_quoted_key_path(self):
        result, probes, published = self.run_feed_step()
        self.assertEqual(0, result.returncode, result.stderr)
        self.assertEqual(1, len(probes))
        self.assertEqual("git@github.com:crossly/galaxy-watch-manager-free-feed.git", published["args"][0])
        options = shlex.split(published["ssh"])
        self.assertIn("BatchMode=yes", options)
        self.assertIn("ConnectTimeout=10", options)
        self.assertTrue(options[options.index("-i") + 1].endswith("runner temp/feed-ssh/id_ed25519"))

    def test_falls_back_to_ssh_over_443_and_keeps_diagnostics(self):
        result, probes, published = self.run_feed_step(probe_failures=1)
        self.assertEqual(0, result.returncode, result.stderr)
        self.assertEqual(2, len(probes))
        self.assertIn("fixture: SSH remote unavailable", result.stderr)
        self.assertEqual("git@ssh.github.com:crossly/galaxy-watch-manager-free-feed.git", published["args"][0])
        self.assertIn("443", shlex.split(published["ssh"]))

    def test_retries_temporary_probe_failures(self):
        result, probes, published = self.run_feed_step(probe_failures=2)
        self.assertEqual(0, result.returncode, result.stderr)
        self.assertEqual(3, len(probes))
        self.assertIsNotNone(published)

    def test_all_probe_failures_stop_before_publishing_with_diagnostics(self):
        result, probes, published = self.run_feed_step(probe_failures=99)
        self.assertNotEqual(0, result.returncode)
        self.assertEqual(6, len(probes))
        self.assertIsNone(published)
        self.assertIn("fixture: SSH remote unavailable", result.stderr)
        self.assertIn("::error::", result.stderr)

    def test_publisher_failure_is_not_reported_as_success(self):
        result, _, _ = self.run_feed_step(publish_status=17)
        self.assertEqual(17, result.returncode)
        workflow = (ROOT / ".github/workflows/release.yml").read_text()
        step = workflow.split("      - name: Publish update feed\n", 1)[1].split("        run: |", 1)[0]
        self.assertNotIn("continue-on-error: true", step)
