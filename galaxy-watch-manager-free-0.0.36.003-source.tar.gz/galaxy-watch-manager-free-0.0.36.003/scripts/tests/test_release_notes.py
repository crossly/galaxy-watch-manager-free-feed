import importlib.util
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location("release_notes", ROOT / "scripts/release-notes.py")
source = importlib.util.module_from_spec(spec)
spec.loader.exec_module(source)


class ReleaseNotesTests(unittest.TestCase):
    NOTES = """# Release notes

## 0.0.36.002 Nightly

- Second nightly change.

## 0.0.36.001 Nightly

- First nightly change.

## 0.0.36

- Stable change.
"""

    def test_extracts_only_the_requested_nightly_section(self):
        self.assertEqual(
            "## 0.0.36.002 Nightly\n\n- Second nightly change.\n",
            source.extract(self.NOTES, "0.0.36.002"),
        )

    def test_extracts_only_the_requested_stable_section(self):
        self.assertEqual(
            "## 0.0.36\n\n- Stable change.\n",
            source.extract(self.NOTES, "0.0.36"),
        )

    def test_rejects_missing_section(self):
        with self.assertRaises(SystemExit) as raised:
            source.extract(self.NOTES, "0.0.37")
        self.assertIn("found 0", str(raised.exception))

    def test_rejects_duplicate_section(self):
        duplicated = self.NOTES + "\n## 0.0.36.001 Nightly\n\n- Duplicate.\n"
        with self.assertRaises(SystemExit) as raised:
            source.extract(duplicated, "0.0.36.001")
        self.assertIn("found 2", str(raised.exception))

    def test_rejects_empty_section(self):
        with self.assertRaises(SystemExit) as raised:
            source.extract("## 0.0.36.001 Nightly\n\n## 0.0.36\n\n- Stable.\n", "0.0.36.001")
        self.assertIn("empty", str(raised.exception))

    def test_cli_writes_selected_version(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            notes = folder / "RELEASE-NOTES.md"
            notes.write_text(self.NOTES)
            output = folder / "out/release-notes.md"
            result = subprocess.run(
                [
                    sys.executable,
                    str(ROOT / "scripts/release-notes.py"),
                    "--tag",
                    "v0.0.36.001",
                    "--notes",
                    str(notes),
                    "--output",
                    str(output),
                ],
                capture_output=True,
                text=True,
            )
            self.assertEqual(0, result.returncode, result.stdout + result.stderr)
            self.assertEqual("## 0.0.36.001 Nightly\n\n- First nightly change.\n", output.read_text())

    def test_current_version_has_a_release_notes_section(self):
        values = dict(
            line.split("=", 1)
            for line in (ROOT / "version.properties").read_text().splitlines()
            if "=" in line
        )
        section = source.extract((ROOT / "docs/RELEASE-NOTES.md").read_text(), values["VERSION_NAME"].strip())
        self.assertTrue(section.startswith("## "))


if __name__ == "__main__":
    unittest.main()
