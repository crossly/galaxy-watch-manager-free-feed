import importlib.util
from pathlib import Path
import tempfile
import unittest

spec = importlib.util.spec_from_file_location("version", Path(__file__).resolve().parents[1] / "version.py")
version = importlib.util.module_from_spec(spec)
spec.loader.exec_module(version)


class VersionTests(unittest.TestCase):
    def check(self, contents):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "version.properties"
            path.write_text(contents)
            original = version.VERSION_FILE
            try:
                version.VERSION_FILE = path
                return version.read_version()
            finally:
                version.VERSION_FILE = original

    def test_initial(self):
        self.assertEqual(self.check("VERSION_NAME=0.0.1\nVERSION_CODE=1\n"), ("0.0.1", 1))

    def test_codes_remain_unique_after_99(self):
        self.assertEqual(self.check("VERSION_NAME=0.0.100\nVERSION_CODE=100\n"), ("0.0.100", 100))

    def test_reject_mismatch(self):
        with self.assertRaises(SystemExit):
            self.check("VERSION_NAME=0.0.2\nVERSION_CODE=1\n")

    def test_reject_major_minor_change(self):
        with self.assertRaises(SystemExit):
            self.check("VERSION_NAME=0.1.1\nVERSION_CODE=1\n")

    def test_reject_leading_zero(self):
        with self.assertRaises(SystemExit):
            self.check("VERSION_NAME=0.0.01\nVERSION_CODE=1\n")

    def test_scaled_stable_and_nightly_codes(self):
        self.assertEqual(self.check("VERSION_NAME=0.0.32\nVERSION_CODE=32000\n"), ("0.0.32", 32000))
        self.assertEqual(self.check("VERSION_NAME=0.0.32.001\nVERSION_CODE=32001\n"), ("0.0.32.001", 32001))
        self.assertEqual("stable", version.version_channel("0.0.32"))
        self.assertEqual("nightly", version.version_channel("0.0.32.999"))

    def test_nightly_sequence_and_next_stable(self):
        self.assertEqual(("0.0.32.001", 32001), version.next_version("0.0.32", "nightly"))
        self.assertEqual(("0.0.32.002", 32002), version.next_version("0.0.32.001", "nightly"))
        self.assertEqual(("0.0.33", 33000), version.next_version("0.0.32.999"))
        self.assertEqual(("0.0.33.001", 33001), version.next_version("0.0.33", "nightly"))

    def test_old_stable_rerun_cannot_replace_newer_latest(self):
        self.assertTrue(version.should_mark_latest("0.0.32", []))
        self.assertTrue(version.should_mark_latest("0.0.32", ["v0.0.9", "v0.0.32", "v0.0.33.001"]))
        self.assertFalse(version.should_mark_latest("0.0.32", ["v0.0.33"]))
        self.assertFalse(version.should_mark_latest("0.0.32.001", ["v0.0.31"]))

    def test_android_code_order_and_bounds(self):
        names = ["0.0.30", "0.0.30.001", "0.0.30.002", "0.0.30.999", "0.0.31"]
        self.assertEqual([30000, 30001, 30002, 30999, 31000], [version.version_code(name) for name in names])
        self.assertEqual(2_100_000_000, version.version_code("0.0.2100000"))
        for name in ("0.0.2100000.001", "0.0.2100001"):
            with self.subTest(name=name), self.assertRaises(SystemExit):
                version.version_code(name)
        with self.assertRaises(SystemExit):
            version.next_version("0.0.32.999", "nightly")

    def test_rejects_invalid_nightly_suffixes_and_code(self):
        for name in ("0.0.32.000", "0.0.32.1", "0.0.32.01", "0.0.32.1000", "0.0.032.001"):
            with self.subTest(name=name), self.assertRaises(SystemExit):
                version.version_code(name)
        with self.assertRaises(SystemExit):
            self.check("VERSION_NAME=0.0.32.001\nVERSION_CODE=32\n")


if __name__ == "__main__":
    unittest.main()
