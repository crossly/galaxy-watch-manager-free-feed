import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

spec = importlib.util.spec_from_file_location(
    "write_update_feed", Path(__file__).resolve().parents[1] / "write-update-feed.py"
)
feed = importlib.util.module_from_spec(spec)
spec.loader.exec_module(feed)


class WriteUpdateFeedTests(unittest.TestCase):
    def release(self, **overrides):
        data = {
            "published_at": "2026-10-27T02:51:21Z",
            "html_url": "https://github.com/crossly/galaxy-watch-manager-free/releases/tag/v0.0.4",
            "body": "  - 新图标\n  - 更新检测  ",
            "assets": [
                {"name": "galaxy-watch-manager-free-0.0.4.apk.sha256", "digest": "sha256:aa"},
                {
                    "name": "galaxy-watch-manager-free-0.0.4.apk",
                    "digest": "sha256:" + "b" * 64,
                },
            ],
        }
        data.update(overrides)
        return data

    def test_builds_entry_from_release(self):
        entry = feed.build_entry("0.0.4", 4, "v0.0.4", self.release())
        self.assertEqual("0.0.4", entry["version_name"])
        self.assertEqual(4, entry["version_code"])
        self.assertEqual("https://github.com/crossly/galaxy-watch-manager-free/releases/tag/v0.0.4", entry["page_url"])
        self.assertEqual("galaxy-watch-manager-free-0.0.4.apk", entry["apk_name"])
        self.assertEqual("b" * 64, entry["sha256"])
        self.assertTrue(entry["notes"].startswith("- 新图标"))
        self.assertNotIn("  ", entry["notes"])

    def test_stub_still_points_at_release_page(self):
        entry = feed.build_entry("0.0.5", 5, "v0.0.5", None)
        self.assertEqual("0.0.5", entry["version_name"])
        self.assertIsNone(entry["published_at"])
        self.assertIsNone(entry["apk_name"])
        self.assertTrue(entry["page_url"].endswith("/tag/v0.0.5"))

    def test_ignores_assets_without_apk_or_digest(self):
        entry = feed.build_entry(
            "0.0.6", 6, "v0.0.6",
            self.release(assets=[{"name": "notes.txt"}, {"name": "app.apk"}]),
        )
        self.assertEqual("app.apk", entry["apk_name"])
        self.assertIsNone(entry["sha256"])

    def test_notes_are_capped(self):
        entry = feed.build_entry("0.0.7", 7, "v0.0.7", self.release(body="y" * 5000))
        self.assertEqual(1000, len(entry["notes"]))


    def test_public_apk_name_and_url_agree(self):
        self.assertEqual(
            "galaxy-watch-manager-free-0.0.6.apk", feed.apk_file_name("0.0.6")
        )
        self.assertEqual(
            "https://raw.githubusercontent.com/crossly/galaxy-watch-manager-free-feed/apk/"
            "galaxy-watch-manager-free-0.0.6.apk",
            feed.apk_url_for("0.0.6"),
        )

    def test_apk_meta_hashes_local_artifact(self):
        with tempfile.TemporaryDirectory() as tmp:
            apk = Path(tmp) / "app-release.apk"
            payload = b"fake apk bytes" * 1000
            apk.write_bytes(payload)
            meta = feed.apk_meta(apk, "0.0.6")
        self.assertEqual("galaxy-watch-manager-free-0.0.6.apk", meta["apk_name"])
        self.assertEqual(len(payload), meta["apk_size"])
        self.assertEqual(hashlib.sha256(payload).hexdigest(), meta["sha256"])
        self.assertEqual(feed.apk_url_for("0.0.6"), meta["apk_url"])

    def test_local_apk_wins_over_release_asset(self):
        with tempfile.TemporaryDirectory() as tmp:
            apk = Path(tmp) / "app-release.apk"
            apk.write_bytes(b"mirrored")
            entry = feed.build_entry("0.0.6", 6, "v0.0.6", self.release(), apk=apk)
        self.assertEqual("galaxy-watch-manager-free-0.0.6.apk", entry["apk_name"])
        self.assertEqual(8, entry["apk_size"])
        self.assertEqual(hashlib.sha256(b"mirrored").hexdigest(), entry["sha256"])
        self.assertEqual(feed.apk_url_for("0.0.6"), entry["apk_url"])

    def test_entry_without_apk_has_no_mirror_url(self):
        entry = feed.build_entry("0.0.6", 6, "v0.0.6", self.release())
        self.assertIsNone(entry["apk_url"])
        self.assertEqual(0, entry["apk_size"])

    def test_entry_is_json_serialisable_utf8(self):
        entry = feed.build_entry("0.0.8", 8, "v0.0.8", self.release())
        text = json.dumps(entry, ensure_ascii=False, indent=2)
        self.assertIn("新图标", text)
        self.assertEqual(entry["version_code"], json.loads(text)["version_code"])

    def test_channel_and_default_apk_branch_follow_version(self):
        stable = feed.build_entry("0.0.32", 32000, "v0.0.32", None)
        nightly = feed.build_entry("0.0.32.001", 32001, "v0.0.32.001", None)
        self.assertEqual("stable", stable["channel"])
        self.assertEqual("nightly", nightly["channel"])
        self.assertIn("/apk-nightly/", feed.apk_url_for("0.0.32.001"))
        self.assertIn("/apk/", feed.apk_url_for("0.0.32"))
        self.assertIn("/" + "a" * 40 + "/", feed.apk_url_for("0.0.32.001", "a" * 40))


if __name__ == "__main__":
    unittest.main()
