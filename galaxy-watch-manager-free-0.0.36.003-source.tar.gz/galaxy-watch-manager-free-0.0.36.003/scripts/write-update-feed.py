#!/usr/bin/env python3
"""Write the public update feed entry for a release.

Run from the release workflow (optionally needs GH_TOKEN for release notes) or
locally to repair a feed:

    python3 scripts/write-update-feed.py out/version.json v0.0.4 --apk artifacts/app.apk

The feed repository is public so the app can update itself without any token:
`version.json` and `nightly.json` live on main. Published APK URLs use immutable
commits retained by version-and-digest tags; apk and apk-nightly are convenience
pointers. Old packages remain available so old feeds stay valid.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import textwrap
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
_version_spec = importlib.util.spec_from_file_location("release_version", Path(__file__).with_name("version.py"))
_version = importlib.util.module_from_spec(_version_spec)
_version_spec.loader.exec_module(_version)
version_channel = _version.version_channel
REPO = "crossly/galaxy-watch-manager-free"
API = f"https://api.github.com/repos/{REPO}/releases/tags/"
FEED_REPO = "crossly/galaxy-watch-manager-free-feed"
APK_BRANCH = "apk"
# Legacy default; the publisher passes a retained commit SHA for new public entries.


def apk_file_name(name: str) -> str:
    """公开镜像里的固定命名，和 version.json 的 apk_url 必须一致。"""
    return f"galaxy-watch-manager-free-{name}.apk"


def apk_branch_for(name: str) -> str:
    return "apk-nightly" if version_channel(name) == "nightly" else APK_BRANCH


def apk_url_for(name: str, revision: str | None = None) -> str:
    """Use a retained commit for published URLs; branch default supports legacy feed readers."""
    return f"https://raw.githubusercontent.com/{FEED_REPO}/{revision or apk_branch_for(name)}/{apk_file_name(name)}"


def read_version() -> tuple[str, int]:
    return _version.read_version(ROOT / "version.properties")


def fetch_release(tag: str, token: str) -> dict | None:
    """Private releases need a token; without one the feed still gets a stub."""
    if not token:
        return None
    request = urllib.request.Request(
        API + tag,
        headers={
            "Accept": "application/vnd.github+json",
            "Authorization": f"Bearer {token}",
            "X-GitHub-Api-Version": "2022-11-28",
            "User-Agent": "galaxy-watch-manager-free-feed",
        },
    )
    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            return json.load(response)
    except Exception as error:  # noqa: BLE001 - the feed must never block a release
        print(f"warning: could not read release metadata: {error}")
        return None


def apk_meta(path: Path, name: str, revision: str | None = None) -> dict:
    """用本地签名产物算摘要，不依赖 GitHub 的 asset digest。"""
    digest = hashlib.sha256()
    size = 0
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
            size += len(chunk)
    return {
        "apk_name": apk_file_name(name),
        "apk_size": size,
        "sha256": digest.hexdigest(),
        "apk_url": apk_url_for(name, revision),
    }


def build_entry(
    name: str,
    code: int,
    tag: str,
    release: dict | None,
    apk: Path | None = None,
    revision: str | None = None,
    source: Path | None = None,
) -> dict:
    page_url = f"https://github.com/{REPO}/releases/tag/{tag}"
    entry = {
        "channel": version_channel(name),
        "version_name": name,
        "version_code": code,
        "published_at": None,
        "page_url": page_url,
        "apk_name": None,
        "apk_size": 0,
        "sha256": None,
        "apk_url": None,
        "notes": None,
    }
    if apk is not None:
        entry.update(apk_meta(apk, name, revision))
    if source is not None:
        source_name = f"galaxy-watch-manager-free-{name}-source.tar.gz"
        entry.update({
            "source_name": source_name,
            "source_size": source.stat().st_size,
            "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
            "source_url": f"https://raw.githubusercontent.com/{FEED_REPO}/{revision or apk_branch_for(name)}/{source_name}",
        })
    if not release:
        return entry

    entry["published_at"] = release.get("published_at")
    entry["page_url"] = release.get("html_url") or page_url
    body = textwrap.dedent(release.get("body") or "").strip()
    if body:
        entry["notes"] = body[:1000]
    # 本地产物优先；只有在没有传 --apk 时才回落到 release 资产信息。
    if apk is None:
        for asset in release.get("assets") or []:
            if str(asset.get("name", "")).endswith(".apk"):
                entry["apk_name"] = asset["name"]
                digest = asset.get("digest") or ""
                if digest.startswith("sha256:"):
                    entry["sha256"] = digest.split(":", 1)[1]
                break
    return entry


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    parser.add_argument("tag")
    parser.add_argument("--source", type=Path, help="corresponding source archive published alongside the APK")
    parser.add_argument("--apk-revision", help="retained 40-character APK commit SHA")
    parser.add_argument(
        "--apk",
        type=Path,
        default=None,
        help="signed APK to mirror; sets apk_url/apk_size/sha256",
    )
    args = parser.parse_args()

    name, code = read_version()
    expected = f"v{name}"
    if args.tag != expected:
        raise SystemExit(f"Tag {args.tag!r} does not match version.properties ({expected})")

    apk = args.apk
    if apk is not None:
        if not apk.is_file():
            raise SystemExit(f"APK not found: {apk}")
        if apk.stat().st_size <= 0:
            raise SystemExit(f"APK is empty: {apk}")

    if args.source is not None and (not args.source.is_file() or args.source.stat().st_size == 0):
        raise SystemExit("Corresponding source archive is missing or empty")
    if args.apk_revision is not None and not re.fullmatch(r"[0-9a-f]{40}", args.apk_revision):
        raise SystemExit("--apk-revision must be a full commit SHA")
    entry = build_entry(
        name,
        code,
        args.tag,
        fetch_release(args.tag, os.environ.get("GH_TOKEN", "")),
        apk=apk,
        revision=args.apk_revision,
        source=args.source,
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(entry, ensure_ascii=False, indent=2) + "\n")
    mirrored = f", apk mirrored to {apk_branch_for(name)} branch" if apk is not None else ""
    print(f"wrote {args.output} for {name} ({code}){mirrored}")


if __name__ == "__main__":
    main()
