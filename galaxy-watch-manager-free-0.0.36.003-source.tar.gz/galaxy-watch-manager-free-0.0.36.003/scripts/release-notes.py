#!/usr/bin/env python3
"""Extract one version's section from docs/RELEASE-NOTES.md for a GitHub release."""
from __future__ import annotations

import argparse
import os
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
NOTES = ROOT / "docs/RELEASE-NOTES.md"
HEADING = re.compile(r"^##\s+(0\.0\.\d+(?:\.\d{3})?)(?:\s+Nightly)?\s*$")


def extract(text: str, version: str) -> str:
    lines = text.splitlines()
    headings: list[tuple[int, str, str]] = []
    for index, line in enumerate(lines):
        match = HEADING.match(line)
        if match is not None:
            headings.append((index, match.group(1), line.strip()))
    matches = [(index, heading) for index, name, heading in headings if name == version]
    if len(matches) != 1:
        raise SystemExit(
            f"Expected exactly one release-notes section for {version}, found {len(matches)}"
        )
    start, heading = matches[0]
    end = next((index for index, _, _ in headings if index > start), len(lines))
    body = "\n".join(lines[start + 1 : end]).strip("\n")
    if not body:
        raise SystemExit(f"Release-notes section for {version} is empty")
    return f"{heading}\n\n{body}\n"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tag", default=os.environ.get("RELEASE_TAG", ""), help="release tag, e.g. v0.0.35.005")
    parser.add_argument("--notes", type=Path, default=NOTES, help="release-notes Markdown file")
    parser.add_argument("--output", type=Path, help="write the extracted section here instead of stdout")
    parser.add_argument("--check", action="store_true", help="only verify that the section exists")
    args = parser.parse_args()

    if re.fullmatch(r"v0\.0\.\d+(?:\.\d{3})?", args.tag) is None:
        raise SystemExit(f"Invalid release tag: {args.tag!r}")
    section = extract(args.notes.read_text(), args.tag[1:])
    if args.check:
        print(f"{args.tag} release notes found ({len(section.encode('utf-8'))} bytes)")
    elif args.output is not None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(section)
        print(f"wrote {args.output} for {args.tag}")
    else:
        sys.stdout.write(section)


if __name__ == "__main__":
    main()
