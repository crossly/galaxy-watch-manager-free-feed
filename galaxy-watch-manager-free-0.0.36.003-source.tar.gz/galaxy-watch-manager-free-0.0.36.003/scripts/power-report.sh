#!/usr/bin/env bash
# Read-only phone diagnostics. Does not reset battery stats, clear logs, or change app settings.
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then
  echo "Usage: $0 [phone-serial] (or set ANDROID_SERIAL)"
  exit 0
fi
if [[ "$#" -gt 1 ]]; then
  echo "Usage: $0 [phone-serial]" >&2
  exit 1
fi
command -v adb >/dev/null
phone_serial="${1:-${ANDROID_SERIAL:-}}"
if [[ -z "$phone_serial" ]]; then
  phones=()
  while IFS= read -r candidate; do
    [[ -n "$candidate" ]] && phones+=("$candidate")
  done < <(adb devices | awk 'NR > 1 && $2 == "device" && $1 !~ /^emulator-/ { print $1 }')
  if [[ "${#phones[@]}" -ne 1 ]]; then
    echo "Select one connected physical phone with ANDROID_SERIAL or a serial argument." >&2
    exit 1
  fi
  phone_serial="${phones[0]}"
fi
if [[ "$phone_serial" == emulator-* ]]; then
  echo "Use a physical phone; emulator diagnostics are disabled." >&2
  exit 1
fi
adb -s "$phone_serial" get-state >/dev/null
if [[ "$(adb -s "$phone_serial" shell getprop ro.kernel.qemu | tr -d '\r')" == "1" ]]; then
  echo "Use a physical phone; emulator diagnostics are disabled." >&2
  exit 1
fi
output_dir="private/power-audit/$(date '+%Y%m%d-%H%M%S')-$$"
mkdir -p "$output_dir"
package_name="dev.ricky.galaxywatchmanagerfree"
adb -s "$phone_serial" shell dumpsys battery > "$output_dir/battery.txt"
adb -s "$phone_serial" shell dumpsys batterystats --charged "$package_name" > "$output_dir/batterystats.txt"
adb -s "$phone_serial" shell dumpsys activity services "$package_name" > "$output_dir/services.txt"
adb -s "$phone_serial" shell dumpsys package "$package_name" > "$output_dir/package.txt"
adb -s "$phone_serial" shell 'logcat -d -v threadtime -s "Galaxy Watch Manager Free:I" "*:S"' > "$output_dir/app-logcat.txt"
python3 - "$output_dir" <<'PY'
from pathlib import Path
import json
import sys

folder = Path(sys.argv[1])
log = (folder / "app-logcat.txt").read_text(errors="replace")
patterns = {
    "health_requests": "发起健康同步 REQUEST_DATA",
    "full_recovery_requests": "REQUEST_DATA recovery=true",
    "ble_wakes": "开始 BLE GATT 唤醒手表",
    "rfcomm_connections": "RFCOMM 已接通",
    "health_sync_timeouts": "同步等待超时",
}
counts = {key: log.count(text) for key, text in patterns.items()}
counts["scope"] = "Counts cover retained app logcat only, not a complete battery session."
(folder / "counts.json").write_text(json.dumps(counts, ensure_ascii=False, indent=2) + "\n")
print(json.dumps(counts, ensure_ascii=False, indent=2))
print(f"Power report: {folder.resolve()}")
PY
