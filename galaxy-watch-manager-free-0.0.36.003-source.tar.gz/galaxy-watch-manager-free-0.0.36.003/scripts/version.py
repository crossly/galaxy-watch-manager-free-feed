#!/usr/bin/env python3
"""Version source of truth for stable 0.0.N and Nightly 0.0.N.MMM releases."""
from __future__ import annotations

import argparse
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
VERSION_FILE = ROOT / "version.properties"
MAX_VERSION_CODE = 2_100_000_000


def version_parts(name: str) -> tuple[int, int]:
    match = re.fullmatch(r"0\.0\.([1-9][0-9]*)(?:\.([0-9]{3}))?", name)
    if match is None or match[2] == "000":
        raise SystemExit("Expected version 0.0.N or 0.0.N.MMM (N >= 1, MMM = 001..999)")
    stable, nightly = int(match[1]), int(match[2] or 0)
    if stable * 1000 + nightly > MAX_VERSION_CODE:
        raise SystemExit("Version exceeds Android versionCode limit")
    return stable, nightly


def version_channel(name: str) -> str:
    return "nightly" if version_parts(name)[1] else "stable"


def version_code(name: str) -> int:
    stable, nightly = version_parts(name)
    return stable * 1000 + nightly


def read_version(path: Path | None = None) -> tuple[str, int]:
    values = dict(line.split("=", 1) for line in (path or VERSION_FILE).read_text().splitlines() if "=" in line)
    name, code = values["VERSION_NAME"].strip(), int(values["VERSION_CODE"])
    stable, nightly = version_parts(name)
    expected = version_code(name)
    # Existing stable tags used N directly; new releases reserve 999 Nightly codes per stable.
    if code != expected and not (nightly == 0 and code == stable):
        raise SystemExit(f"Expected VERSION_CODE={expected} for {name}")
    return name, code


def next_version(name: str, channel: str = "stable") -> tuple[str, int]:
    stable, nightly = version_parts(name)
    if channel == "nightly":
        if nightly == 999:
            raise SystemExit("Nightly counter exhausted; publish the next stable version first")
        name = f"0.0.{stable}.{nightly + 1:03d}"
    elif channel == "stable":
        name = f"0.0.{stable + 1}"
    else:
        raise SystemExit(f"Unknown release channel: {channel}")
    return name, version_code(name)


def should_mark_latest(name: str, published_tags: list[str]) -> bool:
    if version_channel(name) != "stable":
        return False
    incoming = version_parts(name)[0]
    for tag in published_tags:
        if re.fullmatch(r"v0\.0\.[1-9][0-9]*", tag) and version_parts(tag[1:])[0] > incoming:
            return False
    return True


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["show", "next", "bump", "channel", "check-tag", "latest-stable"])
    parser.add_argument("tag", nargs="?")
    parser.add_argument("--channel", choices=["stable", "nightly"], default="stable")
    args = parser.parse_args()
    name, code = read_version()
    if args.command in {"next", "bump"}:
        name, code = next_version(name, args.channel)
        if args.command == "bump":
            VERSION_FILE.write_text(f"VERSION_NAME={name}\nVERSION_CODE={code}\n")
    elif args.command == "channel":
        print(version_channel(name))
        return
    elif args.command == "latest-stable":
        print(str(should_mark_latest(name, sys.stdin.read().splitlines())).lower())
        return
    elif args.command == "check-tag":
        tag = args.tag or os.environ.get("RELEASE_TAG", "")
        if tag != f"v{name}":
            raise SystemExit(f"Tag {tag!r} does not match version.properties (v{name})")
        subprocess.run(["git", "rev-parse", "--verify", f"refs/tags/{tag}^{{commit}}"], cwd=ROOT, check=True, stdout=subprocess.DEVNULL)
    print(name)


if __name__ == "__main__":
    main()
