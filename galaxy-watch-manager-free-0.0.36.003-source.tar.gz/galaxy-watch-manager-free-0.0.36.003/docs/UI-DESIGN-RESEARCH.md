# Android UI 设计规范与开源实现调研

调研日期：2026-11-13。项目基线：`7a569d3`（v0.0.35.002）。本报告保留调研时的官方文档、固定提交上游源码与本项目基线对照；以下“已有事实”均指该基线。随后实施的范围与待验收事项见第 7 节补记，当前约定以 [UI 与交互规范](UI-STANDARDS.md) 为准。

## 1. 结论与建议顺序

本产品适合在现有 Material 3、主题配色和可编辑卡片基础上，进一步强化「快速看懂手表状态、读懂健康数据、顺利完成操作」的体验。最值得学习的是信息层级、窗口自适应、语义主题和可验证的交互；Expressive 可以为关键操作增加表现力，但需要按页面任务选择。

建议分三轮推进，每轮都能独立验收：

| 顺序 | 目标 | 产品中的具体变化 | 依赖条件 |
| --- | --- | --- | --- |
| 第一轮 | 统一信息层级与视觉节奏 | 摘要卡统一标题、主数值、单位和必要分类；详情按日期选择、主要图形、解释、记录组织；重复形状与颜色使用同一语义 | 大部分可在现有 Material 3 1.4.0 上完成 |
| 第二轮 | 让现有界面适应更多使用方式 | 窄窗口/大字号合理重排；宽窗口给记录和详情更多空间；图表补充读屏和键盘选点；保留历史选择与滚动位置 | 先整理布局策略和状态归属，新增自适应依赖另行核对 |
| 第三轮 | 有选择地采用 Expressive 与转场 | 主操作的形状/强调、卡片到详情的连续转场、自定义返回路径的手势预览 | `MaterialExpressiveTheme` / `MotionScheme` 需要升级至公开这些接口的 1.5 系列；截至调研日仍为 RC |

这是设计取舍，不是已复现缺陷的严重性排序。第一轮优先选择一个健康详情作为样板，再推广到其他同类页面，避免同时重做全部页面。

## 2. 官方规范：哪些指导当前就适用

### 2.1 Material 3 Expressive 的重点是建立注意力层级

官方将 M3 Expressive 定义为 Material 3 的扩展，涉及主题、组件、动效和排版，并继续支持 Material You 动态色；颜色、文字和形状仍是主题基础。[O1]

对本产品的启发：

- **概览的主角是当前设备与可执行操作。** 设备状态和与该状态相符的主操作应容易辨认；其他控制使用较低强调，避免所有卡片都争夺注意力。
- **健康的主角是测量结果与时间范围。** 摘要保持简洁，详情再解释数据来源、时间、历史与算法；装饰不能遮盖单位、未知值和实际记录范围。
- **设置的主角是选择与结果。** 继续使用分组行、完整行点击和清楚的当前值，复杂诊断放在高级区域。
- **强调需要有节制。** 较强的颜色、形状变化和动效用于主操作、选中状态与空间关系；普通健康读数不因装饰而使用错误色。

以上是结合产品任务提出的设计建议。项目已经在 [UI-STANDARDS.md](UI-STANDARDS.md) 中约定摘要卡层级、设备连接单一主操作和诊断信息折叠，应通过实际页面对照继续落实。

### 2.2 主题角色比单独调整每张卡片更有持续收益

官方建议通过 `MaterialTheme` 配置颜色、Typography 和 Shapes，配对使用 `primary/onPrimary`、`surface/onSurface` 等颜色角色；Typography 的五类角色均有默认值，不要求每个产品使用全部 15 种文字样式。[O1]

对本产品的启发：

- 延续已有 palette 与健康语义色，统一页面、卡片、内嵌内容的表面层级；不要另建并行配色系统。
- 主数值、单位、分类、辅助时间分别分配空间，使用现有 Typography 角色；普通标题可换行，不能靠不断缩小字号适应长英文。
- 只对反复出现且含义相同的卡片、内嵌块和面板形状建立映射；局部尺寸仍可留在局部，不为每个 padding 增加全局常量。
- 自定义颜色、透明混合和玻璃背景需单独验证对比度。系统动态色具备合适的色阶，不等于任意自定义叠加都自动可读。

### 2.3 自适应应基于当前窗口和内容任务

官方推荐的 canonical layouts 包括 list-detail、feed、supporting pane。Feed 根据可用宽度调整列数；list-detail 在宽窗口同时展示列表和详情，在窄窗口切换显示，并在窗口变化时保留选择。[O2]

对本产品的映射：

| 内容 | 适合的布局 | 小窗口 | 宽窗口 |
| --- | --- | --- | --- |
| 概览/健康摘要卡片 | Feed | 保留熟悉的卡片布局，空间不足时重排 | 调整列数或限制内容最大宽度，避免两张卡无限拉宽 |
| ECG/BP 等历史记录 | List-detail | 记录列表进入详情，返回保留位置 | 列表与选定记录并列，连续比较更方便 |
| 图表与说明/统计 | Supporting pane | 纵向组织，必要时在面板展示说明 | 图形与辅助解释并列，主图获得更多空间 |
| 少量设置选项 | 自适应模态容器 | 底部面板 | 有最大宽度的居中面板或对话框 |

`ListDetailPaneScaffold`、`SupportingPaneScaffold` 是官方实现入口。是否引入这些库、使用哪个版本，应在实施时验证本项目依赖组合；布局思想不要求先迁移整个导航框架。[O2]

不要用「设备是手机还是平板」代替当前窗口判断：横屏、分屏、折叠屏窗口都可能改变可用宽度。

### 2.4 无障碍需要覆盖自定义交互

官方要求交互目标至少 48dp。Compose 会自动向小型 clickable 元素的边界外扩展触控区域，因此仅看到 `size(24.dp)` 不能直接判定实际点击区域只有 24dp；仍需检查与邻近目标的重叠。`minimumInteractiveComponentSize()` 可预留布局空间，并应注意与 size 修饰符的顺序。[O3]

对于本产品，优先检查图表探针、卡片编辑按钮、自定义底部导航和图标操作：

- 每个操作有明确名称、角色、可用状态；整行设置只有一次回调。
- 读屏和键盘可以执行主要任务；图表不能仅靠手指在 Canvas 上横向拖动选点。
- 图表用时间、数值和单位描述当前选择，并提供上一条/下一条等离散操作；记录列表可作为另一种访问途径。
- 阶段和分类同时用文字/图例表达，避免仅凭色相判断。未知、未收到、有效零值继续分开。

### 2.5 预测返回与空间连续性应分别处理

预测返回让用户在手势过程中预览返回目的地，官方提供标准系统/导航集成和手动 `PredictiveBackHandler` 两条路径。[O4]

本项目已经调用 `enableEdgeToEdge()`，`AppBottomSheet` 基于 Material 3 `ModalBottomSheet`；当前依赖已具备该标准面板的预测返回支持。后续应重点检查编辑态、表盘页等自定义 `BackHandler` 路径，而不是重新实现 Material 面板已有的行为。系统版本和手势设置仍影响实际表现，源码支持不能替代手机验收。

卡片到详情的共享元素转场是另一项体验改进：它用于解释「点开的详情来自哪里」。应优先尝试稳定的标题、图标或容器，避免在健康图表坐标和数据发生变化时强行变形。

## 3. 版本事实：设计规范与可调用接口必须区分

官方发布页截至调研日列出的稳定版为 **1.4.0（2025-09-24）**，最新候选发布版为 **1.5.0-rc01（2026-11-04）**。[O5]

1.4.0-beta01（2025-07-30）的 Breaking changes 明确写道：

> All public APIs tagged with `ExperimentalMaterial3ExpressiveApi` or `ExperimentalMaterial3ComponentOverrideApi` have been removed, please switch to `1.5.0-alpha` to continue enjoying these features.

本次还直接读取了 Google Maven 的 `material3-1.4.0-sources.jar`：[O6]

| 符号 | 1.4.0 源码事实 | 对本项目的含义 |
| --- | --- | --- |
| `MaterialExpressiveTheme` | `MaterialTheme.kt:185`：`internal fun` | 应用不能直接导入使用，添加 OptIn 无法解决可见性 |
| `MotionScheme` | `MotionScheme.kt:42`：`internal interface` | 不能在当前版本照抄 `MotionScheme.expressive()` |
| `ShortNavigationBar` | `ShortNavigationBar.kt:95`：公开 `fun` | 此符号在 1.4.0 已公开；不能笼统声称所有新导航接口都不可用 |

1.5 系列发布说明还记录了 alpha15 的 MotionScheme 脱离 experimental、alpha18 的主题接口提升与无需 OptIn 的 `Material3ExpressiveApi`。这些是 1.5 线的变化，不代表 1.4.0 稳定版也有同样公开接口。[O5]

本项目当前配置：

| 项目 | 当前值/观察 |
| --- | --- |
| AGP / Kotlin | 8.7.3 / 2.0.21 |
| compileSdk / targetSdk / minSdk | 36 / 35 / 26 |
| Material 3 | 声明 1.4.0 |
| Compose UI | 声明 1.7.6；本次 `debugRuntimeClasspath` 解析为 1.8.2 |
| Activity Compose | 1.9.3 |

来源：[根构建配置](../build.gradle)、[应用构建配置](../app/build.gradle)。解析核对命令：`./gradlew :app:dependencyInsight --configuration debugRuntimeClasspath --dependency androidx.compose.ui:ui --offline --console=plain`。上述 1.8.2 观察限于 debug 运行时配置，不能直接推广为每个变体与所有 Compose 模块的版本。

因此可以先做信息层级、语义主题、预览和布局改进；需要 Expressive 接口时，再单独评估 1.5 系列与 Kotlin、Compose、AGP 的兼容性。Android 系统版本、compileSdk 和 AndroidX 库版本是不同维度，不能因为 compileSdk 为 36 就推断 Expressive 接口可用。

## 4. 六个开源项目的实现与启发

样本包括官方示例与持续维护的实际应用；本次查看的是下列固定提交的源码，没有把它们的所有页面或真机体验作为已验证结论。不同项目采用的 UI 库和导航方式不同，不应整套搬入。

### 4.1 Now in Android：窗口适配与预览成为日常开发方式

固定提交：`2982e63cb691ad49cd009aab43dc206fee6699c2`。[S1][S2]

`NiaApp` 通过 `currentWindowAdaptiveInfo()` 取得窗口信息，传给 `NiaNavigationSuiteScaffold`；选定版本同时使用 Navigation 3 的 `NavDisplay` 与 `rememberListDetailSceneStrategy`。`DevicePreviews` 用组合注解覆盖手机、手机横屏、折叠屏、平板和桌面。

**可借鉴：** 让窗口信息成为布局决策的明确输入；同一个内容模块在多个窗口下预览，不到功能完成后才发现窄屏问题。

**本产品落点：** 摘要网格、根导航、历史记录与详情；先建立少量合成预览，再试一个历史记录双栏布局。借鉴窗口策略无需先迁移到 Navigation 3，也不必复制 NIA 的多模块规模。

### 4.2 Androidify：统一动效主题与共享转场作用域

固定提交：`a4be10f78b7b84b4cc8907e1e7da307aab6c373c`。[S3][S4]

`AndroidifyTheme` 将配色、Typography、Shapes、`MotionScheme.expressive()` 一并交给 `MaterialExpressiveTheme`，并提供 `SharedTransitionLayout` 的作用域。`Motion.kt` 的共享元素 `BoundsTransform` 使用 MotionScheme 的 `slowSpatialSpec()`。

**可借鉴：** 用同一组空间动效解释页面关系，让各处转场保持一致；形状和排版也在主题层一起考虑。

**本产品落点：** 摘要卡片到健康详情、表盘列表到表盘详情。应先选一条用户频繁使用的路径验证；本项目 1.4.0 无法直接照抄其 Expressive 主题代码。

### 4.3 Jetcaster：一份主题连接文字、形状与色阶

Compose Samples 固定提交：`25631e8f544a9a1e3f01e296eaf1b4c28428196c`。[S5][S6]

手机端 `JetcasterTheme` 使用 `MaterialExpressiveTheme`、`MotionScheme.expressive()`、`JetcasterShapes` 和 `JetcasterTypography`，定义明暗及不同对比度的配色，并提供动态色分支。该提交版本目录声明 Material 3 **1.5.0-alpha22**；主题文件虽定义多种方案，所查看的入口实际以暗色为主，不能由定义反推所有方案都已在运行时接入。

**可借鉴：** 把核心视觉角色放在一个可理解的入口，由卡片和控件消费；审查「有哪些定义」时同时检查「当前真正使用哪个分支」。

**本产品落点：** 在已有 `WatchFreeTheme` 中核对表面、文字、卡片与控件形状的关系；借鉴排版和表面层级即可，不沿用播客内容结构，也不因示例用了 alpha 就把它当作稳定版本建议。

### 4.4 Bitwarden：产品语义与 Material 主题保持映射

固定提交：`6569c91e6d1a3e6ea4bd16e3070683466ea12d1c`。[S7]

`BitwardenTheme` 通过 CompositionLocal 提供产品颜色、形状与文字角色，再将颜色和 Typography 映射到 Material 3 的 `MaterialTheme`。调用处使用产品语义，不必知道每个主题分支的具体色值。

**可借鉴：** 产品语义色与 Material 系统角色协作；控件可以保持标准行为，品牌与业务颜色仍然一致。

**本产品落点：** 已有 `LocalWfPalette` 与健康色就是可继续完善的基础。优先检查同一指标在摘要、图表、图例和详情是否一致；补充确有重复需求的角色，无需再建立一套平行主题。

### 4.5 Pocket Casts：主题作为数据，并遍历主题进行预览

固定提交：`e371f6607a3ae68d2a18162b185928fb99169bf0`。[S8][S9]

选定 Compose 主题入口使用 `PocketCastsTheme` data class 保存主题类型与颜色，经 CompositionLocal 提供；`ThemePreviewParameterProvider` 遍历 `Theme.ThemeType.entries`。这个入口导入的是 **`androidx.compose.material.MaterialTheme`（Material 2）**。

**可借鉴：** 预览应覆盖实际支持的主题组合；主题差异通过数据表达，页面无需散布主题判断。

**本产品落点：** 用合成数据预览系统色与自选色、明暗主题；优先覆盖语义色差异大的健康卡片和图表。这里借鉴主题管理和验证方法，不迁移到 Material 2。

### 4.6 Mihon：同一内容选择合适的模态容器

固定提交：`0c888b010c9c52a824148f1ff6961ff46fdbaf83`。[S10][S11]

应用层 `AdaptiveSheet` 使用全屏 Dialog 包装并传入布局判断；核心实现让手机内容靠底、平板内容居中，内容最大宽度为 **460dp**。因此其手机分支的底部呈现不是直接使用 Material 3 `ModalBottomSheet`。

**可借鉴：** 内容与承载容器分离，让同一组选择项在不同窗口中保持合适宽度和阅读距离。

**本产品落点：** 可从 `AppBottomSheet` 这一处入口试验自适应容器；保留小窗口已有的 Material 面板行为，宽窗口选用居中容器或独立详情布局。460dp 是该项目的设计选择，应根据本产品长英文、图表和大字号试验，不作为通用硬标准；不要为复制外形丢失已有的返回、焦点和系统 inset 支持。

## 5. 本项目已经具备什么，哪些地方值得继续优化

以下是源码观察，不是手机截图评审或已完成的可用性测试。

| 领域 | 已有事实 | 值得继续验证/改进的点 | 代码入口 |
| --- | --- | --- | --- |
| 主题 | 动态色、自选色、明暗 palette；Material Typography | 重复形状与表面层级是否一致；`displayMedium/displaySmall` 使用默认值，应在实际使用前检查是否与自定义排版协调，而非机械补齐 | [Theme.kt](../app/src/main/java/dev/ricky/galaxywatchmanagerfree/ui/theme/Theme.kt):19、158、200 |
| 卡片布局 | 原地编辑、稳定 ID、半宽/整行、拖动排序、无障碍上移/下移操作 | `GridCells.Fixed(2)` 与整行 span=2 写死；改列数时必须同时处理 span、拖动与已有用户配置语义 | [EditableBlockGrid.kt](../app/src/main/java/dev/ricky/galaxywatchmanagerfree/ui/components/EditableBlockGrid.kt):106、143、184 |
| 根导航 | 漂浮/固定、可选玻璃、底部安全间距与恢复测试 | 保留现有选择；宽窗口可评估 rail，不能只因新 API 可用就替换全部手机导航 | [UI-STANDARDS.md](UI-STANDARDS.md):7、[NavigationLayoutTest.kt](../app/src/androidTest/java/dev/ricky/galaxywatchmanagerfree/NavigationLayoutTest.kt) |
| 系统区域 | 已调用 `enableEdgeToEdge()` | 继续验证键盘、手势/三键导航、横屏与面板 inset；无需再次提议「开启 edge-to-edge」 | [MainActivity.kt](../app/src/main/java/dev/ricky/galaxywatchmanagerfree/MainActivity.kt):40 |
| 详情容器/返回 | 共用 Material `ModalBottomSheet`；编辑态和表盘页使用自定义 BackHandler | 自适应容器及自定义返回路径的预览；手机取消返回不能误退出编辑或丢失选择 | [AppBottomSheet.kt](../app/src/main/java/dev/ricky/galaxywatchmanagerfree/ui/components/AppBottomSheet.kt):30、[HomeScreen.kt](../app/src/main/java/dev/ricky/galaxywatchmanagerfree/ui/HomeScreen.kt):135 |
| 图表 | 本地日时间轴、触摸探针、窄屏刻度；部分图形已有内容描述及测试 | `chartProbe` 负责 pointer 手势，所查心率 Canvas 未暴露等价的逐点语义操作；应补选点操作与当前读数语义 | [ChartInteraction.kt](../app/src/main/java/dev/ricky/galaxywatchmanagerfree/ui/components/ChartInteraction.kt):33、[HeartRateChart.kt](../app/src/main/java/dev/ricky/galaxywatchmanagerfree/ui/components/HeartRateChart.kt):103 |
| 验证 | 健康布局测试包含语言、字号、宽度、主题配置和文字溢出断言；导航有 StateRestorationTester | 在这些既有测试上补合成 Preview 和少量视觉基线；不能声称项目没有布局或状态恢复测试 | [HealthLayoutTest.kt](../app/src/androidTest/java/dev/ricky/galaxywatchmanagerfree/HealthLayoutTest.kt):84、[NavigationLayoutTest.kt](../app/src/androidTest/java/dev/ricky/galaxywatchmanagerfree/NavigationLayoutTest.kt):56 |

在 `app/src/main/java/.../ui` 范围搜索未发现 `@Preview`，但项目已有 ui-tooling 依赖。因此合成 Preview 是一个较小的起点，不必先引入新测试平台。

## 6. 可执行的改进方案与验收条件

### A. 先完成一套一致的卡片与详情层级

**方案：** 以一个健康模块为样板，核对摘要的「图标/标题 → 主数值 → 单位/必要分类」，详情的「日期 → 主要结果/图形 → 解释 → 原始记录」。时间、接收状态、每日统计和完整历史继续进入详情。保持半宽与整行的信息优先级一致，并梳理真实重复的形状与颜色角色。[O1][S5][S7]

**入口：** `Theme.kt`、健康摘要卡及对应详情，优先复用已有模块。

**验收：** 英文长文案、简体中文、明暗主题、320/360dp 宽度及 1.5/2.0 字号缩放下，主要结果和必要分类不被省略或裁切；大字号可以增加高度或重排。合成数据覆盖未知、无当天数据、长单位和较长分类。上述数值是建议验收矩阵，不是官方固定断点。

### B. 让网格和历史详情按空间分配内容

**方案：** 普通手机保留熟悉的双列卡片；空间不足时提供合理单列。宽窗口先选择「限制内容最大宽度」或「增加列数」中的一种进行试验，避免同时叠加复杂规则。若增加列数，整行使用当前最大 span，并明确已有半宽配置在新网格中的对应关系；不能只替换 `GridCells.Fixed(2)`。[O2][S1]

**入口：** `EditableBlockGrid.kt`；历史记录列表与详情的布局入口。

**验收：** 改窗口宽度、横竖屏、进入/退出编辑后，顺序、隐藏状态、半宽/整行偏好保持；拖动命中与边缘滚动正确；选定历史记录不被新数据替换，返回保持列表位置。先对一个记录模块验证双栏，再决定是否推广。

### C. 图表同时支持触摸、读屏和键盘

**方案：** 沿用现有探针和同一份选择状态，为离散读数增加上一条/下一条等语义操作，给出所选时间、数值和单位；提供可读记录途径。保留真实时间轴、无数据区间和既有手势分工。[O3]

**入口：** `ChartInteraction.kt` 与使用它的图表；心率可作为第一条验证路径。

**验收：** TalkBack 可以在不拖动 Canvas 的情况下浏览真实读数；键盘可操作；无数据和边界点行为清楚；纵向页面滚动仍正常。既有卡片编辑无障碍操作保留，不重复建设。

### D. 在统一面板入口处理窗口和返回体验

**方案：** 小窗口继续用现有 `AppBottomSheet`；宽窗口优先对简单选择面板试验居中容器。长健康详情根据任务考虑独立页面/双栏，而不是统一压进固定宽度弹窗。自定义返回单独评估手势进度与取消行为。[O2][O4][S10][S11]

**验收：** 取消与提交返回均正确；切换窗口不重复执行操作或清空记录选择；焦点、键盘、inset 和滚动区域正确；设备上验证 Material 面板的预测返回表现。

### E. 用合成状态建立可见的评审与回归入口

**方案：** 为样板卡片、详情和设置行增加可独立渲染的合成 Preview；通过多预览或参数提供器覆盖主题与关键状态。保留并扩展已有布局/恢复测试，在需要防止具体视觉回归的地方逐步建立截图基线。[S2][S9][O7][O8]

**工具限制：** 官方旧 `com.android.compose.screenshot` 独立插件页面已标明不再维护。推荐的新测试套件方案要求 **AGP 9.5.0-alpha03+**、截图引擎 **0.0.1-alpha16+**，并明确处于实验阶段；当前项目 AGP 8.7.3 无法原样采用。不要为增加 Preview 就升级整条工具链，也不要按旧教程把已停止维护的插件直接引入。[O7][O8]

**验收：** Preview 不依赖在线手表、真实存储或网络；固定日期、时区与数据。截图基线只用合成数据，并记录渲染环境；更新基线需要检查差异，不能把所有变化直接接受。像素一致不能替代手势、读屏和持久化验收。

### F. Expressive 放在可独立验证的一次升级中

**方案：** 完成第一轮样板后，再决定是否试用 1.5 系列。升级前核对每个构建变体的解析版本与工具链要求；试验主题统一动效和一条卡片到详情转场，保留系统关闭动画时的可用性。[O5][S3][S4]

**验收：** 主操作可辨认；转场没有遮挡真实数值或因后台新数据而跳变；快速切换、取消返回和恢复状态正确；低性能设备滚动与电量消耗另行测量。不能仅凭使用新主题就宣称更流畅或更省电。

## 7. 实施边界与本次证据范围

- 本次只新增调研报告；没有调整产品代码、依赖、健康模型、算法、持久化、留存或采集设置，没有提交、推送或发布。
- 后续纯视觉调整也要检查是否影响数据解释；一旦改变派生统计、数据字段或存储，必须按 [健康导出说明](HEALTH-EXPORT.md) 与 [CONTRIBUTING.md](../CONTRIBUTING.md) 同步快照、归档、Schema、manifest 和回归测试。漂亮的图表不能改变官方字段含义或补造测量结果。
- 已完成的是官方资料核对、六个上游固定提交的静态源码对照、当前仓库静态检查和 debug 运行时依赖解析；本次没有重新运行产品单元测试、构建或设备测试。
- 没有在手机上完成本报告建议的视觉、TalkBack、预测返回、保存/分享或重启持久化验收，也没有运行这六个参考应用。不得把源码支持当作已完成的设备体验验证。
- 后续截图、预览与测试统一用合成数据；真实设备证据只放被忽略的 `private/`，不进入 Git。

### 实施补记（0.0.35.003 Nightly）

- A–E 的本轮实现：主题形状与分组卡片层级；最大宽度 840dp、按窗口与字号切换单/双列的卡片网格；图表读屏与键盘逐点选择；步数目标面板在宽窗口居中并保留草稿；固定日期、UTC 与合成数据的 debug Preview 及 UI 回归用例。
- B 采用限制最大宽度的路径，未引入历史记录双栏；D 保留 Material 标准返回行为，自定义编辑态/表盘页的预测返回进度和共享转场仍属后续项目；F 的 Material 3 1.5 升级本轮未实施。
- 本地 632 项 JVM 测试、43 项脚本测试、1369 项双语资源检查、Spotless、Lint 与 Release 构建通过，Android UI 测试源码编译通过。无可用 Android 设备，未运行 UI 用例或实际渲染 Preview，TalkBack、预测返回、拖动与窗口切换、覆盖升级仍待真机验收；没有建立像素截图基线。
- 已核对健康导出联动：本轮只改变展示、选点与未提交草稿的恢复，不改变健康数据字段、算法、已保存目标、采集设置或历史范围。`HealthExportSnapshot`、独立手动小睡/本机睡眠分析缓存、原始/标准化归档、Schema v3 与 manifest 无需结构变更；导出回归随 JVM 测试通过。

## 8. 来源

### 官方资料

- **[O1]** [Material Design 3 in Compose](https://developer.android.com/develop/ui/compose/designsystems/material3)：Expressive 定位、颜色/排版/形状、强调、导航与无障碍。
- **[O2]** [Canonical layouts](https://developer.android.com/develop/ui/compose/layouts/adaptive/canonical-layouts)：feed、list-detail、supporting pane、窗口变化与选择保持。
- **[O3]** [Accessibility defaults in Compose](https://developer.android.com/develop/ui/compose/accessibility/api-defaults)：48dp、触控区域扩展、语义与自定义交互。
- **[O4]** [Predictive back in Compose](https://developer.android.com/develop/ui/compose/system/predictive-back)：系统、导航、Material 与手动返回集成入口。
- **[O5]** [Compose Material 3 release notes](https://developer.android.com/jetpack/androidx/releases/compose-material3)：稳定/RC 状态及各版本接口变化。
- **[O6]** [Google Maven：Material 3 1.4.0 sources JAR](https://dl.google.com/dl/android/maven2/androidx/compose/material3/material3/1.4.0/material3-1.4.0-sources.jar)：本次用于检查真实源码可见性，未执行归档中的代码。
- **[O7]** [Compose Preview Screenshot Testing](https://developer.android.com/studio/preview/compose-screenshot-testing)：旧独立插件不再维护的提示。
- **[O8]** [Screenshot testing with test suites](https://developer.android.com/studio/preview/compose-screenshot-testing-with-testsuites)：当前推荐方案、实验状态和工具链要求。

### 固定提交的开源实现

- **[S1]** [Now in Android / NiaApp.kt](https://github.com/android/nowinandroid/blob/2982e63cb691ad49cd009aab43dc206fee6699c2/app/src/main/kotlin/com/google/samples/apps/nowinandroid/ui/NiaApp.kt)。
- **[S2]** [Now in Android / DevicePreviews.kt](https://github.com/android/nowinandroid/blob/2982e63cb691ad49cd009aab43dc206fee6699c2/core/ui/src/main/kotlin/com/google/samples/apps/nowinandroid/core/ui/DevicePreviews.kt)。
- **[S3]** [Androidify / Theme.kt](https://github.com/android/androidify/blob/a4be10f78b7b84b4cc8907e1e7da307aab6c373c/core/theme/src/main/java/com/android/developers/androidify/theme/Theme.kt)。
- **[S4]** [Androidify / Motion.kt](https://github.com/android/androidify/blob/a4be10f78b7b84b4cc8907e1e7da307aab6c373c/core/theme/src/main/java/com/android/developers/androidify/theme/Motion.kt)。
- **[S5]** [Jetcaster / Theme.kt](https://github.com/android/compose-samples/blob/25631e8f544a9a1e3f01e296eaf1b4c28428196c/Jetcaster/mobile/src/main/java/com/example/jetcaster/ui/theme/Theme.kt)。
- **[S6]** [Jetcaster / libs.versions.toml](https://github.com/android/compose-samples/blob/25631e8f544a9a1e3f01e296eaf1b4c28428196c/Jetcaster/gradle/libs.versions.toml)。
- **[S7]** [Bitwarden / BitwardenTheme.kt](https://github.com/bitwarden/android/blob/6569c91e6d1a3e6ea4bd16e3070683466ea12d1c/ui/src/main/kotlin/com/bitwarden/ui/platform/theme/BitwardenTheme.kt)。
- **[S8]** [Pocket Casts / Theme.kt](https://github.com/Automattic/pocket-casts-android/blob/e371f6607a3ae68d2a18162b185928fb99169bf0/modules/services/compose/src/main/java/au/com/shiftyjelly/pocketcasts/compose/Theme.kt)。
- **[S9]** [Pocket Casts / ThemePreviewParameterProvider.kt](https://github.com/Automattic/pocket-casts-android/blob/e371f6607a3ae68d2a18162b185928fb99169bf0/modules/services/compose/src/main/java/au/com/shiftyjelly/pocketcasts/compose/preview/ThemePreviewParameterProvider.kt)。
- **[S10]** [Mihon / 应用层 AdaptiveSheet.kt](https://github.com/mihonapp/mihon/blob/0c888b010c9c52a824148f1ff6961ff46fdbaf83/app/src/main/java/eu/kanade/presentation/components/AdaptiveSheet.kt)。
- **[S11]** [Mihon / 核心 AdaptiveSheet.kt](https://github.com/mihonapp/mihon/blob/0c888b010c9c52a824148f1ff6961ff46fdbaf83/presentation-core/src/main/java/tachiyomi/presentation/core/components/AdaptiveSheet.kt)。

版本状态与官方文档可能在本报告日期后更新。上游源码链接均固定到本次核对的提交；实施前重新检查发布状态、依赖兼容性与当前项目代码。
