# 项目架构导航

本页描述当前依赖与职责，以文件和符号定位；函数位置用 `rg -n '函数名' 文件` 查询。
历史审查记录见 `REVIEW-0.0.9.md`、`OPTIMIZATION-PROGRESS.md`；本轮发现与验证见
[2026-11-01 审查](REVIEW-2026-11-01.md)，后续工作见 [技术债](TECH-DEBT.md)。

## 入口与依赖

生产 Kotlin 源码根目录为 `app/src/main/java/dev/ricky/galaxywatchmanagerfree/`。

```mermaid
flowchart TD
    Activity[MainActivity / HomeScreen] --> Controller[WatchController]
    Service[WatchConnectionService] --> Controller
    Controller --> Identity[DeviceIdentityStore / ConnectionRequestGate]
    Controller --> Transport[RfcommTransport]
    Controller --> Session[WcsSession]
    Controller --> Repository[WatchRepository]
    Session --> Transport
    Session --> Repository
    Repository --> State[WatchState / StateFlow]
    State --> UI[Compose screens / components]
    State --> Notification[ConnectionNotificationSnapshot]
    Repository --> Health[HealthRepository]
    Health --> Records[HealthRecordStore]
    Records --> Projection[HealthDataProjection / metric parsers]
    Projection --> State
    Health --> Cache[DevicePreferences / health archive]
    Health --> Sleep[LocalSleepAnalyzer / ManualNapStore]
    Repository --> Commands[SettingCommands / WatchSettingSchema]
    Repository --> Sync[StartupSyncCoordinator / AutoQueryCoordinator / RefreshCoordinator]
    Health --> HealthSync[HealthSyncCoordinator]
    Repository --> Monitor[HealthMonitorSession]
    Monitor --> Health
    UI --> Handover[OfficialAppHandover]
    Handover --> Journal[HandoverJournal / HandoverSnapshotStore]
```

这是依赖图，双向业务回包通过回调进入仓库；不是每个节点各自拥有一个线程。

## 模块职责

| 位置 | 负责 | 约束与主要符号 |
| --- | --- | --- |
| `MainActivity.kt`、`ui/HomeScreen.kt` | 应用入口、根 Tab、子页面及生命周期 | `HomeTab`、`HomeScreen`；导航由状态与 `BackHandler` 实现 |
| `core/WatchController.kt` | 当前设备、连接请求代次、服务与传输生命周期 | `startService`、`prepareHandover`、`continueHandover`、`stop` |
| `core/ConnectionRequestGate.kt` | 排除过时的身份获取、服务启动及连接回调 | `begin`、`invalidate`、`isCurrent` |
| `service/WatchConnectionService.kt` | 前台服务与动态通知订阅 | `ConnectionNotificationSnapshot` 只比较通知需要的字段 |
| `feature/DeviceIdentityStore.kt` | 按 MAC 保存已确认身份、待验证身份、交接与官方连接归属 | 候选身份必须经现场验证，进程重启不得自动抢回已交还的连接 |
| `feature/handover/` | 官方包状态检查、Shizuku 批量操作、恢复日志与恢复点 | 包的启停状态属于手机；连接归属属于具体手表，两者不能等同 |
| `wcs/RfcommTransport.kt` | Server/Client 竞争接入、流式读写、队列、保活与重连 | 生命周期回调顺序由 `lifecycleLock` 保证；回调不得持有资源锁 `connectionLock`；`stop` 不等待生命周期锁 |
| `wcs/WcsFrame.kt`、`WcsPieceAssembler.kt` | 信封编解码、路径、分片重组 | 帧大小和分片边界在此处理 |
| `wcs/WcsSession.kt`、`SessionReadiness.kt` | 身份握手、序列与 generation、协议路由、一次性就绪动作 | 会话就绪不等于单项设置或健康测量已完成 |
| `wcs/CompanionProfile.kt` | Watch4/5/6/7 官方插件包名、版本和型号识别 | 现场机型优先，已验证选择按 MAC 保存；SyncStart 游标不能提供手机/手表身份。证据与验收边界见 `WATCH4-6-COMPATIBILITY.md` |
| `feature/WatchRepository.kt` | 协议观察者与业务门面、设备状态、设置、表盘、通知 | 目前仍是宽门面；健康解析已委托给 `HealthRepository` |
| `feature/WatchState.kt` | 各页面共享的不可变展示快照 | `@Immutable` 不冻结集合；发布新快照，禁止原地修改 |
| `feature/WatchSettingSchema.kt`、`SettingCommands.kt` | 设置类型、路径/key、待确认写入与一次重试 | UI 目标值与设备确认值分开，新增设置优先登记 Schema |
| `feature/AutoQueryPolicy.kt`、`AutoQueryCoordinator.kt` | 全局查询配置与周期调度 | 默认 900 秒，可选 30/60/120/300/600/900 秒；前台电量、后台健康，无周期内存查询 |
| `feature/RefreshCoordinator.kt` | 概览整轮手动刷新防重入与回包等待 | 忙碌时忽略重复请求；设备回包有界等待、健康分块沿用独立超时；断线取消，过期设备护理任务不补发 |
| `feature/HealthSyncCoordinator.kt` | 健康请求防重入、分块续期、完成与超时 | 不拥有周期调度器；持锁发送时不能反向获取健康仓库锁 |
| `feature/HealthSyncRequestPolicy.kt` | 增量、自动回补与显式历史查询的窗口选择 | 自动全量回补限频按设备保存；显式窗口不能被覆盖为全历史，未入队不消耗回补额度 |
| `wcs/ReconnectPolicy.kt` | 主动重连退避与 BLE 唤醒限频 | 短暂接通不能重置退避；Server 被动监听持续可用 |
| `feature/HealthRepository.kt` | 原始记录接收、投影、缓存、导出快照、睡眠分析与健康同步 | 共享缓存写入口统一同步；需要持久化成功后才确认游标 |
| `feature/HealthRecordStore.kt`、`HealthDataProjection.kt` | 按身份/修订保存记录，从完整留存记录重算投影 | 不对已聚合均值再次累加 |
| `feature/HeartRateLog.kt`、`StressLog.kt`、`HealthMetricLog.kt` | 指标解析、分箱展开、按本地日统计 | 排除无效值；压力 0 有效；真实读数与元数据时间分开 |
| `feature/HealthStepParser.kt`、`HealthStepSnapshot.kt` | 增量步数去重、汇总覆盖、完整回补替换 | 普通增量不能冒充完整快照；缺失模块不能视作零步 |
| `feature/SleepParser.kt`、`LocalSleepAnalyzer.kt`、`ManualNapStore.kt` | 睡眠会话、分期、离线推理与补记 | 多段睡眠合并真实时间线；没有分期不推断阶段 |
| `feature/HealthMeasurements.kt` | 手表原生测量偏好、匹配 ACK 与回读 | 完整保存基线行，匹配身份/修订/目标值才确认 |
| `feature/monitor/` | 官方 SHM 通道、ECG/BP 记录与校准状态 | 记录成功持久化后才确认；测量和校准继续走手表官方入口 |
| `feature/HealthArchive.kt`、`core/EcgImageRenderer.kt` | 健康 ZIP 与 ECG PNG 导出 | JSON/CSV 保留来源与单位，ECG 保留真实定标 |
| `ui/screens/`、`ui/components/`、`ui/theme/` | 页面、共用交互与主题 | 遵循 `UI-STANDARDS.md`，避免把协议与磁盘工作放进组合期 |
| `scripts/`、`.github/workflows/` | 国际化检查、测试、构建、签名、版本与公开更新 feed | 发布统一用 `scripts/release.sh`；签名材料不进仓库 |

## 关键数据流

### 健康同步

1. `AutoQueryCoordinator` 或手动刷新调用 `HealthRepository.requestSync`。
2. `HealthSyncCoordinator` 防重入，`sendHealthSyncRequest` 经 `WcsSession` 入发送队列。
3. 读线程经 `WcsSession` → `WatchRepository.onMessage` → `HealthRepository.handleMessage`。
4. `HealthRecordStore` 合并记录，步数处理汇总/增量/完整回补，`HealthDataProjection` 重算展示值。
5. 发布 `WatchState`，持久化完整缓存；持久化成功后回复协议确认。
6. 心率记录的接收时间只随真实心率 `SYNC_DATA` 更新；整体同步时间单独保存。

睡眠分析在后台执行，完成后重新获取健康仓库同步保护再投影。手工午休、ECG/BP 写入和导出快照
也通过同一仓库边界，不能在 UI 或其他仓库直接修改其集合。

### 设置写入

`设置控件` → `WatchRepository.updateSetting` → `WatchSettingSchema` 选择类型/key →
`SettingCommands` 登记目标与重试 → `WcsSession` 入队 → 回包经 `applyWatchSetting` 归一并确认 →
`WatchState` 更新设备确认值。未知路径的兼容猜 key 仍存在，不是新增设置的默认实现方式。

### 连接交接

`prepareHandover` 先按 MAC 落盘待验证身份，再停止本应用连接；UI 可停用官方应用并显式继续。
`continueHandover` 仅把待定身份作为候选，WCS 验证成功后才确认。
恢复官方应用时先持久交还连接，自动连接必须检查归属。恢复按钮同时考虑恢复日志和当前实际
停用状态，不依赖上一次事务是否完整成功；部分停用时仍须提供处理剩余应用的入口。

### 图表

按本地日期过滤真实读数 → `chartDayFraction` 投影至本地 00:00–24:00 →
`drawReadingCurve` 绘制平滑渐变与探针 → `chartProbe` 点按或横向拖动选点 →
`ChartTimeAxis` 按可用宽度/字号显示时刻。指标纵轴和压力分级留在各自组件中。

## 新功能落点

- **新增通用指标**：`HealthMetricLog` 注册枚举和有效范围，确认 `HealthRecordStore.supported`，在投影中派生，复用 `MetricSheet`；为解析/日期/缺失值补测试。
- **新增复杂健康模块**：先定义记录身份与修订，再实现解析和投影；通过 `HealthRepository` 接入持久化与 ACK。不要在 UI 上拼接原始 JSON。
- **新增手表设置**：先核对 `PROTOCOL-SPEC.md`，补 `WatchSettingSchema` 和确认测试，再绑定设置行。
- **新增交接动作**：同时核对包状态恢复、MAC 归属、请求代次、进程重启和失败后的下一步，不能只改按钮文案。
- **新增页面**：根页在 `HomeTab` 注册；二级页面同步底栏显隐和返回行为；详情使用 `AppBottomSheet`。
- **新增发布行为**：修改发布脚本及其 Python 回归测试，按 `CONTRIBUTING.md` 验证 Release、公开清单与匿名产物。
