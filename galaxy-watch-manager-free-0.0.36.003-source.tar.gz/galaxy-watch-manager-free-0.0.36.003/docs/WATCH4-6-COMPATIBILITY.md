# Watch 4 / 5 / 6 兼容性调查

更新日期：2026-11-04。静态调查起点：`v0.0.18` / `f7d0e08`。

**实测状态**：

- **Galaxy Watch 6 + 一加 13 Pro**：用户反馈基础功能基本正常；`v0.0.29` 移除并发远程 Intent 并改为手机三轮向导后，尚未在该设备对上复测，不代表三轮袖带校准已通过。
- **Galaxy Watch 7 Ultra + 荣耀 Magic 8 Pro**：开发设备组合，已有连接、健康同步等实机记录；`v0.0.29` 手机三轮袖带校准已于 2026-11-04 实测通过，手表端不再闪退；最新设置开关修复仍需验证，不能标记为全功能验收通过。
- **Watch 4 / 5 / FE**：完成选定官方插件的静态对比、身份适配和回归测试，尚待对应真机验证。

具体系统、固件和已安装组件版本需随现场日志记录，不能从手表代际或静态样本推定。

## 样本与来源

Galaxy Wearable 是共用管理器，各代手表另有独立插件；应用商店也把插件称为 Manager。
本机既有官方管理器 `2.2.72.26092361` 的机型表
`research/decompiled/watchmanager/sources/b7/l.java` 明确给出了下表映射。

| 手表 | 手机插件包名 | 本次检查版本 | 插件最低手机 API / target API |
| --- | --- | --- | --- |
| Watch 4 / Classic / FE | `com.samsung.android.waterplugin` | `2.2.11.26071051` | 28 / 35 |
| Watch 5 / Pro | `com.samsung.android.heartplugin` | `2.2.12.26071051` | 28 / 35 |
| Watch 6 / Classic | `com.samsung.wearable.watch6plugin` | `2.2.13.26071051` | 29 / 35 |
| Watch 7 / Ultra | `com.samsung.wearable.watch7plugin` | `2.2.15.26071051` | 30 / 35 |

四份插件的 `versionCode` 均为 `126071051`。表中的手机 API 不代表手表系统版本，
也不改变本应用的 `minSdk=26`。Watch 4 / 5 的包名不是 `watch4plugin` / `watch5plugin`。

官方商店条目：

- [Watch 4 / FE](https://play.google.com/store/apps/details?id=com.samsung.android.waterplugin)
- [Watch 5](https://play.google.com/store/apps/details?id=com.samsung.android.heartplugin)
- [Watch 6](https://play.google.com/store/apps/details?id=com.samsung.wearable.watch6plugin)
- [Watch 7](https://play.google.com/store/apps/details?id=com.samsung.wearable.watch7plugin)

Watch 4 / 5 / 6 原件通过 `d.apkpure.net/b/APK/<package>?version=latest` 下载；
Watch 7 与 Galaxy Wearable 沿用此前从手机提取的原件。镜像只用于取得待分析文件，
结论依据是 APK 内的 manifest、DEX、证书和方法体，不采用镜像页面的协议描述。
`apksigner verify --print-certs` 验证通过，四代插件的 signer SHA-256
均与本机 Watch 7 官方原件相同：

```text
34df0e7a9f1cf1892e45c056b4973cd81ccf148a4050d11aea4ac5a65f900a42
```

| APK | 文件 SHA-256 |
| --- | --- |
| Watch 4 | `78a0d9c2c1f32a0602109818390ec33cb7b218f7d009803b6d18e25380309f48` |
| Watch 5 | `f67cb3908565fdd1c69afd3ec37f2138994f98f8259734209f283f438ab0e6b8` |
| Watch 6 | `d8da7149973b1296d5cccf34b88c7fb29781d1fc01e0ab8bca4e57df09e5be01` |
| Watch 7 | `da69a834616ca65a5895cb74331eaf0a1aad1fea530e3917777a03f0b988644f` |
| Galaxy Wearable | `2efebda07a7c3948c61e4d701d31a3fbd4f36c96c499fb699b156ded88640036` |

原件在忽略目录 `research/apks/watch-compatibility/`、`research/apks/pulled/`；
证书、包信息、REA 完整记录与验证日志在 `private/watch-compatibility/`。
不把官方 APK 或大批反编译源码加入仓库。

## 协议对比结果

1. **应用身份不同，证书相同。** Wear 应用信封中的包名需要按代选择；
   同一张证书并不使不同包名成为同一个 AppKey。此前所有 WCS JSON、空请求、
   二进制消息和设置 DataItem 都使用 Watch 7 包名。该固定行为已确认，
   但缺少旧表端日志，尚不能证明它是所有连接失败的原因。
2. **检查到的路径集合一致。** 从每份 APK 的全部 DEX 字符串表提取
   `/wcs_extension/`、`/w_module_sec_watch_setting/` 前缀、三个核心 msgId 和 UUID，
   四份样本各有 264 项去重字符串，排序后 SHA-256 均为
   `6cca79e01a8288be0d97e19c0c6899caaaf5651e458f7a702c10a4a9f2cd4024`。
   这证明该范围的字面量一致，不证明所有方法、字段语义、能力或固件行为一致。
3. **核心发送入口相近。** 四份 `CommonMessageSenderImpl.sendMessageToNode`
   都把 JSON 编为字节，通过 Google Wear MessageClient 发送到给定 node/path，
   并处理成功、取消、失败回调。已检查方法体完整、无 smali fallback；
   部分混淆类名、辅助日志调用不同，不能宣称整份二进制等价。
4. **核心消息值一致。** 已导出的 `connection.bluetooth.define.Constants`、
   `CapabilityExchageConst` 在连接路径、`set_device_activation`、
   `feature_exchange` 请求类型 `2` 等值上一致。设置同步仍使用 Wear DataItem。
   本轮没有找到必须改用另一套 WCS 路径或 RFCOMM UUID 的证据。
5. **管理器的集成元数据有代际差别。** 当前管理器给 Watch 4 / 5 的
   companion-service 字段为 `null`，Watch 6 / 7 为 `WRCompanionService`。
   但本次新插件样本中 Watch 4 / 5 也包含该类，不能把管理器字段直接解释成
   “旧表没有 Wear 传输”或“必须切换到另一种蓝牙协议”。

REA 方法证据：

| 手表 | `sendMessageToNode` Evidence ID |
| --- | --- |
| Watch 4 | `ev_8255840a10fe31a13224aa78fa2ab842fdc45f9547440bec019cef6159972956` |
| Watch 5 | `ev_69703bc5ddac0005af5e87cf8366b46f5282f9e08fb17a5dab95a143d9edb5e2` |
| Watch 6 | `ev_6d88518fc47fdd6641e3273190449ece8fe951ef6b8c6e77dc58d614927eae50` |
| Watch 7 | `ev_8cdc8784fd92d8504137a61ed0b42486c7c45a0057e6bce5ac8df65558386f0c` |

工具：REA 6.8.0、JADX headless MCP 0.7.1、独立 JADX 1.5.5、
Android build-tools 35.0.0。只做静态分析，没有执行这些 APK。
定向导出覆盖 Watch 4 / 5 各 10 个类、Watch 6 共 11 个类；其他类和方法没有
逐个审查，导出日志也包含未完全恢复的方法，不能称为完整反编译验证。

## 已落实的修改

- **官方应用交接**：在精确白名单、Android 包可见性、中英文名称及启停脚本中加入
  Water / Heart / Watch6 插件。旧版只处理 Watch7，即使显示交接完成也可能留下旧插件
  运行；旧插件也进不了本应用的恢复流程。Samsung Health / SHM 仍不在启停白名单内。
- **按代发送**：新增 `CompanionProfile`。优先由现场 Connect 名称或 `SM-R...` /
  `SM-L...` 型号识别；名称不可识别时使用按设备保存且曾通过业务验证的选择，
  再考虑手机上唯一的已安装官方插件，最后保留 Watch7 作为历史兼容回退。
  已识别的旧表不再发送 Watch7 包名或版本。
- **验证后保存**：只有通过原有实时身份验证后，才按配对地址保存插件选择。
  同一对端的有效 feature 响应可用真实型号修正选择；不放宽目的节点、来源节点、
  有效业务内容和对应请求的验证条件。
- **修正 SyncStart 身份污染**：tag8 的 f2 是无顺序角色的复制游标表，
  不是“第一个手机、第二个手表”。解码改为 `SyncStart.cursors`，完全移除
  以游标覆盖 `phoneNode` / `watchNode` 的逻辑；同时移除旧 `NodeAlloc` 命名与无效编码参数。
- **旧表自动发现**：识别 Watch 4 / 5 / 6 已知 `SM-R` 型号；不把所有 `SM-R`
  前缀都当作手表，避免 Galaxy Buds 的型号被自动连接选中。
- **诊断与消息序列**：Connect 日志增加实际 peer wire 版本范围；
  `sendBytes` 与其他消息共用递增 message ID 和当前 generation，避免沿用固定默认值。
  新日志不等于已经实现了所有旧版 wire 分支。

## 验证边界与后续验收

本轮新增回归覆盖各代名称/型号、包名与设置 DataItem 编码、身份选择优先级、
游标反序/历史节点/空向量/残缺项、wire 版本读取、交接白名单及旧插件恢复日志。
最终命令和结果记录在 `private/watch-compatibility/validation-full.log`、
`validation-final.log`；资源检查和脚本测试另行运行。没有使用模拟器。

2026-11-01 最终验证：

- Java 17 下执行 `:app:spotlessCheck :app:testDebugUnitTest :app:lintDebug
  :app:assembleRelease :app:assembleDebugAndroidTest`，结果 `BUILD SUCCESSFUL`。
- JVM：365 项测试，失败 0、错误 0、跳过 0。Android Lint：错误 0，警告 56。
- `python3 scripts/check-i18n.py`：1118 项资源、2 种语言，键及格式参数一致；
  Python 脚本测试 24 项通过，两个启停脚本的 Bash 语法检查通过。
- 四份 APK 的 SHA-256、发送方法 Evidence ID 及路径集合摘要与证据清单逐项一致；
  `git diff --check` 通过。
- 本地 Release 构建产物未签名；AndroidTest 仅编译，没有在设备上执行。
  本轮没有 bump 版本、发布或宣称旧型号已经通过真机测试。

Watch 4 / 5 / 6 仍需对应真机验证以下完整路径：

1. 记录具体型号、Wear OS / One UI Watch、手机系统、官方插件与 Google Wear 版本；
   首次配对仍先走官方流程，本轮未实现零配对登记。
2. 获取该手表已登记的手机身份，停用正确的官方连接组件，确认它们不再抢占连接。
3. 检查日志的 Connect 回帧、peer wire 区间、所选 WCS 插件身份与业务验证结果，
   不能把 RFCOMM 接通或收到 SyncStart 当成接管成功。
4. 验证电量、表盘、通知、一次设置写入及回读、健康增量同步与重连；
   不支持的单项能力应单独定位，不能据此认定整个连接协议不支持。
5. 恢复官方组件，验证原始启用状态、自动连接暂停和异常恢复入口。

本次选取的是各代插件的 2026-07 发布修订，**没有取得并比较所有 2021–2025
历史修订，也没有拿到旧表端 WCS / GMS APK**。历史下载入口部分返回 403，
不把请求失败当作已检查。若用户仍失败，需要对应连接时段的诊断日志和上述版本信息；
必要时再从其设备提取相应官方组件，检查 wire 协商、手机节点来源与真实响应结构。
当前不能宣传“Watch 4 到 Watch 7 全系统版本已实测兼容”。

## 血压校准补充复核（2026-11-02）

本文件的插件兼容结论不覆盖 Samsung Health Monitor 的三轮袖带校准。已对比
Watch SHM `1.2.7.003` / `1.5.1.022` 和 Phone SHM `1.5.2.002`：两版 Watch SHM
都把 `/991` 的 `do_calibration` 分派到 `BpMainActivity`，并由手表自己的
`BpCalibrationActivity`、Room 校准配置和 `shm-bp.so` 完成三轮袖带与个人特征合并。
手表只通过 `capability_bp` 判断手机侧能力，不需要手机版 SHM 参与计算。

`v0.0.21` 的直连入口方向正确，但存在非空校准配置阻塞同批 BP、`need_to_recal`
未处理和状态刷新不完整等缺口。`v0.0.22` 曾错误改为手机版 SHM 交接，增加手机端
机型/环境校验与官方软件强依赖；`v0.0.23` 已撤销该路线，恢复直接向手表发送
`do_calibration`，并保留配置归档、整批确认、自动状态回查和错误展示。相关 JVM
回归通过，但仍未在 Watch 4 / 5 / 6 上验证三轮袖带、算法升级重校准和真实重传行为，
因此不能标为这些型号已完整兼容或已真机验收。

样本身份、基线缺口、当前实现、诊断复现和验收条件见
[SHM 调查：血压校准兼容性复核](HEALTH-MONITOR-INVESTIGATION.md#watch-4--5--6-血压校准兼容性复核)。

## Watch 6 测试反馈与后续验证（2026-11-04）

用户确认的设备组合为一加 13 Pro + Galaxy Watch 6，基础功能基本正常；荣耀 Magic 8 Pro + Galaxy Watch 7 Ultra 为另一组实测环境。尚未获得两组设备的完整系统与组件版本清单。

### 血压校准启动

`v0.0.27` 在监测器就绪时继续向 `/991` 发送 `measuring/do_calibration`，并尝试通过 `/remote_intent/rpc` 启动 `com.samsung.android.shealthmonitor.bp.ui.activity.BpMainActivity`。远程 Intent 使用 `android.intent.action.MAIN` 和 `android.intent.category.LAUNCHER`，不携带 extras；两条路径没有按手表型号或系统版本分支。

该并发路径已被 `v0.0.29` 移除：接收端忽略 `class_name`，`MAIN` 只会拉起应用根入口，与 `/991` 唤起的校准 Activity 跨模块冲突会触发 `finishAffinity()` 闪退。`v0.0.29` 改为仅通过 `/991` 的 `prepare_calibration` → `start_calibration` → `update_calibration` → `initial_calibration` 三轮时序驱动手表官方校准，手机端提供向导与袖带读数录入。该流程已在 Galaxy Watch 7 Ultra 真机确认完整走通；Watch 6 上仍需朋友实测，不能由静态 SHM 样本推定全部固件是否注册 `/plain_connection`。

### 设置反馈

常规设置排队成功后先更新界面并请求回读；手机 DataItem 自回声不作为手表确认。实际收到的手表回报会校正状态。Watch7 Ultra 抬腕亮屏及同类开关的最新修复仍需真机复测。
