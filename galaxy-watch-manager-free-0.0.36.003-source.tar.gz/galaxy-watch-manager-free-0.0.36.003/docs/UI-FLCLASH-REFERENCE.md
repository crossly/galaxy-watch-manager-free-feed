# FLClash Android 源码对照与 UI 评估

评估日期：2026-10-30。参考官方 [`chen08209/FlClash`](https://github.com/chen08209/FlClash) 的 `0.9.2+2026102401`，固定提交 [`7fd417fb9a9a277c6a9339a8ac87f907df7c25f7`](https://github.com/chen08209/FlClash/commit/7fd417fb9a9a277c6a9339a8ac87f907df7c25f7)。已阅读 `/tmp/flclash-android-reference` 的主题、表面层级、列表、导航、状态卡和折叠模块实现，并核对主要文件的官方原文。

本项目使用 Kotlin/Compose。评估对象是视觉规则与交互组织，不是复制 Flutter 运行时、着色器或代理业务。

## 总体判断

现有页面已经复用了 FLClash 的部分基础规则：动态配色、明暗表面层级、连续圆角、共享字阶、分组设置和悬浮导航。主要偏差集中在设备连接页：多个同等醒目的操作竞争、技术说明与正常操作混排、可选接管功能常驻展开，以及“等待用户”“正在工作”“已验证”状态混淆。只换色值或加大圆角不能解决这些问题。

## 上游源码依据

以下链接均固定到上述提交，避免随上游更新改变评估依据。

| 主题 | FLClash 的实际实现 | 本项目采用的规则 |
| --- | --- | --- |
| 表面层级 | [`ui/surface.dart`](https://github.com/chen08209/FlClash/blob/7fd417fb9a9a277c6a9339a8ac87f907df7c25f7/lib/ui/surface.dart#L6-L30)：亮色 page/card/block 为 surfaceContainer/surfaceBright/surfaceContainer；暗色为 surface/surfaceContainer/surfaceContainerHigh | 保留 `paletteFor`，不另建一套固定色板 |
| 间距与触控 | [`ui/metrics.dart`](https://github.com/chen08209/FlClash/blob/7fd417fb9a9a277c6a9339a8ac87f907df7c25f7/lib/ui/metrics.dart#L5-L25)：基本边距 16、列表行至少 56、行内垂直留白 10、页面工具栏 72；部分间距随文字缩放适配 | 设置页统一边距与行结构；展开和选择由整行承载 |
| 字阶 | [`ui/typography.dart`](https://github.com/chen08209/FlClash/blob/7fd417fb9a9a277c6a9339a8ac87f907df7c25f7/lib/ui/typography.dart#L6-L106)：页面 24/30、正文 17/22、说明 15/20、脚注 13/18，显示数字 40/44 | 保留现有 Typography；诊断文字取消局部 10sp 缩小 |
| 圆角与分组 | [`ui/shape.dart`](https://github.com/chen08209/FlClash/blob/7fd417fb9a9a277c6a9339a8ac87f907df7c25f7/lib/ui/shape.dart)、[`ui/list_selected.dart`](https://github.com/chen08209/FlClash/blob/7fd417fb9a9a277c6a9339a8ac87f907df7c25f7/lib/ui/list_selected.dart#L43-L107)：普通卡片、分组和 dashboard 使用不同圆角；分组内部以分隔线连续连接 | 连接选表使用分组列表，不给每个普通设备绘制独立强调色边框 |
| 列表交互 | [`ui/list.dart`](https://github.com/chen08209/FlClash/blob/7fd417fb9a9a277c6a9339a8ac87f907df7c25f7/lib/ui/list.dart#L111-L264)：导航、选项、输入与开关具有各自的统一行结构 | 选表与帮助为次级入口；自动连接、自动查询为设置行 |
| 状态与主操作 | [`views/dashboard/widgets/current_outbound.dart`](https://github.com/chen08209/FlClash/blob/7fd417fb9a9a277c6a9339a8ac87f907df7c25f7/lib/views/dashboard/widgets/current_outbound.dart)：移动端状态卡只有一个主要启停操作，操作可用性、连接状态与语义标签分别表达 | 连接页按实际状态提供配对、连接、重试或停止；不堆放多个重复主操作 |
| 选择与状态色 | [`ui/selection_mark.dart`](https://github.com/chen08209/FlClash/blob/7fd417fb9a9a277c6a9339a8ac87f907df7c25f7/lib/ui/selection_mark.dart)、[`ui/color.dart`](https://github.com/chen08209/FlClash/blob/7fd417fb9a9a277c6a9339a8ac87f907df7c25f7/lib/ui/color.dart)：选择主要用主题色勾选；成功、警告、错误各有语义色 | 已选择不等于已连接；候选身份不显示绿色验证成功；可选管理入口保持中性 |
| 悬浮导航 | [`ui/navigation_dock.dart`](https://github.com/chen08209/FlClash/blob/7fd417fb9a9a277c6a9339a8ac87f907df7c25f7/lib/ui/navigation_dock.dart)：浮动底板与选中底板使用相邻表面层级，选中内容使用 primary，未选中使用 onSurfaceVariant；开启液态玻璃后由 `LiquidGlassStyle.pill` 接管底板 | 保留高度、安全区、动画与路由状态，统一底板及图标文字色角色；可选液态玻璃使用真实背景模糊、通透着色和高光边缘 |
| 折叠信息 | [`ui/collapsible_section.dart`](https://github.com/chen08209/FlClash/blob/7fd417fb9a9a277c6a9339a8ac87f907df7c25f7/lib/ui/collapsible_section.dart)：折叠项有明确展开状态与动画 | 官方应用切换默认收起，进入等待切换时展开；折叠只影响内容展示，不销毁操作所有者 |

FLClash 支持系统取色与自选颜色，蓝色截图并不是唯一配色规范。统一性应来自角色一致：主题色表达操作/选择，绿色表达已确认状态，警告色表达需要处理的问题。

## 本项目问题与本轮处理

| 区域 | 源码或界面确认的问题 | 本轮处理 |
| --- | --- | --- |
| 连接首屏 | 未选表时仍堆放连接、获取身份、重新引导三个大按钮；重复选表说明 | 只保留当前状态的一个主操作；选表和帮助改为分组入口 |
| 设备列表 | 耳机、打印机等所有已配对设备常驻铺开，选择主要依赖边框颜色；极长名称在 200% 字号下撑高主页面 | 列表移入选择面板，保留全部设备与刷新/系统设置入口，增加 RadioButton 选择语义与明确勾选；主页面摘要最多两行，完整名称在面板中保留 |
| 官方应用切换 | 选表后整张 Shizuku/包名/操作/手动说明卡片始终展开 | 使用可展开分组；等待切换时自动展开；保留所有授权、停用、继续、取消、恢复和应用详情操作 |
| 连接状态 | PREPARING_HANDOVER 的持久暂停被画成持续加载；空闲描述却说正在连接；READY 文案说正在同步 | 区分实际忙碌、等待用户与就绪；保持真实控制器和持久状态规则 |
| 手机身份 | 待验证身份可命中“已验证”文案，Node ID 出现在主要状态中 | 区分已确认与候选；数值移入高级详情；同步修正引导中的候选显示 |
| 自动连接 | 偏好和说明仍在，但页面已没有写入它的开关；旧设置页面却继续执行无用的配对列表查询 | 恢复现有自动连接偏好的设置入口；删除重复查询、日志订阅和失效 Activity 转发 |
| 诊断 | 手输身份、冗长查询说明与协议日志抢占正常操作；日志另设 10sp | 将详细说明和诊断统一置于高级折叠区，使用共享可读字阶，保留复制/清空/筛选和手动验证 |
| 配色 | 心率首页使用 HeartRose，详情和曲线却借用 error 色；接管标题常驻警告色；导航选中角色与参考不同 | 心率正常展示统一 HeartRose；接管普通态保持中性；导航使用中性选中底板与主题色内容 |
| 设置交互 | 外观整行与 RadioButton 各自注册相同操作；搜索清空图标只有 18dp 可点击区域 | 外观行作为唯一交互目标并暴露单选状态；清空操作使用正常 IconButton 触控区域 |
| 通知权限 | 未授权时仍使用绿色验证图标，视觉含义与“需要权限”冲突 | 未授权使用中性锁图标，仅实际已授权显示成功色；权限与转发偏好保持独立 |
| 通用交互 | 分段选项缺少 Tab/selected 语义；目标步数面板不能滚动 | 补齐选择语义；目标步数内容支持滚动 |

主要实现位于 [设备连接页](../app/src/main/java/dev/ricky/galaxywatchmanagerfree/ui/screens/connection/DeviceConnectionScreen.kt)、[页面状态](../app/src/main/java/dev/ricky/galaxywatchmanagerfree/ui/screens/connection/ConnectionPageModel.kt)、[官方应用切换](../app/src/main/java/dev/ricky/galaxywatchmanagerfree/ui/components/CompanionHandoverCard.kt)、[共享组件](../app/src/main/java/dev/ricky/galaxywatchmanagerfree/ui/components/CommonUi.kt)与[主题](../app/src/main/java/dev/ricky/galaxywatchmanagerfree/ui/theme/Color.kt)。

## 整体页面评估

| 页面 | 判断 | 边界 |
| --- | --- | --- |
| 概览 | 设备、电量、表盘、快捷控制的层级已比较完整；连续圆角和主题表面可继续复用 | [INFERENCE] 两列快捷卡在 320dp/200% 字号下可能显著增高，应按实际渲染判断，不直接缩小文字 |
| 健康 | 摘要与完整详情分离、数值与单位分工合理；修正正常心率的颜色角色即可消除一处明显不一致 | [INFERENCE] 固定两列及步数/目标横向组合是极端字号下的优先检查项；不应因此改写用户保存的排版配置 |
| 通知 | 权限、转发开关、会话状态属于不同条件，现有分组可保留；不需要再放入一个测试表单 | 仅凭一张权限未授予截图，不能判定通知功能失败或把转发偏好当作已授权 |
| 设置 | 分组入口与详情页隐藏主导航符合参考组织方式；主要问题是重复点击目标与失效查询逻辑 | 修正交互目标，保留路由恢复和返回行为 |
| ECG/BP 详情 | 固定工具栏、独立内容滚动、按记录 ID 选择历史、离线可读具有清楚的职责 | 保留已工作的官方测量/校准/记录通路，不用 UI 调整替换业务状态机 |
| 连接与引导 | 是当前最需要重排的区域；日常连接管理与首次设置应分开 | 引导继续独立全屏；本轮修正候选身份显示，未替代官方首次配对 |

截图中滚动内容经过浮动导航后方，不足以证明末尾内容不可到达：现有根列表保留了底部滚动空间。需要结合滚动到底后的界面和实际可访问性判断，不能只凭中途截图判为遮挡缺陷。

## 实现边界

保留现有蓝牙发现排序、手机身份获取与现场验证、Shizuku 白名单及回滚、三星健康心率同步、SHM 血压/ECG 测量校准与结果持久化。连续圆角仍为 Compose 原生实现；漂浮底栏移植下述移动端玻璃 shader 和按压拖动逻辑，Flutter 的纹理图集捕获改为 Compose GPU 显示列表。桌面悬停、弹窗和 goo 轮廓不在移动底栏范围内。

## 本轮验证与证据

- `:app:spotlessCheck :app:testDebugUnitTest :app:lintDebug :app:assembleRelease :app:assembleDebug :app:assembleDebugAndroidTest` 通过；303 项 JVM 测试，0 失败/错误。脚本 24 项通过，1054 条资源的中英文键和格式参数一致。
- 最终 46 项 Android instrumentation 测试通过：包含选表面板切换、等待切换不出现忙碌进度、自动连接偏好写入与重建恢复，以及既有健康详情、连接身份、排版与导航回归。
- 模拟器已有正式证书安装，Gradle 的默认调试证书无法覆盖；因此将最终调试与测试 APK 用原证书签名后，通过 `adb -s emulator-5554 shell am instrument -w -r dev.ricky.galaxywatchmanagerfree.test/androidx.test.runner.AndroidJUnitRunner` 运行同一套测试。旧用例包含固定英文定位，最终回归明确将应用语言设为 `en`；中文另行通过实际界面验证，没有改动产品文案来配合断言。
- 两项临时 Compose 视觉探针验证 320dp/200% 字号的已连接与等待切换状态、待验证身份、长设备名、继续/取消可达性；受控状态仅用于渲染，不是蓝牙或真实测量证据。探针源码已移除。
- 最终正式签名 APK 已在模拟器覆盖安装，实测中文连接页、选择面板与系统设置入口布局。额外将系统密度设为 320dp、系统字号设为 200%，确认面板标题、关闭/刷新、长说明和操作均未裁切或重叠；之后恢复原始密度与字号。
- 截图与 UIAutomator 层级在忽略目录 `private/flclash-ui-review-20261030/`：`connection-before.png`、`connection-after-zh-light.png`、`chooser-after-zh-light.png`、`chooser-after-zh-system-large.png`；受控明暗状态截图在其 `FlClashUiReview/` 子目录。
- 版本保持 0.0.12，APK 使用现有正式证书。当前没有真机连接，本轮未重新验收真实蓝牙测量；官方心率数据处理、血压/ECG 协议及结果存储保留，心率详情仅调整普通数据的颜色角色。


## Material 基础与 Android 外观选项

FLClash 的主题先设置 [`useMaterial3: true`](https://github.com/chen08209/FlClash/blob/7fd417fb9a9a277c6a9339a8ac87f907df7c25f7/lib/manager/theme_manager.dart#L63-L78)，再应用自有 shapes、surfaces 与 typography。因此应描述为“以 Material 3 为基础的定制设计系统”。其[字阶](https://github.com/chen08209/FlClash/blob/7fd417fb9a9a277c6a9339a8ac87f907df7c25f7/lib/ui/typography.dart#L3-L19)明确参考 iOS Dynamic Type，[连续圆角与弹窗](https://github.com/chen08209/FlClash/blob/7fd417fb9a9a277c6a9339a8ac87f907df7c25f7/lib/ui/shape.dart#L6-L109)及悬浮导航也有自定义规则，不能把全部外观归为原生 Material 默认样式。

以下是该固定提交的 Android 可见选项；侧栏模糊是桌面专属，不列为 Android 能力。

| 类别 | FLClash Android 的实际选项 | 本项目采用范围 |
| --- | --- | --- |
| 明暗模式 | 跟随系统、浅色、深色 | 保留现有三种模式 |
| 配色来源 | 跟随系统、八种预设色、自定义颜色 | 保留现有系统取色、蓝/紫/薄荷三种强调色；预设同时覆盖 primary、secondary、tertiary 及其容器色，健康功能色再按主题色族派生 |
| 色彩风格 | 鲜明、氛围、柔和、单色 | 当前未提供这些独立的色板生成选项 |
| 深色背景 | 标准、纯黑，仅深色时生效 | 当前保留现有分层深色表面 |
| 底部导航 | 漂浮、固定，默认漂浮 | 新增可持久化的漂浮/固定选择，沿用漂浮默认值；两种模式使用相同页面与选中状态 |
| 其他外观 | 页面滑动/淡入、液态玻璃（无/标准/极致）、系统字体与字号选项 | 新增可持久化的液态玻璃开关；页面动画与系统字号继续沿用 Android 默认行为，不复制上游质量分级 |

选项源码：[`views/theme.dart`](https://github.com/chen08209/FlClash/blob/7fd417fb9a9a277c6a9339a8ac87f907df7c25f7/lib/views/theme.dart#L78-L104)、[配色与风格](https://github.com/chen08209/FlClash/blob/7fd417fb9a9a277c6a9339a8ac87f907df7c25f7/lib/views/theme.dart#L180-L287)、[纯黑与底栏](https://github.com/chen08209/FlClash/blob/7fd417fb9a9a277c6a9339a8ac87f907df7c25f7/lib/views/theme.dart#L584-L670)。上游系统取色先取 seed，再[生成自身色板](https://github.com/chen08209/FlClash/blob/7fd417fb9a9a277c6a9339a8ac87f907df7c25f7/lib/providers/state/theme.dart#L38-L88)，并非原样沿用 Android 整套 ColorScheme。

底栏结构直接参考 [`pages/home.dart`](https://github.com/chen08209/FlClash/blob/7fd417fb9a9a277c6a9339a8ac87f907df7c25f7/lib/pages/home.dart#L65-L139)：漂浮栏叠放并为列表保留滚动余量，固定栏使用 Material 3 NavigationBar、独立占用内容区下方的空间。本项目通过共享的根页面底部间距替代原有三处固定 110dp 留白；切换样式不会重建两套页面树，也不改变所选页面。新偏好放在现有 `watchfree_theme` 中，沿用外观备份白名单，不扩大健康数据或身份备份范围。

液态玻璃直接移植同一固定提交的 `lib/ui/liquid_glass.dart`、`lib/ui/liquid_glass_capture.dart`、`shaders/liquid_glass.frag` 与 `lib/ui/navigation_dock.dart` 的移动底栏路径：

- `LiquidGlassDock.kt` 用 Compose `GraphicsLayer` 记录后方页面。底栏不在记录树内，避免把自身重复采入；留出 48dp 边界供模糊与折射采样，无 CPU 截图或常驻刷新定时器。
- `res/raw/liquid_glass.agsl` 保留 pill 的 0.72 haze、15.6dp Gaussian 霜化、清晰背景混合、60dp 折射深度、20dp bevel、明暗饱和度 2.1/1.925、hairline 与高光。与 FLClash 一样，清晰与预模糊背景放在同一捕获图集中，宽霜化直接采样预模糊区域；透镜窄边缘使用 Vogel-disc kernel，避免宽模糊出现文字重影。
- 按下时从 secondary 选中底板升起透明 lens，采用 -4.3dp 折射、5.5dp bevel、6.5dp 色散。另行记录图标文字，以 lensContent 的 14dp 折射、11.2dp bevel、3.6dp 色散和 16% 放大绘制透镜内的内容；透镜外保留清晰文字。颜色继续使用当前 Material 主题角色。
- `FloatingNavigationBar.kt` 移植按下、触摸阈值、连续横向拖动、跨项触觉、100ms 速度投影、松手提交和取消恢复；弹簧控制透镜跟随、抬升、横向形变和回落。支持 RTL 与无障碍点击，路由在松手前不切换。
- Android 13 及以上启用 AGSL；Android 12/12L 使用 RenderEffect 模糊，Android 11 及以下使用着色降级。普通漂浮底栏共用拖动行为。
- 上游来源和 GPLv3 文本随 APK 放在 `assets/licenses/FLCLASH-NOTICE.txt`、`FLCLASH-LICENSE.txt`。已移除 Haze 依赖。

验证只使用已连接的实体手机与代码检查，不使用模拟器。真实背景更新、连续跨四项拖动、取消恢复、无障碍点击均由 `LiquidGlassDockTest` 覆盖；坐标、RTL 与甩动边界由 `DockGeometryTest` 覆盖。

## 主题与健康协调色

健康模块不再使用固定粉/橙/紫/青。`WfPalette` 提供步数、心率、压力、睡眠、血氧、体温、呼吸、HRV 与血压的语义色；颜色由当前主题色族生成，在保持指标辨识度的同时共享色相锚点和明暗对比。壁纸取色从动态 primary 色相派生，蓝/紫/薄荷预设各自使用独立的协调色组合。成功、警告、错误保持固定语义，不随主题漂移。
