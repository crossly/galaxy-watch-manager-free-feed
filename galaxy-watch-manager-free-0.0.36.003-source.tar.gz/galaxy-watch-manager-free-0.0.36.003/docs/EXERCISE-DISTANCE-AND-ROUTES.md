# 运动距离与健走地图核查

数据来源：当前手机 `watchfree_health` 持久化的 `HealthRecordStore`，共 8 条 `com.samsung.shealth.exercise` 记录。原始副本及展开后的明细位于未跟踪目录 `private/exercise-investigation/`。自动测试夹具 `app/src/test/resources/health/exercise-history.json` 仅保留核查所需字段，并替换记录 ID。

## 距离

每次运动的 `distance` 单位为米，是该次运动的汇总距离。8 条数据分别为：

| 起始记录日期（上海时区） | 距离（米，四舍五入） |
| --- | ---: |
| 10 月 14 日 | 760.14 |
| 10 月 14 日 | 1137.62 |
| 10 月 15 日 | 765.32 |
| 10 月 15 日 | 1075.80 |
| 10 月 15 日 | 1463.15 |
| 10 月 15 日 | 1075.15 |
| 10 月 21 日 | 627.32 |
| 10 月 22 日 | 1828.16 |

合计原始值为 **8732.66015625 米**，显示为 **8.73 公里**。每条 `mean_speed × duration / 1000` 都与该条 distance 一致（误差小于 0.001 米）。因此没有发现千倍的米/公里单位错误，也不应把 `live_data` 中可能存在的累计距离再逐点相加。

原解析把 distance 提前转成 Int，会丢失不足 1 米的小数。已改为 Double，持久化亦保留小数；UI 汇总后再格式化。此问题只能解释几米的舍入差，不能解释大幅距离差异。

`duration` 是有效运动毫秒数，与 `end_time - start_time` 不一定相同。列表原来只展示整数分钟和一天内的时刻，容易混淆不同日期及有效时长。现已显示日期、起止时间、有效运动时长的分秒，详情显示精确米数、步数、平均/最高心率和平均速度。

## 地图信息

- 8 条记录的 `source_type` 都为 **4**。已解包 Samsung Health `SportSharedConstants.WORKOUT_SOURCE_TYPE_AUTO = 4`，因此是自动识别运动。
- 逐条展开 `live_data` 后，字段全集为 cadence、distance、heart_rate、speed、start_time。
- 逐条展开 `live_data_internal` 后，字段全集为 elapsed_time、interval、segment、source_type、start_time。
- 本批记录无 latitude / longitude、`location_data`、`location_data_internal`；当前 RecordStore 也没有保存的 exercise.route 记录。
- 官方模型 `JExercise` 确有 location 字段，`SportDataConstants.ExerciseEx` 定义了 `location_data` / `location_data_internal`。`com.samsung.shealth.exercise.route` 是另一个保存路线的数据类型，不能仅凭它的名字就把它当成本次健走的 GPS 明细。

结论仅限本批实际收到的记录：**没有可绘制真实地图的定位点**。不能根据步数、速度或距离编造路线，也不能据此断言所有健走都不支持地图。界面明确显示“未收到地图轨迹”。以后若运动包实际带有定位资料，会区分“已收到定位点”和“收到但格式尚未解析”，避免错误地声称不存在数据。

## 复核

`ExerciseLogTest` 使用这批真机数值验证合计、逐条速度/有效时间关系、来源类型、无地图载体状态；另验证小数距离与秒级时长的持久化、位置资料存在时的状态区分。旧整数实现已在实际夹具的精度断言上失败，修复后通过。
