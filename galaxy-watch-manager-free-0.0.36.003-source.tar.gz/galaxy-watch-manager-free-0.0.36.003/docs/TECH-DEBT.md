# 技术债与改进顺序

本页只保留当前边界、仍需实施的改进和验收条件。已完成工作的背景与证据见
[优化记录](OPTIMIZATION-PROGRESS.md)、[本轮审查](REVIEW-2026-11-01.md)；模块定位见
[架构导航](PROJECT-MAP.md)。优先级表示实施次序，架构建议不等同于已复现的运行故障。

## 本轮修复

| 问题 | 处理 | 验证位置 |
| --- | --- | --- |
| RFCOMM 断开回调持资源锁，控制器停止时反向获取锁 | 资源清理与外部回调分离；独立锁仅维持生命周期事件顺序，`stop` 不获取它 | `RfcommTransport.handleEstablishedSocket`；锁路径静态复核，尚无真实蓝牙并发断开的复现验收 |
| 健康报文入口与其他缓存写入口缺少统一同步 | `restore`、`handleMessage` 使用仓库同步保护 | `HealthPersistenceConcurrencyTest` 模拟慢磁盘与并发报文，重启后两条记录均保留 |
| 官方应用部分停用时主操作消失 | 使用“仍有启用的官方应用”作判定，不以“已停用过任何应用”反推整体状态 | `HandoverPrimaryActionTest` |
| 图表手势、夏令时横轴、曲线及窄屏刻度实现分裂 | 提取 `ChartInteraction`，复用 `drawReadingCurve`；周心率也只消费横向拖动 | `ChartInteractionTest`、`HeartRateChartsUiTest`、`MetricChartsUiTest`、`StressChartsUiTest` |
| 孤立方法、未使用参数和引导状态 | 删除无生产调用的旧入口，手动身份统一进入候选验证路径 | 全仓引用检查、编译、身份与交接回归测试 |
| 失效文案、资源重名及架构索引漂移 | 删除 51 项双语未引用键；`selected` 改为业务资源名；导航改用符号定位 | i18n、Android Lint、构建 |
| `WatchController.onEnvelope` 接收与连接生命周期争用全局监视器 | 引入 `SessionReceiveQueue` 有界串行队列（64 帧 / 8 MiB）与会话代次约束，将解析与写盘移出锁；断开与切换时即时废弃旧代次 | `SessionReceiveQueueTest`、`WatchRepository` 状态校验 |
| `WatchState` 跨域单体导致页面级不必要重组 | 引入 `WatchPageState` / `WatchPage` 投影与 `RefreshActionState`，通过 `distinctUntilChanged` 隔离各子页面消费域 | `WatchPageStateTest`、`WatchPageRecompositionTest` |
| `HealthRecordStore` 身份提取二次归一化往返 | 引入 `normalizedIdentity`，在已归一化 JSON 上直接提取主键 | `HealthDataProjectionTest` |
| `HealthRepository` 会话取消时脏数据落盘风险 | 在解码、投影、落盘及应答链路补齐 `isActive()` 检查，保留 Durable-before-ACK 不变性 | `HealthPersistenceConcurrencyTest` |

## 待办

| 次序 | 优先级 | 现状与影响 | 建议及验收条件 |
| --- | --- | --- | --- |
| 1 | P2 | `WatchRepository` 仍混合设备设置、表盘、通知与调度；`WcsSession` 同时包含生产握手和 debug 回放/字段实验 | 优先沿现有稳定协议边界抽出表盘状态处理；debug 实验实现移至 debug source set。让每个新模块拥有解析、状态和取消行为，避免一层层空转发。用现有协议回放与表盘确认测试约束 |
| 2 | P2 | 原生测量偏好、连接归属和交接恢复点有同步 `commit`；这些落盘顺序有业务含义，但部分调用仍可能在主线程发生 | 保留 durable 语义，异步执行对应业务事务；调用方等到真实成功才显示完成。验证进程重启、写盘失败、部分包操作成功和用户取消，不能为消除 Lint 机械替换为 `apply` |
| 3 | P3 | Compose 生产/测试组件存在多个版本来源，Lint 仍提示依赖与其他存量问题 | 单独对齐 Compose 依赖约束，保留小屏、大字号、明暗主题回归；不在并发修复中批量升级工具链。弃用 API 与反射回退逐项按实机证据替换，不全局压制规则 |

## 隐式状态机收敛顺序

按用户体验（中间态与失败态可见、可取消）、开发者体验（迁移局部、可单测）、智能体体验（状态与迁移可从类型推导）三者同时收益排序。以下 13 项已按序收敛到生产代码；每条收敛都逐条保留了右侧列出的既有迁移与恢复约束。

| 次序 | 优先级 | 位置与隐式状态 | 收敛方向 | 必须保留 |
| --- | --- | --- | --- | --- |
| 1 | P0 | 健康报文的 decode→merge→project→persist→ACK 顺序及失败重试 | `HealthMessagePipeline.process` 统一解码、待重试门控、归并/投影与落盘顺序，成功返回 `persisted`、`ackCursor`；仓库通过私有方法提供归并/投影和持久化，实现与 Android 无关的管线 JVM 回归 | durable-before-ACK：仅落盘成功才 ACK 数据游标；失败保持 pending、不 ACK 以重试；控制包无脏数据时免落盘 |
| 2 | P1 | `WatchController` 连接生命周期：9 个字段 + `OnboardingStatus`，`isRunning` 为派生布尔，迁移散在 9 个方法、RFCOMM 回调与 30s 延时 | `sealed ConnectionPhase` + 单一 `transition(next)`，`OnboardingStatus` 退为 UI 投影 | `ConnectionRequestGate` 代际、30s 超时后不复活旧回调、`owns()` 一致性、`PAUSED_FOR_OFFICIAL_APPS`/`PAUSED_BY_USER` |
| 3 | P1 | `DeviceIdentityStore` 身份/交接：7 个持久化键 + 进程内候选与跨键清理 | `IdentityEvent` + 唯一公开写入口 `transition(event)`，原写方法私有化；`IdentityPhase` 从持久化与候选状态派生，交接待定可与已确认身份共存 | 跨进程持久化、`HandoverIdentityTest` 11 项、`releasedToOfficialApps` 阻塞自动/粘性重启 |
| 4 | P1 | `OfficialAppHandover`：`close()` 在操作中只置 `closeRequested`，真正关闭延迟到 `finishOperation`（隐藏的 running→closing-deferred→closed） | `enum HandoverLifecycle { STOPPED, STARTING, IDLE, OPERATING, CLOSING_DEFERRED }` | 回滚 `NonCancellable`、journal 首条不覆盖、snapshot commit-before-mutation |
| 5 | P2 | `ApkUpdater`：`READY` 混同文件就绪/待装权限/已拉起安装器 | `READY` + `AWAITING_INSTALL_PERMISSION` + `INSTALLING` | 权限跳转后仍能回到正确 CTA |
| 6 | P2 | `HealthTab`：10 个布尔 + 可空 `metric`，手动互斥复位 | 单一 `sealed HealthPane` + 可选负载 | 各面板互斥、返回导航一致 |
| 7 | P2 | `ConnectionOnboardingScreen`：显式 `OnboardingStep` + 5 个副布尔，`LaunchedEffect` 命令式迁移 | 步骤与副状态合并到可保存的 `OnboardingUiState`；继续复用 `OnboardingStep` 与 `OnboardingRouting` | `OnboardingRouting` 纯函数与测试不变 |
| 8 | P2 | `WatchNameSync`：6 字段推 read_template→write→confirm_readback | 内部 `enum Stage`（IDLE / READING_TEMPLATE / CONFIRMING_WRITE） | `Result` 语义、`SettingCommands` 替换旧请求 |
| 9 | P2 | `HealthMeasurements`：`acknowledged`+`readbackRequested` 推 SENT→ACKED→READBACK | `PendingStage` 枚举 | ACK-then-readback、单调 `update_time`、新写取消旧写 |
| 10 | P2 | `HealthMonitorSession`：BP review 4 个布尔 | `BpReviewStage` 枚举 | 10s/15s 超时、过期回调守卫（`BpCalibrationStep` 为样板） |
| 11 | P2 | `HealthSyncCoordinator`：`Status` 已建模但冗余 `connected/busy/timeout` | 以内部 `Phase` 替代 connected/busy 冗余布尔，保留负责取消的 timeout Job 与对外 `Status` | 60s 超时、模块完成语义 |
| 12 | P2 | `WatchState.isFindingWatch`：布尔混同振铃/失败/空闲（5 处翻转） | `FindWatchStatus { IDLE, RINGING, FAILED }`，保留派生 `isFindingWatch` | 振铃停止与失败提示区分 |
| 13 | P3 | `RefreshCoordinator`：`active+dispatching+pending+generation` | 轻收敛为 `Phase` | 代际守卫、30s 部分缺失日志、健康 60s 不截断 |

已由代际令牌保证安全、无需重写：`StartupSyncCoordinator`、`AutoQueryCoordinator`、`LogBus.clearGeneration`、`ConnectionRequestGate`、`WatchController.repositoryRevision`。已显式建模、不要改动：`SessionReadiness`、`BpCalibrationStep`、`SettingCommands`、`HealthSyncRequestPolicy`、`OnboardingRouting`、`ReconnectPolicy`、`HandoverJournal`/`HandoverSnapshotStore`。

P0 验证：`HealthMessagePipelineTest` 通过真实报文解码、`HealthRecordStore` 及 `HealthDataProjection` 配合可控落盘回调，覆盖落盘失败不返回 ACK、控制包重试保留原数据、空表/SYNC_DATA 落盘、修订去重及会话取消。`HealthPersistenceConcurrencyTest`（androidTest）保留并发写入与重启恢复用例；本轮只编译，未在设备执行，JVM 测试不能代替 Android 实际落盘或手表游标固化验收。

## 已有边界应保留

- `SessionReadiness` 统一握手就绪；`ConnectionRequestGate` 统一连接代次；两者不应再分散回多个布尔分支。
- `WatchSettingSchema` 与 `SettingCommands` 负责设置规格和确认。未知路径仍有兼容兜底；新增设置必须补规格。
- `WatchState` 已标注 `@Immutable` 并有守卫测试。集合通过新快照发布，注解不代替深层不可变性约束。
- 默认全局查询间隔为 900 秒，允许 30/60/120/300/600/900 秒；保活与传感器采样不属于该周期。
- 真实首次配对、跨手机/固件兼容与长时间双向蓝牙稳定性仍需独立实机验收；模拟器不能证明这些边界。
- 保留厂商来源组件和协议研究资料的授权边界，不因方法未被直接调用而删除 JNI、AIDL、反射或动态加载入口。
