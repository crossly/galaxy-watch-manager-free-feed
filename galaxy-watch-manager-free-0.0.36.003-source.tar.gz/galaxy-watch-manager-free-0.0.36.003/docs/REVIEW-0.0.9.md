# v0.0.9 整体代码审查与开源整理清单

> 后续实施状态见 [OPTIMIZATION-PROGRESS.md](OPTIMIZATION-PROGRESS.md)。下文是审查时的基线事实，保留用于追踪，不表示这些问题仍全部未修复。

审查基线：`main@9e263c183d16fa1b023b8336c0bab33f13353410`（v0.0.9）。

本轮按用户要求检查当前应用整体，不做单个提交的差分审查。仅新增这份报告；未修改应用、协议、测试或发布配置，未安装设备、未发布新版本。问题按两个轴分别记录：**工程规范与结构（Standards）**、**行为与协议口径（Spec）**。编号方便后续逐项修复，不代表所有问题都应放在一次 PR 中。

- P1：优先处理，影响通用可用性或开源交付前提。
- P2：应安排修复，影响数据正确性、状态可信度、稳定性或维护成本。
- P3：整理项，主要影响一致性、可读性与贡献体验。
- “源码确认”表示触发条件和错误路径可由当前实现直接确认，不表示已在用户手机触发。
- “临时复现”表示使用本次编译的生产类，在仓库外构造输入并执行；没有向仓库添加测试或修改生产类。

## 范围与验证

目录扫描覆盖 Android 源码、资源、测试、构建与发布脚本、CI、公开研究资料和主要产品/协议文档。当前主源码有 72 个 Kotlin 文件，共 15,216 行。重点逐段阅读连接控制、RFCOMM/WCS、Asset/Channel、健康记录与投影、睡眠分析、通知桥、更新链路及主要页面；其余页面/资源做结构和定向检索。不是对每个页面进行设备交互验收，也没有重新审计第三方闭源 JNI 的内部实现。

本轮执行：

| 检查 | 结果 |
|---|---|
| `./gradlew :app:testDebugUnitTest :app:lintDebug :app:assembleRelease` | 成功 |
| Android/JVM 单元测试 | 203 项，0 failure / 0 error |
| `python3 -m unittest discover -s scripts/tests -v` | 14 项通过 |
| Android Lint | 0 errors / 43 warnings |
| 临时生产类探针 | 复现下文 B03、B04 的坐标计算、B05、B06、B07 的错误映射、B14 |

现有测试主要覆盖纯解析器和同步辅助类；不能据此声称 Android 生命周期、系统安装器、双工蓝牙竞态和整个 JNI 运行时已得到自动化覆盖。本轮未修改测试来“消除”这些缺口。

仓库没有独立的 CONTRIBUTING / CODING_STANDARDS / 根 LICENSE。明确的本地约定主要来自 README：协议发现需同步维护 `docs/PROTOCOL-SPEC.md`；展示应以真实数据为准；未验收功能不能宣传为可用。结构建议属于审查判断，不冒充已有的强制规范。

## Standards：工程规范与结构

### S01 · P1 · 开源许可证与随包第三方组件的交付边界没有闭合

**位置**：仓库根目录；`app/src/main/assets/sleep/NOTICE.md:1`；`scripts/sleep-engine/README.md:1`。

**事实**：

- Git 跟踪的文件中没有根 LICENSE / COPYING，也没有贡献者许可说明。
- 当前确实跟踪并打包 `engine.jar`、Samsung 来源的 `libmobilesleepjni.so`、模型，以及两种 ABI 的 TensorFlow Lite 库。
- NOTICE 如实说明厂商所有权，也明确写了提取和重新打包不授予新权利；仓库内未见这些厂商组件的再分发许可依据。TensorFlow 的许可证目前仅链接到上游，没有随二进制一并放置完整许可证文本。

**影响**：他人无法从仓库确定原创代码的使用/修改/分发许可；原创开源代码与厂商二进制组件也不能仅靠一个总许可证混为一谈。这是交付信息缺口，本文不据此作侵权法律结论。

**建议**：由维护者选定原创代码许可证；列出第三方组件版本、来源、许可证和分发依据。未明确可再分发的睡眠组件应考虑从开源默认产物中分离，提供可选、本地提取构建路径。不要只把 NOTICE 改写成“开源组件”便视为解决。

### S02 · P2 · WatchRepository 同时承担过多责任，并保留多套可变状态

**位置**：`app/src/main/java/dev/ricky/galaxywatchmanagerfree/feature/WatchRepository.kt:26`（全文件 1,849 行）；`wcs/WcsSession.kt:1`（979 行）。

**判断**：存在可能的 Divergent Change / Duplicated Code。一个 Repository 同时处理连接观察、设置映射、设备快照、设备护理限流、通知构造、表盘命令、健康包拆解、冷同步、睡眠推理调度及 SharedPreferences。健康数据又同时存在 RecordStore、stepsAccumulator/contributions、派生字段和 WatchState 中。

**影响**：修改一项健康规则需要追踪“原始记录 → 增量累加 → 投影 → 状态 → 缓存”多个入口；B03 就是两条计算路径互相覆盖的实例。初始化/关闭离线与在线 Repository 也会触发恢复、序列化和分析调度，不容易独立测试。

**建议**：先建立 `HealthRepository` 单一业务入口，将原始记录、投影、持久化集中；再分离 DeviceSettings / DeviceCare / Notifications / WatchFaces。WcsSession 保留会话和路由，LAB/REPLAY 放入独立诊断模块或 debug source set。不要先引入通用事件总线等大抽象。

### S03 · P2 · 正式包长期记录通知正文与健康记录，备份策略未显式划界

**位置**：`wcs/WcsSession.kt:329`；`feature/WatchRepository.kt:1563`；`feature/NotificationBridgeService.kt:62`；`feature/LogBus.kt:29`；`app/src/main/AndroidManifest.xml:27`。

**事实**：Bridger 发送日志包含标题和正文；健康包日志包含第一条原始记录的最多 1,600 个字符；LogBus 同时写 logcat 与应用私有日志。Manifest 开启 allowBackup，未配置备份排除规则；健康 SharedPreferences、设备快照中的 IMEI/EID 和普通 files 日志均未显式排除。

**影响**：诊断输出混入日常个人内容；备份/设备迁移时，哪些健康数据、身份和日志应被带走没有代码层约定。具体备份是否发生还取决于 Android 版本及系统实现，不能等同于“任何应用可读取”。

**建议**：正常模式只记模块、条数、结果和耗时；原文采集改为显式、限时的诊断模式，导出前脱敏。分别决定健康记录、设备身份和日志的备份策略，配置旧版 `fullBackupContent` 和新版 `dataExtractionRules`，提供数据清理入口。

### S04 · P3 · 文案与展示参数散落，命名和代码格式没有统一约束

**位置**：`app/src/main/res/values/strings.xml`（仅 3 个条目）；`ui/screens/HealthTab.kt`、`ui/screens/SettingsHome.kt`、`ui/HomeScreen.kt`；`feature/HealthMetricLog.kt`。

**事实/判断**：大量中文文案、单位、日期标签直接写在 Composable 或业务枚举中；页面混用通配 import、显式 import、完整限定名与重复 import。Theme 有共享组件，但仍有大量重复的标题、间距和尺寸；`applePress` 等实现名包含借鉴对象的品牌而非交互语义。

**建议**：先抽出重复文案、格式化与共享尺寸，保留协议字段的原样常量；UI 文案用 strings/plurals，领域类型提供指标标识、由展示层负责本地化。补 `.editorconfig` 与一种格式化工具，并将 `applePress` 这类名称改为描述行为的名称。不要把每个一次性的 8.dp 都变成全局常量。

### S05 · P2 · 部分异常被静默吞掉，故障与“没有数据”不可区分

**位置**：`feature/WatchRepository.kt:1407`、`:1440`、`:1532`；`feature/HealthRecordStore.kt:83`；`core/ApkUpdater.kt:217`。

**事实**：表盘确认线程有空的 Throwable catch；健康解码失败直接返回；RecordStore 恢复异常会清空内存集合而不报告原因；签名读取错误退化为空集合。多处 `runCatching` 覆盖 Throwable，缺少错误分类。

**影响**：格式不兼容、缓存损坏、取消任务和确实没有记录常表现相同，维护者只能从结果缺失猜测。更新签名路径还存在 B10 的放行问题。

**建议**：只捕获预期异常，保留 CancellationException 的传播语义；至少记录错误类别、模块、schema 和输入长度，不记录原始个人数据。缓存恢复失败保留损坏文件副本或版本化迁移信息，区分“空”“不支持”“解析失败”。

### S06 · P2 · CI 只覆盖基础构建，缺少结构与 Android 集成边界的约束

**位置**：`.github/workflows/ci.yml:1`；`app/build.gradle:1`；`app/src/test/`。

**事实**：有 JVM 测试、Lint 和编译，这是有效基础；尚无 ktlint/detekt 或同类检查，无 Android instrumentation 测试；睡眠动态加载/JNI 和更新 PackageManager 校验依赖手工设备验证。依赖版本与 SDK/build-tools 配置分散于 Gradle、CI、签名和睡眠构建脚本。

**建议**：将本次复现输入补成回归测试；提取安装包检查策略做纯逻辑测试，并增加少量 PackageManager/FileProvider 与恢复流程的 Android 集成测试。加入格式检查和有限的复杂度检查；统一 SDK/依赖配置来源。原生 ARM64 实机回放继续单列，不能用 x86 模拟器测试替代。现有 Lint 能直接报告的旧依赖/弃用 API 不在本文重复计成独立发现。

### S07 · P2 · README、功能矩阵和 SSOT 中存在过期或相互矛盾的描述

**位置**：`README.md:34`；`docs/SHEALTH-FEATURE-MATRIX.md:39`；`docs/PROTOCOL-SPEC.md:674`、`:719`；`MainActivity.kt:74`。

**例子**：

- README 仍以“0.0.3 新增、未连 ADB、待真机复核”承载现在的健康能力说明，缺少 v0.0.8 UI 与 v0.0.9 离线分析的当前入口说明。
- 功能矩阵仍将目标进度环、里程碑卡等旧界面列作当前呈现，现健康主页已经改版。
- SSOT 仍称心率按 `(时间, 值)` 去重、日统计增量加权；当前主路径按时间覆盖，并从完整 RecordStore 重新计算。
- 睡眠 SSOT 称起点差 6 小时判同夜，而当前 `SleepParser.merge` 判断实际区间重叠；此方法与当前主要投影路径的关系也未说明。
- MainActivity 的更新注释仍说需要去设置填写令牌，而正式更新早已无需令牌。

**建议**：README 只描述当前行为和边界，历史开发记录留在 release notes；SSOT 中区分“抓包事实”“当前实现”“历史方案”，删除旧规则或显式标注已替换。避免继续添加多个同名章节而保留冲突规则。

## Spec：行为、数据与协议正确性

### B01 · P1 · 正式握手仍依赖开发设备身份；自定义节点入口没有完成闭环

**位置**：`wcs/WcsSession.kt:67`、`:583`、`:967`；`wcs/WcsPaths.kt:318`；`feature/WatchRepository.kt:1066`；`ui/screens/SettingsTab.kt:276`。

**证据**：CREDENTIAL 模式直接发送固定 `CREDENTIAL_FRAME_HEX`，含开发手机节点和蓝牙名；phoneNode、fallback watchNode 也有设备专属默认值。`setCustomPhoneNode` 只按长度 7/8 判断，未校验 hex，未持久化；它只改变后续字段，不重建最初发送的固定 NodeInfo。新会话会回到默认身份。

**影响**：换手机/换手表不能认为只输入节点就可建立一致握手；UI 允许的配置和真实握手身份会分裂。README 已明确“不支持完整首次配对”，所以这是已知兼容边界的实现债，不是本轮新发现的回归，也不能通过随便随机一个 ID 修复。

**建议**：独立 PairingIdentity 模型，以配对设备为作用域持久化已确认身份，所有信封/NodeInfo 从同一模型生成。未登记身份明确报告不支持，样本仅留在诊断路径。首次配对需要独立协议开发和真实跨设备验证。

### B02 · P2 · 握手状态上报伪装成固定开发手机，与手动刷新路径不一致

**位置**：`wcs/WcsSession.kt:849`、`:921`；`feature/WatchRepository.kt:791`。

**证据**：握手的 `sendStatusExchange()` 固定使用 zh/CN/Hans、Asia/Shanghai、Android 16、SDK 36、开发机固件号及 MCC/MNC；而 `buildPhoneStatus()` 会读取当前 Locale、TimeZone 和 Build。握手与手动刷新调用两套实现。

**影响**：其他时区、地区或 Android 版本启动时会报错手机环境；即使本机稍后刷新纠正，也可能先引起手表语言/时区同步或能力判断不一致。本轮未在其他时区的手表实测其具体副作用。

**建议**：统一从同一个状态构造器生成；确需固定的官方兼容版本单独命名为协议兼容常量。测试明确注入 Locale、ZoneId 和 BuildInfo。

### B03 · P2 · 全天热量/距离会被不完整的区间集合覆盖

**位置**：`feature/WatchRepository.kt:1607`、`:1635`；`feature/HealthDataProjection.kt:82`。

**临时复现**：当天 summary 为 `300 kcal / 4,500 m`，同时仅收到一条区间 `5 kcal / 75 m`。投影返回 `5 / 75`，Repository 无条件用它覆盖前面刚读到的 summary。

**影响**：步数可能显示全天总量，但热量与距离只显示部分同步区间，数值显著缩水。区间里即使没有 calorie/distance，当前 amount 缺失返回 0，也能覆盖已知全天值。

**建议**：投影显式建模 summary、区间和覆盖完整性，完整全天值优先；仅在确认区间覆盖完整或没有 summary 时采用区间和。未知值保持 null，不能用 0 代表字段缺失。补 summary 与局部区间同批/异批、明细缺字段的回归测试。

### B04 · P2 · “今日采样分布”实际传入近 7 天样本，坐标被压到最右边

**位置**：`ui/screens/MetricSheets.kt:92`、`:185`；`ui/components/MetricCharts.kt:44`、`:69`。

**证据/临时计算**：HealthTab 传入近 7 天 samples，MetricSheet 原样交给 MetricLineChart；图表以最早样本当天零点作为原点，横轴固定 24 小时并把超界值 clamp 到 1。输入“昨天中午、今天中午”，今天样本 x=1.0，而今日坐标应为 0.5。

**影响**：累积多日后，最近几天样本堆成 24 点位置的线段，标题与所画数据不符。最高/平均/最低也用全量 samples，统计时间窗口没有单独标明。

**建议**：图表参数显式传入所选 LocalDate/ZoneId；只画 `onDay(samples, selectedDay)`。统计说明是“今日”还是“近 7 天”，周趋势继续用全量。补多日样本和只有历史无今日样本的测试。

### B05 · P2 · RecordStore 未统一长字段名，记录在进入解析器前已被合并丢失

**位置**：`feature/HealthRecordStore.kt:28`、`:34`、`:36`；`feature/ExerciseLog.kt:124`。

**临时复现**：两条无 UUID 的运动记录分别使用 `com.samsung.health.exercise.start_time` 和 duration 长字段名。ExerciseLog 能解析两条，但 RecordStore 的 fallback identity 只读短名，两条都得到 `|||`，存储后仅剩 1 条。revision 还借用专门的 step_count 字段函数，裁剪时间同样只认短名。

**影响**：标称兼容的长名记录可能在公共入口静默丢失，历史裁剪和新旧版本替换也可能失效。

**建议**：在数据进入存储时按模块 schema 归一化身份、测量时间与修订时间；不要用计步专属解析器作为所有模块的修订规则。缺少足够身份信息的记录要明确处理，不能把全空 key 当正常主键。

### B06 · P2 · 睡眠 GAP/LATENCY 边界被先过滤，前一分期被错误延长

**位置**：`feature/SleepParser.kt:109`；规则：`docs/PROTOCOL-SPEC.md:698`、`:713`。

**临时复现**：`LIGHT@t0 → GAP@t+60s → DEEP@t+120s → AWAKE@t+180s`。预期浅睡 60 秒，实际浅睡 120 秒，因为 mapNotNull 先丢弃 GAP，随后才取下一个有效阶段作为终点。

**影响**：已同步的 `sleep_status` blob 遇到脱落或缺测时，会把未知区间算成上一档睡眠，虚增时长并影响效率。此问题在接收分期 blob 路径，不等于已验证的本地推理路径也存在同一错误。

**建议**：先对完整样本序列确定相邻时间边界，再决定该区间是否属于可统计分期；GAP 保留为不统计的间断。补 GAP、LATENCY、未知码、重复时间戳测试。

### B07 · P2 · 部分运动类型数字映射错误

**位置**：`feature/ExerciseLog.kt:71`、`:81`；核对来源：本地 Samsung Health `SportTypeConstants.java`。

| 编码 | 当前显示 | 三星常量对应 |
|---|---|---|
| 12001 | 轮滑 | AEROBIC（有氧健身） |
| 14002 | 户外游泳 | AQUAROBICS（水中有氧） |
| 14004 | 皮划艇 | SAILING（帆船） |
| 11007 | 滑冰 | CYCLING（骑行） |
| 12002 / 12003 | 滑雪 / 单板滑雪 | 不应以这两个值映射；源码为 16002 / 16007 |
| 9014001 | “运动 9014001” | SWIMMING_OUTDOOR（户外游泳） |

**建议**：从经核对的常量表生成可追溯的数据文件，而不是凭编号区段手写。为这些错位值补表驱动测试。未支持的值继续诚实显示编号。

### B08 · P2 · 设置发送失败仍改成目标状态；PSM 重试没有请求作用域

**位置**：`feature/WatchRepository.kt:913`、`:970`、`:1280`。

**源码确认**：setAod/setBrightness 等先修改顶层 WatchState，再进入 updateSetting；若 writeSetting 返回 false，updateSetting 只写日志就返回，先前状态不回退。PSM 也提前修改已显示值；重试使用独立 Thread 和共享 psmConfirmedAt，任务不随 Repository.close 取消，也不关联具体目标命令。

**影响**：断线或队列失败时看起来“已生效”；连续切换或重连中，旧目标补发和新请求共享回执状态，不能可靠说明哪次操作被确认。

**建议**：分开 confirmed value / pending requested value；发送失败恢复已确认值并显示错误，回包确认后才更新 confirmed。PSM 每次操作带 generation/request token，最新请求替换旧重试，任务归入可取消的 scope。

### B09 · P2 · 转发通知丢失原始 id/tag，时间取模导致覆盖或重复

**位置**：`feature/NotificationBridgeService.kt:50`、`:53`；`feature/WatchRepository.kt:1190`；`wcs/WcsSession.kt:292`。

**源码确认**：手机端去重用 package/tag/id，但向 Repository 仅传 package/tag/time；Repository 不用 tag 构造手表身份，改用 `time % 100000`。WcsSession 又把 tag 固定为 null/null_tag、UID 固定 1000，通知 when 改成当前时间。

**触发例子**：同一包两条不同 tag/id、相同 postTime，或 postTime 相差 100,000 ms，会生成同一手表路径；同一个原始通知更新 postTime 则可能生成新路径，手表留下重复项。

**建议**：引入 NotificationIdentity（package/user/id/tag），从 StatusBarNotification 一直传到 Bridger；保留真实 when/postTime 的约定。无法回传清除是已知边界，不应把该边界误写成已同步清除。

### B10 · P2 · APK 校验失败时没有完全拒绝；也未核对包名和实际版本

**位置**：`core/ApkUpdater.kt:197`、`:211`、`:217`、`:259`。

**源码确认**：摘要缺失时跳过；已安装应用签名查询失败返回 emptySet，`expectedSigners.isNotEmpty()` 条件使比对直接跳过。ArchiveInfo 只用于签名，未验证 packageName、longVersionCode 与清单、当前应用的关系；READY 快捷复用也只按 versionName 和文件存在判断。

**影响**：界面文案“已校验通过”强于实际保证。并非声称任意不同签名包都能覆盖本应用——Android 安装器仍会执行自身签名/版本规则——但当前应用自身不能保证交出去的是本包、清单所述版本且完成全部校验。

**建议**：缺摘要、读不到当前签名或读不到 ArchiveInfo 一律进入明确错误；核对包名、单调版本号、文件大小、SHA256、签名集合，返回结构化 VerifiedApk。安装时确认 READY 所属清单/文件身份，清理逻辑不要只凭文件名 versionName 前缀。

### B11 · P2 · 健康缓存没有设备作用域，切换手表可能混入旧记录与覆盖标记

**位置**：`feature/WatchRepository.kt:46`、`:193`、`:405`；对照设备快照 `:120`。

**源码确认**：设备快照按 watchNode 分区，但健康记录、当日 steps_coverage_complete、历史及目标都写固定的 watchfree_health。onWatchNodeChanged 只恢复设备快照；不会切换健康 Store、覆盖标记或分析缓存上下文。

**影响**：同一安装换到另一只表后，旧表今天的记录与“已完整回补”标记继续有效，可能跳过新表回补或把两只表记录累加。即便未来有合并同一个人多设备的需求，也不能直接按记录 UUID 累加作为正确合并规则。

**建议**：明确用户/设备健康记录的作用域；保留来源 ID，按设备维护同步覆盖与游标；展示合并另设明确策略。迁移现有单设备缓存时不丢旧数据。

### B12 · P2 · 睡眠分期 Blob 仍使用无上限解压

**位置**：`feature/SleepParser.kt:361`；对照 `feature/HealthJson.kt:15`。

**源码确认**：公共 HealthJson 已实现有界 gzip 解压，但 `sleep_status` 单独调用 GZIPInputStream.readBytes()，没有解压后大小限制。上层消息大小限制只约束压缩输入，不能限制嵌套 blob 的膨胀。

**影响**：异常或损坏的睡眠输入可大量分配内存，导致连接被异常中断或进程 OOM。本轮没有故意在设备上触发 OOM，也不据此宣称存在来自互联网的直接攻击入口。

**建议**：统一使用有界解压 helper，明确压缩输入/解压后 JSON/样本数三层限制；失败保留原始记录状态，不把它标记为“无睡眠”。

### B13 · P2 · 公开 APK 镜像与版本清单不是稳定的一次提交，重跑旧发布可回退 feed

**位置**：`.github/workflows/release.yml:14`、`:136`；`scripts/write-update-feed.py:41`。

**源码确认**：APK 在 apk 分支被 force push 替换，version.json 另写 main，URL 引用可变分支。每次新发布删除上一版本文件，但客户端和 CDN 仍可能持有旧清单。concurrency 按 tag 分组，不同版本/旧标签的 workflow_dispatch 可同时写同一 feed；没有禁止较旧 versionCode 覆盖较新清单。

**影响**：发布交界期旧清单可能指向刚删除的文件而 404；重跑旧标签可能让公共 feed 和唯一 APK 都回退，漏报最新更新。`continue-on-error` 又意味着总体 Release 成功不等于镜像步骤成功，需继续分别检查（目前的发布人工核验有做到）。

**建议**：清单 apk_url 指向不可变 commit SHA 或持久公共资产；至少保留前一版。所有版本的 feed 写入共用发布锁，并在远端比较 versionCode 保证不倒退。发布摘要分别报告私有 Release、镜像、清单三个状态。

### B14 · P2 · 没有时间的楼层记录被当作今天

**位置**：`feature/HealthMetricLog.kt:196`、`:206`。

**临时复现**：`{datauuid:"missing-time", floor_count:5}` 无任何时间字段，accumulate 仍返回今日 5 层，因为只有 `ts > 0` 时才检查是否为今天。

**影响**：历史回补/不完整记录缺时间时会凭空归入当天，不符合“只显示真实日期所属值”的口径。保留记录可以，但不能在没有日期证据时强行入今日。

**建议**：未能得到有效测量日期时只保留为未归属记录，不参与今日统计。长字段名和 create/update 兜底是否能代表测量日期也应按模块明确。

## 硬编码分类：保留哪些，清理哪些

| 类别 | 例子 | 建议 |
|---|---|---|
| 协议固定值 | WCS UUID、tag 编号、40001–40006 分期码、官方包名和签名指纹 | 保留命名常量与来源，不能为了“消除硬编码”改成随意配置 |
| 设备专属身份 | 默认 phoneNode/watchNode、固定 NodeInfo 中的开发机信息 | 从配对身份生成；历史样本放诊断夹具，见 B01 |
| 真实运行环境 | 时区、Locale、Android 版本、固件、运营商字段 | 动态读取/明确未知，见 B02 |
| 产品与部署配置 | 源仓/公开 feed 地址、超时、重试间隔、缓存上限 | 集中到合适模块或构建配置，保留合理默认；不用全做成用户设置 |
| UI 文案与设计参数 | 中文字符串、单位、日期格式、重复标题尺寸 | 文案资源化，共享设计 token；一次性局部尺寸可留在局部 |
| 真实数据样本 | replay_p2w.bin、抓包十六进制、研究与截图资料 | 公开前逐项审查去标识化；正式包不应默认携带整套实验回放 |

`SESSION_TOKEN` 在源码已注明实际为消息头中的应用签名 SHA-1，不能仅因名字带 TOKEN 就认定为泄露登录令牌。建议改为表达真实含义的字段名，和真正的私有密钥分开管理。本轮没有进行完整 Git 历史密钥扫描，也未逐张 OCR 审查仓库截图，不能据此出具“历史数据全部脱敏”结论。

## 建议实施顺序（不等于本轮已修复）

1. **先定开源交付边界**：S01 许可证/第三方组件与 B01 设备身份的当前支持范围；这些决定 README 应怎样描述产品。
2. **小 PR 修数据错误**：B03/B04/B05/B06/B07/B14，每项先加能失败的回归测试，再修现有逻辑，避免同时改界面。
3. **小 PR 修命令和更新状态**：B08/B09/B10，明确请求身份、confirmed/pending 和校验失败路径。
4. **存储与生命周期整理**：B11、B12、S02/S03/S05，设备分区、统一投影、有界输入与可取消任务；涉及缓存迁移需单独验收。
5. **发布与贡献体验**：B13、S04/S06/S07，稳定下载地址、规范检查、文案资源及同步文档。

不建议一次性重写整个架构。现有 Asset 落盘后 ACK、同步游标与 DataItem 一起保存、RecordStore 先替换修订再投影、离线推理串行和结果缓存等方向应保留；按具体问题加边界和测试。

发现统计：**Standards 7 项（最高 S01：开源许可及第三方分发依据缺口）；Spec 14 项（最高 B01：开发设备身份仍进入正式握手）。其余多为 P2 正确性与工程问题，S04 为 P3 整理项。**
