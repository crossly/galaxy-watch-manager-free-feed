# Samsung Health Monitor 血压计算逻辑：Java 与 ARM 原生库分析

核对对象：Wear OS Samsung Health Monitor 1.5.1.022；APK SHA-256 `a714e9a5950f456b8da4843bd6cdb19948a0c6fd9101b473e24beb3384a2c620`。

结论：该版本已恢复的 BP 计算路径是**个人参考血压 + 脉搏形态特征变化的分段修正算法**。它不是用一个通用的正常血压值直接计算所有人，也没有在这条计算路径上观察到 TFLite/神经网络推理调用。本文是对官方 Wear OS Health Monitor 库的静态分析，作为理解官方校准与数据格式的历史逆向背景；心率数据来自 Samsung Health 官方同步，ECG 与血压均基于手表官方 SHM 测量与校准结果桥接（血压依赖官方袖带校准并在用户完成官方流程后正常出值），本项目不在本 App 内单独采集传感器，自研血压算法与独立实验模块已彻底放弃并移除，不保留任何独立传感器运行链路。

## 1. 分层与入口

| 层 | 位置 | 已观察到的工作 |
|---|---|---|
| 采集 | `pl.onEventChanged`、`sl.g`、`fn` | `sem_sensor` 类型 28 的 `getGreenRaw()`，写入 4096 点环形缓冲；同时监听佩戴与 HR 质量状态 |
| 调度 | `rl.run`、`fl.e`、`zl.e` | 预积累后每 10 ms 消费一点，每 20 点调用 JNI |
| JNI | `BpLibrary` → `libshm-bp.so` | Java 数组/原生参数转换，调用计算库，包装返回结果 |
| 计算 | `libbp_v3_06_10.so` | 插值、滤波、代表脉搏、形态特征、校准合并、分段血压修正 |
| 显示 | `vl.a` → `DmcFirFilter` → `BpPpgView` | 显示脉搏曲线；不能当成进入血压 JNI 的同一条滤波路径 |
| 保存同步 | `zl.e`、`ln`、`/991d` | 成功结果保存到 BloodPressureData，再请求手机同步 |

主路径：

```text
原始 green_raw
  → 环形缓冲 / 20 点分批
  → estimateBP
      → 100 Hz 输入坐标 → 样条插值到 250 Hz 内部网格
      → PPG_main → PPG_preprocess → PPG_represent
      → CCD_main → CCD_onedur_RPG → ccd_feat_extract
      → 当前 16 维特征
      → recal_BP(参考 SYS/DIA, 校准特征, 当前特征)
  → 取整 → 保存 / 同步
```

这条调用链没有 ECG R 峰输入，也没有来自第二个测量部位的脉搏到达时间。因此不能把它描述成已经证实的 ECG–PPG PAT 或双点 PTT 测量。此前关于“脉搏传导时间”的通用说明不足以描述此版本实际实现。

## 2. 原始输入与采样时序

`pl.onEventChanged` 读 `SemBpManualSensorEvent.getGreenRaw()` 并保存为环形缓冲的一个数值。`rl` 等到写位置超过 200 后，把读位置置为写位置前 100，复位原生状态，再以 10 ms 定时消费。`fl/zl` 收满 20 点调用 `calBpProcess/estBpProcess`。

原生 `estimateBP` 按 100 Hz 输入、250 Hz 内部重采样网格设计；插值本身不增加采样信息。当前项目沿用三星官方手表测量流程；此设计参数用于解释官方采样与校准要求，不代表 Watch Manager 自行采集了 BP 原始波形。后续依次调用 `PPG_main`（取反、预热、IIR 预处理、代表脉搏筛选）、`CCD_main` 与 `ccd_feat_extract`（逐次差分至四阶、形态特征提取）。不使用 ECG R 峰作为该函数的输入，不能称为已实现双点 PTT 测量。
## 3. 滤波、代表波与质量筛选

`PPG_main` 对传入原始值取负并进入初始化/预热状态；内部参数包括 250 的采样网格值。`PPG_preprocess` 有两组带历史状态的递归滤波（A/B 系数），并对路径作差。系数对象名包含 `glpf` / `ghpf`。尚未独立求频响，不给出未经核对的截止频率。

`PPG_represent` 包含：

- 波形幅度检查、周期边界与长度处理；
- 中位数、相关系数与周期长度离散程度；
- 对多段脉搏作幅度归一化和代表波加权合并；
- 一处权重由相关系数变换为 `2 × correlation − 1`，低于 0.5 的权重归零；这一分支相当于只保留 correlation ≥ 0.75 的候选，但不能将其当成全算法唯一的质量门槛；
- 多个质量指标和成功标志，失败时不应输出血压。

Java 侧也检查移动、低可靠性、脱腕等状态：`fl0` 可发布 `-11`（移动）和 `-10`（物体/低可靠性类）。

**显示滤波要单独看**：`DmcFirFilter.PPGFilterFor100Hz` 是 71 抽头 FIR，调用位置在 `vl.a` 给波形视图供数。送入 JNI 的是 `fl/zl` 的原始整数分块。不能把屏幕曲线或这一 FIR 直接当成算法内部处理结果。

## 4. 16 维特征不是 16 个血压预测值

`CCD_onedur_RPG` 从代表波截取一个周期相关区段；`ccd_feat_extract` 连续计算一阶至四阶差分，寻找导数极值、过零点和形态拐点，存在大量候选点筛选和有效性分支。`CCD_main` 把内部结果整理为 16 个 double：

| 特征下标 | 代码可以支持的说明 |
|---|---|
| F0 | 离散形态状态；后续区分 0/1/2 分支，生理名称未确认 |
| F1 | 第二个离散/有效性状态，用于选择修正路径；生理名称未确认 |
| F2、F3 | 内部形态量之间的比值：同一分子分别除以两个提取量 |
| F4–F6 | 三个波形标志位置，含截取偏移修正；内部网格位置，不能直接叫毫秒 |
| F7 | 指定位置相对周期起点的幅度之比，可使用校准位置辅助取点 |
| F8 | 两个提取幅度量之比 |
| F9–F11 | 提取幅度量除以三个形态量 |
| F12–F14 | 带 0.1 / 0.05 幅度修正的形态比率 |
| F15 | `15000 / 周期长度`；在 250 Hz 网格下等于 `60×250/周期点数`，与心率换算一致 |

没有为 F2–F14 强行赋予“血管弹性”“脉搏传导速度”等名称。需继续从大型提取函数中的结构偏移、条件和对照波形逐项验证。`ccd_feat_extract` 完整伪代码约 130 KB；REA 大函数值流记录有明确截断限制，不能把伪代码完整保存等同于所有语义已经恢复。

## 5. 三次校准具体做了什么

1. `cal_bp_proc` 调用同一 `estimateBP` 主体的校准模式，取得一次有效 PPG 的特征和心率。
2. `fl.e` 把该次特征写入 CalibrationConfig，向手机返回 `hr/datauuid`。
3. 手机的 `update_calibration` 把实际袖带读数 `ref_systolic/ref_diastolic` 按 datauuid 绑定到这次特征。
4. 三次完成后 `pa.b` 把三份读数与特征交给 JNI `averageMcal`。Java 虽分配 40 行，JNI 实际固定调用 `average_mcal(3,...)`；不能理解成用户要测 40 次。
5. `multi_cal` 的参考 SYS/DIA 作平均并取整，合并次数保存为 3；F2–F15 作算术平均，F0/F1 按计数投票选择离散状态。
6. 写入 `shealth_monitor_bp_calibration_last_feature`：`refSystolic/refDiastolic/numOfMergeData/features/calUuid`，并独立保存校准成功时间。

Java 合并后还要求参考收缩压在 70..180、舒张压在 40..120；这是该版本实现的校准数据范围检查，不是正常血压的判定标准。

## 6. 最终计算公式的可恢复结构

以下是对 `recal_BP` 的数学整理，符号是分析用名称，不是三星原始源码变量名。设校准特征为 C[0..15]，本次特征为 X[0..15]，参考读数为 S0、D0。

首先生成比值，例如：

```text
r2  = X2 / C2
r3  = X3 / C3
r8  = X8 / C8
r15 = X15 / C15
```

再根据 C0/X0（形态状态）、C1、r2、r15 选择不同的比率组合。可见的路径包括：

- 在 X11/C11 与 X13/C13、X12/C12 之间切换；
- 在 X9/C9、X10/C10 与 X13/C13、X14/C14 之间切换；
- 对某些比率与 X8/C8 取平均；
- 特殊形态分支按位置差是否大于 20，选 X7/C7 或 X8/C8；
- F15 的相对变化和三个标志位置变化还参与附加偏置修正。

对大于 1 的某些比率使用平滑压缩：

```text
T_k(r) = 1 + sqrt(k) − k / (r + sqrt(k) − 1),  当 r > 1
T_k(r) = r,                                    当 r ≤ 1
```

代码中可见 k=10 和 k=2。它让较大的比率变化逐渐饱和，避免直接线性放大。

三个变化量生成的单项权重可整理为：

```text
w(r) = min(1, 0.6 + abs(r − 1))
W = [w(r2) + w(r_selected) + w(r2 + r_selected − 1)] / 3
```

此整理限于正常有限输入，边界比较的浮点行为仍以原库为准。

最终写入结果的结构在伪代码中明确可见：

```text
S = S0 + W × gainS × deltaS − biasS
D = D0 + W × gainD × deltaD − biasD
```

- `deltaS/deltaD` 来自以上按形态分支选择的特征比值及交叉项；不是一个通用的“心率乘系数”。
- 收缩方向修正为非负时 `gainS=50`；负方向的增益依赖校准脉压 S0−D0，并有上下界。
- 舒张方向修正非负时 `gainD=42`；负方向时 `gainD=0.4×D0`。
- bias 由心率/位置变化等条件分支决定；不能为了简化把它删掉。
- `est_bp_proc` 最后把非负结果按 `+0.5` 转为整数，JNI 将其包装为结果对象。

这解释了校准为何直接影响读数：S0/D0 明确出现在最后的加法中，而不只是 UI 上的“已校准”标志。把一个通用正常值写进去，就会把输出基线锚在这个值附近，不会自动获得个人真实基线。

## 7. 对官方校准流程的实现意义

原生库的输出以个人校准的 S0/D0 为基线，因此需要用手表端记录的 calibration_time、条款状态和校准配置判断流程。向 measuring 端点发送 `do_measure` 只会直接启动测量；在无有效校准特征时，测量页会报告无法设置测量特征，于是用户只看到“请先校准”提示而不能进入校准引导。

三星官方手机端 `BloodPressureController` 的分支是：校准可用时请求 `do_measure`；缺少有效校准时请求 `do_calibration`。Watch Health Monitor 会把 `do_calibration` 路由到 BpMainActivity，由它进入 calibration / expired-calibration 页面。当前 App 入口读取监测器上报的 `tnc`、`calibration_time` 和 service 状态：只有条款已完成、且校准时间仍在本地日历 28 天有效期内时才发送 `do_measure`；未校准、过期或状态未知时启动手机三轮向导，直接发送 `prepare_calibration` 并逐轮推进 `start_calibration` / `update_calibration` / `initial_calibration`，由手表官方页面与算法完成采样和合并（`v0.0.29`，2026-11-04 真机验证通过）。条款未完成时给出说明，不自动发送 `terms_and_condition`，不构造生日/个人档案或校准数值。

这条集成继续使用三星 Health Monitor 官方传感器流程和其本地校准记录，官方袖带校准后的实际血压结果同步与校准有效状态已在实机得到验证并正常出值。心率数据由 Samsung Health 官方服务同步，本 App 不采集原始传感器，也没有把三星原生算法库接入本 App。独立传感器采集与自研血压重算已彻底放弃，应用内不保留任何独立运行链路。

## 8. 证据与限制

ARM32 Ghidra 12.1.4 当前程序地址（不是 ELF 文件偏移）：

| 位置 | 地址 | REA Evidence |
|---|---|---|
| JNI estBpProc | 0x11ebc（JNI 库） | `ev_1af44fb2bdb23f9da328a566e88ce28adb878683efa480793aed251db2cfaa50` |
| JNI averageMcal | 0x11b94（JNI 库） | `ev_580bc08d31af8bed2debe2f904e09566bc1adb9aa5267909581b4b758a414ccb` |
| estimateBP | 0x1cec0 | `ev_0ed0e5f2538d8d56b9ea1e3108e06427f21baae3b94482d146274fce04360f45` |
| recal_BP | 0x1c6a8 | `ev_e86934b1b2e427619da5d59d39a8fe86aa0f4ec1baf56fbccbf71d628730b416` |
| multi_cal | 0x1c46c | `ev_747268050b97ffdcd9d877c29e35ad1d78e58bb465105fb35bcaa86a663f3a61` |
| PPG_main | 0x21d44 | `ev_8f114c4db6054d4c7a5793f48b55069fcbb8cb31c32b5aae9617d66b5c621e63` |
| PPG_preprocess | 0x2225c | `ev_dc5d0ad7a7cb5a50a485bfee3e11d0d2bcb6bce144c2b5fec8e7c0d21c4a5078` |
| PPG_represent | 0x226d0 | `ev_daeafec13c61543385102f6862415a93f56eea8c1be23c9042a02a587bc301f7` |
| CCD_main | 0x219d0 | `ev_a9a598a42fec6e5abfde70890478f280859d5ae7e8301af18aaf530d88a41d82` |
| ccd_feat_extract | 0x1da28 | `ev_f5c1283ee45fb752f2b298b3900d45bf58d45890270730e3744bd2541735a02e` |

库 SHA-256：

- `libshm-bp.so`：`d6f69fe504d21ceefcc184797e57f64ba2133b889ad875483aa05c0387b07b20`
- `libbp_v3_06_10.so`：`9b30c1de424e77b110a8be14bc4152e3b212349af3ca9c564da82e190538d4a9`

完整 REA 记录和私有伪代码保存于 `private/shm-investigation/bp-native/`。APK 全量提取因大小写冲突资源失败，随后用 Python ZipFile 只读提取两份原生库并计算摘要；没有替换 APK 或执行库。Java 来源为既有 JADX 输出。

Ghidra 的恢复类型、void 返回、栈局部变量分割、ARM 浮点条件和间接调用可能不等于原始声明；大型提取函数值流有截断。本文给出已核对结构，不宣称逐指令/逐数值等价，也没有用用户测量生成任何未经验证的血压值。
