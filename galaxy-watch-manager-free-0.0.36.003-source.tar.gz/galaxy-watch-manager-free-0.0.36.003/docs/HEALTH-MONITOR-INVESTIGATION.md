# Samsung Health Monitor：ECG / BP 逆向与验收记录

状态：**ECG 与 BP 官方结果同步已在实机验证；用户完成官方袖带校准后，已收到真实 BP 记录与校准有效状态，用户也已确认当前心率和血压功能可用。** `v0.0.29` 的手机三轮袖带校准向导已于 2026-11-04 由用户真机确认完整走通，手表端不再闪退。独立传感器实验已撤下，心率继续读取 Samsung Health，ECG/BP 继续使用官方 SHM。

上述验收来自开发设备，不覆盖 Watch 4 / 5 / 6。2026-11-02 对 `v0.0.21` 的兼容性复核定位了非空校准配置、强制重校准和状态刷新方面的缺口；`v0.0.22` 曾错误改为手机版 SHM 交接，`v0.0.23` 已撤销该路线并恢复直接呼起手表端校准，`v0.0.29` 进一步移除并发远程 Intent 并改为纯 `/991` 三轮编排。Watch 4 / 5 / 6 仍需各自真机验收。详见本文“Watch 4 / 5 / 6 血压校准兼容性复核”。

此前“收到 request_connection 即全流程激活/通信成功”的结论不成立。该消息表示手表请求恢复连接，不能证明传输握手完成，更不能证明数据已接收。本文替换之前过度确定的说明，以静态来源、观察结果和未完成项分别记录。

## 输入与分析范围

- 手机 APK：`com.samsung.android.shealthmonitor`，`1.5.2.002 / 1502002`，SHA-256 `af8039dead5b697feb1940d290e830f9eed0b9b51bcc60a25f8e6a1f81cf80a3`。
- 用户提供的 Wear OS APK：`1.5.1.022 / 1501022`，`minSdk=30`、`targetSdk=36`、armeabi-v7a；manifest 有 `android.hardware.type.watch`。手机与手表包名相同，不能仅凭包名辨识平台。
- 用户手表从 `1.2.7.003` 覆盖升级到该 Wear OS 包后，通过 ADB 核对已安装版本为 `1.5.1.022`。原 APK 备份在本地忽略目录，未卸载/清空用户数据库。
- JADX CLI 输出分别在 `research/decompiled/shealthmonitor/`、`research/decompiled/watch-shealthmonitor/`。两次反编译均有少量错误；不能称“所有代码完整恢复”。
- 手机 REA 包证据 `ev_336695698fdc3a9357d4e55c751f4361ad54527b842fcd72a88825656d4ef920`；Channel enum `ev_6d00edc268092b25ba30fbe16924059c00414c73fd6a40682497e021f8a95306`；WearEventReceiver `ev_108b8f437f8eefbc466a440d3fdc08e4876438c381fa3434adc6b9b16a24cce1`。
- 用户 APK、测量内容、日志及屏幕证据只留在 Git 忽略的 `research/apks/`、`research/decompiled/`、`private/shm-investigation/`，不加入公共源码或截图目录。

## 已核对的独立协议

| 通道 | 消息 | 控制 | Channel 数据 |
|---|---|---|---|
| BP | `/991` | `/991c` | `/991d` |
| ECG | `/992` | `/992c` | `/992d` |
| IHRN | `/993` | `/993c` | `/993d` |
| SLEEP/APNEA | `/994` | `/994c` | `/994d` |

来源：手机 `wearable/v2/.../messenger/path/*`；手表 `defpackage/nx.java`、`MessageReceiver.java`。本应用业务结果接收仅验收 ECG/BP 路径，IHRN/睡眠呼吸暂停不据此宣称实现。

### 手机品牌、安装状态与激活是不同条件

- 手表 `ra2.invokeSuspend` 通过 `hp0.z` 查询 `content://com.samsung.android.wcs.extension.provider.companion/vendor`；为空、读取失败或不满足其字符串判断时，发出 false，由 `ml` 启动 `ErrorActivity(type=3)`。这是静态观察，不应泛化为“系统没有其他限制”。
- `qx.c/g` 使用 CapabilityClient 查找 `capability_bp/ecg/ihrn/sleep`，更新 `application_installed_in_mobile`。实机日志已观察到这些 capability 找到手机节点。
- 当前兼容路径会发送三星兼容手机特性与 capability DataItem；这不代表手机硬件变成三星，也不代表完成医学功能验证或首次设备配对。
- ECG `onboarding` 只处理手腕方向/引导标志；`terms_and_condition` 是独立动作。此前“onboarding 自己会同时完成条款”的说法不准确。
- 结果同步修复移除了自动写虚构生日、自动将用户档案/服务可用性设为 true 的流程，也不再在每次重连时自动发送条款和手腕配置。显式激活操作须等待对应响应；BP 校准数据不伪造、不重置。

## ECG 无结果问题：根因与修复

### 1. 控制请求不等于握手成功

失败证据：手表实际完成测量后，EcgSyncManager 报告 `cryptography updated to: NOT_READY`、`failed to get connection`；手机不断收到 `/992c request_connection`，旧实现却直接宣称 READY 并重发业务/档案/激活消息，引发请求循环。

修复：控制请求触发 `/plain_connection` 的 `{"action":"connection"}` 握手；CONNECTING 内合并重复请求，只有收到真实明文握手回复后才进入 READY，再发送 ECG/BP common `connection`。收到 `information` 后回应不重置设备的数据，并请求同步。

实机观察：手表 `PlainCryptographyProvider` 回复，`PLAIN connection successful`，`Cryptography state changed: READY`。

### 2. 大结果走 Wear Channel，不是普通 JSON Message

现有普通 Samsung Health Channel 接收器只允许 `/samsung_health/wearable_message`。它不会接收 `/992d`。

修复：通过独立 SHM package/path 白名单接收 `/991d`、`/992d`，保留 Wear Channel fixed64 ID、序列确认和重发去重，重连时清掉半包。SHM 的 Channel 确认使用其独立包名和签名摘要，不再套普通 Samsung Health 的发送者。

每个 Channel 流包含多个应用层任务：

```
[4 字节大端任务长度][zlib 压缩的 JSON]
[4 字节大端任务长度][zlib 压缩的 JSON]
...
```

来源：手表 `rr.c`、`oz1.a`、`hu1.p`；手机 `yk.g.b/d`。注意：普通 SHM 消息的外层 body 使用 gzip/Base64；Channel 内部和 report 使用 zlib/Deflate。不能混用。

### 3. 同步正文与波形格式

Channel 解压后的任务结构：

```json
{
  "message_info": {"action":"SYNC_DATA", "id":13, "type":"", "result":""},
  "device_info": {"is_last_chunk":true},
  "data": [{"datauuid":"synthetic-example", "start_time":1, "sample_rate":500,
            "avg_hr":70, "classification":1, "report":"Base64(zlib(big-endian double[]))"}]
}
```

此示例为形状说明，不是用户测量记录。任务 id 与普通 Message sequence 不应混用。

- `x90.getJsonObject` 的 `report` 是 Base64 包装的 zlib 二进制数组；`convertDoubletoByteArray` 使用 Java ByteBuffer 默认大端 double，不能按逗号文本解析。
- 解码保持所有点的顺序与实际 sample_rate；限制压缩长度、解压长度和采样点数，非有限值拒绝。
- 波形横轴按照记录采样率计算；屏幕格线表示 0.04 s / 0.1 mV 的比例，不把 dp 误称为物理毫米，不用固定点距冒充 25 mm/s。
- 手表 classification 原值可映射展示，但页面注明“手表分类”，本应用不自行作医学诊断。
- BP 同步 data 可能是 `com.samsung.health.bp` / `.configuration` 命名数组。空数组正常处理；`v0.0.21` 对非空配置不确认成功，当前分支已改为原样归档配置，并仅在配置和同批记录都可靠落盘后确认成功。

### 4. 先保存，再业务确认

ECG/BP 记录由 Repository 按设备分区写入，只有同步落盘成功后才发：

- 外层 `message=RESPONSE`、`type=DATA`；
- 内层 `message_info.action=SYNC_DATA`、`type=RESPONSE`、原任务 `id`、`result=SUCCESS`；
- 同步发送者/接收者使用对应 channel 的 `.syncmanager`。

失败不发送 SUCCESS。Channel 字节接收 ACK 和结果业务保存 ACK 是两层确认，不可混淆。

## 实机验收（2026-10-28）

通过用户 MacBook 的 loopback SSH → ADB 隧道 → USB 手机 → 手机热点上的手表调试链路验证：

1. 初次修复接收 `/992d`，观察到约 150 KB（2 条任务），但 gzip 解压报错，未确认业务保存；继续核对并改为 zlib。
2. 后续收到约 225 KB Channel，拆出 3 条真实 ECG 任务，每条 500 Hz、15,000 点，即 30 秒。
3. 手机缓存保存 3 条，手表分别打印 `onSyncCompleted with 13`、`14`、`15`，形成实际结果闭环。
4. 覆盖最终同签名 preview 并强制停止/重启手机应用后，3 条记录仍在。手机详情 UI dump 包含手表分类、心率、`30 秒 · 500 Hz`、连接状态与波形图；历史列表为 3 条。
5. 再次同步返回空队列，手机没有重复新增记录。BP 空队列处理成功，但没有真实血压值，不标为血压测量验收。

完整设备证据在 `private/shm-investigation/ecg-missing-result/`。实际心率/结果值和用户波形不进入公开回归 fixture。

## BP 官方测量/校准流程修复（2026-10-28 后续）

- 根因一：本 App 先前固定发送 `/991` `measuring/do_measure`，Watch SHM 直接启动 `BpMeasureRunActivity`。缺少 calibration feature 时，`yl.e()` 报告 `setMeasurementFeature is fail`，用户因此只看到“请校准”提示，没有进入校准引导。
- 手机 SHM 1.5.2.002 `BloodPressureController` 的官方分支为：校准有效发送 `do_measure`，否则发送 `do_calibration`。Watch SHM 将后者路由到 `BpMainActivity` 的 calibration/expired-calibration 流程。
- 真机首先发现手机 SHM 的 BP 向导在“开始”时弹出“手表已断开连接”。WatchFree 的 RFCOMM/WCS 已连接，但官方 App 还要求 Wear Data Layer 节点。手机上 `com.google.android.wearable.app.cn`、`com.samsung.android.app.watchmanager` 和 `com.samsung.wearable.watch7plugin` 原先均处于 user-disabled。
- 经用户选择官方流程后，已重新启用手机上这些已安装的 Wearable/Watch Manager 组件；WatchFree 的 WearApi NodeClient 随后报告节点 `<watchNode> / Galaxy Watch Ultra (<watchSuffix>)`。重新进入三星官方 BP 校准步骤后，断开提示消失；手机进入 `SHealthMonitorMeasurementActivity`，手表进入 `BpCalibrationActivity`。
- 后续用户完成官方流程并报告本 App 已读到 BP；真机页面确认一条真实 BP 记录（19:50:06）及手表上报“校准有效”。这证明非空 BP 结果已同步；三次袖带输入和最后合并确认未由本会话完整观测，不将页面状态等同于每一步均已验收。
- 2026-10-28 的基线入口读取手表上报的 `tnc`、`calibration_time`、`is_service_available`：只在条款已确认、服务可用、校准未过期时发送 `do_measure`；状态未知/缺失/过期时发送 `do_calibration`。通过当前 WCS 会话直接请求，不要求 Google Wear 节点；不自动同意条款，不写生日、个人资料或校准数据。`do_calibration` 直接进入手表本地校准流程，不打开手机版 SHM。`v0.0.23` 在此基础上补齐 READY 校验、同步后自动回查状态和非空配置归档。
- 官方连接管理器与独立 RFCOMM 实测发生竞争：19:51:43–19:51:51 出现 5 次连接结束，导致 `sessionReady` 反复变化，BP 测量与刷新控件随之变灰/恢复。用户要求停用手机 Wearable / Watch Manager / Watch7 plugin / SHM 后，19:52:01 之后的连续观察约 6 分钟未再断线；五次详情页采样的两个控件均可用，空闲期间没有新增断线或日志中的测量动作。手表 SHM 保留。
- 移除 BP 入口先前引入的 Wear 节点前置条件，避免停用官方组件后阻断已经可用的 WCS 请求。ECG/BP 页面统一为最近测量、历史列表和按 ID 选择详情；每条 ECG 详情绑定自身波形。健康页数值单行自适应，单位/分类单独显示，修复长血压数字撑高卡片。
- 独立传感器采集 App（watch-experiment）、native 算法探针（native-probe）、Lab 实验界面/存储与多语言词条已彻底移除；原生算法分析仅保留为官方校准与数据格式的逆向背景参考，不参与 App 构建，应用不保留任何独立运行链路。
- 最新记录页预览包经 USB ADB 覆盖安装。247 项 JVM 测试、Lint 和 Release 构建通过；真机验证最新与历史 ECG 详情绑定各自时间和 15,000 点波形、BP 单条详情与返回列表、健康页 BP 卡片不再溢出、空闲五次采样两个 BP 控件持续可用。BP 多条历史的保留、去重与重启恢复有单元测试；实机已确认真实非空 BP 记录，不虚构旧记录。三次袖带过程与校准过期行为属当时单会话未直接观测到的边界，官方桥接通路已在实机确认正常。


## Watch 4 / 5 / 6 血压校准兼容性复核

日期：2026-11-02。复核基线：`v0.0.21` / `518ba18`。本节保留基线排查与诊断证据，并在各项后记录当前工作分支的处理状态。

**结论：`do_calibration` 就是正确的手表端直连入口。** 两版 Watch SHM 都在 `dm.a()` 将该动作分派到 `BpMainActivity`，随后由手表自己的 `BpCalibrationActivity`、本地 Room 校准配置和 `shm-bp.so` 完成三轮袖带与个人特征合并；手机版 SHM 不参与校准计算。`v0.0.21` 的入口方向正确，但非空校准配置会阻塞同批 BP，且缺少强制重校准和完整状态刷新。`v0.0.22` 错误地把入口交给手机版 SHM，`v0.0.23` 已恢复直连并保留其余修复；`v0.0.29` 改为手机向导直接编排 `prepare_calibration` 等 measuring 动作，并于 2026-11-04 在 Galaxy Watch 7 Ultra 真机验证通过，但仍不能称为 Watch 4 / 5 / 6 完整兼容或已真机验收。

### 样本和覆盖范围

| 样本 | 文件 SHA-256 | 本次用途 |
| --- | --- | --- |
| Watch SHM `1.2.7.003` | `fb6c95135709414c129d55306fa3cf3f0d4ec762d7355ba4196062989b369584` | 较低版本的入口、状态、校准交互与同步结构 |
| Watch SHM `1.5.1.022` | `a714e9a5950f456b8da4843bd6cdb19948a0c6fd9101b473e24beb3384a2c620` | 与已有实现所依据版本对比 |
| Phone SHM `1.5.2.002` | `af8039dead5b697feb1940d290e830f9eed0b9b51bcc60a25f8e6a1f81cf80a3` | 手机的袖带值提交、最终合并及重校准语义 |

两份 Watch APK 的包名均为 `com.samsung.android.shealthmonitor`，`minSdk=30`，签名证书 SHA-256 均为 `34df0e7a9f1cf1892e45c056b4973cd81ccf148a4050d11aea4ac5a65f900a42`。Phone APK 的 `minSdk=31`；这再次说明把校准交给手机版 SHM 会额外引入 Android 版本和手机环境限制，不能从本应用 `minSdk=26` 推导手机官方校准也能在旧系统使用。

`1.2.7.003` 来自本机已有备份，并不是从 Watch 4 / 5 / 6 各自提取的固件样本。此次没有这三代目标真机，也未取得其所有历史 SHM 版本；签名与最低 API 不证明某个型号的固件、地区资格及运行时路径已验收。

三星[官方 Health Monitor 说明](https://www.samsung.com/uk/apps/samsung-health-monitor/)列明 Watch 4 / 5 / 6 系列可使用 BP，但受适用地区、设备和软件条件限制；校准包含三次袖带参考测量，并要求每 28 天重新校准。这里不把官方产品支持范围等同于本应用的兼容范围。

### 已确认一致的协议部分

- 旧版 `yi` 与新版 `dm` 均注册 `/991`，接受 `.bp.measuring` 接收者，`do_calibration` 打开 `BpMainActivity`；`do_measure` 进入测量流程。未找到必须按 Watch 4 / 5 / 6 切换这些动作或通道的证据。
- 旧版 `iw0` / 新版 `h41` 的信封均使用 `version=0.1`、`sequence_num` 和压缩 `body`。管理器插件的代际身份与这个共用 SHM 业务身份是不同层，已有插件兼容修改不能证明校准闭环兼容。
- 两版均有 `prepare_calibration`、`ready_calibration`、`start_calibration`、`update_calibration`、`initial_calibration`、`re_calibration`、`cancel_calibration`。`update_calibration` 都读取 `ref_systolic`、`ref_diastolic`、`nth`、`datauuid`；最终合并要求三条配置记录，并返回 `calibration_time`。
- 两版都上报 `tnc`、`calibration_time`、`is_service_available`；本地午夜加 28 个日历日的到期计算也一致。新增版本的 ABI / One UI 字段和校准提醒端点不是目前入口的必要参数。
- APK 中 `bp_metadata.json` 的 `feature_version` 从 `1.1.13.002` 变为 `1.1.16.013`。这证明算法特征版本发生变化，不证明必须更换入口命令，也不能把跨算法版本的个人校准数据直接视为可复用。

### 基线缺口与当前处理

1. **P1：校准执行者必须是手表，不是手机版 SHM。** 手表 `dm.a()` 会把 `/991` `do_calibration` 分派到 `BpMainActivity`，后续三轮袖带、最终合并和算法特征均留在手表端；`v0.0.22` 曾暂停直连并转交手机版 SHM，会引入手机端机型/Knox/组件校验和官方软件依赖，已删除。`v0.0.29` 的正式入口是手机向导直接发送 `prepare_calibration`，逐轮推进 `start_calibration` / `update_calibration`，第三轮后发送 `initial_calibration` 由手表合并；不再并发发送 `/remote_intent/rpc`。当前实现增加 READY 前置校验，并在手表上传校准/血压数据并 ACK 后自动查询 `information` 刷新手表校准状态。该闭环已在 Galaxy Watch 7 Ultra 真机验收，仍未在 Watch 4 / 5 / 6 验收。
2. **P1：非空校准配置与同批血压结果。** 基线 `HealthMonitorSession.receiveSync()` 只允许空的 `com.samsung.health.bp.configuration`，非空时退出整批收集并不发成功 ACK。当前实现用 `BpCalibrationConfigStore` 按设备、`datauuid` 和修订时间归档配置原文；配置写入失败时不确认整批，配置和同批 BP 记录都成功后才发送 SUCCESS。诊断时构造的“非空配置 + 非空 BP”阻塞已由回归测试覆盖；仍需用各代真机数据验证真实字段和重传行为。任务队列的移除不是删除手表数据库记录。
3. **P2：强制重校准信号。** 基线 `BpCalibrationStatus.from()` 未处理 `need_to_recal`。当前实现在该字段为 true 时优先返回 `REQUIRED`，即使 `calibration_time` 尚未过期，并有状态回归测试。两份已检查 Watch APK 当前都固定上报 false，因此仍不能宣称已在 Watch 4 / 5 / 6 上收到 true 并走完官方重校准。
4. **P2：状态新鲜度和错误展示。** 基线 BP 页不会跨到期时刻自动重算，断线可能保留旧 information，且握手/解析/保存错误未展示。当前实现在本地到期时刻和页面恢复时重算状态，断线清空 measurement information，BP 卡片展示可操作错误；BP 与 ECG 的 information 失败使用各自提示。设备侧错误文案与真机恢复体验仍需验收。

两个启动动作的官方分发器未直接返回业务成功回执。本应用的 `send=true` 只表示发送队列接受请求，现有文案也只说“已请求”，并未直接宣称校准成功。因此不能仅因没有入口 ACK 就判断手表拒绝，也不应增加一个把“未收到 ACK”直接判为“校准失败”的通用超时。需要区分启动请求、官方流程完成、收到新校准状态与结果持久化。

### 各代判断与真机验收

| 系列 | 官方 BP 功能 | 本应用入口协议 | 三轮校准和结果闭环 |
| --- | --- | --- | --- |
| Watch 4 / Classic | 有，须满足官方适用条件 | `v0.0.23` 直连入口、`v0.0.29` 手机三轮向导；样本静态对比支持，未逐固件验证 | 手表端代码路径已接入；未真机验收 |
| Watch 5 / Pro | 有，须满足官方适用条件 | `v0.0.23` 直连入口、`v0.0.29` 手机三轮向导；样本静态对比支持，未逐固件验证 | 手表端代码路径已接入；未真机验收 |
| Watch 6 / Classic | 有，须满足官方适用条件 | `v0.0.23` 直连入口、`v0.0.29` 手机三轮向导；样本静态对比支持，未逐固件验证 | 手表端代码路径已接入；未真机验收 |

当前实现按“WCS 直连 → 手机向导发送 `/991 measuring/prepare_calibration` → 手表进入准备界面 → `start_calibration` 触发约 30 秒 PPG 采样 → 手机提交袖带读数 `update_calibration` → 三轮后 `initial_calibration` 由手表本地合并 → 手表通过 `/991d` 上传配置和 BP 记录 → 应用落盘并 ACK → 自动查询 `information`”闭环。手机版 SHM、Shizuku、连接暂停、官方组件恢复和远程 Intent 均不在校准路径中。该流程已于 2026-11-04 在 Galaxy Watch 7 Ultra 真机完整走通；剩余工作是 Watch 4 / 5 / 6 真机验收。

每代至少验收未校准、有效期内、已过期、服务不可用、取消/断线重试、算法更新要求重校准，以及“非空配置 + 非空 BP”同批同步。需同时记录型号、Watch OS、手机系统、手机/手表 SHM 版本；验收标准是完成三轮后收到新的 `calibration_time`，记录可靠入库并确认同步，重启后仍可读。

### 验证与证据

基线复核时，Java 17 下定向运行现有协议、BP 状态、通道、机型身份和交接测试：34 项通过。另用忽略目录中的 Gradle init script 注入 3 个诊断用例，复现当时的非空配置阻塞、强制重校准被忽略和重连保留旧服务状态：合计 37 项通过。那些诊断断言的是基线缺口仍然存在，绿色结果不代表当时问题已修复。

当前 `v0.0.23` 在 Java 17 下执行 `:app:spotlessCheck :app:testDebugUnitTest` 为 `BUILD SUCCESSFUL`，JVM 413 项测试、失败/错误/跳过均为 0；`scripts/check-i18n.py` 检查 1,130 项资源、2 种语言且键与格式参数一致；Python 脚本测试 24 项通过。以上是 JVM/脚本验证，不替代 Watch 4 / 5 / 6 真机校准和同步验收。

```sh
JAVA_HOME="$(/usr/libexec/java_home -v 17)" ./gradlew :app:spotlessCheck \
  :app:testDebugUnitTest --console=plain
```

本轮 REA 定向恢复了独立 JADX 全量导出未恢复的两版 `BpMainActivity.init()`；结果完整、无 smali fallback，但保留 switch 重建警告。较低版本的整包导出报告 7 个错误，不称为全 APK 无损反编译。全部 APK 只做静态分析，未运行；没有使用模拟器，也没有进行 Watch 4 / 5 / 6 真机校准。

| 证据 | REA Evidence ID |
| --- | --- |
| Watch `1.2.7.003` 包/组件 | `ev_1f6dcdb827246b0cca92317c0269c5f25c3456b2b273da8d32ab8c3661ef2164` |
| Watch `1.2.7.003` `BpMainActivity` 成员 | `ev_05acdb0b30d49e0a2024ea6876f9b14267ae7055047879f58405cc86fefbe095` |
| Watch `1.2.7.003` `BpMainActivity.init()` | `ev_dcaacf08b02b9f1e9cc5f77ef7be46f5301b19e508a0f9e15a9a4db6ac953c45` |
| Watch `1.5.1.022` `BpMainActivity.init()` | `ev_6ae5d6788493caded5de7f00c9afddb73e2db0e17d31d81d39861c31bb70f2c1` |
| Watch `1.2.7.003` 同步任务 `ak.invokeSuspend()` | `ev_659dc950e687ae075586b0cd8b7bef18ecfe1ffe73ca73aef1d14f5d76cbbfbf` |
| Watch `1.5.1.022` 同步任务 `ln.n()` | `ev_f1ddbc9aa1258d68995fc876beb5e3631f86ee40be08a660c55e51d0ccde6d97` |
| Watch `1.2.7.003` ACK 分发 `qg.m()` | `ev_db6285650244d48bfa48692b66ba7116e72d5c114f1ca4c6d8101f4de123925c` |
| Watch `1.5.1.022` ACK 分发 `db2.invokeSuspend()` | `ev_0889b9a56ba47cc6f968c409ab3be7163a5115044336642c172472b3238bcd0f` |

APK 身份清单、较低版本源码导出、metadata 和诊断代码/日志保存在 `private/shm-bp-compatibility-20261102/`。这类证据和官方 APK 不加入版本控制；官方源码方法定位沿用 `research/decompiled/watch-shealthmonitor/`、`research/decompiled/shealthmonitor/`。

## 血压计算库分析

已进一步恢复 `libshm-bp.so` JNI → `libbp_v3_06_10.so` 的 `estimateBP/PPG_main/PPG_represent/CCD_main/ccd_feat_extract/recal_BP/multi_cal` 调用关系。主要结论：按 100 Hz 输入并插值至 250 Hz 内部网格，提取 16 维形态特征，通过当前/校准特征比值和分段修正公式作用于个人参考收缩压/舒张压；未观察到该路径的神经网络推理，也没有 ECG R 峰或双部位脉搏到达时间作为输入。显示用 FIR 与计算用滤波是不同路径。独立免校准模型与原生自研算法重放已彻底放弃并不再推进；算法逆向分析仅作为理解官方数据格式与校准基线设计的历史研究。详见 [BP-ALGORITHM-ANALYSIS.md](BP-ALGORITHM-ANALYSIS.md)，全部协议发现已同步 SSOT。

## 待完成与边界

- BP 已收到真实非空结果且校准有效；三次袖带过程与 28 天到期切换属单次会话的历史观测边界，官方结果同步已闭环。自研独立血压算法与免校准模型已彻底放弃。
- WSM 加密路径未重建；当前已验收该固件支持的明文握手路径。
- 已验证历史 ECG 点选、对应波形与返回列表；导出、其他固件/版本、长期后台重连仍需持续验证。
- 手机原版 Xposed hook 的失效原因并未因此单独证实；不能把静态发现或禁用官方组件笼统当成唯一根因。
