package dev.ricky.galaxywatchmanagerfree

import java.io.File
import java.util.Locale
import javax.xml.parsers.DocumentBuilderFactory

/** Read the shipped catalog in JVM tests without constructing Android Resources. */
class TestStrings(qualifier: String = "zh-rCN") {
    private val locale = if (qualifier == "zh-rCN") Locale.SIMPLIFIED_CHINESE else Locale.ENGLISH
    private val names = R.string::class.java.fields.associate { it.getInt(null) to it.name }
    private val texts: Map<String, String>

    init {
        val directory = if (qualifier.isEmpty()) "values" else "values-$qualifier"
        val root = File("src/main/res").takeIf { it.isDirectory } ?: File("app/src/main/res")
        val factory =
            DocumentBuilderFactory.newInstance().apply {
                setFeature("http://apache.org/xml/features/disallow-doctype-decl", true)
            }
        val nodes =
            factory
                .newDocumentBuilder()
                .parse(File(root, "$directory/strings.xml"))
                .getElementsByTagName("string")
        texts =
            (0 until nodes.length).associate { index ->
                val node = nodes.item(index)
                node.attributes.getNamedItem("name").nodeValue to
                    node.textContent
                        .removeSurrounding("\"")
                        .replace("\\'", "'")
                        .replace("\\\"", "\"")
                        .replace("\\n", "\n")
                        .replace("\\t", "\t")
            }
    }

    fun get(id: Int, vararg arguments: Any): String {
        val text = requireNotNull(texts[names[id]]) { "Missing test resource $id" }
        return if (arguments.isEmpty()) text else String.format(locale, text, *arguments)
    }
}
