package dev.ricky.galaxywatchmanagerfree.wcs

import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** 握手就绪状态机：转换语义 + 并发下的单次初始化。 */
class SessionReadinessTest {

    @Test
    fun `首次对端 NodeInfo 广播 peers 并初始化业务`() {
        val readiness = SessionReadiness()

        val step = readiness.onPeerNodeInfo(hasPhoneNode = true)

        assertTrue(step.peers)
        assertTrue(step.activate)
        assertTrue(step.notifyReady)
        assertTrue(readiness.ready)
        assertTrue(readiness.peersSent)
    }

    @Test
    fun `重复的 NodeInfo 不再广播也不再初始化`() {
        val readiness = SessionReadiness()
        readiness.onPeerNodeInfo(hasPhoneNode = true)

        val again = readiness.onPeerNodeInfo(hasPhoneNode = true)

        assertTrue(again.isEmpty)
    }

    @Test
    fun `身份未配置时完全不动状态`() {
        val readiness = SessionReadiness()

        val step = readiness.onPeerNodeInfo(hasPhoneNode = false)

        assertTrue(step.isEmpty)
        assertFalse(readiness.ready)
        assertFalse(readiness.peersSent)
    }

    @Test
    fun `SyncStart 抢先就绪后 NodeInfo 只补发 peers`() {
        val readiness = SessionReadiness()
        readiness.onSyncStart()

        val step = readiness.onPeerNodeInfo(hasPhoneNode = true)

        assertTrue(step.peers)
        assertFalse(step.activate)
        assertFalse(step.notifyReady)
    }

    @Test
    fun `就绪后的 SyncStart 与状态回包都被忽略`() {
        val readiness = SessionReadiness()
        readiness.onPeerNodeInfo(hasPhoneNode = true)

        assertTrue(readiness.onSyncStart().isEmpty)
        assertTrue(readiness.onStatusReceived().isEmpty)
    }

    @Test
    fun `状态回包是旧固件的兜底就绪路径`() {
        val readiness = SessionReadiness()

        val step = readiness.onStatusReceived()

        assertFalse(step.activate)
        assertTrue(step.notifyReady)
        assertTrue(readiness.ready)
    }

    @Test
    fun `重连 reset 后可以重新走完整流程`() {
        val readiness = SessionReadiness()
        readiness.onPeerNodeInfo(hasPhoneNode = true)

        readiness.reset()
        assertFalse(readiness.ready)
        assertFalse(readiness.peersSent)

        val step = readiness.onPeerNodeInfo(hasPhoneNode = true)
        assertTrue(step.activate)
        assertTrue(step.notifyReady)
    }

    @Test
    fun `并发回帧只允许一次业务初始化`() {
        val readiness = SessionReadiness()
        val pool = Executors.newFixedThreadPool(8)
        val start = CountDownLatch(1)
        val activations = AtomicInteger(0)
        val notifications = AtomicInteger(0)
        val peersBursts = AtomicInteger(0)
        try {
            repeat(64) { index ->
                pool.execute {
                    start.await()
                    val step =
                        when (index % 3) {
                            0 -> readiness.onPeerNodeInfo(hasPhoneNode = true)
                            1 -> readiness.onSyncStart()
                            else -> readiness.onStatusReceived()
                        }
                    if (step.peers) peersBursts.incrementAndGet()
                    if (step.activate) activations.incrementAndGet()
                    if (step.notifyReady) notifications.incrementAndGet()
                }
            }
            start.countDown()
            pool.shutdown()
            assertTrue(pool.awaitTermination(5, TimeUnit.SECONDS))
        } finally {
            pool.shutdownNow()
        }

        // A status reply may win the race: it is the documented legacy fallback that marks the
        // session ready without running business initialization. The invariant is "never twice".
        assertTrue("业务初始化最多发生一次", activations.get() <= 1)
        assertEquals("onSessionReady 只能回调一次", 1, notifications.get())
        assertTrue("peers 广播最多发生一次", peersBursts.get() <= 1)
    }
}
