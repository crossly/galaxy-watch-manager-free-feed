package dev.ricky.galaxywatchmanagerfree.ui.components

import org.junit.Assert.assertEquals
import org.junit.Test

class DockGeometryTest {
    private val geometry = DockGeometry(pitch = 80f, count = 4)

    @Test
    fun continuousDragPassesAllFourDestinations() {
        listOf(40f, 120f, 200f, 280f).forEachIndexed { index, x ->
            assertEquals(index.toFloat(), geometry.positionAt(x), 0.001f)
            assertEquals(index, geometry.indexAt(geometry.positionAt(x)))
        }
        assertEquals(1.25f, geometry.positionAt(140f), 0.001f)
    }

    @Test
    fun draggingPastEitherEdgeClampsToEndDestination() {
        assertEquals(0f, geometry.positionAt(-500f), 0f)
        assertEquals(3f, geometry.positionAt(900f), 0f)
    }

    @Test
    fun flickProjectsAtMostOneDestinationPastFinger() {
        assertEquals(2, geometry.releaseIndex(1.2f, 8000f, 1, true))
        assertEquals(0, geometry.releaseIndex(1.2f, -8000f, 1, true))
        assertEquals(1, geometry.releaseIndex(1.2f, 0f, 1, true))
        assertEquals(3, geometry.releaseIndex(3f, 8000f, 3, true))
    }

    @Test
    fun tapDoesNotFling() {
        assertEquals(1, geometry.releaseIndex(1f, 8000f, 1, false))
    }

    @Test
    fun rtlMirrorsBothDragAndFling() {
        val rtl = geometry.copy(rtl = true)
        assertEquals(3f, rtl.positionAt(40f), 0f)
        assertEquals(0f, rtl.positionAt(280f), 0f)
        assertEquals(0, rtl.releaseIndex(1f, 8000f, 1, true))
        assertEquals(2, rtl.releaseIndex(1f, -8000f, 1, true))
    }
}
