package dev.ricky.galaxywatchmanagerfree.feature

import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class HealthTimelineTest {

    private val zone: ZoneId = ZoneId.of("Asia/Shanghai")
    private val day: LocalDate = LocalDate.of(2026, 10, 27)

    private fun millisOf(day: LocalDate, hour: Int, minute: Int = 0): Long =
        ZonedDateTime.of(day.year, day.monthValue, day.dayOfMonth, hour, minute, 0, 0, zone)
            .toInstant()
            .toEpochMilli()

    // ---------- 小时分布 ----------

    @Test
    fun `binning buckets map ten minute slots into hours`() {
        val bins =
            JSONArray()
                .put(JSONObject().put("index", 0).put("steps", 12))
                .put(JSONObject().put("index", 5).put("steps", 30)) // 00:50
                .put(JSONObject().put("index", 6).put("steps", 7)) // 01:00
                .put(JSONObject().put("index", 78).put("steps", 250)) // 13:00
                .put(JSONObject().put("index", 143).put("steps", 4)) // 23:50
                .put(JSONObject().put("index", 200).put("steps", 999)) // 越界忽略
        val hours = HealthTimeline.hoursFromBinning(bins, zone)
        assertEquals(HealthTimeline.HOURS, hours.size)
        assertEquals(42, hours[0])
        assertEquals(7, hours[1])
        assertEquals(250, hours[13])
        assertEquals(4, hours[23])
        assertEquals(0, hours[2])
    }

    @Test
    fun `run and walk buckets are summed when steps is absent`() {
        val bins =
            JSONArray()
                .put(JSONObject().put("index", 12).put("run_steps", 40).put("walk_steps", 60))
        assertEquals(100, HealthTimeline.hoursFromBinning(bins, zone)[2])
    }

    @Test
    fun `array style buckets are supported`() {
        val bins = JSONArray().put(JSONArray().put(18).put(15))
        assertEquals(15, HealthTimeline.hoursFromBinning(bins, zone)[3])
    }

    @Test
    fun `interval records fall back to their start hour`() {
        val now = millisOf(day, 23, 55)
        val records =
            listOf(
                JSONObject().put("start_time", millisOf(day, 9, 10)).put("count", 120),
                JSONObject().put("start_time", millisOf(day, 9, 40)).put("count", 80),
                JSONObject().put("start_time", millisOf(day, 18, 5)).put("count", 300),
            )
        val hours = HealthTimeline.hoursFromIntervals(records, zone, now)
        assertEquals(200, hours[9])
        assertEquals(300, hours[18])
    }

    @Test
    fun `merge keeps the taller bar`() {
        val merged =
            HealthTimeline.mergeHours(
                listOf(1, 2, 3) + List(21) { 0 },
                listOf(5, 1, 0) + List(21) { 0 },
            )
        assertEquals(listOf(5, 2, 3), merged.take(3))
    }

    @Test
    fun `resolve prefers the larger of bins and interval data for the same hour`() {
        val now = millisOf(day, 23, 55)
        val bins = JSONArray().put(JSONObject().put("index", 0).put("steps", 10))
        val intervals = listOf(JSONObject().put("start_time", millisOf(day, 0, 20)).put("count", 5))
        val hours =
            HealthTimeline.resolveTodayHours(
                HealthTimeline.emptyHours(),
                bins,
                intervals,
                zone,
                now,
            )
        // 分桶与区间明细描述的是同一批步数，取较大值而不是相加，否则会重复计数。
        assertEquals(10, hours[0])
    }

    // ---------- 历史与连续达标 ----------

    private fun history(vararg days: Pair<String, Int>): MutableMap<String, HealthTimeline.Day> {
        val map = mutableMapOf<String, HealthTimeline.Day>()
        days.forEach { (day, steps) -> map[day] = HealthTimeline.Day(steps, steps / 30, steps) }
        return map
    }

    @Test
    fun `streak counts back from today when the goal is already met`() {
        val today = LocalDate.of(2026, 10, 27)
        val map =
            history(
                "2026-10-27" to 7000,
                "2026-10-26" to 6500,
                "2026-10-25" to 6000,
                "2026-10-24" to 5999,
            )
        assertEquals(3, HealthTimeline.streak(map, 6000, today, 7000))
    }

    @Test
    fun `unfinished today does not break yesterday's streak`() {
        val today = LocalDate.of(2026, 10, 27)
        val map = history("2026-10-26" to 6500, "2026-10-25" to 6000)
        assertEquals(2, HealthTimeline.streak(map, 6000, today, 1200))
    }

    @Test
    fun `missing history day breaks the chain`() {
        val today = LocalDate.of(2026, 10, 27)
        val map = history("2026-10-27" to 7000, "2026-10-25" to 7000)
        assertEquals(1, HealthTimeline.streak(map, 6000, today, 7000))
    }

    @Test
    fun `upsert keeps the larger value so late packets cannot lower a day`() {
        val map = mutableMapOf<String, HealthTimeline.Day>()
        HealthTimeline.upsertDay(map, "2026-10-27", 5000, 120, 3900)
        HealthTimeline.upsertDay(map, "2026-10-27", 4200, 90, 3100)
        assertEquals(5000, map["2026-10-27"]!!.steps)
        assertEquals(120, map["2026-10-27"]!!.calories)
    }

    @Test
    fun `history is trimmed to the newest days`() {
        val map = mutableMapOf<String, HealthTimeline.Day>()
        (1..10).forEach { day ->
            HealthTimeline.upsertDay(
                map,
                "2026-10-${day.toString().padStart(2, '0')}",
                day * 100,
                0,
                0,
            )
        }
        HealthTimeline.trimHistory(map, keep = 3)
        assertEquals(setOf("2026-10-10", "2026-10-09", "2026-10-08"), map.keys)
    }

    // ---------- 里程碑 ----------

    @Test
    fun `milestones follow Samsung 10K 20K 30K 40K thresholds`() {
        val milestones = HealthTimeline.milestones(23_000)
        assertEquals(listOf(10_000, 20_000, 30_000, 40_000), milestones.map { it.steps })
        assertEquals(listOf(true, true, false, false), milestones.map { it.achieved })
        assertEquals(30_000, HealthTimeline.nextMilestone(23_000))
        assertNull(HealthTimeline.nextMilestone(45_000))
    }

    @Test
    fun `streak badges follow weekly thresholds`() {
        assertEquals(7, HealthTimeline.nextStreakBadge(3))
        assertEquals(14, HealthTimeline.nextStreakBadge(7))
        assertNull(HealthTimeline.nextStreakBadge(28))
    }

    // ---------- 最近 7 天 ----------

    @Test
    fun `last week returns seven ascending days using live steps for today`() {
        val today = LocalDate.of(2026, 10, 27)
        val map = history("2026-10-26" to 4000, "2026-10-20" to 9000)
        val week = HealthTimeline.lastWeek(map, today, todaySteps = 1234)
        assertEquals(7, week.size)
        assertEquals(LocalDate.of(2026, 10, 21), week.first().first)
        assertEquals(today, week.last().first)
        assertEquals(1234, week.last().second)
        assertEquals(4000, week[5].second)
    }

    // ---------- 持久化 ----------

    @Test
    fun `history and hours survive a round trip`() {
        val map = history("2026-10-27" to 7000, "2026-10-26" to 6500)
        val decoded = HealthTimeline.decodeHistory(HealthTimeline.encodeHistory(map))
        assertEquals(map, decoded)

        val hours = List(HealthTimeline.HOURS) { it * 10 }
        assertEquals(hours, HealthTimeline.decodeHours(HealthTimeline.encodeHours(hours)))
        assertTrue(HealthTimeline.decodeHours("broken").all { it == 0 })
        assertTrue(HealthTimeline.decodeHours(null).size == HealthTimeline.HOURS)
    }
}
