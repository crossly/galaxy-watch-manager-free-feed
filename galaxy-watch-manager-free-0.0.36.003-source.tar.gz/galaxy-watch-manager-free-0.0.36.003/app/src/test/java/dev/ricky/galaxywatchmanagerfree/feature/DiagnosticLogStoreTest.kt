package dev.ricky.galaxywatchmanagerfree.feature

import java.io.ByteArrayOutputStream
import java.io.File
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class DiagnosticLogStoreTest {
    @get:Rule val temporary = TemporaryFolder()

    @Test
    fun `rotation bounds storage and exports previous before current`() {
        val dir = temporary.newFolder()
        val store = DiagnosticLogStore(dir, maxBytes = 12)
        store.append("first")
        store.append("second")
        store.append("third")
        val output = ByteArrayOutputStream()
        store.export(output, "header")
        assertEquals("header\n\nsecond\nthird\n", output.toString("UTF-8"))
        assertTrue(dir.listFiles()!!.all { it.length() <= 12 })
        assertEquals(2, dir.listFiles()!!.size)
    }

    @Test
    fun `export preserves full UTF8 entries and does not mutate logs`() {
        val store = DiagnosticLogStore(temporary.newFolder())
        store.append("[INFO] 已连接手表")
        store.append("[DEBUG] seq=17\nframe queued")
        val first = ByteArrayOutputStream()
        val second = ByteArrayOutputStream()
        store.export(first, "app=0.0.31")
        store.export(second, "app=0.0.31")
        assertEquals(first.toString("UTF-8"), second.toString("UTF-8"))
        assertTrue(first.toString("UTF-8").contains("已连接手表"))
        assertTrue(first.toString("UTF-8").contains("frame queued"))
    }

    @Test
    fun `clearing removes both generations but logging can resume`() {
        val dir = temporary.newFolder()
        val store = DiagnosticLogStore(dir, maxBytes = 12)
        store.append("first")
        store.append("second")
        store.clear()
        assertEquals(0, dir.listFiles()!!.size)
        store.append("new")
        val output = ByteArrayOutputStream()
        store.export(output, "header")
        assertEquals("header\n\nnew\n", output.toString("UTF-8"))
    }

    @Test(expected = IllegalStateException::class)
    fun `write failures propagate instead of reporting persistence success`() {
        val path = temporary.newFile()
        DiagnosticLogStore(File(path, "logs")).append("cannot write")
    }
}
