package dev.ricky.galaxywatchmanagerfree.feature.monitor

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import org.junit.Assert.*
import org.junit.Test

class MonitorDayTest {
    @Test
    fun `today grouping uses local dates and respects midnight across time zones`() {
        val time = Instant.parse("2026-10-28T23:30:00Z").toEpochMilli()
        assertTrue(
            MonitorDay.contains(time, LocalDate.parse("2026-10-29"), ZoneId.of("Asia/Shanghai"))
        )
        assertTrue(
            MonitorDay.contains(time, LocalDate.parse("2026-10-28"), ZoneId.of("America/New_York"))
        )
        assertFalse(
            MonitorDay.contains(time, LocalDate.parse("2026-10-28"), ZoneId.of("Asia/Shanghai"))
        )
        assertFalse(MonitorDay.contains(0, LocalDate.parse("1970-01-01"), ZoneId.of("UTC")))
    }
}
