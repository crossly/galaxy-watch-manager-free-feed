package dev.ricky.galaxywatchmanagerfree.feature

import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class HealthMetricLogTest {

    private val zone: ZoneId = ZoneId.of("Asia/Shanghai")
    private val day = LocalDate.of(2026, 10, 27)

    private fun millisOf(hour: Int, minute: Int = 0, dayOffset: Int = 0): Long =
        LocalDateTime.of(day.plusDays(dayOffset.toLong()), java.time.LocalTime.of(hour, minute))
            .atZone(zone)
            .toInstant()
            .toEpochMilli()

    @Test
    fun `daily view excludes yesterday and never uses its values for todays statistics`() {
        val samples =
            listOf(
                HealthMetricLog.Sample(millisOf(12, dayOffset = -1), 80f),
                HealthMetricLog.Sample(millisOf(12), 98f),
            )
        val daily = HealthMetricLog.daily(samples, day, zone)
        assertEquals(listOf(HealthMetricLog.Sample(millisOf(12), 98f)), daily.samples)
        assertEquals(98f, daily.stats!!.avg, 0.001f)
        assertNull(HealthMetricLog.daily(samples, day.plusDays(1), zone).stats)
    }

    @Test
    fun `undated floors stay unassigned instead of becoming todays activity`() {
        val records = listOf(JSONObject().put("datauuid", "undated").put("floor_count", 5))
        assertEquals(0, FloorsLog.accumulate(0, linkedSetOf(), records, millisOf(20), zone))
    }

    @Test
    fun `floor total keeps missing counts unknown and explicit zero measured`() {
        val missing = listOf(JSONObject().put("datauuid", "missing").put("start_time", millisOf(9)))
        assertNull(FloorsLog.todayTotal(missing, millisOf(20), zone))

        val zero =
            listOf(
                JSONObject()
                    .put("datauuid", "zero")
                    .put("start_time", millisOf(9))
                    .put("floor_count", 0)
            )
        assertEquals(0, FloorsLog.todayTotal(zero, millisOf(20), zone))
    }

    @Test
    fun `spo2 samples parse and out-of-range values are dropped`() {
        val samples =
            HealthMetricLog.samples(
                HealthMetric.SPO2,
                listOf(
                    JSONObject().put("start_time", millisOf(2)).put("spo2", 97),
                    JSONObject().put("start_time", millisOf(3)).put("spo2", 30), // 低于 50
                    JSONObject().put("start_time", 0L).put("spo2", 95), // 无时间
                    JSONObject().put("start_time", millisOf(4)).put("spo2", 101), // 高于 100
                ),
            )
        assertEquals(1, samples.size)
        assertEquals(97f, samples.single().value, 0.001f)
    }

    @Test
    fun `skin temperature and respiratory use their own ranges`() {
        val temp =
            HealthMetricLog.samples(
                HealthMetric.SKIN_TEMP,
                listOf(JSONObject().put("start_time", millisOf(2)).put("temperature", 34.6)),
            )
        assertEquals(34.6f, temp.single().value, 0.001f)

        val breath =
            HealthMetricLog.samples(
                HealthMetric.RESPIRATORY,
                listOf(JSONObject().put("start_time", millisOf(2)).put("breath_rate", 14.4)),
            )
        assertEquals(14.4f, breath.single().value, 0.001f)
    }

    @Test
    fun `hrv prefers rmssd and falls back to sdnn`() {
        val rmssd =
            HealthMetricLog.samples(
                HealthMetric.HRV,
                listOf(
                    JSONObject().put("start_time", millisOf(6)).put("rmssd", 42.5).put("sdnn", 60.0)
                ),
            )
        assertEquals(42.5f, rmssd.single().value, 0.001f)

        val sdnn =
            HealthMetricLog.samples(
                HealthMetric.HRV,
                listOf(JSONObject().put("start_time", millisOf(6)).put("sdnn", 55.0)),
            )
        assertEquals(55.0f, sdnn.single().value, 0.001f)
    }

    @Test
    fun `merge keeps seven days sorted and deduplicated`() {
        val now = millisOf(20)
        val existing =
            listOf(
                HealthMetricLog.Sample(millisOf(9), 96f),
                HealthMetricLog.Sample(millisOf(9, 0, -9), 95f), // 超期
            )
        val incoming =
            listOf(
                HealthMetricLog.Sample(millisOf(9), 96f),
                HealthMetricLog.Sample(millisOf(14), 97f),
            )
        val merged = HealthMetricLog.merge(existing, incoming, now)
        assertEquals(listOf(96f, 97f), merged.map { it.value })
    }

    @Test
    fun `stats and latest report min average max`() {
        val samples =
            listOf(
                HealthMetricLog.Sample(millisOf(9), 96f),
                HealthMetricLog.Sample(millisOf(10), 99f),
                HealthMetricLog.Sample(millisOf(11), 93f),
            )
        val stats = HealthMetricLog.stats(samples)!!
        assertEquals(93f, stats.min, 0.001f)
        assertEquals(99f, stats.max, 0.001f)
        assertEquals(96f, stats.avg, 0.001f)
        assertEquals(3, stats.count)
        assertEquals(millisOf(11), HealthMetricLog.latest(samples)!!.ts)
        assertNull(HealthMetricLog.stats(emptyList()))
    }

    @Test
    fun `weekly trend aligns by day and leaves gaps empty`() {
        val samples =
            listOf(
                HealthMetricLog.Sample(millisOf(2), 96f),
                HealthMetricLog.Sample(millisOf(2, 0, -2), 94f),
                HealthMetricLog.Sample(millisOf(2, 0, -2), 96f),
            )
        val week = HealthMetricLog.weekly(samples, day, zone)
        assertEquals(7, week.size)
        assertEquals(96f, week[6]!!, 0.001f)
        assertEquals(95f, week[4]!!, 0.001f)
        assertNull(week[5])
    }

    @Test
    fun `samples survive a round trip`() {
        val samples =
            listOf(
                HealthMetricLog.Sample(millisOf(2), 96.5f),
                HealthMetricLog.Sample(millisOf(3), 34.25f),
            )
        val decoded = HealthMetricLog.decode(HealthMetricLog.encode(samples))
        assertEquals(2, decoded.size)
        assertEquals(96.5f, decoded[0].value, 0.0001f)
        assertEquals(34.25f, decoded[1].value, 0.0001f)
        assertTrue(HealthMetricLog.decode("broken").isEmpty())
    }

    @Test
    fun `records are looked up by module aliases`() {
        val record = JSONObject().put("start_time", millisOf(2)).put("spo2", 98)
        val chunks = mapOf("com.samsung.shealth.tracker.oxygen_saturation" to listOf(record))
        assertEquals(1, HealthMetricLog.recordsFor(HealthMetric.SPO2, chunks).size)
        assertEquals(0, HealthMetricLog.recordsFor(HealthMetric.HRV, chunks).size)
    }

    // ---------- 楼层 ----------

    @Test
    fun `floors accumulate unique records of today only`() {
        val seen = linkedSetOf<String>()
        val records =
            listOf(
                JSONObject()
                    .put("datauuid", "a")
                    .put("start_time", millisOf(9))
                    .put("floor_count", 3),
                JSONObject()
                    .put("datauuid", "a")
                    .put("start_time", millisOf(9))
                    .put("floor_count", 3),
                JSONObject()
                    .put("datauuid", "b")
                    .put("start_time", millisOf(10))
                    .put("floor_count", 5),
                JSONObject()
                    .put("datauuid", "c")
                    .put("start_time", millisOf(10, 0, -1))
                    .put("floor_count", 9),
            )
        val total = FloorsLog.accumulate(0, seen, records, millisOf(20), zone)
        assertEquals(8, total)
        // 重发同一批不会重复累加
        assertEquals(8, FloorsLog.accumulate(total, seen, records, millisOf(21), zone))
    }

    @Test
    fun `floors keep zero measured and ignore negative counts`() {
        val seen = linkedSetOf<String>()
        val records =
            listOf(
                JSONObject()
                    .put("datauuid", "z")
                    .put("start_time", millisOf(9))
                    .put("floor_count", 0),
                JSONObject()
                    .put("datauuid", "n")
                    .put("start_time", millisOf(9))
                    .put("floor_count", -2),
                JSONObject()
                    .put("datauuid", "negative-fraction")
                    .put("start_time", millisOf(9))
                    .put("floor_count", -0.5),
            )
        assertEquals(0, FloorsLog.accumulate(0, seen, records, millisOf(20), zone))
        assertTrue(seen.contains("z"))
        assertTrue(!seen.contains("n"))
        assertTrue(!seen.contains("negative-fraction"))
    }
}
