package dev.ricky.galaxywatchmanagerfree.wcs

import org.junit.Assert.*
import org.junit.Test

class CompanionProfileTest {
    @Test
    fun `official family names include classic pro FE and Ultra variants`() {
        val examples =
            mapOf(
                "Galaxy Watch4 (ABCD)" to CompanionProfile.WATCH4,
                "Galaxy Watch 4 Classic" to CompanionProfile.WATCH4,
                "Galaxy Watch FE" to CompanionProfile.WATCH4,
                "Galaxy Watch5 Pro" to CompanionProfile.WATCH5,
                "galaxy watch 5 golf edition" to CompanionProfile.WATCH5,
                "Galaxy Watch6 Classic (1234)" to CompanionProfile.WATCH6,
                "Watch 6" to CompanionProfile.WATCH6,
                "Galaxy Watch7" to CompanionProfile.WATCH7,
                "Galaxy Watch Ultra (ABCD)" to CompanionProfile.WATCH7,
            )
        examples.forEach { (name, expected) ->
            assertEquals(name, expected, CompanionProfile.fromDeviceName(name))
        }
    }

    @Test
    fun `model aliases distinguish older watches from Samsung earbuds`() {
        val examples =
            mapOf(
                "SM-R860" to CompanionProfile.WATCH4,
                "SM-R895F" to CompanionProfile.WATCH4,
                "SM-R861" to CompanionProfile.WATCH4,
                "SM-R900" to CompanionProfile.WATCH5,
                "SM-R925F" to CompanionProfile.WATCH5,
                "SM-R930" to CompanionProfile.WATCH6,
                "sm-r9650" to CompanionProfile.WATCH6,
                "SM-L300" to CompanionProfile.WATCH7,
                "SM-L7050" to CompanionProfile.WATCH7,
            )
        examples.forEach { (name, expected) ->
            assertEquals(name, expected, CompanionProfile.fromDeviceName(name))
        }
        listOf(
                null,
                "",
                "SM-R177",
                "SM-R190",
                "SM-R500",
                "Galaxy Watch8",
                "Watch 40",
                "Watch Ultra2",
            )
            .forEach { assertNull(it, CompanionProfile.fromDeviceName(it)) }
    }

    @Test
    fun `live peer overrides saved identity and unrelated installed plugins`() {
        assertEquals(
            CompanionProfile.WATCH5,
            CompanionProfile.resolve(
                "SM-R920",
                CompanionProfile.WATCH7.packageName,
                listOf(CompanionProfile.WATCH4.packageName, CompanionProfile.WATCH6.packageName),
            ),
        )
    }

    @Test
    fun `renamed peer reuses verified identity before considering installed plugins`() {
        assertEquals(
            CompanionProfile.WATCH4,
            CompanionProfile.resolve(
                "My wrist",
                CompanionProfile.WATCH4.packageName,
                listOf(CompanionProfile.WATCH7.packageName),
            ),
        )
        assertEquals(
            CompanionProfile.WATCH6,
            CompanionProfile.resolve(null, null, listOf(CompanionProfile.WATCH6.packageName)),
        )
        assertEquals(
            CompanionProfile.WATCH7,
            CompanionProfile.resolve(
                "My wrist",
                null,
                listOf(CompanionProfile.WATCH4.packageName, CompanionProfile.WATCH6.packageName),
            ),
        )
        assertNull(CompanionProfile.fromPackage("com.samsung.android.waterplugin.impostor"))
    }

    @Test
    fun `family identity survives JSON and settings DataItem encoding`() {
        val examples =
            listOf(
                Triple("SM-R860", "com.samsung.android.waterplugin", "2.2.11.26071051"),
                Triple("SM-R900", "com.samsung.android.heartplugin", "2.2.12.26071051"),
                Triple("SM-R930", "com.samsung.wearable.watch6plugin", "2.2.13.26071051"),
                Triple("SM-L7050", "com.samsung.wearable.watch7plugin", "2.2.15.26071051"),
            )
        for ((model, expectedPackage, expectedVersion) in examples) {
            val profile = CompanionProfile.resolve(model, null, emptyList())
            assertEquals(expectedVersion, profile.versionName)
            val jsonFrame =
                WcsFrame.jsonFrame(
                    WcsPaths.INTERNAL_FEATURE,
                    """{"msgId":"feature_exchange","msgType":2}""",
                    profile.packageName,
                    WcsPaths.SIGNATURE_PLUGIN,
                    destNode = "abcdef12",
                    sourceNode = "12345678",
                    code = 17,
                    generation = 42,
                )
            val message =
                WcsFrame.decode(jsonFrame.copyOfRange(4, jsonFrame.size))
                    as WcsFrame.Incoming.Wearable
            assertEquals(model, expectedPackage, message.senderPkg)
            assertEquals(WcsPaths.SIGNATURE_PLUGIN, message.senderNode)
            assertEquals("12345678", message.sourceNode)
            val itemFrame =
                WcsFrame.wearPathFrame(
                    "wear://12345678/w_module_sec_watch_setting/display/aod",
                    listOf(DataMapEncoder.encode(mapOf("enabled" to true))),
                    profile.packageName,
                    nodeId = "12345678",
                )
            val item =
                WcsFrame.decode(itemFrame.copyOfRange(4, itemFrame.size))
                    as WcsFrame.Incoming.WearPath
            assertEquals(model, expectedPackage, item.senderPkg)
            assertEquals(WcsPaths.SIGNATURE_PLUGIN, item.senderNode)
        }
    }
}
