package dev.ricky.galaxywatchmanagerfree.feature

import dev.ricky.galaxywatchmanagerfree.feature.VascularLoadLog.Band
import dev.ricky.galaxywatchmanagerfree.feature.VascularLoadLog.Type
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class VascularLoadLogTest {

    private val zone = ZoneId.of("Asia/Shanghai")
    private val offsetMillis = 8L * 3_600_000

    private fun at(date: String, time: String): Long =
        LocalDate.parse(date).atTime(LocalTime.parse(time)).atZone(zone).toInstant().toEpochMilli()

    private fun record(
        type: Type,
        endMillis: Long,
        measurement: Float? = null,
        offset: Long = offsetMillis,
        id: String = "record-${type.name}-$endMillis",
    ): JSONObject =
        JSONObject()
            .put("datauuid", id)
            .put("type", type.code)
            .put("start_time", endMillis)
            .put("end_time", endMillis)
            .put("time_offset", offset)
            .put("measurement", measurement?.toDouble() ?: JSONObject.NULL)

    private fun entry(type: Type, endMillis: Long, offset: Long = offsetMillis) =
        VascularLoadLog.Entry("entry", endMillis, endMillis, type, null, offset)

    @Test
    fun `bands match the official inclusive thresholds`() {
        assertEquals(Band.HIGHER, VascularLoadLog.bandOf(-12.5f))
        assertEquals(Band.OUT_OF_RANGE_UNKNOWN, VascularLoadLog.bandOf(-12.51f))
        assertEquals(Band.HIGHER, VascularLoadLog.bandOf(-10f))
        assertEquals(Band.HIGHER, VascularLoadLog.bandOf(-7.51f))
        assertEquals(Band.SLIGHTLY_HIGHER, VascularLoadLog.bandOf(-7.5f))
        assertEquals(Band.SLIGHTLY_HIGHER, VascularLoadLog.bandOf(-2.51f))
        assertEquals(Band.STEADY, VascularLoadLog.bandOf(-2.5f))
        assertEquals(Band.STEADY, VascularLoadLog.bandOf(0f))
        assertEquals(Band.STEADY, VascularLoadLog.bandOf(2.5f))
        assertEquals(Band.SLIGHTLY_LOWER, VascularLoadLog.bandOf(2.51f))
        assertEquals(Band.SLIGHTLY_LOWER, VascularLoadLog.bandOf(7.5f))
        assertEquals(Band.LOWER, VascularLoadLog.bandOf(7.51f))
        assertEquals(Band.LOWER, VascularLoadLog.bandOf(12.5f))
        assertEquals(Band.OUT_OF_RANGE_UNKNOWN, VascularLoadLog.bandOf(12.51f))
        assertEquals(Band.NOT_ENOUGH_DATA, VascularLoadLog.bandOf(null))
        assertEquals(Band.OUT_OF_RANGE_UNKNOWN, VascularLoadLog.bandOf(Float.NaN))
        assertEquals(Band.OUT_OF_RANGE_UNKNOWN, VascularLoadLog.bandOf(Float.POSITIVE_INFINITY))
        assertEquals(Band.OUT_OF_RANGE_UNKNOWN, VascularLoadLog.bandOf(Float.NEGATIVE_INFINITY))
    }

    @Test
    fun `baseline map values are never graded as relative load`() {
        val baseline = VascularLoadLog.Entry("b", 0, 0, Type.BASELINE, 93.333336f)
        assertEquals(Band.NOT_ENOUGH_DATA, baseline.band)
        assertEquals(2.5f, baseline.chartValue!!, 0.0001f)
        assertEquals(Band.OUT_OF_RANGE_UNKNOWN, VascularLoadLog.bandOf(93.333336f))

        val result = VascularLoadLog.Entry("m", 0, 0, Type.MEASUREMENT, -5f)
        assertEquals(Band.SLIGHTLY_HIGHER, result.band)
        assertEquals(3.5f, result.chartValue!!, 0.0001f)
        val steady = VascularLoadLog.Entry("z", 0, 0, Type.MEASUREMENT, 0f)
        assertEquals(2.5f, steady.chartValue!!, 0.0001f)
        assertNull(VascularLoadLog.Entry("o", 0, 0, Type.MEASUREMENT, 13f).chartValue)
    }

    @Test
    fun `tracking day shifts at 20 30 in the record offset and never for resets`() {
        val cutoff = at("2026-07-01", "20:30")
        val before = entry(Type.MEASUREMENT, at("2026-07-01", "20:29"))

        assertEquals(LocalDate.of(2026, 7, 1), before.trackingDate)

        val shifted = entry(Type.MEASUREMENT, cutoff)
        assertEquals(LocalDate.of(2026, 7, 2), shifted.trackingDate)
        assertEquals(LocalDate.of(2026, 7, 2), entry(Type.BASELINE, cutoff).trackingDate)

        val reset = entry(Type.RESET, cutoff)
        assertEquals(LocalDate.of(2026, 7, 1), reset.trackingDate)
    }

    @Test
    fun `tracking day uses the recorded offset instead of the phone zone`() {
        val instant = Instant.parse("2026-07-01T12:30:00Z").toEpochMilli()
        assertEquals(
            LocalDate.of(2026, 7, 2),
            entry(Type.MEASUREMENT, instant, offsetMillis).trackingDate,
        )
        assertEquals(LocalDate.of(2026, 7, 1), entry(Type.MEASUREMENT, instant, 0L).trackingDate)
    }

    @Test
    fun `reset invalidates measurements collected before it`() {
        val now = at("2026-07-10", "12:00")
        val records =
            listOf(
                record(Type.BASELINE, at("2026-07-01", "06:00"), 93f),
                record(Type.MEASUREMENT, at("2026-07-02", "06:00"), -5f),
                record(Type.RESET, at("2026-07-03", "06:00")),
            )

        val snapshot = VascularLoadLog.project(records, now, zone)
        assertFalse(snapshot.baselineComplete)
        assertNull(snapshot.baseline)
        assertNull(snapshot.latest)
        assertEquals(0, snapshot.baselineNights)
    }

    @Test
    fun `a valued baseline after reset restores results`() {
        val now = at("2026-07-10", "12:00")
        val records =
            listOf(
                record(Type.BASELINE, at("2026-07-01", "06:00"), 93f),
                record(Type.MEASUREMENT, at("2026-07-02", "06:00"), -5f),
                record(Type.RESET, at("2026-07-03", "06:00")),
                record(Type.BASELINE, at("2026-07-04", "06:00"), 93.2f),
                record(Type.MEASUREMENT, at("2026-07-05", "06:00"), -3f),
            )

        val snapshot = VascularLoadLog.project(records, now, zone)
        assertTrue(snapshot.baselineComplete)
        assertEquals(-3f, snapshot.latest?.measurement!!, 0.0001f)
    }

    @Test
    fun `completed baseline remains valid until a reset`() {
        val records =
            listOf(
                record(Type.BASELINE, at("2026-06-01", "06:00"), 93f),
                record(Type.MEASUREMENT, at("2026-07-19", "06:00"), -4f),
            )

        val snapshot = VascularLoadLog.project(records, at("2026-07-20", "13:30"), zone)
        assertTrue(snapshot.baselineComplete)
        assertEquals(93f, snapshot.baseline?.measurement!!, 0.0001f)
        assertEquals(-4f, snapshot.latest?.measurement!!, 0.0001f)
    }

    @Test
    fun `baseline completion is never inferred from three null measurement nights`() {
        val now = at("2026-07-19", "13:29")
        val records =
            listOf(
                record(Type.BASELINE, at("2026-07-17", "06:00")),
                record(Type.BASELINE, at("2026-07-18", "06:00")),
                record(Type.BASELINE, at("2026-07-19", "06:00")),
                record(Type.MEASUREMENT, at("2026-07-19", "07:00"), -4f),
            )

        val snapshot = VascularLoadLog.project(records, now, zone)
        assertFalse(snapshot.baselineComplete)
        assertNull(snapshot.baseline)
        assertNull(snapshot.latest)
        // Three unvalued rows do not establish calibration.
        assertEquals(2, snapshot.baselineNights)
    }

    @Test
    fun `baseline freshness moves its reference day at 13 30`() {
        val beforeCutoff = at("2026-07-20", "13:29")
        val atCutoff = at("2026-07-20", "13:30")

        fun nights(date: String, now: Long) =
            VascularLoadLog.project(listOf(record(Type.BASELINE, at(date, "06:00"))), now, zone)
                .baselineNights

        assertEquals(1, nights("2026-07-08", beforeCutoff))
        assertEquals(0, nights("2026-07-07", beforeCutoff))
        assertEquals(1, nights("2026-07-09", atCutoff))
        assertEquals(0, nights("2026-07-08", atCutoff))
    }

    @Test
    fun `two baselines need a twelve day span and thirteen day freshness`() {
        val records =
            listOf(
                record(Type.BASELINE, at("2026-07-08", "06:00")),
                record(Type.BASELINE, at("2026-07-20", "06:00")),
            )

        assertEquals(
            2,
            VascularLoadLog.project(records, at("2026-07-20", "13:29"), zone).baselineNights,
        )
        assertEquals(
            1,
            VascularLoadLog.project(records, at("2026-07-22", "13:29"), zone).baselineNights,
        )

        val spread =
            listOf(
                record(Type.BASELINE, at("2026-07-07", "06:00")),
                record(Type.BASELINE, at("2026-07-20", "06:00")),
            )
        assertEquals(
            1,
            VascularLoadLog.project(spread, at("2026-07-20", "13:29"), zone).baselineNights,
        )
    }

    @Test
    fun `parse accepts plain and module prefixed official fields`() {
        val end = at("2026-07-01", "06:00")
        val plain =
            JSONObject()
                .put("datauuid", "plain")
                .put("type", 3)
                .put("start_time", end)
                .put("end_time", end)
                .put("time_offset", offsetMillis)
                .put("measurement", -4.5)
        val aliased =
            JSONObject()
                .put("datauuid", "aliased")
                .put("${VascularLoadLog.MODULE}.type", 2)
                .put("${VascularLoadLog.MODULE}.start_time", end)
                .put("${VascularLoadLog.MODULE}.end_time", end)
                .put("${VascularLoadLog.MODULE}.time_offset", offsetMillis)
                .put("${VascularLoadLog.MODULE}.measurement", 93.0)

        val parsed = VascularLoadLog.parse(plain)!!
        assertEquals(Type.MEASUREMENT, parsed.type)
        assertEquals(-4.5f, parsed.measurement!!, 0.0001f)
        assertEquals(Type.BASELINE, VascularLoadLog.parse(aliased)!!.type)
    }

    @Test
    fun `parse rejects unusable rows and treats null measurement as missing`() {
        val end = at("2026-07-01", "06:00")

        assertNull(
            VascularLoadLog.parse(
                JSONObject().put("datauuid", "no-type").put("start_time", end).put("end_time", end)
            )
        )
        assertNull(
            VascularLoadLog.parse(
                JSONObject()
                    .put("datauuid", "bad-type")
                    .put("type", 9)
                    .put("start_time", end)
                    .put("end_time", end)
            )
        )
        assertNull(
            VascularLoadLog.parse(
                JSONObject()
                    .put("datauuid", "zero-start")
                    .put("type", 3)
                    .put("start_time", 0)
                    .put("end_time", end)
            )
        )
        assertNull(
            VascularLoadLog.parse(
                JSONObject()
                    .put("datauuid", "bad-range")
                    .put("type", 3)
                    .put("start_time", end + 1)
                    .put("end_time", end)
            )
        )
        assertNull(
            VascularLoadLog.parse(
                JSONObject()
                    .put("datauuid", "bad-offset")
                    .put("type", 3)
                    .put("start_time", end)
                    .put("end_time", end)
                    .put("time_offset", 100_000_000L)
            )
        )

        val nullValue =
            VascularLoadLog.parse(
                JSONObject()
                    .put("datauuid", "null-value")
                    .put("type", 3)
                    .put("start_time", end)
                    .put("end_time", end)
                    .put("measurement", JSONObject.NULL)
            )!!
        assertNull(nullValue.measurement)
    }

    @Test
    fun `health record store accepts vascular rows and keeps baselines older than thirty days`() {
        val now = 1_800_000_000_000L
        val old = now - 40L * 24 * 3_600_000
        val store = HealthRecordStore()

        store.merge(
            mapOf(VascularLoadLog.MODULE to listOf(record(Type.BASELINE, old, 93f, id = "old"))),
            now,
        )
        assertEquals(1, store.records(VascularLoadLog.MODULE).size)

        store.merge(
            mapOf(
                "com.samsung.shealth.unknown" to
                    listOf(JSONObject().put("datauuid", "unknown").put("end_time", now))
            ),
            now,
        )
        assertFalse(store.hasModule("com.samsung.shealth.unknown"))
    }

    @Test
    fun `health record store keeps the newest vascular revision across persistence`() {
        val now = 1_800_000_000_000L
        val end = now - 3_600_000

        fun row(value: Float, update: Long) =
            record(Type.BASELINE, end, value, id = "same").put("update_time", update)

        val store = HealthRecordStore()
        store.merge(mapOf(VascularLoadLog.MODULE to listOf(row(93f, 100))), now)
        store.merge(mapOf(VascularLoadLog.MODULE to listOf(row(94f, 200))), now)
        store.merge(mapOf(VascularLoadLog.MODULE to listOf(row(92f, 150))), now)
        assertEquals(
            94.0,
            store.records(VascularLoadLog.MODULE).single().getDouble("measurement"),
            0.0001,
        )

        val restored = HealthRecordStore()
        assertTrue(restored.restore(store.encode(), now))
        assertEquals(
            94.0,
            restored.records(VascularLoadLog.MODULE).single().getDouble("measurement"),
            0.0001,
        )
    }
}
