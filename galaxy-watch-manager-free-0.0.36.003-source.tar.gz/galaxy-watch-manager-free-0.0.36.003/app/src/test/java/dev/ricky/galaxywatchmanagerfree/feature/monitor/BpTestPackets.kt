package dev.ricky.galaxywatchmanagerfree.feature.monitor

import org.json.JSONArray
import org.json.JSONObject

internal object BpTestPackets {
    const val TIME = 1_793_000_000_000L

    fun information(
        time: Long = TIME,
        message: String = "REQUEST",
        result: String = "",
        forced: Boolean = false,
    ): ByteArray =
        HealthMonitorProtocol.envelope(
                message,
                "com.samsung.wearable.app.health.samd.bp.common",
                "com.samsung.mobile.app.health.samd.bp.common",
                100,
                "MESSAGE",
                JSONObject()
                    .put("action", "information")
                    .put("result", result)
                    .put(
                        "data",
                        JSONObject()
                            .put("tnc", true)
                            .put("is_service_available", true)
                            .put("need_to_recal", forced)
                            .put("calibration_time", time),
                    ),
            )
            .toString()
            .toByteArray()

    fun configuration(id: String = "calibration"): JSONObject =
        JSONObject()
            .put("datauuid", id)
            .put("deviceuuid", "watch")
            .put("start_time", TIME)
            .put("update_time", TIME)
            .put("ref_systolic", 118)
            .put("ref_diastolic", 76)
            .put("hr", 65)
            .put("feature", "[1.0,2.0]")

    fun record(): JSONObject =
        JSONObject()
            .put("datauuid", "measurement")
            .put("start_time", TIME)
            .put("systolic", 118)
            .put("diastolic", 76)

    fun sync(rows: JSONArray = JSONArray(), last: Boolean = true): JSONObject =
        JSONObject()
            .put("message_info", JSONObject().put("action", "SYNC_DATA").put("id", 23))
            .put("device_info", JSONObject().put("is_last_chunk", last))
            .put("data", rows)

    fun calibrationResponse(
        action: String,
        result: String = "success",
        data: JSONObject = JSONObject(),
    ): ByteArray =
        HealthMonitorProtocol.envelope(
                message = "RESPONSE",
                sender = "com.samsung.wearable.app.health.samd.bp.measuring",
                receiver = "com.samsung.mobile.app.health.samd.bp.measuring",
                sequence = 200,
                type = "RESPONSE",
                body =
                    JSONObject()
                        .put("type", "response")
                        .put("action", action)
                        .put("result", result)
                        .put("data", data),
            )
            .toString()
            .toByteArray()
}
