package dev.ricky.galaxywatchmanagerfree.ui.screens.connection

import org.junit.Assert.assertEquals
import org.junit.Test

class ConnectionOwnershipTest {
    @Test
    fun noSelectedDeviceHasNoOwnership() {
        assertEquals(
            ConnectionOwnership.NONE,
            resolveConnectionOwnership(
                hasDevice = false,
                handoverPreparing = false,
                releasedToOfficialApps = false,
            ),
        )
    }

    @Test
    fun preparedHandoverTakesPriorityOverReleasedState() {
        assertEquals(
            ConnectionOwnership.HANDOVER,
            resolveConnectionOwnership(
                hasDevice = true,
                handoverPreparing = true,
                releasedToOfficialApps = true,
            ),
        )
    }

    @Test
    fun releasedDeviceReportsOfficialOwnership() {
        assertEquals(
            ConnectionOwnership.OFFICIAL_APPS,
            resolveConnectionOwnership(
                hasDevice = true,
                handoverPreparing = false,
                releasedToOfficialApps = true,
            ),
        )
    }

    @Test
    fun otherwiseTheAppOwnsDirectConnection() {
        assertEquals(
            ConnectionOwnership.DIRECT,
            resolveConnectionOwnership(
                hasDevice = true,
                handoverPreparing = false,
                releasedToOfficialApps = false,
            ),
        )
    }
}
