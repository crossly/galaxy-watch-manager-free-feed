package dev.ricky.galaxywatchmanagerfree.feature

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class WatchFacePreviewResolverTest {
    @Test
    fun `preview resource name follows the protocol preset id`() {
        assertEquals("wf_ultraanalog", WatchFacePreviewResolver.resourceName("ultraanalog"))
        assertEquals("wf_simpledigital", WatchFacePreviewResolver.resourceName("simpledigital"))
    }

    @Test
    fun `present local resource keeps the vendor preview`() {
        val selection = WatchFacePreviewResolver.select("ultraanalog") { it == "wf_ultraanalog" }

        assertEquals("wf_ultraanalog", selection.drawableName)
        assertFalse(selection.isIllustration)
    }

    @Test
    fun `missing local resource falls back to the illustration`() {
        val selection = WatchFacePreviewResolver.select("ultraanalog") { false }

        assertNull(selection.drawableName)
        assertTrue(selection.isIllustration)
    }

    @Test
    fun `every preset resolves a unique resource name`() {
        val names = WatchFacePresets.ALL.map { WatchFacePreviewResolver.resourceName(it.id) }

        assertEquals(WatchFacePresets.ALL.size, names.toSet().size)
        assertTrue(names.all { it.startsWith("wf_") })
    }
}
