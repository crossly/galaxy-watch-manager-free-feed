package dev.ricky.galaxywatchmanagerfree.feature.monitor

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class BpCalibrationConfigStoreTest {
    @Test
    fun `retransmissions deduplicate and older revisions cannot replace newer configurations`() {
        var saved: String? = null
        val store =
            BpCalibrationConfigStore(
                { saved },
                {
                    saved = it
                    true
                },
            )
        val row =
            BpTestPackets.configuration().put("future_field", JSONObject().put("algorithm", 2))
        assertTrue(store.persist(listOf(row, row)))
        val newer =
            JSONObject(row.toString()).put("update_time", BpTestPackets.TIME + 1).put("hr", 70)
        assertTrue(store.persist(listOf(newer)))
        assertTrue(store.persist(listOf(row)))
        val rows = JSONArray(saved)
        assertEquals(1, rows.length())
        assertEquals(70, rows.getJSONObject(0).getInt("hr"))
        assertEquals(2, rows.getJSONObject(0).getJSONObject("future_field").getInt("algorithm"))
        assertEquals("[1.0,2.0]", rows.getJSONObject(0).getString("feature"))
    }

    @Test
    fun `device identity separates equal ids and nullable algorithm fields remain unchanged`() {
        var saved: String? = null
        val store =
            BpCalibrationConfigStore(
                { saved },
                {
                    saved = it
                    true
                },
            )
        val first = BpTestPackets.configuration().put("feature", JSONObject.NULL)
        val second = BpTestPackets.configuration().put("deviceuuid", "other-watch")
        assertTrue(store.persist(listOf(first, second)))
        assertEquals(2, JSONArray(saved).length())
        assertTrue(JSONArray(saved).getJSONObject(0).isNull("feature"))
    }

    @Test
    fun `failed disk commit must be retried even when preferences changed in memory`() {
        var memory: String? = null
        var writes = 0
        val store =
            BpCalibrationConfigStore(
                { memory },
                {
                    memory = it
                    ++writes > 1
                },
            )
        assertFalse(store.persist(listOf(BpTestPackets.configuration())))
        assertTrue(store.persist(listOf(BpTestPackets.configuration())))
        assertEquals(2, writes)
        assertEquals(1, JSONArray(memory).length())
    }

    @Test
    fun `invalid incoming or corrupt saved data cannot erase the archive`() {
        var writes = 0
        val invalidStore =
            BpCalibrationConfigStore(
                { null },
                {
                    writes++
                    true
                },
            )
        assertFalse(invalidStore.persist(listOf(BpTestPackets.configuration(""))))
        val corruptStore =
            BpCalibrationConfigStore(
                { "corrupt" },
                {
                    writes++
                    true
                },
            )
        assertFalse(corruptStore.persist(listOf(BpTestPackets.configuration())))
        assertEquals(0, writes)
    }
}
