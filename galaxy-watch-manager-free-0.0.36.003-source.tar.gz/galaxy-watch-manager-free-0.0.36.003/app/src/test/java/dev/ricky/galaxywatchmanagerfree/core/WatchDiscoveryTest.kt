package dev.ricky.galaxywatchmanagerfree.core

import dev.ricky.galaxywatchmanagerfree.core.WatchDiscovery.Candidate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class WatchDiscoveryTest {

    private val watchUltra = Candidate("Galaxy Watch Ultra (ABCD)", "watch-ultra")
    private val buds = Candidate("FreeBuds Pro 4", "buds")
    private val car = Candidate("BYD Seal", "car-kit")
    private val oldGear = Candidate("Gear S3", "gear-s3")

    @Test
    fun `prefers the watch over earbuds and car kits`() {
        val picked = WatchDiscovery.pick(listOf(buds, car, watchUltra), savedMac = null)
        assertEquals("watch-ultra", picked?.address)
    }

    @Test
    fun `saved device wins even when a higher scoring watch is present`() {
        val otherWatch = Candidate("Galaxy Watch 6", "watch-6")
        val picked = WatchDiscovery.pick(listOf(watchUltra, otherWatch), "saved-but-unpaired")
        assertEquals("watch-6", picked?.address)
    }

    @Test
    fun `stale saved mac falls back to name matching`() {
        val picked = WatchDiscovery.pick(listOf(buds, watchUltra), "stale-saved")
        assertEquals("watch-ultra", picked?.address)
    }

    @Test
    fun `bluetooth hands-free alias still matches the watch`() {
        // 系统可能显示为 "Galaxy Watch Ultra (ABCD)" 或型号别名
        val picked = WatchDiscovery.pick(listOf(buds, Candidate("SM-L7050", "sm-l7050")), null)
        assertEquals("sm-l7050", picked?.address)
    }

    @Test
    fun `older model aliases are discoverable without treating SM-R earbuds as watches`() {
        for (model in listOf("SM-R860", "SM-R900", "SM-R925F", "SM-R930", "SM-R9650")) {
            val picked =
                WatchDiscovery.pick(
                    listOf(Candidate("SM-R177", "buds"), Candidate(model, "watch")),
                    null,
                )
            assertEquals(model, "watch", picked?.address)
        }
        assertEquals(0, WatchDiscovery.score("SM-R190"))
        assertEquals(0, WatchDiscovery.score("SM-R500"))
    }

    @Test
    fun `gear device is only used when nothing better exists`() {
        assertEquals(40, WatchDiscovery.score("Gear S3"))
        assertEquals(100, WatchDiscovery.score("Galaxy Watch Ultra"))
        assertEquals(0, WatchDiscovery.score("FreeBuds Pro 4"))
        assertEquals(0, WatchDiscovery.score(null))
        val picked = WatchDiscovery.pick(listOf(buds, oldGear), null)
        assertEquals("gear-s3", picked?.address)
    }

    @Test
    fun `returns null when no bonded device looks like a watch`() {
        assertNull(WatchDiscovery.pick(listOf(buds, car), savedMac = null))
        assertNull(WatchDiscovery.pick(emptyList(), savedMac = "watch-ultra"))
    }

    @Test
    fun `equal scores resolve deterministically by address`() {
        val a = Candidate("Galaxy Watch A", "watch-a")
        val b = Candidate("Galaxy Watch B", "watch-b")
        assertEquals("watch-a", WatchDiscovery.pick(listOf(a, b), null)?.address)
        assertEquals("watch-a", WatchDiscovery.pick(listOf(b, a), null)?.address)
    }
}
