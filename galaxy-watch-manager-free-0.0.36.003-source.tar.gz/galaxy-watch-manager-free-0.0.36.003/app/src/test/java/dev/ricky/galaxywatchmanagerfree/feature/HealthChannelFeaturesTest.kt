package dev.ricky.galaxywatchmanagerfree.feature

import java.time.ZoneId
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class HealthChannelFeaturesTest {
    private val zone = ZoneId.of("Asia/Shanghai")

    private fun chunks(): Map<String, List<JSONObject>> {
        val root = JSONObject(javaClass.getResource("/health/channel-features.json")!!.readText())
        return root.keys().asSequence().associateWith { key ->
            val array = root.getJSONArray(key)
            (0 until array.length()).map(array::getJSONObject)
        }
    }

    @Test fun `actual Channel respiratory record uses average and minute bins`() {
        val records = chunks().getValue("com.samsung.health.respiratory_rate")
        assertTrue(HealthMetricLog.samples(HealthMetric.RESPIRATORY, records).isNotEmpty())
    }

    @Test fun `actual Channel HRV record has samples only inside compressed bins`() {
        val records = chunks().getValue("com.samsung.health.hrv")
        assertTrue(HealthMetricLog.samples(HealthMetric.HRV, records).size > 1)
    }

    @Test fun `actual Channel sleep stages join via sleep_id`() {
        val chunks = chunks()
        val sessions = SleepParser.sessions(chunks.getValue(SleepParser.MODULE_SLEEP), emptyList(),
            chunks.getValue(SleepParser.MODULE_SLEEP_STAGE_LEGACY))
        assertTrue(sessions.any { it.segments.isNotEmpty() })
    }

    @Test fun `actual Channel floors use floor rather than floor_count`() {
        val records = chunks().getValue("com.samsung.health.floors_climbed")
        val now = records.last().getLong("end_time")
        assertEquals(3, FloorsLog.accumulate(0, linkedSetOf(), records, now, zone))
    }
}
