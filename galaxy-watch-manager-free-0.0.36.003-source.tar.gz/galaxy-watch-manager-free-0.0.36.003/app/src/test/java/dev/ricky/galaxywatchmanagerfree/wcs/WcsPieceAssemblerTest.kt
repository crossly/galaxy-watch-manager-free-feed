package dev.ricky.galaxywatchmanagerfree.wcs

import org.junit.Assert.*
import org.junit.Test

class WcsPieceAssemblerTest {
    private val inner =
        Proto.bytes(
            16,
            Proto.string(6, "/samsung_health/wearable_message/123") +
                Proto.bytes(9, ByteArray(40_000) { (it % 251).toByte() }),
        )

    private fun piece(
        index: Int,
        count: Int = 4,
        digest: String = WcsFrame.messageDigest(inner),
    ): ByteArray {
        val start = (index - 1) * 12_288
        val data = inner.copyOfRange(start, minOf(inner.size, start + 12_288))
        return Proto.bytes(1, data) +
            Proto.string(2, digest) +
            Proto.integer(3, index.toLong()) +
            Proto.integer(4, count.toLong()) +
            Proto.integer(5, 9)
    }

    @Test
    fun `reassembles captured-size fragments before decoding channel protobuf`() {
        val assembler = WcsPieceAssembler()
        assertNull(assembler.accept(piece(1)))
        assertNull(assembler.accept(piece(2)))
        assertNull(assembler.accept(piece(3)))
        val env = Proto.parse(assembler.accept(piece(4))!!)
        assertArrayEquals(inner, env.raw(1))
        assertEquals(9L, env.num(5))
    }

    @Test
    fun `retransmitted and interleaved pieces do not append bytes twice`() {
        val assembler = WcsPieceAssembler()
        assertNull(assembler.accept(piece(2)))
        assertNull(assembler.accept(piece(1)))
        assertNull(assembler.accept(piece(1)))
        assertNull(assembler.accept(piece(3)))
        assertArrayEquals(inner, Proto.parse(assembler.accept(piece(4))!!).raw(1))
    }

    @Test
    fun `corrupt digest is never delivered`() {
        val assembler = WcsPieceAssembler()
        (1..4).forEach { assertNull(assembler.accept(piece(it, digest = "wrong"))) }
    }

    @Test
    fun `expired partial stream does not combine with a new tail`() {
        var now = 0L
        val assembler = WcsPieceAssembler { now }
        assembler.accept(piece(1))
        now = 30_001L
        (2..4).forEach { assertNull(assembler.accept(piece(it))) }
    }

    @Test
    fun `reconnect discards fragments from the previous socket`() {
        val assembler = WcsPieceAssembler()
        assertNull(assembler.accept(piece(1)))
        assembler.reset()
        (2..4).forEach { assertNull(assembler.accept(piece(it))) }
        assertArrayEquals(inner, Proto.parse(assembler.accept(piece(1))!!).raw(1))
    }

    @Test
    fun `single-piece envelope remains unchanged`() {
        val body = Proto.bytes(1, inner) + Proto.integer(3, 1) + Proto.integer(4, 1)
        assertArrayEquals(body, WcsPieceAssembler().accept(body))
    }

    @Test
    fun `malformed piece count is rejected before buffering`() {
        val envelope =
            Proto.bytes(1, byteArrayOf(1)) +
                Proto.string(2, "x") +
                Proto.integer(3, 1) +
                Proto.integer(4, Long.MAX_VALUE)
        assertNull(WcsPieceAssembler().accept(envelope))
    }
}
