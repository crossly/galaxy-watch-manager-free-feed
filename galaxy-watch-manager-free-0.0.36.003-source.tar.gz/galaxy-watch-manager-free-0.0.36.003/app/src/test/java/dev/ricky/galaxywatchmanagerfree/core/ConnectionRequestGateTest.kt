package dev.ricky.galaxywatchmanagerfree.core

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ConnectionRequestGateTest {
    @Test
    fun stopInvalidatesPendingDiscoveryAndDelayedServiceStart() {
        val gate = ConnectionRequestGate()
        val pending = gate.begin("AA:01")
        gate.invalidate()
        assertFalse(gate.isCurrent(pending))
        assertFalse(gate.matches(pending.generation, pending.mac))
    }

    @Test
    fun switchRejectsOldDeviceCallbacksAndServiceDestruction() {
        val gate = ConnectionRequestGate()
        val first = gate.begin("AA:01")
        val second = gate.begin("BB:02")
        assertFalse(gate.isCurrent(first))
        assertTrue(gate.isCurrent(second))
        assertFalse(gate.matches(first.generation, first.mac))
        assertTrue(gate.matches(second.generation, "bb:02"))
    }

    @Test
    fun retrySameDeviceDoesNotReviveTimedOutAttempt() {
        val gate = ConnectionRequestGate()
        val first = gate.begin("AA:01")
        gate.invalidate()
        val retry = gate.begin("AA:01")
        assertFalse(gate.isCurrent(first))
        assertTrue(gate.isCurrent(retry))
        assertFalse(gate.matches(first.generation, retry.mac))
    }
}
