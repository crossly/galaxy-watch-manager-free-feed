package dev.ricky.galaxywatchmanagerfree.core

import java.io.ByteArrayInputStream
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ApkIntegrityTest {

    @Test
    fun `sha256 computes expected hash for known bytes`() {
        // "abc" 的标准 sha-256
        val digest = ApkIntegrity.sha256("abc".toByteArray())
        assertEquals("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad", digest)
    }

    @Test
    fun `streaming sha256 matches in-memory result`() {
        val payload = "Galaxy Watch Manager Free Update Payload".toByteArray()
        val mem = ApkIntegrity.sha256(payload)
        val stream = ApkIntegrity.sha256(ByteArrayInputStream(payload))
        assertEquals(mem, stream)
    }

    @Test
    fun `matches normalizes case and prefix`() {
        val hash = "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
        assertTrue(ApkIntegrity.matches(hash, hash.uppercase()))
        assertTrue(ApkIntegrity.matches("sha256:$hash", hash))
        assertTrue(ApkIntegrity.matches("SHA256:" + hash.uppercase(), hash))
        assertFalse(ApkIntegrity.matches(hash, "0" * 64))
        assertFalse(ApkIntegrity.matches(null, hash))
        assertFalse(ApkIntegrity.matches(hash, null))
        assertFalse(ApkIntegrity.matches("short", "short"))
    }

    @Test
    fun `fileNameFrom extracts apk name safely`() {
        assertEquals(
            "galaxy-watch-manager-free-0.0.6.apk",
            ApkIntegrity.fileNameFrom(
                "https://raw.github.com/crossly/feed/apk/galaxy-watch-manager-free-0.0.6.apk?token=xyz"
            ),
        )
        assertEquals(
            "fallback.apk",
            ApkIntegrity.fileNameFrom("https://example.com/download", "fallback.apk"),
        )
        assertEquals(
            "fallback.apk",
            ApkIntegrity.fileNameFrom("https://example.com/not-an-apk.zip", "fallback.apk"),
        )
    }

    @Test
    fun `sizeText produces readable strings`() {
        assertEquals("", ApkIntegrity.sizeText(0))
        assertEquals("512 B", ApkIntegrity.sizeText(512))
        assertEquals("1.5 KB", ApkIntegrity.sizeText(1536))
        assertEquals("13.51 MB", ApkIntegrity.sizeText(14_165_555))
    }

    private operator fun String.times(n: Int): String = repeat(n)
}
