package dev.ricky.galaxywatchmanagerfree.feature.monitor

import java.io.ByteArrayOutputStream
import java.util.Base64
import java.util.zip.GZIPOutputStream
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test

class EcgLogTest {
    private val texts = dev.ricky.galaxywatchmanagerfree.TestStrings()

    private fun classificationLabel(type: Int) = texts.get(EcgRecord.classificationLabelRes(type))

    private fun compress(str: String): String {
        val bos = ByteArrayOutputStream()
        GZIPOutputStream(bos).use { it.write(str.toByteArray(Charsets.UTF_8)) }
        return Base64.getEncoder().encodeToString(bos.toByteArray())
    }

    @Test
    fun `watch report decodes big endian deflate doubles without dropping sample positions`() {
        val binary =
            java.nio.ByteBuffer.allocate(24)
                .putDouble(0.125)
                .putDouble(-0.25)
                .putDouble(0.5)
                .array()
        val output = ByteArrayOutputStream()
        java.util.zip.DeflaterOutputStream(output).use { it.write(binary) }
        val record =
            JSONObject()
                .put("datauuid", "binary-report")
                .put("start_time", 1_793_000_000_000L)
                .put("avg_hr", 75)
                .put("classification", 1)
                .put("sample_rate", 250)
                .put("report", Base64.getEncoder().encodeToString(output.toByteArray()))
        val parsed = EcgRecord.parse(record)!!
        assertEquals(250.0, parsed.sampleRate, 0.0)
        org.junit.Assert.assertArrayEquals(floatArrayOf(0.125f, -0.25f, 0.5f), parsed.waveform, 0f)
    }

    @Test
    fun `parse ecg record with raw waveform data`() {
        val waveformJson = "[0.01, 0.05, 0.25, 1.20, -0.40, 0.15]"
        val record =
            JSONObject()
                .put("datauuid", "ecg-uuid-1")
                .put("start_time", 1793000000000L)
                .put("avg_hr", 72)
                .put("classification", 1)
                .put("sample_rate", 500.0)
                .put("value", compress(waveformJson))

        val parsed = EcgRecord.parse(record)
        assertNotNull(parsed)
        assertEquals("ecg-uuid-1", parsed!!.id)
        assertEquals(72, parsed.heartRate)
        assertEquals(1, parsed.classification)
        assertEquals("窦性心律", texts.get(parsed.classificationRes))
        assertEquals(500.0, parsed.sampleRate, 0.001)
        assertEquals(6, parsed.waveform.size)
        assertEquals(1.20f, parsed.waveform[3], 0.001f)
    }

    @Test
    fun `waveform parsing handles plain comma separated string`() {
        val points = EcgRecord.decodeWaveform("0.1, 0.2, -0.3, 0.4")
        assertEquals(4, points.size)
        assertEquals(-0.3f, points[2], 0.001f)
    }

    @Test
    fun `classification labels map expected clinical types`() {
        assertEquals("窦性心律", classificationLabel(1))
        assertEquals("心房颤动 (房颤)", classificationLabel(2))
        assertEquals("信号欠佳", classificationLabel(0))
        assertEquals("无法确定", classificationLabel(3))
        assertEquals("无法确定", classificationLabel(5))
        assertEquals("窦性心律 (心率过速)", classificationLabel(11))
    }

    @Test
    fun `ecg log encodes and decodes round trip`() {
        val record =
            EcgRecord(
                id = "ecg-1",
                startTime = 1793000000000L,
                heartRate = 68,
                classification = 1,
                sampleRate = 500.0,
                waveform = floatArrayOf(0.1f, 0.2f, 0.3f),
            )
        val encoded = EcgLog.encode(listOf(record))
        val decoded = EcgLog.decode(encoded)
        assertEquals(1, decoded.size)
        assertEquals(record, decoded[0])
    }

    @Test
    fun `ecg log decodes legacy uncompressed json array waveform`() {
        val legacy =
            """[{"id":"legacy-1","start_time":1793000000000,"avg_hr":72,"classification":1,"sample_rate":500.0,"waveform":[0.1,0.2,-0.15]}]"""
        val decoded = EcgLog.decode(legacy)
        assertEquals(1, decoded.size)
        assertEquals("legacy-1", decoded[0].id)
        org.junit.Assert.assertArrayEquals(
            floatArrayOf(0.1f, 0.2f, -0.15f),
            decoded[0].waveform,
            0.001f,
        )
    }
}
