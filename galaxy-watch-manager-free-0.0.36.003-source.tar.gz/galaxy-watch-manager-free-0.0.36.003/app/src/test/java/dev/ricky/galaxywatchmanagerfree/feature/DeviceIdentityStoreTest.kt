package dev.ricky.galaxywatchmanagerfree.feature

import org.junit.Assert.*
import org.junit.Test

class DeviceIdentityStoreTest {

    @Test
    fun `normalization preserves full identity so invalid lengths are rejected`() {
        assertEquals("c0ffee1", DeviceIdentityStore.normalizeNode(" C0FFEE1 "))
        val longNode = DeviceIdentityStore.normalizeNode("ABCDEF12345678")
        assertEquals("abcdef12345678", longNode)
        assertFalse(DeviceIdentityStore.isValidNode(longNode))
        assertEquals("", DeviceIdentityStore.normalizeNode(""))
    }

    @Test
    fun `isValidNode validates 7 or 8 hex characters`() {
        assertTrue(DeviceIdentityStore.isValidNode("c0ffee1"))
        assertTrue(DeviceIdentityStore.isValidNode("12345678"))
        assertTrue(DeviceIdentityStore.isValidNode("abcdef12"))

        assertFalse(DeviceIdentityStore.isValidNode("123456")) // 6 chars
        assertFalse(DeviceIdentityStore.isValidNode("123456789")) // 9 chars
        assertFalse(DeviceIdentityStore.isValidNode("xyz1234")) // non-hex
        assertFalse(DeviceIdentityStore.isValidNode(""))
    }
}
