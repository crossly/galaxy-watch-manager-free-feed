package dev.ricky.galaxywatchmanagerfree.core

import org.junit.Assert.assertEquals
import org.junit.Test

class DownloadMirrorTest {
    private val feedUrl =
        "https://raw.githubusercontent.com/crossly/galaxy-watch-manager-free-feed/main/version.json"
    private val apkUrl =
        "https://raw.githubusercontent.com/crossly/galaxy-watch-manager-free-feed/" +
            "5ceb09904c73aa519b4b5e401db3383fb86e0746/galaxy-watch-manager-free-0.0.34.005.apk"
    private val releaseUrl =
        "https://github.com/crossly/galaxy-watch-manager-free/releases/download/" +
            "v0.0.34.005/galaxy-watch-manager-free-0.0.34.005.apk"

    @Test
    fun `off leaves urls unchanged`() {
        assertEquals(feedUrl, DownloadMirror.rewrite(feedUrl, DownloadMirror.OFF))
        assertEquals(apkUrl, DownloadMirror.rewrite(apkUrl, DownloadMirror.OFF))
    }

    @Test
    fun `mirrors prefix raw and release urls`() {
        listOf(DownloadMirror.GH_PROXY, DownloadMirror.GH_PROXY_NET, DownloadMirror.GH_FAST)
            .forEach { mirror ->
                assertEquals(mirror.baseUrl + feedUrl, DownloadMirror.rewrite(feedUrl, mirror))
                assertEquals(mirror.baseUrl + apkUrl, DownloadMirror.rewrite(apkUrl, mirror))
                assertEquals(
                    mirror.baseUrl + releaseUrl,
                    DownloadMirror.rewrite(releaseUrl, mirror),
                )
            }
    }

    @Test
    fun `non github and malformed urls are not proxied`() {
        listOf(
                "http://127.0.0.1:8080/version.json",
                "https://example.com/app.apk",
                "https://github.com.example.com/app.apk",
                "https://github.com@other.example/app.apk",
                "ftp://github.com/app.apk",
                "not a url",
                "",
            )
            .forEach { url ->
                assertEquals(url, DownloadMirror.rewrite(url, DownloadMirror.GH_PROXY))
            }
    }

    @Test
    fun `already proxied urls are not rewritten again`() {
        val proxied = DownloadMirror.GH_PROXY.baseUrl + apkUrl
        assertEquals(proxied, DownloadMirror.rewrite(proxied, DownloadMirror.GH_FAST))
    }

    @Test
    fun `unknown preference falls back to off`() {
        assertEquals(DownloadMirror.OFF, DownloadMirror.fromPreference(null))
        assertEquals(DownloadMirror.OFF, DownloadMirror.fromPreference("unknown"))
        assertEquals(DownloadMirror.GH_PROXY, DownloadMirror.fromPreference("gh-proxy"))
        assertEquals(DownloadMirror.entries.size, DownloadMirror.entries.map { it.id }.toSet().size)
    }
}
