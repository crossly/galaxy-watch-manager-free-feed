package dev.ricky.galaxywatchmanagerfree.wcs

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** 协议夹具中的设备身份使用合成值；包名与签名摘要保留协议定义。 */
class WcsCodecTest {

    @Test
    fun `oversized length cannot overflow into a negative slice`() {
        val malformed = Proto.tag(1, 2) + Proto.varint(Int.MAX_VALUE.toLong())
        assertTrue(Proto.parse(malformed).fields.isEmpty())
    }

    @Test
    fun `64 bit length cannot wrap to an empty field`() {
        val malformed = Proto.tag(1, 2) + Proto.varint(1L shl 32) + Proto.integer(2, 1)
        assertTrue(Proto.parse(malformed).fields.isEmpty())
    }

    private val rpcFrame =
        Proto.fromHex(
            "000000be" +
                "0a9801" +
                "529501" +
                "08c503" +
                "121f636f6d2e676f6f676c652e616e64726f69642e7765617261626c652e617070" +
                "1a2861313937663932313266326665643634663066663963326134656466323462396338383031633863" +
                "22083765353763306465" +
                "2800" +
                "320d2f73657474696e67732f727063" +
                "3a1c0a1a0a1073657474696e67732e434f4d4d414e441206080612023030" +
                "42086330666665653132" +
                "5002" +
                "6801" +
                "121b6b793448335267556c32696f4b5066346c5150576d784e58456d59" +
                "1801" +
                "2001" +
                "2804"
        )

    @Test
    fun `decode settings rpc frame with synthetic identities`() {
        val len = LengthPrefix.readLength(rpcFrame)
        assertEquals(rpcFrame.size - 4, len)

        val msg = WcsFrame.decode(rpcFrame.copyOfRange(4, rpcFrame.size))
        assertNotNull(msg)
        assertTrue(msg is WcsFrame.Incoming.Wearable)

        val w = msg as WcsFrame.Incoming.Wearable
        assertEquals("/settings/rpc", w.path)
        assertEquals(453L, w.code)
        assertEquals("com.google.android.wearable.app", w.senderPkg)
        assertEquals("a197f9212f2fed64f0ff9c2a4edf24b9c8801c8c", w.senderNode)
        assertEquals("7e57c0de", w.destNode)
        assertEquals(4L, w.envType)
        assertEquals("ky4H3RgUl2ioKPf4lQPWmxNXEmY", w.requestId)
        assertEquals(28, w.payloadRaw.size)
    }

    @Test
    fun `LAB invalid digest generator has expected wire length`() {
        val id = WcsFrame.newRequestId()
        assertEquals(27, id.length)
        assertTrue(id.all { it.isLetterOrDigit() || it == '-' || it == '_' })

        val digest = "ky4H3RgUl2ioKPf4lQPWmxNXEmY"
        assertEquals(27, digest.length)
        val decoded =
            java.util.Base64.getUrlDecoder()
                .decode(digest + "=".repeat((4 - digest.length % 4) % 4))
        assertEquals(20, decoded.size)
    }

    @Test
    fun `generated message pieces carry SHA1 of exact inner bytes`() {
        val inner = Proto.bytes(11, ByteArray(0))
        val frames =
            listOf(
                WcsFrame.envelope(inner),
                WcsFrame.envelopeNoType(inner),
                WcsFrame.syncStartFrame("7e57c0de"),
                WcsFrame.jsonFrame("/test", "{}", "pkg", "signature", "7e57c0de"),
            )
        for (frame in frames) {
            val env = Proto.parse(frame.copyOfRange(4, frame.size))
            val expected =
                java.util.Base64.getUrlEncoder()
                    .withoutPadding()
                    .encodeToString(
                        java.security.MessageDigest.getInstance("SHA-1").digest(env.raw(1)!!)
                    )
            assertEquals("message digest must match serialized content", expected, env.text(2))
        }
    }

    @Test
    fun `heartbeat digest matches capture without pairing credentials`() {
        val frame = WcsFrame.envelopeNoType(Proto.bytes(11, ByteArray(0)))
        assertEquals(
            "000000250a025a00121b4930305a724d6c397664744d4931485a74595064794b325667344118012001",
            Proto.toHex(frame),
        )
    }

    @Test
    fun `changing NodeInfo content recomputes its digest`() {
        fun frame(name: String) =
            WcsFrame.envelopeNoType(
                Proto.bytes(7, Proto.string(1, "c0ffee12") + Proto.string(2, name))
            )
        val first = frame("phone")
        val second = frame("renamed phone")
        for (bytes in listOf(first, second)) {
            val env = Proto.parse(bytes.copyOfRange(4, bytes.size))
            val expected =
                java.util.Base64.getUrlEncoder()
                    .withoutPadding()
                    .encodeToString(
                        java.security.MessageDigest.getInstance("SHA-1").digest(env.raw(1)!!)
                    )
            assertEquals(expected, env.text(2))
        }
    }

    @Test
    fun `wearableMessage serializes generation in field 10`() {
        val msg =
            WcsFrame.wearableMessage(
                path = "/test",
                payload = "hello".toByteArray(),
                senderPkg = CompanionProfile.WATCH7.packageName,
                senderNode = WcsPaths.SIGNATURE_PLUGIN,
                destNode = "7e57c0de",
                generation = 42L,
            )
        val m = Proto.parse(msg)
        val inner = m.nested(10)
        assertNotNull(inner)
        assertEquals(42L, inner?.num(10))
    }

    @Test
    fun `encode then decode round trip`() {
        val json = """{"msgId":"feature_exchange","msgType":2,"deviceId":"7e57c0de"}"""
        val frame =
            WcsFrame.jsonFrame(
                path = "/wcs_extension/internal/feature",
                json = json,
                senderPkg = "com.google.android.wearable.app",
                senderNode = "c0ffee12",
                destNode = "7e57c0de",
            )

        val body = frame.copyOfRange(4, frame.size)
        val msg = WcsFrame.decode(body) as WcsFrame.Incoming.Wearable
        assertEquals("/wcs_extension/internal/feature", msg.path)
        assertEquals(json, msg.payload)
        assertEquals(4L, msg.envType) // queueId=4 (legacy property name)
    }

    @Test
    fun `wear path normalisation`() {
        val (node, path) =
            WcsFrame.splitWearPath("wear://7e57c0de/w_module_sec_watch_setting/info/setting_info")
        assertEquals("7e57c0de", node)
        assertEquals("/w_module_sec_watch_setting/info/setting_info", path)

        val (n2, p2) = WcsFrame.splitWearPath("/wcs_extension/internal/feature")
        assertEquals(null, n2)
        assertEquals("/wcs_extension/internal/feature", p2)
    }

    @Test
    fun `node info decoding`() {
        val name = "测试手机"
        val inner =
            Proto.bytes(
                7,
                Proto.string(1, "c0ffee12") +
                    Proto.string(2, name) +
                    Proto.integer(3, 1792801879627L) +
                    Proto.integer(4, 3) +
                    Proto.integer(5, 1) +
                    Proto.integer(6, 0),
            )
        val env = Proto.bytes(1, inner) + Proto.string(2, WcsFrame.newRequestId())

        val msg = WcsFrame.decode(env)
        assertTrue(msg is WcsFrame.Incoming.NodeInfo)
        val n = msg as WcsFrame.Incoming.NodeInfo
        assertEquals("c0ffee12", n.nodeId)
        assertEquals(name, n.deviceName)
        assertEquals(1792801879627L, n.timestamp)
    }

    @Test
    fun `heartbeat decoding`() {
        val env =
            Proto.bytes(1, Proto.bytes(11, ByteArray(0))) + Proto.string(2, WcsFrame.newRequestId())
        val msg = WcsFrame.decode(env)
        assertTrue(msg is WcsFrame.Incoming.Heartbeat)
    }

    @Test
    fun `health body gzip base64 round trip`() {
        val payload =
            """[{"message_info":[{"action":"REQUEST_DATA"}]},{"device_info":[{"device":"SM-L7050","device_type":0}]}]"""

        val encoded = encodeHealthBody(payload)
        // Android Base64.NO_WRAP 等价物
        assertTrue(encoded.none { it == '\n' })

        val decoded = decodeHealthBody(encoded)
        assertEquals(2, decoded.length())
        val first = decoded.getJSONObject(0).getJSONArray("message_info").getJSONObject(0)
        assertEquals("REQUEST_DATA", first.getString("action"))
    }

    @Test
    fun `decode real health body from capture`() {
        // 实机抓到的 /samsung_health/wearable_message 包体（MESSAGE 形态，单对象）
        val b64 =
            "H4sIAAAAAAAA/6tWKi5JLCktVrICMvILClJTlHSUclOLixPTU4FirhWpRcmZxZl56fHBEHU6SmWpRcWZ+XlKVkYGBga1AOaIFX5BAAAA"
        val arr = decodeHealthBody(b64)
        assertEquals(1, arr.length())
        val obj = arr.getJSONObject(0)
        assertEquals("Exercising_Status", obj.getString("message"))
        assertEquals("stopped", obj.getString("status"))
        assertEquals(2000, obj.getInt("version"))
    }

    @Test
    fun `decode real battery DataItem from capture`() {
        val hex =
            "0ac8020a046461746112bf02080912ba024a170a0d626174746572795f6c6576656c12060806120230644a140a0a70736d5f73746174757312060808120240004a1e0a0b7275745f70736d5f6f6666120f0806120b30ffffffffffffffffff014a1d0a0a7275745f70736d5f6f6e120f0806120b30ffffffffffffffffff014a100a0673746174757312060806120230034a180a0e74696d655f72656d61696e696e6712060805120228004a200a1274696d655f73696e63655f63686172676564120a08051206288883f7a1744a2d0a1a75736167655f74696d655f666f725f66756c6c5f636861726765120f0806120b30ffffffffffffffffff014a220a187765617261626c655f70726f7465637465645f66756c6c7912060808120240004a290a1f7765617261626c655f70736d5f636f6e74726f6c5f7265737472696374656412060806120230000a140a09646174614d6170496412070806120330c801"
        val raw = Proto.fromHex(hex)
        val map = DataMapDecoder.decode(raw)
        assertEquals(200, map["dataMapId"])
        @Suppress("UNCHECKED_CAST") val data = map["data"] as Map<String, Any>
        assertEquals(100, data["battery_level"])
        assertEquals(false, data["psm_status"])
        assertEquals(3, data["status"])
        assertEquals(0L, data["time_remaining"])
    }

    @Test
    fun `wrist wake receipt preserves false when protobuf omits the default boolean field`() {
        val item =
            Proto.bytes(
                1,
                Proto.string(1, "booleanIsChecked") +
                    Proto.bytes(2, Proto.integer(1, 8) + Proto.bytes(2, ByteArray(0))),
            ) + DataMapEncoder.encode(mapOf("from" to "watch", "time" to 1_793_000_000_000L))
        val frame =
            WcsFrame.wearPathFrame(
                path = "wear://7e57c0de/w_module_sec_watch_setting/display/wake_on_wrist_raised",
                dataItems = listOf(item),
                senderPkg = "com.samsung.android.wcs.extension",
                nodeId = "7e57c0de",
            )

        val receipt =
            WcsFrame.decode(frame.copyOfRange(4, frame.size)) as WcsFrame.Incoming.WearPath

        assertEquals(false, receipt.dataMap["booleanIsChecked"])
        assertEquals("watch", receipt.dataMap["from"])
    }

    @Test
    fun `wrist wake receipt preserves false when protobuf omits the value submessage entirely`() {
        val item =
            Proto.bytes(
                1,
                Proto.string(1, "booleanIsChecked") + Proto.bytes(2, Proto.integer(1, 8)),
            ) + DataMapEncoder.encode(mapOf("from" to "watch", "time" to 1_793_000_000_000L))
        val frame =
            WcsFrame.wearPathFrame(
                path = "wear://7e57c0de/w_module_sec_watch_setting/display/wake_on_wrist_raised",
                dataItems = listOf(item),
                senderPkg = "com.samsung.android.wcs.extension",
                nodeId = "7e57c0de",
            )

        val receipt =
            WcsFrame.decode(frame.copyOfRange(4, frame.size)) as WcsFrame.Incoming.WearPath

        assertEquals(false, receipt.dataMap["booleanIsChecked"])
        assertEquals("watch", receipt.dataMap["from"])
    }

    @Test
    fun `setting metadata without a boolean value does not become false`() {
        val metadata = DataMapEncoder.encode(mapOf("from" to "watch", "time" to 1_793_000_000_000L))
        val emptyIntValue =
            Proto.bytes(
                1,
                Proto.string(1, "intLevel") +
                    Proto.bytes(2, Proto.integer(1, 6) + Proto.bytes(2, ByteArray(0))),
            )

        assertTrue("booleanIsChecked" !in DataMapDecoder.decode(metadata))
        val decoded = DataMapDecoder.decode(emptyIntValue + metadata)
        assertEquals(0, decoded["intLevel"])
        assertFalse(decoded["intLevel"] is Boolean)
        assertTrue("booleanIsChecked" !in decoded)
    }

    @Test
    fun `integer zero value preserved when protobuf omits default field`() {
        val item =
            Proto.bytes(
                1,
                Proto.string(1, "intSelectedItem") +
                    Proto.bytes(
                        2,
                        Proto.integer(1, DataMapEncoder.TYPE_INT32) + Proto.bytes(2, ByteArray(0)),
                    ),
            )
        val decoded = DataMapDecoder.decode(item)
        assertEquals(0, decoded["intSelectedItem"])
    }

    @Test
    fun `empty string preserved when protobuf omits default field`() {
        val item =
            Proto.bytes(
                1,
                Proto.string(1, "emptyText") +
                    Proto.bytes(
                        2,
                        Proto.integer(1, DataMapEncoder.TYPE_STRING) + Proto.bytes(2, ByteArray(0)),
                    ),
            )
        val decoded = DataMapDecoder.decode(item)
        assertEquals("", decoded["emptyText"])
    }

    @Test
    fun `array of typed elements decoded properly`() {
        val list = listOf(true, false, 42, "hello")
        val encoded = DataMapEncoder.encode(mapOf("testArray" to list))
        val decoded = DataMapDecoder.decode(encoded)
        @Suppress("UNCHECKED_CAST") val arr = decoded["testArray"] as List<Any?>
        assertEquals(listOf(true, false, 42, "hello"), arr)
    }

    @Test
    fun `find my watch message frames and finishalert round trip`() {
        val reqJson =
            JSONObject()
                .put("msg_id", WcsPaths.MSG_FMW_FINISH_ALERT_REQ)
                .put("type", "found_device")
                .put("deviceId", "7e57c0de")
                .toString()
        val frame =
            WcsFrame.jsonFrame(
                path = WcsPaths.FIND_MY_WATCH,
                json = reqJson,
                senderPkg = CompanionProfile.WATCH7.packageName,
                senderNode = "7e57c0de",
                destNode = "c0ffee12",
            )
        val decoded = WcsFrame.decode(frame.copyOfRange(4, frame.size))
        assertTrue(decoded is WcsFrame.Incoming.Wearable)
        val w = decoded as WcsFrame.Incoming.Wearable
        assertEquals(WcsPaths.FIND_MY_WATCH, w.path)
        val json = JSONObject(w.payload)
        assertEquals(WcsPaths.MSG_FMW_FINISH_ALERT_REQ, json.getString("msg_id"))
        assertEquals("found_device", json.getString("type"))
        assertEquals("7e57c0de", json.getString("deviceId"))
    }

    @Test
    fun `wear path decoding extracts data items and map`() {
        val hex =
            "0ac8020a046461746112bf02080912ba024a170a0d626174746572795f6c6576656c12060806120230644a140a0a70736d5f73746174757312060808120240004a1e0a0b7275745f70736d5f6f6666120f0806120b30ffffffffffffffffff014a1d0a0a7275745f70736d5f6f6e120f0806120b30ffffffffffffffffff014a100a0673746174757312060806120230034a180a0e74696d655f72656d61696e696e6712060805120228004a200a1274696d655f73696e63655f63686172676564120a08051206288883f7a1744a2d0a1a75736167655f74696d655f666f725f66756c6c5f636861726765120f0806120b30ffffffffffffffffff014a220a187765617261626c655f70726f7465637465645f66756c6c7912060808120240004a290a1f7765617261626c655f70736d5f636f6e74726f6c5f7265737472696374656412060806120230000a140a09646174614d6170496412070806120330c801"
        val itemBytes = Proto.fromHex(hex)
        val wpBody =
            Proto.string(1, "com.samsung.android.wcs.extension") +
                Proto.string(2, "wear://7e57c0de/c_devicecare/battery/change") +
                Proto.bytes(4, itemBytes)
        val inner = Proto.bytes(9, wpBody)
        val frame = WcsFrame.envelope(inner)

        val decoded = WcsFrame.decode(frame.copyOfRange(4, frame.size))
        assertTrue(decoded is WcsFrame.Incoming.WearPath)
        val wp = decoded as WcsFrame.Incoming.WearPath
        assertEquals("wear://7e57c0de/c_devicecare/battery/change", wp.path)
        assertEquals(1, wp.dataItems.size)
        assertEquals(100, (wp.dataMap["data"] as Map<*, *>)["battery_level"])
    }

    /* ---------------- DataMap 编码：写设置（实机已验证） ---------------- */

    @Test
    fun `encodeSettingDataMap_matchesCapturedPhoneWrite`() {
        // 抓包原字节：phone → watch 的 bedtime/lifestyle_info
        //   from="phone"(type 2)  support=false(type 8)  time=<int64>(type 5)
        val hex =
            "0a130a0466726f6d120b08021207120570686f6e65" +
                "0a110a07737570706f72741206080812024000" +
                "0a130a0474696d65120b0805120728f6ecc6da9634"
        val expected = Proto.fromHex(hex)

        val encoded =
            DataMapEncoder.encode(
                linkedMapOf("from" to "phone", "support" to false, "time" to 1792801879670L)
            )
        assertEquals(Proto.toHex(expected), Proto.toHex(encoded))
        // 编码结果可被自身解码器还原
        val back = DataMapDecoder.decode(encoded)
        assertEquals("phone", back["from"])
        assertEquals(false, back["support"])
        assertEquals(1792801879670L, back["time"])
    }

    @Test
    fun `encodeSettingDataMap_typesFollowHqbFieldNumbers`() {
        val encoded =
            DataMapEncoder.encode(
                linkedMapOf(
                    "booleanIsChecked" to true,
                    "intLevel" to 120,
                    "fontNameString" to "Default",
                )
            )
        val map = DataMapDecoder.decode(encoded)
        assertEquals(true, map["booleanIsChecked"])
        assertEquals(120, map["intLevel"])
        assertEquals("Default", map["fontNameString"])

        // 逐个校验 type 字段：string=2 int32=6 bool=8
        val p = Proto.parse(encoded)
        val entries = p.fields[1]!!.map { it as ByteArray }
        fun typeOf(entry: ByteArray): Long {
            val e = Proto.parse(entry)
            val wrapper = Proto.parse(e.raw(2)!!)
            return wrapper.num(1)!!
        }
        assertEquals(8L, typeOf(entries[0]))
        assertEquals(6L, typeOf(entries[1]))
        assertEquals(2L, typeOf(entries[2]))
    }

    @Test
    fun `writeSettingFrame_usesWearUriAndPhoneNode`() {
        val dataMap =
            DataMapEncoder.encode(
                linkedMapOf("intLevel" to 120, "from" to "phone", "time" to 1793021830140L)
            )
        val frame =
            WcsFrame.wearPathFrame(
                path = "wear://c0ffee12/w_module_sec_watch_setting/display/brightness",
                dataItems = listOf(dataMap),
                senderPkg = CompanionProfile.WATCH7.packageName,
                nodeId = "c0ffee12",
                seqId = 1793021830140L,
            )
        val env = Proto.parse(frame.copyOfRange(4, frame.size))
        assertEquals(3L, env.num(5)) // DATA_QUEUE
        val inner = Proto.parse(env.raw(1)!!)
        val wp = Proto.parse(inner.raw(9)!!)
        assertEquals("wear://c0ffee12/w_module_sec_watch_setting/display/brightness", wp.text(2))
        assertEquals("c0ffee12", wp.text(7))
        assertEquals(1793021830140L, wp.num(5))
        assertEquals(1, wp.fields[4]!!.size)
    }
}

/* ---------------- 与 WatchRepository 中相同的编解码实现（保持单一语义） ---------------- */

private fun gzip(data: ByteArray): ByteArray {
    val bos = ByteArrayOutputStream()
    GZIPOutputStream(bos).use { it.write(data) }
    return bos.toByteArray()
}

private fun gunzip(data: ByteArray): ByteArray =
    GZIPInputStream(ByteArrayInputStream(data), 102400).use { it.readBytes() }

private fun encodeHealthBody(json: String): String {
    val b64 =
        java.util.Base64.getEncoder().withoutPadding().encodeToString(gzip(json.toByteArray()))
    return b64
}

private fun decodeHealthBody(b64: String): JSONArray {
    val padded = b64 + "=".repeat((4 - b64.length % 4) % 4)
    val raw = java.util.Base64.getMimeDecoder().decode(padded)
    val json = String(gunzip(raw)).trim()
    if (json.startsWith("[")) return JSONArray(json)
    return JSONArray().put(JSONObject(json))
}
