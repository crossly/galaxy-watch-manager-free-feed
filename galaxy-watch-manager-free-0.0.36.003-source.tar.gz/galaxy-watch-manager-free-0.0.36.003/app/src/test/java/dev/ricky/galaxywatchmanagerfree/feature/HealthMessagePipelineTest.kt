package dev.ricky.galaxywatchmanagerfree.feature

import dev.ricky.galaxywatchmanagerfree.wcs.WcsPaths
import java.io.ByteArrayOutputStream
import java.time.Instant
import java.time.ZoneId
import java.util.Base64
import java.util.zip.GZIPOutputStream
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class HealthMessagePipelineTest {
    private val now = Instant.parse("2026-11-09T12:00:00Z").toEpochMilli()
    private val zone = ZoneId.of("UTC")

    @Test
    fun dataIsDecodedMergedProjectedAndSavedBeforeReturningItsAckCursor() {
        val harness = Harness()
        val result = harness.receive(request(rows = listOf(heart("one", 60))))

        assertTrue(result.persisted)
        assertEquals(
            HealthMessagePipeline.AckCursor(11, WcsPaths.HEALTH_ACTION_SYNC_DATA),
            result.ackCursor,
        )
        assertEquals(listOf("decode", "merge", "project", "persist", "ack:11"), harness.events)
        assertEquals(now, harness.heartReportTime)
        assertEquals(listOf(60), harness.restoredHeartRates())
    }

    @Test
    fun controlPacketAcksWithoutRebuildingOrSavingTheArchive() {
        val harness = Harness()
        val result = harness.receive(request(action = "LOG_DATA"))

        assertFalse(result.persisted)
        assertEquals(HealthMessagePipeline.AckCursor(11, "LOG_DATA"), result.ackCursor)
        assertEquals(listOf("decode", "ack:11"), harness.events)
        assertNull(harness.savedRecords)
    }

    @Test
    fun explicitEmptyTableStillRequiresPersistence() {
        val harness = Harness()
        val result = harness.receive(request(action = "LOG_DATA", rows = emptyList()))

        assertTrue(result.persisted)
        assertTrue(result.packet.chunks.containsKey(HeartRateLog.MODULE))
        assertEquals(listOf("decode", "merge", "project", "persist", "ack:11"), harness.events)
        assertNull(harness.heartReportTime)
    }

    @Test
    fun syncDataWithoutTablesStillRequiresPersistence() {
        val harness = Harness()
        assertTrue(harness.receive(request()).persisted)
        assertNull(harness.heartReportTime)
    }

    @Test
    fun failedSaveWithholdsAckAndTheNextControlPacketRetriesRetainedData() {
        val harness = Harness()
        harness.allowSave = false
        assertEquals(
            HealthMessagePipeline.Result.PersistenceFailed,
            harness.process(request(rows = listOf(heart("one", 60)))),
        )
        assertNull(harness.savedRecords)
        assertFalse(harness.events.any { it.startsWith("ack:") })

        harness.allowSave = true
        harness.events.clear()
        val retried = harness.receive(request(action = "LOG_DATA", sequence = 12))
        assertTrue(retried.persisted)
        assertEquals(HealthMessagePipeline.AckCursor(12, "LOG_DATA"), retried.ackCursor)
        assertEquals(listOf(60), harness.restoredHeartRates())
        assertEquals(listOf("decode", "merge", "project", "persist", "ack:12"), harness.events)

        harness.events.clear()
        assertFalse(harness.receive(request(action = "LOG_DATA", sequence = 13)).persisted)
        assertEquals(listOf("decode", "ack:13"), harness.events)
    }

    @Test
    fun repeatedPacketsAndRevisionsKeepOnlyTheNewestRetainedRecord() {
        val harness = Harness()
        harness.allowSave = false
        val first = request(rows = listOf(heart("one", 60)))
        assertEquals(HealthMessagePipeline.Result.PersistenceFailed, harness.process(first))
        harness.allowSave = true
        harness.receive(first)
        harness.receive(request(rows = listOf(heart("one", 90).put("update_time", now + 1))))
        assertEquals(listOf(90), harness.restoredHeartRates())
    }

    @Test
    fun responseAndPhoneOriginPacketsAreSavedWithoutReturningAnAckCursor() {
        for ((direction, message) in
            listOf(
                HealthPacket.Direction.FROM_WATCH to WcsPaths.HEALTH_MSG_RESPONSE,
                HealthPacket.Direction.FROM_PHONE to WcsPaths.HEALTH_MSG_REQUEST,
            )) {
            val harness = Harness()
            val result =
                harness.receive(
                    request(rows = listOf(heart("one", 60)), message = message),
                    direction,
                )
            assertTrue(result.persisted)
            assertNull(result.ackCursor)
            assertNull(harness.heartReportTime)
            assertFalse(harness.events.any { it.startsWith("ack:") })
        }
    }

    @Test
    fun missingActionDoesNotProduceAnAckCursor() {
        val harness = Harness()
        val result = harness.receive(request(action = "", rows = listOf(heart("one", 60))))
        assertTrue(result.persisted)
        assertNull(result.ackCursor)
    }

    @Test
    fun decodingCollectsRepeatedModuleTablesAndPreservesMetadataAndRawEntries() {
        val harness = Harness()
        val payload =
            JSONArray()
                .put(
                    JSONObject()
                        .put(
                            "message_info",
                            JSONArray()
                                .put(
                                    JSONObject()
                                        .put("action", WcsPaths.HEALTH_ACTION_SYNC_DATA)
                                        .put("request_module_list", HeartRateLog.MODULE)
                                ),
                        )
                )
                .put(
                    JSONObject()
                        .put(
                            "device_info",
                            JSONArray().put(JSONObject().put("device", "synthetic-watch")),
                        )
                )
                .put(JSONObject().put(HeartRateLog.MODULE, JSONArray().put(heart("one", 60))))
                .put(
                    JSONObject()
                        .put(
                            HeartRateLog.MODULE,
                            JSONArray().put(heart("two", 90).put("start_time", now - 120_000)),
                        )
                )
        val result = harness.receive(envelope(payload.toString()))
        assertEquals(HeartRateLog.MODULE, result.packet.moduleList)
        assertEquals("synthetic-watch", result.packet.deviceModel)
        assertEquals(2, result.packet.chunks.getValue(HeartRateLog.MODULE).size)
        assertEquals(4, result.packet.raw.size)
        assertEquals(listOf(90, 60), harness.restoredHeartRates())
    }

    @Test
    fun singleObjectBodiesAreDecodedAsOneEntry() {
        val harness = Harness()
        val body =
            JSONObject()
                .put("message_info", JSONArray().put(JSONObject().put("action", "LOG_DATA")))
        val result = harness.receive(envelope(body.toString()))
        assertFalse(result.persisted)
        assertEquals(1, result.packet.raw.size)
        assertEquals("LOG_DATA", result.ackCursor?.action)
    }

    @Test
    fun malformedBodyDoesNotMergePersistOrClearAnEarlierPendingSave() {
        val harness = Harness()
        harness.allowSave = false
        harness.process(request(rows = listOf(heart("one", 60))))
        harness.events.clear()
        val malformed = request().put("body", "not-base64")
        assertTrue(harness.process(malformed) is HealthMessagePipeline.Result.DecodeFailed)
        assertTrue(harness.events.isEmpty())

        harness.allowSave = true
        assertTrue(harness.receive(request(action = "LOG_DATA")).persisted)
        assertEquals(listOf(60), harness.restoredHeartRates())
    }

    @Test
    fun inactiveSessionAndMissingBodyPerformNoWork() {
        val harness = Harness()
        assertEquals(HealthMessagePipeline.Result.Skipped, harness.process(JSONObject()))
        harness.active = false
        assertEquals(HealthMessagePipeline.Result.Skipped, harness.process(request()))
        assertTrue(harness.events.isEmpty())
    }

    @Test
    fun cancellationDuringProjectionPreventsPersistenceAndKeepsRetryPending() {
        val harness = Harness()
        harness.afterProjection = { harness.active = false }
        assertEquals(
            HealthMessagePipeline.Result.Skipped,
            harness.process(request(rows = listOf(heart("one", 60)))),
        )
        assertNull(harness.savedRecords)
        assertEquals(listOf("decode", "merge", "project"), harness.events)

        harness.active = true
        harness.afterProjection = {}
        assertTrue(harness.receive(request(action = "LOG_DATA")).persisted)
        assertEquals(listOf(60), harness.restoredHeartRates())
    }

    @Test
    fun cancellationDuringCommitPreservesSaveResultButWithholdsAckCursor() {
        val harness = Harness()
        harness.afterSave = { harness.active = false }
        val result = harness.receive(request(rows = listOf(heart("one", 60))))
        assertTrue(result.persisted)
        assertNull(result.ackCursor)
        assertEquals(listOf(60), harness.restoredHeartRates())
        assertFalse(harness.events.any { it.startsWith("ack:") })
    }

    private inner class Harness {
        val events = mutableListOf<String>()
        val records = HealthRecordStore()
        var active = true
        var allowSave = true
        var savedRecords: String? = null
        var heartReportTime: Long? = null
        var afterProjection: () -> Unit = {}
        var afterSave: () -> Unit = {}
        private val pipeline =
            HealthMessagePipeline(
                isActive = { active },
                mergeAndProject = { packet, _, receivedAt ->
                    events += "merge"
                    records.merge(packet.chunks, receivedAt)
                    HealthDataProjection.build(records, receivedAt, zone)
                    events += "project"
                    afterProjection()
                    active
                },
                persist = { reportTime ->
                    events += "persist"
                    heartReportTime = reportTime
                    if (allowSave) savedRecords = records.encode()
                    afterSave()
                    allowSave
                },
                onDecoded = { events += "decode" },
            )

        fun process(
            request: JSONObject,
            direction: HealthPacket.Direction = HealthPacket.Direction.FROM_WATCH,
        ): HealthMessagePipeline.Result {
            val result = pipeline.process(request, direction, now)
            if (result is HealthMessagePipeline.Result.Completed) {
                result.ackCursor?.let { events += "ack:${it.sequenceNum}" }
            }
            return result
        }

        fun receive(
            request: JSONObject,
            direction: HealthPacket.Direction = HealthPacket.Direction.FROM_WATCH,
        ) = process(request, direction) as HealthMessagePipeline.Result.Completed

        fun restoredHeartRates(): List<Int> {
            val restored = HealthRecordStore()
            assertTrue(restored.restore(savedRecords, now))
            return HealthDataProjection.build(restored, now, zone).heartRatePoints.map { it.bpm }
        }
    }

    private fun heart(id: String, bpm: Int) =
        JSONObject()
            .put("datauuid", id)
            .put("start_time", now - 60_000)
            .put("update_time", now)
            .put("heart_rate", bpm)

    private fun request(
        action: String = WcsPaths.HEALTH_ACTION_SYNC_DATA,
        rows: List<JSONObject>? = null,
        sequence: Int = 11,
        message: String = WcsPaths.HEALTH_MSG_REQUEST,
    ): JSONObject {
        val entries =
            JSONArray()
                .put(
                    JSONObject()
                        .put("message_info", JSONArray().put(JSONObject().put("action", action)))
                )
        if (rows != null) entries.put(JSONObject().put(HeartRateLog.MODULE, JSONArray(rows)))
        return envelope(entries.toString(), sequence, message)
    }

    private fun envelope(
        payload: String,
        sequence: Int = 11,
        message: String = WcsPaths.HEALTH_MSG_REQUEST,
    ): JSONObject {
        val bytes = ByteArrayOutputStream()
        GZIPOutputStream(bytes).use { it.write(payload.toByteArray(Charsets.UTF_8)) }
        return JSONObject()
            .put("message", message)
            .put("sequence_num", sequence)
            .put("body", Base64.getEncoder().encodeToString(bytes.toByteArray()))
    }
}
