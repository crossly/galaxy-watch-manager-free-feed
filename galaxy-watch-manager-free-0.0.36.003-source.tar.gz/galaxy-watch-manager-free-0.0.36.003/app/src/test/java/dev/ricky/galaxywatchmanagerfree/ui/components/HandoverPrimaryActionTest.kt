package dev.ricky.galaxywatchmanagerfree.ui.components

import org.junit.Assert.assertEquals
import org.junit.Test

class HandoverPrimaryActionTest {
    @Test
    fun officialOwnershipWithVerifiedIdentityAndShizukuTakesConnectionBack() {
        assertEquals(HandoverPrimaryAction.DISABLE_AND_CONNECT, action(released = true))
    }

    @Test
    fun missingIdentityOnlyStartsIdentityPreparation() {
        assertEquals(HandoverPrimaryAction.PREPARE_IDENTITY, action(hasIdentity = false))
    }

    @Test
    fun preparedHandoverOffersOneClickDisableBeforeVerification() {
        assertEquals(
            HandoverPrimaryAction.DISABLE_AND_CONNECT,
            action(isPreparing = true, pending = true, canDisable = true),
        )
    }

    @Test
    fun manualDisableFallsBackToContinueVerification() {
        assertEquals(
            HandoverPrimaryAction.CONTINUE_VERIFICATION,
            action(isPreparing = true, pending = true),
        )
    }

    @Test
    fun alreadyDisabledAppsDoNotShowASecondDisableAction() {
        assertEquals(HandoverPrimaryAction.NONE, action(enabledApps = false))
    }

    @Test
    fun partiallyDisabledAppsStillOfferToDisableTheRemainingApps() {
        assertEquals(HandoverPrimaryAction.DISABLE_AND_CONNECT, action(enabledApps = true))
    }

    @Test
    fun partiallyDisabledAppsWithoutShizukuStillOfferManualSteps() {
        assertEquals(HandoverPrimaryAction.MANUAL, action(enabledApps = true, shizuku = false))
    }

    @Test
    fun unavailableShizukuFallsBackToManualSteps() {
        assertEquals(HandoverPrimaryAction.MANUAL, action(shizuku = false))
    }

    private fun action(
        isPreparing: Boolean = false,
        pending: Boolean = false,
        canDisable: Boolean = false,
        released: Boolean = false,
        enabledApps: Boolean = true,
        hasIdentity: Boolean = true,
        shizuku: Boolean = true,
    ): HandoverPrimaryAction =
        resolveHandoverPrimaryAction(
            isPreparing = isPreparing,
            canOneClickDisable = canDisable,
            hasPendingIdentity = pending,
            releasedToOfficialApps = released,
            hasEnabledOfficialApp = enabledApps,
            hasIdentity = hasIdentity,
            shizukuAvailable = shizuku,
        )
}
