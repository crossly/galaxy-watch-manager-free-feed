package dev.ricky.galaxywatchmanagerfree.feature

import org.junit.Assert.*
import org.junit.Test

class SettingLabelsTest {
    private val texts = dev.ricky.galaxywatchmanagerfree.TestStrings()
    private val labels = SettingLabels(java.util.Locale.SIMPLIFIED_CHINESE) { texts.get(it) }

    @Test
    fun `setting paths have readable context instead of selected item as a title`() {
        val label =
            labels.describe("/w_module_sec_watch_setting/display/screen_time_out/selected_item")
        assertEquals("显示", label.category)
        assertEquals("屏幕关闭时间 · 当前选项", label.title)
        assertTrue(label.known)
    }

    @Test
    fun `accessibility prefixes and compound option fields are translated`() {
        val label =
            labels.describe(
                "/w_module_sec_watch_setting_accessibility/selected_touch_and_hold_delay"
            )
        assertEquals("辅助功能", label.category)
        assertEquals("触摸并按住延迟 · 当前选项", label.title)
        assertTrue(label.known)
    }

    @Test
    fun `unknown vendor fields are identified as unknown rather than inventing a meaning`() {
        val label = labels.describe("/w_module_sec_watch_setting/vendor/opaque_value")
        assertFalse(label.known)
        assertEquals("未识别配置", label.title)
    }

    @Test
    fun `repository paths without a leading slash keep their category`() {
        assertEquals(
            "辅助功能",
            labels.describe("w_module_sec_watch_setting_accessibility/grayscale").category,
        )
        assertEquals(
            "显示",
            labels.describe("w_module_sec_watch_setting/display/brightness").category,
        )
    }

    @Test
    fun `value formatting explains switches lists and enum numbers`() {
        assertEquals(
            "振动",
            labels.value(SettingItem("/sound_settings/sound_mode", "mode", 3, "vibrate")),
        )
        assertEquals("已开启", labels.value(SettingItem("/x", "value", 0, true)))
        assertEquals("项目数：2", labels.value(SettingItem("/x", "value", 5, listOf(1, 2))))
        assertEquals(
            "右手腕",
            labels.value(SettingItem("/general/orientation/selected_wrist", "value", 1, 1)),
        )
        assertEquals(
            "选项 7（手表编号）",
            labels.value(SettingItem("/unknown/selected_item", "value", 1, 7)),
        )
    }
}
