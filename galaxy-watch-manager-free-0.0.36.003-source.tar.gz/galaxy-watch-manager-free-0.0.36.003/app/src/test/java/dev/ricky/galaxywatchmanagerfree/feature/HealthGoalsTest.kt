package dev.ricky.galaxywatchmanagerfree.feature

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class HealthGoalsTest {

    @Test
    fun `normalize clamps to Samsung goal range and 100-step grid`() {
        assertEquals(1000, HealthGoals.normalize(0))
        assertEquals(1000, HealthGoals.normalize(-500))
        assertEquals(6000, HealthGoals.normalize(6000))
        assertEquals(5600, HealthGoals.normalize(5550))
        assertEquals(50_000, HealthGoals.normalize(99_999))
    }

    @Test
    fun `local goal wins over watch values`() {
        val resolved = HealthGoals.resolve(localGoal = 8000, watchGoal = 10_000, recommendation = 6000)
        assertEquals(8000, resolved.goal)
        assertEquals(HealthGoals.Source.LOCAL, resolved.source)
    }

    @Test
    fun `watch target beats recommendation`() {
        val resolved = HealthGoals.resolve(localGoal = 0, watchGoal = 12_000, recommendation = 6000)
        assertEquals(12_000, resolved.goal)
        assertEquals(HealthGoals.Source.WATCH, resolved.source)
    }

    @Test
    fun `recommendation from the watch payload is the default`() {
        val resolved = HealthGoals.resolve(localGoal = 0, watchGoal = 0, recommendation = 6000)
        assertEquals(6000, resolved.goal)
        assertEquals(HealthGoals.Source.DEFAULT, resolved.source)
    }

    @Test
    fun `invalid sources fall back to six thousand`() {
        val resolved = HealthGoals.resolve(localGoal = 0, watchGoal = 12, recommendation = -1)
        assertEquals(HealthGoals.DEFAULT_STEP_GOAL, resolved.goal)
    }

    @Test
    fun `progress caps at one and ignores empty data`() {
        assertEquals(0f, HealthGoals.progress(-1, 6000), 0.0001f)
        assertEquals(0.5f, HealthGoals.progress(3000, 6000), 0.0001f)
        assertEquals(1f, HealthGoals.progress(12_000, 6000), 0.0001f)
        assertEquals(0f, HealthGoals.progress(1000, 0), 0.0001f)
    }

    @Test
    fun `remaining never goes negative and achieved matches goal`() {
        assertEquals(2000, HealthGoals.remaining(4000, 6000))
        assertEquals(0, HealthGoals.remaining(6500, 6000))
        assertTrue(HealthGoals.achieved(6000, 6000))
        assertFalse(HealthGoals.achieved(5999, 6000))
    }
}
