package dev.ricky.galaxywatchmanagerfree.ui

import dev.ricky.galaxywatchmanagerfree.feature.HealthSyncCoordinator
import dev.ricky.galaxywatchmanagerfree.feature.HeartRateLog
import dev.ricky.galaxywatchmanagerfree.feature.SettingCommands
import dev.ricky.galaxywatchmanagerfree.feature.SettingItem
import dev.ricky.galaxywatchmanagerfree.feature.SleepParser
import dev.ricky.galaxywatchmanagerfree.feature.VascularLoadLog
import dev.ricky.galaxywatchmanagerfree.feature.WatchSettingSchema
import dev.ricky.galaxywatchmanagerfree.feature.WatchState
import dev.ricky.galaxywatchmanagerfree.feature.monitor.EcgRecord
import dev.ricky.galaxywatchmanagerfree.ui.components.WatchModelKind
import dev.ricky.galaxywatchmanagerfree.ui.components.detectWatchModelKind
import dev.ricky.galaxywatchmanagerfree.wcs.DataMapDecoder
import dev.ricky.galaxywatchmanagerfree.wcs.DataMapEncoder
import dev.ricky.galaxywatchmanagerfree.wcs.Proto
import dev.ricky.galaxywatchmanagerfree.wcs.WcsPaths
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class WatchPageStateTest {
    private val dayKey = "2026-11-03"
    private val sleep =
        SleepParser.Session(
            startMillis = 1_000,
            endMillis = 8_000,
            segments = listOf(SleepParser.Segment(1_000, 8_000, SleepParser.Stage.DEEP)),
            efficiency = 90,
            score = 80,
        )
    private val heartRate = HeartRateLog.Point(1_000, 70)

    private val populated =
        WatchState(
            connected = true,
            sessionReady = true,
            deviceName = "Galaxy Watch",
            watchNode = "watch-node",
            firmware = "R900XXU1",
            batteryLevel = 81,
            ramApps = mapOf("com.example" to 12L),
            settingItems =
                mapOf(
                    "display/brightness" to SettingItem("display/brightness", "brightness", 1L, 42)
                ),
            brightness = 42,
            aodEnabled = true,
            batteryProtection = 1,
            autoRefresh = false,
            autoQueryIntervalSeconds = 600,
            activeWatchfacePkg = "com.example.face",
            watchfaceOrderType = "alphabetic",
            watchfaceEditRequested = true,
            todaySteps = 1_234,
            sleep = sleep,
            heartRateHistory = mapOf(dayKey to listOf(heartRate)),
            ecgRecords = listOf(EcgRecord("ecg", 1_000, 65, 1)),
            healthSyncStatus = HealthSyncCoordinator.Status.IDLE,
            lastHealthSyncTime = 2_000,
        )

    @Test
    fun `battery estimate reception and learning reach the overview`() {
        val state =
            populated.copy(
                remainingNormalMin = -1,
                remainingPsmMin = 0,
                normalBatteryEstimateReceived = true,
                psmBatteryEstimateReceived = true,
            )
        val projected = WatchPage.DASHBOARD.projection(state)

        assertEquals(-1, projected.remainingNormalMin)
        assertEquals(0, projected.remainingPsmMin)
        assertTrue(projected.normalBatteryEstimateReceived)
        assertTrue(projected.psmBatteryEstimateReceived)
        assertNotEquals(WatchPage.DASHBOARD.projection(populated), projected)
    }

    @Test
    fun `connection sync time follows health receipts without copying health readings`() {
        for ((deviceTime, healthTime) in
            listOf(0L to 0L, 0L to 9_000L, 9_000L to 0L, 1_000L to 9_000L, 9_000L to 1_000L)) {
            val state = populated.copy(lastSyncAt = deviceTime, lastHealthSyncTime = healthTime)
            val settings = WatchPage.SETTINGS.projection(state)
            assertEquals(maxOf(deviceTime, healthTime), settings.lastSyncAt)
            assertEquals(-1, settings.todaySteps)
            assertTrue(settings.heartRateHistory.isEmpty())
            assertEquals(0L, settings.lastHealthSyncTime)
        }
    }

    @Test
    fun `health readings and sync status do not change other pages`() {
        val changed =
            populated.copy(
                todaySteps = 4_321,
                sleep = null,
                heartRateHistory = emptyMap(),
                ecgRecords = emptyList(),
                healthSyncStatus = HealthSyncCoordinator.Status.SYNCING,
            )
        for (page in listOf(WatchPage.DASHBOARD, WatchPage.SETTINGS, WatchPage.WATCH_FACE)) {
            assertEquals(page.toString(), page.projection(populated), page.projection(changed))
        }
        assertNotEquals(
            WatchPage.HEALTH.projection(populated),
            WatchPage.HEALTH.projection(changed),
        )
    }

    @Test
    fun `vascular load capability changes reach both health measurement entry points`() {
        for (supported in listOf(false, true, false)) {
            val state = populated.copy(vascularLoadSupported = supported)
            for (page in listOf(WatchPage.HEALTH, WatchPage.SETTINGS)) {
                val projected = page.projection(state)
                assertEquals(page.toString(), supported, projected.vascularLoadSupported)
                if (supported) assertNotEquals(page.projection(populated), projected)
            }
            for (page in listOf(WatchPage.DASHBOARD, WatchPage.WATCH_FACE)) {
                assertEquals(page.toString(), page.projection(populated), page.projection(state))
            }
        }
    }

    @Test
    fun `vascular load backfill results reach health independently of capability changes`() {
        val baseline =
            VascularLoadLog.Entry("baseline", 1_000, 2_000, VascularLoadLog.Type.BASELINE, 0f)
        val measurement =
            VascularLoadLog.Entry("measurement", 3_000, 4_000, VascularLoadLog.Type.MEASUREMENT, 2f)
        val snapshot =
            VascularLoadLog.Snapshot(
                records = listOf(baseline, measurement),
                baseline = baseline,
                baselineComplete = true,
                latest = measurement,
                baselineNights = 3,
            )
        val before = populated.copy(vascularLoadSupported = true)
        val after = before.copy(vascularLoad = snapshot)
        val projected = WatchPage.HEALTH.projection(after)

        assertEquals(snapshot, projected.vascularLoad)
        assertNotEquals(WatchPage.HEALTH.projection(before), projected)
        for (page in listOf(WatchPage.DASHBOARD, WatchPage.SETTINGS, WatchPage.WATCH_FACE)) {
            assertEquals(page.toString(), page.projection(before), page.projection(after))
        }
    }

    @Test
    fun `wrist wake replies confirm off and on and reach overview and settings`() = runTest {
        val path = WcsPaths.SET_DISPLAY_WAKE_WRIST.trimStart('/')
        val spec = WatchSettingSchema.spec(path)!!
        val failures = mutableListOf<SettingCommands.Failure>()
        val commands = SettingCommands(this, onError = failures::add)
        var state = populated.copy(wakeOnWrist = true)

        for (enabled in listOf(false, true, false)) {
            assertTrue(commands.submit(path, enabled) { true })
            val valueBytes = if (enabled) Proto.integer(8, 1) else ByteArray(0)
            val entry =
                Proto.bytes(
                    1,
                    Proto.string(1, "booleanIsChecked") +
                        Proto.bytes(2, Proto.integer(1, 8) + Proto.bytes(2, valueBytes)),
                )
            val receipt =
                DataMapDecoder.decode(entry + DataMapEncoder.encode(mapOf("from" to "watch")))
            val value = receipt.getValue("booleanIsChecked")

            assertTrue(spec.kind.accepts(value))
            assertTrue(commands.confirm(path, value))
            state = spec.apply!!.invoke(state, value)
            assertEquals(enabled, WatchPage.DASHBOARD.projection(state).wakeOnWrist)
            assertEquals(enabled, WatchPage.SETTINGS.projection(state).wakeOnWrist)
            assertFalse(commands.hasPending(path))
        }
        assertTrue(failures.isEmpty())
    }

    @Test
    fun `settings updates do not change health overview or watch face`() {
        val changed =
            populated.copy(
                brightness = 5,
                aodEnabled = false,
                settingItems = emptyMap(),
                batteryProtection = 0,
                autoRefresh = true,
                autoQueryIntervalSeconds = 60,
            )
        for (page in listOf(WatchPage.DASHBOARD, WatchPage.HEALTH, WatchPage.WATCH_FACE)) {
            assertEquals(page.toString(), page.projection(populated), page.projection(changed))
        }
        assertNotEquals(
            WatchPage.SETTINGS.projection(populated),
            WatchPage.SETTINGS.projection(changed),
        )
    }

    @Test
    fun `overview updates do not change health settings or watch face`() {
        val changed =
            populated.copy(
                batteryLevel = 10,
                ramApps = emptyMap(),
                watchNode = "other-node",
                firmware = "other-firmware",
            )
        for (page in listOf(WatchPage.HEALTH, WatchPage.SETTINGS, WatchPage.WATCH_FACE)) {
            assertEquals(page.toString(), page.projection(populated), page.projection(changed))
        }
        assertNotEquals(
            WatchPage.DASHBOARD.projection(populated),
            WatchPage.DASHBOARD.projection(changed),
        )
    }

    @Test
    fun `watch face updates only reach pages that render faces`() {
        val orderChanged =
            populated.copy(watchfaceOrderType = "recent", watchfaceEditRequested = false)
        for (page in listOf(WatchPage.DASHBOARD, WatchPage.HEALTH, WatchPage.SETTINGS)) {
            assertEquals(page.toString(), page.projection(populated), page.projection(orderChanged))
        }
        assertNotEquals(
            WatchPage.WATCH_FACE.projection(populated),
            WatchPage.WATCH_FACE.projection(orderChanged),
        )

        val faceChanged = populated.copy(activeWatchfacePkg = "com.example.other")
        assertNotEquals(
            WatchPage.DASHBOARD.projection(populated),
            WatchPage.DASHBOARD.projection(faceChanged),
        )
        assertNotEquals(
            WatchPage.WATCH_FACE.projection(populated),
            WatchPage.WATCH_FACE.projection(faceChanged),
        )
        assertNotEquals(
            WatchPage.SETTINGS.projection(populated),
            WatchPage.SETTINGS.projection(faceChanged),
        )
        assertEquals(
            WatchPage.HEALTH.projection(populated),
            WatchPage.HEALTH.projection(faceChanged),
        )
    }

    @Test
    fun `current face preview and favorite reach the pages that render them`() {
        val favoriteChanged = populated.copy(activeWatchfaceFavoriteId = 9)
        for (page in listOf(WatchPage.DASHBOARD, WatchPage.WATCH_FACE)) {
            val projected = page.projection(favoriteChanged)
            assertEquals(9, projected.activeWatchfaceFavoriteId)
            assertNotEquals(page.projection(populated), projected)
        }
        for (page in listOf(WatchPage.HEALTH, WatchPage.SETTINGS)) {
            assertEquals(page.projection(populated), page.projection(favoriteChanged))
        }

        val previewChanged = populated.copy(activeWatchfacePreviewPath = "/watchfaces/preview.png")
        for (page in listOf(WatchPage.DASHBOARD, WatchPage.WATCH_FACE, WatchPage.SETTINGS)) {
            val projected = page.projection(previewChanged)
            assertEquals("/watchfaces/preview.png", projected.activeWatchfacePreviewPath)
            assertNotEquals(page.projection(populated), projected)
        }
        assertEquals(
            WatchPage.HEALTH.projection(populated),
            WatchPage.HEALTH.projection(previewChanged),
        )
    }

    @Test
    fun `watch alias and display name fallback logic`() {
        val defaultState = WatchState(deviceName = "Galaxy Watch7 (ABCD)")
        assertEquals("Galaxy Watch7", defaultState.displayName)

        val emptyDeviceState = WatchState(deviceName = "")
        assertEquals("Galaxy Watch", emptyDeviceState.displayName)

        val customAliasState =
            WatchState(deviceName = "Galaxy Watch7 (ABCD)", watchAlias = "My Titanium Ultra")
        assertEquals("My Titanium Ultra", customAliasState.displayName)
    }

    @Test
    fun `detect watch model kind accurately classifies ultra classic and standard models`() {
        assertEquals(WatchModelKind.ULTRA, detectWatchModelKind("SM-L700", "Galaxy Watch Ultra"))
        assertEquals(WatchModelKind.ULTRA, detectWatchModelKind("SM-L705F", "Galaxy Watch7 Ultra"))
        assertEquals(
            WatchModelKind.CLASSIC,
            detectWatchModelKind("SM-R950", "Galaxy Watch6 Classic"),
        )
        assertEquals(
            WatchModelKind.CLASSIC,
            detectWatchModelKind("SM-R880", "Galaxy Watch4 Classic"),
        )
        assertEquals(WatchModelKind.STANDARD, detectWatchModelKind("SM-L300", "Galaxy Watch7"))
        assertEquals(WatchModelKind.STANDARD, detectWatchModelKind("SM-R930", "Galaxy Watch6"))
    }

    @Test
    fun `settings connection page receives device identity and active face changes`() {
        val identity =
            populated.copy(
                deviceName = "Galaxy Watch7 (ABCD)",
                watchAlias = "My Titanium Ultra",
                modelName = "Galaxy Watch7",
                modelNumber = "SM-L300",
                startupSyncing = true,
            )
        val settings = WatchPage.SETTINGS.projection(identity)
        assertEquals("Galaxy Watch7 (ABCD)", settings.deviceName)
        assertEquals("My Titanium Ultra", settings.watchAlias)
        assertEquals("My Titanium Ultra", settings.displayName)
        assertEquals("Galaxy Watch7", settings.modelName)
        assertEquals("SM-L300", settings.modelNumber)
        assertTrue(settings.startupSyncing)

        val faceChanged =
            identity.copy(
                activeWatchfacePkg = "com.example.other",
                activeWatchfaceCls = "com.example.other.Face",
                activeWatchfacePreviewPath = "/watchfaces/other.png",
            )
        val faceSettings = WatchPage.SETTINGS.projection(faceChanged)
        assertEquals("com.example.other", faceSettings.activeWatchfacePkg)
        assertEquals("com.example.other.Face", faceSettings.activeWatchfaceCls)
        assertEquals("/watchfaces/other.png", faceSettings.activeWatchfacePreviewPath)
        assertNotEquals(settings, faceSettings)

        val healthChanged =
            faceChanged.copy(
                todaySteps = 9_999,
                sleep = null,
                heartRateHistory = emptyMap(),
                ecgRecords = emptyList(),
            )
        assertEquals(faceSettings, WatchPage.SETTINGS.projection(healthChanged))
    }

    @Test
    fun `explicit snapshots exclude fields owned by other pages`() {
        val health = WatchPage.HEALTH.projection(populated)
        assertEquals("", health.deviceName)
        assertEquals(-1, health.batteryLevel)
        assertEquals(-1, health.brightness)
        assertTrue(health.settingItems.isEmpty())
        assertNull(health.activeWatchfacePkg)

        val overview = WatchPage.DASHBOARD.projection(populated)
        assertEquals(-1, overview.todaySteps)
        assertNull(overview.sleep)
        assertTrue(overview.heartRateHistory.isEmpty())
        assertTrue(overview.settingItems.isEmpty())
        assertEquals(HealthSyncCoordinator.Status.DISCONNECTED, overview.healthSyncStatus)

        val settings = WatchPage.SETTINGS.projection(populated)
        assertEquals("Galaxy Watch", settings.deviceName)
        assertEquals("com.example.face", settings.activeWatchfacePkg)
        assertEquals(-1, settings.todaySteps)
        assertTrue(settings.ecgRecords.isEmpty())
        assertEquals(-1, settings.batteryLevel)

        val watchFace = WatchPage.WATCH_FACE.projection(populated)
        assertFalse(watchFace.connected)
        assertEquals(-1, watchFace.batteryLevel)
        assertEquals(-1, watchFace.todaySteps)
        assertTrue(watchFace.settingItems.isEmpty())
    }

    @Test
    fun `refresh action only follows refresh derived values`() {
        val idle = WatchState(sessionReady = true)
        assertEquals(
            RefreshActionState(canRefresh = true, refreshInProgress = false),
            idle.refreshActionState(),
        )
        assertEquals(
            idle.refreshActionState(),
            idle.copy(todaySteps = 1, batteryLevel = 2, brightness = 3).refreshActionState(),
        )
        for (busy in
            listOf(
                idle.copy(refreshing = true),
                idle.copy(startupSyncing = true),
                idle.copy(healthSyncStatus = HealthSyncCoordinator.Status.SYNCING),
            )) {
            assertTrue(busy.refreshActionState().refreshInProgress)
            assertFalse(busy.refreshActionState().canRefresh)
        }
        assertFalse(WatchState().refreshActionState().canRefresh)
    }
}
