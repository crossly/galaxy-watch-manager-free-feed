package dev.ricky.galaxywatchmanagerfree.feature

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DeviceCareBatteryPayloadTest {
    @Test
    fun `learning estimates replace previously valid durations`() {
        val state =
            WatchState(remainingNormalMin = 120, remainingPsmMin = 240)
                .withBatteryEstimates(mapOf("rut_psm_off" to -1, "rut_psm_on" to -1))

        assertEquals(-1, state.remainingNormalMin)
        assertEquals(-1, state.remainingPsmMin)
        assertTrue(state.normalBatteryEstimateReceived)
        assertTrue(state.psmBatteryEstimateReceived)
    }

    @Test
    fun `a real zero is distinct from an unread estimate`() {
        val unread = WatchState()
        val received = unread.withBatteryEstimates(mapOf("rut_psm_off" to 0))

        assertFalse(unread.normalBatteryEstimateReceived)
        assertEquals(0, received.remainingNormalMin)
        assertTrue(received.normalBatteryEstimateReceived)
        assertFalse(received.psmBatteryEstimateReceived)
    }

    @Test
    fun `base-info packets preserve estimates and independent reception flags`() {
        val state =
            WatchState().withBatteryEstimates(mapOf("rut_psm_off" to 120, "rut_psm_on" to 240))

        assertEquals(state, state.withBatteryEstimates(mapOf("battery_level" to 97)))
        assertEquals(state, state.withBatteryEstimates(mapOf("rut_psm_off" to "-1")))
    }

    @Test
    fun `one estimate update leaves the other unchanged`() {
        val state =
            WatchState().withBatteryEstimates(mapOf("rut_psm_off" to 120, "rut_psm_on" to 240))
        val updated = state.withBatteryEstimates(mapOf("rut_psm_off" to -1))

        assertEquals(-1, updated.remainingNormalMin)
        assertEquals(240, updated.remainingPsmMin)
        assertTrue(updated.normalBatteryEstimateReceived)
        assertTrue(updated.psmBatteryEstimateReceived)
    }

    @Test
    fun `metadata-only and empty frames do not confirm battery details`() {
        assertFalse(hasDeviceCareBatteryPayload(mapOf("dataMapId" to 209)))
        assertFalse(hasDeviceCareBatteryPayload(emptyMap()))
    }

    @Test
    fun `real battery fields confirm battery details`() {
        assertTrue(hasDeviceCareBatteryPayload(mapOf("battery_level" to 42)))
        assertTrue(hasDeviceCareBatteryPayload(mapOf("time_remaining" to 0L)))
        assertTrue(hasDeviceCareBatteryPayload(mapOf("rut_psm_off" to 0)))
        assertTrue(hasDeviceCareBatteryPayload(mapOf("psm_status" to false)))
    }

    @Test
    fun `an invalid-only battery level is not treated as a payload`() {
        assertFalse(hasDeviceCareBatteryPayload(mapOf("battery_level" to 101)))
    }

    @Test
    fun `parseDeviceCareMemory extracts app memory and distinguishes cleanable apps`() {
        val payload =
            mapOf(
                "data" to
                    mapOf(
                        "mem_total" to 2147483648L,
                        "mem_available" to 1073741824L,
                        "memory_usage_list" to
                            listOf(
                                mapOf(
                                    "package" to "com.tencent.mm",
                                    "memory_used" to 104857600L,
                                    "cleanable" to true,
                                ),
                                mapOf(
                                    "package" to "com.google.android.wearable.sysui",
                                    "memory_used" to 209715200L,
                                    "cleanable" to false,
                                ),
                                mapOf(
                                    "package" to "com.samsung.android.watch.cameracontroller",
                                    "memory_used" to 52428800L,
                                ),
                            ),
                    )
            )

        val (apps, cleanable) = parseDeviceCareMemory(payload)
        assertEquals(3, apps.size)
        assertEquals(100L, apps["com.tencent.mm"])
        assertEquals(200L, apps["com.google.android.wearable.sysui"])
        assertEquals(50L, apps["com.samsung.android.watch.cameracontroller"])

        assertEquals(
            listOf("com.tencent.mm", "com.samsung.android.watch.cameracontroller"),
            cleanable,
        )
    }

    @Test
    fun `parseDeviceCareMemory falls back to all apps when cleanable is empty`() {
        val payload =
            mapOf(
                "memory_usage_list" to
                    listOf(
                        mapOf(
                            "package" to "com.google.android.wearable.sysui",
                            "memory_used" to 209715200L,
                            "cleanable" to false,
                        )
                    )
            )

        val (apps, cleanable) = parseDeviceCareMemory(payload)
        assertEquals(listOf("com.google.android.wearable.sysui"), cleanable)
    }
}
