package dev.ricky.galaxywatchmanagerfree.feature

import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ConnectionNotificationSnapshotTest {
    private val zone: ZoneId = ZoneId.of("Asia/Shanghai")
    private val day = LocalDate.of(2026, 10, 31)

    private fun millisOf(hour: Int, minute: Int = 0, dayOffset: Int = 0): Long =
        LocalDateTime.of(day.plusDays(dayOffset.toLong()), java.time.LocalTime.of(hour, minute))
            .atZone(zone)
            .toInstant()
            .toEpochMilli()

    @Test
    fun `snapshot uses today's latest heart rate and real step progress`() {
        val todayKey = day.toString()
        val snapshot =
            ConnectionNotificationSnapshot.from(
                WatchState(
                    deviceName = "Galaxy Watch",
                    sessionReady = true,
                    todaySteps = 6_540,
                    stepGoal = 8_000,
                    heartRateHistory =
                        mapOf(
                            todayKey to
                                listOf(
                                    HeartRateLog.Point(millisOf(9), 68),
                                    HeartRateLog.Point(millisOf(14), 75),
                                )
                        ),
                    latestHeartRate = HeartRateLog.Point(millisOf(21, dayOffset = -1), 91),
                    batteryLevel = 82,
                ),
                nowMillis = millisOf(16),
                zone = zone,
            )

        assertEquals("Galaxy Watch", snapshot.deviceName)
        assertEquals(ConnectionNotificationState.READY, snapshot.connection)
        assertEquals(6_540, snapshot.steps)
        assertEquals(8_000, snapshot.stepGoal)
        assertEquals(81, snapshot.stepProgressPercent)
        assertEquals(75, snapshot.heartRate)
        assertEquals(82, snapshot.batteryLevel)
    }

    @Test
    fun `yesterday's heart rate is not presented as today's dynamic value`() {
        val snapshot =
            ConnectionNotificationSnapshot.from(
                WatchState(
                    heartRateHistory =
                        mapOf(
                            day.minusDays(1).toString() to
                                listOf(HeartRateLog.Point(millisOf(22, dayOffset = -1), 91))
                        ),
                    latestHeartRate = HeartRateLog.Point(millisOf(22, dayOffset = -1), 91),
                ),
                nowMillis = millisOf(8),
                zone = zone,
            )
        assertNull(snapshot.heartRate)
    }

    @Test
    fun `zero steps are valid and unrelated state updates do not churn the snapshot`() {
        val base =
            WatchState(
                connected = true,
                deviceName = "Watch",
                todaySteps = 0,
                stepGoal = 6_000,
                batteryLevel = 67,
            )
        val first = ConnectionNotificationSnapshot.from(base, millisOf(10), zone)
        val second =
            ConnectionNotificationSnapshot.from(
                base.copy(firmware = "new firmware", brightness = 100),
                millisOf(10, 5),
                zone,
            )
        assertEquals(0, first.steps)
        assertEquals(0, first.stepProgressPercent)
        assertEquals(ConnectionNotificationState.CONNECTING, first.connection)
        assertEquals(first, second)
        assertNotEquals(
            first,
            ConnectionNotificationSnapshot.from(base.copy(todaySteps = 1), millisOf(10), zone),
        )
    }

    @Test
    fun `snapshot prioritizes watchAlias over deviceName and modelName for title`() {
        val state =
            WatchState(
                deviceName = "Galaxy Watch 7 Ultra (4A2B)",
                modelName = "Galaxy Watch7 Ultra",
                watchAlias = "Ricky's Ultra",
                sessionReady = true,
            )
        val snapshot = ConnectionNotificationSnapshot.from(state)
        assertEquals("Ricky's Ultra", snapshot.deviceName)
    }

    @Test
    fun `snapshot captures additional metrics including calories, sleep, distance and stress`() {
        val state =
            WatchState(
                deviceName = "Galaxy Watch",
                todayCalories = 450.5f,
                todayDistanceMeters = 5200f,
                lastStressScore = 42,
                sleep =
                    SleepParser.Session(
                        startMillis = millisOf(0),
                        endMillis = millisOf(7, 30),
                        segments = emptyList(),
                        efficiency = 90,
                        score = 85,
                        reportedSleepMinutes = 450,
                    ),
            )
        val customConfig = NotificationBarConfig(showCalories = true, showSleep = true)
        val snapshot = ConnectionNotificationSnapshot.from(state, config = customConfig)

        assertEquals(450.5f, snapshot.calories)
        assertEquals(5200f, snapshot.distanceMeters)
        assertEquals(42, snapshot.stressScore)
        assertEquals(450, snapshot.sleepMinutes)
        assertEquals(customConfig, snapshot.config)
    }
}
