package dev.ricky.galaxywatchmanagerfree.wcs

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class IdentityProofTest {
    @Test
    fun proofMustBelongToFreshPeerAndCandidateDestination() {
        assertTrue(
            IdentityProof.matchesPeer("abcdef12", "12345678", "abcdef12", "12345678", "abcdef12")
        )
        assertTrue(IdentityProof.matchesPeer("abcdef12", "12345678", null, "12345678", null))
        assertFalse(IdentityProof.matchesPeer("", "12345678", null, "12345678", null))
        assertFalse(IdentityProof.matchesPeer("abcdef12", "12345678", "badcafe1", "12345678", null))
        assertFalse(IdentityProof.matchesPeer("abcdef12", "12345678", null, "87654321", null))
        assertFalse(IdentityProof.matchesPeer("abcdef12", "12345678", null, "12345678", "badcafe1"))
    }

    @Test
    fun emptyMalformedAndPhoneEchoAreNotProof() {
        for (payload in
            listOf(
                "{}",
                "bad",
                "{\"msgId\":\"feature_exchange\",\"data\":{}}",
                "{\"msgId\":\"feature_exchange\",\"data\":{\"modelNumber\":\"SM-S938U1\",\"modelName\":\"Galaxy S25 Ultra\"}}",
            )) {
            assertFalse(IdentityProof.accepts(WcsPaths.INTERNAL_FEATURE, payload))
        }
    }

    @Test
    fun watchFeatureRequiresCorrectPathMessageAndSuccessfulResult() {
        val valid =
            "{\"msgId\":\"feature_exchange\",\"result\":0,\"data\":{\"modelNumber\":\"SM-L705\"}}"
        assertTrue(IdentityProof.accepts(WcsPaths.INTERNAL_FEATURE, valid))
        assertFalse(IdentityProof.accepts(WcsPaths.INTERNAL_STATUS, valid))
        assertFalse(
            IdentityProof.accepts(
                WcsPaths.INTERNAL_FEATURE,
                valid.replace("\"result\":0", "\"result\":1"),
            )
        )
        assertFalse(
            IdentityProof.accepts(
                WcsPaths.INTERNAL_FEATURE,
                valid.replace("feature_exchange", "status_exchange"),
            )
        )
    }

    @Test
    fun watchfaceNeedsConcreteComponentAndCorrectMessage() {
        val valid =
            "{\"msgId\":\"${WcsPaths.MSG_CHANGE_ACTIVE_WATCHFACE}\",\"data\":{\"packageName\":\"com.samsung.watch\",\"className\":\"Face\"}}"
        assertTrue(IdentityProof.accepts(WcsPaths.WATCHFACE_SYSUI, valid))
        assertFalse(IdentityProof.accepts(WcsPaths.WATCHFACE_SYSUI, valid.replace("Face", "")))
        assertFalse(IdentityProof.accepts(WcsPaths.INTERNAL_FEATURE, valid))
    }
}
