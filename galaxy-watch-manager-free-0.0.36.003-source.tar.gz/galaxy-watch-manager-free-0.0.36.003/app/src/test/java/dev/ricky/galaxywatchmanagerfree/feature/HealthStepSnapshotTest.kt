package dev.ricky.galaxywatchmanagerfree.feature

import java.time.ZoneId
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class HealthStepSnapshotTest {
    private val now = 1793112414441L
    private val zone = ZoneId.of("Asia/Shanghai")

    private fun info(start: Long, last: Boolean) =
        JSONObject().put("start_time", start).put("end_time", now).put("is_last_chunk", last)

    private fun records(): List<JSONObject> {
        val raw = javaClass.getResource("/health/cold-sync-step-intervals.json")!!.readText()
        val array = JSONArray(raw)
        return (0 until array.length()).map(array::getJSONObject)
    }

    @Test
    fun `captured cold sync recovers exactly the watch total rather than the cached 3270`() {
        val snapshot =
            HealthStepSnapshot().apply { begin() }.accept(info(0, true), records(), now, zone)!!
        assertEquals(99, snapshot.records.size)
        assertEquals(4269, snapshot.total)
    }

    @Test
    fun `ordinary delta window cannot be mistaken for a complete day`() {
        val collector = HealthStepSnapshot().apply { begin() }
        assertNull(collector.accept(info(now - 60_000, true), records().take(1), now, zone))
    }

    @Test
    fun `unsolicited zero-start window cannot replace the cache`() {
        assertNull(HealthStepSnapshot().accept(info(0, true), records(), now, zone))
    }

    @Test
    fun `chunks are collected until the explicit final chunk`() {
        val collector = HealthStepSnapshot().apply { begin() }
        assertNull(collector.accept(info(0, false), records().take(40), now, zone))
        val result = collector.accept(info(now - 1000, true), records().drop(40), now, zone)!!
        assertEquals(4269, result.total)
        assertNull(collector.accept(info(0, true), records(), now, zone))
    }

    @Test
    fun `duplicate records across chunks are not added twice`() {
        val collector = HealthStepSnapshot().apply { begin() }
        collector.accept(info(0, false), records(), now, zone)
        assertEquals(4269, collector.accept(info(0, true), records(), now, zone)!!.total)
    }

    @Test
    fun `missing step module cannot establish zero steps`() {
        assertNull(HealthStepSnapshot().apply { begin() }.accept(info(0, true), null, now, zone))
        assertEquals(
            0,
            HealthStepSnapshot()
                .apply { begin() }
                .accept(info(0, true), emptyList(), now, zone)!!
                .total,
        )
    }

    @Test
    fun `reset cancels pending collection so subsequent incremental sync cannot complete as full snapshot`() {
        val collector = HealthStepSnapshot().apply { begin() }
        assertNull(collector.accept(info(0, false), records().take(40), now, zone))
        collector.reset()
        assertNull(collector.accept(info(now - 1000, true), records().drop(40), now, zone))
    }
}
