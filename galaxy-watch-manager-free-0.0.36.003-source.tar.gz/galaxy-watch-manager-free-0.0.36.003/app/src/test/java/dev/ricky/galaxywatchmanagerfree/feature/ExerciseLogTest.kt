package dev.ricky.galaxywatchmanagerfree.feature

import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExerciseLogTest {
    private val texts = dev.ricky.galaxywatchmanagerfree.TestStrings()

    private fun typeName(code: Int) = texts.get(ExerciseLog.typeNameRes(code), code)

    private val zone: ZoneId = ZoneId.of("Asia/Shanghai")
    private val day = LocalDate.of(2026, 10, 27)

    private fun millisOf(hour: Int, minute: Int = 0, dayOffset: Int = 0): Long =
        LocalDateTime.of(day.plusDays(dayOffset.toLong()), java.time.LocalTime.of(hour, minute))
            .atZone(zone)
            .toInstant()
            .toEpochMilli()

    private fun record(
        uuid: String = "ex-1",
        type: Int = 1002,
        start: Long = millisOf(18),
        end: Long = millisOf(18, 32),
    ) =
        JSONObject()
            .put("datauuid", uuid)
            .put("exercise_type", type)
            .put("start_time", start)
            .put("end_time", end)
            .put("calorie", 246.5)
            .put("distance", 5120.0)
            .put("mean_heart_rate", 148)
            .put("max_heart_rate", 172)

    @Test
    fun `sport labels match the documented Samsung type codes`() {
        val expected =
            mapOf(
                11007 to "骑行",
                12001 to "有氧健身",
                14002 to "水中有氧",
                14004 to "帆船",
                14007 to "皮划艇",
                16002 to "滑雪",
                16007 to "单板滑雪",
                9014001 to "户外游泳",
            )
        expected.forEach { (code, label) -> assertEquals("sport $code", label, typeName(code)) }
        assertEquals("运动 12002", typeName(12002))
    }

    @Test
    fun `exercise records parse into sessions`() {
        val session = ExerciseLog.parse(listOf(record())).single()
        assertEquals(1002, session.typeCode)
        assertEquals("跑步", texts.get(session.typeNameRes, session.typeCode))
        assertEquals(32, session.durationMinutes)
        assertEquals(246, session.calories)
        assertEquals(5120.0, session.distanceMeters, 0.0001)
        assertEquals(148, session.avgHeartRate)
        assertEquals(172, session.maxHeartRate)
    }

    @Test
    fun `explicit duration wins over timestamps`() {
        val session = ExerciseLog.parse(listOf(record().put("duration", 45 * 60_000L))).single()
        assertEquals(45, session.durationMinutes)
    }

    @Test
    fun `records without start or duration are dropped`() {
        assertTrue(ExerciseLog.parse(listOf(JSONObject().put("exercise_type", 1001))).isEmpty())
        assertTrue(
            ExerciseLog.parse(
                    listOf(JSONObject().put("start_time", millisOf(9)).put("exercise_type", 1001))
                )
                .isEmpty()
        )
    }

    @Test
    fun `login long field names are accepted`() {
        val record =
            JSONObject()
                .put("com.samsung.health.exercise.start_time", millisOf(7))
                .put("com.samsung.health.exercise.end_time", millisOf(7, 20))
                .put("com.samsung.health.exercise.exercise_type", 1001)
                .put("com.samsung.health.exercise.calorie", 88.0)
        val session = ExerciseLog.parse(listOf(record)).single()
        assertEquals("健走", texts.get(session.typeNameRes, session.typeCode))
        assertEquals(20, session.durationMinutes)
        assertEquals(88, session.calories)
    }

    @Test
    fun `merge deduplicates by uuid and keeps newest first`() {
        val first =
            ExerciseLog.parse(
                listOf(record(uuid = "a", start = millisOf(7), end = millisOf(7, 30)))
            )
        val second =
            ExerciseLog.parse(
                listOf(record(uuid = "b", start = millisOf(18), end = millisOf(18, 30)))
            )
        val merged = ExerciseLog.merge(first, second)
        assertEquals(listOf("b", "a"), merged.map { it.id })

        val updated =
            ExerciseLog.parse(
                listOf(record(uuid = "a", start = millisOf(7), end = millisOf(7, 45)))
            )
        val afterUpdate = ExerciseLog.merge(merged, updated)
        assertEquals(2, afterUpdate.size)
        assertEquals(45, afterUpdate.first { it.id == "a" }.durationMinutes)
    }

    @Test
    fun `merge caps the history`() {
        val sessions =
            (0 until 50).map { index ->
                ExerciseLog.parse(
                        listOf(
                            record(
                                uuid = "e$index",
                                start = millisOf(6, 0, -index),
                                end = millisOf(6, 30, -index),
                            )
                        )
                    )
                    .single()
            }
        assertEquals(50, ExerciseLog.merge(emptyList(), sessions).size)
        assertEquals(40, ExerciseLog.merge(emptyList(), sessions, keep = 40).size)
    }

    @Test
    fun `sessions survive a round trip`() {
        val session = ExerciseLog.parse(listOf(record())).single()
        val decoded = ExerciseLog.decode(ExerciseLog.encode(listOf(session))).single()
        assertEquals(session, decoded)
        assertTrue(ExerciseLog.decode(null).isEmpty())
        assertTrue(ExerciseLog.decode("garbage").isEmpty())
    }

    @Test
    fun `today summary counts only todays sessions`() {
        val sessions =
            ExerciseLog.parse(
                listOf(
                    record(uuid = "today", start = millisOf(8), end = millisOf(8, 40)),
                    record(
                        uuid = "yesterday",
                        start = millisOf(8, 0, -1),
                        end = millisOf(8, 30, -1),
                    ),
                )
            )
        val (count, minutes, calories) = ExerciseLog.todaySummary(sessions, day, zone)
        assertEquals(1, count)
        assertEquals(40, minutes)
        assertEquals(246, calories)
    }

    @Test
    fun `captured walking distances retain decimal meters and match speed times active time`() {
        val raw = javaClass.getResource("/health/exercise-history.json")!!.readText()
        val array = org.json.JSONArray(raw)
        val records = (0 until array.length()).map { array.getJSONObject(it) }
        val sessions = ExerciseLog.parse(records)
        assertEquals(8, sessions.size)
        assertEquals(8732.66015625, sessions.sumOf { it.distanceMeters }, 0.001)
        assertTrue(sessions.all { it.autoDetected && it.stepCount > 0 })
        assertTrue(sessions.none { it.locationPayloadPresent || it.locationPointCount > 0 })
        sessions.zip(records).forEach { (session, record) ->
            assertEquals(
                record.getDouble("mean_speed") * record.getLong("duration") / 1000.0,
                session.distanceMeters,
                0.001,
            )
        }
    }

    @Test
    fun `active time keeps seconds and coordinate availability is explicit`() {
        val record =
            record()
                .put("duration", 652_932)
                .put(
                    "location_data",
                    org.json
                        .JSONArray()
                        .put(JSONObject().put("latitude", 31.2).put("longitude", 121.4))
                        .put(JSONObject().put("latitude", 31.21).put("longitude", 121.41)),
                )
        val session = ExerciseLog.parse(listOf(record)).single()
        assertEquals(
            "10 分 52 秒",
            texts.get(
                dev.ricky.galaxywatchmanagerfree.R.string.workout_duration,
                session.durationMillis / 60_000,
                session.durationMillis % 60_000 / 1000,
            ),
        )
        assertEquals(2, session.locationPointCount)
        assertTrue(session.locationPayloadPresent)
        assertEquals(session, ExerciseLog.decode(ExerciseLog.encode(listOf(session))).single())
    }

    @Test
    fun `miscellaneous is a real type and missing type stays unclassified`() {
        val misc = ExerciseLog.parse(listOf(record(type = 0))).single()
        val missing = record().apply { remove("exercise_type") }
        assertEquals("其他运动", typeName(misc.typeCode))
        assertEquals(-1, ExerciseLog.parse(listOf(missing)).single().typeCode)
        assertEquals(117, ExerciseTypes.supportedCodes.size)
        ExerciseTypes.supportedCodes.forEach { assertTrue(typeName(it).isNotBlank()) }
    }

    @Test
    fun `swim and strength counts and detailed metrics survive cache restore`() {
        val swim =
            record(type = 14001)
                .put("count_type", 30002)
                .put("count", 600)
                .put("min_heart_rate", 65)
                .put("mean_speed", 1.5)
                .put("max_speed", 2.3)
                .put("altitude_gain", 0)
                .put("source_type", 1)
        val strength =
            record(uuid = "strength", type = 10012)
                .put("count_type", 30004)
                .put("count", 30)
                .put("title", "Leg session")
                .put("routine_datauuid", "routine")
        val parsed = ExerciseLog.parse(listOf(swim, strength))
        assertEquals(-1, parsed.first().stepCount)
        assertEquals(600, parsed.first().count)
        assertEquals(30002, parsed.first().countType)
        assertEquals(65, parsed.first().minHeartRate)
        assertEquals(2.3, parsed.first().maxSpeed, 0.001)
        assertEquals("Leg session", parsed.last().title)
        assertEquals(parsed, ExerciseLog.decode(ExerciseLog.encode(parsed)))
    }

    @Test
    fun `custom titles resolve and routine children do not inflate totals`() {
        val custom = JSONObject().put("custom_id", "custom-1").put("custom_name", "Mobility")
        val child =
            ExerciseLog.parse(
                    listOf(
                        record(type = 51001)
                            .put("custom_id", "custom-1")
                            .put("routine_datauuid", "routine-1")
                    ),
                    listOf(custom),
                )
                .single()
        val parent =
            child.copy(id = "routine-1", typeCode = 51005, routineId = "", title = "Routine")
        assertEquals("Mobility", child.title)
        assertEquals(listOf(parent), ExerciseLog.topLevel(listOf(child, parent)))
        assertEquals(1, ExerciseLog.todaySummary(listOf(child, parent), day, zone).first)
        assertEquals(listOf(child), ExerciseLog.topLevel(listOf(child)))
    }

    @Test
    fun `unknown sport codes stay readable`() {
        assertEquals("运动 88888", typeName(88888))
    }
}
