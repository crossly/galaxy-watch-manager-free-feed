package dev.ricky.galaxywatchmanagerfree.feature

import dev.ricky.galaxywatchmanagerfree.wcs.CompanionProfile
import dev.ricky.galaxywatchmanagerfree.wcs.DataMapDecoder
import dev.ricky.galaxywatchmanagerfree.wcs.DataMapEncoder
import dev.ricky.galaxywatchmanagerfree.wcs.Proto
import dev.ricky.galaxywatchmanagerfree.wcs.WcsFrame
import dev.ricky.galaxywatchmanagerfree.wcs.WcsPaths
import dev.ricky.galaxywatchmanagerfree.wcs.WearDataSnapshot
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class WatchNameSyncTest {
    private val sourceUri = "wear://7e57c0de${WcsPaths.SET_INFO_WATCH_NAME}"
    private val phoneUri = "wear://c0ffee12${WcsPaths.SET_INFO_WATCH_NAME}"
    private val original =
        mapOf<String, Any>(
            "from" to "watch",
            "key" to "stringName",
            "stringName" to "Old name",
            "type" to 3L,
            "time" to 123L,
            "booleanIsAvailable" to true,
        )

    private inner class Fixture(scope: CoroutineScope, initialAlias: String = "") {
        val events = mutableListOf<String>()
        val writes = mutableListOf<Map<String, Any>>()
        val writtenUris = mutableListOf<String>()
        val frames = mutableListOf<ByteArray>()
        val results = mutableListOf<WatchNameSync.Result>()
        var name = initialAlias
        var readSucceeds = true
        var writeSucceeds = true
        var watchNode = "7e57c0de"
        val sync =
            WatchNameSync(
                scope,
                initialAlias,
                watchNode = { watchNode },
                requestRead = {
                    events += "read"
                    readSucceeds
                },
                write = { uri, dataMap ->
                    events += "write"
                    writes += dataMap
                    writtenUris += uri
                    frames +=
                        WcsFrame.wearPathFrame(
                            path = uri,
                            dataItems = listOf(DataMapEncoder.encode(dataMap)),
                            senderPkg = CompanionProfile.WATCH7.packageName,
                            nodeId = "c0ffee12",
                            seqId = 42L,
                        )
                    writeSucceeds
                },
                onName = { name = it },
                onResult = results::add,
            )

        fun receive(dataMap: Map<String, Any>, uri: String = sourceUri) {
            sync.receive(uri, dataMap)
        }
    }

    @Test
    fun `rename writes a restored name item even when the watch sends no duplicate read response`() =
        runTest {
            val frame =
                WcsFrame.wearPathFrame(
                    path = sourceUri,
                    dataItems = listOf(DataMapEncoder.encode(original)),
                    senderPkg = CompanionProfile.WATCH7.packageName,
                    nodeId = "7e57c0de",
                    seqId = 42L,
                )
            val snapshot = WearDataSnapshot()
            assertTrue(snapshot.accept(frame.copyOfRange(4, frame.size)))
            val restored = WearDataSnapshot()
            restored.restore(snapshot.encode())
            val f = Fixture(this)
            restored.envelopes().forEach { envelope ->
                val item = WcsFrame.decode(envelope) as WcsFrame.Incoming.WearPath
                f.receive(item.dataMap, item.path)
            }
            f.sync.connect()
            f.sync.rename("My watch")

            assertEquals(
                "A cached DataItem must reach the write without another incoming frame",
                1,
                f.frames.size,
            )
            val item = Proto.parse(f.frames.single().drop(4).toByteArray()).nested(1)!!.nested(9)!!
            assertEquals(sourceUri, item.text(2))
            assertEquals("c0ffee12", item.text(7))
            assertEquals(WcsPaths.SIGNATURE_PLUGIN, item.text(9))
            assertEquals(
                original + mapOf("stringName" to "My watch", "from" to "phone"),
                DataMapDecoder.decode(item.raw(4)!!),
            )
            assertEquals(listOf("write", "read"), f.events)
            advanceTimeBy(SettingCommands.CONFIRM_TIMEOUT_MS)
            runCurrent()
            assertEquals(WatchNameSync.Result.SUBMITTED, f.results.last())
        }

    @Test
    fun `rename after restart reuses a phone write echoed into the DataItem snapshot`() = runTest {
        val snapshot = WearDataSnapshot()
        val watchFrame =
            WcsFrame.wearPathFrame(
                path = sourceUri,
                dataItems = listOf(DataMapEncoder.encode(original)),
                senderPkg = CompanionProfile.WATCH7.packageName,
                nodeId = "7e57c0de",
                seqId = 41L,
            )
        assertTrue(snapshot.accept(watchFrame.copyOfRange(4, watchFrame.size)))
        val beforeRestart = Fixture(this)
        beforeRestart.receive(original)
        beforeRestart.sync.connect()
        beforeRestart.sync.rename("First name")
        val lastWrite = beforeRestart.frames.single()
        assertTrue(snapshot.accept(lastWrite.copyOfRange(4, lastWrite.size)))
        beforeRestart.sync.disconnect()

        val restored = WearDataSnapshot()
        restored.restore(snapshot.encode())
        val lastItem = WcsFrame.decode(restored.envelopes().single()) as WcsFrame.Incoming.WearPath
        assertEquals("phone", lastItem.dataMap["from"])
        val afterRestart = Fixture(this, initialAlias = "First name")
        afterRestart.receive(lastItem.dataMap, lastItem.path)
        afterRestart.sync.connect()
        assertEquals("First name", afterRestart.writes.single()["stringName"])
        assertTrue(afterRestart.results.isEmpty())
        afterRestart.sync.rename("Second name")
        advanceTimeBy(SettingCommands.CONFIRM_TIMEOUT_MS)
        runCurrent()

        assertEquals(listOf(sourceUri, sourceUri), afterRestart.writtenUris)
        assertEquals(
            original + mapOf("stringName" to "Second name", "from" to "phone"),
            afterRestart.writes.last(),
        )
        assertEquals(
            listOf(WatchNameSync.Result.PENDING, WatchNameSync.Result.SUBMITTED),
            afterRestart.results,
        )
        afterRestart.sync.disconnect()
    }

    @Test
    fun `submitted rename without readback does not report a retry failure or invent confirmation`() =
        runTest {
            val f = Fixture(this)
            f.sync.connect()
            f.receive(original)
            f.sync.rename("My watch")
            assertEquals("My watch", f.writes.single()["stringName"])
            assertEquals(listOf("write", "read"), f.events)

            advanceTimeBy(SettingCommands.CONFIRM_TIMEOUT_MS)
            runCurrent()

            assertFalse(WatchNameSync.Result.CONFIRMED in f.results)
            assertFalse(WatchNameSync.Result.SEND_FAILED in f.results)
            assertEquals(
                listOf(WatchNameSync.Result.PENDING, WatchNameSync.Result.SUBMITTED),
                f.results,
            )
        }

    @Test
    fun `idle startup name is retained and consecutive renames do not need another template`() =
        runTest {
            val f = Fixture(this)
            f.sync.connect()
            f.receive(original)
            f.sync.rename("First name")
            f.sync.rename("Second name")
            assertEquals(listOf("First name", "Second name"), f.writes.map { it["stringName"] })
            assertEquals(listOf("write", "read", "write", "read"), f.events)
            f.receive(original + ("stringName" to "First name"))
            assertFalse(WatchNameSync.Result.CONFIRMED in f.results)
            f.receive(original + ("stringName" to "Second name"))
            assertEquals(WatchNameSync.Result.CONFIRMED, f.results.last())
        }

    @Test
    fun `another owners same path item cannot become a rename template`() = runTest {
        val f = Fixture(this)
        f.receive(original, phoneUri)
        f.sync.connect()
        f.sync.rename("My watch")
        f.receive(original, phoneUri)
        assertTrue(f.writes.isEmpty())
        f.receive(original)
        assertEquals(listOf(sourceUri), f.writtenUris)
        f.sync.disconnect()
    }

    @Test
    fun `reconnect reuses the same watch template while disconnected frames cannot confirm`() =
        runTest {
            val f = Fixture(this)
            f.sync.connect()
            f.receive(original)
            f.sync.rename("My watch")
            f.sync.disconnect()
            f.receive(original + ("stringName" to "My watch"))
            assertFalse(WatchNameSync.Result.CONFIRMED in f.results)
            f.sync.connect()
            assertEquals(listOf(sourceUri, sourceUri), f.writtenUris)
            assertEquals(listOf("write", "read", "write", "read"), f.events)
            f.sync.disconnect()
        }

    @Test
    fun `rename reads then preserves the existing DataMap and waits for matching readback`() =
        runTest {
            val f = Fixture(this)
            f.sync.connect()
            f.sync.rename("My watch")
            assertEquals(listOf("read"), f.events)
            assertTrue(f.writes.isEmpty())

            f.receive(original)
            assertEquals(listOf("read", "write", "read"), f.events)
            val written = f.writes.single()
            assertEquals(original + mapOf("stringName" to "My watch", "from" to "phone"), written)
            assertEquals(written, DataMapDecoder.decode(DataMapEncoder.encode(written)))
            assertEquals(listOf(WatchNameSync.Result.PENDING), f.results)

            f.receive(original)
            f.receive(written)
            assertEquals("My watch", f.name)
            assertEquals(listOf(WatchNameSync.Result.PENDING), f.results)

            f.receive(original + ("stringName" to "My watch"))
            f.receive(original)
            advanceTimeBy(20_000)
            runCurrent()
            assertEquals("My watch", f.name)
            assertEquals(
                listOf(WatchNameSync.Result.PENDING, WatchNameSync.Result.CONFIRMED),
                f.results,
            )
        }

    @Test
    fun `rename preserves source URI through frame encoding while the sender remains the phone`() =
        runTest {
            val f = Fixture(this)
            f.sync.connect()
            f.sync.rename("My watch")
            f.receive(original)

            assertEquals(sourceUri, f.writtenUris.single())
            val frame = f.frames.single()
            val item =
                WcsFrame.decode(frame.copyOfRange(4, frame.size)) as WcsFrame.Incoming.WearPath
            assertEquals(sourceUri, item.path)
            assertEquals("c0ffee12", item.sourceNode)
            assertEquals(
                original + mapOf("stringName" to "My watch", "from" to "phone"),
                item.dataMap,
            )
            f.sync.disconnect()
        }

    @Test
    fun `matching name on another node cannot confirm the modified item`() = runTest {
        val f = Fixture(this)
        f.sync.connect()
        f.sync.rename("My watch")
        f.receive(original)
        val matching = original + ("stringName" to "My watch")
        f.receive(matching, uri = phoneUri)
        assertEquals(listOf(WatchNameSync.Result.PENDING), f.results)
        f.receive(matching)
        assertEquals(WatchNameSync.Result.CONFIRMED, f.results.last())
    }

    @Test
    fun `missing authority or another settings path cannot supply a name item`() = runTest {
        val f = Fixture(this)
        f.sync.connect()
        f.sync.rename("My watch")
        for (uri in
            listOf(
                WcsPaths.SET_INFO_WATCH_NAME,
                "wear://${WcsPaths.SET_INFO_WATCH_NAME}",
                "wear://7e57c0de/w_module_sec_watch_setting/other",
            )) {
            f.receive(original, uri)
        }
        assertTrue(f.writes.isEmpty())
        assertEquals(listOf(WatchNameSync.Result.PENDING), f.results)
        f.receive(original)
        assertEquals(sourceUri, f.writtenUris.single())
        f.sync.disconnect()
    }

    @Test
    fun `reconnect reads the URI afresh instead of reusing the previous item owner`() = runTest {
        val f = Fixture(this, initialAlias = "My watch")
        f.sync.connect()
        f.receive(original)
        f.sync.disconnect()
        val newUri = "wear://ba5eba11${WcsPaths.SET_INFO_WATCH_NAME}"
        f.watchNode = "ba5eba11"
        f.sync.connect()
        f.receive(original)
        assertEquals(listOf(sourceUri), f.writtenUris)
        f.receive(original, uri = newUri)
        assertEquals(listOf(sourceUri, newUri), f.writtenUris)
        f.receive(original + ("stringName" to "My watch"))
        f.sync.disconnect()
    }

    @Test
    fun `even an already matching first read must be written before it can confirm`() = runTest {
        val f = Fixture(this)
        f.sync.connect()
        f.sync.rename("My watch")
        val matching = original + ("stringName" to "My watch")
        f.receive(matching)
        assertEquals(1, f.writes.size)
        assertEquals(listOf(WatchNameSync.Result.PENDING), f.results)
        f.receive(matching)
        assertEquals(WatchNameSync.Result.CONFIRMED, f.results.last())
    }

    @Test
    fun `new rename waits for the previous timeout before changing its feedback`() = runTest {
        val results = CopyOnWriteArrayList<WatchNameSync.Result>()
        val attempted = CountDownLatch(1)
        var pendingDuringOldTimeout = false
        lateinit var renameThread: Thread
        lateinit var sync: WatchNameSync
        sync =
            WatchNameSync(
                this,
                initialAlias = "Saved name",
                watchNode = { "7e57c0de" },
                requestRead = { true },
                write = { _, _ -> true },
                onName = {},
                onResult = results::add,
                onDebug = { message ->
                    if (message.contains("confirmation timeout")) {
                        renameThread =
                            thread(isDaemon = true) {
                                attempted.countDown()
                                sync.rename("New name")
                            }
                        assertTrue(attempted.await(2, TimeUnit.SECONDS))
                        val deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(2)
                        while (
                            renameThread.state != Thread.State.BLOCKED &&
                                System.nanoTime() < deadline
                        ) {
                            Thread.yield()
                        }
                        assertEquals(Thread.State.BLOCKED, renameThread.state)
                        pendingDuringOldTimeout = results.isNotEmpty()
                    }
                },
            )
        sync.connect()
        runCurrent()
        advanceTimeBy(SettingCommands.CONFIRM_TIMEOUT_MS)
        runCurrent()
        renameThread.join(2_000)
        sync.disconnect()
        assertFalse(renameThread.isAlive)
        assertFalse(pendingDuringOldTimeout)
        assertEquals(listOf(WatchNameSync.Result.PENDING), results)
    }

    @Test
    fun `no custom alias imports watch name without writing it back`() = runTest {
        val f = Fixture(this)
        f.sync.connect()
        f.receive(original)
        assertEquals("Old name", f.name)
        f.receive(original + ("stringName" to "Changed on watch"))
        assertEquals("Changed on watch", f.name)
        assertTrue(f.events.isEmpty())
        assertTrue(f.results.isEmpty())
    }

    @Test
    fun `phone origin name item supplies the template but repeated echoes cannot confirm or resend`() =
        runTest {
            val f = Fixture(this)
            f.sync.connect()
            f.sync.rename("My watch")
            val phoneItem = original + ("from" to "phone")
            f.receive(phoneItem)
            assertEquals(listOf("read", "write", "read"), f.events)
            assertEquals(listOf(sourceUri), f.writtenUris)
            val written = f.writes.single()
            assertEquals(phoneItem + ("stringName" to "My watch"), written)
            repeat(3) { f.receive(written) }
            assertEquals(1, f.writes.size)
            assertEquals(listOf(WatchNameSync.Result.PENDING), f.results)
            advanceTimeBy(SettingCommands.CONFIRM_TIMEOUT_MS)
            runCurrent()
            assertEquals(WatchNameSync.Result.SUBMITTED, f.results.last())
            f.sync.disconnect()
        }

    @Test
    fun `phone origin template does not import an unconfirmed watch name`() = runTest {
        val f = Fixture(this)
        f.receive(original + ("from" to "phone"))
        assertEquals("", f.name)
        f.sync.connect()
        assertTrue(f.events.isEmpty())
        f.sync.rename("My watch")
        assertEquals("My watch", f.writes.single()["stringName"])
        assertEquals(listOf("write", "read"), f.events)
        f.sync.disconnect()
    }

    @Test
    fun `malformed names from either origin cannot provide a template or confirm a rename`() =
        runTest {
            val f = Fixture(this)
            f.sync.connect()
            f.sync.rename("My watch")
            for (origin in listOf("phone", "watch")) {
                val item = original + ("from" to origin)
                f.receive(item + ("stringName" to " "))
                f.receive(item + ("stringName" to 1))
                f.receive(item - "stringName")
                f.receive(item + ("key" to "other"))
            }
            assertTrue(f.writes.isEmpty())
            assertEquals("My watch", f.name)
            advanceTimeBy(20_000)
            runCurrent()
            assertEquals(
                listOf(WatchNameSync.Result.PENDING, WatchNameSync.Result.SOURCE_UNAVAILABLE),
                f.results,
            )
        }

    @Test
    fun `missing source item times out and a late read cannot start the write`() = runTest {
        val f = Fixture(this)
        f.sync.connect()
        f.sync.rename("My watch")
        advanceTimeBy(20_000)
        runCurrent()
        f.receive(original)
        assertTrue(f.writes.isEmpty())
        assertEquals("My watch", f.name)
        assertEquals(
            listOf(WatchNameSync.Result.PENDING, WatchNameSync.Result.SOURCE_UNAVAILABLE),
            f.results,
        )
    }

    @Test
    fun `mismatched readback times out without reverting the saved alias or reporting success`() =
        runTest {
            val f = Fixture(this)
            f.sync.connect()
            f.sync.rename("My watch")
            f.receive(original)
            f.receive(original)
            advanceTimeBy(20_000)
            runCurrent()
            f.receive(original + ("stringName" to "My watch"))
            assertEquals("My watch", f.name)
            assertEquals(
                listOf(WatchNameSync.Result.PENDING, WatchNameSync.Result.SUBMITTED),
                f.results,
            )
        }

    @Test
    fun `offline rename stays local and reconnect performs a fresh read modify write`() = runTest {
        val f = Fixture(this)
        f.sync.rename("My watch")
        assertEquals(listOf(WatchNameSync.Result.LOCAL_ONLY), f.results)
        assertTrue(f.events.isEmpty())
        f.sync.connect()
        f.receive(original)
        assertEquals("My watch", f.writes.single()["stringName"])
        f.receive(original + ("stringName" to "My watch"))
        f.sync.disconnect()
        f.sync.connect()
        f.receive(original)
        assertEquals(listOf("read", "write", "read", "write", "read"), f.events)
        assertEquals("My watch", f.name)
        f.sync.disconnect()
    }

    @Test
    fun `restored custom alias survives stale startup readbacks`() = runTest {
        val f = Fixture(this, initialAlias = "My watch")
        f.receive(original)
        f.sync.connect()
        f.receive(original)
        assertEquals("My watch", f.name)
        assertEquals("My watch", f.writes.single()["stringName"])
        f.sync.disconnect()
        f.receive(original)
        assertEquals("My watch", f.name)
        advanceTimeBy(20_000)
        runCurrent()
        assertTrue(f.results.isEmpty())
    }

    @Test
    fun `disconnect cancels both the initial read and the write confirmation`() = runTest {
        for (sourceReceived in listOf(false, true)) {
            val f = Fixture(this)
            f.sync.connect()
            f.sync.rename("My watch")
            if (sourceReceived) f.receive(original)
            f.sync.disconnect()
            val writes = f.writes.size
            f.receive(original)
            f.receive(original + ("stringName" to "My watch"))
            advanceTimeBy(20_000)
            runCurrent()
            assertEquals(writes, f.writes.size)
            assertEquals("My watch", f.name)
            assertEquals(listOf(WatchNameSync.Result.PENDING), f.results)
        }
    }

    @Test
    fun `a newer rename replaces the old read and only its own readback confirms`() = runTest {
        val f = Fixture(this)
        f.sync.connect()
        f.sync.rename("First name")
        f.sync.rename("Second name")
        f.receive(original)
        assertEquals("Second name", f.writes.single()["stringName"])
        f.receive(original + ("stringName" to "First name"))
        assertEquals("Second name", f.name)
        assertFalse(WatchNameSync.Result.CONFIRMED in f.results)
        f.receive(original + ("stringName" to "Second name"))
        advanceTimeBy(20_000)
        runCurrent()
        assertEquals(1, f.results.count { it == WatchNameSync.Result.CONFIRMED })
        assertFalse(WatchNameSync.Result.SUBMITTED in f.results)
    }

    @Test
    fun `a newer rename replaces an outstanding write confirmation`() = runTest {
        val f = Fixture(this)
        f.sync.connect()
        f.sync.rename("First name")
        f.receive(original)
        f.sync.rename("Second name")
        f.receive(original + ("stringName" to "First name"))
        assertEquals(listOf("First name", "Second name"), f.writes.map { it["stringName"] })
        assertFalse(WatchNameSync.Result.CONFIRMED in f.results)
        f.receive(original + ("stringName" to "First name"))
        assertFalse(WatchNameSync.Result.CONFIRMED in f.results)
        f.receive(original + ("stringName" to "Second name"))
        assertEquals("Second name", f.name)
        assertEquals(WatchNameSync.Result.CONFIRMED, f.results.last())
    }

    @Test
    fun `failed reads and writes report send failure and keep the local name`() = runTest {
        for (failRead in listOf(true, false)) {
            val f = Fixture(this)
            f.readSucceeds = !failRead
            f.writeSucceeds = false
            f.sync.connect()
            f.sync.rename("My watch")
            f.receive(original)
            advanceTimeBy(20_000)
            runCurrent()
            assertEquals(if (failRead) 0 else 1, f.writes.size)
            assertEquals("My watch", f.name)
            assertEquals(
                listOf(WatchNameSync.Result.PENDING, WatchNameSync.Result.SEND_FAILED),
                f.results,
            )
        }
    }
}
