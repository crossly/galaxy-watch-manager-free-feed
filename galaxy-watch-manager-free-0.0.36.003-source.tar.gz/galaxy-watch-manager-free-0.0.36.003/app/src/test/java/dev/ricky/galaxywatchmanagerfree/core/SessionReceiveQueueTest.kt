package dev.ricky.galaxywatchmanagerfree.core

import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import org.junit.After
import org.junit.Assert.*
import org.junit.Test

class SessionReceiveQueueTest {
    private val executor = Executors.newSingleThreadExecutor()
    private val producers = Executors.newCachedThreadPool()

    @After
    fun tearDown() {
        producers.shutdownNow()
        executor.shutdownNow()
        assertTrue(producers.awaitTermination(5, TimeUnit.SECONDS))
        assertTrue(executor.awaitTermination(5, TimeUnit.SECONDS))
    }

    @Test
    fun lifecycleAndPacketsKeepTheirOrder() {
        val events = mutableListOf<String>()
        val closed = CountDownLatch(1)
        val queue =
            queue(
                onClosed = {
                    events += "closed"
                    closed.countDown()
                }
            )
        assertTrue(queue.await { events += "connected" })
        assertTrue(queue.submit(4) { events += "packet1" })
        assertTrue(queue.submit(4) { events += "packet2" })
        assertTrue(queue.await { events += "disconnected" })
        queue.close()
        await(closed)
        assertEquals(listOf("connected", "packet1", "packet2", "disconnected", "closed"), events)
    }

    @Test
    fun stoppingDuringSlowPersistenceReturnsAndDiscardsOldDevicePackets() {
        val started = CountDownLatch(1)
        val releaseDisk = CountDownLatch(1)
        val cleaned = CountDownLatch(1)
        val gate = ConnectionRequestGate()
        val request = gate.begin("AA:01")
        val writes = mutableListOf<String>()
        val queue =
            queue(isActive = { gate.isCurrent(request) }, onClosed = { cleaned.countDown() })
        queue.submit(4) {
            started.countDown()
            await(releaseDisk)
            if (gate.isCurrent(request)) writes += "old"
        }
        await(started)
        queue.submit(4) { writes += "queued-old" }
        gate.invalidate()
        queue.close()
        gate.begin("BB:02")
        assertEquals(1L, releaseDisk.count)
        assertEquals(1L, cleaned.count)
        releaseDisk.countDown()
        await(cleaned)
        assertTrue(writes.isEmpty())
        assertFalse(queue.submit { fail("closed session ran a task") })
    }

    @Test
    fun sameDeviceRestoreWaitsForInFlightCommitAndCleanup() {
        val writing = CountDownLatch(1)
        val releaseDisk = CountDownLatch(1)
        val cleaned = CountDownLatch(1)
        val events = mutableListOf<String>()
        val old =
            queue(
                onClosed = {
                    events += "close-old"
                    cleaned.countDown()
                }
            )
        old.submit {
            writing.countDown()
            await(releaseDisk)
            events += "commit-old"
        }
        await(writing)
        old.close()
        val next = queue()
        next.submit { events += "restore-new" }
        releaseDisk.countDown()
        assertTrue(next.await { events += "connected-new" })
        await(cleaned)
        assertEquals(listOf("commit-old", "close-old", "restore-new", "connected-new"), events)
        next.close()
    }

    @Test
    fun byteBudgetIncludesInFlightPacketAndAppliesBackpressure() {
        val started = CountDownLatch(1)
        val releaseDisk = CountDownLatch(1)
        val producerStarted = CountDownLatch(1)
        val producerReturned = CountDownLatch(1)
        val queue = queue(maxBytes = 8)
        queue.submit(8) {
            started.countDown()
            await(releaseDisk)
        }
        await(started)
        val submitted =
            producers.submit<Boolean> {
                producerStarted.countDown()
                queue.submit(1) {}.also { producerReturned.countDown() }
            }
        await(producerStarted)
        assertFalse(producerReturned.await(100, TimeUnit.MILLISECONDS))
        releaseDisk.countDown()
        assertTrue(submitted.get(5, TimeUnit.SECONDS))
        assertTrue(queue.await {})
        queue.close()
    }

    @Test
    fun closeWakesBlockedProducerAndLifecycleWaiter() {
        val started = CountDownLatch(1)
        val releaseDisk = CountDownLatch(1)
        val queue = queue(maxEvents = 2)
        queue.submit {
            started.countDown()
            await(releaseDisk)
        }
        await(started)
        val lifecycleStarted = CountDownLatch(1)
        val waiting =
            producers.submit<Boolean> {
                lifecycleStarted.countDown()
                queue.await { fail("cancelled lifecycle event ran") }
            }
        await(lifecycleStarted)
        val blocked = producers.submit<Boolean> { queue.submit { fail("cancelled packet ran") } }
        queue.close()
        assertFalse(waiting.get(5, TimeUnit.SECONDS))
        assertFalse(blocked.get(5, TimeUnit.SECONDS))
        releaseDisk.countDown()
    }

    @Test
    fun obsoleteGenerationIsCheckedAtExecution() {
        val active = AtomicBoolean(true)
        val started = CountDownLatch(1)
        val release = CountDownLatch(1)
        executor.execute {
            started.countDown()
            await(release)
        }
        await(started)
        val cleaned = CountDownLatch(1)
        val queue = queue(isActive = active::get, onClosed = { cleaned.countDown() })
        queue.submit { fail("stale event ran") }
        active.set(false)
        release.countDown()
        executor.submit {}.get(5, TimeUnit.SECONDS)
        queue.close()
        await(cleaned)
    }

    @Test
    fun failedDecodeClosesQueueAndReleasesLifecycleWaiter() {
        val failed = CountDownLatch(1)
        val cleaned = CountDownLatch(1)
        val queue = queue(onClosed = { cleaned.countDown() }, onFailure = { failed.countDown() })
        assertFalse(queue.await { throw IllegalArgumentException("invalid frame") })
        await(failed)
        await(cleaned)
        assertFalse(queue.submit {})
    }

    @Test
    fun oversizedPacketIsRejectedWithoutAffectingFollowingPackets() {
        val queue = queue(maxBytes = 8)
        assertFalse(queue.submit(9) { fail("oversized packet ran") })
        assertTrue(queue.await {})
        queue.close()
    }

    private fun queue(
        isActive: () -> Boolean = { true },
        onClosed: () -> Unit = {},
        onFailure: (Exception) -> Unit = { throw AssertionError(it) },
        maxBytes: Int = 8,
        maxEvents: Int = 64,
    ) = SessionReceiveQueue(executor, isActive, onClosed, onFailure, maxEvents, maxBytes)

    private fun await(latch: CountDownLatch) {
        assertTrue("Timed out waiting for receive worker", latch.await(5, TimeUnit.SECONDS))
    }
}
