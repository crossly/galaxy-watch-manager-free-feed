package dev.ricky.galaxywatchmanagerfree.feature

import java.time.LocalDate
import java.time.ZoneId
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class HealthSyncRequestPolicyTest {
    private val now =
        LocalDate.of(2026, 11, 2)
            .atTime(12, 0)
            .atZone(ZoneId.systemDefault())
            .toInstant()
            .toEpochMilli()

    @Test
    fun `missing coverage does not pull all historical data on every five minute tick`() {
        val policy = HealthSyncRequestPolicy()
        var fullReads = 0
        repeat(12) { tick ->
            val at = now + tick * 300_000L
            val plan = policy.plan(at, now - 60_000L, needsRecovery = true)
            if (plan.recovery) fullReads++
            policy.onSent(plan, at)
        }
        assertEquals("A missing module must not cause 12 full-history reads per hour", 1, fullReads)
    }

    @Test
    fun `explicit history query preserves its requested window despite missing step coverage`() {
        val start = now - 48 * 3_600_000L
        val plan =
            HealthSyncRequestPolicy()
                .plan(
                    now,
                    now - 60_000L,
                    needsRecovery = true,
                    forceRecovery = true,
                    windowStart = start,
                )
        assertEquals(start, plan.startTime)
        assertEquals(0L, plan.lastSyncTime)
        assertFalse(plan.recovery)
    }

    @Test
    fun `stored recovery attempt survives a new repository without another cold pull`() {
        val plan =
            HealthSyncRequestPolicy(lastRecoveryAt = now - 300_000L)
                .plan(now, now - 60_000L, needsRecovery = true)
        assertFalse(plan.recovery)
        assertEquals(now - 60_000L, plan.startTime)
    }

    @Test
    fun `manual recovery remains available during automatic recovery cooldown`() {
        val plan =
            HealthSyncRequestPolicy(lastRecoveryAt = now - 300_000L)
                .plan(now, now - 60_000L, needsRecovery = true, forceRecovery = true)
        assertTrue(plan.recovery)
        assertEquals(0L, plan.startTime)
    }

    @Test
    fun `recovery retries after one hour and missing coverage stays eligible`() {
        val policy = HealthSyncRequestPolicy(lastRecoveryAt = now)
        assertFalse(policy.plan(now + 3_599_999L, now, needsRecovery = true).recovery)
        assertTrue(policy.plan(now + 3_600_000L, now, needsRecovery = true).recovery)
        assertFalse(policy.plan(now + 3_600_000L, now, needsRecovery = false).recovery)
    }

    @Test
    fun `failed enqueue does not consume automatic recovery allowance`() {
        val policy = HealthSyncRequestPolicy()
        assertTrue(policy.plan(now, 0L, needsRecovery = true).recovery)
        assertTrue(policy.plan(now + 30_000L, 0L, needsRecovery = true).recovery)
    }

    @Test
    fun `without a persisted cursor cooldown requests today rather than all history`() {
        val plan = HealthSyncRequestPolicy(now).plan(now + 300_000L, 0L, needsRecovery = true)
        assertFalse(plan.recovery)
        val today =
            LocalDate.of(2026, 11, 2)
                .atStartOfDay(ZoneId.systemDefault())
                .toInstant()
                .toEpochMilli()
        assertEquals(today, plan.lastSyncTime)
        assertEquals(today, plan.startTime)
    }

    @Test
    fun `midnight and a clock correction cannot lock out recovery`() {
        val midnight =
            LocalDate.of(2026, 11, 3)
                .atStartOfDay(ZoneId.systemDefault())
                .toInstant()
                .toEpochMilli()
        assertTrue(HealthSyncRequestPolicy(midnight - 1_000L).plan(midnight, now, true).recovery)
        assertTrue(HealthSyncRequestPolicy(now + 60_000L).plan(now, now - 60_000L, true).recovery)
    }

    @Test
    fun `real periodic and busy gate chain preserves delta ticks and disabling stops requests`() =
        runTest {
            var requests = 0
            var recoveries = 0
            val policy = HealthSyncRequestPolicy()
            val sync =
                HealthSyncCoordinator(
                    backgroundScope,
                    {
                        val at = now + testScheduler.currentTime
                        val plan = policy.plan(at, now - 60_000L, needsRecovery = true)
                        requests++
                        if (plan.recovery) recoveries++
                        policy.onSent(plan, at)
                        true
                    },
                    {},
                )
            val queries =
                AutoQueryCoordinator(
                    backgroundScope,
                    { error("A background sync must not poll the battery") },
                    { if (sync.request()) sync.onWatchRequest("LOG_DATA") },
                    AutoQueryPolicy(intervalSeconds = 300),
                )
            sync.start()
            queries.start()
            runCurrent()
            advanceTimeBy(3_600_000L)
            runCurrent()
            assertEquals(13, requests)
            assertEquals(1, recoveries)
            queries.configure(AutoQueryPolicy(enabled = false))
            advanceTimeBy(3_600_000L)
            runCurrent()
            assertEquals(13, requests)
            queries.stop()
            sync.stop()
        }
}
