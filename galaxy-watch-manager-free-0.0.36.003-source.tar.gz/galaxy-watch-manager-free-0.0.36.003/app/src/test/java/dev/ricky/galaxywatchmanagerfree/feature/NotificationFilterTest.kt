package dev.ricky.galaxywatchmanagerfree.feature

import org.junit.Assert.*
import org.junit.Test

class NotificationFilterTest {
    private val chat = "example.synthetic.chat"
    private val mail = "example.synthetic.mail"

    @Test
    fun defaultsAllowAllApps() {
        assertTrue(NotificationFilterConfig().allows(chat))
        assertTrue(NotificationFilterConfig().allows(mail))
    }

    @Test
    fun selectedModeMatchesExactPackageNames() {
        val config = NotificationFilterConfig(NotificationFilterMode.SELECTED, setOf(chat))
        assertTrue(config.allows(chat))
        assertFalse(config.allows(mail))
        assertFalse(config.allows("$chat.clone"))
        assertFalse(config.allows(chat.uppercase()))
    }

    @Test
    fun emptySelectionBlocksEveryApp() {
        val config = NotificationFilterConfig(NotificationFilterMode.SELECTED)
        assertFalse(config.allows(chat))
        assertFalse(config.allows(mail))
    }

    @Test
    fun switchingToAllRetainsSelectionButAllowsOtherApps() {
        val selected = NotificationFilterConfig(NotificationFilterMode.SELECTED, setOf(chat))
        val all = selected.copy(mode = NotificationFilterMode.ALL)
        assertTrue(all.allows(mail))
        assertEquals(setOf(chat), all.packages)
        assertFalse(all.copy(mode = NotificationFilterMode.SELECTED).allows(mail))
    }

    @Test
    fun nonemptyLegacyListMigratesToSelectedMode() {
        val config = NotificationFilterConfig.restore(null, emptySet(), setOf(chat))
        assertEquals(NotificationFilterMode.SELECTED, config.mode)
        assertTrue(config.allows(chat))
        assertFalse(config.allows(mail))
    }

    @Test
    fun emptyLegacyListPreservesAllAppsDefault() {
        assertEquals(NotificationFilterConfig(), NotificationFilterConfig.restore(null, emptySet()))
    }

    @Test
    fun savedEmptySelectionDoesNotFallBackToLegacyOrAll() {
        val config = NotificationFilterConfig.restore("SELECTED", emptySet(), setOf(chat))
        assertTrue(config.packages.isEmpty())
        assertFalse(config.allows(chat))
    }

    @Test
    fun savedAllModeIsNotOverwrittenByLegacyList() {
        val config = NotificationFilterConfig.restore("ALL", setOf(chat), setOf(mail))
        assertEquals(setOf(chat), config.packages)
        assertTrue(config.allows(mail))
    }

    @Test
    fun unreadableModeDoesNotEnableUnselectedApps() {
        val config = NotificationFilterConfig.restore("invalid", setOf(chat))
        assertTrue(config.allows(chat))
        assertFalse(config.allows(mail))
    }

    @Test
    fun restoredSelectionDoesNotShareMutableStorageSet() {
        val stored = mutableSetOf(chat)
        val config = NotificationFilterConfig.restore("SELECTED", stored)
        stored.clear()
        assertTrue(config.allows(chat))
    }
}
