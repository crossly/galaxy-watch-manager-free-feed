package dev.ricky.galaxywatchmanagerfree.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AppUpdateTest {

    private val currentName = "0.0.3"
    private val currentCode = 3

    // ---------- 版本比较 ----------

    @Test
    fun `strips v prefix and prerelease suffix`() {
        assertEquals(listOf(0, 0, 4), AppUpdate.versionParts("v0.0.4"))
        assertEquals(listOf(1, 2, 3), AppUpdate.versionParts("V1.2.3-beta.1"))
        assertEquals(listOf(2, 0), AppUpdate.versionParts("2.0+build7"))
        assertEquals(emptyList<Int>(), AppUpdate.versionParts(null))
        assertEquals(emptyList<Int>(), AppUpdate.versionParts("  "))
    }

    @Test
    fun `version code decides when the feed provides one`() {
        val newer = AppUpdate.parseFeed("""{"version_name":"0.0.4","version_code":4}""")!!
        val same = AppUpdate.parseFeed("""{"version_name":"0.0.3","version_code":3}""")!!
        val older = AppUpdate.parseFeed("""{"version_name":"0.0.2","version_code":2}""")!!
        assertTrue(AppUpdate.isNewer(currentName, currentCode, newer))
        assertFalse(AppUpdate.isNewer(currentName, currentCode, same))
        assertFalse(AppUpdate.isNewer(currentName, currentCode, older))
    }

    @Test
    fun `falls back to version names when code is missing`() {
        val newer = AppUpdate.parseFeed("""{"version_name":"v0.1.0"}""")!!
        assertNull(newer.versionCode)
        assertTrue(AppUpdate.isNewer(currentName, currentCode, newer))
        assertFalse(AppUpdate.isNewer("0.1.0", 0, newer))
    }

    @Test
    fun `uneven component counts do not raise false positives`() {
        assertEquals(0, AppUpdate.compareNames("1.0", "1.0.0"))
        assertTrue(AppUpdate.compareNames("1.0", "1.0.1") > 0)
        assertFalse(AppUpdate.compareNames("1.0.1", "1.0") > 0)
    }

    @Test
    fun `nightly names sort between their base and the next stable release`() {
        val versions =
            listOf("0.0.32", "0.0.32.001", "0.0.32.009", "0.0.32.010", "0.0.32.999", "0.0.33")
        versions.zipWithNext().forEach { (older, newer) ->
            assertTrue(AppUpdate.compareNames(older, newer) > 0)
            assertTrue(AppUpdate.compareNames(newer, older) < 0)
        }
        assertEquals(listOf(0, 0, 32, 1), AppUpdate.versionParts("v0.0.32.001"))
    }

    @Test
    fun `legacy stable can upgrade to nightly then to the next stable`() {
        val nightly = release("0.0.32.001", 32001)
        val nextStable = release("0.0.33", 33000)
        assertTrue(AppUpdate.isNewer("0.0.32", 32, nightly))
        assertTrue(AppUpdate.isNewer(nightly.versionName, nightly.versionCode!!, nextStable))
        assertFalse(
            AppUpdate.isNewer(nightly.versionName, nightly.versionCode, release("0.0.32", 32))
        )
        assertFalse(AppUpdate.isNewer("0.0.33", 33000, nightly))
    }

    @Test
    fun `fresh or unknown channel preferences default to stable`() {
        assertEquals(AppUpdate.Channel.STABLE, AppUpdate.Channel.fromPreference(null))
        assertEquals(AppUpdate.Channel.STABLE, AppUpdate.Channel.fromPreference("unknown"))
        assertEquals(AppUpdate.Channel.NIGHTLY, AppUpdate.Channel.fromPreference("nightly"))
        assertEquals("version.json", AppUpdate.Channel.STABLE.feedFile)
        assertEquals("nightly.json", AppUpdate.Channel.NIGHTLY.feedFile)
    }

    @Test
    fun `feed channel is inferred for old feeds and checked when declared`() {
        assertEquals(AppUpdate.Channel.STABLE, release("0.0.32", 32).channel)
        assertEquals(AppUpdate.Channel.NIGHTLY, release("0.0.32.001", 32001).channel)
        assertNull(AppUpdate.parseFeed("""{"version_name":"0.0.32.001","channel":"stable"}"""))
        assertNull(AppUpdate.parseFeed("""{"version_name":"0.0.32","channel":"nightly"}"""))
        assertNull(AppUpdate.parseFeed("""{"version_name":"0.0.32","channel":"other"}"""))
        assertEquals(
            AppUpdate.Channel.NIGHTLY,
            AppUpdate.parseFeed("""{"version_name":"0.0.32.001","channel":"nightly"}""")!!.channel,
        )
    }

    @Test
    fun `stable channel never selects a newer nightly`() {
        val stable = release("0.0.32", 32)
        assertEquals(
            stable,
            AppUpdate.selectRelease(AppUpdate.Channel.STABLE, stable, release("0.0.32.001", 32001)),
        )
    }

    @Test
    fun `nightly channel takes the newest release across both feeds`() {
        val stable = release("0.0.32", 32)
        val nightly = release("0.0.32.002", 32002)
        assertEquals(nightly, AppUpdate.selectRelease(AppUpdate.Channel.NIGHTLY, stable, nightly))
        val nextStable = release("0.0.33", 33000)
        assertEquals(
            nextStable,
            AppUpdate.selectRelease(AppUpdate.Channel.NIGHTLY, nextStable, nightly),
        )
        assertEquals(stable, AppUpdate.selectRelease(AppUpdate.Channel.NIGHTLY, stable, null))
    }

    private fun release(name: String, code: Int) =
        AppUpdate.parseFeed("""{"version_name":"$name","version_code":$code}""")!!

    // ---------- 清单解析 ----------

    @Test
    fun `parses apk url and size when available`() {
        val feed =
            AppUpdate.parseFeed(
                """
            {
              "version_name": "0.0.6",
              "version_code": 6,
              "apk_name": "galaxy-watch-manager-free-0.0.6.apk",
              "apk_size": 14165555,
              "sha256": "AABBCC112233445566778899AABBCCDDEEFF00112233445566778899AABBCCDD",
              "apk_url": "https://raw.githubusercontent.com/crossly/galaxy-watch-manager-free-feed/apk/galaxy-watch-manager-free-0.0.6.apk"
            }
            """
                    .trimIndent()
            )!!
        assertEquals(
            "https://raw.githubusercontent.com/crossly/galaxy-watch-manager-free-feed/apk/galaxy-watch-manager-free-0.0.6.apk",
            feed.apkUrl,
        )
        assertEquals(14165555L, feed.apkSize)
        // 摘要统一小写，便于与本地计算结果直接比较
        assertTrue(feed.sha256!!.startsWith("aabbcc"))
    }

    @Test
    fun `rejects non http apk urls`() {
        val feed =
            AppUpdate.parseFeed(
                """{"version_name":"0.0.6","apk_url":"ftp://example.com/app.apk"}"""
            )!!
        assertNull(feed.apkUrl)
        assertEquals(0L, feed.apkSize)
    }

    private val realFeed =
        """
        {
          "version_name": "0.0.3",
          "version_code": 3,
          "published_at": "2026-10-27T02:51:21Z",
          "page_url": "https://github.com/crossly/galaxy-watch-manager-free/releases/tag/v0.0.3",
          "apk_name": "galaxy-watch-manager-free-0.0.3.apk",
          "sha256": "c5139b0465ec4bd0177a40ecb336afaf6c6acedccb9a926e5c498af3e22e62ca",
          "notes": "健康后台自动同步、健康数据归并修复。"
        }
    """
            .trimIndent()

    @Test
    fun `parses the published feed format`() {
        val info = AppUpdate.parseFeed(realFeed)!!
        assertEquals("0.0.3", info.versionName)
        assertEquals(3, info.versionCode)
        assertEquals("galaxy-watch-manager-free-0.0.3.apk", info.apkName)
        assertEquals(
            "c5139b0465ec4bd0177a40ecb336afaf6c6acedccb9a926e5c498af3e22e62ca",
            info.sha256,
        )
        assertTrue(info.pageUrl!!.endsWith("/v0.0.3"))
        assertFalse(AppUpdate.isNewer("0.0.3", 3, info))
    }

    @Test
    fun `feed without version is rejected`() {
        assertNull(AppUpdate.parseFeed("""{"notes":"n"}"""))
        assertNull(AppUpdate.parseFeed("{}"))
        assertNull(AppUpdate.parseFeed("not json"))
    }

    @Test
    fun `version code alone is enough for a newer feed`() {
        val info = AppUpdate.parseFeed("""{"version_code":9}""")!!
        assertEquals("", info.versionName)
        assertTrue(AppUpdate.isNewer(currentName, currentCode, info))
    }

    @Test
    fun `long notes are capped and blank notes dropped`() {
        val long =
            AppUpdate.parseFeed("""{"version_name":"1.0.0","notes":"${"x".repeat(9000)}"}""")!!
        assertEquals(4000, long.notes!!.length)
        val blank = AppUpdate.parseFeed("""{"version_name":"1.0.0","notes":"   "}""")!!
        assertNull(blank.notes)
    }

    @Test
    fun `auto check options include disabled and default hours`() {
        assertTrue(UpdateChecker.AUTO_HOURS_OPTIONS.contains(UpdateChecker.AUTO_HOURS_DISABLED))
        assertEquals(0, UpdateChecker.AUTO_HOURS_DISABLED)
        assertTrue(UpdateChecker.AUTO_HOURS_OPTIONS.contains(UpdateChecker.DEFAULT_AUTO_HOURS))
        assertEquals(12, UpdateChecker.DEFAULT_AUTO_HOURS)
    }

    @Test
    fun `shouldAutoCheck returns false when disabled`() {
        val now = 1_000_000_000L
        val longAgo = 0L
        assertFalse(UpdateChecker.shouldAutoCheck(UpdateChecker.AUTO_HOURS_DISABLED, longAgo, now))
        assertFalse(UpdateChecker.shouldAutoCheck(-1, longAgo, now))
    }

    @Test
    fun `shouldAutoCheck enforces time interval boundaries`() {
        val now = 24 * 3600_000L
        val hours = 6
        val intervalMs = 6 * 3600_000L

        assertFalse(UpdateChecker.shouldAutoCheck(hours, now - intervalMs + 1L, now))
        assertTrue(UpdateChecker.shouldAutoCheck(hours, now - intervalMs, now))
        assertTrue(UpdateChecker.shouldAutoCheck(hours, now - intervalMs - 1000L, now))
    }
}
