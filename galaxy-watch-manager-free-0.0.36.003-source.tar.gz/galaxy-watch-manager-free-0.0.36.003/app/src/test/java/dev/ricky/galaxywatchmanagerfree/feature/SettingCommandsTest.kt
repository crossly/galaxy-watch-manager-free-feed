package dev.ricky.galaxywatchmanagerfree.feature

import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class SettingCommandsTest {
    @Test
    fun `send sees pending request and an immediate confirmation does not time out`() = runTest {
        val failures = mutableListOf<SettingCommands.Failure>()
        val commands = SettingCommands(this, onError = failures::add)
        val sent =
            commands.submit("psm", true) {
                assertTrue(commands.isPending("psm", true))
                assertTrue(commands.confirm("psm", true))
                true
            }
        assertTrue(sent)
        advanceTimeBy(20_000)
        runCurrent()
        assertFalse(commands.hasPending("psm"))
        assertTrue(failures.isEmpty())
    }

    @Test
    fun `a throwing sender clears pending state and reports failure`() = runTest {
        val failures = mutableListOf<SettingCommands.Failure>()
        val commands = SettingCommands(this, onError = failures::add)
        assertFalse(
            commands.submit("aod", true) { throw IllegalStateException("transport closed") }
        )
        assertFalse(commands.hasPending("aod"))
        assertEquals(listOf(SettingCommands.Failure.SEND_FAILED), failures)
    }

    @Test
    fun `a failed send never leaves an optimistic confirmed value`() = runTest {
        var pending = emptyMap<String, Any>()
        val errors = mutableListOf<SettingCommands.Failure>()
        val commands = SettingCommands(this, { pending = it }, errors::add)
        assertFalse(commands.submit("aod", true) { false })
        assertTrue(pending.isEmpty())
        assertEquals(1, errors.size)
    }

    @Test
    fun `a newer command cancels older retries and only its matching reply confirms`() = runTest {
        val sends = mutableListOf<Boolean>()
        var pending = emptyMap<String, Any>()
        val commands = SettingCommands(this, { pending = it }, {})
        commands.submit("psm", true, retries = 2) {
            sends.add(true)
            true
        }
        runCurrent()
        advanceTimeBy(1_000)
        commands.submit("psm", false, retries = 2) {
            sends.add(false)
            true
        }
        assertFalse(commands.confirm("psm", true))
        assertEquals(false, pending["psm"])
        assertTrue(commands.confirm("psm", false))
        advanceTimeBy(20_000)
        runCurrent()
        assertEquals(listOf(true, false), sends)
        assertTrue(pending.isEmpty())
    }

    @Test
    fun `a setting without unsolicited feedback is confirmed by an explicit read`() = runTest {
        val errors = mutableListOf<SettingCommands.Failure>()
        val events = mutableListOf<String>()
        val commands = SettingCommands(this, onError = errors::add)
        var watchValue = true
        val path = "w_module_sec_watch_setting/display/wake_on_wrist_raised"
        assertTrue(
            commands.submit(
                path,
                false,
                readBack = {
                    events += "read"
                    assertFalse(watchValue)
                    assertTrue(commands.confirm(path, watchValue))
                },
            ) {
                events += "write"
                watchValue = false
                true
            }
        )
        advanceTimeBy(20_000)
        runCurrent()
        assertEquals(listOf("write", "read"), events)
        assertTrue(errors.isEmpty())
        assertFalse(commands.hasPending(path))
    }

    @Test
    fun `a lost read response is requested again after retrying the write`() = runTest {
        val errors = mutableListOf<SettingCommands.Failure>()
        val events = mutableListOf<String>()
        val commands = SettingCommands(this, onError = errors::add)
        var reads = 0
        commands.submit(
            "wrist",
            false,
            retries = 1,
            readBack = {
                events += "read"
                if (++reads == 2) commands.confirm("wrist", false)
            },
        ) {
            events += "write"
            true
        }
        advanceTimeBy(20_000)
        runCurrent()
        assertEquals(listOf("write", "read", "write", "read"), events)
        assertTrue(errors.isEmpty())
        assertFalse(commands.hasPending("wrist"))
    }

    @Test
    fun `failed sends and already confirmed writes do not request a read`() = runTest {
        val commands = SettingCommands(this, onError = {})
        var reads = 0
        assertFalse(commands.submit("failed", false, readBack = { reads++ }) { false })
        assertTrue(
            commands.submit("confirmed", false, readBack = { reads++ }) {
                commands.confirm("confirmed", false)
                true
            }
        )
        advanceTimeBy(20_000)
        runCurrent()
        assertEquals(0, reads)
    }

    @Test
    fun `confirmation callback fires once only for a matching pending value`() = runTest {
        val confirmed = mutableListOf<Pair<String, Any>>()
        val commands =
            SettingCommands(
                this,
                onError = {},
                onConfirmed = { path, value -> confirmed += path to value },
            )
        commands.submit("name", "My watch") { true }
        assertTrue(confirmed.isEmpty())
        assertFalse(commands.confirm("name", "Old name"))
        assertTrue(confirmed.isEmpty())
        assertTrue(commands.confirm("name", "My watch"))
        assertFalse(commands.confirm("name", "My watch"))
        assertEquals(listOf("name" to "My watch"), confirmed)
    }

    @Test
    fun `cleared and timed out requests never report confirmation`() = runTest {
        val confirmed = mutableListOf<String>()
        val commands =
            SettingCommands(this, onError = {}, onConfirmed = { path, _ -> confirmed += path })
        commands.submit("cleared", "My watch") { true }
        commands.clear()
        assertFalse(commands.confirm("cleared", "My watch"))
        commands.submit("expired", "My watch") { true }
        advanceTimeBy(20_000)
        runCurrent()
        assertFalse(commands.confirm("expired", "My watch"))
        assertTrue(confirmed.isEmpty())
    }

    @Test
    fun `queued writes start their confirmation window only after actual send`() = runTest {
        val queue = mutableListOf<() -> Unit>()
        val failures = mutableListOf<SettingCommands.Failure>()
        val commands = SettingCommands(this, onError = failures::add)
        var writes = 0
        assertTrue(
            commands.submit("battery", true, enqueue = { queue.add(it) }) {
                writes++
                true
            }
        )
        advanceTimeBy(12_000)
        runCurrent()
        assertTrue(commands.hasPending("battery"))
        assertEquals(0, writes)
        assertTrue(failures.isEmpty())
        queue.removeAt(0)()
        runCurrent()
        advanceTimeBy(3_999)
        runCurrent()
        assertEquals(1, writes)
        assertTrue(commands.confirm("battery", true))
        advanceTimeBy(10_000)
        runCurrent()
        assertTrue(failures.isEmpty())
    }

    @Test
    fun `queued writes cannot outlive disconnect or a same value replacement`() = runTest {
        val queue = mutableListOf<() -> Unit>()
        val commands = SettingCommands(this, onError = {})
        val writes = mutableListOf<String>()
        fun request(label: String, value: Boolean) =
            commands.submit("battery", value, enqueue = { queue.add(it) }) {
                writes += label
                true
            }
        request("previous connection", true)
        commands.clear()
        request("old true", true)
        request("old false", false)
        request("current true", true)
        queue.forEach { it() }
        assertEquals(listOf("current true"), writes)
        assertTrue(commands.confirm("battery", true))
    }

    @Test
    fun `failed queued writes report send failure and never start confirmation retries`() =
        runTest {
            val queue = mutableListOf<() -> Unit>()
            val failures = mutableListOf<SettingCommands.Failure>()
            val commands = SettingCommands(this, onError = failures::add)
            assertTrue(
                commands.submit("battery", true, retries = 2, enqueue = { queue.add(it) }) { false }
            )
            queue.single()()
            advanceTimeBy(20_000)
            runCurrent()
            assertEquals(listOf(SettingCommands.Failure.SEND_FAILED), failures)
            assertFalse(commands.hasPending("battery"))
            assertEquals(1, queue.size)
        }

    @Test
    fun `disconnect cancels all pending writes and retry jobs`() = runTest {
        val sends = mutableListOf<Boolean>()
        val commands = SettingCommands(this, {}, {})
        commands.submit("psm", true, retries = 2) {
            sends.add(true)
            true
        }
        commands.clear()
        advanceTimeBy(20_000)
        runCurrent()
        assertEquals(listOf(true), sends)
    }
}
