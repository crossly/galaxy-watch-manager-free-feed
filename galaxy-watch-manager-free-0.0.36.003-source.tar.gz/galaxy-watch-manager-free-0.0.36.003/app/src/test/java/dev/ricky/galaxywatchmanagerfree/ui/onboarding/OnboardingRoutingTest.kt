package dev.ricky.galaxywatchmanagerfree.ui.onboarding

import dev.ricky.galaxywatchmanagerfree.ui.screens.connection.BondedWatch
import org.junit.Assert.assertEquals
import org.junit.Test

class OnboardingRoutingTest {
    private val watch6 = BondedWatch("Galaxy Watch6", "00:11:22:33:44:55")
    private val ultra = BondedWatch("Galaxy Watch Ultra", "00:11:22:33:44:66")
    private val earbuds = BondedWatch("Galaxy Buds2 Pro", "00:11:22:33:44:77")

    @Test
    fun explicitSelectionSurvivesWhileTheDeviceIsStillBonded() {
        assertEquals(
            "00:11:22:33:44:66",
            resolveSelectedMac(listOf(watch6, ultra), "00:11:22:33:44:66"),
        )
    }

    @Test
    fun explicitSelectionMatchesRegardlessOfCaseAndKeepsTheBondedSpelling() {
        val upper = BondedWatch("Galaxy Watch6", "AA:BB:CC:DD:EE:FF")
        assertEquals("AA:BB:CC:DD:EE:FF", resolveSelectedMac(listOf(upper), "aa:bb:cc:dd:ee:ff"))
    }

    @Test
    fun staleSavedAddressFallsBackToTheBestScoredWatch() {
        assertEquals(
            "00:11:22:33:44:55",
            resolveSelectedMac(listOf(earbuds, watch6, ultra), "00:11:22:33:44:99"),
        )
    }

    @Test
    fun staleSavedAddressIsNeverReusedWhenTheSelectionIsUnbonded() {
        assertEquals("", resolveSelectedMac(listOf(earbuds), "00:11:22:33:44:55"))
    }

    @Test
    fun earbudOnlyBondListYieldsNoSelection() {
        assertEquals("", resolveSelectedMac(listOf(earbuds), ""))
    }

    @Test
    fun emptyBondListYieldsNoSelection() {
        assertEquals("", resolveSelectedMac(emptyList(), "00:11:22:33:44:55"))
    }

    @Test
    fun blankSelectionPicksTheBestScoredWatch() {
        assertEquals("00:11:22:33:44:55", resolveSelectedMac(listOf(earbuds, watch6, ultra), ""))
    }

    @Test
    fun missingPermissionOutranksEveryOtherCheckOutcome() {
        assertEquals(
            OnboardingCheckAction.GRANT_PERMISSION,
            resolveCheckAction(
                permissionMissing = true,
                bluetoothUnavailable = true,
                hasGoogleWear = false,
                wearEnabled = false,
                hasBondedDevices = false,
                hasSelectedWatch = false,
            ),
        )
    }

    @Test
    fun inaccessibleBluetoothOutranksEnvironmentChecks() {
        assertEquals(
            OnboardingCheckAction.OPEN_BLUETOOTH,
            resolveCheckAction(
                permissionMissing = false,
                bluetoothUnavailable = true,
                hasGoogleWear = true,
                wearEnabled = true,
                hasBondedDevices = true,
                hasSelectedWatch = true,
            ),
        )
    }

    @Test
    fun absentGoogleWearSendsTheUserToThePairingGuideEvenWithASelectedWatch() {
        assertEquals(
            OnboardingCheckAction.SHOW_PAIRING_GUIDE,
            resolveCheckAction(
                permissionMissing = false,
                bluetoothUnavailable = false,
                hasGoogleWear = false,
                wearEnabled = false,
                hasBondedDevices = true,
                hasSelectedWatch = true,
            ),
        )
    }

    @Test
    fun disabledGoogleWearOffersItsAppDetails() {
        assertEquals(
            OnboardingCheckAction.OPEN_WEAR_DETAILS,
            resolveCheckAction(
                permissionMissing = false,
                bluetoothUnavailable = false,
                hasGoogleWear = true,
                wearEnabled = false,
                hasBondedDevices = true,
                hasSelectedWatch = true,
            ),
        )
    }

    @Test
    fun noBondedDeviceSendsTheUserToThePairingGuide() {
        assertEquals(
            OnboardingCheckAction.SHOW_PAIRING_GUIDE,
            resolveCheckAction(
                permissionMissing = false,
                bluetoothUnavailable = false,
                hasGoogleWear = true,
                wearEnabled = true,
                hasBondedDevices = false,
                hasSelectedWatch = false,
            ),
        )
    }

    @Test
    fun bondedDevicesWithoutASelectionAskForAWatch() {
        assertEquals(
            OnboardingCheckAction.SELECT_WATCH,
            resolveCheckAction(
                permissionMissing = false,
                bluetoothUnavailable = false,
                hasGoogleWear = true,
                wearEnabled = true,
                hasBondedDevices = true,
                hasSelectedWatch = false,
            ),
        )
    }

    @Test
    fun satisfiedEnvironmentContinues() {
        assertEquals(
            OnboardingCheckAction.CONTINUE,
            resolveCheckAction(
                permissionMissing = false,
                bluetoothUnavailable = false,
                hasGoogleWear = true,
                wearEnabled = true,
                hasBondedDevices = true,
                hasSelectedWatch = true,
            ),
        )
    }

    @Test
    fun readyConnectionReopensOnTheDoneStep() {
        assertEquals(
            OnboardingStep.DONE,
            initialOnboardingStep(
                ready = true,
                handoverPreparing = false,
                hasPendingIdentity = false,
                hasConfirmedIdentity = true,
            ),
        )
    }

    @Test
    fun preparedHandoverResumesOnTheReleaseStep() {
        assertEquals(
            OnboardingStep.RELEASE,
            initialOnboardingStep(
                ready = false,
                handoverPreparing = true,
                hasPendingIdentity = true,
                hasConfirmedIdentity = false,
            ),
        )
    }

    @Test
    fun stagedButUnpausedIdentityStillResumesOnTheReleaseStep() {
        assertEquals(
            OnboardingStep.RELEASE,
            initialOnboardingStep(
                ready = false,
                handoverPreparing = false,
                hasPendingIdentity = true,
                hasConfirmedIdentity = false,
            ),
        )
    }

    @Test
    fun confirmedIdentityResumesOnTheConnectStep() {
        assertEquals(
            OnboardingStep.CONNECT,
            initialOnboardingStep(
                ready = false,
                handoverPreparing = false,
                hasPendingIdentity = false,
                hasConfirmedIdentity = true,
            ),
        )
    }

    @Test
    fun noIdentityStartsAtTheEnvironmentCheck() {
        assertEquals(
            OnboardingStep.CHECK,
            initialOnboardingStep(
                ready = false,
                handoverPreparing = false,
                hasPendingIdentity = false,
                hasConfirmedIdentity = false,
            ),
        )
    }

    @Test
    fun readyOutranksAStaleHandoverPreparation() {
        assertEquals(
            OnboardingStep.DONE,
            initialOnboardingStep(
                ready = true,
                handoverPreparing = true,
                hasPendingIdentity = true,
                hasConfirmedIdentity = true,
            ),
        )
    }

    @Test
    fun checkAndInstallShareTheFirstStepIndicator() {
        assertEquals(0, stepIndex(OnboardingStep.CHECK))
        assertEquals(0, stepIndex(OnboardingStep.INSTALL))
        assertEquals(1, stepIndex(OnboardingStep.IDENTITY))
        assertEquals(2, stepIndex(OnboardingStep.RELEASE))
        assertEquals(3, stepIndex(OnboardingStep.CONNECT))
        assertEquals(4, stepIndex(OnboardingStep.DONE))
    }
}
