package dev.ricky.galaxywatchmanagerfree.feature

import org.junit.Assert.*
import org.junit.Test

class DeviceScopeTest {
    @Test
    fun `health records and legacy migration belong to exactly one device`() {
        val first = "AA:BB:CC:DD:EE:01"
        val other = "AA:BB:CC:DD:EE:02"
        assertNotEquals(
            DeviceScope.preferences("health", first),
            DeviceScope.preferences("health", other),
        )
        assertEquals(
            DeviceScope.preferences("health", first),
            DeviceScope.preferences("health", first.lowercase()),
        )
        assertTrue(DeviceScope.canImportLegacy(first, first.lowercase()))
        assertFalse(DeviceScope.canImportLegacy(other, first))
        assertFalse(DeviceScope.canImportLegacy(first, null))
        assertFalse(DeviceScope.canImportLegacy(null, null))
    }
}
