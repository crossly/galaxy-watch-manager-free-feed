package dev.ricky.galaxywatchmanagerfree.wcs

import org.junit.Assert.*
import org.junit.Test

class HealthChannelReceiverTest {
    private val id = 0x1dc2065d5fcef575L

    private fun open() =
        Proto.bytes(
            2,
            Proto.integer(1, 1) +
                Proto.fixed64(2, id) +
                Proto.integer(3, 1) +
                Proto.string(4, "com.samsung.android.wear.shealth") +
                Proto.string(5, WcsPaths.SIGNATURE_PLUGIN) +
                Proto.string(6, "/samsung_health/wearable_message/123"),
        )

    private fun data(sequence: Long, text: String, last: Boolean) =
        Proto.bytes(
            3,
            Proto.bytes(
                1,
                Proto.fixed64(1, id) + Proto.integer(2, 1) + Proto.integer(3, sequence),
            ) + Proto.string(2, text) + Proto.integer(3, if (last) 1 else 0),
        )

    @Test
    fun `fixed64 preserves every channel id bit`() {
        for (v in listOf(id, -1L, Long.MIN_VALUE, 0L)) assertEquals(
            v,
            Proto.parse(Proto.fixed64(2, v)).num(2),
        )
    }

    @Test
    fun `opens and assembles data once while acknowledging retransmissions`() {
        val replies = mutableListOf<ByteArray>()
        val deliveries = mutableListOf<String>()
        val receiver =
            HealthChannelReceiver(
                {
                    replies.add(it)
                    true
                },
                { _, b -> deliveries.add(String(b)) },
                {},
            )
        receiver.receive(open())
        assertEquals(2L, Proto.parse(replies.last()).nested(2)?.num(1))
        assertEquals(id, Proto.parse(replies.last()).nested(2)?.num(2))
        receiver.receive(data(0, "hello ", false))
        receiver.receive(data(0, "hello ", false))
        receiver.receive(data(1, "world", true))
        receiver.receive(data(1, "world", true))
        assertEquals(listOf("hello world"), deliveries)
        val ack = Proto.parse(replies.last()).nested(4)!!
        assertEquals(1L, ack.num(2))
        assertEquals(1L, ack.nested(1)?.num(3))
        assertEquals(0L, ack.nested(1)?.num(2))
    }

    @Test
    fun `monitor channel explicitly accepts its package and discards partial data on reconnect`() {
        val deliveries = mutableListOf<ByteArray>()
        val receiver =
            HealthChannelReceiver(
                { true },
                { _, b -> deliveries.add(b) },
                {},
                accepts = { path, pkg ->
                    path == "/992d" && pkg == "com.samsung.android.shealthmonitor"
                },
            )
        val monitorOpen =
            Proto.bytes(
                2,
                Proto.integer(1, 1) +
                    Proto.fixed64(2, id) +
                    Proto.string(4, "com.samsung.android.shealthmonitor") +
                    Proto.string(6, "/992d"),
            )
        receiver.receive(open())
        receiver.receive(data(0, "wrong package", true))
        assertTrue(deliveries.isEmpty())
        receiver.receive(monitorOpen)
        receiver.receive(data(0, "partial", false))
        receiver.reset()
        receiver.receive(data(1, "old tail", true))
        assertTrue(deliveries.isEmpty())
        receiver.receive(monitorOpen)
        receiver.receive(data(0, "complete", true))
        assertEquals("complete", String(deliveries.single()))
    }

    @Test
    fun `unknown and out of order chunks cannot be delivered`() {
        val deliveries = mutableListOf<ByteArray>()
        val receiver = HealthChannelReceiver({ true }, { _, b -> deliveries.add(b) }, {})
        receiver.receive(data(0, "orphan", true))
        receiver.receive(open())
        receiver.receive(data(1, "gap", true))
        assertTrue(deliveries.isEmpty())
    }
}
