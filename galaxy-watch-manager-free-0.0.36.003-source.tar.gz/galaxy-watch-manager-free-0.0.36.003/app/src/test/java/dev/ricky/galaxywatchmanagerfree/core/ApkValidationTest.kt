package dev.ricky.galaxywatchmanagerfree.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class ApkValidationTest {
    private val digest = "a".repeat(64)
    private val current = ApkValidation.PackageIdentity("dev.ricky.test", 9, setOf("release-cert"))
    private val archive = ApkValidation.PackageIdentity("dev.ricky.test", 10, setOf("release-cert"))
    private val release =
        AppUpdate.ReleaseInfo(
            "0.0.10",
            10,
            null,
            null,
            null,
            "app.apk",
            digest,
            "https://example.com/app.apk",
            1024,
        )

    @Test
    fun `only the same application newer version and verified bytes are accepted`() {
        val verified = ApkValidation.verify(release, current, archive, 1024, digest)
        assertEquals(10L, verified.versionCode)
    }

    @Test
    fun `missing trusted metadata never skips a validation step`() {
        assertThrows(IllegalArgumentException::class.java) {
            ApkValidation.verify(release.copy(sha256 = null), current, archive, 1024, digest)
        }
        assertThrows(IllegalArgumentException::class.java) {
            ApkValidation.verify(release, current.copy(signers = emptySet()), archive, 1024, digest)
        }
        assertThrows(IllegalArgumentException::class.java) {
            ApkValidation.verify(release.copy(apkSize = 0), current, archive, 1024, digest)
        }
    }

    @Test
    fun `a signed archive must still match the announced package and version`() {
        listOf(
                archive.copy(packageName = "dev.ricky.other"),
                archive.copy(versionCode = 9),
                archive.copy(versionCode = 11),
                archive.copy(signers = setOf("unrelated-cert")),
                archive.copy(signers = emptySet()),
                archive.copy(signers = setOf("release-cert", "unrelated-cert")),
            )
            .forEach { wrong ->
                assertThrows(IllegalArgumentException::class.java) {
                    ApkValidation.verify(release, current, wrong, 1024, digest)
                }
            }
        assertThrows(IllegalArgumentException::class.java) {
            ApkValidation.verify(release, current, archive, 1000, digest)
        }
        assertThrows(IllegalArgumentException::class.java) {
            ApkValidation.verify(release, current, archive, 1024, "b".repeat(64))
        }
    }
}
