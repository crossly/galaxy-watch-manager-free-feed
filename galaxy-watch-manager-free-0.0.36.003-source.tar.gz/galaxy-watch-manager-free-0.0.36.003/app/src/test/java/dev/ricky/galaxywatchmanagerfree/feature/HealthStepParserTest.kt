package dev.ricky.galaxywatchmanagerfree.feature

import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 步数解析/累计逻辑的单元测试。
 *
 * 这些用例直接复刻实机抓到的报文结构（见 research/HEALTH-PROTOCOL.md 8.1 / 8.2）， 用来锁死「界面只显示连接后步数」这个回归。
 */
class HealthStepParserTest {

    private val zone: ZoneId = ZoneId.of("Asia/Shanghai")
    private val now: Long =
        ZonedDateTime.of(LocalDate.of(2026, 3, 18), java.time.LocalTime.of(14, 30), zone)
            .toInstant()
            .toEpochMilli()

    private fun todayAt(hour: Int, minute: Int): Long =
        ZonedDateTime.of(LocalDate.of(2026, 3, 18), java.time.LocalTime.of(hour, minute), zone)
            .toInstant()
            .toEpochMilli()

    private fun yesterdayAt(hour: Int): Long =
        ZonedDateTime.of(LocalDate.of(2026, 3, 17), java.time.LocalTime.of(hour, 0), zone)
            .toInstant()
            .toEpochMilli()

    // ---------- 全天汇总 ----------

    @Test
    fun `day summary uses step_count when present`() {
        val o = JSONObject("""{"step_count":612,"run_step_count":147,"walk_step_count":333}""")
        assertEquals(612, HealthStepParser.daySummarySteps(o))
    }

    @Test
    fun `day summary falls back to run plus walk (real captured payload)`() {
        // 实机抓包样本：只有 run/walk 两个字段，没有 step_count
        val o =
            JSONObject(
                """
            {"datauuid":"6f748919-b265-4c6b-b820-2688d779cf0a",
             "run_step_count":147,"walk_step_count":333,
             "update_time":1792801220038,"healthy_step":0,"recommendation":6000,
             "distance":507.39752197265625,"pkg_name":"com.sec.android.app.shealth",
             "deviceuuid":"VfS0qUERdZ"}
            """
                    .trimIndent()
            )
        assertEquals(480, HealthStepParser.daySummarySteps(o))
    }

    @Test
    fun `day summary falls back to binning buckets`() {
        val bins =
            JSONArray()
                .put(JSONObject("""{"index":0,"steps":1}"""))
                .put(JSONObject("""{"index":3,"steps":14}"""))
                .put(JSONObject("""{"index":445,"steps":4}"""))
        val o = JSONObject().put("binning_data", bins)
        assertEquals(19, HealthStepParser.daySummarySteps(o))
    }

    @Test
    fun `day summary returns minus one when nothing usable`() {
        assertEquals(-1, HealthStepParser.daySummarySteps(JSONObject("""{"calorie":1.2}""")))
    }

    @Test
    fun `latest day summary prefers today and newest`() {
        val old = JSONObject().put("day_time", yesterdayAt(20)).put("step_count", 9999)
        val morning = JSONObject().put("day_time", todayAt(8, 0)).put("step_count", 120)
        val noon = JSONObject().put("day_time", todayAt(12, 0)).put("step_count", 480)
        val picked = HealthStepParser.latestDaySummary(listOf(old, morning, noon), now, zone)
        assertEquals(480, HealthStepParser.daySummarySteps(picked!!))
    }

    @Test
    fun `latest day summary returns null for empty input`() {
        assertNull(HealthStepParser.latestDaySummary(emptyList(), now, zone))
    }

    @Test
    fun `latest day summary parses basic ISO and epoch millisecond day times`() {
        val basic =
            JSONObject()
                .put("datauuid", "basic")
                .put("day_time", 20260318)
                .put("update_time", todayAt(12, 0))
                .put("step_count", 480)
        val epoch =
            JSONObject()
                .put("datauuid", "epoch")
                .put("day_time", todayAt(0, 0))
                .put("update_time", todayAt(13, 0))
                .put("step_count", 612)

        val iso =
            JSONObject()
                .put("datauuid", "iso")
                .put("day_time", "2026-03-18")
                .put("update_time", todayAt(13, 30))
                .put("step_count", 700)

        assertEquals(
            480,
            HealthStepParser.daySummarySteps(
                HealthStepParser.latestDaySummary(listOf(basic), now, zone)!!
            ),
        )
        assertEquals(
            612,
            HealthStepParser.daySummarySteps(
                HealthStepParser.latestDaySummary(listOf(epoch), now, zone)!!
            ),
        )
        assertEquals(
            700,
            HealthStepParser.daySummarySteps(
                HealthStepParser.latestDaySummary(listOf(iso), now, zone)!!
            ),
        )
    }

    @Test
    fun `historical summary updated today is not presented as today`() {
        val old =
            JSONObject()
                .put("datauuid", "old")
                .put("day_time", 20260317)
                .put("update_time", todayAt(9, 0))
                .put("step_count", 9999)
        val undated =
            JSONObject()
                .put("datauuid", "undated")
                .put("update_time", todayAt(10, 0))
                .put("step_count", 7777)
        assertNull(HealthStepParser.latestDaySummary(listOf(old, undated), now, zone))
    }

    @Test
    fun `yesterday summary is not presented as today`() {
        val old = JSONObject().put("day_time", yesterdayAt(20)).put("step_count", 9999)
        assertNull(HealthStepParser.latestDaySummary(listOf(old), now, zone))
    }

    @Test
    fun `explicit zero summary is valid`() {
        assertEquals(0, HealthStepParser.daySummarySteps(JSONObject().put("step_count", 0)))
    }

    @Test
    fun `old interval updated today is not counted today`() {
        val old =
            JSONObject()
                .put("datauuid", "old")
                .put("count", 500)
                .put("start_time", yesterdayAt(21))
                .put("update_time", todayAt(9, 0))
        assertEquals(0, HealthStepParser.accumulate(0, linkedSetOf(), listOf(old), now, zone).total)
    }

    // ---------- 区间记录 ----------

    @Test
    fun `record steps reads short and long count keys`() {
        assertEquals(37, HealthStepParser.recordSteps(JSONObject("""{"count":37}""")))
        assertEquals(
            37,
            HealthStepParser.recordSteps(
                JSONObject("""{"com.samsung.health.step_count.count":37}""")
            ),
        )
    }

    @Test
    fun `record steps falls back to run plus walk`() {
        val o = JSONObject("""{"run_step":10,"walk_step":4}""")
        assertEquals(14, HealthStepParser.recordSteps(o))
    }

    @Test
    fun `accumulate sums interval deltas instead of taking the latest`() {
        // 关键回归：三条区间记录必须相加成 40，而不是只显示最后一条的 15
        val records =
            listOf(
                JSONObject()
                    .put("datauuid", "a")
                    .put("count", 10)
                    .put("update_time", todayAt(10, 0)),
                JSONObject()
                    .put("datauuid", "b")
                    .put("count", 15)
                    .put("update_time", todayAt(10, 10)),
                JSONObject()
                    .put("datauuid", "c")
                    .put("count", 15)
                    .put("update_time", todayAt(10, 20)),
            )
        val seen = linkedSetOf<String>()
        val acc = HealthStepParser.accumulate(0, seen, records, now, zone)
        assertEquals(40, acc.total)
        assertEquals(40, acc.added)
        assertEquals(3, acc.acceptedRecords)
    }

    @Test
    fun `accumulate deduplicates resent records`() {
        val records =
            listOf(
                JSONObject()
                    .put("datauuid", "a")
                    .put("count", 10)
                    .put("update_time", todayAt(10, 0))
            )
        val seen = linkedSetOf<String>()
        val first = HealthStepParser.accumulate(0, seen, records, now, zone)
        assertEquals(10, first.total)
        // 手表重发同一批记录：不重复计入
        val second = HealthStepParser.accumulate(first.total, seen, records, now, zone)
        assertEquals(10, second.total)
        assertEquals(0, second.added)
        assertEquals(0, second.acceptedRecords)
    }

    @Test
    fun `accumulate ignores records from previous days`() {
        val records =
            listOf(
                JSONObject()
                    .put("datauuid", "old")
                    .put("count", 500)
                    .put("update_time", yesterdayAt(21)),
                JSONObject()
                    .put("datauuid", "new")
                    .put("count", 12)
                    .put("update_time", todayAt(9, 0)),
            )
        val seen = linkedSetOf<String>()
        val acc = HealthStepParser.accumulate(0, seen, records, now, zone)
        assertEquals(12, acc.total)
        assertTrue(seen.contains("new"))
        assertTrue(!seen.contains("old"))
    }

    @Test
    fun `accumulate keeps growing across multiple syncs`() {
        val seen = linkedSetOf<String>()
        var total = 0
        total =
            HealthStepParser.accumulate(
                    total,
                    seen,
                    listOf(
                        JSONObject()
                            .put("datauuid", "a")
                            .put("count", 30)
                            .put("update_time", todayAt(9, 0))
                    ),
                    now,
                    zone,
                )
                .total
        total =
            HealthStepParser.accumulate(
                    total,
                    seen,
                    listOf(
                        JSONObject()
                            .put("datauuid", "a")
                            .put("count", 30)
                            .put("update_time", todayAt(9, 0)),
                        JSONObject()
                            .put("datauuid", "b")
                            .put("count", 25)
                            .put("update_time", todayAt(9, 30)),
                    ),
                    now,
                    zone,
                )
                .total
        assertEquals(55, total)
    }

    @Test
    fun `identity falls back to time triple when uuid missing`() {
        val o =
            JSONObject().put("start_time", 1000L).put("end_time", 2000L).put("update_time", 3000L)
        assertEquals("t_1000_2000_3000", HealthStepParser.recordIdentity(o))
    }

    @Test
    fun `identity prefers long-form uuid`() {
        val o = JSONObject().put("com.samsung.health.step_count.datauuid", "uuid-x")
        assertEquals("uuid-x", HealthStepParser.recordIdentity(o))
    }

    // ---------- 最终展示值 ----------

    @Test
    fun `resolve prefers day summary over small session delta`() {
        // 手表全天 612 步，本次会话只走了 40 步 → 必须显示 612
        assertEquals(
            612,
            HealthStepParser.resolveSteps(daySummary = 612, accumulated = 40, displayed = 40),
        )
    }

    @Test
    fun `resolve uses accumulation when no day summary`() {
        assertEquals(
            40,
            HealthStepParser.resolveSteps(daySummary = -1, accumulated = 40, displayed = -1),
        )
    }

    @Test
    fun `resolve never regresses below displayed value`() {
        assertEquals(
            480,
            HealthStepParser.resolveSteps(daySummary = 300, accumulated = 120, displayed = 480),
        )
    }

    @Test
    fun `resolve returns minus one when nothing known`() {
        assertEquals(-1, HealthStepParser.resolveSteps(-1, 0, -1))
    }

    @Test
    fun `summary seeds accumulator so later deltas keep counting`() {
        // 场景：连接后先收到全天汇总 612 步，之后又走了 20 步
        var acc = 0
        var displayed = -1
        acc = HealthStepParser.seedAccumulator(acc, 612)
        displayed = HealthStepParser.resolveSteps(612, acc, displayed)
        assertEquals(612, displayed)

        val seen = linkedSetOf<String>()
        val acc2 =
            HealthStepParser.accumulate(
                    acc,
                    seen,
                    listOf(
                        JSONObject()
                            .put("datauuid", "n1")
                            .put("count", 20)
                            .put("update_time", todayAt(14, 0))
                    ),
                    now,
                    zone,
                )
                .total
        assertEquals(632, acc2)
        // 本次报文没有 day_summary（-1），展示值仍应推进到 632
        displayed = HealthStepParser.resolveSteps(-1, acc2, displayed)
        assertEquals(632, displayed)
    }

    @Test
    fun `seed accumulator never lowers an already larger value`() {
        assertEquals(700, HealthStepParser.seedAccumulator(700, 612))
        assertEquals(612, HealthStepParser.seedAccumulator(0, 612))
        assertEquals(50, HealthStepParser.seedAccumulator(50, -1))
    }

    @Test
    fun `summary and covered intervals in one batch are not double counted`() {
        val seen = linkedSetOf<String>()
        val summary = JSONObject().put("step_count", 612).put("update_time", todayAt(12, 0))
        val records =
            listOf(
                JSONObject()
                    .put("datauuid", "a")
                    .put("count", 40)
                    .put("end_time", todayAt(11, 50))
                    .put("update_time", todayAt(12, 5))
            )
        val result = HealthStepParser.mergeBatch(0, seen, records, summary, 0, now, zone)
        assertEquals(612, result.total)
        assertEquals(0, result.added)
        assertTrue(seen.contains("a"))
    }

    @Test
    fun `late delivery before summary is ignored but subsequent walking is counted`() {
        val seen = linkedSetOf<String>()
        val summary = JSONObject().put("step_count", 612).put("update_time", todayAt(12, 0))
        val first = HealthStepParser.mergeBatch(0, seen, emptyList(), summary, 0, now, zone)
        val records =
            listOf(
                JSONObject()
                    .put("datauuid", "old")
                    .put("count", 40)
                    .put("end_time", todayAt(11, 0)),
                JSONObject().put("datauuid", "new").put("count", 20).put("end_time", todayAt(13, 0)),
            )
        val second =
            HealthStepParser.mergeBatch(
                first.total,
                seen,
                records,
                null,
                first.summaryThroughMillis,
                now,
                zone,
            )
        assertEquals(632, second.total)
        val replay =
            HealthStepParser.mergeBatch(
                second.total,
                seen,
                records,
                null,
                second.summaryThroughMillis,
                now,
                zone,
            )
        assertEquals(632, replay.total)
    }

    @Test
    fun `zero is retained as a valid daily display value`() {
        assertEquals(0, HealthStepParser.resolveSteps(0, 0, -1))
        assertEquals(0, HealthStepParser.resolveSteps(-1, 0, 0))
    }

    @Test
    fun `summary with same day_time chooses the most recently updated row`() {
        val old =
            JSONObject()
                .put("day_time", todayAt(0, 0))
                .put("update_time", todayAt(8, 0))
                .put("step_count", 100)
        val newer =
            JSONObject()
                .put("day_time", todayAt(0, 0))
                .put("update_time", todayAt(12, 0))
                .put("step_count", 480)
        val picked = HealthStepParser.latestDaySummary(listOf(old, newer), now, zone)
        assertEquals(480, HealthStepParser.daySummarySteps(picked!!))
    }

    @Test
    fun `trim seen records keeps newest entries`() {
        val seen = LinkedHashSet<String>()
        repeat(900) { seen.add("id$it") }
        HealthStepParser.trimSeen(seen)
        assertEquals(400, seen.size)
        assertTrue(seen.contains("id899"))
        assertTrue(!seen.contains("id0"))
    }
}
