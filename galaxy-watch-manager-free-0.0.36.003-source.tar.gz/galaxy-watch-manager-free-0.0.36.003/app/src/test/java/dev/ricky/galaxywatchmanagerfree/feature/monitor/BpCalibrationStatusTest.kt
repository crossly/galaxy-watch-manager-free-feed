package dev.ricky.galaxywatchmanagerfree.feature.monitor

import java.util.Calendar
import org.junit.Assert.assertEquals
import org.junit.Test

class BpCalibrationStatusTest {
    @Test
    fun `missing information fails closed to unknown or needs calibration`() {
        assertEquals(BpCalibrationStatus.State.UNKNOWN, BpCalibrationStatus.from(null, 1_000L))
        assertEquals(
            BpCalibrationStatus.State.UNKNOWN,
            BpCalibrationStatus.from("not-json", 1_000L),
        )
        assertEquals(
            BpCalibrationStatus.State.REQUIRED,
            BpCalibrationStatus.from("""{"tnc":true}""", 1_000L),
        )
    }

    @Test
    fun `terms and unavailable service are reported before calibration time`() {
        assertEquals(
            BpCalibrationStatus.State.SERVICE_UNAVAILABLE,
            BpCalibrationStatus.from(
                """{"tnc":true,"is_service_available":"false","calibration_time":1}""",
                1_000L,
            ),
        )
        assertEquals(
            BpCalibrationStatus.State.TERMS_REQUIRED,
            BpCalibrationStatus.from("""{"tnc":false,"calibration_time":1}""", 1_000L),
        )
    }

    @Test
    fun `expiry follows Samsung local midnight plus 28 calendar days`() {
        val calendar = Calendar.getInstance()
        calendar.set(2026, Calendar.MARCH, 1, 15, 30, 0)
        calendar.set(Calendar.MILLISECOND, 500)
        val calibratedAt = calendar.timeInMillis
        val expiry = BpCalibrationStatus.expiryTime(calibratedAt)!!
        calendar.timeInMillis = calibratedAt
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        calendar.set(Calendar.MILLISECOND, 0)
        calendar.add(Calendar.DAY_OF_YEAR, 28)
        assertEquals(calendar.timeInMillis, expiry)
        val json =
            """{"tnc":true,"is_service_available":"true","calibration_time":$calibratedAt,"need_to_recal":false}"""
        assertEquals(BpCalibrationStatus.State.CURRENT, BpCalibrationStatus.from(json, expiry - 1L))
        assertEquals(BpCalibrationStatus.State.EXPIRED, BpCalibrationStatus.from(json, expiry))
        assertEquals(BpCalibrationStatus.State.EXPIRED, BpCalibrationStatus.from(json, expiry + 1L))
    }

    @Test
    fun `algorithm requested recalibration overrides a current date`() {
        val time = System.currentTimeMillis()
        assertEquals(
            BpCalibrationStatus.State.REQUIRED,
            BpCalibrationStatus.from(
                """{"tnc":true,"calibration_time":$time,"need_to_recal":true}""",
                time,
            ),
        )
    }
}
