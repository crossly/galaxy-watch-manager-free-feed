package dev.ricky.galaxywatchmanagerfree.feature

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test

class LocalSleepAnalyzerLogTest {
    @Test
    fun `completion keeps only category status and elapsed time`() {
        assertEquals("[睡眠分析] 状态=完成 耗时=321ms", sleepAnalysisLog("完成", 321))
    }

    @Test
    fun `failure records the exception category without vendor payload`() {
        val error =
            IllegalStateException(
                "vendor payload datauuid=synthetic-sleep-record asleepMinutes=421 efficiency=93.5"
            )
        val message = sleepAnalysisLog("暂不可用", 87, error)

        assertEquals("[睡眠分析] 状态=暂不可用 类别=IllegalStateException 耗时=87ms", message)
        assertFalse(message.contains("synthetic-sleep-record"))
        assertFalse(message.contains("421"))
        assertFalse(message.contains("93.5"))
    }
}
