package dev.ricky.galaxywatchmanagerfree.feature

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class HealthSyncCoordinatorTest {
    @Test
    fun `session readiness alone does not create another polling loop`() = runTest {
        var sent = 0
        val statuses = mutableListOf<HealthSyncCoordinator.Status>()
        val sync =
            HealthSyncCoordinator(
                backgroundScope,
                {
                    sent++
                    true
                },
                statuses::add,
            )
        sync.start()
        advanceTimeBy(900_000)
        runCurrent()
        assertEquals(0, sent)
        assertEquals(HealthSyncCoordinator.Status.WAITING, statuses.last())
        assertTrue(sync.request())
        sync.onWatchRequest("LOG_DATA")
        assertEquals(HealthSyncCoordinator.Status.IDLE, statuses.last())
        sync.stop()
    }

    @Test
    fun `manual periodic and recovery requests share one busy gate`() = runTest {
        var regular = 0
        var recovery = 0
        val sync =
            HealthSyncCoordinator(
                backgroundScope,
                {
                    regular++
                    true
                },
                {},
            )
        sync.start()
        assertTrue(sync.request())
        assertFalse(
            sync.request {
                recovery++
                true
            }
        )
        assertEquals(0, recovery)
        sync.onWatchRequest("LOG_DATA")
        assertTrue(
            sync.request {
                recovery++
                true
            }
        )
        assertFalse(sync.request())
        assertEquals(1, regular)
        assertEquals(1, recovery)
        sync.stop()
    }

    @Test
    fun `vascular history waits for the active sync and completes only after its own response`() =
        runTest {
            val state = MutableStateFlow(WatchState(vascularLoadSupported = true))
            var backfills = 0
            val sync =
                HealthSyncCoordinator(
                    backgroundScope,
                    { true },
                    { status -> state.update { it.copy(healthSyncStatus = status) } },
                )
            sync.start()
            assertTrue(sync.request())
            val backfill =
                backgroundScope.async {
                    syncVascularLoadHistory(state) {
                        sync.request {
                            backfills++
                            true
                        }
                    }
                }
            runCurrent()
            assertTrue("The busy gate must defer history recovery", backfill.isActive)
            assertEquals(0, backfills)
            sync.onWatchRequest("LOG_DATA")
            runCurrent()
            assertEquals(1, backfills)
            assertTrue("Queue acceptance does not prove history recovery", backfill.isActive)
            sync.onWatchRequest("LOG_DATA")
            runCurrent()
            assertTrue(backfill.await())
            sync.stop()
        }

    @Test
    fun `vascular history aborts when support is withdrawn while waiting`() = runTest {
        val state = MutableStateFlow(WatchState(vascularLoadSupported = true))
        var backfills = 0
        val sync =
            HealthSyncCoordinator(
                backgroundScope,
                { true },
                { status -> state.update { it.copy(healthSyncStatus = status) } },
            )
        sync.start()
        sync.request()
        val backfill =
            backgroundScope.async {
                syncVascularLoadHistory(state) {
                    backfills++
                    false
                }
            }
        runCurrent()
        state.update { it.copy(vascularLoadSupported = false) }
        runCurrent()
        assertFalse(backfill.await())
        sync.onWatchRequest("LOG_DATA")
        runCurrent()
        assertEquals(0, backfills)
        sync.stop()
    }

    @Test
    fun `interrupted vascular history is never marked recovered`() = runTest {
        for (disconnect in listOf(false, true)) {
            val state = MutableStateFlow(WatchState(vascularLoadSupported = true))
            val sync =
                HealthSyncCoordinator(
                    backgroundScope,
                    { true },
                    { status -> state.update { it.copy(healthSyncStatus = status) } },
                )
            sync.start()
            val backfill =
                backgroundScope.async { syncVascularLoadHistory(state) { sync.request() } }
            runCurrent()
            assertTrue(backfill.isActive)
            if (disconnect) sync.stop() else advanceTimeBy(HealthSyncCoordinator.TIMEOUT_MS + 1)
            runCurrent()
            assertFalse(backfill.await())
            sync.stop()
        }
    }

    @Test
    fun `vascular history stops after enqueue rejection without claiming recovery`() = runTest {
        val state = MutableStateFlow(WatchState(vascularLoadSupported = true))
        val sync =
            HealthSyncCoordinator(
                backgroundScope,
                { false },
                { status -> state.update { it.copy(healthSyncStatus = status) } },
            )
        sync.start()
        val backfill = backgroundScope.async { syncVascularLoadHistory(state) { sync.request() } }
        runCurrent()
        assertFalse("A rejected request must finish the backfill attempt", backfill.isActive)
        assertFalse(backfill.await())
        assertEquals(HealthSyncCoordinator.Status.TIMED_OUT, state.value.healthSyncStatus)
        sync.stop()
    }

    @Test
    fun `vascular history can start after the preceding sync timed out`() = runTest {
        val state = MutableStateFlow(WatchState(vascularLoadSupported = true))
        var requests = 0
        val sync =
            HealthSyncCoordinator(
                backgroundScope,
                {
                    requests++
                    true
                },
                { status -> state.update { it.copy(healthSyncStatus = status) } },
            )
        sync.start()
        sync.request()
        advanceTimeBy(HealthSyncCoordinator.TIMEOUT_MS + 1)
        runCurrent()
        val backfill = backgroundScope.async { syncVascularLoadHistory(state) { sync.request() } }
        runCurrent()
        assertEquals(2, requests)
        assertTrue(backfill.isActive)
        sync.onWatchRequest("LOG_DATA")
        runCurrent()
        assertTrue(backfill.await())
        sync.stop()
    }

    @Test
    fun `request exceptions retain category without logging the payload`() = runTest {
        val logs = mutableListOf<String>()
        val statuses = mutableListOf<HealthSyncCoordinator.Status>()
        val sync =
            HealthSyncCoordinator(
                backgroundScope,
                { throw IllegalStateException("synthetic private health record") },
                statuses::add,
                logs::add,
            )
        sync.start()
        assertFalse(sync.request())
        assertEquals(HealthSyncCoordinator.Status.TIMED_OUT, statuses.last())
        assertTrue(logs.any { it.contains("IllegalStateException") })
        assertTrue(logs.none { it.contains("synthetic private health record") })
        sync.stop()
    }

    @Test
    fun `request cancellation propagates and releases the busy gate`() = runTest {
        val sync = HealthSyncCoordinator(backgroundScope, { true }, {})
        sync.start()
        assertThrows(CancellationException::class.java) {
            sync.request { throw CancellationException("synthetic cancellation") }
        }
        assertTrue(sync.request())
        sync.stop()
    }

    @Test
    fun `disconnect rejects requests and reconnect reopens the busy gate`() = runTest {
        var sent = 0
        val sync =
            HealthSyncCoordinator(
                backgroundScope,
                {
                    sent++
                    true
                },
                {},
            )
        sync.start()
        assertTrue(sync.request())
        sync.stop()
        assertFalse(sync.request())
        sync.start()
        sync.start()
        assertTrue(sync.request())
        assertEquals(2, sent)
        sync.stop()
    }

    @Test
    fun `timeout releases manual retry without pretending sync succeeded`() = runTest {
        val statuses = mutableListOf<HealthSyncCoordinator.Status>()
        val sync = HealthSyncCoordinator(backgroundScope, { true }, statuses::add)
        sync.start()
        sync.request()
        runCurrent()
        advanceTimeBy(HealthSyncCoordinator.TIMEOUT_MS)
        runCurrent()
        assertEquals(HealthSyncCoordinator.Status.TIMED_OUT, statuses.last())
        assertTrue(sync.request())
        sync.stop()
    }

    @Test
    fun `watch initiated chunks suppress queries and extend timeout`() = runTest {
        var sent = 0
        val statuses = mutableListOf<HealthSyncCoordinator.Status>()
        val sync =
            HealthSyncCoordinator(
                backgroundScope,
                {
                    sent++
                    true
                },
                statuses::add,
            )
        sync.start()
        sync.onWatchRequest("SYNC_DATA")
        advanceTimeBy(50_000)
        sync.onWatchRequest("SYNC_DATA")
        advanceTimeBy(20_000)
        runCurrent()
        assertFalse(sync.request())
        assertEquals(0, sent)
        assertEquals(HealthSyncCoordinator.Status.SYNCING, statuses.last())
        sync.onWatchRequest("LOG_DATA")
        assertTrue(sync.request())
        sync.stop()
    }

    @Test
    fun `queue rejection allows retry and never reports completion`() = runTest {
        var accepts = false
        val statuses = mutableListOf<HealthSyncCoordinator.Status>()
        val sync = HealthSyncCoordinator(backgroundScope, { accepts }, statuses::add)
        sync.start()
        assertFalse(sync.request())
        assertEquals(HealthSyncCoordinator.Status.TIMED_OUT, statuses.last())
        accepts = true
        assertTrue(sync.request())
        assertEquals(HealthSyncCoordinator.Status.SYNCING, statuses.last())
        sync.stop()
    }

    @Test
    fun `completion cancels timeout and disconnect ignores late packets`() = runTest {
        val statuses = mutableListOf<HealthSyncCoordinator.Status>()
        val sync = HealthSyncCoordinator(backgroundScope, { true }, statuses::add)
        sync.start()
        sync.request()
        sync.onWatchRequest("LOG_DATA")
        advanceTimeBy(HealthSyncCoordinator.TIMEOUT_MS + 1)
        runCurrent()
        assertEquals(HealthSyncCoordinator.Status.IDLE, statuses.last())
        sync.stop()
        sync.onWatchRequest("SYNC_DATA")
        advanceTimeBy(120_000)
        runCurrent()
        assertEquals(HealthSyncCoordinator.Status.DISCONNECTED, statuses.last())
    }
}
