package dev.ricky.galaxywatchmanagerfree.feature.handover

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class HandoverJournalTest {

    @Test
    fun `allowlist is exact and excludes health apps`() {
        assertEquals(
            listOf(
                "com.google.android.wearable.app.cn",
                "com.google.android.wearable.app",
                "com.samsung.android.waterplugin",
                "com.samsung.android.heartplugin",
                "com.samsung.wearable.watch6plugin",
                "com.samsung.wearable.watch7plugin",
                "com.samsung.android.app.watchmanager",
            ),
            OfficialCompanionApp.packageNames,
        )
        assertTrue(OfficialCompanionApp.isAllowed("com.samsung.android.app.watchmanager"))
        assertFalse(OfficialCompanionApp.isAllowed("com.sec.android.app.shealth"))
        assertFalse(OfficialCompanionApp.isAllowed("com.samsung.android.shealthmonitor"))
        assertFalse(OfficialCompanionApp.isAllowed("com.samsung.android.app.watchmanager.extra"))
        assertFalse(OfficialCompanionApp.isAllowed("com.google.android.wearable.app.cn.extra"))
        assertFalse(OfficialCompanionApp.isAllowed("com.samsung.wearable.watch4plugin"))
        assertFalse(OfficialCompanionApp.isAllowed("com.samsung.wearable.watch5plugin"))
    }

    @Test
    fun `older watch plugins use exact official package names`() {
        val plugins =
            mapOf(
                "com.samsung.android.waterplugin" to OfficialCompanionApp.WATCH4_PLUGIN,
                "com.samsung.android.heartplugin" to OfficialCompanionApp.WATCH5_PLUGIN,
                "com.samsung.wearable.watch6plugin" to OfficialCompanionApp.WATCH6_PLUGIN,
            )

        for ((packageName, app) in plugins) {
            assertTrue(OfficialCompanionApp.isAllowed(packageName))
            assertEquals(app, OfficialCompanionApp.find(packageName))
            assertFalse(OfficialCompanionApp.isAllowed("$packageName.extra"))
            assertFalse(OfficialCompanionApp.isAllowed("extra.$packageName"))
            assertFalse(OfficialCompanionApp.isAllowed(packageName.uppercase()))
            assertNull(OfficialCompanionApp.find("$packageName.extra"))
        }
    }

    @Test
    fun `older plugin restore points survive retries and journal round trips`() {
        val packages =
            listOf(
                "com.samsung.android.waterplugin",
                "com.samsung.android.heartplugin",
                "com.samsung.wearable.watch6plugin",
            )

        for (packageName in packages) {
            for (original in listOf(EnabledState.DEFAULT, EnabledState.ENABLED)) {
                val journal = HandoverJournal().snapshot(mapOf(packageName to original))
                val retried =
                    journal
                        .snapshot(mapOf(packageName to EnabledState.DISABLED_USER))
                        .snapshot(mapOf(packageName to EnabledState.ENABLED))
                val decoded = HandoverJournal.decode(retried.encode())

                assertEquals(mapOf(packageName to original), decoded.originalStates)
                assertEquals(
                    original,
                    HandoverPolicy.restoreTarget(
                        decoded.originalStates[packageName],
                        EnabledState.DISABLED_USER,
                    ),
                )
                assertTrue(decoded.without(setOf(packageName)).isEmpty)
            }
        }
    }

    @Test
    fun `older plugin snapshots exclude disabled and unknown states`() {
        for (state in
            listOf(
                EnabledState.DISABLED,
                EnabledState.DISABLED_USER,
                EnabledState.DISABLED_UNTIL_USED,
                EnabledState.UNKNOWN,
            )) {
            val observed =
                mapOf(
                    "com.samsung.android.waterplugin" to state,
                    "com.samsung.android.heartplugin" to state,
                    "com.samsung.wearable.watch6plugin" to state,
                )

            assertTrue(HandoverJournal().snapshot(observed).isEmpty)
        }
    }

    @Test
    fun `snapshot records only allowlisted apps that would actually change`() {
        val journal =
            HandoverJournal()
                .snapshot(
                    mapOf(
                        "com.google.android.wearable.app.cn" to EnabledState.DEFAULT,
                        "com.samsung.android.app.watchmanager" to EnabledState.ENABLED,
                        "com.samsung.wearable.watch7plugin" to EnabledState.DISABLED_USER,
                        "com.google.android.wearable.app" to EnabledState.DISABLED,
                        "com.sec.android.app.shealth" to EnabledState.ENABLED,
                    )
                )

        assertEquals(
            mapOf(
                "com.google.android.wearable.app.cn" to EnabledState.DEFAULT,
                "com.samsung.android.app.watchmanager" to EnabledState.ENABLED,
            ),
            journal.originalStates,
        )
    }

    @Test
    fun `repeat snapshot never overwrites the true original state`() {
        val first =
            HandoverJournal()
                .snapshot(mapOf("com.google.android.wearable.app" to EnabledState.DEFAULT))
        val second =
            first.snapshot(
                mapOf(
                    "com.google.android.wearable.app" to EnabledState.ENABLED,
                    "com.samsung.wearable.watch7plugin" to EnabledState.DEFAULT,
                )
            )

        assertEquals(EnabledState.DEFAULT, second.originalStates["com.google.android.wearable.app"])
        assertEquals(
            EnabledState.DEFAULT,
            second.originalStates["com.samsung.wearable.watch7plugin"],
        )
    }

    @Test
    fun `encoding round trips deterministically`() {
        val journal =
            HandoverJournal()
                .snapshot(
                    mapOf(
                        "com.samsung.android.app.watchmanager" to EnabledState.ENABLED,
                        "com.google.android.wearable.app.cn" to EnabledState.DEFAULT,
                    )
                )
        val encoded = journal.encode()

        assertEquals(
            "com.google.android.wearable.app.cn|0\n" + "com.samsung.android.app.watchmanager|1",
            encoded,
        )
        assertEquals(journal.originalStates, HandoverJournal.decode(encoded).originalStates)
    }

    @Test
    fun `decoding ignores unknown packages malformed lines and impossible states`() {
        val raw =
            """
            com.google.android.wearable.app.cn|0
            not a journal line
            com.sec.android.app.shealth|0
            com.samsung.android.shealthmonitor|1

            com.samsung.android.app.watchmanager|3
            com.samsung.wearable.watch7plugin|9
            com.google.android.wearable.app|1
            com.google.android.wearable.app|0
            """
                .trimIndent()

        val decoded = HandoverJournal.decode(raw)

        assertEquals(
            mapOf(
                "com.google.android.wearable.app.cn" to EnabledState.DEFAULT,
                "com.google.android.wearable.app" to EnabledState.ENABLED,
            ),
            decoded.originalStates,
        )
    }

    @Test
    fun `without removes only restored packages`() {
        val journal =
            HandoverJournal()
                .snapshot(
                    mapOf(
                        "com.google.android.wearable.app.cn" to EnabledState.DEFAULT,
                        "com.samsung.android.app.watchmanager" to EnabledState.ENABLED,
                    )
                )

        val remaining = journal.without(setOf("com.google.android.wearable.app.cn"))

        assertEquals(setOf("com.samsung.android.app.watchmanager"), remaining.packages)
        assertFalse(remaining.isEmpty)
        assertTrue(journal.without(journal.packages).isEmpty)
    }

    @Test
    fun `enabled state policy matches shell restrictions`() {
        assertTrue(HandoverPolicy.isEnabled(EnabledState.DEFAULT))
        assertTrue(HandoverPolicy.isEnabled(EnabledState.ENABLED))
        assertFalse(HandoverPolicy.isEnabled(EnabledState.DISABLED_USER))
        assertFalse(HandoverPolicy.isEnabled(EnabledState.DISABLED))
        assertFalse(HandoverPolicy.isEnabled(EnabledState.DISABLED_UNTIL_USED))

        assertTrue(HandoverPolicy.canSet(EnabledState.DEFAULT))
        assertTrue(HandoverPolicy.canSet(EnabledState.ENABLED))
        assertTrue(HandoverPolicy.canSet(EnabledState.DISABLED_USER))
        assertFalse(HandoverPolicy.canSet(EnabledState.DISABLED))
        assertFalse(HandoverPolicy.canSet(EnabledState.DISABLED_UNTIL_USED))
        assertFalse(HandoverPolicy.canSet(EnabledState.UNKNOWN))

        assertEquals(EnabledState.DISABLED_USER, HandoverPolicy.DISABLE_TARGET)
    }

    @Test
    fun `missing snapshot still restores a disabled app to default`() {
        val empty = HandoverJournal()

        assertTrue(empty.originalStates.isEmpty())
        assertTrue(HandoverPolicy.needsRestore(EnabledState.DISABLED_USER))
        assertTrue(HandoverPolicy.needsRestore(EnabledState.DISABLED))
        assertTrue(HandoverPolicy.needsRestore(EnabledState.DISABLED_UNTIL_USED))
        assertFalse(HandoverPolicy.needsRestore(EnabledState.DEFAULT))
        assertFalse(HandoverPolicy.needsRestore(EnabledState.UNKNOWN))
        assertEquals(
            EnabledState.DEFAULT,
            HandoverPolicy.restoreTarget(null, EnabledState.DISABLED_USER),
        )
        assertEquals(
            EnabledState.ENABLED,
            HandoverPolicy.restoreTarget(EnabledState.ENABLED, EnabledState.DISABLED_USER),
        )
        assertNull(HandoverPolicy.restoreTarget(null, EnabledState.DEFAULT))
    }
}
