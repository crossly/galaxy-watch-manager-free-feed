package dev.ricky.galaxywatchmanagerfree.feature

import java.io.ByteArrayOutputStream
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.util.Base64
import java.util.zip.GZIPOutputStream
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SleepParserTest {

    private val zone: ZoneId = ZoneId.of("Asia/Shanghai")
    private val night = LocalDate.of(2026, 10, 27)

    private fun millisOf(hour: Int, minute: Int, dayOffset: Int = -1): Long =
        LocalDateTime.of(night.plusDays(dayOffset.toLong()), java.time.LocalTime.of(hour, minute))
            .atZone(zone)
            .toInstant()
            .toEpochMilli()

    private fun blob(samples: List<Pair<Long, Int>>): String {
        val array = JSONArray()
        samples.forEach { (start, code) ->
            array.put(JSONObject().put("startTime", start).put("status", code))
        }
        val bos = ByteArrayOutputStream()
        GZIPOutputStream(bos).use { it.write(array.toString().toByteArray(Charsets.UTF_8)) }
        return Base64.getEncoder().encodeToString(bos.toByteArray())
    }

    /** 23:00 入睡 → 07:00 起床：浅睡/深睡/REM/清醒 交替 */
    private fun sleepRecord(start: Long, end: Long, extra: JSONObject.() -> Unit = {}): JSONObject =
        JSONObject()
            .put("datauuid", "sleep-uuid-1")
            .put("start_time", start)
            .put("end_time", end)
            .apply(extra)

    private fun dataRecord(start: Long, samples: List<Pair<Long, Int>>): JSONObject =
        JSONObject()
            .put("sleep_uuid", "sleep-uuid-1")
            .put("start_time", start)
            .put("json_version", 2)
            .put("sleep_status", blob(samples))

    @Test
    fun `oversized nested sleep payload is rejected before stage parsing`() {
        val start = millisOf(23, 0)
        val json =
            " ".repeat(8 * 1024 * 1024) +
                """[
            {"startTime":$start,"status":40002},
            {"startTime":${start + 60_000},"status":40001}
        ]"""
        val compressed =
            ByteArrayOutputStream().also { out ->
                GZIPOutputStream(out).use { it.write(json.toByteArray()) }
            }
        assertTrue(
            SleepParser.decodeStatusBlob(
                    Base64.getEncoder().encodeToString(compressed.toByteArray())
                )
                .isEmpty()
        )
    }

    @Test
    fun `missing stages preserve interval boundaries without extending sleep`() {
        val start = millisOf(23, 0)
        val segments =
            SleepParser.segmentsFromSamples(
                listOf(
                    start to SleepParser.CODE_LIGHT,
                    start + 60_000 to SleepParser.CODE_GAP,
                    start + 120_000 to SleepParser.CODE_DEEP,
                    start + 180_000 to SleepParser.CODE_LATENCY,
                    start + 240_000 to 99999,
                    start + 300_000 to SleepParser.CODE_AWAKE,
                )
            )
        assertEquals(
            listOf(
                SleepParser.Segment(start, start + 60_000, SleepParser.Stage.LIGHT),
                SleepParser.Segment(start + 120_000, start + 180_000, SleepParser.Stage.DEEP),
            ),
            segments,
        )
    }

    private val samples =
        listOf(
            millisOf(23, 0) to SleepParser.CODE_AWAKE,
            millisOf(23, 20) to SleepParser.CODE_LIGHT,
            millisOf(0, 40, 0) to SleepParser.CODE_DEEP,
            millisOf(1, 40, 0) to SleepParser.CODE_LIGHT,
            millisOf(3, 10, 0) to SleepParser.CODE_REM,
            millisOf(3, 50, 0) to SleepParser.CODE_LIGHT,
            millisOf(5, 30, 0) to SleepParser.CODE_DEEP,
            millisOf(6, 30, 0) to SleepParser.CODE_REM,
            millisOf(7, 0, 0) to SleepParser.CODE_AWAKE,
        )

    @Test
    fun `stage codes follow Samsung SleepStageType`() {
        assertEquals(SleepParser.Stage.AWAKE, SleepParser.stageOf(40001))
        assertEquals(SleepParser.Stage.LIGHT, SleepParser.stageOf(40002))
        assertEquals(SleepParser.Stage.DEEP, SleepParser.stageOf(40003))
        assertEquals(SleepParser.Stage.REM, SleepParser.stageOf(40004))
        assertNull(SleepParser.stageOf(40005)) // 入睡潜伏不进图表
        assertNull(SleepParser.stageOf(40006)) // 缺测间断同理
        assertNull(SleepParser.stageOf(0))
    }

    @Test
    fun `samples become contiguous segments and merge same stages`() {
        val segments =
            SleepParser.segmentsFromSamples(
                listOf(1000L to 40002, 2000L to 40002, 3000L to 40003, 4000L to 40001)
            )
        // 最后一个样本没有后续样本，区间长度为 0，不产生分期
        assertEquals(2, segments.size)
        assertEquals(1000L, segments[0].startMillis)
        assertEquals(3000L, segments[0].endMillis)
        assertEquals(SleepParser.Stage.LIGHT, segments[0].stage)
        assertEquals(SleepParser.Stage.DEEP, segments[1].stage)
        assertEquals(4000L, segments[1].endMillis)
    }

    @Test
    fun `invalid samples are ignored`() {
        assertTrue(SleepParser.segmentsFromSamples(listOf(0L to 40002, -5L to 40003)).isEmpty())
        assertTrue(SleepParser.segmentsFromSamples(listOf(1000L to 99999)).isEmpty())
    }

    @Test
    fun `sleep_status blob decodes into stages`() {
        val segments = SleepParser.decodeStatusBlob(blob(samples))
        assertTrue(segments.isNotEmpty())
        assertEquals(SleepParser.Stage.AWAKE, segments.first().stage)
        assertEquals(millisOf(23, 0), segments.first().startMillis)
        assertEquals(millisOf(7, 0, 0), segments.last().endMillis)
    }

    @Test
    fun `broken blob yields no segments instead of crashing`() {
        assertTrue(SleepParser.decodeStatusBlob("not-base64!!").isEmpty())
        assertTrue(
            SleepParser.decodeStatusBlob(Base64.getEncoder().encodeToString("plain".toByteArray()))
                .isEmpty()
        )
    }

    @Test
    fun `session merges record window with stage segments`() {
        val session =
            SleepParser.sessions(
                    listOf(sleepRecord(millisOf(23, 0), millisOf(7, 0, 0))),
                    listOf(dataRecord(millisOf(23, 0), samples)),
                )
                .single()

        assertEquals(millisOf(23, 0), session.startMillis)
        assertEquals(millisOf(7, 0, 0), session.endMillis)
        assertEquals(480, session.inBedMinutes)
        // 23:20→07:00 是睡眠，23:00→23:20 是清醒
        assertEquals(460, session.asleepMinutes)
        assertEquals(96, session.efficiencyPercent)
        assertEquals(120, session.stageMinutes[SleepParser.Stage.DEEP]) // 00:40–01:40 + 05:30–06:30
        assertEquals(270, session.stageMinutes[SleepParser.Stage.LIGHT])
        assertEquals(70, session.stageMinutes[SleepParser.Stage.REM]) // 03:10–03:50 + 06:30–07:00
        assertEquals(20, session.stageMinutes[SleepParser.Stage.AWAKE])
    }

    @Test
    fun `watch provided efficiency and quality win over derived values`() {
        val session =
            SleepParser.sessions(
                    listOf(
                        sleepRecord(millisOf(23, 0), millisOf(7, 0, 0)) {
                            put("efficiency", 91)
                            put("quality", 78)
                        }
                    ),
                    listOf(dataRecord(millisOf(23, 0), samples)),
                )
                .single()
        assertEquals(91, session.efficiency)
        assertEquals(78, session.score)
    }

    @Test
    fun `stage rows with start and end times are supported`() {
        val stages =
            listOf(
                JSONObject()
                    .put("start_time", millisOf(23, 0))
                    .put("end_time", millisOf(23, 30))
                    .put("status", 40002),
                JSONObject()
                    .put("start_time", millisOf(23, 30))
                    .put("end_time", millisOf(1, 0, 0))
                    .put("stage", 40003),
            )
        val parsed = SleepParser.parseStageRecords(stages)
        assertEquals(2, parsed.size)
        assertEquals(SleepParser.Stage.LIGHT, parsed[0].stage)
        assertEquals(30, (parsed[0].durationMillis / 60_000L).toInt())
        assertEquals(SleepParser.Stage.DEEP, parsed[1].stage)
    }

    @Test
    fun `legacy long field names are accepted`() {
        val record =
            JSONObject()
                .put("com.samsung.health.sleep.start_time", millisOf(23, 0))
                .put("com.samsung.health.sleep.end_time", millisOf(6, 0, 0))
                .put("efficiency", 88)
        val session = SleepParser.sessions(listOf(record)).single()
        assertEquals(millisOf(23, 0), session.startMillis)
        assertEquals(88, session.efficiencyPercent)
        assertTrue(session.segments.isEmpty())
    }

    @Test
    fun `segments alone still produce a session`() {
        val session =
            SleepParser.sessions(emptyList(), listOf(dataRecord(millisOf(23, 0), samples))).single()
        assertEquals(480, session.inBedMinutes)
        assertNull(session.score)
    }

    @Test
    fun `latest session picks the most recent night only`() {
        val old =
            SleepParser.sessions(listOf(sleepRecord(millisOf(23, 0, -3), millisOf(7, 0, -2))))
                .single()
        val fresh =
            SleepParser.sessions(listOf(sleepRecord(millisOf(23, 0), millisOf(7, 0, 0)))).single()
        assertEquals(fresh, SleepParser.latestSession(listOf(old, fresh), millisOf(20, 0, -1)))
        assertNull(SleepParser.latestSession(listOf(old), millisOf(20, 0, -1)))
        assertEquals("2026-10-27", SleepParser.nightKey(fresh, zone))
    }

    @Test
    fun `latest day keeps the night and a same-day nap together`() {
        val nightSession =
            SleepParser.sessions(listOf(sleepRecord(millisOf(23, 0, -1), millisOf(7, 0, 0))))
                .single()
        val nap =
            SleepParser.sessions(listOf(sleepRecord(millisOf(13, 0, 0), millisOf(13, 40, 0))))
                .single()
        val old =
            SleepParser.sessions(listOf(sleepRecord(millisOf(23, 0, -3), millisOf(7, 0, -2))))
                .single()

        val day =
            SleepParser.latestDaySessions(listOf(old, nightSession, nap), millisOf(6, 0, 0), zone)
        assertEquals(listOf(nightSession, nap), day)
        assertEquals("2026-10-27", SleepParser.nightKey(nightSession, zone))
        assertEquals("2026-10-27", SleepParser.nightKey(nap, zone))
        assertEquals(nightSession.displayMinutes + 40, day.sumOf { it.displayMinutes })
    }

    @Test
    fun `combined stage minutes includes the night and every nap`() {
        val base = millisOf(23, 0, -1)
        fun session(id: String, start: Long, segments: List<SleepParser.Segment>) =
            SleepParser.Session(
                startMillis = start,
                endMillis = segments.maxOf { it.endMillis },
                segments = segments,
                efficiency = null,
                score = null,
                id = id,
            )
        val night =
            session(
                "night",
                base,
                listOf(
                    SleepParser.Segment(base, base + 60 * 60_000L, SleepParser.Stage.LIGHT),
                    SleepParser.Segment(
                        base + 60 * 60_000L,
                        base + 100 * 60_000L,
                        SleepParser.Stage.DEEP,
                    ),
                ),
            )
        val firstNapStart = millisOf(13, 0, 0)
        val firstNap =
            session(
                "nap-1",
                firstNapStart,
                listOf(
                    SleepParser.Segment(
                        firstNapStart,
                        firstNapStart + 20 * 60_000L,
                        SleepParser.Stage.REM,
                    )
                ),
            )
        val secondNapStart = millisOf(17, 0, 0)
        val secondNap =
            session(
                "nap-2",
                secondNapStart,
                listOf(
                    SleepParser.Segment(
                        secondNapStart,
                        secondNapStart + 10 * 60_000L,
                        SleepParser.Stage.LIGHT,
                    )
                ),
            )

        val minutes = SleepParser.combinedStageMinutes(listOf(night, firstNap, secondNap))
        assertEquals(70, minutes[SleepParser.Stage.LIGHT])
        assertEquals(40, minutes[SleepParser.Stage.DEEP])
        assertEquals(20, minutes[SleepParser.Stage.REM])
        assertNull(minutes[SleepParser.Stage.AWAKE])
    }

    @Test
    fun `manual nap merges with the night and updates history`() {
        val nightSession =
            SleepParser.sessions(
                    listOf(sleepRecord(millisOf(23, 0, -1), millisOf(7, 0, 0))),
                    listOf(dataRecord(millisOf(23, 0, -1), samples)),
                )
                .single()
        val nap = SleepParser.ManualNap(millisOf(14, 0, 0), millisOf(14, 45, 0))

        val merged = SleepParser.mergeSessions(listOf(nightSession), listOf(nap))
        assertEquals(2, merged.size)
        assertEquals(45, merged.last().displayMinutes)
        assertEquals("manual", merged.last().analysisSource)

        val history = SleepParser.historyByDay(merged, zone)
        assertEquals(nightSession.asleepMinutes + 45, history["2026-10-27"])
        assertEquals(2, SleepParser.mergeSessions(listOf(nightSession), listOf(nap, nap)).size)
    }

    @Test
    fun `session and history survive a round trip`() {
        val session =
            SleepParser.sessions(
                    listOf(sleepRecord(millisOf(23, 0), millisOf(7, 0, 0)) { put("quality", 82) }),
                    listOf(dataRecord(millisOf(23, 0), samples)),
                )
                .single()
        val decoded = SleepParser.decode(SleepParser.encode(session))!!
        assertEquals(session.startMillis, decoded.startMillis)
        assertEquals(session.endMillis, decoded.endMillis)
        assertEquals(session.score, decoded.score)
        assertEquals(session.segments, decoded.segments)
        assertNull(SleepParser.decode("garbage"))
        assertNull(SleepParser.decode(null))
    }

    @Test
    fun `history encode keeps days with data`() {
        val history = mapOf("2026-10-27" to 462, "2026-10-26" to 401)
        assertEquals(history, SleepParser.decodeHistory(SleepParser.encodeHistory(history)))
        assertTrue(SleepParser.decodeHistory("{}").isEmpty())
    }

    @Test
    fun `merging session record with stage data keeps both`() {
        val withoutStages =
            SleepParser.sessions(
                    listOf(sleepRecord(millisOf(23, 0), millisOf(7, 0, 0)) { put("quality", 80) })
                )
                .single()
        val withStages =
            SleepParser.sessions(
                    listOf(sleepRecord(millisOf(23, 0), millisOf(7, 0, 0))),
                    listOf(dataRecord(millisOf(23, 0), samples)),
                )
                .single()
        val merged = SleepParser.merge(withoutStages, withStages)!!
        assertEquals(withStages.segments.size, merged.segments.size) // 分期数据优先
        assertTrue(merged.segments.isNotEmpty())
        assertEquals(80, merged.score)
        assertEquals(460, merged.asleepMinutes)
    }

    @Test
    fun `merging keeps the later night and ignores nothing`() {
        val lastNight =
            SleepParser.sessions(listOf(sleepRecord(millisOf(23, 0), millisOf(7, 0, 0)))).single()
        val previous =
            SleepParser.sessions(listOf(sleepRecord(millisOf(23, 0, -1), millisOf(7, 0, 0))))
                .single()
        assertEquals(lastNight, SleepParser.merge(previous, lastNight))
        assertEquals(lastNight, SleepParser.merge(lastNight, null))
        assertNull(SleepParser.merge(null, null))
    }

    @Test
    fun `weekly sleep fills missing days with zero`() {
        val history = mapOf("2026-10-27" to 462, "2026-10-25" to 400)
        val week = SleepParser.lastWeek(history, night)
        assertEquals(7, week.size)
        assertEquals(400, week[4])
        assertEquals(462, week[6])
        assertEquals(0, week[5])
    }

    @Test
    fun `latest day sessions with zero notBefore returns the latest historical day`() {
        val old =
            SleepParser.sessions(listOf(sleepRecord(millisOf(23, 0, -5), millisOf(7, 0, -4))))
                .single()
        val latest =
            SleepParser.sessions(listOf(sleepRecord(millisOf(23, 0, -3), millisOf(7, 0, -2))))
                .single()
        val day = SleepParser.latestDaySessions(listOf(old, latest), notBeforeMillis = 0L, zone)
        assertEquals(listOf(latest), day)
    }
}
