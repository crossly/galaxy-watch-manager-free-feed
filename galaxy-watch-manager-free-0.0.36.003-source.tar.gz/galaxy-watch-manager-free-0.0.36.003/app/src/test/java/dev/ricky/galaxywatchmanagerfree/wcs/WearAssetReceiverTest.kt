package dev.ricky.galaxywatchmanagerfree.wcs

import org.junit.Assert.*
import org.junit.Test

class WearAssetReceiverTest {
    private val content = "captured asset payload".toByteArray()
    private val digest = WcsFrame.messageDigest(content)
    private fun header() = Proto.bytes(4, Proto.string(1, digest)) + Proto.integer(13, 1)
    private fun piece(header: ByteArray, bytes: ByteArray, last: Boolean) = Proto.bytes(12,
        Proto.string(1, WcsFrame.messageDigest(header)) + Proto.integer(2, if (last) 1 else 0) +
            Proto.bytes(3, bytes) + if (last) Proto.string(4, digest) else byteArrayOf())

    @Test fun `chunked assets acknowledge their content digest only after durable persistence`() {
        var saved = false
        val acks = mutableListOf<ByteArray>()
        val receiver = WearAssetReceiver(persist = { id, bytes ->
            assertEquals(digest, id)
            assertArrayEquals(content, bytes)
            saved = true
            true
        }, contains = { false }, send = { assertTrue(saved); acks.add(it); true })
        val header = header()
        receiver.receive(header)
        receiver.receive(piece(header, content.copyOfRange(0, 5), false))
        assertTrue(acks.isEmpty())
        receiver.receive(piece(header, content.copyOfRange(5, content.size), true))
        assertEquals(digest, Proto.parse(acks.single()).nested(5)?.text(1))
    }

    @Test fun `corrupt assets and failed writes are never acknowledged`() {
        var saved = 0
        val acks = mutableListOf<ByteArray>()
        val receiver = WearAssetReceiver({ _, _ -> saved++; false }, { false }, { acks.add(it); true })
        receiver.receive(header())
        receiver.receive(piece(header(), "bad bytes".toByteArray(), true))
        assertEquals(0, saved)
        receiver.receive(header())
        receiver.receive(piece(header(), content, true))
        assertEquals(1, saved)
        assertTrue(acks.isEmpty())
    }

    @Test fun `inline assets and verified existing assets are acknowledged`() {
        val acks = mutableListOf<ByteArray>()
        val receiver = WearAssetReceiver({ _, bytes -> bytes.contentEquals(content) }, { it == digest }, { acks.add(it); true })
        receiver.receive(Proto.bytes(4, Proto.string(1, digest) + Proto.bytes(2, content)))
        receiver.receive(Proto.bytes(4, Proto.string(1, digest)))
        assertEquals(2, acks.size)
    }

    @Test fun `a file piece from an old transport cannot complete after reset`() {
        var saved = 0
        val receiver = WearAssetReceiver({ _, _ -> saved++; true }, { false }, { true })
        receiver.receive(header())
        receiver.reset()
        receiver.receive(piece(header(), content, true))
        assertEquals(0, saved)
    }

    @Test fun `unrelated messages are not consumed`() {
        val receiver = WearAssetReceiver({ _, _ -> true }, { false }, { true })
        assertFalse(receiver.receive(Proto.bytes(10, byteArrayOf())))
    }
}
