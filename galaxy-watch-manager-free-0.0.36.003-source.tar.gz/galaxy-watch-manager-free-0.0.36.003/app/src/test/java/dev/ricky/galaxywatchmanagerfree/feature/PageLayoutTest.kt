package dev.ricky.galaxywatchmanagerfree.feature

import org.junit.Assert.*
import org.junit.Test

class PageLayoutTest {
    @Test
    fun `roundtrip preserves hidden order and wide settings independently of locale`() {
        val defaults = PageLayout.defaults(LayoutPage.HEALTH)
        val modified =
            PageLayout.move(defaults, PageBlock.ECG, -1).map {
                when (it.block) {
                    PageBlock.ECG -> it.copy(wide = true)
                    PageBlock.STRESS -> it.copy(visible = false)
                    else -> it
                }
            }
        assertEquals(modified, PageLayout.decode(PageLayout.encode(modified), LayoutPage.HEALTH))
    }

    @Test
    fun `unknown duplicate and other page entries are ignored while new blocks are appended`() {
        val restored =
            PageLayout.decode(
                """[{"id":"ECG","visible":false},{"id":"ECG"},{"id":"BATTERY"},{"id":"future"}]""",
                LayoutPage.HEALTH,
            )
        assertEquals(PageBlock.ECG, restored.first().block)
        assertFalse(restored.first().visible)
        assertEquals(
            PageLayout.defaults(LayoutPage.HEALTH).map { it.block }.toSet(),
            restored.map { it.block }.toSet(),
        )
        assertEquals(restored.map { it.block }.distinct().size, restored.size)
    }

    @Test
    fun `bad input resets safely and moving out of bounds has no effect`() {
        val defaults = PageLayout.defaults(LayoutPage.OVERVIEW)
        assertEquals(defaults, PageLayout.decode("broken", LayoutPage.OVERVIEW))
        assertEquals(defaults, PageLayout.move(defaults, defaults.first().block, -1))
        assertEquals(defaults, PageLayout.move(defaults, defaults.last().block, 1))
        assertTrue(
            PageLayout.decode("""[{"id":"STEPS","wide":false}]""", LayoutPage.HEALTH).first().wide
        )
    }
}
