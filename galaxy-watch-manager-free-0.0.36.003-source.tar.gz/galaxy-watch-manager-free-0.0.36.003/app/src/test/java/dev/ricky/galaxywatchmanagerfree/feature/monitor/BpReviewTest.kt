package dev.ricky.galaxywatchmanagerfree.feature.monitor

import dev.ricky.galaxywatchmanagerfree.R
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.runTest
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class BpReviewTest {
    private class Rig(scope: TestScope) {
        val sent = mutableListOf<JSONObject>()
        val events = mutableListOf<String>()
        var sendOk = true
        var saveConfig = true
        var saveRecord = true
        val monitor =
            HealthMonitorSession(
                scope,
                { _, packet ->
                    sent += packet
                    events += "send"
                    sendOk
                },
                onBpReceived = {
                    events += "record"
                    saveRecord
                },
                onBpConfigurationsReceived = {
                    events += "configuration"
                    saveConfig
                },
                nowMillis = { BpTestPackets.TIME + 1_000 },
            )

        fun connect() {
            monitor.receive("/plain_connection", """{"action":"connection"}""".toByteArray())
        }

        fun information(message: String = "RESPONSE", result: String = "") {
            monitor.receive("/991", BpTestPackets.information(message = message, result = result))
        }
    }

    @Test
    fun `repeated reviews share a handshake information query and sync request`() = runTest {
        val rig = Rig(this)
        repeat(5) { assertTrue(rig.monitor.reviewBp()) }
        assertEquals(1, rig.sent.size)
        rig.connect()
        rig.connect()
        assertEquals(
            1,
            rig.sent.count {
                it.has("body") && HealthMonitorProtocol.decode(it).action == "information"
            },
        )
        rig.information()
        assertFalse(rig.monitor.state.value.bpInformationPending)
        assertTrue(rig.monitor.state.value.bpSyncPending)
        repeat(5) { assertTrue(rig.monitor.reviewBp()) }
        assertEquals(
            1,
            rig.sent.count { it.has("body") && HealthMonitorProtocol.decode(it).type == "DATA" },
        )
        rig.monitor.receiveSync(HealthMonitorProtocol.Channel.BP, BpTestPackets.sync())
        assertNotNull(rig.monitor.state.value.bpReviewedInformation)
        rig.monitor.disconnect()
    }

    @Test
    fun `an earlier sync and information alone cannot confirm the return review`() = runTest {
        val rig = Rig(this)
        rig.connect()
        rig.monitor.receiveSync(HealthMonitorProtocol.Channel.BP, BpTestPackets.sync())
        rig.monitor.reviewBp()
        rig.information()
        assertNull(rig.monitor.state.value.bpReviewedInformation)
        rig.monitor.receiveSync(HealthMonitorProtocol.Channel.BP, BpTestPackets.sync(last = false))
        assertNull(rig.monitor.state.value.bpReviewedInformation)
        rig.monitor.receiveSync(HealthMonitorProtocol.Channel.BP, BpTestPackets.sync())
        assertNotNull(rig.monitor.state.value.bpReviewedInformation)
        rig.monitor.disconnect()
    }

    @Test
    fun `an unsolicited completed BP sync refreshes watch calibration status`() = runTest {
        val rig = Rig(this)
        rig.connect()
        rig.sent.clear()
        rig.monitor.receiveSync(HealthMonitorProtocol.Channel.BP, BpTestPackets.sync())
        assertEquals("SUCCESS", HealthMonitorProtocol.decode(rig.sent.first()).result)
        val information =
            rig.sent.filter {
                it.has("body") && HealthMonitorProtocol.decode(it).action == "information"
            }
        assertEquals(1, information.size)
        assertTrue(rig.monitor.state.value.bpInformationPending)

        rig.information()
        assertNotNull(rig.monitor.state.value.information[HealthMonitorProtocol.Channel.BP])
        assertFalse(rig.monitor.state.value.bpInformationPending)
        assertFalse(rig.monitor.state.value.bpSyncPending)
        rig.monitor.disconnect()
    }

    @Test
    fun `configuration and measurement in the same object are both saved before ACK`() = runTest {
        val rig = Rig(this)
        val rows =
            JSONArray()
                .put(
                    JSONObject()
                        .put(
                            "com.samsung.health.bp.configuration",
                            JSONArray().put(BpTestPackets.configuration()),
                        )
                        .put("com.samsung.health.bp", JSONArray().put(BpTestPackets.record()))
                )
        rig.monitor.receiveSync(HealthMonitorProtocol.Channel.BP, BpTestPackets.sync(rows))
        assertEquals(listOf("configuration", "record", "send"), rig.events)
        assertEquals("SUCCESS", HealthMonitorProtocol.decode(rig.sent.single()).result)
        assertNotNull(rig.monitor.state.value.lastBp)
    }

    @Test
    fun `failed configuration write prevents acknowledging the batch or advancing review`() =
        runTest {
            val rig = Rig(this)
            rig.connect()
            rig.monitor.reviewBp()
            rig.information()
            rig.events.clear()
            rig.saveConfig = false
            val rows =
                JSONArray()
                    .put(
                        JSONObject()
                            .put(
                                "com.samsung.health.bp.configuration",
                                JSONArray().put(BpTestPackets.configuration()),
                            )
                    )
                    .put(
                        JSONObject()
                            .put("com.samsung.health.bp", JSONArray().put(BpTestPackets.record()))
                    )
            rig.monitor.receiveSync(HealthMonitorProtocol.Channel.BP, BpTestPackets.sync(rows))
            assertEquals(listOf("configuration"), rig.events)
            assertNull(rig.monitor.state.value.bpReviewedInformation)
            assertEquals(R.string.monitor_save_failed, rig.monitor.state.value.error?.resource)
            assertFalse(rig.monitor.state.value.bpSyncPending)
            rig.monitor.disconnect()
        }

    @Test
    fun `measurement write failure after configuration save keeps the batch unacknowledged`() =
        runTest {
            val rig = Rig(this)
            rig.saveRecord = false
            val rows =
                JSONArray()
                    .put(
                        JSONObject()
                            .put(
                                "com.samsung.health.bp.configuration",
                                JSONArray().put(BpTestPackets.configuration()),
                            )
                    )
                    .put(
                        JSONObject()
                            .put("com.samsung.health.bp", JSONArray().put(BpTestPackets.record()))
                    )
            rig.monitor.receiveSync(HealthMonitorProtocol.Channel.BP, BpTestPackets.sync(rows))
            assertEquals(listOf("configuration", "record"), rig.events)
            assertTrue(rig.sent.isEmpty())
            assertEquals(R.string.monitor_save_failed, rig.monitor.state.value.error?.resource)
        }

    @Test
    fun `failed ACK does not confirm calibration even after all records are saved`() = runTest {
        val rig = Rig(this)
        rig.connect()
        rig.monitor.reviewBp()
        rig.information()
        rig.sendOk = false
        rig.monitor.receiveSync(HealthMonitorProtocol.Channel.BP, BpTestPackets.sync())
        assertNull(rig.monitor.state.value.bpReviewedInformation)
        assertFalse(rig.monitor.state.value.bpSyncPending)
        assertEquals(
            R.string.monitor_connection_unavailable,
            rig.monitor.state.value.error?.resource,
        )
        rig.monitor.disconnect()
    }

    @Test
    fun `information timeout clears pending state and ignores a late response`() = runTest {
        val rig = Rig(this)
        rig.connect()
        rig.information(message = "REQUEST")
        rig.monitor.reviewBp()
        advanceUntilIdle()
        assertFalse(rig.monitor.state.value.bpInformationPending)
        assertEquals(
            R.string.monitor_bp_information_unconfirmed,
            rig.monitor.state.value.error?.resource,
        )
        rig.information()
        assertNull(rig.monitor.state.value.information[HealthMonitorProtocol.Channel.BP])
        assertFalse(rig.monitor.startBpMeasurement())
        rig.monitor.disconnect()
    }

    @Test
    fun `sync timeout exposes retry without inventing calibration success`() = runTest {
        val rig = Rig(this)
        rig.connect()
        rig.monitor.reviewBp()
        rig.information()
        advanceUntilIdle()
        assertFalse(rig.monitor.state.value.bpSyncPending)
        assertNull(rig.monitor.state.value.bpReviewedInformation)
        assertEquals(R.string.monitor_bp_sync_unconfirmed, rig.monitor.state.value.error?.resource)
        assertTrue(rig.monitor.reviewBp())
        rig.information()
        rig.monitor.receiveSync(HealthMonitorProtocol.Channel.BP, BpTestPackets.sync())
        assertNotNull(rig.monitor.state.value.bpReviewedInformation)
        rig.monitor.disconnect()
    }

    @Test
    fun `failed information response cannot leave an old calibration usable`() = runTest {
        val rig = Rig(this)
        rig.connect()
        rig.information(message = "REQUEST")
        assertTrue(rig.monitor.startBpMeasurement())
        rig.monitor.reviewBp()
        rig.information(result = "fail")
        assertNull(rig.monitor.state.value.information[HealthMonitorProtocol.Channel.BP])
        assertFalse(rig.monitor.state.value.bpInformationPending)
        assertEquals(
            R.string.monitor_bp_information_unconfirmed,
            rig.monitor.state.value.error?.resource,
        )
        assertFalse(rig.monitor.startBpMeasurement())
        rig.monitor.disconnect()
    }

    @Test
    fun `send failure and handshake timeout leave no stuck review`() = runTest {
        val rig = Rig(this)
        rig.sendOk = false
        assertFalse(rig.monitor.reviewBp())
        assertFalse(rig.monitor.state.value.bpInformationPending)
        rig.sendOk = true
        assertTrue(rig.monitor.reviewBp())
        advanceUntilIdle()
        assertFalse(rig.monitor.state.value.bpInformationPending)
        assertEquals(R.string.monitor_handshake_timeout, rig.monitor.state.value.error?.resource)
        rig.connect()
        rig.sendOk = false
        assertFalse(rig.monitor.reviewBp())
        assertFalse(rig.monitor.state.value.bpInformationPending)
        rig.monitor.disconnect()
    }

    @Test
    fun `unknown forced and expired calibration all block measurement`() = runTest {
        val rig = Rig(this)
        rig.connect()
        assertFalse(rig.monitor.startBpMeasurement())
        rig.monitor.receive("/991", BpTestPackets.information(forced = true))
        assertFalse(rig.monitor.startBpMeasurement())
        rig.monitor.receive("/991", BpTestPackets.information(time = 1))
        assertFalse(rig.monitor.startBpMeasurement())
        rig.information(message = "REQUEST")
        assertTrue(rig.monitor.startBpMeasurement())
        rig.monitor.disconnect()
        rig.connect()
        assertNull(rig.monitor.state.value.information[HealthMonitorProtocol.Channel.BP])
        assertFalse(rig.monitor.startBpMeasurement())
        rig.monitor.disconnect()
    }

    @Test
    fun `malformed information ends review and leaves an actionable error`() = runTest {
        val rig = Rig(this)
        rig.connect()
        rig.monitor.reviewBp()
        rig.monitor.receive("/991", "{}".toByteArray())
        assertFalse(rig.monitor.state.value.bpInformationPending)
        assertEquals(R.string.monitor_parse_failed, rig.monitor.state.value.error?.resource)
        rig.monitor.disconnect()
    }

    @Test
    fun `a malformed channel job clears pending sync and reports parsing failure`() = runTest {
        val rig = Rig(this)
        rig.connect()
        rig.monitor.reviewBp()
        rig.information()
        rig.monitor.receiveSync(HealthMonitorProtocol.Channel.BP, JSONObject())
        assertFalse(rig.monitor.state.value.bpSyncPending)
        assertNull(rig.monitor.state.value.bpReviewedInformation)
        assertEquals(R.string.monitor_parse_failed, rig.monitor.state.value.error?.resource)
        rig.monitor.disconnect()
    }

    @Test
    fun `malformed configuration alongside valid measurements cannot be silently acknowledged`() =
        runTest {
            val rig = Rig(this)
            val rows =
                JSONArray()
                    .put(
                        JSONObject()
                            .put("com.samsung.health.bp.configuration", JSONObject())
                            .put("com.samsung.health.bp", JSONArray().put(BpTestPackets.record()))
                    )
            rig.monitor.receiveSync(HealthMonitorProtocol.Channel.BP, BpTestPackets.sync(rows))
            assertTrue(rig.sent.isEmpty())
            assertNull(rig.monitor.state.value.lastBp)
            assertEquals(R.string.monitor_save_failed, rig.monitor.state.value.error?.resource)
        }

    @Test
    fun `a new forced recalibration notification invalidates a previous successful review`() =
        runTest {
            val rig = Rig(this)
            rig.connect()
            rig.monitor.reviewBp()
            rig.information()
            rig.monitor.receiveSync(HealthMonitorProtocol.Channel.BP, BpTestPackets.sync())
            assertNotNull(rig.monitor.state.value.bpReviewedInformation)
            rig.monitor.receive("/991", BpTestPackets.information(forced = true))
            assertNull(rig.monitor.state.value.bpReviewedInformation)
            assertFalse(rig.monitor.startBpMeasurement())
            rig.monitor.disconnect()
        }
}
