package dev.ricky.galaxywatchmanagerfree.feature

import org.json.JSONException
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LogBusPrivacyTest {
    private val payloads =
        listOf(
            """{"datauuid":"synthetic-private-health-row","heart_rate":73.125,"asleepMinutes":421,"efficiency":93.5,""",
            """{"title":"synthetic-private-notification","body":"synthetic-private-body",""",
            """{"password":"synthetic-private-password","access_token":"synthetic-private-token",""",
        )

    private fun malformedError(payload: String): JSONException =
        JSONException("Unterminated object at character ${payload.length} of $payload")

    @Test
    fun `error line keeps caller context and exception class without throwable message`() {
        for (payload in payloads) {
            val line = LogBus.formatError("[健康] DataItem 消息解析失败 bytes=128", malformedError(payload))

            assertEquals("[健康] DataItem 消息解析失败 bytes=128: JSONException", line)
        }
        assertEquals("[同步] 失败", LogBus.formatError("[同步] 失败", null))
    }

    @Test
    fun `debug stack keeps classes and frames without payload whether debug is off or on`() {
        for (payload in payloads) {
            val error = malformedError(payload)
            val debugOff = LogBus.formatError("[健康监测器] Channel 解码失败 bytes=128", error)
            val debugOn = debugOff + "\n" + LogBus.formatDebugStack(error)

            for (output in listOf(debugOff, debugOn)) {
                assertFalse(output.contains("synthetic-private-"))
                assertFalse(output.contains("73.125"))
                assertFalse(output.contains("421"))
                assertFalse(output.contains("93.5"))
                assertTrue(output.contains("JSONException"))
            }
            assertFalse(debugOff.contains("\tat "))
            assertTrue(debugOn.contains("\tat "))
        }
    }

    @Test
    fun `causes and suppressed failures keep their types and frames without messages`() {
        val cause = malformedError(payloads.first())
        val error = IllegalStateException(payloads[1], cause)
        error.addSuppressed(IllegalArgumentException(payloads[2]))
        val output = LogBus.formatDebugStack(error)

        assertTrue(output.contains("java.lang.IllegalStateException"))
        assertTrue(output.contains("Caused by: org.json.JSONException"))
        assertTrue(output.contains("Suppressed: java.lang.IllegalArgumentException"))
        assertTrue(output.contains("LogBusPrivacyTest"))
        assertFalse(output.contains("synthetic-private-"))
        assertFalse(output.contains("73.125"))
    }
}
