package dev.ricky.galaxywatchmanagerfree.feature

import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class AutoQueryCoordinatorTest {
    @Test
    fun `background has initial health read then one shared interval without battery`() = runTest {
        var health = 0
        var battery = 0
        val queries =
            AutoQueryCoordinator(
                backgroundScope,
                { battery++ },
                { health++ },
                AutoQueryPolicy(intervalSeconds = 300),
            )
        queries.start()
        queries.start()
        runCurrent()
        advanceTimeBy(2_999)
        runCurrent()
        assertEquals(0, health)
        advanceTimeBy(1)
        runCurrent()
        assertEquals(1, health)
        advanceTimeBy(297_000)
        runCurrent()
        assertEquals(2, health)
        assertEquals(0, battery)
        advanceTimeBy(300_000)
        runCurrent()
        assertEquals(3, health)
        queries.stop()
    }

    @Test
    fun `foreground follows selected interval and leaving stops only battery queries`() = runTest {
        var health = 0
        var battery = 0
        val queries =
            AutoQueryCoordinator(
                backgroundScope,
                { battery++ },
                { health++ },
                AutoQueryPolicy(intervalSeconds = 60),
            )
        queries.setVisible(true)
        queries.start()
        runCurrent()
        advanceTimeBy(60_000)
        runCurrent()
        assertEquals(2, health)
        assertEquals(1, battery)
        queries.setVisible(false)
        advanceTimeBy(60_000)
        runCurrent()
        assertEquals(3, health)
        assertEquals(1, battery)
        queries.stop()
    }

    @Test
    fun `disabled policy preserves initial read and manual health request without periodic work`() =
        runTest {
            var sent = 0
            var battery = 0
            val health =
                HealthSyncCoordinator(
                    backgroundScope,
                    {
                        sent++
                        true
                    },
                    {},
                )
            val queries =
                AutoQueryCoordinator(
                    backgroundScope,
                    { battery++ },
                    { health.request() },
                    AutoQueryPolicy(enabled = false),
                )
            health.start()
            queries.setVisible(true)
            queries.start()
            runCurrent()
            advanceTimeBy(900_000)
            runCurrent()
            assertEquals(1, sent)
            assertEquals(0, battery)
            assertEquals(true, health.request())
            queries.stop()
            health.stop()
        }

    @Test
    fun `changing interval cancels old deadline without repeating initial read`() = runTest {
        var health = 0
        val queries = AutoQueryCoordinator(backgroundScope, {}, { health++ })
        queries.start()
        runCurrent()
        advanceTimeBy(20_000)
        runCurrent()
        assertEquals(1, health)
        queries.configure(AutoQueryPolicy(intervalSeconds = 60))
        runCurrent()
        advanceTimeBy(59_999)
        runCurrent()
        assertEquals(1, health)
        advanceTimeBy(1)
        runCurrent()
        assertEquals(2, health)
        queries.configure(AutoQueryPolicy(intervalSeconds = 300))
        runCurrent()
        advanceTimeBy(299_999)
        runCurrent()
        assertEquals(2, health)
        advanceTimeBy(1)
        runCurrent()
        assertEquals(3, health)
        queries.stop()
    }

    @Test
    fun `disabling cancels pending tick and enabling starts a fresh countdown`() = runTest {
        var health = 0
        val queries =
            AutoQueryCoordinator(
                backgroundScope,
                {},
                { health++ },
                AutoQueryPolicy(intervalSeconds = 30),
            )
        queries.start()
        runCurrent()
        advanceTimeBy(29_000)
        runCurrent()
        queries.configure(AutoQueryPolicy(enabled = false, intervalSeconds = 30))
        advanceTimeBy(120_000)
        runCurrent()
        assertEquals(1, health)
        queries.configure(AutoQueryPolicy(intervalSeconds = 30))
        runCurrent()
        advanceTimeBy(30_000)
        runCurrent()
        assertEquals(2, health)
        queries.stop()
    }

    @Test
    fun `disconnect cancels initial and periodic work and reconnect creates one schedule`() =
        runTest {
            var health = 0
            val queries =
                AutoQueryCoordinator(
                    backgroundScope,
                    {},
                    { health++ },
                    AutoQueryPolicy(intervalSeconds = 300),
                )
            queries.start()
            runCurrent()
            advanceTimeBy(1_000)
            queries.stop()
            advanceTimeBy(900_000)
            runCurrent()
            assertEquals(0, health)
            queries.start()
            queries.start()
            runCurrent()
            advanceTimeBy(3_000)
            runCurrent()
            assertEquals(1, health)
            advanceTimeBy(297_000)
            runCurrent()
            assertEquals(2, health)
            queries.stop()
        }

    @Test
    fun `periodic and manual health requests do not overlap across the actual handshake seam`() =
        runTest {
            var sent = 0
            val health =
                HealthSyncCoordinator(
                    backgroundScope,
                    {
                        sent++
                        true
                    },
                    {},
                )
            val queries =
                AutoQueryCoordinator(
                    backgroundScope,
                    {},
                    { health.request() },
                    AutoQueryPolicy(intervalSeconds = 30),
                )
            health.start()
            queries.start()
            runCurrent()
            advanceTimeBy(3_000)
            runCurrent()
            assertEquals(false, health.request())
            advanceTimeBy(27_000)
            runCurrent()
            assertEquals(1, sent)
            health.onWatchRequest("LOG_DATA")
            advanceTimeBy(30_000)
            runCurrent()
            assertEquals(2, sent)
            queries.stop()
            health.stop()
        }

    @Test
    fun `invalid persisted interval falls back to bounded recommended default`() {
        assertEquals(900, AutoQueryPolicy.fromPreferences(true, 0).intervalSeconds)
        assertEquals(900, AutoQueryPolicy.fromPreferences(false, Int.MAX_VALUE).intervalSeconds)
        assertEquals(false, AutoQueryPolicy.fromPreferences(false, -1).enabled)
        AutoQueryPolicy.INTERVALS_SECONDS.forEach {
            assertEquals(it, AutoQueryPolicy.fromPreferences(true, it).intervalSeconds)
        }
    }
}
