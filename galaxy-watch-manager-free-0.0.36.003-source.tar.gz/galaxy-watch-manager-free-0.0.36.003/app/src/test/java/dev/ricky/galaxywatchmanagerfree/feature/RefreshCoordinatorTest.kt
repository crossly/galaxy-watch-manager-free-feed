package dev.ricky.galaxywatchmanagerfree.feature

import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class RefreshCoordinatorTest {
    @Test
    fun `concurrent callers can only dispatch one refresh batch`() = runTest {
        val batches = AtomicInteger()
        val refresh = RefreshCoordinator(backgroundScope, {})
        val accepted =
            List(100) {
                    async(Dispatchers.Default) { refresh.request { batches.incrementAndGet() } }
                }
                .awaitAll()
        assertEquals(1, accepted.count { it })
        assertEquals(1, batches.get())
        refresh.stop()
    }

    @Test
    fun `repeated clicks send one batch until every reply has arrived`() = runTest {
        var batches = 0
        var running = false
        val refresh = RefreshCoordinator(backgroundScope, { running = it })
        val send: (Long) -> Unit = { batches++ }
        assertTrue(refresh.request(send))
        repeat(100) { assertFalse(refresh.request(send)) }
        assertEquals(1, batches)
        assertTrue(running)
        RefreshCoordinator.Target.entries
            .filter { it != RefreshCoordinator.Target.MEMORY }
            .forEach(refresh::confirm)
        assertFalse(refresh.request(send))
        refresh.confirm(RefreshCoordinator.Target.MEMORY)
        assertFalse(running)
        assertTrue(refresh.request(send))
        assertEquals(2, batches)
        refresh.stop()
    }

    @Test
    fun `a real chunked health sync keeps the whole refresh busy past the device timeout`() =
        runTest {
            var running = false
            var healthRequests = 0
            val refresh = RefreshCoordinator(backgroundScope, { running = it })
            val health =
                HealthSyncCoordinator(
                    backgroundScope,
                    {
                        healthRequests++
                        true
                    },
                    {
                        if (
                            it == HealthSyncCoordinator.Status.IDLE ||
                                it == HealthSyncCoordinator.Status.TIMED_OUT ||
                                it == HealthSyncCoordinator.Status.DISCONNECTED
                        ) {
                            refresh.confirm(RefreshCoordinator.Target.HEALTH)
                        }
                    },
                )
            health.start()
            assertTrue(refresh.request { assertTrue(health.request()) })
            RefreshCoordinator.Target.entries
                .filter { it != RefreshCoordinator.Target.HEALTH }
                .forEach(refresh::confirm)
            runCurrent()
            repeat(3) {
                advanceTimeBy(50_000L)
                runCurrent()
                health.onWatchRequest("SYNC_DATA")
                runCurrent()
                assertTrue(running)
                assertFalse(refresh.request { health.request() })
            }
            assertEquals(1, healthRequests)
            health.onWatchRequest("LOG_DATA")
            assertFalse(running)
            assertTrue(refresh.request { health.request() })
            assertEquals(2, healthRequests)
            refresh.stop()
            health.stop()
        }

    @Test
    fun `missing device replies time out without retrying and invalidate queued requests`() =
        runTest {
            var running = false
            var batches = 0
            var token = 0L
            val refresh = RefreshCoordinator(backgroundScope, { running = it })
            refresh.request {
                token = it
                batches++
            }
            refresh.confirm(RefreshCoordinator.Target.HEALTH)
            runCurrent()
            advanceTimeBy(RefreshCoordinator.DEVICE_TIMEOUT_MS - 1)
            runCurrent()
            assertTrue(running)
            assertTrue(refresh.isPending(token, RefreshCoordinator.Target.MEMORY))
            advanceTimeBy(1)
            runCurrent()
            assertFalse(running)
            assertFalse(refresh.isPending(token, RefreshCoordinator.Target.MEMORY))
            advanceTimeBy(120_000L)
            runCurrent()
            assertEquals(1, batches)
        }

    @Test
    fun `health timeout releases the gate even when no completion packet arrives`() = runTest {
        var running = false
        val refresh = RefreshCoordinator(backgroundScope, { running = it })
        val health =
            HealthSyncCoordinator(
                backgroundScope,
                { true },
                {
                    if (it == HealthSyncCoordinator.Status.TIMED_OUT) {
                        refresh.confirm(RefreshCoordinator.Target.HEALTH)
                    }
                },
            )
        health.start()
        refresh.request { health.request() }
        runCurrent()
        advanceTimeBy(HealthSyncCoordinator.TIMEOUT_MS - 1)
        runCurrent()
        assertTrue(running)
        advanceTimeBy(1)
        runCurrent()
        assertFalse(running)
        health.stop()
    }

    @Test
    fun `health send failure still waits for the other device replies`() = runTest {
        var running = false
        val refresh = RefreshCoordinator(backgroundScope, { running = it })
        val health =
            HealthSyncCoordinator(
                backgroundScope,
                { false },
                {
                    if (it == HealthSyncCoordinator.Status.TIMED_OUT) {
                        refresh.confirm(RefreshCoordinator.Target.HEALTH)
                    }
                },
            )
        health.start()
        assertTrue(refresh.request { assertFalse(health.request()) })
        assertTrue(running)
        assertFalse(refresh.request {})
        RefreshCoordinator.Target.entries
            .filter { it != RefreshCoordinator.Target.HEALTH }
            .forEach(refresh::confirm)
        assertFalse(running)
        health.stop()
    }

    @Test
    fun `disconnect invalidates old queued work and its timeout cannot stop a new refresh`() =
        runTest {
            var running = false
            var oldToken = 0L
            var newToken = 0L
            val refresh = RefreshCoordinator(backgroundScope, { running = it })
            refresh.request { oldToken = it }
            runCurrent()
            advanceTimeBy(20_000L)
            runCurrent()
            refresh.stop()
            assertFalse(running)
            refresh.request { newToken = it }
            runCurrent()
            refresh.confirm(RefreshCoordinator.Target.HEALTH)
            assertFalse(refresh.isPending(oldToken, RefreshCoordinator.Target.MEMORY))
            assertTrue(refresh.isPending(newToken, RefreshCoordinator.Target.MEMORY))
            advanceTimeBy(10_000L)
            runCurrent()
            assertTrue(running)
            advanceTimeBy(20_000L)
            runCurrent()
            assertFalse(running)
        }

    @Test
    fun `fast replies do not release the gate before the batch finishes dispatching`() = runTest {
        var running = false
        val refresh = RefreshCoordinator(backgroundScope, { running = it })
        assertTrue(
            refresh.request {
                RefreshCoordinator.Target.entries.forEach(refresh::confirm)
                assertTrue(running)
                assertFalse(refresh.request { error("Must not send another batch") })
            }
        )
        assertFalse(running)
    }

    @Test
    fun `dispatch failure clears the gate and invalidates unsent device work`() = runTest {
        var running = false
        var token = 0L
        val refresh = RefreshCoordinator(backgroundScope, { running = it })
        assertFalse(
            refresh.request {
                token = it
                error("Disconnected during dispatch")
            }
        )
        assertFalse(running)
        assertFalse(refresh.isPending(token, RefreshCoordinator.Target.MEMORY))
        assertTrue(refresh.request {})
        refresh.stop()
    }

    @Test
    fun `toolbar and repository share the same connection and refresh availability`() {
        assertFalse(WatchState().canRefresh)
        val ready = WatchState(sessionReady = true)
        assertTrue(ready.canRefresh)
        assertFalse(ready.copy(refreshing = true).canRefresh)
        assertFalse(ready.copy(startupSyncing = true).canRefresh)
        assertFalse(ready.copy(healthSyncStatus = HealthSyncCoordinator.Status.SYNCING).canRefresh)
        assertTrue(ready.copy(healthSyncStatus = HealthSyncCoordinator.Status.TIMED_OUT).canRefresh)
    }
}
