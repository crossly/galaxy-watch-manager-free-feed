package dev.ricky.galaxywatchmanagerfree.feature

import android.Manifest
import org.junit.Assert.*
import org.junit.Test

class AppPermissionsTest {
    @Test
    fun nearbyDevicesAreRequestedOnlyOnAndroid12AndLater() {
        assertFalse(AppPermission.NEARBY_DEVICES in AppPermission.applicable(30))
        assertTrue(AppPermission.NEARBY_DEVICES.runtimePermissions(30).isEmpty())
        for (sdk in listOf(31, 32, 33, 35, 36)) {
            assertTrue(AppPermission.NEARBY_DEVICES in AppPermission.applicable(sdk))
            assertEquals(
                listOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN),
                AppPermission.NEARBY_DEVICES.runtimePermissions(sdk),
            )
        }
    }

    @Test
    fun appNotificationsUseRuntimePermissionFromAndroid13() {
        assertTrue(AppPermission.APP_NOTIFICATIONS in AppPermission.applicable(26))
        assertTrue(AppPermission.APP_NOTIFICATIONS.runtimePermissions(32).isEmpty())
        assertEquals(
            listOf(Manifest.permission.POST_NOTIFICATIONS),
            AppPermission.APP_NOTIFICATIONS.runtimePermissions(33),
        )
    }

    @Test
    fun storageIsLimitedToAndroid8And9() {
        for (sdk in 26..28) {
            assertTrue(AppPermission.LEGACY_STORAGE in AppPermission.applicable(sdk))
            assertEquals(
                listOf(Manifest.permission.WRITE_EXTERNAL_STORAGE),
                AppPermission.LEGACY_STORAGE.runtimePermissions(sdk),
            )
        }
        for (sdk in 29..36) {
            assertFalse(AppPermission.LEGACY_STORAGE in AppPermission.applicable(sdk))
            assertTrue(AppPermission.LEGACY_STORAGE.runtimePermissions(sdk).isEmpty())
        }
    }

    @Test
    fun specialAccessIsNeverRequestedAsRuntimePermission() {
        for (sdk in 26..36) {
            for (permission in
                listOf(
                    AppPermission.NOTIFICATION_ACCESS,
                    AppPermission.BATTERY_OPTIMIZATION,
                    AppPermission.INSTALL_PACKAGES,
                )) {
                assertTrue(permission in AppPermission.applicable(sdk))
                assertTrue(permission.runtimePermissions(sdk).isEmpty())
            }
        }
    }
}
