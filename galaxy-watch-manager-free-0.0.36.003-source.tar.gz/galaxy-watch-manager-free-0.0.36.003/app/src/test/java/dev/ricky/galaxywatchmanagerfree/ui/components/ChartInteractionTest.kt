package dev.ricky.galaxywatchmanagerfree.ui.components

import java.time.LocalDate
import java.time.ZoneId
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ChartInteractionTest {
    private val zone = ZoneId.of("America/New_York")

    @Test
    fun noonStaysAtTheMiddleOnBothDaylightSavingTransitions() {
        listOf(LocalDate.of(2026, 3, 8), LocalDate.of(2026, 11, 1)).forEach { day ->
            val noon = day.atTime(12, 0).atZone(zone).toInstant().toEpochMilli()
            assertEquals(0.5f, chartDayFraction(noon, zone), 0.00001f)
        }
    }

    @Test
    fun repeatedClockHoursShareTheSamePosition() {
        val first = LocalDate.of(2026, 11, 1).atTime(1, 30).atZone(zone)
        val second = first.withLaterOffsetAtOverlap()
        assertEquals(
            chartDayFraction(first.toInstant().toEpochMilli(), zone),
            chartDayFraction(second.toInstant().toEpochMilli(), zone),
            0.00001f,
        )
    }

    @Test
    fun probeUsesTheNearestRealReadingAndHandlesEmptyDays() {
        assertNull(nearestChartIndex(emptyList(), 0.5f))
        assertEquals(1, nearestChartIndex(listOf(0.25f, 0.5f, 0.75f), 0.6f))
        // Positions can move back at the autumn clock change.
        assertEquals(2, nearestChartIndex(listOf(0.0625f, 0.08f, 0.05f), 0.05f))
    }

    @Test
    fun selectedTimeUsesTheSameExplicitZoneAsTheAxis() {
        val noon = LocalDate.of(2026, 11, 1).atTime(12, 0).atZone(zone)
        assertEquals("12:00", formatClock(noon.toInstant().toEpochMilli(), zone))
    }
}
