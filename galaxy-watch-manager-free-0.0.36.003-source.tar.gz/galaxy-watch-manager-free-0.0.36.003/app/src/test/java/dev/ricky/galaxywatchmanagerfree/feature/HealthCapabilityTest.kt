package dev.ricky.galaxywatchmanagerfree.feature

import dev.ricky.galaxywatchmanagerfree.wcs.WcsPaths
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class HealthCapabilityTest {

    @Test
    fun `buildResponse produces complete official capability payload matching watch expectations`() {
        val payload = HealthCapability.buildResponse("test-phone-node", "Pixel 9 Pro")

        assertEquals(
            HealthCapability.PROTOCOL_VERSION,
            payload.getDouble("protocol_version"),
            0.001,
        )
        assertEquals(HealthCapability.SHEALTH_VERSION, payload.getInt("shealth_version"))
        assertEquals(HealthCapability.MESSAGE_TYPE_RESPONSE, payload.getString("message_type"))
        assertEquals(HealthCapability.RESPONSE_CAPABILITY, payload.getString("capability_type"))
        assertEquals("shealth", payload.getString("sender"))
        assertEquals("wearable", payload.getString("receiver"))
        assertEquals("Pixel 9 Pro", payload.getString("model_name"))
        assertEquals("test-phone-node", payload.getString("device_id"))
        assertEquals("test-phone-node", payload.getString("connection_id"))
        assertEquals(HealthCapability.DEVICE_TYPE_PHONE, payload.getInt("device_type"))

        val vascularLoad =
            payload.getJSONObject("tracker_feature").getJSONObject("vascular_load_feature")
        assertEquals(1002, vascularLoad.getInt("version"))
        assertTrue(vascularLoad.getBoolean("vascular_load_support"))

        val binning = payload.getJSONObject("binning")
        assertEquals(4, binning.getInt("pedometer"))
        assertEquals(10, binning.getInt("sleep"))

        val protocolFeature = payload.getJSONObject("protocol_feature")
        assertTrue(protocolFeature.getBoolean("wearable_messaging"))
        assertTrue(protocolFeature.getBoolean("compression"))
        assertEquals(30, protocolFeature.getInt("sync_duration"))
        assertEquals(10000, protocolFeature.getInt("wm_chunk_size"))
        assertTrue(protocolFeature.getBoolean("blob_compression"))

        assertEquals("gzip", payload.getJSONObject("compression").getString("format"))
        assertEquals(
            WcsPaths.HEALTH_PHONE_SYNC,
            payload.getJSONObject("sync_address").getString("common_sync"),
        )

        val wm = payload.getJSONObject("wearable_message")
        assertEquals(5.03, wm.getDouble("message_version"), 0.001)
        assertTrue(wm.getBoolean("message_support"))
        assertTrue(wm.getBoolean("message_compression"))
        assertEquals("gzip", wm.getString("message_compression_format"))
        assertEquals(10000, wm.getInt("message_size"))
    }

    @Test
    fun `isRequest and isResponse accurately classify capability JSON messages`() {
        val req = JSONObject().put("capability_type", HealthCapability.REQUEST_CAPABILITY)
        val resp = JSONObject().put("capability_type", HealthCapability.RESPONSE_CAPABILITY)
        val other = JSONObject().put("capability_type", "unknown")

        assertTrue(HealthCapability.isRequest(req))
        assertFalse(HealthCapability.isResponse(req))

        assertTrue(HealthCapability.isResponse(resp))
        assertFalse(HealthCapability.isRequest(resp))

        assertFalse(HealthCapability.isRequest(other))
        assertFalse(HealthCapability.isResponse(other))
    }

    @Test
    fun `vascularLoadSupported follows the official category version and support gate`() {
        assertTrue(HealthCapability.vascularLoadSupported(watchCapability()))
        assertTrue(HealthCapability.vascularLoadSupported(watchCapability(version = 1000)))
        assertFalse(HealthCapability.vascularLoadSupported(watchCapability(version = 999)))
        assertFalse(HealthCapability.vascularLoadSupported(watchCapability(support = false)))
        assertFalse(HealthCapability.vascularLoadSupported(watchCapability(category = 40003)))
        assertFalse(HealthCapability.vascularLoadSupported(watchCapability(category = null)))
        assertFalse(HealthCapability.vascularLoadSupported(watchCapability(version = null)))
        assertFalse(HealthCapability.vascularLoadSupported(watchCapability(support = null)))
    }

    @Test
    fun `vascularLoadSupported rejects absent or malformed capability data`() {
        assertFalse(HealthCapability.vascularLoadSupported(JSONObject()))
        assertFalse(HealthCapability.vascularLoadSupported(JSONObject().put("category", 40001)))
        assertFalse(
            HealthCapability.vascularLoadSupported(
                JSONObject().put("category", 40001).put("tracker_feature", JSONObject())
            )
        )
        assertFalse(
            HealthCapability.vascularLoadSupported(
                JSONObject()
                    .put("category", 40001)
                    .put("tracker_feature", JSONObject().put("vascular_load_feature", "malformed"))
            )
        )
        assertFalse(
            HealthCapability.vascularLoadSupported(
                watchCapability(category = null).put("device_category", 40001)
            )
        )
        assertFalse(
            HealthCapability.vascularLoadSupported(watchCapability().put("category", "invalid"))
        )
        val malformedVersion = watchCapability()
        malformedVersion
            .getJSONObject("tracker_feature")
            .getJSONObject("vascular_load_feature")
            .put("version", "invalid")
        assertFalse(HealthCapability.vascularLoadSupported(malformedVersion))
        val malformedSupport = watchCapability()
        malformedSupport
            .getJSONObject("tracker_feature")
            .getJSONObject("vascular_load_feature")
            .put("vascular_load_support", "invalid")
        assertFalse(HealthCapability.vascularLoadSupported(malformedSupport))
    }

    @Test
    fun `buildRequest includes official phone vascular load capability`() {
        val request = HealthCapability.buildRequest("test-phone-node", "Pixel 9 Pro")
        assertEquals(HealthCapability.REQUEST_CAPABILITY, request.getString("capability_type"))
        assertEquals(
            "com.samsung.android.app.shealth.REQUEST_CAPABILITY",
            request.getString("message_type"),
        )
        assertTrue(HealthCapability.isRequest(request))
        assertFalse(HealthCapability.isResponse(request))
        val vascularLoad =
            request.getJSONObject("tracker_feature").getJSONObject("vascular_load_feature")
        assertEquals(1002, vascularLoad.getInt("version"))
        assertTrue(vascularLoad.getBoolean("vascular_load_support"))
    }

    private fun watchCapability(
        category: Int? = 40001,
        version: Int? = 1001,
        support: Boolean? = true,
    ): JSONObject {
        val feature = JSONObject()
        if (version != null) feature.put("version", version)
        if (support != null) feature.put("vascular_load_support", support)
        return JSONObject().apply {
            if (category != null) put("category", category)
            put("tracker_feature", JSONObject().put("vascular_load_feature", feature))
        }
    }
}
