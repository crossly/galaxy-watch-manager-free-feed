package dev.ricky.galaxywatchmanagerfree.feature

import java.time.ZoneId
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class SleepAnalysisResultTest {
    private val fixture: JSONObject
        get() = JSONObject(javaClass.getResource("/health/sleep-local-analysis.json")!!.readText())

    @Test
    fun `pending captured night has a known interval but no invented zero sleep or efficiency`() {
        val session = SleepParser.sessions(listOf(fixture.getJSONObject("record"))).single()
        assertEquals(325, session.inBedMinutes)
        assertEquals(325, session.displayMinutes)
        assertFalse(session.hasSleepDuration)
        assertNull(session.efficiencyPercent)
        assertTrue(session.segments.isEmpty())
    }

    @Test
    fun `verified half minute result produces all four stages and real sleep duration`() {
        val input = fixture
        val original = SleepParser.sessions(listOf(input.getJSONObject("record"))).single()
        val session = SleepAnalysisResult.apply(original, input.getJSONObject("result"))
        assertEquals(301, session.asleepMinutes)
        assertEquals(318, session.inBedMinutes)
        assertEquals(95, session.efficiencyPercent)
        assertEquals(
            mapOf(
                SleepParser.Stage.LIGHT to 130,
                SleepParser.Stage.DEEP to 86,
                SleepParser.Stage.REM to 85,
                SleepParser.Stage.AWAKE to 17,
            ),
            session.stageMinutes,
        )
        assertEquals(original.endMillis, session.recordedEndMillis)
        assertEquals(61, session.segments.size)
        assertEquals(SleepAnalysisResult.SOURCE, session.analysisSource)
        assertEquals(session, SleepParser.decode(SleepParser.encode(session)))
    }

    @Test
    fun `projection uses local analysis only when received stage records are absent`() {
        val input = fixture
        val record = input.getJSONObject("record")
        val source = SleepParser.sessions(listOf(record)).single()
        val local = SleepAnalysisResult.apply(source, input.getJSONObject("result"))
        val store = HealthRecordStore()
        val now = source.endMillis + 60_000
        store.merge(mapOf(SleepParser.MODULE_SLEEP to listOf(record)), now)
        val zone = ZoneId.of("Asia/Shanghai")
        val unresolved = HealthDataProjection.build(store, now, zone)
        assertTrue(unresolved.sleepHistory.isEmpty())
        val resolved = HealthDataProjection.build(store, now, zone, mapOf(source.id to local))
        assertEquals(301, resolved.sleepHistory["2026-10-28"])
        assertEquals(local, resolved.sleepSessions.single())
        store.merge(
            mapOf(
                SleepParser.MODULE_SLEEP_STAGE_LEGACY to
                    listOf(
                        JSONObject()
                            .put("datauuid", "watch-stage")
                            .put("sleep_id", source.id)
                            .put("start_time", source.startMillis)
                            .put("end_time", source.endMillis)
                            .put("stage", 40003)
                    )
            ),
            now,
        )
        val received =
            HealthDataProjection.build(store, now, zone, mapOf(source.id to local))
                .sleepSessions
                .single()
        assertNull(received.analysisSource)
        assertEquals(325, received.stageMinutes[SleepParser.Stage.DEEP])
    }

    @Test
    fun `invalid inferred stage never becomes an apparently complete report`() {
        val input = fixture
        val source = SleepParser.sessions(listOf(input.getJSONObject("record"))).single()
        input.getJSONObject("result").getJSONArray("stages").getJSONArray(0).put(1, 99)
        assertTrue(
            runCatching { SleepAnalysisResult.apply(source, input.getJSONObject("result")) }
                .isFailure
        )
    }

    @Test
    fun `analysis cache export preserves detached history and original result fields`() {
        val earlier =
            SleepParser.Session(
                startMillis = 1_700_000_000_000L,
                endMillis = 1_700_003_600_000L,
                segments = emptyList(),
                efficiency = 90,
                score = null,
                reportedSleepMinutes = 54,
                id = "earlier-night",
                analysisSource = "local-engine/v1",
            )
        val later =
            earlier.copy(
                startMillis = earlier.startMillis + 86_400_000L,
                endMillis = earlier.endMillis + 86_400_000L,
                id = "later-night",
                analysisSource = "local-engine/v2",
            )
        val encodedEarlier = JSONObject(SleepParser.encode(earlier)).put("model_revision", 1)
        val values =
            linkedMapOf(
                "earlier-key" to encodedEarlier.toString(),
                "later-key" to SleepParser.encode(later),
            )
        val exported = LocalSleepAnalyzer.retainedResults(values)
        values.clear()
        assertEquals(setOf("earlier-key", "later-key"), exported.keys().asSequence().toSet())
        val first = exported.getJSONObject("earlier-key")
        assertEquals(earlier, SleepParser.decode(first.toString()))
        assertEquals(1, first.getInt("model_revision"))
        assertEquals(later, SleepParser.decode(exported.getJSONObject("later-key").toString()))
    }

    @Test
    fun `analysis cache export skips preference bookkeeping and unreadable values`() {
        val session =
            SleepParser.Session(
                startMillis = 1_700_000_000_000L,
                endMillis = 1_700_003_600_000L,
                segments = emptyList(),
                efficiency = null,
                score = null,
                reportedSleepMinutes = 54,
                id = "cached-night",
            )
        val exported =
            LocalSleepAnalyzer.retainedResults(
                linkedMapOf(
                    "cached-key" to SleepParser.encode(session),
                    "device_cache_initialized" to true,
                    "legacy-key" to "not-json",
                )
            )
        assertEquals(setOf("cached-key"), exported.keys().asSequence().toSet())
        assertEquals(session, SleepParser.decode(exported.getJSONObject("cached-key").toString()))
    }

    @Test
    fun `raw sensor rows survive record store restart instead of being silently dropped`() {
        val record = fixture.getJSONObject("record")
        val raw =
            JSONObject()
                .put("datauuid", "raw-night")
                .put("sleep_uuid", "pending-night")
                .put("data", "test-payload")
                .put("create_time", record.getLong("end_time"))
        val store = HealthRecordStore()
        store.merge(
            mapOf(
                SleepParser.MODULE_SLEEP to listOf(record),
                SleepParser.MODULE_SLEEP_RAW to listOf(raw),
            ),
            record.getLong("end_time"),
        )
        val restored = HealthRecordStore()
        restored.restore(store.encode(), record.getLong("end_time"))
        assertEquals(
            "test-payload",
            restored.records(SleepParser.MODULE_SLEEP_RAW).single().getString("data"),
        )
    }
}
