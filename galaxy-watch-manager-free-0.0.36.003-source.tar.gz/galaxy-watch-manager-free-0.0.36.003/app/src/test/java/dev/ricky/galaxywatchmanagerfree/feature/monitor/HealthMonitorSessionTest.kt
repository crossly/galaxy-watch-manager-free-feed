package dev.ricky.galaxywatchmanagerfree.feature.monitor

import dev.ricky.galaxywatchmanagerfree.R
import kotlinx.coroutines.test.runTest
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class HealthMonitorSessionTest {
    @Test
    fun `BP calibration opens official calibration flow without accepting terms or writing readings`() =
        runTest {
            val sent = mutableListOf<Pair<String, JSONObject>>()
            val monitor =
                HealthMonitorSession(
                    this,
                    { path, body ->
                        sent.add(path to body)
                        true
                    },
                )
            monitor.receive("/plain_connection", """{"action":"connection"}""".toByteArray())
            sent.clear()
            assertTrue(monitor.startBpCalibration())
            val packet = sent.single()
            val message = HealthMonitorProtocol.decode(packet.second)
            assertEquals("/991", packet.first)
            assertEquals("do_calibration", message.action)
            assertEquals(
                "com.samsung.wearable.app.health.samd.bp.measuring",
                packet.second.getString("receiver"),
            )
            assertEquals(0, message.data.length())
            assertFalse(monitor.state.value.bpActivated)
            assertNull(monitor.state.value.lastBp)
            monitor.disconnect()
        }

    @Test
    fun `BP calibration cannot send before the transport is ready`() = runTest {
        val sent = mutableListOf<Pair<String, JSONObject>>()
        val monitor =
            HealthMonitorSession(
                this,
                { path, body ->
                    sent.add(path to body)
                    true
                },
            )

        assertFalse(monitor.startBpCalibration())
        assertTrue(sent.isEmpty())
        assertEquals(R.string.monitor_connection_unavailable, monitor.state.value.error?.resource)
    }

    @Test
    fun `BP calibration does not invoke remote_intent_rpc and only communicates via measuring channel`() =
        runTest {
            var launches = 0
            val sent = mutableListOf<Pair<String, JSONObject>>()
            val monitor =
                HealthMonitorSession(
                    this,
                    send = { path, body ->
                        sent.add(path to body)
                        true
                    },
                    launchRemoteActivity = { _, _, _, _, _ ->
                        launches++
                        true
                    },
                )
            monitor.receive("/plain_connection", """{"action":"connection"}""".toByteArray())
            sent.clear()

            assertTrue(monitor.startBpCalibration())
            assertEquals(0, launches)
            val packet = sent.single()
            assertEquals("/991", packet.first)
            val message = HealthMonitorProtocol.decode(packet.second)
            assertEquals("do_calibration", message.action)
            assertEquals(
                "com.samsung.wearable.app.health.samd.bp.measuring",
                packet.second.getString("receiver"),
            )
            monitor.disconnect()
        }

    @Test
    fun `BP calibration 3-round workflow orchestrates full lifecycle`() = runTest {
        val sent = mutableListOf<Pair<String, JSONObject>>()
        val monitor =
            HealthMonitorSession(
                this,
                send = { path, body ->
                    sent.add(path to body)
                    true
                },
            )
        monitor.receive("/plain_connection", """{"action":"connection"}""".toByteArray())
        sent.clear()

        // 1. Start Workflow -> sends prepare_calibration (round 1)
        assertTrue(monitor.startBpCalibrationWorkflow())
        assertEquals(BpCalibrationStep.Preparing(1), monitor.state.value.bpCalibrationStep)
        val p1 = sent.removeAt(0)
        assertEquals("/991", p1.first)
        val m1 = HealthMonitorProtocol.decode(p1.second)
        assertEquals("prepare_calibration", m1.action)

        // 2. Start Measurement -> sends start_calibration (round 1)
        assertTrue(monitor.startBpCalibrationMeasurement())
        assertEquals(BpCalibrationStep.Measuring(1), monitor.state.value.bpCalibrationStep)
        val p2 = sent.removeAt(0)
        assertEquals("/991", p2.first)
        val m2 = HealthMonitorProtocol.decode(p2.second)
        assertEquals("start_calibration", m2.action)

        // 3. Watch completes PPG sampling and returns datauuid and hr
        monitor.receive(
            "/991",
            BpTestPackets.calibrationResponse(
                action = "start_calibration",
                result = "success",
                data = JSONObject().put("datauuid", "uuid-round-1").put("hr", 72),
            ),
        )
        val waitingStep1 = monitor.state.value.bpCalibrationStep
        assertTrue(waitingStep1 is BpCalibrationStep.WaitingCuffInput)
        val cuff1 = waitingStep1 as BpCalibrationStep.WaitingCuffInput
        assertEquals(1, cuff1.round)
        assertEquals("uuid-round-1", cuff1.dataUuid)
        assertEquals(72, cuff1.heartRate)

        // 4. Submit cuff input (120/80) -> sends update_calibration
        assertTrue(monitor.submitBpCalibrationCuff(120, 80))
        assertEquals(BpCalibrationStep.Submitting(1), monitor.state.value.bpCalibrationStep)
        val p3 = sent.removeAt(0)
        val m3 = HealthMonitorProtocol.decode(p3.second)
        assertEquals("update_calibration", m3.action)
        assertEquals(120, m3.data.getInt("ref_systolic"))
        assertEquals(80, m3.data.getInt("ref_diastolic"))
        assertEquals(1, m3.data.getInt("nth"))
        assertEquals("uuid-round-1", m3.data.getString("datauuid"))

        // 5. Watch confirms update for round 1 -> auto advances to round 2 prepare
        monitor.receive(
            "/991",
            BpTestPackets.calibrationResponse(action = "update_calibration", result = "success"),
        )
        assertEquals(BpCalibrationStep.Preparing(2), monitor.state.value.bpCalibrationStep)
        val p4 = sent.removeAt(0)
        val m4 = HealthMonitorProtocol.decode(p4.second)
        assertEquals("prepare_calibration", m4.action)

        // Repeat for round 2
        assertTrue(monitor.startBpCalibrationMeasurement())
        monitor.receive(
            "/991",
            BpTestPackets.calibrationResponse(
                action = "start_calibration",
                result = "success",
                data = JSONObject().put("datauuid", "uuid-round-2").put("hr", 70),
            ),
        )
        sent.clear()
        assertTrue(monitor.submitBpCalibrationCuff(122, 82))
        monitor.receive(
            "/991",
            BpTestPackets.calibrationResponse(action = "update_calibration", result = "success"),
        )
        assertEquals(BpCalibrationStep.Preparing(3), monitor.state.value.bpCalibrationStep)
        sent.clear()

        // Round 3
        assertTrue(monitor.startBpCalibrationMeasurement())
        monitor.receive(
            "/991",
            BpTestPackets.calibrationResponse(
                action = "start_calibration",
                result = "success",
                data = JSONObject().put("datauuid", "uuid-round-3").put("hr", 71),
            ),
        )
        sent.clear()
        assertTrue(monitor.submitBpCalibrationCuff(119, 79))
        sent.clear()

        // Watch confirms update for round 3 -> phone requests initial_calibration merge
        monitor.receive(
            "/991",
            BpTestPackets.calibrationResponse(action = "update_calibration", result = "success"),
        )
        val pFinal = sent.removeAt(0)
        val mFinal = HealthMonitorProtocol.decode(pFinal.second)
        assertTrue(mFinal.action == "initial_calibration" || mFinal.action == "re_calibration")
        assertEquals("complete", mFinal.data.getString("status"))

        // Watch completes native algorithm merge and confirms
        monitor.receive(
            "/991",
            BpTestPackets.calibrationResponse(
                action = mFinal.action,
                result = "success",
                data = JSONObject().put("calibration_time", System.currentTimeMillis()),
            ),
        )
        assertEquals(BpCalibrationStep.Completed, monitor.state.value.bpCalibrationStep)
        monitor.resetBpCalibrationStep()
        assertEquals(BpCalibrationStep.Idle, monitor.state.value.bpCalibrationStep)
        monitor.disconnect()
    }

    @Test
    fun `BP calibration cancels cleanly when requested`() = runTest {
        val sent = mutableListOf<Pair<String, JSONObject>>()
        val monitor =
            HealthMonitorSession(
                this,
                send = { path, body ->
                    sent.add(path to body)
                    true
                },
            )
        monitor.receive("/plain_connection", """{"action":"connection"}""".toByteArray())
        sent.clear()

        assertTrue(monitor.startBpCalibrationWorkflow())
        assertEquals(BpCalibrationStep.Preparing(1), monitor.state.value.bpCalibrationStep)
        sent.clear()

        assertTrue(monitor.cancelBpCalibration())
        assertEquals(BpCalibrationStep.Idle, monitor.state.value.bpCalibrationStep)
        val packet = sent.single()
        val message = HealthMonitorProtocol.decode(packet.second)
        assertEquals("cancel_calibration", message.action)
        monitor.disconnect()
    }

    @Test
    fun `queued activation requests do not confirm the monitor connection`() = runTest {
        val monitor = HealthMonitorSession(backgroundScope, { _, _ -> true })
        assertTrue(monitor.activateEcg())
        assertEquals(HealthMonitorSession.Connection.CONNECTING, monitor.state.value.connection)
        assertTrue(monitor.activateBp())
        assertEquals(HealthMonitorSession.Connection.CONNECTING, monitor.state.value.connection)
        assertFalse(monitor.state.value.ecgActivated)
        assertFalse(monitor.state.value.bpActivated)
        assertEquals(0, monitor.state.value.receivedCount)
        monitor.receive("/plain_connection", """{"action":"connection"}""".toByteArray())
        assertEquals(HealthMonitorSession.Connection.READY, monitor.state.value.connection)
        monitor.disconnect()
    }

    @Test
    fun `BP measurement opens the measuring endpoint without changing calibration or claiming a result`() =
        runTest {
            val sent = mutableListOf<Pair<String, JSONObject>>()
            val monitor =
                HealthMonitorSession(
                    this,
                    { path, body ->
                        sent.add(path to body)
                        true
                    },
                )
            assertFalse(monitor.startBpMeasurement())
            assertTrue(sent.isEmpty())
            monitor.receive("/plain_connection", """{"action":"connection"}""".toByteArray())
            monitor.receive("/991", BpTestPackets.information(System.currentTimeMillis()))
            sent.clear()
            assertTrue(monitor.startBpMeasurement())
            val packet = sent.single()
            assertEquals("/991", packet.first)
            assertEquals(
                "com.samsung.wearable.app.health.samd.bp.measuring",
                packet.second.getString("receiver"),
            )
            val message = HealthMonitorProtocol.decode(packet.second)
            assertEquals("do_measure", message.action)
            assertEquals(0, message.data.length())
            assertNull(monitor.state.value.lastBp)
            assertFalse(monitor.state.value.bpActivated)
            monitor.disconnect()
        }

    @Test
    fun `BP measurement reports a transport failure and cannot run after disconnect`() = runTest {
        val monitor = HealthMonitorSession(this, { _, _ -> false })
        monitor.receive("/plain_connection", """{"action":"connection"}""".toByteArray())
        assertFalse(monitor.startBpMeasurement())
        monitor.disconnect()
        assertFalse(monitor.startBpMeasurement())
    }

    @Test
    fun `failed ECG information response uses an ECG-specific error`() = runTest {
        val monitor = HealthMonitorSession(this, { _, _ -> true })
        monitor.receive("/plain_connection", """{"action":"connection"}""".toByteArray())
        val packet =
            HealthMonitorProtocol.envelope(
                "RESPONSE",
                "com.samsung.wearable.app.health.samd.ecg.common",
                "com.samsung.mobile.app.health.samd.ecg.common",
                101,
                "MESSAGE",
                JSONObject()
                    .put("action", "information")
                    .put("result", "fail")
                    .put("data", JSONObject()),
            )
        monitor.receive("/992", packet.toString().toByteArray())
        assertEquals(
            R.string.monitor_ecg_information_unconfirmed,
            monitor.state.value.error?.resource,
        )
        monitor.disconnect()
    }

    @Test
    fun `sync confirmation echoes job id only after the measurement has been saved`() = runTest {
        var saved = false
        val sent = mutableListOf<Pair<String, JSONObject>>()
        val monitor =
            HealthMonitorSession(
                this,
                { path, body ->
                    assertTrue(saved)
                    sent.add(path to body)
                    true
                },
                onBpReceived = {
                    saved = true
                    true
                },
            )
        val payload =
            JSONObject()
                .put("message_info", JSONObject().put("action", "SYNC_DATA").put("id", 23))
                .put(
                    "data",
                    org.json
                        .JSONArray()
                        .put(
                            JSONObject()
                                .put("datauuid", "bp")
                                .put("start_time", 1_793_000_000_000L)
                                .put("systolic", 118)
                                .put("diastolic", 76)
                        ),
                )
        monitor.receiveSync(HealthMonitorProtocol.Channel.BP, payload)
        val response = sent.single().second
        assertEquals("DATA", response.getString("type"))
        val info = HealthMonitorProtocol.decode(response).body.getJSONObject("message_info")
        assertEquals(23, info.getInt("id"))
        assertEquals("SUCCESS", info.getString("result"))
    }

    @Test
    fun `empty named BP tables are not mistaken for invalid measurements`() = runTest {
        val sent = mutableListOf<Pair<String, JSONObject>>()
        val monitor =
            HealthMonitorSession(
                this,
                { path, body ->
                    sent.add(path to body)
                    true
                },
            )
        val payload =
            JSONObject()
                .put("message_info", JSONObject().put("action", "SYNC_DATA").put("id", 18))
                .put(
                    "data",
                    org.json
                        .JSONArray()
                        .put(JSONObject().put("com.samsung.health.bp", org.json.JSONArray()))
                        .put(
                            JSONObject()
                                .put("com.samsung.health.bp.configuration", org.json.JSONArray())
                        ),
                )
        monitor.receiveSync(HealthMonitorProtocol.Channel.BP, payload)
        assertEquals("SUCCESS", HealthMonitorProtocol.decode(sent.single().second).result)
        assertNull(monitor.state.value.lastBp)
    }

    @Test
    fun `unsaved measurement is never acknowledged as successful`() = runTest {
        val sent = mutableListOf<Pair<String, JSONObject>>()
        val monitor =
            HealthMonitorSession(
                this,
                { path, body ->
                    sent.add(path to body)
                    true
                },
                onBpReceived = { false },
            )
        val payload =
            JSONObject()
                .put("message_info", JSONObject().put("action", "SYNC_DATA").put("id", 19))
                .put(
                    "data",
                    org.json
                        .JSONArray()
                        .put(
                            JSONObject()
                                .put("datauuid", "bp")
                                .put("start_time", 1_793_000_000_000L)
                                .put("systolic", 118)
                                .put("diastolic", 76)
                        ),
                )
        monitor.receiveSync(HealthMonitorProtocol.Channel.BP, payload)
        assertTrue(sent.isEmpty())
        assertNotNull(monitor.state.value.error)
    }

    @Test
    fun `watch reconnect request triggers transport handshake without declaring ready or inventing a profile`() =
        runTest {
            val sent = mutableListOf<Pair<String, JSONObject>>()
            val monitor =
                HealthMonitorSession(
                    this,
                    { path, body ->
                        sent.add(path to body)
                        true
                    },
                )
            repeat(8) {
                monitor.receive(
                    "/992c",
                    """{"type":"request_connection","data":""}""".toByteArray(),
                )
            }
            assertEquals(listOf(HealthMonitorProtocol.PLAIN_CONNECTION), sent.map { it.first })
            assertEquals(HealthMonitorSession.Connection.CONNECTING, monitor.state.value.connection)
            assertFalse(monitor.state.value.ecgActivated)
            monitor.disconnect()
        }

    @Test
    fun `successful plain handshake requests channel connection without changing terms or birth date`() =
        runTest {
            val sent = mutableListOf<Pair<String, JSONObject>>()
            val monitor =
                HealthMonitorSession(
                    this,
                    { path, body ->
                        sent.add(path to body)
                        true
                    },
                )
            monitor.connect()
            monitor.receive("/plain_connection", """{"action":"connection"}""".toByteArray())
            val messages =
                sent
                    .filter { it.first == "/991" || it.first == "/992" }
                    .map { HealthMonitorProtocol.decode(it.second) }
            assertTrue(messages.isNotEmpty())
            assertTrue(messages.all { it.action == "connection" })
            assertFalse(monitor.state.value.ecgActivated)
            monitor.disconnect()
        }

    @Test
    fun `disable control frame on channel 994 confirms handshake and transitions connection to READY`() =
        runTest {
            val sent = mutableListOf<Pair<String, JSONObject>>()
            val monitor =
                HealthMonitorSession(
                    this,
                    { path, body ->
                        sent.add(path to body)
                        true
                    },
                )
            monitor.connect()
            assertEquals(HealthMonitorSession.Connection.CONNECTING, monitor.state.value.connection)

            // Watch sends 994c {"type":"disable"} upon entering cryptography READY
            monitor.receive("/994c", """{"type":"disable"}""".toByteArray())

            assertEquals(HealthMonitorSession.Connection.READY, monitor.state.value.connection)
            assertNull(monitor.state.value.error)
            val connectionRequests =
                sent
                    .filter { it.first == "/991" || it.first == "/992" }
                    .map { HealthMonitorProtocol.decode(it.second) }
            assertEquals(2, connectionRequests.size)
            assertTrue(connectionRequests.all { it.action == "connection" })
            monitor.disconnect()
        }

    @Test
    fun `watch initiated information request acknowledges with information response and enters READY`() =
        runTest {
            val sent = mutableListOf<Pair<String, JSONObject>>()
            val monitor =
                HealthMonitorSession(
                    this,
                    { path, body ->
                        sent.add(path to body)
                        true
                    },
                )
            monitor.connect()

            val watchInfo =
                JSONObject()
                    .put("device_name", "Galaxy Watch6")
                    .put("app_version", "1.5.1.022")
                    .put("tnc", true)
                    .put("wrist_position", "left")

            val requestPacket =
                HealthMonitorProtocol.envelope(
                    message = "REQUEST",
                    sender = "com.samsung.wearable.app.health.samd.ecg.common",
                    receiver = "com.samsung.mobile.app.health.samd.ecg.common",
                    sequence = 42,
                    type = "MESSAGE",
                    body =
                        JSONObject()
                            .put("type", "request")
                            .put("action", "information")
                            .put("data", watchInfo)
                            .put("result", ""),
                )

            monitor.receive("/992", requestPacket.toString().toByteArray())

            assertEquals(HealthMonitorSession.Connection.READY, monitor.state.value.connection)
            val infoStr = monitor.state.value.information[HealthMonitorProtocol.Channel.ECG]
            assertNotNull(infoStr)
            val parsed = JSONObject(infoStr!!)
            assertEquals("Galaxy Watch6", parsed.getString("device_name"))

            val responseSent =
                sent.firstOrNull {
                    it.first == "/992" &&
                        HealthMonitorProtocol.decode(it.second).action == "information"
                }
            assertNotNull(responseSent)
            val decodedResp = HealthMonitorProtocol.decode(responseSent!!.second)
            assertEquals("RESPONSE", decodedResp.message)
            assertEquals("information", decodedResp.action)
            assertEquals("success", decodedResp.result)
            assertEquals(42, decodedResp.sequence)
            monitor.disconnect()
        }

    @Test
    fun `activateBp sends terms and conditions on BP channel and marks bpActivated when acknowledged`() =
        runTest {
            val sent = mutableListOf<Pair<String, JSONObject>>()
            val monitor =
                HealthMonitorSession(
                    this,
                    { path, body ->
                        sent.add(path to body)
                        true
                    },
                )
            monitor.receive("/plain_connection", """{"action":"connection"}""".toByteArray())
            sent.clear()

            monitor.activateBp()
            val packet = sent.single()
            assertEquals("/991", packet.first)
            val message = HealthMonitorProtocol.decode(packet.second)
            assertEquals("terms_and_condition", message.action)
            assertEquals("complete", message.data.getString("status"))

            val responsePacket =
                HealthMonitorProtocol.envelope(
                    message = "RESPONSE",
                    sender = "com.samsung.wearable.app.health.samd.bp.common",
                    receiver = "com.samsung.mobile.app.health.samd.bp.common",
                    sequence = message.sequence,
                    type = "MESSAGE",
                    body =
                        JSONObject()
                            .put("type", "response")
                            .put("action", "terms_and_condition")
                            .put("data", JSONObject())
                            .put("result", "success"),
                )

            monitor.receive("/991", responsePacket.toString().toByteArray())
            assertTrue(monitor.state.value.bpActivated)
            monitor.disconnect()
        }

    @Test
    fun `delayed start_calibration after cancel is ignored and does not wake to WaitingCuffInput`() =
        runTest {
            val sent = mutableListOf<Pair<String, JSONObject>>()
            val monitor =
                HealthMonitorSession(
                    this,
                    { path, body ->
                        sent.add(path to body)
                        true
                    },
                )
            monitor.receive("/plain_connection", """{"action":"connection"}""".toByteArray())
            sent.clear()

            assertTrue(monitor.startBpCalibrationWorkflow())
            assertTrue(monitor.startBpCalibrationMeasurement())
            assertEquals(BpCalibrationStep.Measuring(1), monitor.state.value.bpCalibrationStep)

            // User cancels calibration while measuring
            assertTrue(monitor.cancelBpCalibration())
            assertEquals(BpCalibrationStep.Idle, monitor.state.value.bpCalibrationStep)

            // Watch delivers delayed start_calibration SUCCESS
            monitor.receive(
                "/991",
                BpTestPackets.calibrationResponse(
                    action = "start_calibration",
                    result = "success",
                    data = JSONObject().put("datauuid", "stale-uuid").put("hr", 75),
                ),
            )
            // Must remain Idle, not wake up to WaitingCuffInput
            assertEquals(BpCalibrationStep.Idle, monitor.state.value.bpCalibrationStep)
            monitor.disconnect()
        }

    @Test
    fun `delayed cancel_calibration after restarting workflow does not reset Preparing to Idle`() =
        runTest {
            val sent = mutableListOf<Pair<String, JSONObject>>()
            val monitor =
                HealthMonitorSession(
                    this,
                    { path, body ->
                        sent.add(path to body)
                        true
                    },
                )
            monitor.receive("/plain_connection", """{"action":"connection"}""".toByteArray())
            sent.clear()

            // Workflow 1 started and cancelled
            assertTrue(monitor.startBpCalibrationWorkflow())
            assertTrue(monitor.cancelBpCalibration())
            assertEquals(BpCalibrationStep.Idle, monitor.state.value.bpCalibrationStep)

            // Workflow 2 started afresh
            assertTrue(monitor.startBpCalibrationWorkflow())
            assertEquals(BpCalibrationStep.Preparing(1), monitor.state.value.bpCalibrationStep)

            // Watch delivers delayed cancel_calibration confirmation from Workflow 1
            monitor.receive(
                "/991",
                BpTestPackets.calibrationResponse(action = "cancel_calibration", result = "success"),
            )
            // Must stay in Preparing(1), not get reset to Idle
            assertEquals(BpCalibrationStep.Preparing(1), monitor.state.value.bpCalibrationStep)
            monitor.disconnect()
        }
}
