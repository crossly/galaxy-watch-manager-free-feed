package dev.ricky.galaxywatchmanagerfree.feature

import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Test

class HealthDataProjectionTest {

    private val zone = ZoneId.of("Asia/Shanghai")
    private val now =
        ZonedDateTime.of(LocalDate.of(2026, 10, 27), java.time.LocalTime.of(21, 30), zone)
            .toInstant()
            .toEpochMilli()

    private fun ts(day: Int, hour: Int, minute: Int): Long =
        ZonedDateTime.of(LocalDate.of(2026, 10, day), java.time.LocalTime.of(hour, minute), zone)
            .toInstant()
            .toEpochMilli()

    @Test
    fun `workout history retains more than forty sessions and older synced workouts`() {
        val records =
            (0 until 65).map { index ->
                val start = now - (index + 1) * 86_400_000L
                JSONObject()
                    .put("datauuid", "workout-$index")
                    .put("start_time", start)
                    .put("duration", 600_000L)
                    .put("exercise_type", if (index % 2 == 0) 11007 else 1001)
            }
        val store = HealthRecordStore()
        store.merge(mapOf("com.samsung.shealth.exercise" to records), now)
        val restored = HealthRecordStore()
        restored.restore(store.encode(), now)
        val sessions = HealthDataProjection.build(restored, now, zone).exercises
        assertEquals(65, sessions.size)
        assertEquals("workout-64", sessions.last().id)
    }

    @Test
    fun `routine records are projected alongside their individual activities`() {
        val store = HealthRecordStore()
        store.merge(
            mapOf(
                "com.samsung.shealth.exercise.routine" to
                    listOf(
                        JSONObject()
                            .put("datauuid", "routine-1")
                            .put("start_time", ts(27, 9, 0))
                            .put("end_time", ts(27, 9, 40))
                            .put("total_duration", 2_400_000L)
                            .put("total_calorie", 240)
                            .put("title", "Morning routine")
                    )
            ),
            now,
        )
        val sessions = HealthDataProjection.build(store, now, zone).exercises
        assertEquals(1, sessions.size)
        assertEquals(51005, sessions.single().typeCode)
        assertEquals(40, sessions.single().durationMinutes)
        assertEquals(240, sessions.single().calories)
    }

    @Test
    fun `missing interval measurements remain unknown and summary zero is a real zero`() {
        val store = HealthRecordStore()
        store.merge(
            mapOf(
                HealthStepParser.MODULE_STEP_COUNT to
                    listOf(
                        JSONObject()
                            .put("datauuid", "steps-only")
                            .put("start_time", ts(27, 9, 0))
                            .put("count", 10)
                    )
            ),
            now,
        )
        val partial = HealthDataProjection.build(store, now, zone)
        org.junit.Assert.assertNull(partial.calories)
        org.junit.Assert.assertNull(partial.distanceMeters)
        store.merge(
            mapOf(
                HealthStepParser.MODULE_DAY_SUMMARY to
                    listOf(
                        JSONObject()
                            .put("datauuid", "zero")
                            .put("day_time", ts(27, 0, 0))
                            .put("update_time", ts(27, 12, 0))
                            .put("calorie", 0)
                            .put("distance", 0)
                    )
            ),
            now,
        )
        val summary = HealthDataProjection.build(store, now, zone)
        assertEquals(0f, summary.calories!!, 0.001f)
        assertEquals(0f, summary.distanceMeters!!, 0.001f)
    }

    @Test
    fun `failed cache restore preserves the last readable record set`() {
        val store = HealthRecordStore()
        store.merge(
            mapOf(
                "com.samsung.shealth.stress" to
                    listOf(
                        JSONObject()
                            .put("datauuid", "known")
                            .put("score", 35)
                            .put("start_time", ts(27, 9, 0))
                    )
            ),
            now,
        )
        assertEquals(false, store.restore("{broken", now))
        assertEquals(35, HealthDataProjection.build(store, now, zone).stress)
    }

    @Test
    fun `long-name records keep distinct identities and newest revisions after restore`() {
        val module = "com.samsung.health.exercise"
        fun record(start: Long, updated: Long, duration: Long) =
            JSONObject()
                .put("$module.start_time", start)
                .put("$module.update_time", updated)
                .put("$module.duration", duration)
                .put("$module.exercise_type", 1002)
        val store = HealthRecordStore()
        store.merge(
            mapOf(
                module to
                    listOf(
                        record(ts(27, 9, 0), ts(27, 9, 30), 600_000),
                        record(ts(27, 10, 0), ts(27, 10, 30), 1_200_000),
                    )
            ),
            now,
        )
        store.merge(mapOf(module to listOf(record(ts(27, 9, 0), ts(27, 9, 10), 60_000))), now)
        val restored = HealthRecordStore()
        restored.restore(store.encode(), now)
        val sessions = HealthDataProjection.build(restored, now, zone).exercises
        assertEquals(2, sessions.size)
        assertEquals(10, sessions.single { it.startMillis == ts(27, 9, 0) }.durationMinutes)
    }

    @Test
    fun `daily summary remains authoritative when only a partial interval arrives`() {
        val store = HealthRecordStore()
        store.merge(
            mapOf(
                HealthStepParser.MODULE_DAY_SUMMARY to
                    listOf(
                        JSONObject()
                            .put("datauuid", "summary")
                            .put("day_time", ts(27, 0, 0))
                            .put("update_time", ts(27, 12, 0))
                            .put("step_count", 6000)
                            .put("calorie", 300)
                            .put("distance", 4500)
                    )
            ),
            now,
        )
        store.merge(
            mapOf(
                HealthStepParser.MODULE_STEP_COUNT to
                    listOf(
                        JSONObject()
                            .put("datauuid", "partial")
                            .put("start_time", ts(27, 11, 0))
                            .put("end_time", ts(27, 11, 10))
                            .put("count", 100)
                            .put("calorie", 5)
                            .put("distance", 75)
                    )
            ),
            now,
        )

        val result = HealthDataProjection.build(store, now, zone)
        assertEquals(300f, result.calories!!, 0.001f)
        assertEquals(4500f, result.distanceMeters!!, 0.001f)
        assertEquals(6000, result.activityHistory["2026-10-27"]?.steps)
    }

    @Test
    fun `store encodes and restores complete record set across process boundary`() {
        val store = HealthRecordStore()
        val records =
            mapOf(
                HealthStepParser.MODULE_STEP_COUNT to
                    listOf(
                        JSONObject()
                            .put("datauuid", "s1")
                            .put("count", 150)
                            .put("start_time", ts(27, 9, 0))
                            .put("update_time", ts(27, 9, 10)),
                        JSONObject()
                            .put("datauuid", "s2")
                            .put("count", 250)
                            .put("start_time", ts(27, 10, 0))
                            .put("update_time", ts(27, 10, 10)),
                    ),
                "com.samsung.shealth.tracker.heart_rate" to
                    listOf(
                        JSONObject()
                            .put("datauuid", "h1")
                            .put("heart_rate", 72)
                            .put("start_time", ts(27, 9, 0)),
                        JSONObject()
                            .put("datauuid", "h2")
                            .put("heart_rate", 88)
                            .put("start_time", ts(27, 10, 0)),
                    ),
                "com.samsung.health.floors_climbed" to
                    listOf(
                        JSONObject()
                            .put("datauuid", "f1")
                            .put("floor", 3)
                            .put("start_time", ts(27, 9, 0))
                    ),
                "com.samsung.shealth.stress" to
                    listOf(
                        JSONObject()
                            .put("datauuid", "st1")
                            .put("score", 35)
                            .put("start_time", ts(27, 9, 0))
                    ),
            )
        store.merge(records, now)
        val encoded = store.encode()

        val restored = HealthRecordStore()
        restored.restore(encoded, now)

        val projected = HealthDataProjection.build(restored, now, zone)
        assertEquals(2, projected.heartRatePoints.size)
        assertEquals(80, projected.heartRatePoints.map { it.bpm }.average().toInt())
        assertEquals(2, projected.heartRateHistory.values.sumOf { it.size })
        assertEquals(88, projected.latestHeartRate!!.bpm)
        assertEquals(35, projected.stress)
        assertEquals(3, projected.floors)
        assertEquals(400, restored.todaySteps(now, zone).sumOf(HealthStepParser::recordSteps))
    }

    @Test
    fun `projection aggregates historical daily activity across multiple days`() {
        val store = HealthRecordStore()
        val records =
            mapOf(
                HealthStepParser.MODULE_STEP_COUNT to
                    listOf(
                        // Day 25: 1000 steps
                        JSONObject()
                            .put("datauuid", "d25_1")
                            .put("count", 1000)
                            .put("calorie", 50.0)
                            .put("distance", 700.0)
                            .put("start_time", ts(25, 10, 0)),
                        // Day 26: 2000 steps
                        JSONObject()
                            .put("datauuid", "d26_1")
                            .put("count", 2000)
                            .put("calorie", 100.0)
                            .put("distance", 1400.0)
                            .put("start_time", ts(26, 10, 0)),
                        // Day 27 (today): 3000 steps
                        JSONObject()
                            .put("datauuid", "d27_1")
                            .put("count", 3000)
                            .put("calorie", 150.0)
                            .put("distance", 2100.0)
                            .put("start_time", ts(27, 10, 0)),
                    )
            )
        store.merge(records, now)
        val projected = HealthDataProjection.build(store, now, zone)

        assertEquals(3, projected.activityHistory.size)
        assertEquals(1000, projected.activityHistory["2026-10-25"]?.steps)
        assertEquals(2000, projected.activityHistory["2026-10-26"]?.steps)
        assertEquals(3000, projected.activityHistory["2026-10-27"]?.steps)
        assertEquals(3000, projected.hours[10])
        assertEquals(2100.0f, projected.distanceMeters ?: 0f, 0.001f)
    }

    @Test
    fun `projection correctly parses target step preferences and recommendation`() {
        val store = HealthRecordStore()
        store.merge(
            mapOf(
                "com.samsung.shealth.service_preferences" to
                    listOf(
                        JSONObject()
                            .put("key", "target_steps")
                            .put("int_value", 8000)
                            .put("update_time", ts(27, 8, 0))
                    ),
                "com.samsung.shealth.tracker.pedometer_recommendation" to
                    listOf(
                        JSONObject().put("recommendation", 6000).put("update_time", ts(27, 8, 0))
                    ),
            ),
            now,
        )
        val projected = HealthDataProjection.build(store, now, zone)
        assertEquals(8000, projected.watchGoal)
        assertEquals(6000, projected.recommendedGoal)
    }

    @Test
    fun `long-name aliases share identity without mutating incoming rows`() {
        val module = "com.samsung.health.exercise"
        val aliased =
            JSONObject()
                .put("$module.datauuid", "shared")
                .put("$module.start_time", ts(27, 9, 0))
                .put("$module.update_time", ts(27, 9, 30))
                .put("duration", 600_000)
        val canonical =
            JSONObject()
                .put("datauuid", "shared")
                .put("start_time", ts(27, 9, 0))
                .put("update_time", ts(27, 10, 0))
                .put("duration", 1_200_000)
        assertEquals(HealthRecordStore.identity(aliased), HealthRecordStore.identity(canonical))

        val store = HealthRecordStore()
        store.merge(mapOf(module to listOf(aliased)), now)
        org.junit.Assert.assertTrue(aliased.has("$module.update_time"))
        org.junit.Assert.assertFalse(aliased.has("update_time"))
        store.merge(mapOf(module to listOf(canonical)), now)

        val restored = HealthRecordStore()
        restored.restore(store.encode(), now)
        val rows = restored.records(module)
        assertEquals(1, rows.size)
        assertEquals(1_200_000, rows.single().getLong("duration"))
    }

    @Test
    fun `alias metric revisions expand only the latest whole record`() {
        val newestModule = HealthMetric.HRV.moduleKeys.first()
        val olderModule = HealthMetric.HRV.moduleKeys.last()
        val old =
            JSONObject()
                .put("datauuid", "revised-hrv")
                .put("start_time", ts(27, 9, 0))
                .put("update_time", ts(27, 9, 1))
                .put(
                    "binning_data",
                    JSONArray()
                        .put(JSONObject().put("start_time", ts(27, 9, 0)).put("rmssd", 20))
                        .put(JSONObject().put("start_time", ts(27, 9, 10)).put("rmssd", 25)),
                )
        val new =
            JSONObject()
                .put("datauuid", "revised-hrv")
                .put("start_time", ts(27, 9, 0))
                .put("update_time", ts(27, 9, 2))
                .put(
                    "binning_data",
                    JSONArray().put(JSONObject().put("start_time", ts(27, 9, 10)).put("rmssd", 30)),
                )
        val store = HealthRecordStore()
        // The old revision in the later alias must not leave stale bins or override the new one.
        store.merge(mapOf(newestModule to listOf(new), olderModule to listOf(old)), now)

        val samples =
            HealthDataProjection.build(store, now, zone).metrics.getValue(HealthMetric.HRV)
        assertEquals(listOf(30f), samples.map { it.value })
    }

    @Test
    fun `basic date day summaries are grouped by their actual day`() {
        val store = HealthRecordStore()
        store.merge(
            mapOf(
                HealthStepParser.MODULE_DAY_SUMMARY to
                    listOf(
                        JSONObject()
                            .put("datauuid", "yesterday-summary")
                            .put("day_time", 20261026)
                            .put("update_time", ts(27, 8, 0))
                            .put("step_count", 1111)
                            .put("calorie", 50)
                            .put("distance", 700),
                        JSONObject()
                            .put("datauuid", "today-summary")
                            .put("day_time", 20261027)
                            .put("update_time", ts(27, 9, 0))
                            .put("step_count", 2222)
                            .put("calorie", 100)
                            .put("distance", 1400),
                    )
            ),
            now,
        )

        val projected = HealthDataProjection.build(store, now, zone)
        assertEquals(1111, projected.activityHistory["2026-10-26"]?.steps)
        assertEquals(2222, projected.activityHistory["2026-10-27"]?.steps)
        assertEquals(100f, projected.calories!!, 0.001f)
        assertEquals(1400f, projected.distanceMeters!!, 0.001f)
    }

    @Test
    fun `floors keep today valid zero distinct from empty history and missing counts`() {
        val module = "com.samsung.shealth.floors_climbed"
        val empty = HealthRecordStore()
        empty.merge(mapOf(module to emptyList()), now)
        assertEquals(-1, HealthDataProjection.build(empty, now, zone).floors)

        val historical = HealthRecordStore()
        historical.merge(
            mapOf(
                module to
                    listOf(
                        JSONObject()
                            .put("datauuid", "old-floors")
                            .put("start_time", ts(26, 9, 0))
                            .put("floor_count", 4)
                    )
            ),
            now,
        )
        assertEquals(-1, HealthDataProjection.build(historical, now, zone).floors)

        val unknown = HealthRecordStore()
        unknown.merge(
            mapOf(
                module to
                    listOf(
                        JSONObject()
                            .put("datauuid", "unknown-floors")
                            .put("start_time", ts(27, 9, 0))
                    )
            ),
            now,
        )
        assertEquals(-1, HealthDataProjection.build(unknown, now, zone).floors)

        val zero = HealthRecordStore()
        zero.merge(
            mapOf(
                module to
                    listOf(
                        JSONObject()
                            .put("datauuid", "zero-floors")
                            .put("start_time", ts(27, 9, 0))
                            .put("floor_count", 0)
                    )
            ),
            now,
        )
        assertEquals(0, HealthDataProjection.build(zero, now, zone).floors)
    }
}
