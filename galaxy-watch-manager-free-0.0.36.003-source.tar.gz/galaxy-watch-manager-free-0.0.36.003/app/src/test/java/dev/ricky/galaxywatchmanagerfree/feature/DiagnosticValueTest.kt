package dev.ricky.galaxywatchmanagerfree.feature

import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class DiagnosticValueTest {
    @Test
    fun `nested credentials health readings and notification contents are hidden`() {
        val value =
            JSONObject()
                .put("path", "/health")
                .put("data", JSONObject().put("access_token", "abc123").put("heart_rate", 73.125))
                .put("title", "private notification")
                .put("body", "encoded personal content")
                .put("title_raw", "raw title text")
                .put("text_raw", "raw text content")
        val formatted = DiagnosticValue.describe(value)
        assertFalse(formatted.contains("abc123"))
        assertFalse(formatted.contains("private notification"))
        assertFalse(formatted.contains("encoded personal content"))
        assertFalse(formatted.contains("raw title text"))
        assertFalse(formatted.contains("raw text content"))
        assertFalse(formatted.contains("73.125"))
        assertTrue(formatted.contains("heart_rate="))
        assertTrue(formatted.contains("path=/health"))
    }

    @Test
    fun `embedded health and notification values are masked in free text`() {
        val health =
            """{"datauuid":"synthetic-health-record","asleepMinutes":421,"efficiencyPercent":93.5,"heart_rate":58,"measurement":73.125}"""
        val formatted = DiagnosticValue.text("decode failed: $health path=/health")
        assertFalse(formatted.contains("synthetic-health-record"))
        assertFalse(formatted.contains("421"))
        assertFalse(formatted.contains("93.5"))
        assertFalse(formatted.contains("58"))
        assertFalse(formatted.contains("73.125"))
        assertTrue(formatted.contains("datauuid"))
        assertTrue(formatted.contains("path=/health"))

        val notification =
            """{"title":"synthetic private title","body":"synthetic private body","text":"synthetic message"}"""
        val masked = DiagnosticValue.text(notification)
        assertFalse(masked.contains("synthetic private title"))
        assertFalse(masked.contains("synthetic private body"))
        assertFalse(masked.contains("synthetic message"))
    }

    @Test
    fun `sensitive containers and unfinished strings do not expose their remaining contents`() {
        val health =
            """decode failed: {"segments":[{"stage":"deep","duration":421},{"stage":"rem","duration":87}],"path":"/health"}"""
        val masked = DiagnosticValue.text(health)
        assertFalse(masked.contains("deep"))
        assertFalse(masked.contains("421"))
        assertFalse(masked.contains("rem"))
        assertFalse(masked.contains("87"))
        assertTrue(masked.contains("segments"))
        assertTrue(masked.contains("/health"))

        val unfinished =
            DiagnosticValue.text("""decode failed: {"title":"synthetic private notification""")
        assertFalse(unfinished.contains("synthetic"))
        assertFalse(unfinished.contains("private"))
        assertFalse(unfinished.contains("notification"))
    }

    @Test
    fun `credential key fragments remain private without hiding diagnostic counters`() {
        val value =
            JSONObject()
                .put("accesstoken", "synthetic-compact-token")
                .put("sessioncookie", "synthetic-compact-cookie")
                .put("throughput", 128)
        for (output in
            listOf(DiagnosticValue.describe(value), DiagnosticValue.text(value.toString()))) {
            assertFalse(output.contains("synthetic-compact-token"))
            assertFalse(output.contains("synthetic-compact-cookie"))
            assertTrue(output.contains("throughput"))
            assertTrue(output.contains("128"))
        }
    }

    @Test
    fun `binary diagnostics retain size and fingerprint without dumping photo bytes`() {
        val bytes = "private photo bytes".toByteArray()
        val summary = DiagnosticValue.describe(mapOf("data" to bytes))
        assertTrue(summary.contains("size=${bytes.size}"))
        assertTrue(summary.contains("sha256="))
        assertFalse(summary.contains("private photo bytes"))
        assertEquals(summary, DiagnosticValue.describe(mapOf("data" to bytes)))
    }

    @Test
    fun `addresses and inline credentials are masked for every level`() {
        val safe =
            DiagnosticValue.text("peer=01:23:45:67:89:AB access_token=abc123 password=secret123")
        assertFalse(safe.contains("01:23:45:67:89:AB"))
        assertTrue(safe.contains("**:**:**:**:89:AB"))
        assertFalse(safe.contains("abc123"))
        assertFalse(safe.contains("secret123"))
    }

    @Test
    fun `bearer credentials are hidden even in unstructured errors`() {
        val safe =
            DiagnosticValue.text("request failed: Authorization: Bearer fixture-bearer-value")
        assertFalse(safe.contains("fixture-bearer-value"))
    }

    @Test
    fun `large and recursive values are bounded and marked`() {
        val recursive = mutableMapOf<String, Any>()
        recursive["self"] = recursive
        assertTrue(DiagnosticValue.describe(recursive).length < 200)
        val text = DiagnosticValue.text("x".repeat(100_000))
        assertTrue(text.length < DiagnosticValue.MAX_CHARS + 100)
        assertTrue(text.contains("truncated"))
        assertTrue(DiagnosticValue.describe((0..200).toList()).contains("count=201"))
    }
}
