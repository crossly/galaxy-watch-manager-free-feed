package dev.ricky.galaxywatchmanagerfree.ui.theme

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ThemePaletteTest {
    @Test
    fun eachAccentFamilyHasItsOwnCoordinatedHealthPalette() {
        val blue = paletteFor(LightScheme, false, AccentFamily.BLUE)
        val violet = paletteFor(LightScheme, false, AccentFamily.VIOLET)
        val mint = paletteFor(LightScheme, false, AccentFamily.MINT)

        assertNotEquals(blue.healthSteps, violet.healthSteps)
        assertNotEquals(violet.healthSteps, mint.healthSteps)
        assertNotEquals(blue.healthSleep, violet.healthSleep)
        assertNotEquals(violet.healthSleep, mint.healthSleep)
        assertNotEquals(blue.healthHeart, violet.healthHeart)
        assertNotEquals(violet.healthHeart, mint.healthHeart)
    }

    @Test
    fun healthRolesRemainDistinctInsideOneTheme() {
        val palette = paletteFor(DarkScheme, true, AccentFamily.MINT)
        val roles =
            setOf(
                palette.healthSteps,
                palette.healthHeart,
                palette.healthStress,
                palette.healthSleep,
                palette.healthOxygen,
                palette.healthTemperature,
                palette.healthRespiratory,
                palette.healthHrv,
            )
        assertEquals(8, roles.size)
        assertEquals(1f, palette.healthHeart.alpha)
        assertEquals(1f, palette.sleepDeep.alpha)
        assertNotEquals(palette.healthBloodPressure, palette.healthBloodPressureSecondary)
    }

    @Test
    fun wallpaperPaletteFollowsTheDynamicPrimaryHue() {
        val roseScheme = LightScheme.copy(primary = Color(0xFFC2185B))
        val tealScheme = LightScheme.copy(primary = Color(0xFF00796B))
        val rose = paletteFor(roseScheme, false, AccentFamily.SYSTEM)
        val teal = paletteFor(tealScheme, false, AccentFamily.SYSTEM)

        assertNotEquals(rose.healthSteps, teal.healthSteps)
        assertNotEquals(rose.healthSleep, teal.healthSleep)
        assertNotEquals(rose.healthStress, teal.healthStress)
    }

    @Test
    fun lightAndDarkRolesKeepUsableTonalSeparation() {
        val light = paletteFor(LightScheme, false, AccentFamily.BLUE)
        val dark = paletteFor(DarkScheme, true, AccentFamily.BLUE)

        assertTrue(dark.healthHeart.luminance() > light.healthHeart.luminance())
        assertTrue(dark.healthSteps.luminance() > light.healthSteps.luminance())
        assertTrue(dark.healthSleep.luminance() > light.healthSleep.luminance())
    }
}
