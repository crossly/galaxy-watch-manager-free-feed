package dev.ricky.galaxywatchmanagerfree.feature

import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class HeartRateLogTest {

    private val zone: ZoneId = ZoneId.of("Asia/Shanghai")
    private val day = LocalDate.of(2026, 10, 27)

    private fun millisOf(hour: Int, minute: Int = 0, dayOffset: Int = 0): Long =
        LocalDateTime.of(day.plusDays(dayOffset.toLong()), java.time.LocalTime.of(hour, minute))
            .atZone(zone)
            .toInstant()
            .toEpochMilli()

    private fun record(ts: Long, bpm: Int): JSONObject =
        JSONObject().put("start_time", ts).put("heart_rate", bpm)

    @Test
    fun `records become points and invalid values are dropped`() {
        val points =
            HeartRateLog.pointsFromRecords(
                listOf(
                    record(millisOf(9), 68),
                    record(millisOf(10), 71),
                    record(0L, 70),
                    record(millisOf(11), 250),
                    record(millisOf(12), 10),
                )
            )
        assertEquals(listOf(68, 71), points.map { it.bpm })
    }

    @Test
    fun `long field names are accepted`() {
        val record =
            JSONObject()
                .put("com.samsung.health.heart_rate.start_time", millisOf(8))
                .put("com.samsung.health.heart_rate.heart_rate", 64)
        assertEquals(64, HeartRateLog.pointsFromRecords(listOf(record)).single().bpm)
    }

    @Test
    fun `merge keeps newest 24h sorted and deduplicated`() {
        val now = millisOf(20)
        val existing =
            listOf(HeartRateLog.Point(millisOf(9), 70), HeartRateLog.Point(millisOf(19), 80))
        val incoming =
            listOf(
                HeartRateLog.Point(millisOf(9), 70), // 重复
                HeartRateLog.Point(millisOf(12), 75),
                HeartRateLog.Point(millisOf(20, 0, -2), 90), // 超期
            )
        val merged = HeartRateLog.merge(existing, incoming, now)
        assertEquals(listOf(70, 75, 80), merged.map { it.bpm })
        assertTrue(merged.zipWithNext().all { (a, b) -> a.ts <= b.ts })
    }

    @Test
    fun `merge caps the number of retained points`() {
        val now = millisOf(20)
        val many = (0 until 50).map { HeartRateLog.Point(now - it * 60_000L, 60 + it % 30) }
        val merged = HeartRateLog.merge(emptyList(), many, now, cap = 10)
        assertEquals(10, merged.size)
        assertEquals(now, merged.last().ts)
    }

    @Test
    fun `stats reports min max average and count`() {
        val stats =
            HeartRateLog.stats(
                listOf(HeartRateLog.Point(millisOf(9), 60), HeartRateLog.Point(millisOf(10), 90))
            )!!
        assertEquals(60, stats.min)
        assertEquals(90, stats.max)
        assertEquals(75, stats.avg)
        assertEquals(2, stats.count)
        assertNull(HeartRateLog.stats(emptyList()))
    }

    @Test
    fun `hourly averages fill empty hours with null`() {
        val hours =
            HeartRateLog.hourlyAvg(
                listOf(
                    HeartRateLog.Point(millisOf(9, 5), 60),
                    HeartRateLog.Point(millisOf(9, 45), 80),
                    HeartRateLog.Point(millisOf(21, 10), 100),
                ),
                zone,
            )
        assertEquals(24, hours.size)
        assertEquals(70, hours[9])
        assertEquals(100, hours[21])
        assertNull(hours[10])
    }

    @Test
    fun `daily stats merge weights the average by sample count`() {
        val a = HeartRateLog.Stats(min = 60, max = 80, avg = 70, count = 10)
        val b = HeartRateLog.Stats(min = 90, max = 100, avg = 95, count = 10)
        val merged = HeartRateLog.mergeStats(a, b)!!
        assertEquals(60, merged.min)
        assertEquals(100, merged.max)
        assertEquals(82, merged.avg) // (70*10 + 95*10) / 20 = 82.5 → 82
        assertEquals(20, merged.count)
        assertEquals(a, HeartRateLog.mergeStats(a, null))
        assertNull(HeartRateLog.mergeStats(null, null))
    }

    @Test
    fun `axis range keeps at least a 20 bpm window`() {
        val flat =
            HeartRateLog.axisRange(
                listOf(HeartRateLog.Point(millisOf(9), 70), HeartRateLog.Point(millisOf(10), 72))
            )
        assertTrue(flat.last - flat.first >= 20)
        val wide =
            HeartRateLog.axisRange(
                listOf(HeartRateLog.Point(millisOf(9), 55), HeartRateLog.Point(millisOf(10), 150))
            )
        assertEquals(51, wide.first)
        assertEquals(154, wide.last)
        assertTrue(
            HeartRateLog.axisRange(emptyList()).last - HeartRateLog.axisRange(emptyList()).first >=
                20
        )
    }

    @Test
    fun `points and daily stats survive a round trip`() {
        val points =
            listOf(HeartRateLog.Point(millisOf(9), 66), HeartRateLog.Point(millisOf(18), 88))
        assertEquals(points, HeartRateLog.decodePoints(HeartRateLog.encodePoints(points)))
        assertTrue(HeartRateLog.decodePoints("broken").isEmpty())

        val days =
            mapOf("2026-10-27" to HeartRateLog.Stats(min = 58, max = 96, avg = 74, count = 12))
        assertEquals(days, HeartRateLog.decodeDays(HeartRateLog.encodeDays(days)))
        assertEquals(1, HeartRateLog.decodeDays(HeartRateLog.encodeDays(days)).size)
    }

    @Test
    fun `last week aligns by date and counts today`() {
        val days =
            mapOf(
                "2026-10-27" to HeartRateLog.Stats(min = 60, max = 80, avg = 70, count = 5),
                "2026-10-25" to HeartRateLog.Stats(min = 55, max = 75, avg = 65, count = 3),
            )
        val week = HeartRateLog.lastWeek(days, day)
        assertEquals(7, week.size)
        assertEquals(65, week[4]!!.avg)
        assertEquals(70, week[6]!!.avg)
        assertNull(week[5])
    }

    @Test
    fun `points on a day filter by local date`() {
        val points =
            listOf(HeartRateLog.Point(millisOf(9), 60), HeartRateLog.Point(millisOf(9, 0, -1), 80))
        assertEquals(1, HeartRateLog.pointsOnDay(points, day, zone).size)
    }

    @Test
    fun `binning becomes detailed points with real min max and no aggregate duplicate`() {
        val record =
            JSONObject()
                .put("start_time", millisOf(14))
                .put("heart_rate", 88)
                .put("min", 76)
                .put("max", 106)
                .put(
                    "binning_data",
                    JSONArray()
                        .put(
                            JSONObject()
                                .put("start_time", millisOf(14, 6))
                                .put("heart_rate", 92.0)
                                .put("heart_rate_min", 89)
                                .put("heart_rate_max", 93)
                        )
                        .put(
                            JSONObject()
                                .put("start_time", millisOf(14, 7))
                                .put("heart_rate", 80.0)
                                .put("heart_rate_min", 78)
                                .put("heart_rate_max", 82)
                        ),
                )
        val points = HeartRateLog.pointsFromRecords(listOf(record))
        assertEquals(listOf(92, 80), points.map { it.bpm })
        val stats = HeartRateLog.stats(points)!!
        assertEquals(78, stats.min)
        assertEquals(93, stats.max)
        assertEquals(86, stats.avg)
        assertEquals(2, stats.count)
    }

    @Test
    fun `create and update times are not used as measurement times`() {
        val record =
            JSONObject()
                .put("create_time", millisOf(9))
                .put("update_time", millisOf(10))
                .put("heart_rate", 70)
        assertTrue(HeartRateLog.pointsFromRecords(listOf(record)).isEmpty())
    }

    @Test
    fun `day grouping keeps the previous date out of today`() {
        val points =
            listOf(
                HeartRateLog.Point(millisOf(23, 59), 70),
                HeartRateLog.Point(millisOf(0, 1, dayOffset = 1), 80),
            )
        val days = HeartRateLog.byDay(points, zone)
        assertEquals(listOf(70), days[day.toString()]!!.map { it.bpm })
        assertEquals(listOf(80), days[day.plusDays(1).toString()]!!.map { it.bpm })
    }
}
