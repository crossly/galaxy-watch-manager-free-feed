package dev.ricky.galaxywatchmanagerfree.feature

import java.io.ByteArrayOutputStream
import java.time.ZoneId
import java.util.zip.ZipInputStream
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class HealthExportSchemaTest {
    @Test
    fun `every archived JSON has a resolvable v3 schema definition`() {
        val output = ByteArrayOutputStream()
        HealthArchive.write(
            output,
            HealthExportSnapshot(WatchState(), JSONObject()),
            1_790_000_000_000L,
            ZoneId.of("UTC"),
        )
        val files = buildMap {
            ZipInputStream(output.toByteArray().inputStream()).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    put(entry.name, zip.readBytes())
                }
            }
        }
        val schema = JSONObject(files.getValue("schema.json").decodeToString())
        assertEquals("urn:galaxy-watch-manager-free:health:v3", schema.getString("\$id"))
        assertEquals("https://json-schema.org/draft/2020-12/schema", schema.getString("\$schema"))
        val mappings = schema.getJSONObject("files")
        assertEquals(
            files.keys.filter { it.endsWith(".json") && it != "schema.json" }.toSet(),
            mappings.keySet(),
        )
        mappings.keys().forEach { file ->
            assertTrue(resolve(schema, mappings.getString(file)) is JSONObject)
        }
        assertEquals(
            HealthArchive.SCHEMA,
            resolve(schema, "#/\$defs/manifest/properties/schema/const"),
        )
    }

    @Test
    fun `all internal references resolve and required fields have precise property definitions`() {
        val schema = HealthExportSchema.document
        fun visit(value: Any?) {
            when (value) {
                is JSONObject -> {
                    value
                        .optString("\$ref")
                        .takeIf { it.isNotBlank() }
                        ?.let { reference ->
                            assertTrue(reference, resolve(schema, reference) is JSONObject)
                        }
                    value.optJSONArray("required")?.let { required ->
                        val properties = value.optJSONObject("properties")
                        if (properties != null) {
                            for (index in 0 until required.length()) assertTrue(
                                required.getString(index),
                                properties.has(required.getString(index)),
                            )
                        }
                    }
                    value.keys().forEach { visit(value.get(it)) }
                }
                is JSONArray -> for (index in 0 until value.length()) visit(value.get(index))
            }
        }
        visit(schema)
    }

    @Test
    fun `normalized objects are closed while retained vendor payloads stay open`() {
        val definitions = HealthExportSchema.document.getJSONObject("\$defs")
        val objects =
            listOf(
                "measurement",
                "activity_interval",
                "sleep_stage",
                "sleep_session",
                "snapshot",
                "collection_setting",
                "collection_settings",
                "dataset",
                "source_module",
                "retention",
                "sync",
                "manifest",
            )
        objects.forEach { name ->
            assertFalse(name, definitions.getJSONObject(name).getBoolean("additionalProperties"))
            assertTrue(
                name,
                definitions.getJSONObject(name).getJSONObject("properties").length() > 0,
            )
        }
        listOf("source_records", "retained_cache").forEach { name ->
            assertEquals("object", definitions.getJSONObject(name).getString("type"))
            assertFalse(definitions.getJSONObject(name).has("additionalProperties"))
        }
        val workout =
            definitions.getJSONObject("workouts").getJSONObject("items").getJSONObject("properties")
        assertEquals(
            listOf("number", "null"),
            values(workout.getJSONObject("distance_m").getJSONArray("type")),
        )
        assertEquals(
            listOf("integer", "null"),
            values(workout.getJSONObject("energy_kcal").getJSONArray("type")),
        )
        assertEquals(
            listOf("string", "null"),
            values(workout.getJSONObject("routine_id").getJSONArray("type")),
        )
        val measurement = definitions.getJSONObject("measurement").getJSONObject("properties")
        assertEquals(
            listOf("rmssd", "sdnn", "unknown", "samsung_raw_score", JSONObject.NULL),
            values(measurement.getJSONObject("method").getJSONArray("enum")),
        )
        assertEquals(
            listOf("integer", "null"),
            values(measurement.getJSONObject("source_revision_epoch_ms").getJSONArray("type")),
        )
        val vascularBand =
            definitions
                .getJSONObject("vascular_load")
                .getJSONObject("items")
                .getJSONObject("properties")
                .getJSONObject("band")
                .getJSONArray("enum")
        assertEquals(JSONObject.NULL, values(vascularBand).last())
    }

    @Test
    fun `sleep session score fields are bounded and sourced`() {
        val sleep =
            HealthExportSchema.document
                .getJSONObject("\$defs")
                .getJSONObject("sleep_session")
                .getJSONObject("properties")
        assertEquals(
            listOf("integer", "null"),
            values(sleep.getJSONObject("score").getJSONArray("type")),
        )
        assertEquals(100, sleep.getJSONObject("score").getInt("maximum"))
        assertEquals(0, sleep.getJSONObject("score").getInt("minimum"))
        assertEquals(
            listOf("integer", "null"),
            values(sleep.getJSONObject("computed_score").getJSONArray("type")),
        )
        assertEquals(1, sleep.getJSONObject("computed_score").getInt("minimum"))
        assertEquals(99, sleep.getJSONObject("computed_score").getInt("maximum"))
        assertEquals(
            listOf(SleepScore.SOURCE, JSONObject.NULL),
            values(sleep.getJSONObject("computed_score_algorithm").getJSONArray("enum")),
        )
        assertEquals(
            listOf("watch", SleepScore.SOURCE, JSONObject.NULL),
            values(sleep.getJSONObject("score_source").getJSONArray("enum")),
        )
    }

    @Test
    fun `sleep session export carries computed score and source`() {
        val data =
            HealthExportData(HealthExportSnapshot(WatchState(), JSONObject()), ZoneId.of("UTC"))
        val segments =
            listOf(
                SleepParser.Segment(0L, 180 * 60_000L, SleepParser.Stage.LIGHT),
                SleepParser.Segment(180 * 60_000L, 240 * 60_000L, SleepParser.Stage.DEEP),
                SleepParser.Segment(240 * 60_000L, 300 * 60_000L, SleepParser.Stage.REM),
                SleepParser.Segment(300 * 60_000L, 320 * 60_000L, SleepParser.Stage.AWAKE),
            )
        val session = SleepParser.Session(0L, 320 * 60_000L, segments, null, null)
        val json = data.sleepJson(session)
        assertEquals(74, json.getInt("computed_score"))
        assertEquals(SleepScore.SOURCE, json.getString("score_source"))
        assertEquals(SleepScore.SOURCE, json.getString("computed_score_algorithm"))
        assertTrue(json.isNull("score"))

        val watchJson = data.sleepJson(session.copy(score = 88))
        assertEquals(88, watchJson.getInt("score"))
        assertEquals(74, watchJson.getInt("computed_score"))
        assertEquals("watch", watchJson.getString("score_source"))
        assertEquals(SleepScore.SOURCE, watchJson.getString("computed_score_algorithm"))
        val unknown = data.sleepJson(session.copy(segments = emptyList()))
        assertTrue(unknown.isNull("computed_score"))
        assertTrue(unknown.isNull("computed_score_algorithm"))
        assertTrue(unknown.isNull("score_source"))
    }

    private fun values(array: JSONArray): List<Any> = (0 until array.length()).map(array::get)

    private fun resolve(root: JSONObject, reference: String): Any {
        assertTrue(reference, reference.startsWith("#/"))
        return reference.removePrefix("#/").split('/').fold(root as Any) { value, key ->
            (value as JSONObject).get(key.replace("~1", "/").replace("~0", "~"))
        }
    }
}
