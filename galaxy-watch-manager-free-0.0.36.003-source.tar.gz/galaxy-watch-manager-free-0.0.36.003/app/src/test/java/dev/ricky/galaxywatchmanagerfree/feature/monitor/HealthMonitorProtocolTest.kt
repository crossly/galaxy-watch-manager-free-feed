package dev.ricky.galaxywatchmanagerfree.feature.monitor

import dev.ricky.galaxywatchmanagerfree.feature.HealthJson
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class HealthMonitorProtocolTest {
    @Test
    fun `official monitor envelope uses version point one and object body`() {
        val packet =
            HealthMonitorProtocol.request(HealthMonitorProtocol.Channel.ECG, "connection", 7)
        assertEquals("REQUEST", packet.getString("message"))
        assertEquals("com.samsung.mobile.app.health.samd.ecg.common", packet.getString("sender"))
        assertEquals(
            "com.samsung.wearable.app.health.samd.ecg.common",
            packet.getString("receiver"),
        )
        assertEquals(0.1, packet.getDouble("version"), 0.0)
        assertEquals(7, packet.getInt("sequence_num"))
        val body = JSONObject(HealthJson.inflateJson(packet.getString("body")))
        assertEquals("request", body.getString("type"))
        assertEquals("connection", body.getString("action"))
        assertEquals("", body.getString("result"))
        assertEquals(0, body.getJSONObject("data").length())
        assertEquals("connection", HealthMonitorProtocol.decode(packet).action)
    }

    @Test
    fun `blood pressure measurement is addressed to the measuring endpoint`() {
        val packet =
            HealthMonitorProtocol.request(
                HealthMonitorProtocol.Channel.BP,
                "do_measure",
                8,
                endpoint = "measuring",
            )
        assertEquals(
            "com.samsung.wearable.app.health.samd.bp.measuring",
            packet.getString("receiver"),
        )
        assertEquals("/991", HealthMonitorProtocol.Channel.BP.path)
        assertEquals("/992", HealthMonitorProtocol.Channel.ECG.path)
        assertNull(HealthMonitorProtocol.Channel.fromPath("/samsung_health/wearable_message"))
    }
}
