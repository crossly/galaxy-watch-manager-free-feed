package dev.ricky.galaxywatchmanagerfree.feature

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class SleepScoreTest {
    private fun session(
        vararg stageMinutes: Pair<SleepParser.Stage, Int>,
        score: Int? = null,
    ): SleepParser.Session {
        var cursor = 0L
        val segments =
            stageMinutes.map { (stage, minutes) ->
                val end = cursor + minutes * 60_000L
                SleepParser.Segment(cursor, end, stage).also { cursor = end }
            }
        return SleepParser.Session(0L, cursor, segments, null, score)
    }

    @Test
    fun `matches original ARM64 night scores on synthetic reference nights`() {
        val light = SleepParser.Stage.LIGHT
        val deep = SleepParser.Stage.DEEP
        val rem = SleepParser.Stage.REM
        val awake = SleepParser.Stage.AWAKE
        val cases =
            listOf(
                74 to arrayOf(light to 180, deep to 60, rem to 60, awake to 20),
                39 to arrayOf(light to 100, deep to 10, rem to 10, awake to 40),
                99 to arrayOf(light to 288, deep to 96, rem to 96),
                95 to arrayOf(awake to 20, light to 288, deep to 96, rem to 96),
                77 to arrayOf(light to 180, awake to 2, deep to 60, rem to 60),
                76 to arrayOf(light to 180, awake to 3, deep to 60, rem to 60),
                79 to arrayOf(light to 432, deep to 144, rem to 144),
                58 to arrayOf(light to 480),
            )
        cases.forEach { (expected, stages) ->
            assertEquals(
                stages.toList().toString(),
                expected,
                SleepScore.analyze(session(*stages))!!.total,
            )
        }
    }

    @Test
    fun `factor contributions use native weights and truncate before summing`() {
        val result =
            SleepScore.analyze(
                session(
                    SleepParser.Stage.LIGHT to 180,
                    SleepParser.Stage.DEEP to 60,
                    SleepParser.Stage.REM to 60,
                    SleepParser.Stage.AWAKE to 20,
                )
            )!!
        assertEquals(listOf(34, 6, 18, 26, 16), result.factors.map { it.factor.weight })
        assertEquals(listOf(12, 6, 16, 24, 16), result.factors.map { it.contribution })
        assertEquals(74, result.factors.sumOf { it.contribution })
        assertEquals(300, result.totalSleepMinutes)
        assertEquals(60, result.deepMinutes)
        assertEquals(60, result.remMinutes)
        assertEquals(20, result.awakeMinutes)
        assertEquals(320, result.inBedMinutes)
    }

    @Test
    fun `unknown or incomplete stages do not produce a score`() {
        assertNull(SleepScore.analyze(SleepParser.Session(0L, 60_000L, emptyList(), null, null)))
        assertNull(SleepScore.analyze(session(SleepParser.Stage.AWAKE to 10)))
        val complete = session(SleepParser.Stage.LIGHT to 180, SleepParser.Stage.DEEP to 60)
        assertNull(SleepScore.analyze(complete.copy(endMillis = complete.endMillis + 30_000L)))
        assertNull(SleepScore.analyze(complete.copy(segments = complete.segments.drop(1))))
        assertNull(SleepScore.analyze(complete.copy(segments = complete.segments.reversed())))
        assertNull(
            SleepScore.analyze(
                complete.copy(segments = complete.segments + complete.segments.last())
            )
        )
        assertNull(
            SleepScore.analyze(
                SleepParser.Session(
                    0L,
                    15_000L,
                    listOf(SleepParser.Segment(0L, 15_000L, SleepParser.Stage.LIGHT)),
                    null,
                    null,
                )
            )
        )
    }

    @Test
    fun `leading wake is latency and half minute epochs are preserved`() {
        val s =
            session(
                SleepParser.Stage.AWAKE to 20,
                SleepParser.Stage.LIGHT to 288,
                SleepParser.Stage.DEEP to 96,
                SleepParser.Stage.REM to 96,
            )
        val result = SleepScore.analyze(s)!!
        assertEquals(20, result.latencyMinutes)
        assertEquals(0, result.awakeMinutes)
        val halfMinute =
            s.copy(
                startMillis = 30_000L,
                segments =
                    s.segments.mapIndexed { index, segment ->
                        if (index == 0) segment.copy(startMillis = 30_000L) else segment
                    },
            )
        assertEquals(95, SleepScore.analyze(halfMinute)!!.total)
        val shortLatency =
            s.copy(
                startMillis = 19 * 60_000L + 30_000L,
                segments =
                    s.segments.mapIndexed { index, segment ->
                        if (index == 0) segment.copy(startMillis = 19 * 60_000L + 30_000L)
                        else segment
                    },
            )
        val shortResult = SleepScore.analyze(shortLatency)!!
        assertEquals(85, shortResult.total)
        assertEquals(listOf(33, 6, 17, 25, 4), shortResult.factors.map { it.contribution })
    }

    @Test
    fun `splitting a wake run does not change long wake scoring`() {
        val s =
            session(
                SleepParser.Stage.LIGHT to 180,
                SleepParser.Stage.AWAKE to 4,
                SleepParser.Stage.DEEP to 60,
                SleepParser.Stage.REM to 60,
            )
        val wake = s.segments[1]
        val split =
            s.copy(
                segments =
                    listOf(
                        s.segments[0],
                        wake.copy(endMillis = wake.startMillis + 120_000L),
                        wake.copy(startMillis = wake.startMillis + 120_000L),
                    ) + s.segments.drop(2)
            )
        assertEquals(SleepScore.analyze(s), SleepScore.analyze(split))
    }

    @Test
    fun `watch score wins while computed score remains available`() {
        val s =
            session(
                SleepParser.Stage.LIGHT to 180,
                SleepParser.Stage.DEEP to 60,
                SleepParser.Stage.REM to 60,
                SleepParser.Stage.AWAKE to 20,
                score = 88,
            )
        assertEquals(88, s.displayScore)
        assertEquals("watch", s.displayScoreSource)
        assertEquals(74, s.computedScore!!.total)
        val withoutWatch = s.copy(score = null)
        assertEquals(74, withoutWatch.displayScore)
        assertEquals(SleepScore.SOURCE, withoutWatch.displayScoreSource)
        assertEquals(74, s.copy(score = 0).displayScore)
    }

    @Test
    fun `duration-only session has no score at all`() {
        val s =
            SleepParser.Session(
                0L,
                480 * 60_000L,
                emptyList(),
                null,
                null,
                reportedSleepMinutes = 420,
            )
        assertNull(s.computedScore)
        assertNull(s.displayScore)
        assertNull(s.displayScoreSource)
    }
}
