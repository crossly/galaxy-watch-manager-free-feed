package dev.ricky.galaxywatchmanagerfree.feature

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test

class NotificationIdentityTest {
    @Test
    fun `deduplication belongs to the target connection and only accepted notifications`() {
        val cache = NotificationForwardingCache()
        val firstWatch = Any()
        val secondWatch = Any()
        val reconnected = Any()
        var sends = 0
        fun send(session: Any, accepted: Boolean = true) =
            cache.forward(session, "synthetic-key", "synthetic-content") {
                sends++
                accepted
            }
        assertEquals(true, send(firstWatch))
        assertEquals(null, send(firstWatch))
        assertEquals(true, send(secondWatch))
        assertEquals(false, send(reconnected, false))
        assertEquals(true, send(reconnected))
        assertEquals(null, send(reconnected))
        cache.remove("synthetic-key")
        assertEquals(true, send(reconnected))
        assertEquals(5, sends)
    }

    @Test
    fun `updates keep their identity while different tags and users stay distinct`() {
        val first = NotificationIdentity("example.app", 7, "chat:a", 0, 10123)
        assertEquals(first.bridgerPath("phone"), first.copy().bridgerPath("phone"))
        assertNotEquals(first.bridgerPath("phone"), first.copy(tag = "chat:b").bridgerPath("phone"))
        assertNotEquals(first.bridgerPath("phone"), first.copy(userId = 10).bridgerPath("phone"))
        assertNotEquals(
            first.copy(tag = null).bridgerPath("phone"),
            first.copy(tag = "null").bridgerPath("phone"),
        )
        assertEquals("0|example.app|7|chat:a|10123", first.key)
    }
}
