package dev.ricky.galaxywatchmanagerfree.ui.screens

import dev.ricky.galaxywatchmanagerfree.feature.VascularLoadLog
import java.time.LocalDate
import java.time.ZoneOffset
import org.junit.Assert.*
import org.junit.Test

class VascularLoadChartTest {
    private val today = LocalDate.of(2026, 11, 6)

    private fun entry(
        id: String,
        daysAgo: Long = 0,
        hour: Int = 8,
        type: VascularLoadLog.Type = VascularLoadLog.Type.MEASUREMENT,
        measurement: Float? = 0f,
    ): VascularLoadLog.Entry {
        val time = today.minusDays(daysAgo).atTime(hour, 0).toInstant(ZoneOffset.UTC).toEpochMilli()
        return VascularLoadLog.Entry(id, time, time, type, measurement)
    }

    @Test
    fun `daily chart selects the latest record regardless of input order`() {
        val earlier = entry("earlier", hour = 6, measurement = -5f)
        val later = entry("later", hour = 8, measurement = 5f)
        for (records in listOf(listOf(earlier, later), listOf(later, earlier))) {
            val days = vascularChartDays(records, today)
            assertEquals(7, days.size)
            assertEquals(later, days.last())
            assertEquals(1, days.filterNotNull().size)
        }
    }

    @Test
    fun `missing days remain gaps and records outside the week are excluded`() {
        val first = entry("first", daysAgo = 6)
        val last = entry("last")
        val days =
            vascularChartDays(
                listOf(entry("old", daysAgo = 7), first, last, entry("future", daysAgo = -1)),
                today,
            )
        assertEquals(listOf(first, null, null, null, null, null, last), days)
    }

    @Test
    fun `reset and unavailable results cannot fall back to an earlier valid reading`() {
        val valid = entry("valid", hour = 6)
        val reset = entry("reset", type = VascularLoadLog.Type.RESET, measurement = null)
        val unknown = entry("unknown", measurement = 13f)
        for (latest in listOf(reset, unknown)) {
            val day = vascularChartDays(listOf(valid, latest), today).last()
            assertEquals(latest, day)
            assertNull(day!!.chartValue)
        }
        val simultaneous = valid.copy(endMillis = reset.endMillis)
        for (records in listOf(listOf(reset, simultaneous), listOf(simultaneous, reset))) {
            assertEquals(reset, vascularChartDays(records, today).last())
        }
    }

    @Test
    fun `baseline is retained as a reference and evening records use the tracking date`() {
        val baseline =
            entry("baseline", daysAgo = 2, type = VascularLoadLog.Type.BASELINE, measurement = 93f)
        val overnight = entry("overnight", daysAgo = 1, hour = 21, measurement = -5f)
        val days = vascularChartDays(listOf(baseline, overnight), today)
        assertEquals(baseline, days[4])
        assertEquals(2.5f, days[4]!!.chartValue)
        assertNull(days[5])
        assertEquals(overnight, days[6])
    }
}
