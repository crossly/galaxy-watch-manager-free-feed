package dev.ricky.galaxywatchmanagerfree.feature

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.ZoneId

class HealthStepRevisionTest {
    private val now = 1_793_110_000_000L
    private val zone = ZoneId.of("Asia/Shanghai")

    private fun record(count: Int, revision: Long) = JSONObject()
        .put("datauuid", "same-interval")
        .put("count", count)
        .put("start_time", now - 60_000)
        .put("end_time", now - 30_000)
        .put("update_time", revision)

    private fun apply(
        total: Int, seen: MutableSet<String>,
        ledger: MutableMap<String, HealthStepParser.StepContribution>,
        vararg records: JSONObject,
        coveredThrough: Long = 0L,
    ) = HealthStepParser.accumulate(
        total, seen, records.toList(), now, zone, coveredThrough, ledger,
    ).total

    @Test
    fun `a revised interval must replace its old contribution`() {
        val seen = linkedSetOf<String>()
        val ledger = linkedMapOf<String, HealthStepParser.StepContribution>()
        val first = apply(0, seen, ledger, record(10, now - 1000))
        assertEquals(25, apply(first, seen, ledger, record(25, now)))
    }

    @Test
    fun `a repeated revision is counted exactly once`() {
        val seen = linkedSetOf<String>()
        val ledger = linkedMapOf<String, HealthStepParser.StepContribution>()
        val first = apply(0, seen, ledger, record(10, now))
        assertEquals(10, apply(first, seen, ledger, record(10, now)))
    }

    @Test
    fun `an older revision cannot overwrite the newest count`() {
        val seen = linkedSetOf<String>()
        val ledger = linkedMapOf<String, HealthStepParser.StepContribution>()
        val first = apply(0, seen, ledger, record(25, now))
        assertEquals(25, apply(first, seen, ledger, record(10, now - 1000)))
    }

    @Test
    fun `a downward correction adjusts the total too`() {
        val seen = linkedSetOf<String>()
        val ledger = linkedMapOf<String, HealthStepParser.StepContribution>()
        val first = apply(0, seen, ledger, record(25, now - 1000))
        assertEquals(10, apply(first, seen, ledger, record(10, now)))
    }

    @Test
    fun `restart preserves previous contribution before applying revisions`() {
        val seen = linkedSetOf<String>()
        val ledger = linkedMapOf<String, HealthStepParser.StepContribution>()
        val first = apply(0, seen, ledger, record(10, now - 1000))
        val restored = HealthStepParser.decodeContributions(HealthStepParser.encodeContributions(ledger))
        assertEquals(25, apply(first, seen.toMutableSet(), restored, record(25, now)))
    }

    @Test
    fun `legacy UUID-only cache is adopted without counting it twice`() {
        val seen = linkedSetOf("same-interval")
        val ledger = linkedMapOf<String, HealthStepParser.StepContribution>()
        // Its old count is unavailable. Preserve the cached total and establish a baseline.
        val baseline = apply(3270, seen, ledger, record(25, now - 1000))
        assertEquals(3270, baseline)
        assertEquals(3280, apply(baseline, seen, ledger, record(35, now)))
    }

    @Test
    fun `summary-covered revisions do not add the same interval twice`() {
        val seen = linkedSetOf<String>()
        val ledger = linkedMapOf<String, HealthStepParser.StepContribution>()
        val total = apply(600, seen, ledger, record(25, now - 1000), coveredThrough = now)
        assertEquals(600, apply(total, seen, ledger, record(35, now), coveredThrough = now))
    }
}
