package dev.ricky.galaxywatchmanagerfree.feature

import java.io.ByteArrayOutputStream
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.Base64
import java.util.zip.GZIPOutputStream
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class StressLogTest {

    private val zone = ZoneId.of("Asia/Shanghai")
    private val now =
        ZonedDateTime.of(LocalDate.of(2026, 10, 27), LocalTime.of(21, 30), zone)
            .toInstant()
            .toEpochMilli()

    private fun ts(day: Int, hour: Int, minute: Int, second: Int = 0): Long =
        ZonedDateTime.of(LocalDate.of(2026, 10, day), LocalTime.of(hour, minute, second), zone)
            .toInstant()
            .toEpochMilli()

    private fun gzipBase64(json: String): String {
        val bytes =
            ByteArrayOutputStream().use { output ->
                GZIPOutputStream(output).use { gzip -> gzip.write(json.toByteArray()) }
                output.toByteArray()
            }
        return Base64.getEncoder().encodeToString(bytes)
    }

    @Test
    fun `official raw categories classify before display rounding`() {
        assertEquals(StressLog.Level.RELAXED, StressLog.Level.of(0f))
        assertEquals(StressLog.Level.RELAXED, StressLog.Level.of(10f))
        assertEquals(StressLog.Level.LOW, StressLog.Level.of(10.4f))
        assertEquals(StressLog.Level.LOW, StressLog.Level.of(20f))
        assertEquals(StressLog.Level.MODERATE, StressLog.Level.of(20.4f))
        assertEquals(StressLog.Level.MODERATE, StressLog.Level.of(80f))
        assertEquals(StressLog.Level.HIGH, StressLog.Level.of(80.4f))
        assertEquals(StressLog.Level.HIGH, StressLog.Level.of(100f))
        assertNull(StressLog.Level.of(-0.1f))
        assertNull(StressLog.Level.of(100.1f))
        assertNull(StressLog.Level.of(Float.NaN))
    }

    @Test
    fun `gzip binning data expands to real readings and drops the outer aggregate`() {
        val record =
            JSONObject()
                .put("datauuid", "continuous")
                .put("start_time", ts(27, 10, 0))
                .put("end_time", ts(27, 10, 59))
                .put("score", 55)
                .put("min", 1)
                .put("max", 99)
                .put(
                    "binning_data",
                    gzipBase64(
                        """
                        [
                          {"score":10.4,"score_min":8.2,"score_max":12.0,"start_time":${ts(27, 10, 5)},"end_time":${ts(27, 10, 5, 59)}},
                          {"score":80.4,"score_min":70.5,"score_max":95.5,"start_time":${ts(27, 10, 1)},"end_time":${ts(27, 10, 1, 59)}}
                        ]
                        """
                            .trimIndent()
                    ),
                )

        val points = StressLog.pointsFromRecords(listOf(record)).sortedBy { it.ts }
        assertEquals(2, points.size)
        assertEquals(80.4f, points[0].score, 0.001f)
        assertEquals(70.5f, points[0].min, 0.001f)
        assertEquals(95.5f, points[0].max, 0.001f)
        assertEquals(10.4f, points[1].score, 0.001f)
        assertEquals(StressLog.Level.HIGH, StressLog.Level.of(points[0].score))
        assertEquals(StressLog.Level.LOW, StressLog.Level.of(points[1].score))
        assertTrue(points.none { it.score == 55f })
    }

    @Test
    fun `zero is a real reading while missing scores stay unknown`() {
        val zero =
            JSONObject()
                .put("datauuid", "zero")
                .put("start_time", ts(27, 9, 0))
                .put("score", 0)
                .put("min", 0)
                .put("max", 0)
        val missing =
            JSONObject()
                .put("datauuid", "missing")
                .put("start_time", ts(27, 9, 5))
                .put("min", 1)
                .put("max", 2)

        val points = StressLog.pointsFromRecords(listOf(zero, missing))
        assertEquals(1, points.size)
        assertEquals(0f, points.single().score, 0.001f)
        assertEquals(StressLog.Level.RELAXED, StressLog.Level.of(points.single().score))
        assertNotNull(StressLog.stats(points))
        assertNull(StressLog.stats(StressLog.pointsFromRecords(listOf(missing))))
    }

    @Test
    fun `latest valid stress measurement ignores sync time and future revisions`() {
        val store = HealthRecordStore()
        store.merge(
            mapOf(
                StressLog.MODULE to
                    listOf(
                        JSONObject()
                            .put("datauuid", "old")
                            .put("start_time", ts(27, 8, 0))
                            .put("update_time", ts(27, 20, 0))
                            .put("score", 35),
                        JSONObject()
                            .put("datauuid", "new")
                            .put("start_time", ts(27, 9, 0))
                            .put("update_time", ts(27, 9, 5))
                            .put("score", 70.4),
                        JSONObject()
                            .put("datauuid", "sync-only")
                            .put("update_time", ts(27, 21, 0))
                            .put("score", 99),
                        JSONObject()
                            .put("datauuid", "future")
                            .put("start_time", now + 60_000)
                            .put("update_time", ts(27, 21, 10))
                            .put("score", 100),
                    )
            ),
            now,
        )

        val projected = HealthDataProjection.build(store, now, zone)
        assertEquals(ts(27, 9, 0), projected.latestStress?.ts)
        assertEquals(70.4f, projected.latestStress!!.score, 0.001f)
        assertEquals(StressLog.Level.MODERATE, StressLog.Level.of(projected.latestStress!!.score))
        assertEquals(70, projected.stress)
    }

    @Test
    fun `invalid newest record does not hide an older valid measurement`() {
        val store = HealthRecordStore()
        store.merge(
            mapOf(
                StressLog.MODULE to
                    listOf(
                        JSONObject()
                            .put("datauuid", "valid")
                            .put("start_time", ts(27, 8, 0))
                            .put("score", 45),
                        JSONObject()
                            .put("datauuid", "invalid")
                            .put("start_time", ts(27, 9, 0))
                            .put("score", 101),
                    )
            ),
            now,
        )

        val projected = HealthDataProjection.build(store, now, zone)
        assertEquals(ts(27, 8, 0), projected.latestStress?.ts)
        assertEquals(45, projected.stress)
    }

    @Test
    fun `store revision keeps newest stress record even when an older one arrives later`() {
        val store = HealthRecordStore()
        fun record(score: Float, updated: Long) =
            JSONObject()
                .put("datauuid", "stress-1")
                .put("start_time", ts(27, 9, 0))
                .put("update_time", updated)
                .put("score", score.toDouble())

        store.merge(mapOf(StressLog.MODULE to listOf(record(20f, ts(27, 9, 10)))), now)
        store.merge(mapOf(StressLog.MODULE to listOf(record(80.4f, ts(27, 9, 20)))), now)
        store.merge(mapOf(StressLog.MODULE to listOf(record(10f, ts(27, 9, 15)))), now)

        val projected = HealthDataProjection.build(store, now, zone)
        assertEquals(80.4f, projected.latestStress!!.score, 0.001f)
        assertEquals(StressLog.Level.HIGH, StressLog.Level.of(projected.latestStress!!.score))
    }

    @Test
    fun `day boundaries and statistics follow local measurement time`() {
        val points =
            listOf(
                StressLog.Point(ts(27, 23, 59), 80.4f, 70f, 90f),
                StressLog.Point(ts(28, 0, 1), 10.4f, 8f, 12f),
            )
        val days = StressLog.byDay(points, zone)
        assertEquals(setOf("2026-10-27", "2026-10-28"), days.keys)
        assertEquals(80.4f, days.getValue("2026-10-27").single().score, 0.001f)
        assertEquals(10.4f, days.getValue("2026-10-28").single().score, 0.001f)

        val stats = StressLog.stats(points)!!
        assertEquals(8f, stats.min, 0.001f)
        assertEquals(90f, stats.max, 0.001f)
        assertEquals((80.4f + 10.4f) / 2f, stats.avg, 0.001f)
        assertEquals(2, stats.count)
    }

    @Test
    fun `cached stress points round trip without losing fractions or ranges`() {
        val points =
            listOf(
                StressLog.Point(ts(27, 9, 0), 10.4f, 8.2f, 12f),
                StressLog.Point(ts(27, 10, 0), 80.4f, 70f, 95f),
            )
        val decoded = StressLog.decodePoints(StressLog.encodePoints(points))
        assertEquals(points, decoded)
    }
}
