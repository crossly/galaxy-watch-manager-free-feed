package dev.ricky.galaxywatchmanagerfree.feature

import org.junit.Assert.*
import org.junit.Test

class KeepAliveHelperTest {

    @Test
    fun `all rom brands have valid names and localized guide resources`() {
        for (brand in RomBrand.entries) {
            assertTrue("Brand name should not be blank", brand.brandName.isNotBlank())
            assertTrue("System name should not be blank", brand.systemName.isNotBlank())
            assertTrue("Guide string resource should be valid", brand.guideRes != 0)
        }
    }

    @Test
    fun `detectRomBrand identifies various manufacturers correctly`() {
        assertEquals(RomBrand.XIAOMI, KeepAliveHelper.detectRomBrand("Xiaomi", "Xiaomi"))
        assertEquals(RomBrand.XIAOMI, KeepAliveHelper.detectRomBrand("Xiaomi", "Redmi"))
        assertEquals(RomBrand.HUAWEI, KeepAliveHelper.detectRomBrand("HUAWEI", "HUAWEI"))
        assertEquals(RomBrand.HUAWEI, KeepAliveHelper.detectRomBrand("HONOR", "HONOR"))
        assertEquals(RomBrand.OPPO, KeepAliveHelper.detectRomBrand("OPPO", "OPPO"))
        assertEquals(RomBrand.OPPO, KeepAliveHelper.detectRomBrand("OnePlus", "OnePlus"))
        assertEquals(RomBrand.VIVO, KeepAliveHelper.detectRomBrand("vivo", "vivo"))
        assertEquals(RomBrand.VIVO, KeepAliveHelper.detectRomBrand("vivo", "iQOO"))
        assertEquals(RomBrand.MEIZU, KeepAliveHelper.detectRomBrand("Meizu", "Meizu"))
        assertEquals(RomBrand.SAMSUNG, KeepAliveHelper.detectRomBrand("samsung", "samsung"))
        assertEquals(RomBrand.GENERIC, KeepAliveHelper.detectRomBrand("Google", "Pixel"))
        assertEquals(RomBrand.GENERIC, KeepAliveHelper.detectRomBrand("", ""))
    }
}
