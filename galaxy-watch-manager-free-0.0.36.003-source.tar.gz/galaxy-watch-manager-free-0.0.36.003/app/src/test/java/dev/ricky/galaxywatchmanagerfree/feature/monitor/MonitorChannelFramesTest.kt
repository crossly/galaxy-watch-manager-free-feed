package dev.ricky.galaxywatchmanagerfree.feature.monitor

import java.nio.ByteBuffer
import java.nio.ByteOrder
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class MonitorChannelFramesTest {
    @Test
    fun `a channel contains multiple length prefixed deflate sync jobs rather than one JSON envelope`() {
        fun job(id: Int): ByteArray {
            val body =
                JSONObject()
                    .put("message_info", JSONObject().put("action", "SYNC_DATA").put("id", id))
                    .put("data", JSONArray())
            val out = java.io.ByteArrayOutputStream()
            java.util.zip.DeflaterOutputStream(out).use { it.write(body.toString().toByteArray()) }
            val compressed = out.toByteArray()
            return ByteBuffer.allocate(4 + compressed.size)
                .order(ByteOrder.BIG_ENDIAN)
                .putInt(compressed.size)
                .put(compressed)
                .array()
        }
        val jobs = MonitorChannelFrames.decode(job(11) + job(12))
        assertEquals(listOf(11, 12), jobs.map { it.getJSONObject("message_info").getInt("id") })
        assertThrows(IllegalArgumentException::class.java) {
            MonitorChannelFrames.decode(job(1).dropLast(2).toByteArray())
        }
        assertThrows(IllegalArgumentException::class.java) {
            MonitorChannelFrames.decode(byteArrayOf(127, -1, -1, -1))
        }
    }
}
