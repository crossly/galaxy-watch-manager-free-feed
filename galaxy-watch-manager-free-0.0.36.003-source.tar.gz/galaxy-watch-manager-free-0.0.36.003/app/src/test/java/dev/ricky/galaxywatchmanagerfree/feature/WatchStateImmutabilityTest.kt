package dev.ricky.galaxywatchmanagerfree.feature

import java.lang.reflect.Modifier
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 守住 [WatchState] 的 `@Immutable` 契约。
 *
 * `@Immutable` 让 Compose 跳过 `equals` 直接按引用比较，一旦有人往状态里塞可变容器
 * （`JSONObject`、`Any`、`ArrayList`、`HashMap`）或改成 `var`，界面就会静默停止刷新。 这个测试把口子堵在 CI 里。
 */
class WatchStateImmutabilityTest {

    private val fields = WatchState::class.java.declaredFields.filterNot { it.isSynthetic }

    @Test
    fun `状态字段必须是 val`() {
        val mutable = fields.filterNot { Modifier.isFinal(it.modifiers) }.map { it.name }
        assertTrue("WatchState 出现了可变字段：$mutable", mutable.isEmpty())
    }

    @Test
    fun `状态字段不得使用可变或类型擦除的容器`() {
        val banned =
            listOf(
                "org.json.JSONObject",
                "org.json.JSONArray",
                "java.lang.Object",
                "java.util.ArrayList",
                "java.util.HashMap",
                "java.util.LinkedHashMap",
                "kotlin.collections.MutableList",
                "kotlin.collections.MutableMap",
                "kotlin.collections.MutableSet",
            )
        val offenders =
            fields
                .filter { field -> banned.any { field.type.name.contains(it) } }
                .map { "${it.name}: ${it.type.simpleName}" }
        assertTrue("这些字段会让 @Immutable 失真（改用不可变值或 String/Boolean）：$offenders", offenders.isEmpty())
    }

    /** `@Immutable` 是 BINARY 保留，运行时反射看不到，只能在源码层面守。 */
    @Test
    fun `状态类本身带 Immutable 注解`() {
        val source =
            java.io.File("src/main/java/dev/ricky/galaxywatchmanagerfree/feature/WatchState.kt")
        assertTrue("找不到 WatchState.kt：${source.absolutePath}", source.isFile)
        val text = source.readText()
        assertTrue("WatchState 需要 @Immutable 注解", text.contains("@Immutable"))
        assertTrue(
            "需要 import androidx.compose.runtime.Immutable",
            text.contains("import androidx.compose.runtime.Immutable"),
        )
    }
}
