package dev.ricky.galaxywatchmanagerfree.wcs

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ReconnectPolicyTest {
    @Test
    fun `unavailable watch backs off rather than retrying every three seconds forever`() {
        val policy = ReconnectPolicy()
        assertEquals(
            listOf(500L, 1_000L, 2_000L, 4_000L, 8_000L, 16_000L, 32_000L, 60_000L),
            List(8) { policy.nextDelayMillis() },
        )
        repeat(1_000) { assertEquals(60_000L, policy.nextDelayMillis()) }
    }

    @Test
    fun `short connection flaps do not reset the failure backoff`() {
        var time = 0L
        val policy = ReconnectPolicy { time }
        repeat(8) { policy.nextDelayMillis() }
        repeat(10) {
            policy.connected()
            time += 1_000L
            policy.disconnected()
            assertEquals(60_000L, policy.nextDelayMillis())
        }
        policy.connected()
        time += ReconnectPolicy.STABLE_CONNECTION_MS
        policy.disconnected()
        assertEquals(500L, policy.nextDelayMillis())
    }

    @Test
    fun `BLE wake is rate limited across failed attempts and connection flaps`() {
        var time = 0L
        val policy = ReconnectPolicy { time }
        assertTrue(policy.mayWake())
        repeat(119) {
            time += 1_000L
            policy.connected()
            policy.disconnected()
            assertFalse(policy.mayWake())
        }
        time++
        assertFalse(policy.mayWake())
        time = ReconnectPolicy.WAKE_COOLDOWN_MS
        assertTrue(policy.mayWake())
    }
}
