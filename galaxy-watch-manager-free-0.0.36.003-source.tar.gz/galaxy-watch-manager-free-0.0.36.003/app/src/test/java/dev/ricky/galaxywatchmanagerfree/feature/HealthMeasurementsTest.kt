package dev.ricky.galaxywatchmanagerfree.feature

import dev.ricky.galaxywatchmanagerfree.wcs.WcsPaths
import java.io.ByteArrayOutputStream
import java.util.Base64
import java.util.zip.GZIPOutputStream
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class HealthMeasurementsTest {
    @Test
    fun invertedZeroValueConfirmsAfterAckAndReadback() = runTest {
        val store = MemoryStore().apply { writeRow(SLEEP_UUID, baseline(rowValue = 1)) }
        val sent = mutableListOf<JSONObject>()
        var readbacks = 0
        val measurements = controller(store, sent = sent, requestReadback = { readbacks++ })

        assertTrue(measurements.setSleepOxygen(true))
        assertEquals(
            HealthMeasurements.ToggleStatus.PENDING,
            measurements.state.value.sleepOxygen.status,
        )
        assertEquals(true, measurements.state.value.sleepOxygen.desired)
        assertEquals(false, measurements.state.value.sleepOxygen.enabled)

        val packet = sent.single()
        val outbound = preferenceRow(packet)
        assertEquals(0, outbound.getInt("int_value"))
        val sequence = packet.getInt("sequence_num")
        val revision = outbound.getLong("update_time")
        assertTrue(revision > baseline(rowValue = 1).getLong("update_time"))

        assertTrue(measurements.handleMessage(ack(sequence)))
        assertEquals(1, readbacks)
        measurements.receivePreferences(listOf(receivedRow(0, revision)))

        val state = measurements.state.value.sleepOxygen
        assertEquals(true, state.enabled)
        assertNull(state.desired)
        assertEquals(HealthMeasurements.ToggleStatus.CONFIRMED, state.status)
    }

    @Test
    fun strayAndMismatchedAcksNeverConfirmOrRequestReadback() = runTest {
        val store = MemoryStore().apply { writeRow(SLEEP_UUID, baseline(rowValue = 1)) }
        val sent = mutableListOf<JSONObject>()
        var readbacks = 0
        val measurements = controller(store, sent = sent, requestReadback = { readbacks++ })

        assertTrue(measurements.setSleepOxygen(true))
        val sequence = sent.single().getInt("sequence_num")

        assertFalse(
            measurements.handleMessage(
                ack(
                    sequence,
                    sender = "com.samsung.android.wear.shealth.wearable.syncmanager.other",
                )
            )
        )
        assertFalse(measurements.handleMessage(ack(sequence + 1)))
        assertEquals(0, readbacks)
        assertEquals(
            HealthMeasurements.ToggleStatus.PENDING,
            measurements.state.value.sleepOxygen.status,
        )

        assertTrue(measurements.handleMessage(ack(sequence)))
        assertEquals(1, readbacks)
    }

    @Test
    fun oldReadbackRevisionCannotConfirmWrite() = runTest {
        val store = MemoryStore().apply { writeRow(SLEEP_UUID, baseline(rowValue = 1)) }
        val sent = mutableListOf<JSONObject>()
        val measurements = controller(store, sent = sent)

        assertTrue(measurements.setSleepOxygen(true))
        val sequence = sent.single().getInt("sequence_num")
        val revision = preferenceRow(sent.single()).getLong("update_time")
        assertTrue(measurements.handleMessage(ack(sequence)))

        measurements.receivePreferences(listOf(receivedRow(0, revision - 1)))
        assertEquals(
            HealthMeasurements.ToggleStatus.PENDING,
            measurements.state.value.sleepOxygen.status,
        )
        assertEquals(false, measurements.state.value.sleepOxygen.enabled)

        measurements.receivePreferences(listOf(receivedRow(0, revision)))
        assertEquals(
            HealthMeasurements.ToggleStatus.CONFIRMED,
            measurements.state.value.sleepOxygen.status,
        )
        assertEquals(true, measurements.state.value.sleepOxygen.enabled)
    }

    @Test
    fun readbackBeforeAckWaitsForMatchingAck() = runTest {
        val store = MemoryStore().apply { writeRow(SLEEP_UUID, baseline(rowValue = 1)) }
        val sent = mutableListOf<JSONObject>()
        var readbacks = 0
        val measurements = controller(store, sent = sent, requestReadback = { readbacks++ })

        assertTrue(measurements.setSleepOxygen(true))
        val packet = sent.single()
        val sequence = packet.getInt("sequence_num")
        val revision = preferenceRow(packet).getLong("update_time")

        measurements.receivePreferences(listOf(receivedRow(0, revision)))
        assertEquals(
            HealthMeasurements.ToggleStatus.PENDING,
            measurements.state.value.sleepOxygen.status,
        )
        assertEquals(0, readbacks)

        assertTrue(measurements.handleMessage(ack(sequence)))
        assertEquals(1, readbacks)
        assertEquals(
            HealthMeasurements.ToggleStatus.CONFIRMED,
            measurements.state.value.sleepOxygen.status,
        )
        assertEquals(true, measurements.state.value.sleepOxygen.enabled)
    }

    @Test
    fun failedAckAndSendFailureAreReportedWithoutConfirmation() = runTest {
        val store = MemoryStore().apply { writeRow(SLEEP_UUID, baseline(rowValue = 1)) }
        val sent = mutableListOf<JSONObject>()
        var readbacks = 0
        var sendOk = true
        val measurements =
            controller(store, sent = sent, send = { sendOk }, requestReadback = { readbacks++ })

        assertTrue(measurements.setSleepOxygen(true))
        val sequence = sent.single().getInt("sequence_num")
        assertTrue(measurements.handleMessage(ack(sequence, result = "FAIL")))
        assertEquals(0, readbacks)
        assertEquals(
            HealthMeasurements.ToggleStatus.UNCONFIRMED,
            measurements.state.value.sleepOxygen.status,
        )
        assertEquals(true, measurements.state.value.sleepOxygen.desired)

        sendOk = false
        assertFalse(measurements.setSleepOxygen(false))
        assertEquals(
            HealthMeasurements.ToggleStatus.FAILED,
            measurements.state.value.sleepOxygen.status,
        )
    }

    @Test
    fun preferenceWritePreservesFullBaselineRow() = runTest {
        val original = baseline(rowValue = 1)
        val store = MemoryStore().apply { writeRow(SLEEP_UUID, original) }
        val sent = mutableListOf<JSONObject>()
        val measurements = controller(store, sent = sent)

        assertTrue(measurements.setSleepOxygen(true))
        val outbound = preferenceRow(sent.single())

        listOf("datauuid", "create_time", "pkg_name", "deviceuuid", "service_id", "keep_me")
            .forEach { key ->
                assertEquals(original.get(key).toString(), outbound.get(key).toString())
            }
        assertEquals("original", outbound.getString("keep_me"))
        assertEquals(0, outbound.getInt("int_value"))
        assertTrue(outbound.getLong("update_time") > original.getLong("update_time"))
    }

    @Test
    fun timeoutShowsUnconfirmedAndCloseClearsTransientPendingState() = runTest {
        val store = MemoryStore().apply { writeRow(SLEEP_UUID, baseline(rowValue = 1)) }
        val sent = mutableListOf<JSONObject>()
        val measurements = controller(store, sent = sent)

        assertTrue(measurements.setSleepOxygen(true))
        advanceTimeBy(HealthMeasurements.CONFIRM_TIMEOUT_MS + 1)
        runCurrent()

        val timedOut = measurements.state.value.sleepOxygen
        assertEquals(HealthMeasurements.ToggleStatus.UNCONFIRMED, timedOut.status)
        assertEquals(true, timedOut.desired)
        assertEquals(false, timedOut.enabled)

        measurements.close()
        val closed = measurements.state.value.sleepOxygen
        assertEquals(HealthMeasurements.ToggleStatus.CONFIRMED, closed.status)
        assertNull(closed.desired)
        assertEquals(false, closed.enabled)

        advanceTimeBy(HealthMeasurements.CONFIRM_TIMEOUT_MS + 1)
        runCurrent()
        assertEquals(
            HealthMeasurements.ToggleStatus.CONFIRMED,
            measurements.state.value.sleepOxygen.status,
        )
    }

    @Test
    fun stressContinuousUsesInvertedZeroAndManualOne() = runTest {
        val store = MemoryStore().apply { writeRow(STRESS_UUID, stressBaseline(rowValue = 1)) }
        val sent = mutableListOf<JSONObject>()
        val measurements = controller(store, sent = sent)

        assertTrue(measurements.setStressContinuous(true))
        val packet = sent.single()
        assertEquals(0, preferenceRow(packet).getInt("int_value"))
        val sequence = packet.getInt("sequence_num")
        val revision = preferenceRow(packet).getLong("update_time")
        assertTrue(measurements.handleMessage(ack(sequence)))
        measurements.receivePreferences(listOf(stressRow(0, revision)))
        assertEquals(
            HealthMeasurements.ToggleStatus.CONFIRMED,
            measurements.state.value.stressContinuous.status,
        )
        assertEquals(true, measurements.state.value.stressContinuous.enabled)

        assertTrue(measurements.setStressContinuous(false))
        assertEquals(1, preferenceRow(sent.last()).getInt("int_value"))
    }

    @Test
    fun vascularLoadUsesOneForOnAndZeroForOffWithAckAndReadback() = runTest {
        val original = vascularBaseline(0)
        val store = MemoryStore().apply { writeRow(VASCULAR_UUID, original) }
        val sent = mutableListOf<JSONObject>()
        var readbacks = 0
        val measurements = controller(store, sent, requestReadback = { readbacks++ })
        assertEquals(false, measurements.state.value.vascularLoad.enabled)
        assertTrue(measurements.state.value.vascularLoad.canWrite)

        assertTrue(measurements.setVascularLoad(true))
        val packet = sent.single()
        val row = preferenceRow(packet)
        assertEquals(VASCULAR_UUID, row.getString("datauuid"))
        assertEquals("app.settings", row.getString("service_id"))
        assertEquals(1, row.getInt("int_value"))
        listOf("create_time", "pkg_name", "deviceuuid", "keep_me").forEach {
            assertEquals(original.get(it).toString(), row.get(it).toString())
        }
        assertTrue(measurements.handleMessage(ack(packet.getInt("sequence_num"))))
        assertEquals(1, readbacks)
        assertEquals(false, measurements.state.value.vascularLoad.enabled)
        assertEquals(
            HealthMeasurements.ToggleStatus.PENDING,
            measurements.state.value.vascularLoad.status,
        )
        measurements.receivePreferences(listOf(row))
        assertEquals(true, measurements.state.value.vascularLoad.enabled)
        assertNull(measurements.state.value.vascularLoad.desired)
        assertEquals(
            HealthMeasurements.ToggleStatus.CONFIRMED,
            measurements.state.value.vascularLoad.status,
        )

        assertTrue(measurements.setVascularLoad(false))
        val off = preferenceRow(sent.last())
        assertEquals(0, off.getInt("int_value"))
        assertTrue(off.getLong("update_time") > row.getLong("update_time"))
        measurements.receivePreferences(listOf(off))
        assertEquals(
            HealthMeasurements.ToggleStatus.PENDING,
            measurements.state.value.vascularLoad.status,
        )
        measurements.handleMessage(ack(sent.last().getInt("sequence_num")))
        assertEquals(false, measurements.state.value.vascularLoad.enabled)
        assertEquals(
            HealthMeasurements.ToggleStatus.CONFIRMED,
            measurements.state.value.vascularLoad.status,
        )
        val restored = controller(store)
        assertEquals(false, restored.state.value.vascularLoad.enabled)
        assertEquals(
            HealthMeasurements.ToggleStatus.CONFIRMED,
            restored.state.value.vascularLoad.status,
        )
    }

    @Test
    fun absentVascularRowDoesNotConfirmDefaultOrBorrowTrackerIdentity() = runTest {
        val sent = mutableListOf<JSONObject>()
        val measurements = controller(MemoryStore(), sent)
        measurements.receivePreferences(listOf(baseline(0), stressBaseline(0)))
        val state = measurements.state.value.vascularLoad
        assertNull(state.enabled)
        assertFalse(state.canWrite)
        assertEquals(HealthMeasurements.ToggleStatus.UNKNOWN, state.status)
        assertFalse(measurements.setVascularLoad(false))
        assertTrue(sent.isEmpty())
    }

    @Test
    fun absentVascularRowCanBeCreatedFromAppSettingsIdentityWithoutCopyingValues() = runTest {
        val store = MemoryStore()
        val sent = mutableListOf<JSONObject>()
        val measurements = controller(store, sent)
        val template =
            labsTemplate()
                .put("text_value", "unrelated-template-value")
                .put("blob_value", "unrelated-blob")
        measurements.receivePreferences(listOf(template))
        assertTrue(measurements.state.value.vascularLoad.canWrite)
        assertNull(measurements.state.value.vascularLoad.enabled)
        assertEquals(
            HealthMeasurements.ToggleStatus.UNKNOWN,
            measurements.state.value.vascularLoad.status,
        )

        assertTrue(measurements.setVascularLoad(false))
        val packet = sent.single()
        val row = preferenceRow(packet)
        assertEquals(VASCULAR_UUID, row.getString("datauuid"))
        assertEquals("app.settings", row.getString("service_id"))
        assertEquals(template.getString("deviceuuid"), row.getString("deviceuuid"))
        assertEquals(template.getString("pkg_name"), row.getString("pkg_name"))
        assertEquals(5_000L, row.getLong("create_time"))
        assertEquals(0, row.getInt("int_value"))
        assertFalse(row.has("text_value"))
        assertFalse(row.has("blob_value"))
        assertFalse(row.has("keep_me"))
        assertNull(store.readRow(VASCULAR_UUID))
        measurements.handleMessage(ack(packet.getInt("sequence_num")))
        assertEquals(
            HealthMeasurements.ToggleStatus.PENDING,
            measurements.state.value.vascularLoad.status,
        )
        assertNull(measurements.state.value.vascularLoad.enabled)
        measurements.receivePreferences(listOf(row))
        assertEquals(false, measurements.state.value.vascularLoad.enabled)
        assertEquals(
            HealthMeasurements.ToggleStatus.CONFIRMED,
            measurements.state.value.vascularLoad.status,
        )
    }

    @Test
    fun restoredAppSettingsTemplateEnablesWritesWithoutFabricatingConfirmedState() = runTest {
        val store = MemoryStore()
        val original = controller(store)
        original.receivePreferences(listOf(labsTemplate()))
        val sent = mutableListOf<JSONObject>()
        val restored = controller(store, sent)
        assertNull(restored.state.value.vascularLoad.enabled)
        assertEquals(
            HealthMeasurements.ToggleStatus.UNKNOWN,
            restored.state.value.vascularLoad.status,
        )
        assertTrue(restored.state.value.vascularLoad.canWrite)
        assertTrue(restored.setVascularLoad(true))
        assertEquals(1, preferenceRow(sent.single()).getInt("int_value"))
        assertNull(store.readRow(VASCULAR_UUID))
    }

    @Test
    fun vascularReadbackRequiresCorrectServiceDeviceAndRevision() = runTest {
        val store = MemoryStore().apply { writeRow(VASCULAR_UUID, vascularBaseline(0)) }
        val sent = mutableListOf<JSONObject>()
        val measurements = controller(store, sent)
        measurements.setVascularLoad(true)
        val packet = sent.single()
        val row = preferenceRow(packet)
        measurements.handleMessage(ack(packet.getInt("sequence_num")))
        listOf(
                JSONObject(row.toString()).put("service_id", "tracker.vascular_load"),
                JSONObject(row.toString()).put("deviceuuid", "other-device"),
                JSONObject(row.toString()).put("update_time", row.getLong("update_time") - 1),
            )
            .forEach {
                measurements.receivePreferences(listOf(it))
                assertEquals(
                    HealthMeasurements.ToggleStatus.PENDING,
                    measurements.state.value.vascularLoad.status,
                )
                assertEquals(false, measurements.state.value.vascularLoad.enabled)
            }
        measurements.receivePreferences(listOf(row))
        assertEquals(
            HealthMeasurements.ToggleStatus.CONFIRMED,
            measurements.state.value.vascularLoad.status,
        )
        assertEquals(true, measurements.state.value.vascularLoad.enabled)
    }

    @Test
    fun partialPreferenceChunksAndOnboardingFlagCannotEnableVascularLoad() = runTest {
        val store = MemoryStore().apply { writeRow(VASCULAR_UUID, vascularBaseline(0)) }
        val measurements = controller(store)
        val onboarding =
            baseline(1)
                .put("datauuid", "45-vascular.load.onboarding")
                .put("service_id", "tracker.vascular_load")
        measurements.receivePreferences(listOf(labsTemplate(), onboarding))
        assertEquals(false, measurements.state.value.vascularLoad.enabled)
        assertEquals(
            HealthMeasurements.ToggleStatus.CONFIRMED,
            measurements.state.value.vascularLoad.status,
        )
        val withoutBaseline = controller(MemoryStore())
        withoutBaseline.receivePreferences(listOf(onboarding))
        assertNull(withoutBaseline.state.value.vascularLoad.enabled)
        assertFalse(withoutBaseline.state.value.vascularLoad.canWrite)
    }

    @Test
    fun malformedAppSettingsIdentityCannotBeUsedToCreateVascularPreference() = runTest {
        for (field in listOf("pkg_name", "deviceuuid", "create_time", "update_time")) {
            val measurements = controller(MemoryStore())
            val row = labsTemplate().apply { remove(field) }
            measurements.receivePreferences(listOf(row))
            assertFalse(measurements.state.value.vascularLoad.canWrite)
            assertFalse(measurements.setVascularLoad(true))
        }
    }

    @Test
    fun exportSeparatesConfirmedSettingsFromPendingIntentAndReadback() = runTest {
        val store = MemoryStore().apply { writeRow(SLEEP_UUID, baseline(rowValue = 1)) }
        val sent = mutableListOf<JSONObject>()
        val measurements = controller(store, sent)
        assertTrue(measurements.setSleepOxygen(true))
        val revision = preferenceRow(sent.single()).getLong("update_time")

        val exported = measurements.exportSettings()
        val oxygen = exported.getJSONObject("sleep_oxygen")
        assertEquals(false, oxygen.getBoolean("enabled"))
        assertEquals(true, oxygen.getBoolean("desired"))
        assertEquals("PENDING", oxygen.getString("status"))
        assertTrue(oxygen.getBoolean("can_write"))
        assertEquals(1_000L, oxygen.getLong("last_received_revision_epoch_ms"))
        assertEquals(revision, oxygen.getLong("pending_revision_epoch_ms"))

        measurements.receivePreferences(listOf(receivedRow(0, revision)))
        val readback = measurements.exportSettings().getJSONObject("sleep_oxygen")
        assertEquals(false, readback.getBoolean("enabled"))
        assertEquals(true, readback.getBoolean("last_received_enabled"))
        assertEquals(revision, readback.getLong("last_received_revision_epoch_ms"))
        measurements.handleMessage(ack(sent.single().getInt("sequence_num")))
        val confirmed = measurements.exportSettings().getJSONObject("sleep_oxygen")
        assertEquals(true, confirmed.getBoolean("enabled"))
        assertTrue(confirmed.isNull("desired"))
        assertTrue(confirmed.isNull("pending_revision_epoch_ms"))
        assertEquals("CONFIRMED", confirmed.getString("status"))
        assertEquals(false, oxygen.getBoolean("enabled"))
        assertEquals(1_000L, oxygen.getLong("last_received_revision_epoch_ms"))
    }

    @Test
    fun exportKeepsUnknownSettingsNullAndExcludesDeviceAndTemplateFields() = runTest {
        val measurements = controller(MemoryStore())
        measurements.receivePreferences(listOf(labsTemplate().put("secret", "template-value")))
        assertTrue(measurements.setVascularLoad(true))
        val exported = measurements.exportSettings()
        assertEquals(
            setOf("sleep_oxygen", "stress_continuous", "vascular_load"),
            exported.keys().asSequence().toSet(),
        )
        val vascular = exported.getJSONObject("vascular_load")
        assertTrue(vascular.isNull("enabled"))
        assertTrue(vascular.isNull("last_received_enabled"))
        assertTrue(vascular.isNull("last_received_revision_epoch_ms"))
        assertTrue(vascular.getBoolean("desired"))
        assertTrue(vascular.getBoolean("can_write"))
        val stress = exported.getJSONObject("stress_continuous")
        assertTrue(stress.isNull("enabled"))
        assertTrue(stress.isNull("desired"))
        assertEquals("UNKNOWN", stress.getString("status"))
        assertFalse(stress.getBoolean("can_write"))
        for (excluded in
            listOf(
                "device-A",
                "watch-node",
                "deviceuuid",
                "pkg_name",
                "secret",
                "template-value",
            )) {
            assertFalse(exported.toString().contains(excluded))
        }
        measurements.close()
    }

    private fun vascularBaseline(value: Int): JSONObject =
        baseline(value).put("datauuid", VASCULAR_UUID).put("service_id", "app.settings")

    private fun labsTemplate(): JSONObject =
        baseline(1).put("datauuid", "72-lab.enable.age").put("service_id", "app.settings")

    private fun TestScope.controller(
        store: MemoryStore,
        sent: MutableList<JSONObject> = mutableListOf(),
        send: (JSONObject) -> Boolean = { true },
        requestReadback: () -> Unit = {},
    ): HealthMeasurements =
        HealthMeasurements(
            store = store,
            scope = this,
            watchNode = { "watch-node" },
            send = { packet ->
                sent.add(packet)
                send(packet)
            },
            requestReadback = requestReadback,
            clock = { 5_000L },
            deviceModel = { "Test Phone" },
            confirmTimeoutMs = HealthMeasurements.CONFIRM_TIMEOUT_MS,
        )

    private fun baseline(rowValue: Int): JSONObject =
        JSONObject()
            .put("datauuid", SLEEP_UUID)
            .put("create_time", 900L)
            .put("update_time", 1_000L)
            .put("pkg_name", "com.sec.android.app.shealth")
            .put("deviceuuid", "device-A")
            .put("service_id", "tracker.spo2")
            .put("int_value", rowValue)
            .put("keep_me", "original")

    private fun stressBaseline(rowValue: Int): JSONObject =
        JSONObject()
            .put("datauuid", STRESS_UUID)
            .put("create_time", 900L)
            .put("update_time", 1_000L)
            .put("pkg_name", "com.sec.android.app.shealth")
            .put("deviceuuid", "device-A")
            .put("service_id", "tracker.stress")
            .put("int_value", rowValue)

    private fun receivedRow(value: Int, updateTime: Long): JSONObject =
        JSONObject(baseline(value).toString()).put("update_time", updateTime)

    private fun stressRow(value: Int, updateTime: Long): JSONObject =
        JSONObject(stressBaseline(value).toString()).put("update_time", updateTime)

    private fun preferenceRow(packet: JSONObject): JSONObject {
        val entries = HealthJson.entries(packet.getString("body"))
        for (index in 0 until entries.length()) {
            val entry = entries.optJSONObject(index) ?: continue
            val rows = entry.optJSONArray("com.samsung.shealth.preferences") ?: continue
            if (rows.length() > 0) return rows.getJSONObject(0)
        }
        error("preference row missing")
    }

    private fun ack(
        sequence: Int,
        result: String = "SUCCESS",
        sender: String = WcsPaths.HEALTH_WATCH_SYNC,
    ): JSONObject {
        val message =
            JSONObject().put("action", WcsPaths.HEALTH_ACTION_SYNC_DATA).put("result", result)
        val body = JSONArray().put(JSONObject().put("message_info", JSONArray().put(message)))
        return JSONObject()
            .put("message", WcsPaths.HEALTH_MSG_RESPONSE)
            .put("type", WcsPaths.HEALTH_TYPE_DATA)
            .put("sender", sender)
            .put("receiver", WcsPaths.HEALTH_PHONE_SYNC)
            .put("version", 5.03)
            .put("sequence_num", sequence)
            .put("body", encode(body.toString()))
    }

    private fun encode(json: String): String {
        val output = ByteArrayOutputStream()
        GZIPOutputStream(output).use { it.write(json.toByteArray(Charsets.UTF_8)) }
        return Base64.getEncoder().encodeToString(output.toByteArray())
    }

    private class MemoryStore : MeasurementPreferenceStore {
        private val rows = mutableMapOf<String, JSONObject>()
        private val revisions = mutableMapOf<String, Long>()

        override fun readRow(dataUuid: String): JSONObject? = rows[dataUuid]

        override fun writeRow(dataUuid: String, row: JSONObject) {
            rows[dataUuid] = JSONObject(row.toString())
        }

        override fun readRevision(dataUuid: String): Long = revisions[dataUuid] ?: 0L

        override fun writeRevision(dataUuid: String, revision: Long) {
            revisions[dataUuid] = revision
        }
    }

    private companion object {
        const val SLEEP_UUID = "10-measure.period"
        const val STRESS_UUID = "08-measure.period"
        const val VASCULAR_UUID = "72-lab.enable.vascular_load"
    }
}
