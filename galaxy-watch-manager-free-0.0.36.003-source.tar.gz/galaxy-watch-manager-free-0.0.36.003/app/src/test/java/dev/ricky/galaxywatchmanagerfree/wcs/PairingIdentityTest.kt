package dev.ricky.galaxywatchmanagerfree.wcs

import org.junit.Assert.*
import org.junit.Test

class PairingIdentityTest {
    @Test
    fun `Connect preserves the peers wire version interval including legacy zero`() {
        for ((minimum, maximum) in listOf(0L to 0L, 0L to 1L, 1L to 3L)) {
            val body =
                Proto.string(1, "abcdef12") +
                    Proto.string(2, "Galaxy Watch4") +
                    Proto.integer(4, 3) +
                    Proto.integer(5, maximum) +
                    Proto.integer(6, minimum)
            val message =
                WcsFrame.decode(Proto.bytes(1, Proto.bytes(7, body))) as WcsFrame.Incoming.NodeInfo
            assertEquals(minimum, message.minimumProtocolVersion)
            assertEquals(maximum, message.protocolVersion)
        }
        val frame = WcsFrame.nodeInfoFrame("12345678", "Phone", 1)
        val phone = WcsFrame.decode(frame.copyOfRange(4, frame.size)) as WcsFrame.Incoming.NodeInfo
        assertEquals(0L, phone.minimumProtocolVersion)
        assertEquals(1L, phone.protocolVersion)
    }

    @Test
    fun `SyncStart is an unordered replication vector rather than a pair of identities`() {
        val phone = "12345678"
        val watch = "abcdef12"
        val historical = "98765432"
        val expected = mapOf(phone to 42L, watch to 100L, historical to 7L)
        val orders =
            listOf(
                linkedMapOf(watch to 100L, phone to 42L, historical to 7L),
                linkedMapOf(historical to 7L, phone to 42L, watch to 100L),
                linkedMapOf(phone to 42L, watch to 100L, historical to 7L),
            )
        orders.forEach { cursors ->
            val frame = WcsFrame.syncStartFrame(watch, cursors)
            val message =
                WcsFrame.decode(frame.copyOfRange(4, frame.size)) as WcsFrame.Incoming.SyncStart
            assertEquals(expected, message.cursors)
            assertEquals(100L, message.peerSequence)
            assertEquals(2L, message.version)
        }
    }

    @Test
    fun `SyncStart supports no cursors a single cursor and incomplete entries`() {
        for (cursors in listOf(emptyMap(), mapOf("abcdef12" to 100L))) {
            val frame = WcsFrame.syncStartFrame("abcdef12", cursors)
            val message =
                WcsFrame.decode(frame.copyOfRange(4, frame.size)) as WcsFrame.Incoming.SyncStart
            assertEquals(cursors, message.cursors)
        }
        val body =
            Proto.integer(1, -1) +
                Proto.bytes(2, Proto.string(1, "12345678")) +
                Proto.bytes(2, Proto.integer(2, 100)) +
                Proto.bytes(2, Proto.string(1, "abcdef12") + Proto.integer(2, 100))
        val message =
            WcsFrame.decode(Proto.bytes(1, Proto.bytes(8, body))) as WcsFrame.Incoming.SyncStart
        assertEquals(mapOf("abcdef12" to 100L), message.cursors)
        assertEquals(-1L, message.peerSequence)
    }

    @Test
    fun `wearable decoding preserves source separately from app signature`() {
        val body =
            Proto.string(3, "application-signature") +
                Proto.string(4, "12345678") +
                Proto.string(6, "/wcs_extension/internal/feature") +
                Proto.bytes(7, "{}".toByteArray()) +
                Proto.string(8, "abcdef12")
        val envelope = Proto.bytes(1, Proto.bytes(10, body))
        val message = WcsFrame.decode(envelope) as WcsFrame.Incoming.Wearable
        assertEquals("application-signature", message.senderNode)
        assertEquals("abcdef12", message.sourceNode)
        assertEquals("12345678", message.destNode)
    }

    @Test
    fun `registered node names and timestamps are serialized with a fresh content digest`() {
        val frame = WcsFrame.nodeInfoFrame("abc1234", "Test phone", 123456789L)
        val envelope = frame.copyOfRange(4, frame.size)
        val message = WcsFrame.decode(envelope) as WcsFrame.Incoming.NodeInfo
        assertEquals("abc1234", message.nodeId)
        assertEquals("Test phone", message.deviceName)
        assertEquals(123456789L, message.timestamp)
        val parsed = Proto.parse(envelope)
        assertEquals(WcsFrame.messageDigest(parsed.raw(1)!!), parsed.text(2))
        assertThrows(IllegalArgumentException::class.java) {
            WcsFrame.nodeInfoFrame("invalid!", "Phone", 1)
        }
    }
}
