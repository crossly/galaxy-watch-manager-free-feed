package dev.ricky.galaxywatchmanagerfree.feature

import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.*
import org.junit.Assert.*
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class StartupSyncCoordinatorTest {
    @Test fun `ready session queries current face and core device state without a screen refresh`() = runTest {
        val sent = mutableListOf<StartupSyncCoordinator.Target>()
        val sync = StartupSyncCoordinator(backgroundScope, sent::add)
        sync.start()
        runCurrent()
        assertEquals(StartupSyncCoordinator.Target.entries, sent)
        sync.stop()
    }

    @Test fun `only missing responses are retried with bounded attempts`() = runTest {
        val sent = mutableListOf<StartupSyncCoordinator.Target>()
        val sync = StartupSyncCoordinator(backgroundScope, sent::add)
        sync.start()
        runCurrent()
        StartupSyncCoordinator.Target.entries.filter { it != StartupSyncCoordinator.Target.WATCH_FACE }.forEach(sync::confirm)
        sent.clear()
        advanceTimeBy(14_001)
        runCurrent()
        assertEquals(List(3) { StartupSyncCoordinator.Target.WATCH_FACE }, sent)
        sent.clear()
        advanceTimeBy(60_000)
        runCurrent()
        assertTrue(sent.isEmpty())
        sync.stop()
    }

    @Test fun `disconnect cancels pending queries and a reconnect queries cached targets again`() = runTest {
        val sent = mutableListOf<StartupSyncCoordinator.Target>()
        val sync = StartupSyncCoordinator(backgroundScope, sent::add)
        sync.start()
        runCurrent()
        sync.start()
        assertEquals(4, sent.size)
        StartupSyncCoordinator.Target.entries.forEach(sync::confirm)
        sync.stop()
        advanceTimeBy(20_000)
        runCurrent()
        assertEquals(4, sent.size)
        sync.start()
        runCurrent()
        assertEquals(8, sent.size)
        sync.stop()
    }
}
