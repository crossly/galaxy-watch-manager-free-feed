package dev.ricky.galaxywatchmanagerfree.feature

import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class DeviceSnapshotTest {
    @Test
    fun `restart restores confirmed identity and face without restoring a live connection`() {
        val before =
            WatchState(
                connected = true,
                sessionReady = true,
                charging = true,
                batteryLevel = 93,
                deviceName = "Watch Ultra",
                modelNumber = "SM-L7050",
                firmware = "AX01",
                wearOs = "6",
                activeWatchfacePkg = "test.face",
                activeWatchfaceCls = "Face",
                activeWatchfaceFavoriteId = 9,
                activeWatchfacePreviewPath = "/watchfaces/preview.png",
                watchfaceOrderType = "recent",
                watchfaceFavoriteIds = listOf(9, 4),
                watchfaceUpdatedAt = 1000,
            )
        val restored = DeviceSnapshot.restore(DeviceSnapshot.encode(before), WatchState())
        assertEquals("SM-L7050", restored.modelNumber)
        assertEquals("test.face", restored.activeWatchfacePkg)
        assertEquals("/watchfaces/preview.png", restored.activeWatchfacePreviewPath)
        assertEquals(listOf(9, 4), restored.watchfaceFavoriteIds)
        assertEquals(1000L, restored.watchfaceUpdatedAt)
        assertFalse(restored.connected)
        assertFalse(restored.sessionReady)
        assertFalse(restored.charging)
        assertEquals(-1, restored.batteryLevel)
    }

    @Test
    fun `empty acknowledgement never clears the last confirmed face`() {
        val state =
            WatchState(
                activeWatchfacePkg = "test.face",
                activeWatchfaceCls = "Face",
                watchfaceUpdatedAt = 1000,
            )
        val ack = JSONObject().put("msgType", 3).put("result", 0).put("data", JSONObject())
        assertEquals(state, DeviceSnapshot.applyWatchface(state, ack, 2000))
    }

    @Test
    fun `failed command response cannot replace a confirmed face`() {
        val state = WatchState(activeWatchfacePkg = "test.face")
        val reply =
            JSONObject().put("result", 1).put("data", JSONObject().put("packageName", "other.face"))
        assertEquals(state, DeviceSnapshot.applyWatchface(state, reply, 2000))
    }

    @Test
    fun `valid query response replaces cached face and records confirmation time`() {
        val state = WatchState(activeWatchfacePkg = "old.face")
        val reply =
            JSONObject()
                .put(
                    "data",
                    JSONObject()
                        .put("packageName", "new.face")
                        .put("className", "Face")
                        .put("favoriteId", 3),
                )
        val result = DeviceSnapshot.applyWatchface(state, reply, 2000)
        assertEquals("new.face", result.activeWatchfacePkg)
        assertEquals("Face", result.activeWatchfaceCls)
        assertEquals(2000L, result.watchfaceUpdatedAt)
    }

    @Test
    fun `changing face without a favorite id clears the old favorite identity`() {
        val state =
            WatchState(
                activeWatchfacePkg = "old.face",
                activeWatchfaceCls = "OldFace",
                activeWatchfaceFavoriteId = 9,
            )
        val reply =
            JSONObject()
                .put(
                    "data",
                    JSONObject().put("packageName", "new.face").put("className", "NewFace"),
                )
        val result = DeviceSnapshot.applyWatchface(state, reply, 2000)
        assertEquals(-1, result.activeWatchfaceFavoriteId)
    }

    @Test
    fun `same face without a favorite id preserves its confirmed favorite identity`() {
        val state =
            WatchState(
                activeWatchfacePkg = "test.face",
                activeWatchfaceCls = "Face",
                activeWatchfaceFavoriteId = 9,
            )
        val reply = JSONObject().put("data", JSONObject().put("packageName", "test.face"))
        val result = DeviceSnapshot.applyWatchface(state, reply, 2000)
        assertEquals(9, result.activeWatchfaceFavoriteId)
        assertEquals("Face", result.activeWatchfaceCls)
    }

    @Test
    fun `a different favorite invalidates the previous preview`() {
        val state =
            WatchState(
                activeWatchfacePkg = "test.face",
                activeWatchfaceCls = "Face",
                activeWatchfaceFavoriteId = 9,
                activeWatchfacePreviewPath = "/watchfaces/preview.png",
            )
        val reply =
            JSONObject()
                .put("data", JSONObject().put("packageName", "test.face").put("favoriteId", 12))
        assertNull(DeviceSnapshot.applyWatchface(state, reply, 2000).activeWatchfacePreviewPath)
    }

    @Test
    fun `corrupt cache leaves the current state intact`() {
        val state = WatchState(deviceName = "Watch")
        assertEquals(state, DeviceSnapshot.restore("broken json", state))
    }
}
