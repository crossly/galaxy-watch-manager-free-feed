package dev.ricky.galaxywatchmanagerfree.wcs

import java.io.ByteArrayInputStream
import java.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class WearDataSnapshotTest {
    private fun item(
        path: String,
        sequence: Long,
        source: String = "watch",
        deleted: Boolean = false,
        extraBytes: Int = 0,
    ): ByteArray {
        val body =
            Proto.string(1, "settings") +
                Proto.string(2, "wear://watch/$path") +
                Proto.bytes(4, DataMapEncoder.encode(mapOf("enabled" to true))) +
                Proto.integer(5, sequence) +
                Proto.integer(6, if (deleted) 1 else 0) +
                Proto.string(7, source) +
                Proto.string(9, "signature") +
                if (extraBytes > 0) Proto.bytes(11, ByteArray(extraBytes)) else ByteArray(0)
        return Proto.bytes(1, Proto.bytes(9, body))
    }

    private fun syncStart(cursors: Map<String, Long>): Proto.Message {
        val frame = WcsFrame.syncStartFrame("watch", cursors)
        return Proto.parse(frame.copyOfRange(4, frame.size)).nested(1)!!.nested(8)!!
    }

    @Test
    fun `sync start sends durable cursors instead of captured constants`() {
        val frame =
            WcsFrame.syncStartFrame("watch", syncCursors = mapOf("watch" to 990, "phone" to 42))
        val start = Proto.parse(frame.copyOfRange(4, frame.size)).nested(1)!!.nested(8)!!
        val entries =
            start.fields[2]!!
                .map { Proto.parse(it as ByteArray) }
                .associate { it.text(1) to it.num(2) }
        assertEquals(mapOf("watch" to 990L, "phone" to 42L), entries)
        assertEquals(990L, start.num(1))
    }

    @Test
    fun `missing snapshot requests full sync without inventing another devices vector`() {
        val frame = WcsFrame.syncStartFrame("watch")
        val start = Proto.parse(frame.copyOfRange(4, frame.size)).nested(1)!!.nested(8)!!
        assertEquals(-1L, start.num(1))
        assertFalse(start.has(2))
    }

    @Test
    fun `compacted items restore with their cursors and latest revision`() {
        val store = WearDataSnapshot()
        store.accept(item("a", 1))
        store.accept(item("b", 2))
        store.accept(item("a", 3))
        val restored = WearDataSnapshot()
        assertTrue(restored.restore(store.encode()))
        assertEquals(mapOf("watch" to 3L), restored.cursors())
        assertEquals(2, restored.envelopes().size)
        assertEquals(
            setOf(2L, 3L),
            restored
                .envelopes()
                .map { (WcsFrame.decode(it) as WcsFrame.Incoming.WearPath).sequence }
                .toSet(),
        )
    }

    @Test
    fun `origins are tracked independently and tombstones survive a restart`() {
        val store = WearDataSnapshot()
        store.accept(item("a", 40))
        store.accept(item("b", 2, "other"))
        store.accept(item("a", 41, deleted = true))
        val restored = WearDataSnapshot()
        assertTrue(restored.restore(store.encode()))
        assertEquals(mapOf("watch" to 41L, "other" to 2L), restored.cursors())
        assertTrue(
            restored
                .envelopes()
                .map { WcsFrame.decode(it) as WcsFrame.Incoming.WearPath }
                .any { it.deleted }
        )
    }

    @Test
    fun `corrupt data cannot advertise an unbacked cursor`() {
        val store = WearDataSnapshot()
        assertFalse(store.restore("{broken"))
        assertTrue(store.cursors().isEmpty())
        assertFalse(store.accept(Proto.bytes(1, Proto.bytes(11, byteArrayOf()))))
        assertTrue(store.cursors().isEmpty())
    }

    @Test
    fun `legacy oversized snapshot keeps newest items but clears cursors for full resync`() {
        val json = JSONObject().put("schema", 1)
        val array = JSONArray()
        val encoder = Base64.getEncoder()
        // Old schema wrote no completeness marker, so a cursor cannot be trusted after pruning.
        for (i in 0 until 10_005) {
            array.put(encoder.encodeToString(item("path_$i", i.toLong())))
        }
        json.put("items", array)

        val restored = WearDataSnapshot()
        assertTrue(restored.restore(json.toString()))
        assertEquals(WearDataSnapshot.MAX_ITEMS, restored.envelopes().size)
        assertTrue(restored.cursors().isEmpty())
        assertEquals(setOf("watch"), restored.incompleteSources())

        val start = syncStart(restored.cursors())
        assertEquals(-1L, start.num(1))
        assertFalse(start.has(2))
    }

    @Test
    fun `source over item capacity drops its cursor so reconnect can recover every entry`() {
        val store = WearDataSnapshot()
        repeat(WearDataSnapshot.MAX_ITEMS + 1) { index ->
            assertTrue(store.accept(item("path_$index", index.toLong())))
        }
        assertEquals(WearDataSnapshot.MAX_ITEMS, store.envelopes().size)
        assertTrue(store.cursors().isEmpty())
        assertEquals(setOf("watch"), store.incompleteSources())

        val restored = WearDataSnapshot()
        assertTrue(restored.restore(store.encode()))
        assertEquals(WearDataSnapshot.MAX_ITEMS, restored.envelopes().size)
        assertTrue(restored.cursors().isEmpty())

        val start = syncStart(restored.cursors())
        assertEquals(-1L, start.num(1))
        assertFalse(start.has(2))
    }

    @Test
    fun `session sync start uses only cursors with a complete retained copy`() {
        val store = WearDataSnapshot(maxItems = 2)
        assertTrue(store.accept(item("a", 1)))
        assertTrue(store.accept(item("b", 2)))
        assertTrue(store.accept(item("c", 3)))
        assertTrue(store.accept(item("d", 1, "other")))

        val start = syncStart(dataItemSyncCursors(store))
        val entries =
            start.fields[2]!!
                .map { Proto.parse(it as ByteArray) }
                .associate { it.text(1) to it.num(2) }
        assertEquals(mapOf("other" to 1L), entries)
        assertEquals(-1L, start.num(1))
    }

    @Test
    fun `incomplete source does not invalidate other source cursors`() {
        val store = WearDataSnapshot(maxItems = 2)
        assertTrue(store.accept(item("a", 1)))
        assertTrue(store.accept(item("b", 2)))
        assertTrue(store.accept(item("c", 3)))
        assertTrue(store.accept(item("d", 1, "other")))

        assertEquals(mapOf("other" to 1L), store.cursors())
        assertEquals(setOf("watch"), store.incompleteSources())

        val restored = WearDataSnapshot(maxItems = 2)
        assertTrue(restored.restore(store.encode()))
        assertEquals(mapOf("other" to 1L), restored.cursors())
        assertEquals(setOf("watch"), restored.incompleteSources())
    }

    @Test
    fun `incomplete source accepts an older full dump instead of rejecting it`() {
        val store = WearDataSnapshot(maxItems = 2)
        assertTrue(store.accept(item("a", 1)))
        assertTrue(store.accept(item("b", 2)))
        assertTrue(store.accept(item("c", 3)))
        assertTrue(store.accept(item("d", 0)))
        assertTrue(
            store
                .envelopes()
                .map { (WcsFrame.decode(it) as WcsFrame.Incoming.WearPath).path }
                .contains("wear://watch/d")
        )
    }

    @Test
    fun `pruning a tombstone does not make its source incomplete`() {
        val store = WearDataSnapshot(maxItems = 2)
        assertTrue(store.accept(item("deleted", 1, deleted = true)))
        assertTrue(store.accept(item("a", 2)))
        assertTrue(store.accept(item("b", 3)))

        assertEquals(mapOf("watch" to 3L), store.cursors())
        assertTrue(store.incompleteSources().isEmpty())
        assertFalse(
            store.envelopes().any { (WcsFrame.decode(it) as WcsFrame.Incoming.WearPath).deleted }
        )
    }

    @Test
    fun `byte budget evicts entries and removes the affected source cursor`() {
        val unit = item("a", 1).size
        val store = WearDataSnapshot(maxBytes = unit * 2)
        assertTrue(store.accept(item("a", 1)))
        assertTrue(store.accept(item("b", 2)))
        assertEquals((unit * 2).toLong(), store.storedBytes())
        assertTrue(store.accept(item("c", 3)))

        assertEquals(2, store.envelopes().size)
        assertTrue(store.storedBytes() <= (unit * 2).toLong())
        assertTrue(store.cursors().isEmpty())
        assertEquals(setOf("watch"), store.incompleteSources())
    }

    @Test
    fun `same key replacement deducts the old envelope and preserves complete sources`() {
        val small = item("a", 1)
        val other = item("b", 1, "other")
        val large = item("a", 2, extraBytes = small.size * 2)
        val store = WearDataSnapshot(maxBytes = small.size + other.size + large.size)

        assertTrue(store.accept(small))
        assertTrue(store.accept(other))
        assertTrue(store.accept(large))
        assertEquals((other.size + large.size).toLong(), store.storedBytes())
        assertEquals(mapOf("watch" to 2L, "other" to 1L), store.cursors())

        val oversized = item("a", 3, extraBytes = large.size * 8)
        assertTrue(store.accept(oversized))
        assertEquals(other.size.toLong(), store.storedBytes())
        assertEquals(mapOf("other" to 1L), store.cursors())
        assertEquals(setOf("watch"), store.incompleteSources())
    }

    @Test
    fun `snapshot file read is bounded`() {
        val bytes = ByteArray(64) { 'a'.code.toByte() }
        assertNull(WearDataSnapshot.readEncoded(ByteArrayInputStream(bytes), limit = 32))
        assertEquals(
            "a".repeat(64),
            WearDataSnapshot.readEncoded(ByteArrayInputStream(bytes), limit = 64),
        )
    }

    @Test
    fun `schema two restore rejects state beyond configured bounds`() {
        val json =
            JSONObject()
                .put("schema", 2)
                .put(
                    "items",
                    JSONArray(
                        listOf(
                            Base64.getEncoder().encodeToString(item("a", 1)),
                            Base64.getEncoder().encodeToString(item("b", 2)),
                        )
                    ),
                )
                .put("cursors", JSONArray())
                .put("incomplete", JSONArray(listOf("watch")))

        val restored = WearDataSnapshot(maxItems = 1)
        assertFalse(restored.restore(json.toString()))
        assertTrue(restored.cursors().isEmpty())
        assertTrue(restored.envelopes().isEmpty())
    }

    @Test
    fun `malformed completeness metadata clears all restored state`() {
        val original = WearDataSnapshot()
        assertTrue(original.accept(item("a", 7)))
        val valid = original.encode()
        val malformed =
            listOf(
                JSONObject(valid).apply { remove("cursors") },
                JSONObject(valid).apply { remove("incomplete") },
                JSONObject(valid).put("cursors", JSONArray().put(JSONObject.NULL)),
                JSONObject(valid).put("incomplete", JSONArray().put("")),
                JSONObject(valid).put("incomplete", JSONArray().put(42)),
                JSONObject(valid).apply {
                    getJSONArray("cursors").getJSONObject(0).put("source", 42)
                },
                JSONObject(valid).apply {
                    getJSONArray("cursors").getJSONObject(0).put("sequence", "7")
                },
                JSONObject(valid).apply {
                    getJSONArray("cursors").getJSONObject(0).put("sequence", 7.5)
                },
                JSONObject(valid).put("full_sync", "false"),
                JSONObject(valid).put("schema", "2"),
            )
        for (json in malformed) {
            val restored = WearDataSnapshot()
            assertTrue(restored.accept(item("existing", 1, "other")))
            assertFalse(restored.restore(json.toString()))
            assertTrue(restored.envelopes().isEmpty())
            assertTrue(restored.cursors().isEmpty())
            assertTrue(restored.incompleteSources().isEmpty())
            assertEquals(0L, restored.storedBytes())
        }
    }

    @Test
    fun `restored cursor retains sequence guard after its tombstone was pruned`() {
        val original = WearDataSnapshot(maxItems = 2)
        assertTrue(original.accept(item("a", 1)))
        assertTrue(original.accept(item("b", 9, deleted = true)))
        assertTrue(original.accept(item("c", 1, "other")))
        assertEquals(mapOf("watch" to 9L, "other" to 1L), original.cursors())

        val restored = WearDataSnapshot(maxItems = 2)
        assertTrue(restored.restore(original.encode()))
        assertFalse(restored.accept(item("b", 8)))
        assertEquals(mapOf("watch" to 9L, "other" to 1L), restored.cursors())
    }

    @Test
    fun `restore rejects cursor behind a retained revision`() {
        val original = WearDataSnapshot()
        assertTrue(original.accept(item("a", 7)))
        val json = JSONObject(original.encode())
        json.getJSONArray("cursors").getJSONObject(0).put("sequence", 6)
        val restored = WearDataSnapshot()
        assertFalse(restored.restore(json.toString()))
        assertTrue(restored.envelopes().isEmpty())
        assertTrue(restored.cursors().isEmpty())
    }

    @Test
    fun `restore enforces byte budget before retaining entries`() {
        val original = WearDataSnapshot()
        assertTrue(original.accept(item("a", 1, extraBytes = 1024)))
        val restored = WearDataSnapshot(maxBytes = 256)
        assertFalse(restored.restore(original.encode()))
        assertTrue(restored.envelopes().isEmpty())
        assertTrue(restored.cursors().isEmpty())
        assertEquals(0L, restored.storedBytes())
    }

    @Test
    fun `same item accepts an update from a source with an independent sequence`() {
        val store = WearDataSnapshot()
        assertTrue(store.accept(item("a", 100)))
        assertTrue(store.accept(item("a", 1, "phone")))
        assertEquals(mapOf("watch" to 100L, "phone" to 1L), store.cursors())
        val retained = WcsFrame.decode(store.envelopes().single()) as WcsFrame.Incoming.WearPath
        assertEquals("phone", retained.sourceNode)
        assertEquals(1L, retained.sequence)
    }

    @Test
    fun `source tracking overflow remains bounded and requires full sync after restore`() {
        val store = WearDataSnapshot(maxItems = 1)
        repeat(WearDataSnapshot.MAX_ITEMS + 1) { index ->
            assertTrue(store.accept(item("a", 1, "source_$index")))
        }
        assertTrue(store.cursors().isEmpty())
        val restored = WearDataSnapshot(maxItems = 1)
        assertTrue(restored.restore(store.encode()))
        assertTrue(restored.accept(item("b", 2, "fresh")))
        assertTrue(restored.cursors().isEmpty())
        assertTrue(restored.storedBytes() <= WearDataSnapshot.MAX_TOTAL_BYTES)
    }

    @Test
    fun `long source metadata falls back to bounded full sync state`() {
        val source = "s".repeat(300 * 1024)
        val store = WearDataSnapshot()
        assertTrue(store.accept(item("a", 1, source)))
        assertTrue(store.cursors().isEmpty())
        val encoded = store.encode()
        assertTrue(encoded.toByteArray().size <= WearDataSnapshot.MAX_ENCODED_BYTES)
        val restored = WearDataSnapshot()
        assertTrue(restored.restore(encoded))
        assertTrue(restored.cursors().isEmpty())
    }

    @Test
    fun `default byte budget bounds a few large items through codec restore`() {
        val store = WearDataSnapshot()
        repeat(3) { index ->
            assertTrue(
                store.accept(item("large_$index", index.toLong(), extraBytes = 3 * 1024 * 1024))
            )
            assertTrue(store.storedBytes() <= WearDataSnapshot.MAX_TOTAL_BYTES)
        }
        assertEquals(2, store.envelopes().size)
        assertTrue(store.cursors().isEmpty())
        val encoded = store.encode()
        assertTrue(encoded.toByteArray().size <= WearDataSnapshot.MAX_ENCODED_BYTES)
        val restored = WearDataSnapshot()
        assertTrue(restored.restore(encoded))
        assertEquals(store.storedBytes(), restored.storedBytes())
        assertTrue(restored.cursors().isEmpty())
    }

    @Test
    fun `accept caps stored items at MAX_ITEMS and evicts tombstones first`() {
        val store = WearDataSnapshot()
        // Add a tombstone first
        store.accept(item("tombstone", 0, deleted = true))
        for (i in 1..WearDataSnapshot.MAX_ITEMS) {
            store.accept(item("active_$i", i.toLong()))
        }
        assertEquals(WearDataSnapshot.MAX_ITEMS, store.envelopes().size)
        // The tombstone should have been pruned to make room for active items
        val hasTombstone =
            store.envelopes().any { (WcsFrame.decode(it) as WcsFrame.Incoming.WearPath).deleted }
        assertFalse(hasTombstone)
    }
}
