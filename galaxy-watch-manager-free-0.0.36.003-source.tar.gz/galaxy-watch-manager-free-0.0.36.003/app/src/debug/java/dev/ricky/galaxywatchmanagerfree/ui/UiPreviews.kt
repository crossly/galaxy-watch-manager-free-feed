package dev.ricky.galaxywatchmanagerfree.ui

import android.content.res.Configuration
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.feature.HeartRateLog
import dev.ricky.galaxywatchmanagerfree.ui.components.GroupedCard
import dev.ricky.galaxywatchmanagerfree.ui.components.GroupedCardRow
import dev.ricky.galaxywatchmanagerfree.ui.components.HeartRateChart
import dev.ricky.galaxywatchmanagerfree.ui.screens.HealthSummary
import dev.ricky.galaxywatchmanagerfree.ui.screens.StepGoalSheet
import dev.ricky.galaxywatchmanagerfree.ui.theme.DeepCanvas
import dev.ricky.galaxywatchmanagerfree.ui.theme.HealthHeart
import dev.ricky.galaxywatchmanagerfree.ui.theme.WatchFreeTheme
import java.time.LocalDate
import java.time.ZoneId

@Preview(name = "Phone EN", locale = "en", widthDp = 360)
@Preview(name = "Narrow large EN", locale = "en", widthDp = 320, fontScale = 2f)
@Preview(
    name = "Dark ZH",
    locale = "zh-rCN",
    widthDp = 360,
    uiMode = Configuration.UI_MODE_NIGHT_YES,
)
@Preview(name = "Wide EN", locale = "en", widthDp = 840)
@Composable
private fun HealthCardAndChartPreview() {
    val day = LocalDate.of(2026, 11, 1)
    val zone = ZoneId.of("UTC")
    val points =
        listOf(8 to 68, 12 to 72, 18 to 81).map { (hour, bpm) ->
            HeartRateLog.Point(day.atTime(hour, 0).atZone(zone).toInstant().toEpochMilli(), bpm)
        }
    WatchFreeTheme {
        Column(
            Modifier.background(DeepCanvas).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            HealthSummary(
                title = stringResource(R.string.heart_rate),
                value = "72",
                unit = stringResource(R.string.bpm_2),
                icon = Icons.Default.Favorite,
                accent = HealthHeart,
                modifier = Modifier,
                wide = true,
                onClick = {},
            )
            GroupedCard { HeartRateChart(points, day, zone = zone) }
            GroupedCard { HeartRateChart(emptyList(), day, zone = zone) }
            GroupedCard(innerPadding = 0.dp) {
                GroupedCardRow(
                    title = stringResource(R.string.daily_step_goal),
                    subtitle = stringResource(R.string.used_for_daily_progress_and_goal_streaks),
                    trailing = { Text("10,000") },
                    onClick = {},
                )
            }
        }
    }
}

@Preview(name = "Goal phone", locale = "en", widthDp = 360, heightDp = 800)
@Preview(
    name = "Goal wide dark",
    locale = "zh-rCN",
    widthDp = 840,
    heightDp = 900,
    uiMode = Configuration.UI_MODE_NIGHT_YES,
)
@Composable
private fun StepGoalPreview() {
    WatchFreeTheme {
        Column(Modifier.fillMaxSize().background(DeepCanvas)) {
            StepGoalSheet(10_000, canReset = true, onDismiss = {}, onConfirm = {}, onReset = {})
        }
    }
}
