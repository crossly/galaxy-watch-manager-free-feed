package dev.ricky.galaxywatchmanagerfree

import android.content.Context
import android.content.ContextWrapper
import android.content.SharedPreferences
import android.content.res.Configuration
import android.os.LocaleList
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.test.core.app.ApplicationProvider
import dev.ricky.galaxywatchmanagerfree.core.ApkUpdater
import dev.ricky.galaxywatchmanagerfree.core.AppUpdate
import dev.ricky.galaxywatchmanagerfree.core.DownloadMirror
import dev.ricky.galaxywatchmanagerfree.core.UpdateChecker
import dev.ricky.galaxywatchmanagerfree.ui.components.UpdateCard
import dev.ricky.galaxywatchmanagerfree.ui.theme.WatchFreeTheme
import java.io.File
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketException
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread
import org.json.JSONObject
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test

class UpdateChannelTest {
    @get:Rule val compose = createComposeRule()
    private val app = ApplicationProvider.getApplicationContext<Context>()
    private val prefix = "update_test_${UUID.randomUUID()}_"
    private val cache = File(app.cacheDir, prefix).apply { mkdirs() }
    private val server = FeedServer()
    private val context = isolatedContext(app)
    private val prefs = context.getSharedPreferences("watchfree_update", Context.MODE_PRIVATE)
    private val nextBase = AppUpdate.versionParts(BuildConfig.VERSION_NAME)[2] + 1
    private val nightlyName = "0.0.$nextBase.001"
    private val stableFeed = feed("0.0.1", 1)

    @Before
    fun prepare() {
        prefs
            .edit()
            .putString("debug_feed_url", server.url("/stable"))
            .putString("debug_nightly_feed_url", server.url("/nightly"))
            .putInt("auto_check_hours", 0)
            .commit()
        server.respond = { path ->
            if (path == "/stable") Response(stableFeed) else Response("", 404)
        }
        compose.runOnIdle {
            prefs
                .edit()
                .putString("channel", opposite(UpdateChecker.state.value.channel).id)
                .commit()
            UpdateChecker.restoreChannel(context)
            prefs.edit().remove("channel").commit()
            UpdateChecker.restoreChannel(context)
        }
    }

    @After
    fun cleanup() {
        compose.runOnIdle {
            prefs
                .edit()
                .putString("channel", opposite(UpdateChecker.state.value.channel).id)
                .commit()
            UpdateChecker.restoreChannel(context)
            prefs.edit().remove("channel").commit()
            UpdateChecker.restoreChannel(context)
            ApkUpdater.cancel()
        }
        server.close()
        app.deleteSharedPreferences(prefix + "watchfree_update")
        cache.deleteRecursively()
        assertTrue(server.errors.toString(), server.errors.isEmpty())
    }

    @Test
    fun stableIsDefaultAndSelectedChannelSurvivesOpeningPreferencesAgain() {
        assertEquals(AppUpdate.Channel.STABLE, UpdateChecker.channel(context))
        compose.runOnIdle { UpdateChecker.setChannel(context, AppUpdate.Channel.NIGHTLY) }
        awaitCheck(AppUpdate.Channel.NIGHTLY)
        assertEquals(AppUpdate.Channel.NIGHTLY, UpdateChecker.channel(isolatedContext(app)))
        assertEquals("nightly", prefs.getString("channel", null))
        prefs.edit().putString("channel", "unknown-channel").commit()
        assertEquals(AppUpdate.Channel.STABLE, UpdateChecker.channel(context))
    }

    @Test
    fun delayedNightlyResponseCannotReplaceStableResultOrStartItsDownload() {
        val entered = CountDownLatch(1)
        val release = CountDownLatch(1)
        server.respond = { path ->
            when (path) {
                "/stable" -> Response(stableFeed)
                "/nightly" -> {
                    entered.countDown()
                    check(release.await(5, TimeUnit.SECONDS))
                    Response(feed(nightlyName, nextBase * 1000 + 1, server.url("/nightly.apk")))
                }
                else -> Response("synthetic apk")
            }
        }
        compose.runOnIdle { UpdateChecker.setChannel(context, AppUpdate.Channel.NIGHTLY) }
        assertTrue(entered.await(5, TimeUnit.SECONDS))
        compose.runOnIdle { UpdateChecker.setChannel(context, AppUpdate.Channel.STABLE) }
        awaitCheck(AppUpdate.Channel.STABLE)
        release.countDown()
        compose.waitUntil(5_000) { server.served.contains("/nightly") }
        checkStableAgain()
        assertFalse(server.requests.contains("/nightly.apk"))
        assertEquals(0L, prefs.getLong("last_check_at_nightly", 0L))
        assertEquals(ApkUpdater.Phase.IDLE, ApkUpdater.state.value.phase)
    }

    @Test
    fun delayedNightlyHttpFailureCannotCancelTheNewStableDownload() {
        val oldEntered = CountDownLatch(1)
        val oldRelease = CountDownLatch(1)
        val apkEntered = CountDownLatch(1)
        val apkRelease = CountDownLatch(1)
        val switched = AtomicBoolean(false)
        val stableName = "0.0.${nextBase + 1}"
        server.respond = { path ->
            when (path) {
                "/stable" ->
                    Response(
                        if (switched.get())
                            feed(stableName, (nextBase + 1) * 1000, server.url("/stable.apk"))
                        else stableFeed
                    )
                "/nightly" -> {
                    oldEntered.countDown()
                    check(oldRelease.await(5, TimeUnit.SECONDS))
                    Response("synthetic server failure", 500)
                }
                else -> {
                    apkEntered.countDown()
                    check(apkRelease.await(5, TimeUnit.SECONDS))
                    Response("synthetic apk")
                }
            }
        }
        try {
            compose.runOnIdle { UpdateChecker.setChannel(context, AppUpdate.Channel.NIGHTLY) }
            assertTrue(oldEntered.await(5, TimeUnit.SECONDS))
            switched.set(true)
            compose.runOnIdle { UpdateChecker.setChannel(context, AppUpdate.Channel.STABLE) }
            awaitCheck(AppUpdate.Channel.STABLE)
            assertTrue(apkEntered.await(5, TimeUnit.SECONDS))
            oldRelease.countDown()
            compose.waitUntil(5_000) { server.served.contains("/nightly") }
            compose.runOnIdle {
                assertEquals(
                    UpdateChecker.Status.UPDATE_AVAILABLE,
                    UpdateChecker.state.value.status,
                )
                assertEquals(stableName, UpdateChecker.state.value.info?.versionName)
                assertEquals(ApkUpdater.Phase.DOWNLOADING, ApkUpdater.state.value.phase)
                assertEquals(stableName, ApkUpdater.state.value.versionName)
            }
            assertEquals(0L, prefs.getLong("last_check_at_nightly", 0L))
        } finally {
            compose.runOnIdle { ApkUpdater.cancel() }
            oldRelease.countDown()
            apkRelease.countDown()
        }
    }

    @Test
    fun switchingWhileNightlyDownloadIsBlockedClearsTheOldInstallState() {
        val entered = CountDownLatch(1)
        val release = CountDownLatch(1)
        server.respond = { path ->
            when (path) {
                "/stable" -> Response(stableFeed)
                "/nightly" ->
                    Response(feed(nightlyName, nextBase * 1000 + 1, server.url("/nightly.apk")))
                else -> {
                    entered.countDown()
                    check(release.await(5, TimeUnit.SECONDS))
                    Response("synthetic apk")
                }
            }
        }
        compose.runOnIdle { UpdateChecker.setChannel(context, AppUpdate.Channel.NIGHTLY) }
        assertTrue(entered.await(5, TimeUnit.SECONDS))
        compose.runOnIdle {
            assertEquals(ApkUpdater.Phase.DOWNLOADING, ApkUpdater.state.value.phase)
            UpdateChecker.setChannel(context, AppUpdate.Channel.STABLE)
            assertEquals(ApkUpdater.Phase.IDLE, ApkUpdater.state.value.phase)
        }
        awaitCheck(AppUpdate.Channel.STABLE)
        release.countDown()
        compose.waitUntil(5_000) { server.served.contains("/nightly.apk") }
        checkStableAgain()
        assertEquals(ApkUpdater.Phase.IDLE, ApkUpdater.state.value.phase)
        assertEquals(null, ApkUpdater.state.value.filePath)
    }

    @Test
    fun downloadMirrorDefaultsOffAndPersistsSelection() {
        assertEquals(DownloadMirror.OFF, UpdateChecker.mirror(context))
        compose.runOnIdle { UpdateChecker.setMirror(context, DownloadMirror.GH_PROXY) }
        assertEquals(DownloadMirror.GH_PROXY, UpdateChecker.mirror(isolatedContext(app)))
        assertEquals("gh-proxy", prefs.getString("download_mirror", null))
        prefs.edit().putString("download_mirror", "removed-mirror").commit()
        assertEquals(DownloadMirror.OFF, UpdateChecker.mirror(context))
    }

    @Test
    fun switchingMirrorRestartsCheckAndIgnoresTheOldFailure() {
        val entered = CountDownLatch(1)
        val release = CountDownLatch(1)
        val firstNightly = AtomicBoolean(true)
        server.respond = { path ->
            when {
                path == "/stable" -> Response(stableFeed)
                firstNightly.compareAndSet(true, false) -> {
                    entered.countDown()
                    check(release.await(5, TimeUnit.SECONDS))
                    Response("synthetic server failure", 500)
                }
                else -> Response(feed(nightlyName, nextBase * 1000 + 1))
            }
        }
        try {
            compose.runOnIdle { UpdateChecker.setChannel(context, AppUpdate.Channel.NIGHTLY) }
            assertTrue(entered.await(5, TimeUnit.SECONDS))
            compose.runOnIdle { UpdateChecker.setMirror(context, DownloadMirror.GH_PROXY) }
            awaitCheck(AppUpdate.Channel.NIGHTLY)
            release.countDown()
            compose.waitUntil(5_000) { server.served.count { it == "/nightly" } == 2 }
            compose.runOnIdle {
                assertEquals(
                    UpdateChecker.Status.UPDATE_AVAILABLE,
                    UpdateChecker.state.value.status,
                )
                assertEquals(nightlyName, UpdateChecker.state.value.info?.versionName)
            }
        } finally {
            release.countDown()
        }
    }

    @Test
    fun switchingMirrorRestartsDownloadAndIgnoresTheOldFailure() {
        val oldEntered = CountDownLatch(1)
        val oldRelease = CountDownLatch(1)
        val newEntered = CountDownLatch(1)
        val newRelease = CountDownLatch(1)
        val firstDownload = AtomicBoolean(true)
        server.respond = { path ->
            when {
                path == "/stable" -> Response(stableFeed)
                path == "/nightly" ->
                    Response(feed(nightlyName, nextBase * 1000 + 1, server.url("/nightly.apk")))
                firstDownload.compareAndSet(true, false) -> {
                    oldEntered.countDown()
                    check(oldRelease.await(5, TimeUnit.SECONDS))
                    Response("synthetic server failure", 500)
                }
                else -> {
                    newEntered.countDown()
                    check(newRelease.await(5, TimeUnit.SECONDS))
                    Response("synthetic apk")
                }
            }
        }
        try {
            compose.runOnIdle { UpdateChecker.setChannel(context, AppUpdate.Channel.NIGHTLY) }
            assertTrue(oldEntered.await(5, TimeUnit.SECONDS))
            compose.runOnIdle { UpdateChecker.setMirror(context, DownloadMirror.GH_FAST) }
            assertTrue(newEntered.await(5, TimeUnit.SECONDS))
            oldRelease.countDown()
            compose.waitUntil(5_000) { server.served.contains("/nightly.apk") }
            compose.runOnIdle {
                assertEquals(ApkUpdater.Phase.DOWNLOADING, ApkUpdater.state.value.phase)
                assertEquals(nightlyName, ApkUpdater.state.value.versionName)
            }
        } finally {
            compose.runOnIdle { ApkUpdater.cancel() }
            oldRelease.countDown()
            newRelease.countDown()
        }
    }

    @Test
    fun recentStableCheckDoesNotSuppressFirstAutomaticNightlyCheck() {
        val now = System.currentTimeMillis()
        prefs
            .edit()
            .putString("channel", "nightly")
            .putInt("auto_check_hours", 12)
            .putLong("last_check_at", now)
            .putLong("last_check_at_stable", now)
            .commit()
        compose.runOnIdle { UpdateChecker.maybeAutoCheck(context) }
        awaitCheck(AppUpdate.Channel.NIGHTLY)
        assertTrue(server.requests.contains("/stable"))
        assertTrue(server.requests.contains("/nightly"))
        assertTrue(prefs.getLong("last_check_at_nightly", 0L) > 0L)
        assertEquals(now, prefs.getLong("last_check_at_stable", 0L))
    }

    @Test
    fun nightlyChannelFallsBackWhenMissingAndAcceptsANewerStableRelease() {
        compose.runOnIdle { UpdateChecker.setChannel(context, AppUpdate.Channel.NIGHTLY) }
        awaitCheck(AppUpdate.Channel.NIGHTLY)
        assertEquals("0.0.1", UpdateChecker.state.value.info?.versionName)
        val laterStable = "0.0.${nextBase + 1}"
        server.respond = { path ->
            if (path == "/stable") Response(feed(laterStable, (nextBase + 1) * 1000))
            else Response(feed(nightlyName, nextBase * 1000 + 1))
        }
        compose.runOnIdle { UpdateChecker.check(context) }
        awaitCheck(AppUpdate.Channel.NIGHTLY)
        assertEquals(laterStable, UpdateChecker.state.value.info?.versionName)
        assertEquals(AppUpdate.Channel.STABLE, UpdateChecker.state.value.info?.channel)
        assertEquals(UpdateChecker.Status.UPDATE_AVAILABLE, UpdateChecker.state.value.status)
    }

    @Test
    fun englishDarkChannelChoiceWorksOnNarrowScreenWithLargeText() {
        checkChannelChoice("en", dark = true)
    }

    @Test
    fun chineseLightChannelChoiceWorksOnNarrowScreenWithLargeText() {
        checkChannelChoice("zh-CN", dark = false)
    }

    private fun checkChannelChoice(locale: String, dark: Boolean) {
        val configuration =
            Configuration(app.resources.configuration).apply {
                setLocales(LocaleList.forLanguageTags(locale))
            }
        val localized = isolatedContext(app.createConfigurationContext(configuration))
        val strings = localized.resources
        compose.setContent {
            val density = LocalDensity.current.density
            CompositionLocalProvider(
                LocalContext provides localized,
                LocalConfiguration provides configuration,
                LocalDensity provides Density(density, 1.5f),
            ) {
                WatchFreeTheme(darkTheme = dark) {
                    Column(Modifier.width(320.dp).verticalScroll(rememberScrollState())) {
                        UpdateCard(localized)
                    }
                }
            }
        }
        val title = strings.getString(R.string.update_channel)
        compose.onNodeWithText(title).performScrollTo().performClick()
        compose.onNodeWithText(strings.getString(R.string.update_channel_nightly)).performClick()
        awaitCheck(AppUpdate.Channel.NIGHTLY)
        assertEquals(AppUpdate.Channel.NIGHTLY, UpdateChecker.channel(isolatedContext(app)))
        compose
            .onNodeWithText(strings.getString(R.string.update_channel_nightly_hint))
            .performScrollTo()
            .assertIsDisplayed()
        compose.onNodeWithText(title).performScrollTo().performClick()
        compose.onNodeWithText(strings.getString(R.string.update_channel_stable)).performClick()
        awaitCheck(AppUpdate.Channel.STABLE)
        assertEquals(AppUpdate.Channel.STABLE, UpdateChecker.channel(context))
        val mirrorTitle = strings.getString(R.string.update_mirror_title)
        listOf(
                DownloadMirror.GH_PROXY,
                DownloadMirror.GH_PROXY_NET,
                DownloadMirror.GH_FAST,
                DownloadMirror.OFF,
            )
            .forEach { mirror ->
                compose.onNodeWithText(mirrorTitle).performScrollTo().performClick()
                val label =
                    if (mirror == DownloadMirror.OFF) strings.getString(R.string.update_mirror_off)
                    else mirror.host
                compose.onNodeWithText(label).performClick()
                assertEquals(mirror, UpdateChecker.mirror(isolatedContext(app)))
            }
        compose
            .onNodeWithText(strings.getString(R.string.update_mirror_hint))
            .performScrollTo()
            .assertIsDisplayed()
    }

    private fun checkStableAgain() {
        val before = server.requests.count { it == "/stable" }
        compose.runOnIdle { UpdateChecker.check(context) }
        compose.waitUntil(5_000) { server.requests.count { it == "/stable" } > before }
        awaitCheck(AppUpdate.Channel.STABLE)
        compose.runOnIdle { assertEquals("0.0.1", UpdateChecker.state.value.info?.versionName) }
    }

    private fun awaitCheck(channel: AppUpdate.Channel) {
        compose.waitUntil(5_000) {
            UpdateChecker.state.value.let {
                it.channel == channel &&
                    it.status != UpdateChecker.Status.CHECKING &&
                    it.status != UpdateChecker.Status.IDLE
            }
        }
        compose.runOnIdle {
            assertFalse(UpdateChecker.state.value.status == UpdateChecker.Status.ERROR)
        }
    }

    private fun isolatedContext(base: Context): Context =
        object : ContextWrapper(base) {
            override fun getApplicationContext(): Context = this

            override fun getCacheDir(): File = cache

            override fun getSharedPreferences(name: String, mode: Int): SharedPreferences =
                app.getSharedPreferences(prefix + name, mode)
        }

    private fun opposite(channel: AppUpdate.Channel): AppUpdate.Channel =
        if (channel == AppUpdate.Channel.STABLE) AppUpdate.Channel.NIGHTLY
        else AppUpdate.Channel.STABLE

    private fun feed(name: String, code: Int, apkUrl: String? = null): String =
        JSONObject()
            .put("version_name", name)
            .put("version_code", code)
            .apply {
                if (apkUrl != null) {
                    put("apk_url", apkUrl)
                    put("apk_size", "synthetic apk".toByteArray().size)
                    put("sha256", "a".repeat(64))
                }
            }
            .toString()

    private data class Response(val body: String, val status: Int = 200)

    private class FeedServer : AutoCloseable {
        private val listener = ServerSocket(0, 8, InetAddress.getByName("127.0.0.1"))
        private val sockets = ConcurrentHashMap.newKeySet<Socket>()
        private val workers =
            Executors.newCachedThreadPool { task ->
                Thread(task, "update-test-http").apply { isDaemon = true }
            }
        val requests = ConcurrentLinkedQueue<String>()
        val served = ConcurrentLinkedQueue<String>()
        val errors = ConcurrentLinkedQueue<Exception>()
        @Volatile var respond: (String) -> Response = { Response("", 404) }
        private val acceptor =
            thread(name = "update-test-accept", isDaemon = true) {
                try {
                    while (!listener.isClosed) {
                        val socket = listener.accept()
                        sockets += socket
                        workers.execute { handle(socket) }
                    }
                } catch (error: SocketException) {
                    if (!listener.isClosed) errors += error
                }
            }

        fun url(path: String): String = "http://127.0.0.1:${listener.localPort}$path"

        private fun handle(socket: Socket) {
            var path: String? = null
            try {
                socket.use {
                    it.soTimeout = 5_000
                    val input = it.getInputStream().bufferedReader()
                    path = input.readLine()?.split(' ')?.getOrNull(1) ?: return
                    while (!input.readLine().isNullOrEmpty()) {}
                    requests += path!!
                    val response = respond(path!!)
                    val bytes = response.body.toByteArray(Charsets.UTF_8)
                    val header =
                        "HTTP/1.1 ${response.status} Test\r\nContent-Type: application/json\r\n" +
                            "Content-Length: ${bytes.size}\r\nConnection: close\r\n\r\n"
                    it.getOutputStream().apply {
                        write(header.toByteArray(Charsets.US_ASCII))
                        write(bytes)
                        flush()
                    }
                }
            } catch (error: Exception) {
                if (!listener.isClosed && error !is SocketException) errors += error
            } finally {
                path?.let { served += it }
                sockets -= socket
            }
        }

        override fun close() {
            listener.close()
            sockets.forEach { it.close() }
            workers.shutdownNow()
            acceptor.join(1_000)
            workers.awaitTermination(1, TimeUnit.SECONDS)
        }
    }
}
