package dev.ricky.galaxywatchmanagerfree

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.hasText
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollToNode
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import dev.ricky.galaxywatchmanagerfree.feature.SleepParser
import dev.ricky.galaxywatchmanagerfree.feature.WatchState
import dev.ricky.galaxywatchmanagerfree.ui.components.SleepHypnogram
import dev.ricky.galaxywatchmanagerfree.ui.screens.SleepDetailSheet
import dev.ricky.galaxywatchmanagerfree.ui.theme.WatchFreeTheme
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class SleepSessionsUiTest {
    @get:Rule val compose = createComposeRule()
    private val app = ApplicationProvider.getApplicationContext<android.content.Context>()

    private fun session(id: String, startHour: Int, endHour: Int, minutes: Int) =
        SleepParser.Session(
            startMillis = startHour * 3_600_000L,
            endMillis = endHour * 3_600_000L,
            segments = emptyList(),
            efficiency = 90,
            score = null,
            reportedSleepMinutes = minutes,
            id = id,
        )

    @Test
    fun napAndNightAreShownTogetherWithCombinedTitle() {
        val night = session("night", 0, 7, 360)
        val nap = session("nap", 13, 14, 40)
        compose.setContent {
            WatchFreeTheme(darkTheme = false) {
                SleepDetailSheet(
                    state = WatchState(sleep = night, sleepSessions = listOf(night, nap)),
                    onDismiss = {},
                )
            }
        }
        listOf(
                R.string.sleep_day_sessions_title,
                R.string.sleep_main_session,
                R.string.sleep_nap_session,
            )
            .forEach { resource ->
                val text = app.getString(resource)
                compose.onNodeWithTag("sleep_detail_list").performScrollToNode(hasText(text))
                compose.onNodeWithText(text).assertIsDisplayed()
            }
    }

    @Test
    fun singleSessionKeepsTheSheetWithoutBreakdownCard() {
        val night = session("night", 0, 7, 360)
        compose.setContent {
            WatchFreeTheme(darkTheme = false) {
                SleepDetailSheet(
                    state = WatchState(sleep = night, sleepSessions = listOf(night)),
                    onDismiss = {},
                )
            }
        }
        compose.onNodeWithText(app.getString(R.string.time_asleep)).assertIsDisplayed()
    }

    @Test
    fun hypnogramDescriptionIncludesTheNightAndEveryNap() {
        fun stagedSession(id: String, startHour: Int, endHour: Int) =
            SleepParser.Session(
                startMillis = startHour * 3_600_000L,
                endMillis = endHour * 3_600_000L,
                segments =
                    listOf(
                        SleepParser.Segment(
                            startHour * 3_600_000L,
                            endHour * 3_600_000L,
                            SleepParser.Stage.LIGHT,
                        )
                    ),
                efficiency = 90,
                score = null,
                id = id,
            )
        val sessions =
            listOf(
                stagedSession("night", 0, 7),
                stagedSession("nap-1", 13, 14),
                stagedSession("nap-2", 17, 18),
            )
        compose.setContent {
            WatchFreeTheme(darkTheme = false) { SleepHypnogram(sessions = sessions) }
        }
        compose
            .onNodeWithContentDescription(
                app.getString(R.string.sleep_hypnogram_description, sessions.size)
            )
            .assertIsDisplayed()
        compose.onNodeWithTag("sleep_hypnogram").assertIsDisplayed()
    }

    @Test
    fun manualNapShowsManualLabelAndCanOpenTheAddDialog() {
        val night = session("night", 0, 7, 360)
        val manual =
            SleepParser.Session(
                startMillis = 13 * 3_600_000L,
                endMillis = 14 * 3_600_000L,
                segments = emptyList(),
                efficiency = null,
                score = null,
                reportedSleepMinutes = 45,
                id = "manual:13:14",
                analysisSource = "manual",
            )
        compose.setContent {
            WatchFreeTheme(darkTheme = false) {
                SleepDetailSheet(
                    state = WatchState(sleep = night, sleepSessions = listOf(night, manual)),
                    onDismiss = {},
                    onAddNap = { _, _ -> true },
                    onDeleteNap = { _, _ -> true },
                )
            }
        }
        val manualLabel = app.getString(R.string.sleep_manual_session)
        compose.onNodeWithTag("sleep_detail_list").performScrollToNode(hasText(manualLabel))
        compose.onNodeWithText(manualLabel).assertIsDisplayed()
        compose.onNodeWithTag("sleep_detail_list").performScrollToNode(hasTestTag("tag_add_nap"))
        compose.onNodeWithTag("tag_add_nap").performClick()
        compose.onNodeWithTag("tag_save_nap").assertIsDisplayed()
    }
}
