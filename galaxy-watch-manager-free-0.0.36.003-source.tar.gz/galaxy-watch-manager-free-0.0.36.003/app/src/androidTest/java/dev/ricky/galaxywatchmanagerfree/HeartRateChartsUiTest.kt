package dev.ricky.galaxywatchmanagerfree

import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.test.SemanticsMatcher
import androidx.compose.ui.test.assert
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.click
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performKeyInput
import androidx.compose.ui.test.performSemanticsAction
import androidx.compose.ui.test.performTouchInput
import androidx.compose.ui.test.pressKey
import androidx.compose.ui.test.swipe
import androidx.compose.ui.unit.dp
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import dev.ricky.galaxywatchmanagerfree.feature.HeartRateLog
import dev.ricky.galaxywatchmanagerfree.ui.components.HeartRateChart
import dev.ricky.galaxywatchmanagerfree.ui.components.HeartRateWeekBars
import dev.ricky.galaxywatchmanagerfree.ui.theme.WatchFreeTheme
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class HeartRateChartsUiTest {
    @get:Rule val compose = createComposeRule()
    private val app = ApplicationProvider.getApplicationContext<android.content.Context>()
    private val zone: ZoneId = ZoneId.of("UTC")
    private val day = LocalDate.of(2026, 10, 31)

    private fun millisOf(hour: Int): Long =
        LocalDateTime.of(day, java.time.LocalTime.of(hour, 0))
            .atZone(zone)
            .toInstant()
            .toEpochMilli()

    @Test
    fun tappingTheDailyCurveShowsTheNearestReading() {
        compose.setContent {
            WatchFreeTheme(darkTheme = false) {
                Box(Modifier.width(360.dp)) {
                    HeartRateChart(
                        points =
                            listOf(
                                HeartRateLog.Point(millisOf(9), 68),
                                HeartRateLog.Point(millisOf(12), 72),
                                HeartRateLog.Point(millisOf(18), 81),
                            ),
                        day = day,
                        zone = zone,
                    )
                }
            }
        }
        val chart = compose.onNodeWithTag("heart_rate_chart")
        val bounds = chart.fetchSemanticsNode().boundsInRoot
        chart.performTouchInput { click(Offset(bounds.width * 0.5f, bounds.height * 0.5f)) }
        compose.onNodeWithText("72 ${app.getString(R.string.bpm_2)}").assertIsDisplayed()
    }

    @Test
    fun tappingAWeeklyRangeShowsMinimumAverageAndMaximum() {
        val stats = HeartRateLog.Stats(min = 60, avg = 70, max = 80, count = 10)
        compose.setContent {
            WatchFreeTheme(darkTheme = false) {
                Box(Modifier.width(360.dp)) { HeartRateWeekBars(days = List(7) { stats }) }
            }
        }
        val chart = compose.onNodeWithTag("heart_rate_week_bars")
        val bounds = chart.fetchSemanticsNode().boundsInRoot
        chart.performTouchInput { click(Offset(bounds.width * 6.5f / 7f, bounds.height * 0.5f)) }
        compose
            .onNodeWithText(
                app.getString(R.string.heart_week_range_value, 60, 70, 80),
                substring = true,
            )
            .assertIsDisplayed()
    }

    @Test
    fun daylightSavingDayUsesTheClockHoursPrintedOnTheAxis() {
        val dstZone = ZoneId.of("America/New_York")
        val dstDay = LocalDate.of(2026, 11, 1)
        fun point(hour: Int, minute: Int, bpm: Int) =
            HeartRateLog.Point(
                dstDay.atTime(hour, minute).atZone(dstZone).toInstant().toEpochMilli(),
                bpm,
            )
        compose.setContent {
            WatchFreeTheme {
                HeartRateChart(
                    listOf(point(11, 30, 70), point(12, 0, 72), point(12, 30, 74)),
                    dstDay,
                    zone = dstZone,
                )
            }
        }
        compose.onNodeWithTag("heart_rate_chart").performTouchInput {
            click(Offset(width / 2f, height / 2f))
        }
        compose.onNodeWithText("72 ${app.getString(R.string.bpm_2)}").assertIsDisplayed()
    }

    @Test
    fun verticalDragOnTheDailyCurveScrollsThePage() {
        assertVerticalScroll("heart_rate_chart") {
            HeartRateChart(listOf(HeartRateLog.Point(millisOf(12), 72)), day, zone = zone)
        }
    }

    @Test
    fun verticalDragOnWeeklyRangesScrollsThePage() {
        assertVerticalScroll("heart_rate_week_bars") {
            HeartRateWeekBars(List(7) { HeartRateLog.Stats(60, 70, 80, 10) })
        }
    }

    @Test
    fun accessibleActionsSelectReadingsAndStopAtTheBoundary() {
        compose.setContent {
            WatchFreeTheme {
                HeartRateChart(
                    listOf(
                        HeartRateLog.Point(millisOf(9), 68),
                        HeartRateLog.Point(millisOf(12), 72),
                    ),
                    day,
                    zone = zone,
                )
            }
        }
        val chart = compose.onNodeWithTag("heart_rate_chart")
        chart.performClick()
        compose.onNodeWithText("68 ${app.getString(R.string.bpm_2)}").assertIsDisplayed()
        val next =
            chart.fetchSemanticsNode().config[SemanticsActions.CustomActions].single {
                it.label == app.getString(R.string.chart_next_reading)
            }
        compose.runOnIdle { assertTrue(next.action()) }
        chart.assert(
            SemanticsMatcher.expectValue(
                SemanticsProperties.StateDescription,
                app.getString(
                    R.string.chart_selected_reading,
                    "12:00 · 72 ${app.getString(R.string.bpm_2)}",
                    2,
                    2,
                ),
            )
        )
        val boundaryActions = chart.fetchSemanticsNode().config[SemanticsActions.CustomActions]
        assertTrue(boundaryActions.none { it.label == app.getString(R.string.chart_next_reading) })
        compose.runOnIdle {
            assertTrue(
                boundaryActions
                    .single { it.label == app.getString(R.string.chart_clear_selection) }
                    .action()
            )
        }
        chart.assert(
            SemanticsMatcher.expectValue(
                SemanticsProperties.StateDescription,
                app.getString(R.string.chart_no_selection),
            )
        )
    }

    @OptIn(androidx.compose.ui.test.ExperimentalTestApi::class)
    @Test
    fun keyboardCanSelectTheLastReadingThenClearIt() {
        compose.setContent {
            WatchFreeTheme {
                HeartRateChart(
                    listOf(
                        HeartRateLog.Point(millisOf(9), 68),
                        HeartRateLog.Point(millisOf(12), 72),
                    ),
                    day,
                    zone = zone,
                )
            }
        }
        val chart = compose.onNodeWithTag("heart_rate_chart")
        chart.performSemanticsAction(SemanticsActions.RequestFocus)
        chart.performKeyInput { pressKey(Key.MoveEnd) }
        compose.onNodeWithText("72 ${app.getString(R.string.bpm_2)}").assertIsDisplayed()
        chart.performKeyInput { pressKey(Key.DirectionLeft) }
        compose.onNodeWithText("68 ${app.getString(R.string.bpm_2)}").assertIsDisplayed()
        chart.performKeyInput { pressKey(Key.Escape) }
        compose.onNodeWithText("68 ${app.getString(R.string.bpm_2)}").assertDoesNotExist()
    }

    @Test
    fun emptyChartHasNoSelectablePlaceholderReading() {
        compose.setContent { WatchFreeTheme { HeartRateChart(emptyList(), day, zone = zone) } }
        compose
            .onNodeWithTag("heart_rate_chart")
            .assert(
                SemanticsMatcher.expectValue(
                    SemanticsProperties.StateDescription,
                    app.getString(R.string.chart_no_readings),
                ) and SemanticsMatcher.keyNotDefined(SemanticsActions.OnClick)
            )
    }

    @Test
    fun weeklyAccessibilityNavigationSkipsDaysWithoutMeasurements() {
        val first = HeartRateLog.Stats(min = 60, max = 80, avg = 70, count = 10)
        val last = HeartRateLog.Stats(min = 65, max = 85, avg = 75, count = 10)
        compose.setContent {
            WatchFreeTheme { HeartRateWeekBars(listOf(first, null, null, null, null, null, last)) }
        }
        val chart = compose.onNodeWithTag("heart_rate_week_bars")
        chart.performClick()
        compose
            .onNodeWithText(
                app.getString(R.string.heart_week_range_value, 60, 70, 80),
                substring = true,
            )
            .assertIsDisplayed()
        val next =
            chart.fetchSemanticsNode().config[SemanticsActions.CustomActions].single {
                it.label == app.getString(R.string.chart_next_reading)
            }
        compose.runOnIdle { assertTrue(next.action()) }
        compose
            .onNodeWithText(
                app.getString(R.string.heart_week_range_value, 65, 75, 85),
                substring = true,
            )
            .assertIsDisplayed()
    }

    private fun assertVerticalScroll(tag: String, content: @Composable () -> Unit) {
        val scroll = ScrollState(0)
        compose.setContent {
            WatchFreeTheme {
                Column(Modifier.verticalScroll(scroll)) {
                    content()
                    Spacer(Modifier.height(1200.dp))
                }
            }
        }
        compose.onNodeWithTag(tag).performTouchInput {
            swipe(Offset(width / 2f, height * 0.85f), Offset(width / 2f, 0f), durationMillis = 500)
        }
        compose.runOnIdle {
            assertTrue("The chart must allow vertical scrolling", scroll.value > 0)
        }
    }
}
