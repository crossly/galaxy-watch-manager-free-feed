package dev.ricky.galaxywatchmanagerfree

import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.click
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performTouchInput
import androidx.compose.ui.test.swipe
import androidx.compose.ui.unit.dp
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import dev.ricky.galaxywatchmanagerfree.feature.HealthMetric
import dev.ricky.galaxywatchmanagerfree.feature.HealthMetricLog
import dev.ricky.galaxywatchmanagerfree.ui.components.MetricLineChart
import dev.ricky.galaxywatchmanagerfree.ui.theme.HealthOxygen
import dev.ricky.galaxywatchmanagerfree.ui.theme.WatchFreeTheme
import java.time.LocalDate
import java.time.ZoneId
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class MetricChartsUiTest {
    @get:Rule val compose = createComposeRule()
    private val app = ApplicationProvider.getApplicationContext<android.content.Context>()
    private val day = LocalDate.of(2026, 11, 1)
    private val zone = ZoneId.of("America/New_York")
    private val metric = HealthMetric.SPO2

    private fun sample(hour: Int, minute: Int, value: Float) =
        HealthMetricLog.Sample(
            day.atTime(hour, minute).atZone(zone).toInstant().toEpochMilli(),
            value,
        )

    private fun reading(value: Int) = "$value ${app.getString(metric.unitRes)}"

    @Test
    fun tapAndHorizontalDragSelectRealReadingsOnADaylightSavingDate() {
        compose.setContent {
            WatchFreeTheme {
                MetricLineChart(
                    listOf(sample(11, 30, 95f), sample(12, 0, 97f), sample(18, 0, 99f)),
                    metric,
                    HealthOxygen,
                    day = day,
                    zone = zone,
                )
            }
        }
        val chart = compose.onNodeWithTag("metric_chart")
        chart.performTouchInput { click(Offset(width / 2f, height / 2f)) }
        compose.onNodeWithText(reading(97)).assertIsDisplayed()
        chart.performTouchInput {
            swipe(Offset(width * 0.5f, height / 2f), Offset(width * 0.75f, height / 2f), 500)
        }
        compose.onNodeWithText(reading(99)).assertIsDisplayed()
        chart.performTouchInput { click(Offset(width * 0.75f, height / 2f)) }
        compose.onNodeWithText(reading(99)).assertDoesNotExist()
    }

    @Test
    fun changingToAnEmptyDateClearsTheSelectedReading() {
        val selectedDay = mutableStateOf(day)
        compose.setContent {
            WatchFreeTheme {
                MetricLineChart(
                    listOf(sample(12, 0, 97f)),
                    metric,
                    HealthOxygen,
                    day = selectedDay.value,
                    zone = zone,
                )
            }
        }
        compose.onNodeWithTag("metric_chart").performTouchInput {
            click(Offset(width / 2f, height / 2f))
        }
        compose.onNodeWithText(reading(97)).assertIsDisplayed()
        compose.runOnIdle { selectedDay.value = day.plusDays(1) }
        compose.onNodeWithText(reading(97)).assertDoesNotExist()
    }

    @Test
    fun verticalDragScrollsThePageWithoutSelectingAReading() {
        val scroll = ScrollState(0)
        compose.setContent {
            WatchFreeTheme {
                Column(Modifier.verticalScroll(scroll)) {
                    MetricLineChart(
                        listOf(sample(12, 0, 97f)),
                        metric,
                        HealthOxygen,
                        day = day,
                        zone = zone,
                    )
                    Spacer(Modifier.height(1200.dp))
                }
            }
        }
        compose.onNodeWithTag("metric_chart").performTouchInput {
            swipe(Offset(width / 2f, height * 0.85f), Offset(width / 2f, 0f), 500)
        }
        compose.runOnIdle { assertTrue(scroll.value > 0) }
        compose.onNodeWithText(reading(97)).assertDoesNotExist()
    }
}
