package dev.ricky.galaxywatchmanagerfree

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Text
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import dev.ricky.galaxywatchmanagerfree.feature.HealthSyncCoordinator
import dev.ricky.galaxywatchmanagerfree.feature.WatchState
import dev.ricky.galaxywatchmanagerfree.ui.RefreshAction
import dev.ricky.galaxywatchmanagerfree.ui.WatchPage
import dev.ricky.galaxywatchmanagerfree.ui.WatchPageState
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.flow.MutableStateFlow
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test

class WatchPageRecompositionTest {
    @get:Rule val compose = createComposeRule()

    @Test
    fun healthPageIgnoresOverviewAndSettingsUpdates() {
        val source =
            MutableStateFlow(WatchState(sessionReady = true, todaySteps = 10, batteryLevel = 50))
        val compositions = AtomicInteger()
        compose.setContent {
            WatchPageState(source, WatchPage.HEALTH) { state ->
                SideEffect { compositions.incrementAndGet() }
                Text("steps=${state.todaySteps}")
            }
        }
        compose.waitForIdle()
        val baseline = compositions.get()

        compose.runOnIdle {
            source.value =
                source.value.copy(
                    batteryLevel = 40,
                    deviceName = "Other watch",
                    brightness = 10,
                    settingItems = emptyMap(),
                )
        }
        compose.waitForIdle()
        assertEquals(baseline, compositions.get())
        compose.onNodeWithText("steps=10").assertExists()

        compose.runOnIdle { source.value = source.value.copy(todaySteps = 11) }
        compose.waitForIdle()
        assertTrue(compositions.get() > baseline)
        compose.onNodeWithText("steps=11").assertExists()
    }

    @Test
    fun switchingSourceShowsNewSnapshotAndIgnoresOldSource() {
        val first = MutableStateFlow(WatchState(sessionReady = true, todaySteps = 11))
        val second = MutableStateFlow(WatchState(sessionReady = true, todaySteps = 22))
        var current by mutableStateOf<MutableStateFlow<WatchState>>(first)
        compose.setContent {
            WatchPageState(current, WatchPage.HEALTH) { state -> Text("steps=${state.todaySteps}") }
        }
        compose.onNodeWithText("steps=11").assertExists()

        compose.runOnIdle { current = second }
        compose.waitForIdle()
        compose.onNodeWithText("steps=22").assertExists()

        compose.runOnIdle { first.value = WatchState(sessionReady = true, todaySteps = 99) }
        compose.waitForIdle()
        compose.onNodeWithText("steps=22").assertExists()
    }

    @Test
    fun refreshActionOnlyRecomposesForRefreshDerivedValues() {
        val source = MutableStateFlow(WatchState(sessionReady = true))
        val compositions = AtomicInteger()
        compose.setContent {
            RefreshAction(source) { refresh ->
                SideEffect { compositions.incrementAndGet() }
                Text(
                    when {
                        refresh.refreshInProgress -> "busy"
                        refresh.canRefresh -> "ready"
                        else -> "blocked"
                    }
                )
            }
        }
        compose.waitForIdle()
        compose.onNodeWithText("ready").assertExists()
        val baseline = compositions.get()

        compose.runOnIdle { source.value = source.value.copy(batteryLevel = 1, todaySteps = 2) }
        compose.waitForIdle()
        assertEquals(baseline, compositions.get())
        compose.onNodeWithText("ready").assertExists()

        compose.runOnIdle {
            source.value =
                source.value.copy(healthSyncStatus = HealthSyncCoordinator.Status.SYNCING)
        }
        compose.waitForIdle()
        assertTrue(compositions.get() > baseline)
        compose.onNodeWithText("busy").assertExists()
    }

    @Test
    fun settingsPageFollowsDeviceIdentityAndActiveFaceButNotHealthReadings() {
        val source =
            MutableStateFlow(
                WatchState(
                    sessionReady = true,
                    deviceName = "Galaxy Watch7 (ABCD)",
                    modelName = "Galaxy Watch7",
                    activeWatchfacePkg = "com.example.face",
                    todaySteps = 10,
                )
            )
        val compositions = AtomicInteger()
        compose.setContent {
            WatchPageState(source, WatchPage.SETTINGS) { state ->
                SideEffect { compositions.incrementAndGet() }
                Text(
                    "name=${state.displayName} model=${state.modelName} face=${state.activeWatchfacePkg}"
                )
            }
        }
        compose.waitForIdle()
        compose
            .onNodeWithText("name=Galaxy Watch7 model=Galaxy Watch7 face=com.example.face")
            .assertExists()
        val baseline = compositions.get()

        compose.runOnIdle { source.value = source.value.copy(watchAlias = "My Watch") }
        compose.waitForIdle()
        assertTrue(compositions.get() > baseline)
        compose
            .onNodeWithText("name=My Watch model=Galaxy Watch7 face=com.example.face")
            .assertExists()
        val afterName = compositions.get()

        compose.runOnIdle {
            source.value =
                source.value.copy(modelName = "Galaxy Watch Ultra", modelNumber = "SM-L705")
        }
        compose.waitForIdle()
        assertTrue(compositions.get() > afterName)
        compose
            .onNodeWithText("name=My Watch model=Galaxy Watch Ultra face=com.example.face")
            .assertExists()
        val afterModel = compositions.get()

        compose.runOnIdle {
            source.value =
                source.value.copy(
                    activeWatchfacePkg = "com.example.other",
                    activeWatchfacePreviewPath = "/watchfaces/other.png",
                )
        }
        compose.waitForIdle()
        assertTrue(compositions.get() > afterModel)
        compose
            .onNodeWithText("name=My Watch model=Galaxy Watch Ultra face=com.example.other")
            .assertExists()
        val afterFace = compositions.get()

        compose.runOnIdle {
            source.value =
                source.value.copy(
                    todaySteps = 99,
                    healthSyncStatus = HealthSyncCoordinator.Status.SYNCING,
                )
        }
        compose.waitForIdle()
        assertEquals(afterFace, compositions.get())
        compose
            .onNodeWithText("name=My Watch model=Galaxy Watch Ultra face=com.example.other")
            .assertExists()
    }

    @Test
    fun eachPageCollectorOnlyRecomposesForItsOwnDomain() {
        val source =
            MutableStateFlow(
                WatchState(
                    sessionReady = true,
                    todaySteps = 10,
                    batteryLevel = 50,
                    brightness = 20,
                    activeWatchfacePkg = "com.example.face",
                    watchfaceOrderType = "alphabetic",
                )
            )
        val dashboardCompositions = AtomicInteger()
        val settingsCompositions = AtomicInteger()
        val watchFaceCompositions = AtomicInteger()
        compose.setContent {
            Column {
                WatchPageState(source, WatchPage.DASHBOARD) { state ->
                    SideEffect { dashboardCompositions.incrementAndGet() }
                    Text("battery=${state.batteryLevel}")
                }
                WatchPageState(source, WatchPage.SETTINGS) { state ->
                    SideEffect { settingsCompositions.incrementAndGet() }
                    Text("brightness=${state.brightness}")
                }
                WatchPageState(source, WatchPage.WATCH_FACE) { state ->
                    SideEffect { watchFaceCompositions.incrementAndGet() }
                    Text("order=${state.watchfaceOrderType}")
                }
            }
        }
        compose.waitForIdle()
        val dashboardBaseline = dashboardCompositions.get()
        val settingsBaseline = settingsCompositions.get()
        val watchFaceBaseline = watchFaceCompositions.get()

        compose.runOnIdle {
            source.value =
                source.value.copy(
                    todaySteps = 11,
                    healthSyncStatus = HealthSyncCoordinator.Status.SYNCING,
                    lastHealthSyncTime = 1_000,
                )
        }
        compose.waitForIdle()
        assertEquals(dashboardBaseline, dashboardCompositions.get())
        assertEquals(settingsBaseline, settingsCompositions.get())
        assertEquals(watchFaceBaseline, watchFaceCompositions.get())

        compose.runOnIdle { source.value = source.value.copy(batteryLevel = 40) }
        compose.waitForIdle()
        assertTrue(dashboardCompositions.get() > dashboardBaseline)
        assertEquals(settingsBaseline, settingsCompositions.get())
        assertEquals(watchFaceBaseline, watchFaceCompositions.get())
        val dashboardAfterBattery = dashboardCompositions.get()

        compose.runOnIdle { source.value = source.value.copy(brightness = 10) }
        compose.waitForIdle()
        assertEquals(dashboardAfterBattery, dashboardCompositions.get())
        assertTrue(settingsCompositions.get() > settingsBaseline)
        assertEquals(watchFaceBaseline, watchFaceCompositions.get())
        val settingsAfterBrightness = settingsCompositions.get()

        compose.runOnIdle { source.value = source.value.copy(watchfaceOrderType = "recent") }
        compose.waitForIdle()
        assertEquals(dashboardAfterBattery, dashboardCompositions.get())
        assertEquals(settingsAfterBrightness, settingsCompositions.get())
        assertTrue(watchFaceCompositions.get() > watchFaceBaseline)
    }
}
