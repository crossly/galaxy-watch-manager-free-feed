package dev.ricky.galaxywatchmanagerfree

import android.content.Context
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.text.TextLayoutResult
import androidx.core.graphics.ColorUtils
import androidx.test.core.app.ApplicationProvider
import dev.ricky.galaxywatchmanagerfree.core.WatchController
import dev.ricky.galaxywatchmanagerfree.ui.screens.HealthExportSettings
import dev.ricky.galaxywatchmanagerfree.ui.theme.*
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test

class ExportAppearanceTest {
    @get:Rule val compose = createComposeRule()

    @Test
    fun exportParagraphsUseGlobalTextRolesAndContrastInBothThemes() {
        var dark by mutableStateOf(false)
        var primary = Color.Unspecified
        var secondary = Color.Unspecified
        var card = Color.Unspecified
        val context = ApplicationProvider.getApplicationContext<Context>()
        compose.setContent {
            WatchFreeTheme(darkTheme = dark) {
                primary = TextPrimary
                secondary = TextSecondary
                card = CardSurface
                HealthExportSettings(WatchController.repository)
            }
        }
        for (isDark in listOf(false, true)) {
            compose.runOnIdle { dark = isDark }
            compose.waitForIdle()
            for ((resource, expected) in
                listOf(
                    R.string.export_health_description to primary,
                    R.string.export_health_scope to secondary,
                )) {
                val layouts = mutableListOf<TextLayoutResult>()
                compose
                    .onNodeWithText(context.getString(resource))
                    .performScrollTo()
                    .performSemanticsAction(SemanticsActions.GetTextLayoutResult) { it(layouts) }
                val actual = layouts.single().layoutInput.style.color
                assertEquals("Text role for $resource (dark=$isDark)", expected, actual)
                assertTrue(
                    "Readable paragraph contrast",
                    ColorUtils.calculateContrast(actual.toArgb(), card.toArgb()) >= 4.5,
                )
            }
        }
    }
}
