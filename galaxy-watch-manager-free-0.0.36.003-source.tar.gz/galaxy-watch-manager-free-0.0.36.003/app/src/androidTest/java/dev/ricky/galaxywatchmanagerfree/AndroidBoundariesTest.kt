package dev.ricky.galaxywatchmanagerfree

import android.content.Context
import android.content.ContextWrapper
import android.content.SharedPreferences
import androidx.core.content.FileProvider
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import dev.ricky.galaxywatchmanagerfree.core.AndroidApkReader
import dev.ricky.galaxywatchmanagerfree.feature.DevicePreferences
import java.io.File
import java.util.UUID
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class AndroidBoundariesTest {
    private val app: Context
        get() = ApplicationProvider.getApplicationContext()

    @Test
    fun legacyCachesMigrateOnlyToTheirOriginalDeviceAndRemainRecoverable() {
        val prefix = "test_${UUID.randomUUID()}_"
        val created = mutableSetOf<String>()
        val context =
            object : ContextWrapper(app) {
                override fun getSharedPreferences(name: String, mode: Int): SharedPreferences {
                    val scopedName = prefix + name
                    created += scopedName
                    return super.getSharedPreferences(scopedName, mode)
                }
            }
        val original = "02:11:22:33:44:55"
        val other = "02:11:22:33:44:66"
        try {
            context
                .getSharedPreferences("watchfree_health", Context.MODE_PRIVATE)
                .edit()
                .putInt("steps", 1234)
                .putBoolean("steps_coverage_complete", true)
                .commit()
            DevicePreferences.rememberLegacyOwner(context, original)
            val migrated = DevicePreferences.open(context, "watchfree_health", original)
            assertEquals(1234, migrated.getInt("steps", -1))
            DevicePreferences.rememberLegacyOwner(context, other)
            val fresh = DevicePreferences.open(context, "watchfree_health", other)
            assertFalse(fresh.contains("steps_coverage_complete"))
            assertFalse(fresh.contains("steps"))
            assertEquals(
                1234,
                context
                    .getSharedPreferences("watchfree_health", Context.MODE_PRIVATE)
                    .getInt("steps", -1),
            )
            migrated.edit().putInt("steps", 2000).commit()
            assertEquals(
                2000,
                DevicePreferences.open(context, "watchfree_health", original).getInt("steps", -1),
            )
            // A new installation with no saved peer must never adopt the legacy identity later.
            val migration =
                context.getSharedPreferences("watchfree_device_migration", Context.MODE_PRIVATE)
            migration.edit().clear().commit()
            DevicePreferences.rememberLegacyOwner(context, null)
            DevicePreferences.rememberLegacyOwner(context, other)
            assertNull(DevicePreferences.legacyOwner(context))
        } finally {
            created.forEach { app.deleteSharedPreferences(it) }
        }
    }

    @Test
    fun archiveReaderReturnsTheActualInstalledPackageAndSigner() {
        val installed = AndroidApkReader.read(app)
        val archive = AndroidApkReader.read(app, app.applicationInfo.sourceDir)
        assertEquals(app.packageName, archive.packageName)
        assertEquals(installed, archive)
        assertTrue(archive.signers.isNotEmpty())
        assertThrows(dev.ricky.galaxywatchmanagerfree.core.UserFacingException::class.java) {
            AndroidApkReader.read(app, "/missing-update.apk")
        }
    }

    @Test
    fun fileProviderSharesOnlyTheUpdateCache() {
        val apk =
            File(app.cacheDir, "updates/boundary-test.apk").apply {
                parentFile!!.mkdirs()
                writeText("test")
            }
        val other = File(app.cacheDir, "outside-update-test.apk").apply { writeText("test") }
        try {
            val uri = FileProvider.getUriForFile(app, app.packageName + ".fileprovider", apk)
            assertEquals("content", uri.scheme)
            assertEquals(app.packageName + ".fileprovider", uri.authority)
            assertEquals(
                "test",
                app.contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() },
            )
            assertThrows(IllegalArgumentException::class.java) {
                FileProvider.getUriForFile(app, app.packageName + ".fileprovider", other)
            }
        } finally {
            apk.delete()
            other.delete()
        }
    }
}
