package dev.ricky.galaxywatchmanagerfree

import android.content.Context
import android.content.res.Configuration
import android.os.LocaleList
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.assertIsEnabled
import androidx.compose.ui.test.assertIsNotEnabled
import androidx.compose.ui.test.assertIsOn
import androidx.compose.ui.test.click
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.hasText
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performSemanticsAction
import androidx.compose.ui.test.performTouchInput
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.test.core.app.ApplicationProvider
import dev.ricky.galaxywatchmanagerfree.core.WatchController
import dev.ricky.galaxywatchmanagerfree.feature.HealthMeasurements
import dev.ricky.galaxywatchmanagerfree.feature.LayoutPage
import dev.ricky.galaxywatchmanagerfree.feature.PageBlock
import dev.ricky.galaxywatchmanagerfree.feature.VascularLoadLog
import dev.ricky.galaxywatchmanagerfree.feature.WatchState
import dev.ricky.galaxywatchmanagerfree.feature.monitor.BpRecord
import dev.ricky.galaxywatchmanagerfree.feature.monitor.EcgRecord
import dev.ricky.galaxywatchmanagerfree.ui.PageLayoutController
import dev.ricky.galaxywatchmanagerfree.ui.components.formatMonitorRecordTime
import dev.ricky.galaxywatchmanagerfree.ui.screens.BpDetailSheet
import dev.ricky.galaxywatchmanagerfree.ui.screens.EcgDetailSheet
import dev.ricky.galaxywatchmanagerfree.ui.screens.HealthTab
import dev.ricky.galaxywatchmanagerfree.ui.theme.WatchFreeTheme
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Rule
import org.junit.Test

/** Synthetic fixtures render only inside this test; no readings are saved or sent. */
class HealthLayoutTest {
    @get:Rule val compose = createComposeRule()
    private val oldTime = 1_790_000_000_000L
    private val newTime = oldTime + 60_000

    @Before
    fun resetLayouts() {
        LayoutPage.entries.forEach(PageLayoutController::reset)
    }

    @After
    fun restoreLayouts() {
        LayoutPage.entries.forEach(PageLayoutController::reset)
    }

    private fun assertTextFits(text: String) {
        val node = compose.onNodeWithText(text, useUnmergedTree = true)
        val results = mutableListOf<TextLayoutResult>()
        node.performSemanticsAction(SemanticsActions.GetTextLayoutResult) { it(results) }
        val result = results.single()
        val info = "text=$text size=${result.size} lines=${result.lineCount}"
        assertFalse("$info overflows width", result.didOverflowWidth)
        assertFalse("$info overflows height", result.didOverflowHeight)
        for (line in 0 until result.lineCount) {
            assertFalse("$info line $line is ellipsized", result.isLineEllipsized(line))
        }
    }

    @Composable
    private fun TestLayout(
        tag: String,
        fontScale: Float = 1f,
        darkTheme: Boolean = false,
        width: androidx.compose.ui.unit.Dp = 360.dp,
        content: @Composable () -> Unit,
    ) {
        val app = ApplicationProvider.getApplicationContext<Context>()
        val configuration =
            Configuration(app.resources.configuration).apply {
                setLocales(LocaleList.forLanguageTags(tag))
            }
        val localized = app.createConfigurationContext(configuration)
        val density = LocalDensity.current.density
        CompositionLocalProvider(
            LocalContext provides localized,
            LocalConfiguration provides configuration,
            LocalDensity provides Density(density, fontScale),
        ) {
            WatchFreeTheme(darkTheme = darkTheme) { Box(Modifier.width(width)) { content() } }
        }
    }

    @Test
    fun unchangedMetricValueStillShowsTheNewMeasurementTime() {
        val metric = dev.ricky.galaxywatchmanagerfree.feature.HealthMetric.SPO2
        fun state(time: Long) =
            WatchState(
                metricSamples =
                    mapOf(
                        metric to
                            listOf(
                                dev.ricky.galaxywatchmanagerfree.feature.HealthMetricLog.Sample(
                                    time,
                                    96f,
                                )
                            )
                    )
            )
        val current = androidx.compose.runtime.mutableStateOf(state(oldTime))
        compose.setContent {
            TestLayout("en", 1.7f) { HealthTab(current.value, WatchController.repository) }
        }
        val oldLabel =
            "Measured " + dev.ricky.galaxywatchmanagerfree.ui.components.formatRecordTime(oldTime)
        val newLabel =
            "Measured " + dev.ricky.galaxywatchmanagerfree.ui.components.formatRecordTime(newTime)
        compose.onNodeWithTag("block_grid").performScrollToNode(hasText(oldLabel))
        compose.onNodeWithText(oldLabel, useUnmergedTree = true).assertExists()
        compose.runOnIdle { current.value = state(newTime) }
        val label = compose.onNodeWithText(newLabel, useUnmergedTree = true)
        label.assertExists()
        compose.onNodeWithText(oldLabel, useUnmergedTree = true).assertDoesNotExist()
        val layout = mutableListOf<TextLayoutResult>()
        label.performSemanticsAction(SemanticsActions.GetTextLayoutResult) { it(layout) }
        assertFalse(layout.single().didOverflowWidth)
        assertFalse(layout.single().didOverflowHeight)
    }

    @Test
    fun metricDetailShowsTheDateOfAnOlderSample() {
        compose.setContent {
            TestLayout("zh-CN") {
                dev.ricky.galaxywatchmanagerfree.ui.screens.MetricSheet(
                    dev.ricky.galaxywatchmanagerfree.feature.HealthMetric.SPO2,
                    listOf(
                        dev.ricky.galaxywatchmanagerfree.feature.HealthMetricLog.Sample(
                            oldTime,
                            96f,
                        )
                    ),
                    {},
                )
            }
        }
        compose
            .onNodeWithText(
                "测量于 " + dev.ricky.galaxywatchmanagerfree.ui.components.formatRecordTime(oldTime)
            )
            .assertExists()
    }

    @Test
    fun todaysEcgWaveformIsVisibleWithoutOpeningARecord() {
        val time = System.currentTimeMillis()
        compose.setContent {
            TestLayout("en") {
                EcgDetailSheet(
                    WatchState(
                        ecgRecords =
                            listOf(EcgRecord("today", time, 75, 1, waveform = FloatArray(15000)))
                    ),
                    WatchController.repository,
                    {},
                )
            }
        }
        compose
            .onNodeWithContentDescription("ECG waveform, 15000 samples at 500 Hz")
            .performScrollTo()
            .assertExists()
        compose.onNodeWithContentDescription("Save ECG image to Photos").assertExists()
        compose.onNodeWithText("Today's ECG").assertExists()
    }

    @Test
    fun healthHomeKeepsEcgAsSummaryRatherThanExpandedWaveform() {
        compose.setContent {
            TestLayout("en") {
                HealthTab(
                    WatchState(
                        ecgRecords =
                            listOf(
                                EcgRecord(
                                    "today",
                                    System.currentTimeMillis(),
                                    75,
                                    1,
                                    waveform = FloatArray(15000),
                                )
                            )
                    ),
                    WatchController.repository,
                )
            }
        }
        compose.onNodeWithTag("block_grid").performScrollToNode(hasText("ECG"))
        compose.onNodeWithText("ECG").assertExists()
        compose
            .onNodeWithContentDescription("ECG waveform, 15000 samples at 500 Hz")
            .assertDoesNotExist()
        compose.onNodeWithText("Today's ECG").assertDoesNotExist()
    }

    @Test
    fun englishBreathingLabelFitsAtLargeFontScale() {
        compose.setContent {
            TestLayout("en", 1.7f) {
                dev.ricky.galaxywatchmanagerfree.ui.screens.StressDetailSheet(
                    WatchState(lastStressScore = 45),
                    {},
                    {},
                    {},
                )
            }
        }
        compose.onNodeWithTag("stress_detail_list").performScrollToNode(hasText("Deep breathing"))
        val label = compose.onNodeWithText("Deep breathing", useUnmergedTree = true)
        val layout = mutableListOf<TextLayoutResult>()
        label.performSemanticsAction(SemanticsActions.GetTextLayoutResult) { it(layout) }
        val debug =
            layout.single().let { measured ->
                "size=${measured.size} lines=${measured.lineCount} " +
                    (0 until measured.lineCount).joinToString {
                        "${measured.getLineLeft(it)}..${measured.getLineRight(it)}"
                    }
            }
        assertFalse(
            "Breathing label must not clip horizontally: $debug",
            layout.single().didOverflowWidth,
        )
        assertFalse("Breathing label must not clip vertically", layout.single().didOverflowHeight)
        val measured = layout.single()
        for (line in 0 until measured.lineCount) {
            val lineCenter = (measured.getLineLeft(line) + measured.getLineRight(line)) / 2f
            assertEquals(
                "Each wrapped line must be centered",
                measured.size.width / 2f,
                lineCenter,
                1f,
            )
        }
    }

    @Test
    fun longBloodPressureValueRemainsOneLineWithLargeEnglishText() {
        compose.setContent {
            TestLayout("en", 1.5f) {
                HealthTab(
                    WatchState(bpRecords = listOf(BpRecord("bp", newTime, 137, 100, 88))),
                    WatchController.repository,
                )
            }
        }
        compose.onNodeWithTag("block_grid").performScrollToNode(hasText("137/100"))
        val value = compose.onNodeWithText("137/100", useUnmergedTree = true)
        val results = mutableListOf<TextLayoutResult>()
        value.performSemanticsAction(SemanticsActions.GetTextLayoutResult) { it(results) }
        assertEquals(1, results.single().lineCount)
        assertFalse(results.single().didOverflowWidth)
        compose.onNodeWithText("mmHg · Stage 2 high blood pressure").assertExists()
    }

    @Test
    fun selectingAnOldEcgOpensThatRecordsOwnWaveform() {
        val records =
            listOf(
                EcgRecord("new", newTime, 75, 1, waveform = FloatArray(15_000)),
                EcgRecord("old", oldTime, 80, 1, waveform = FloatArray(2_500)),
            )
        compose.setContent {
            TestLayout("en") {
                EcgDetailSheet(WatchState(ecgRecords = records), WatchController.repository, {})
            }
        }
        compose.onNodeWithText(formatMonitorRecordTime(oldTime)).performScrollTo().performClick()
        compose.onNodeWithText("ECG details").assertExists()
        compose.onNodeWithContentDescription("ECG waveform, 2500 samples at 500 Hz").assertExists()
        compose.onNodeWithContentDescription("Back to records").performClick()
        compose.onNodeWithText("History (1)").assertExists()
    }

    @Test
    fun selectingAnOldBpOpensItsOwnValuesAndReturnsToHistory() {
        val records =
            listOf(BpRecord("new", newTime, 137, 100, 88), BpRecord("old", oldTime, 111, 75, 67))
        compose.setContent {
            TestLayout("en") {
                BpDetailSheet(WatchState(bpRecords = records), WatchController.repository, {})
            }
        }
        compose.onNodeWithText(formatMonitorRecordTime(oldTime)).performScrollTo().performClick()
        compose.onNodeWithText("Blood pressure details").assertExists()
        compose.onNodeWithText("111").assertExists()
        compose.onNodeWithText("75").assertExists()
        compose.onNodeWithText("Pulse 67 bpm").assertExists()
        compose.onNodeWithContentDescription("Back to records").performClick()
        compose.onNodeWithText("History (1)").assertExists()
    }

    @Test
    fun heartDetailKeepsOlderLatestSeparateFromEmptyTodayAndOpensHistory() {
        val zone = java.time.ZoneId.systemDefault()
        val yesterday = java.time.LocalDate.now(zone).minusDays(1)
        val latestTime = yesterday.atTime(19, 30, 40).atZone(zone).toInstant().toEpochMilli()
        val earlierTime = yesterday.atTime(18, 0, 0).atZone(zone).toInstant().toEpochMilli()
        val latest =
            dev.ricky.galaxywatchmanagerfree.feature.HeartRateLog.Point(latestTime, 95, 92, 98)
        val reportTime = System.currentTimeMillis()
        compose.setContent {
            TestLayout("en", 2f, darkTheme = true, width = 320.dp) {
                dev.ricky.galaxywatchmanagerfree.ui.screens.HeartRateSheet(
                    WatchState(
                        heartRateHistory =
                            mapOf(
                                yesterday.toString() to
                                    listOf(
                                        dev.ricky.galaxywatchmanagerfree.feature.HeartRateLog.Point(
                                            earlierTime,
                                            84,
                                            80,
                                            88,
                                        ),
                                        latest,
                                    )
                            ),
                        heartRateDays =
                            mapOf(
                                yesterday.toString() to
                                    dev.ricky.galaxywatchmanagerfree.feature.HeartRateLog.Stats(
                                        min = 80,
                                        max = 98,
                                        avg = 89,
                                        count = 2,
                                    )
                            ),
                        latestHeartRate = latest,
                        lastHeartRateReportTime = reportTime,
                        lastHealthSyncTime = reportTime,
                    ),
                    {},
                )
            }
        }
        val measured = "Measured " + formatMonitorRecordTime(latestTime)
        val measurement = compose.onNodeWithText(measured, useUnmergedTree = true)
        measurement.performScrollTo().assertExists()
        val layout = mutableListOf<TextLayoutResult>()
        measurement.performSemanticsAction(SemanticsActions.GetTextLayoutResult) { it(layout) }
        val measuredLayout = layout.single()
        val layoutInfo =
            "size=${measuredLayout.size} lines=${measuredLayout.lineCount} " +
                (0 until measuredLayout.lineCount).joinToString { line ->
                    "${measuredLayout.getLineLeft(line)}..${measuredLayout.getLineRight(line)}"
                }
        for (line in 0 until measuredLayout.lineCount) {
            assertTrue(layoutInfo, measuredLayout.getLineLeft(line) >= -1f)
            assertTrue(
                layoutInfo,
                measuredLayout.getLineRight(line) <= measuredLayout.size.width + 1f,
            )
            assertFalse(layoutInfo, measuredLayout.isLineEllipsized(line))
        }
        assertTrue(
            layoutInfo,
            measuredLayout.multiParagraph.height <= measuredLayout.size.height + 1f,
        )
        compose.onNodeWithText("No heart rate readings today").performScrollTo().assertExists()
        compose
            .onNodeWithText(
                "Heart rate data received: " + formatMonitorRecordTime(reportTime),
                useUnmergedTree = true,
            )
            .performScrollTo()
            .assertExists()
        compose.onNodeWithText(yesterday.toString()).performScrollTo().performClick()
        compose.onNodeWithText("2 readings").assertExists()
        compose
            .onNode(
                androidx.compose.ui.test.SemanticsMatcher.keyIsDefined(
                    androidx.compose.ui.semantics.SemanticsProperties.VerticalScrollAxisRange
                )
            )
            .performScrollToNode(hasText("95 bpm"))
        compose.onNodeWithText("95 bpm").assertExists()
        compose.onNodeWithText(formatMonitorRecordTime(latestTime)).assertExists()
    }

    @Test
    fun healthCardsUseTheFullWidthAt320dpWithLargeFont() {
        compose.setContent {
            TestLayout("en", 2f, width = 320.dp) {
                HealthTab(
                    WatchState(
                        lastHeartRate = 72,
                        lastStressScore = 45,
                        ecgRecords = listOf(EcgRecord("ecg", newTime, 75, 1)),
                        bpRecords = listOf(BpRecord("bp", newTime, 137, 100, 88)),
                    ),
                    WatchController.repository,
                )
            }
        }
        val grid = compose.onNodeWithTag("block_grid")
        listOf(
                "HEART_RATE" to listOf("72", "bpm"),
                "STRESS" to listOf("45", "Score"),
                "ECG" to listOf("75", "bpm · Sinus rhythm"),
                "BP" to listOf("137/100", "mmHg · Stage 2 high blood pressure"),
            )
            .forEach { (block, texts) ->
                grid.performScrollToNode(hasTestTag("block_$block"))
                val bounds = compose.onNodeWithTag("block_$block").fetchSemanticsNode().boundsInRoot
                assertTrue(
                    "$block should use a single column",
                    bounds.width > grid.fetchSemanticsNode().boundsInRoot.width * .8f,
                )
                texts.forEach(::assertTextFits)
            }
    }

    @Test
    fun goalDraftSurvivesWindowChangesAndStateRestorationBeforeSaving() {
        val app = ApplicationProvider.getApplicationContext<Context>()
        val wide = androidx.compose.runtime.mutableStateOf(false)
        val confirmed = mutableListOf<Int>()
        val restoration = androidx.compose.ui.test.junit4.StateRestorationTester(compose)
        restoration.setContent {
            val configuration =
                Configuration(app.resources.configuration).apply {
                    screenWidthDp = if (wide.value) 840 else 360
                    screenHeightDp = 900
                    setLocales(LocaleList.forLanguageTags("en"))
                }
            CompositionLocalProvider(
                LocalContext provides app.createConfigurationContext(configuration),
                LocalConfiguration provides configuration,
            ) {
                WatchFreeTheme {
                    dev.ricky.galaxywatchmanagerfree.ui.screens.StepGoalSheet(
                        current = 10_000,
                        canReset = false,
                        onDismiss = {},
                        onConfirm = { confirmed.add(it) },
                        onReset = {},
                    )
                }
            }
        }
        compose
            .onNode(
                androidx.compose.ui.test.SemanticsMatcher.keyIsDefined(SemanticsActions.SetProgress)
            )
            .performSemanticsAction(SemanticsActions.SetProgress) { assertTrue(it(12_000f)) }
        compose.runOnIdle { wide.value = true }
        compose.onNodeWithText("Save").assertExists()
        compose.runOnIdle { wide.value = false }
        restoration.emulateSavedInstanceStateRestore()
        assertTrue("Window changes must not submit the draft", confirmed.isEmpty())
        compose.onNodeWithText("Save").performScrollTo().performClick()
        assertEquals(listOf(12_000), confirmed)
    }

    @Test
    fun vascularCollectionSwitchRequiresCapabilityAndLabelsTheUnconfirmedDefault() {
        val supported = androidx.compose.runtime.mutableStateOf(true)
        val changes = mutableListOf<Boolean>()
        compose.setContent {
            TestLayout("en") {
                TestMeasurementSettings(
                    HealthMeasurements.Toggle(canWrite = true),
                    supported = supported.value,
                    onChange = { changes.add(it) },
                )
            }
        }
        compose
            .onNodeWithText("Vascular load collection")
            .performScrollTo()
            .assertIsEnabled()
            .assertIsOn()
            .performClick()
        compose
            .onNodeWithText(
                "Watch setting not yet confirmed. Samsung Health defaults to on; you can change it and wait for confirmation."
            )
            .assertExists()
        compose.runOnIdle {
            assertEquals(listOf(false), changes)
            supported.value = false
        }
        compose.onNodeWithText("Vascular load collection").assertDoesNotExist()
    }

    @Test
    fun vascularCollectionSwitchCannotSendWhilePendingOrDisconnected() {
        val toggle =
            androidx.compose.runtime.mutableStateOf(
                HealthMeasurements.Toggle(
                    enabled = false,
                    desired = true,
                    status = HealthMeasurements.ToggleStatus.PENDING,
                    canWrite = true,
                )
            )
        val connected = androidx.compose.runtime.mutableStateOf(true)
        compose.setContent {
            TestLayout("zh-CN") {
                TestMeasurementSettings(toggle.value, connected = connected.value)
            }
        }
        compose.onNodeWithText("血管负荷采集").performScrollTo().assertIsNotEnabled()
        compose.onNodeWithText("正在应用…").assertExists()
        compose.runOnIdle {
            toggle.value =
                toggle.value.copy(
                    desired = null,
                    status = HealthMeasurements.ToggleStatus.CONFIRMED,
                )
            connected.value = false
        }
        compose.onNodeWithText("血管负荷采集").assertIsNotEnabled()
    }

    @Test
    fun vascularCollectionLabelsFitAt320dpWithLargeEnglishTextInBothThemes() {
        val dark = androidx.compose.runtime.mutableStateOf(false)
        compose.setContent {
            TestLayout("en", 2f, darkTheme = dark.value, width = 320.dp) {
                TestMeasurementSettings(
                    HealthMeasurements.Toggle(
                        enabled = true,
                        status = HealthMeasurements.ToggleStatus.CONFIRMED,
                        canWrite = true,
                    )
                )
            }
        }
        for (theme in listOf(false, true)) {
            compose.runOnIdle { dark.value = theme }
            compose.onNodeWithText("Vascular load collection").performScrollTo().assertIsOn()
            assertTextFits("Vascular load collection")
            assertTextFits(
                "Samsung Health Labs: measure vascular load during sleep. Establishing a baseline requires at least 3 nights within 14 days, with at least 4 hours of sleep each night."
            )
        }
    }

    @Composable
    private fun TestMeasurementSettings(
        toggle: HealthMeasurements.Toggle,
        supported: Boolean = true,
        connected: Boolean = true,
        onChange: (Boolean) -> Unit = {},
    ) {
        dev.ricky.galaxywatchmanagerfree.ui.screens.HealthMeasurementSettings(
            state = HealthMeasurements.State(vascularLoad = toggle),
            connected = connected,
            vascularLoadSupported = supported,
            onSleepOxygen = {},
            onStressContinuous = {},
            onVascularLoad = onChange,
            onMeasure = {},
            onOpenWatchSettings = {},
            onRefresh = {},
        )
    }

    @Test
    fun vascularLoadDisappearsWhenDeviceSupportIsUnknownOrFalse() {
        val current =
            androidx.compose.runtime.mutableStateOf(WatchState(vascularLoadSupported = true))
        compose.setContent {
            TestLayout("en") { HealthTab(current.value, WatchController.repository) }
        }
        compose.onNodeWithTag("block_grid").performScrollToNode(hasTestTag("block_VASCULAR_LOAD"))
        compose.onNodeWithTag("block_VASCULAR_LOAD").assertExists()
        compose.runOnIdle { current.value = WatchState() }
        compose.onNodeWithTag("block_VASCULAR_LOAD").assertDoesNotExist()
    }

    @Test
    fun unsupportedVascularLoadCannotBeAddedInLayoutEditor() {
        PageLayoutController.change(LayoutPage.HEALTH, PageBlock.VASCULAR_LOAD, visible = false)
        val current =
            androidx.compose.runtime.mutableStateOf(WatchState(vascularLoadSupported = true))
        compose.setContent {
            TestLayout("en") {
                HealthTab(current.value, WatchController.repository, editing = true)
            }
        }
        compose.onNodeWithTag("block_grid").performScrollToNode(hasText("Vascular load"))
        compose.onNodeWithText("Vascular load").assertExists()
        compose.runOnIdle { current.value = WatchState() }
        compose.onNodeWithText("Vascular load").assertDoesNotExist()
    }

    @Test
    fun vascularLoadBaselineCardWrapsAt320dpWithLargeEnglishText() {
        compose.setContent {
            TestLayout("en", 2f, darkTheme = true, width = 320.dp) {
                HealthTab(WatchState(vascularLoadSupported = true), WatchController.repository)
            }
        }
        compose.onNodeWithTag("block_grid").performScrollToNode(hasText("Establishing baseline"))
        listOf("Vascular load", "Establishing baseline", "Compared with your baseline")
            .forEach(::assertTextFits)
        compose.onNodeWithTag("vascular_load_baseline_progress").assertExists()
        compose.onNodeWithTag("vascular_load_scale").assertDoesNotExist()
    }

    @Test
    fun vascularLoadDetailShowsBaselineProgressWithoutInventingMeasurements() {
        compose.setContent {
            TestLayout("en", 1.7f, width = 320.dp) {
                dev.ricky.galaxywatchmanagerfree.ui.screens.VascularLoadSheet(
                    VascularLoadLog.Snapshot(baselineNights = 2),
                    {},
                )
            }
        }
        compose.onNodeWithText("2 of 3 nights recorded").performScrollTo().assertExists()
        assertTextFits("2 of 3 nights recorded")
        compose
            .onNodeWithTag("vascular_load_detail")
            .performScrollToNode(hasText("No records in the past 7 days"))
        compose.onNodeWithTag("vascular_load_chart").assertDoesNotExist()
    }

    @Test
    fun vascularLoadDetailUsesBandsAndKeepsBaselineSeparateFromReadings() {
        val zone = java.time.ZoneId.systemDefault()
        val now = java.time.LocalDate.now(zone).atTime(8, 0).atZone(zone)
        val offset = now.offset.totalSeconds * 1000L
        val time = now.toInstant().toEpochMilli()
        val baseline =
            VascularLoadLog.Entry(
                "baseline",
                time - 86_400_000L,
                time - 86_400_000L,
                VascularLoadLog.Type.BASELINE,
                93.333336f,
                offset,
            )
        val reading =
            VascularLoadLog.Entry(
                "measurement",
                time,
                time,
                VascularLoadLog.Type.MEASUREMENT,
                -5f,
                offset,
            )
        compose.setContent {
            TestLayout("en", 1.7f, darkTheme = true, width = 320.dp) {
                dev.ricky.galaxywatchmanagerfree.ui.screens.VascularLoadSheet(
                    VascularLoadLog.Snapshot(
                        records = listOf(baseline, reading),
                        baseline = baseline,
                        baselineComplete = true,
                        latest = reading,
                    ),
                    {},
                )
            }
        }
        compose.onNodeWithText("Slightly higher").assertExists()
        assertTextFits("Slightly higher")
        compose
            .onNodeWithTag("vascular_load_detail")
            .performScrollToNode(hasTestTag("vascular_load_chart"))
        compose.onNodeWithTag("vascular_load_chart").assertExists()
        compose
            .onNodeWithTag("vascular_load_detail")
            .performScrollToNode(hasText("Baseline established"))
        compose.onNodeWithText("Baseline established").assertExists()
        compose.onNodeWithText("93.333336").assertDoesNotExist()
    }

    @Test
    fun completedVascularBaselineAppearsBeforeTheFirstMeasurement() {
        val now = java.time.ZonedDateTime.now()
        val time = now.withHour(8).withMinute(0).toInstant().toEpochMilli()
        val baseline =
            VascularLoadLog.Entry(
                "synthetic-baseline",
                time,
                time,
                VascularLoadLog.Type.BASELINE,
                93f,
                now.offset.totalSeconds * 1000L,
            )
        compose.setContent {
            TestLayout("en", 2f, width = 320.dp) {
                dev.ricky.galaxywatchmanagerfree.ui.screens.VascularLoadSheet(
                    VascularLoadLog.Snapshot(
                        records = listOf(baseline),
                        baseline = baseline,
                        baselineComplete = true,
                    ),
                    {},
                )
            }
        }
        compose.onNodeWithText("Not enough data").assertDoesNotExist()
        compose
            .onNodeWithTag("vascular_load_detail")
            .performScrollToNode(hasTestTag("vascular_load_chart"))
        compose.onNodeWithTag("vascular_load_chart").assertExists()
    }

    @Test
    fun vascularLoadScaleLabelsFitInBothThemesAtLargeEnglishFont() {
        val dark = androidx.compose.runtime.mutableStateOf(false)
        val reading =
            VascularLoadLog.Entry(
                "synthetic",
                oldTime,
                oldTime,
                VascularLoadLog.Type.MEASUREMENT,
                -5f,
            )
        compose.setContent {
            TestLayout("en", 2f, darkTheme = dark.value, width = 320.dp) {
                dev.ricky.galaxywatchmanagerfree.ui.screens.VascularLoadSheet(
                    VascularLoadLog.Snapshot(baselineComplete = true, latest = reading),
                    {},
                )
            }
        }
        for (darkTheme in listOf(false, true)) {
            compose.runOnIdle { dark.value = darkTheme }
            compose.onNodeWithTag("vascular_load_scale").performScrollTo().assertExists()
            listOf("Slightly higher", "Lower", "Steady", "Higher").forEach(::assertTextFits)
            compose.onNodeWithTag("vascular_load_baseline_progress").assertDoesNotExist()
        }
    }

    @Test
    fun vascularChartWithAnUnavailableDailyResultDoesNotClaimHistoryIsEmpty() {
        val now = java.time.ZonedDateTime.now().withHour(8).withMinute(0)
        val time = now.toInstant().toEpochMilli()
        val offset = now.offset.totalSeconds * 1000L
        val earlier =
            VascularLoadLog.Entry(
                "earlier",
                time - 3600_000,
                time - 3600_000,
                VascularLoadLog.Type.MEASUREMENT,
                -5f,
                offset,
            )
        val unknown =
            VascularLoadLog.Entry(
                "unknown",
                time,
                time,
                VascularLoadLog.Type.MEASUREMENT,
                13f,
                offset,
            )
        compose.setContent {
            TestLayout("en", width = 320.dp) {
                dev.ricky.galaxywatchmanagerfree.ui.screens.VascularLoadSheet(
                    VascularLoadLog.Snapshot(
                        records = listOf(earlier, unknown),
                        baselineComplete = true,
                        latest = unknown,
                    ),
                    {},
                )
            }
        }
        val empty =
            "The latest daily records have no results to display. See the full history below."
        compose.onNodeWithTag("vascular_load_detail").performScrollToNode(hasText(empty))
        assertTextFits(empty)
        compose.onNodeWithText("No records in the past 7 days").assertDoesNotExist()
        compose.onNodeWithTag("vascular_load_chart").assertDoesNotExist()
        compose
            .onNodeWithTag("vascular_load_detail")
            .performScrollToNode(hasText("Slightly higher"))
        compose.onNodeWithText("Slightly higher").assertExists()
    }

    @Test
    fun vascularChartProbeShowsTheLatestResultOfTheDayAndKeepsEarlierHistory() {
        val now = java.time.ZonedDateTime.now().withHour(8).withMinute(0)
        val time = now.toInstant().toEpochMilli()
        val offset = now.offset.totalSeconds * 1000L
        val earlier =
            VascularLoadLog.Entry(
                "earlier",
                time - 3600_000,
                time - 3600_000,
                VascularLoadLog.Type.MEASUREMENT,
                -5f,
                offset,
            )
        val later =
            VascularLoadLog.Entry("later", time, time, VascularLoadLog.Type.MEASUREMENT, 5f, offset)
        compose.setContent {
            TestLayout("en", 1.7f, darkTheme = true, width = 320.dp) {
                dev.ricky.galaxywatchmanagerfree.ui.screens.VascularLoadSheet(
                    VascularLoadLog.Snapshot(
                        records = listOf(later, earlier),
                        baselineComplete = true,
                        latest = later,
                    ),
                    {},
                )
            }
        }
        val chart = compose.onNodeWithTag("vascular_load_chart")
        compose
            .onNodeWithTag("vascular_load_detail")
            .performScrollToNode(hasTestTag("vascular_load_chart_reading"))
        chart.performTouchInput {
            click(androidx.compose.ui.geometry.Offset(width * 6.5f / 7f, height / 2f))
        }
        val reading = compose.onNodeWithTag("vascular_load_chart_reading")
        val labels = mutableListOf<TextLayoutResult>()
        reading.performSemanticsAction(SemanticsActions.GetTextLayoutResult) { it(labels) }
        assertTrue(labels.single().layoutInput.text.text.endsWith("Slightly lower"))
        assertFalse(labels.single().didOverflowWidth)
        assertFalse(labels.single().didOverflowHeight)
        compose
            .onNodeWithTag("vascular_load_detail")
            .performScrollToNode(hasText("Slightly higher"))
        compose.onNodeWithText("Slightly higher").assertExists()
    }

    @Test
    fun historicalSleepSessionRemainsVisibleOnHomeCardAndDetailSheet() {
        val threeDaysAgo = System.currentTimeMillis() - 72 * 3600_000L
        val oldSession =
            dev.ricky.galaxywatchmanagerfree.feature.SleepParser.Session(
                startMillis = threeDaysAgo,
                endMillis = threeDaysAgo + 360 * 60_000L,
                segments = emptyList(),
                efficiency = 95,
                score = 80,
                reportedSleepMinutes = 360,
                id = "historical-sleep",
            )
        val dayKey = dev.ricky.galaxywatchmanagerfree.feature.SleepParser.nightKey(oldSession)
        compose.setContent {
            TestLayout("en") {
                HealthTab(
                    WatchState(
                        sleep = oldSession,
                        sleepSessions = listOf(oldSession),
                        sleepDays = mapOf(dayKey to listOf(oldSession)),
                        allSleepSessions = listOf(oldSession),
                    ),
                    dev.ricky.galaxywatchmanagerfree.core.WatchController.repository,
                )
            }
        }
        compose.onNodeWithTag("block_grid").performScrollToNode(hasText("6 h"))
        compose.onNodeWithText("6 h").assertExists()
        compose.onNodeWithText("Latest measurement").assertExists()
    }
}
