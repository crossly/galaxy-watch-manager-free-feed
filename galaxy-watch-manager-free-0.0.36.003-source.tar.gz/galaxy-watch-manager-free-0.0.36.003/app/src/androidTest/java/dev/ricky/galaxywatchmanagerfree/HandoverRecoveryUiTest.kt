package dev.ricky.galaxywatchmanagerfree

import android.content.Context
import android.content.ContextWrapper
import android.content.SharedPreferences
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.test.assertIsEnabled
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.unit.dp
import androidx.test.core.app.ApplicationProvider
import dev.ricky.galaxywatchmanagerfree.feature.DeviceIdentityStore
import dev.ricky.galaxywatchmanagerfree.feature.IdentityEvent
import dev.ricky.galaxywatchmanagerfree.feature.handover.HandoverJournal
import dev.ricky.galaxywatchmanagerfree.feature.handover.HandoverSnapshotStore
import dev.ricky.galaxywatchmanagerfree.ui.components.CompanionHandoverCard
import dev.ricky.galaxywatchmanagerfree.ui.theme.WatchFreeTheme
import java.util.UUID
import org.junit.After
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test

class HandoverRecoveryUiTest {
    @get:Rule val compose = createComposeRule()
    private val app = ApplicationProvider.getApplicationContext<Context>()
    private val prefix = "handover_recovery_test_${UUID.randomUUID()}_"
    private val created = mutableSetOf<String>()
    private val context =
        object : ContextWrapper(app) {
            override fun getApplicationContext(): Context = this

            override fun getSharedPreferences(name: String, mode: Int): SharedPreferences {
                val scoped = prefix + name
                created += scoped
                return super.getSharedPreferences(scoped, mode)
            }
        }

    @After
    fun cleanup() {
        created.forEach { app.deleteSharedPreferences(it) }
    }

    @Test
    fun incompleteRestoreRemainsRetryableAfterConnectionWasReleased() {
        val mac = "02:11:22:33:44:88"
        val identity = DeviceIdentityStore(context, mac)
        assertTrue(identity.transition(IdentityEvent.ReleaseToOfficialApps))
        val snapshots = HandoverSnapshotStore(context)
        assertTrue(
            snapshots.save(
                HandoverJournal().snapshot(mapOf("com.samsung.android.app.watchmanager" to 0))
            )
        )
        compose.setContent {
            CompositionLocalProvider(LocalContext provides context) {
                WatchFreeTheme {
                    Box(Modifier.width(320.dp).verticalScroll(rememberScrollState())) {
                        CompanionHandoverCard(mac, "Galaxy Watch")
                    }
                }
            }
        }
        compose.waitUntil(timeoutMillis = 10_000) {
            compose
                .onAllNodes(androidx.compose.ui.test.hasTestTag("tag_handover_restore"))
                .fetchSemanticsNodes()
                .isNotEmpty()
        }
        compose
            .onNodeWithTag("tag_handover_restore")
            .performScrollTo()
            .assertIsEnabled()
            .performClick()
        compose.onNodeWithTag("tag_handover_restore_confirm").assertIsEnabled()
        assertTrue(identity.releasedToOfficialApps)
        assertFalse(snapshots.load().isEmpty)
    }
}
