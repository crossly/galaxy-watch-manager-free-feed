package dev.ricky.galaxywatchmanagerfree

import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.assertCountEquals
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.click
import androidx.compose.ui.test.hasText
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performSemanticsAction
import androidx.compose.ui.test.performTouchInput
import androidx.compose.ui.test.swipe
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import dev.ricky.galaxywatchmanagerfree.feature.StressLog
import dev.ricky.galaxywatchmanagerfree.feature.WatchState
import dev.ricky.galaxywatchmanagerfree.ui.components.StressChart
import dev.ricky.galaxywatchmanagerfree.ui.screens.StressDetailSheet
import dev.ricky.galaxywatchmanagerfree.ui.theme.WatchFreeTheme
import java.time.LocalDate
import java.time.ZoneId
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class StressChartsUiTest {
    @get:Rule val compose = createComposeRule()
    private val app = ApplicationProvider.getApplicationContext<android.content.Context>()
    private val zone = ZoneId.systemDefault()
    private val day = LocalDate.of(2026, 10, 31)

    private fun millisOf(hour: Int, date: LocalDate = day): Long =
        date.atTime(hour, 0).atZone(zone).toInstant().toEpochMilli()

    private fun label(value: String, level: Int): String =
        app.getString(R.string.stress_chart_reading, value, app.getString(level))

    private fun showChart(points: List<StressLog.Point>) {
        compose.setContent {
            WatchFreeTheme(darkTheme = false) {
                Box(Modifier.width(360.dp)) { StressChart(points, day) }
            }
        }
    }

    private fun tapAt(fraction: Float) {
        val chart = compose.onNodeWithTag("stress_chart")
        chart.performTouchInput { click(Offset(width * fraction, height / 2f)) }
    }

    @Test
    fun tapShowsTheFractionalReadingAndRawClassificationAndCanDismissIt() {
        showChart(listOf(StressLog.Point(millisOf(12), 10.4f)))
        tapAt(0.5f)
        compose.onNodeWithText(label("10.4", R.string.low)).assertIsDisplayed()
        compose.onAllNodesWithText("12:00").assertCountEquals(2)
        tapAt(0.5f)
        compose.onNodeWithText(label("10.4", R.string.low)).assertDoesNotExist()
    }

    @Test
    fun horizontalDragMovesTheProbeToAnotherRealReading() {
        showChart(
            listOf(
                StressLog.Point(millisOf(9), 0f),
                StressLog.Point(millisOf(12), 10.4f),
                StressLog.Point(millisOf(18), 80.4f),
            )
        )
        compose.onNodeWithTag("stress_chart").performTouchInput {
            swipe(
                start = Offset(width * 0.375f, height / 2f),
                end = Offset(width * 0.75f, height / 2f),
                durationMillis = 500,
            )
        }
        compose.onNodeWithText(label("80.4", R.string.high)).assertIsDisplayed()
        compose.onAllNodesWithText("18:00").assertCountEquals(2)
    }

    @Test
    fun otherDaysAndInvalidScoresAreExcludedButZeroRemainsSelectable() {
        showChart(
            listOf(
                StressLog.Point(millisOf(12, day.minusDays(1)), 99f),
                StressLog.Point(millisOf(0), 0f),
                StressLog.Point(millisOf(12), Float.NaN),
                StressLog.Point(millisOf(13), 101f),
                StressLog.Point(millisOf(0, day.plusDays(1)), 88f),
            )
        )
        compose
            .onNodeWithContentDescription(app.getString(R.string.stress_chart_description, 1))
            .assertIsDisplayed()
        tapAt(0.5f)
        compose.onNodeWithText(label("0", R.string.relaxed)).assertIsDisplayed()
    }

    @Test
    fun changingToAnEmptyDayClearsTheProbe() {
        val selectedDay = mutableStateOf(day)
        compose.setContent {
            WatchFreeTheme(darkTheme = true) {
                Box(Modifier.width(320.dp)) {
                    StressChart(
                        points = listOf(StressLog.Point(millisOf(12), 10.4f)),
                        day = selectedDay.value,
                    )
                }
            }
        }
        tapAt(0.5f)
        compose.onNodeWithText(label("10.4", R.string.low)).assertIsDisplayed()
        compose.runOnIdle { selectedDay.value = day.plusDays(1) }
        tapAt(0.5f)
        compose.onNodeWithText(label("10.4", R.string.low)).assertDoesNotExist()
        compose
            .onNodeWithContentDescription(app.getString(R.string.stress_chart_description, 0))
            .assertIsDisplayed()
    }

    @Test
    fun daylightSavingDayUsesWallClockHoursForBothSelectionAndTooltip() {
        val newYork = ZoneId.of("America/New_York")
        val date = LocalDate.of(2026, 11, 1)
        fun millis(hour: Int, minute: Int) =
            date.atTime(hour, minute).atZone(newYork).toInstant().toEpochMilli()
        compose.setContent {
            WatchFreeTheme(darkTheme = false) {
                Box(Modifier.width(360.dp)) {
                    StressChart(
                        points =
                            listOf(
                                StressLog.Point(millis(11, 45), 19f),
                                StressLog.Point(millis(12, 10), 21f),
                            ),
                        day = date,
                        zone = newYork,
                    )
                }
            }
        }
        tapAt(0.5f)
        compose.onNodeWithText(label("21", R.string.stress_level_moderate)).assertIsDisplayed()
        compose.onNodeWithText("12:10").assertIsDisplayed()
    }

    @Test
    fun selectedReadingFitsAt320dpAndDoubleFontScale() {
        compose.setContent {
            val density = LocalDensity.current.density
            CompositionLocalProvider(LocalDensity provides Density(density, 2f)) {
                WatchFreeTheme(darkTheme = true) {
                    Box(Modifier.width(320.dp)) {
                        StressChart(listOf(StressLog.Point(millisOf(12), 45.6f)), day)
                    }
                }
            }
        }
        tapAt(0.5f)
        val reading = compose.onNodeWithText(label("45.6", R.string.stress_level_moderate))
        reading.assertIsDisplayed()
        val layouts = mutableListOf<TextLayoutResult>()
        reading.performSemanticsAction(SemanticsActions.GetTextLayoutResult) { it(layouts) }
        assertFalse(
            "The selected reading must not clip horizontally",
            layouts.single().didOverflowWidth,
        )
        assertFalse(
            "The selected reading must not clip vertically",
            layouts.single().didOverflowHeight,
        )
        for (time in listOf("00:00", "24:00")) {
            val labels = mutableListOf<TextLayoutResult>()
            compose.onNodeWithText(time).performSemanticsAction(
                SemanticsActions.GetTextLayoutResult
            ) {
                it(labels)
            }
            assertEquals("Time labels must remain on one line", 1, labels.single().lineCount)
            val layout = labels.single()
            assertTrue(
                "Time label $time must fit: size=${layout.size}, right=${layout.getLineRight(0)}",
                layout.getLineLeft(0) >= -1f && layout.getLineRight(0) <= layout.size.width + 1f,
            )
            assertFalse("Time labels must not be truncated", layout.isLineEllipsized(0))
            assertFalse("Time labels must fit vertically", layout.didOverflowHeight)
        }
        compose.onNodeWithText("06:00").assertDoesNotExist()
    }

    @Test
    fun verticalDragOnTheChartStillScrollsThePage() {
        val scroll = ScrollState(0)
        compose.setContent {
            WatchFreeTheme(darkTheme = false) {
                Column(Modifier.verticalScroll(scroll)) {
                    StressChart(listOf(StressLog.Point(millisOf(12), 10.4f)), day)
                    Spacer(Modifier.height(1200.dp))
                }
            }
        }
        compose.onNodeWithTag("stress_chart").performTouchInput {
            swipe(
                start = Offset(width / 2f, height * 0.85f),
                end = Offset(width / 2f, 0f),
                durationMillis = 500,
            )
        }
        compose.runOnIdle {
            assertTrue("Vertical scrolling must remain available", scroll.value > 0)
        }
        compose.onNodeWithText(label("10.4", R.string.low)).assertDoesNotExist()
    }

    @Test
    fun breathingPrecedesTheReadingList() {
        val today = LocalDate.now(zone)
        val point = StressLog.Point(millisOf(12, today), 10.4f)
        compose.setContent {
            WatchFreeTheme(darkTheme = true) {
                StressDetailSheet(
                    state =
                        WatchState(
                            latestStress = point,
                            stressHistory = mapOf(today.toString() to listOf(point)),
                        ),
                    onDismiss = {},
                    onMeasure = {},
                    onOpenMeasurementSettings = {},
                )
            }
        }
        compose.onNodeWithTag("stress_detail_list").performScrollToNode(hasText("10.4 / 100"))
        val breathing =
            compose
                .onNodeWithText(app.getString(R.string.guided_breathing))
                .fetchSemanticsNode()
                .boundsInRoot
                .top
        val readings =
            compose.onNodeWithTag("stress_readings_header").fetchSemanticsNode().boundsInRoot.top
        assertTrue("Breathing must appear above the reading list", breathing < readings)
        compose.onNodeWithTag("stress_detail_list").performScrollToNode(hasText("10.4 / 100"))
        compose.onNodeWithText("10.4 / 100").assertIsDisplayed()
    }
}
