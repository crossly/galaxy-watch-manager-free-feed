package dev.ricky.galaxywatchmanagerfree

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsEnabled
import androidx.compose.ui.test.assertTextContains
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import dev.ricky.galaxywatchmanagerfree.core.ConnectionProgress
import dev.ricky.galaxywatchmanagerfree.core.OnboardingController
import dev.ricky.galaxywatchmanagerfree.core.WatchController
import dev.ricky.galaxywatchmanagerfree.feature.DeviceIdentityStore
import dev.ricky.galaxywatchmanagerfree.feature.DeviceScope
import dev.ricky.galaxywatchmanagerfree.feature.IdentityEvent
import dev.ricky.galaxywatchmanagerfree.feature.OnboardingStatus
import dev.ricky.galaxywatchmanagerfree.feature.onboarding.CompanionApps
import dev.ricky.galaxywatchmanagerfree.feature.onboarding.CompanionEnvironment
import dev.ricky.galaxywatchmanagerfree.ui.onboarding.ConnectionOnboardingScreen
import dev.ricky.galaxywatchmanagerfree.ui.screens.connection.BondedWatch
import dev.ricky.galaxywatchmanagerfree.ui.screens.connection.BondedWatchResult
import dev.ricky.galaxywatchmanagerfree.ui.screens.connection.BondedWatchSource
import dev.ricky.galaxywatchmanagerfree.ui.theme.WatchFreeTheme
import java.util.UUID
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class OnboardingScreenTest {
    @get:Rule val compose = createComposeRule()
    private val app = ApplicationProvider.getApplicationContext<Context>()
    private val preferences = app.getSharedPreferences("watchfree", Context.MODE_PRIVATE)
    private val onboardingPreferences =
        app.getSharedPreferences("watchfree_onboarding", Context.MODE_PRIVATE)
    private val macs = mutableSetOf<String>()
    private lateinit var watch: BondedWatch
    private lateinit var source: TestWatchSource
    private lateinit var originalPreferences: Map<String, *>
    private lateinit var originalOnboardingPreferences: Map<String, *>
    private var originalVisible = false
    private var closed = false
    private val environment = CompanionEnvironment(CompanionApps.WEAR_INTL, true, true)

    @Before
    fun setUp() {
        WatchController.init(app)
        originalPreferences = preferences.all.toMap()
        originalOnboardingPreferences = onboardingPreferences.all.toMap()
        originalVisible = OnboardingController.isVisible
        watch = BondedWatch("Galaxy Watch Ultra", newMac())
        preferences
            .edit()
            .putString("watch_mac", watch.mac)
            .putBoolean("auto_connect", false)
            .putBoolean("enabled", false)
            .commit()
        WatchController.stopConnection(app)
        WatchController.resetProcessStateForTest()
        OnboardingController.open()
        source = TestWatchSource(BondedWatchResult(listOf(watch)))
    }

    @After
    fun cleanup() {
        WatchController.stopConnection(app)
        WatchController.resetProcessStateForTest()
        macs.forEach { mac ->
            DeviceIdentityStore(app, mac).transition(IdentityEvent.ClearHandover)
            app.deleteSharedPreferences(
                DeviceScope.preferences(DeviceIdentityStore.PREFS_BASE, mac)
            )
        }
        // Restoring through savedMac would clear the original device's handover flags.
        restorePreferences(preferences, originalPreferences)
        restorePreferences(onboardingPreferences, originalOnboardingPreferences)
        if (originalVisible) OnboardingController.open() else OnboardingController.close()
    }

    @Test
    fun fullScreenGuideShowsStepProgressAndSkip() {
        showGuide()

        compose.onNodeWithText(app.getString(R.string.onboarding_flow_title)).assertIsDisplayed()
        assertStep(1)
        compose.onNodeWithTag("tag_onboarding_primary").assertIsDisplayed()
        compose.onNodeWithTag("tag_onboarding_skip").performClick()
        assertTrue(closed)
        assertFalse(WatchController.isRunning)
    }

    @Test
    fun permissionFailureDoesNotMasqueradeAsAnUnpairedWatch() {
        assertPlatformIssue(R.string.conn_permission_needed)
    }

    @Test
    fun bluetoothOffDoesNotMasqueradeAsAnUnpairedWatch() {
        assertPlatformIssue(R.string.conn_bluetooth_off)
    }

    @Test
    fun missingBluetoothAdapterDoesNotMasqueradeAsAnUnpairedWatch() {
        assertPlatformIssue(R.string.conn_bluetooth_unavailable)
    }

    @Test
    fun noBondedWatchOpensTheOfficialPairingStepsAndStaysThere() {
        source.result = BondedWatchResult(emptyList())
        showGuide()

        assertStep(1)
        compose
            .onNodeWithTag("tag_onboarding_primary")
            .assertTextContains(app.getString(R.string.onboarding_view_steps))
            .performClick()
        compose.waitForIdle()

        // The install/pairing steps share step 1 and must not bounce back to the check card.
        assertStep(1)
        compose.onNodeWithText(app.getString(R.string.onboarding_install_title)).assertIsDisplayed()
        compose.onNodeWithTag("tag_onboarding_open_manager").assertIsEnabled()
        compose.onNodeWithTag("tag_onboarding_open_wear").assertIsEnabled()
        assertFalse(WatchController.isRunning)
    }

    @Test
    fun permissionRefreshPreservesTheSelectedDeviceAndItsResumeStep() {
        assertTrue(
            DeviceIdentityStore(app, watch.mac)
                .transition(IdentityEvent.ConfirmPhoneNode("abcdef12"))
        )
        source.result = BondedWatchResult(emptyList(), R.string.conn_permission_needed)
        showGuide()
        assertStep(1)
        assertEquals(watch.mac, WatchController.savedMac)

        source.result = BondedWatchResult(listOf(watch))
        val previousLoads = source.loads.get()
        compose.onNodeWithTag("tag_onboarding_recheck").performClick()
        compose.waitUntil(5_000) { source.loads.get() > previousLoads }
        compose.waitForIdle()

        assertStep(4)
        compose.onNodeWithText(app.getString(R.string.onboarding_connect_title)).assertIsDisplayed()
        assertEquals(watch.mac, WatchController.savedMac)
        assertFalse(WatchController.isRunning)
    }

    @Test
    fun renamedDeviceCanBeSelectedWithoutStartingAConnection() {
        val renamedWatch = BondedWatch("Morning runner", newMac())
        WatchController.savedMac = null
        source.result = BondedWatchResult(listOf(renamedWatch))
        showGuide()

        compose.onNodeWithTag("tag_onboarding_choose_watch").performClick()
        compose.onNodeWithTag("tag_device_${renamedWatch.mac}").performClick()
        compose.waitForIdle()

        compose
            .onNodeWithText(app.getString(R.string.onboarding_check_paired, renamedWatch.name))
            .assertIsDisplayed()
        assertEquals(renamedWatch.mac, WatchController.savedMac)
        assertFalse(WatchController.isRunning)
        assertFalse(DeviceIdentityStore(app, renamedWatch.mac).handoverPreparing)
        assertEquals("", DeviceIdentityStore(app, renamedWatch.mac).confirmedPhoneNode)
    }

    @Test
    fun staleSavedDeviceCannotResumeUsingItsConfirmedIdentity() {
        val staleMac = newMac()
        WatchController.savedMac = staleMac
        assertTrue(
            DeviceIdentityStore(app, staleMac)
                .transition(IdentityEvent.ConfirmPhoneNode("12345678"))
        )
        showGuide()

        assertStep(1)
        assertEquals(watch.mac, WatchController.savedMac)
        compose.onNodeWithText(app.getString(R.string.onboarding_step_check)).assertIsDisplayed()
        assertFalse(WatchController.isRunning)
    }

    @Test
    fun acquireButtonPersistsTheCandidateAndStopsAtReleaseBeforeRfcomm() {
        val store = DeviceIdentityStore(app, watch.mac)
        assertTrue(store.transition(IdentityEvent.StageCandidatePhoneNode("abcdef12")))
        showGuide()
        compose.onNodeWithTag("tag_onboarding_primary").performClick()
        compose
            .onNodeWithText(app.getString(R.string.onboarding_identity_title))
            .assertIsDisplayed()

        compose.onNodeWithTag("tag_onboarding_primary").performClick()
        compose.waitForIdle()

        assertStep(3)
        compose.onNodeWithText(app.getString(R.string.onboarding_release_title)).assertIsDisplayed()
        assertEquals("abcdef12", store.pendingHandoverNode)
        assertEquals("", store.confirmedPhoneNode)
        assertTrue(store.handoverPreparing)
        assertEquals(
            OnboardingStatus.PREPARING_HANDOVER,
            WatchController.connectionProgress.value.status,
        )
        assertFalse(WatchController.isRunning)
        compose.onNodeWithTag("tag_onboarding_primary").assertIsEnabled()
    }

    @Test
    fun persistedPreparationResumesAtReleaseAndAllowsContinuingToConnect() {
        assertTrue(
            DeviceIdentityStore(app, watch.mac).transition(IdentityEvent.BeginHandover("abcdef12"))
        )
        val progress =
            MutableStateFlow(ConnectionProgress(watch.mac, OnboardingStatus.PREPARING_HANDOVER))
        showGuide(progress)

        assertStep(3)
        compose.onNodeWithTag("tag_onboarding_primary").assertIsEnabled().performClick()

        assertStep(4)
        compose.onNodeWithTag("tag_onboarding_waiting_handover").assertIsDisplayed()
        compose.onNodeWithTag("tag_onboarding_connect_progress").assertDoesNotExist()
        compose.onNodeWithTag("tag_onboarding_primary").assertIsEnabled()
        assertFalse(WatchController.isRunning)
    }

    @Test
    fun confirmedIdentityResumesAtConnectWithoutStartingAConnection() {
        assertTrue(
            DeviceIdentityStore(app, watch.mac)
                .transition(IdentityEvent.ConfirmPhoneNode("abcdef12"))
        )
        showGuide()

        assertStep(4)
        compose.onNodeWithText(app.getString(R.string.onboarding_connect_title)).assertIsDisplayed()
        compose.onNodeWithTag("tag_onboarding_primary").assertIsEnabled()
        assertFalse(WatchController.isRunning)
    }

    @Test
    fun connectFailureIsVisibleAndIdentityCanBeAcquiredAgain() {
        assertTrue(
            DeviceIdentityStore(app, watch.mac)
                .transition(IdentityEvent.ConfirmPhoneNode("abcdef12"))
        )
        val progress = MutableStateFlow(ConnectionProgress(watch.mac, OnboardingStatus.ERROR))
        showGuide(progress)

        compose
            .onNodeWithTag("tag_onboarding_connect_status")
            .assertTextContains(app.getString(R.string.connection_desc_failed))
        compose.onNodeWithTag("tag_onboarding_connect_progress").assertDoesNotExist()
        compose.onNodeWithTag("tag_onboarding_primary").assertIsEnabled()
        compose.onNodeWithTag("tag_onboarding_reacquire").performClick()

        assertStep(2)
        compose
            .onNodeWithText(app.getString(R.string.onboarding_identity_title))
            .assertIsDisplayed()
        compose.onNodeWithTag("tag_onboarding_primary").assertIsEnabled()
        assertFalse(WatchController.isRunning)
    }

    @Test
    fun readyProgressReopensOnCompletionAndFinishDoesNotReconnect() {
        val progress = MutableStateFlow(ConnectionProgress(watch.mac, OnboardingStatus.READY))
        showGuide(progress)

        assertStep(5)
        compose.onNodeWithText(app.getString(R.string.onboarding_done_title)).assertIsDisplayed()
        compose.onNodeWithTag("tag_onboarding_finish").performClick()
        assertTrue(closed)
        assertFalse(WatchController.isRunning)
    }

    private fun showGuide(
        progress: StateFlow<ConnectionProgress> = WatchController.connectionProgress
    ) {
        compose.setContent {
            WatchFreeTheme(darkTheme = false) {
                ConnectionOnboardingScreen(
                    onClose = { closed = true },
                    watchSource = source,
                    readEnvironment = { environment },
                    connectionProgress = progress,
                )
            }
        }
        compose.waitUntil(5_000) { source.loads.get() > 0 }
        compose.waitForIdle()
    }

    private fun assertPlatformIssue(issueRes: Int) {
        source.result = BondedWatchResult(emptyList(), issueRes)
        showGuide()

        compose
            .onNodeWithTag("tag_onboarding_platform_issue")
            .assertTextContains(app.getString(issueRes))
        compose
            .onNodeWithText(
                app.getString(
                    R.string.onboarding_check_paired,
                    app.getString(R.string.onboarding_check_none),
                )
            )
            .assertDoesNotExist()
        assertStep(1)
        assertEquals(watch.mac, WatchController.savedMac)
        assertFalse(WatchController.isRunning)
    }

    private fun assertStep(number: Int) {
        compose
            .onNodeWithText(app.getString(R.string.onboarding_step_progress, number, 5))
            .assertIsDisplayed()
    }

    private fun newMac(): String =
        ("02:" +
                UUID.randomUUID().toString().replace("-", "").take(10).chunked(2).joinToString(":"))
            .also { macs += it }

    private fun restorePreferences(target: SharedPreferences, snapshot: Map<String, *>) {
        val editor = target.edit().clear()
        snapshot.forEach { (key, value) ->
            when (value) {
                is Boolean -> editor.putBoolean(key, value)
                is Int -> editor.putInt(key, value)
                is Long -> editor.putLong(key, value)
                is Float -> editor.putFloat(key, value)
                is String -> editor.putString(key, value)
                is Set<*> -> editor.putStringSet(key, value.filterIsInstance<String>().toSet())
            }
        }
        editor.commit()
    }

    private class TestWatchSource(@Volatile var result: BondedWatchResult) : BondedWatchSource {
        val loads = AtomicInteger()

        override suspend fun load(): BondedWatchResult {
            loads.incrementAndGet()
            return result
        }
    }
}
