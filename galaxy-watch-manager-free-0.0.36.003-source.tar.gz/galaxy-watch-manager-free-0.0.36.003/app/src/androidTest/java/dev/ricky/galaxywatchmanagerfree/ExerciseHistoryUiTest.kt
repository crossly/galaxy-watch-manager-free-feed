package dev.ricky.galaxywatchmanagerfree

import android.content.Context
import android.content.res.Configuration
import android.os.LocaleList
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.test.core.app.ApplicationProvider
import dev.ricky.galaxywatchmanagerfree.feature.ExerciseLog
import dev.ricky.galaxywatchmanagerfree.feature.WatchState
import dev.ricky.galaxywatchmanagerfree.ui.components.BatteryGaugeCard
import dev.ricky.galaxywatchmanagerfree.ui.screens.ExerciseRow
import dev.ricky.galaxywatchmanagerfree.ui.screens.ExerciseSheet
import dev.ricky.galaxywatchmanagerfree.ui.theme.WatchFreeTheme
import java.io.File
import org.junit.Rule
import org.junit.Test

class ExerciseHistoryUiTest {
    @get:Rule val compose = createComposeRule()

    @Composable
    private fun English(content: @Composable () -> Unit) {
        val app = ApplicationProvider.getApplicationContext<Context>()
        val config =
            Configuration(app.resources.configuration).apply {
                setLocales(LocaleList.forLanguageTags("en"))
            }
        CompositionLocalProvider(
            LocalContext provides app.createConfigurationContext(config),
            LocalConfiguration provides config,
        ) {
            WatchFreeTheme(darkTheme = true, content = content)
        }
    }

    private fun session(id: String, type: Int) =
        ExerciseLog.Session(
            id = id,
            typeCode = type,
            startMillis = 1_793_702_400_000L,
            endMillis = 1_793_704_200_000L,
            durationMinutes = 30,
            calories = 200,
            distanceMeters = -1.0,
            avgHeartRate = 110,
            maxHeartRate = 140,
        )

    private fun capture(name: String) {
        val context = ApplicationProvider.getApplicationContext<Context>()
        File(context.getExternalFilesDir(null), "$name.png").outputStream().use {
            (if (name.startsWith("cycling")) compose.onNode(hasScrollToIndexAction())
                else compose.onRoot())
                .captureToImage()
                .asAndroidBitmap()
                .compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it)
        }
    }

    @Test
    fun batteryDistinguishesWaitingLearningAndZero() {
        val state = mutableStateOf(WatchState())
        compose.setContent { English { BatteryGaugeCard(state.value) } }
        compose.onAllNodesWithText("Waiting for watch estimate").assertCountEquals(2)
        compose.runOnIdle {
            state.value =
                WatchState(
                    normalBatteryEstimateReceived = true,
                    psmBatteryEstimateReceived = true,
                    remainingNormalMin = -1,
                    remainingPsmMin = 0,
                )
        }
        compose.onNodeWithText("Learning usage patterns").assertIsDisplayed()
        compose.onNodeWithText("0 minutes").assertIsDisplayed()
        capture("battery-learning-and-zero")
    }

    @Test
    fun workoutFilterSelectsCyclingAndRestoresAllTypes() {
        val sessions =
            listOf(
                session("bike", 11007).copy(distanceMeters = 12_345.0),
                session("swim", 14001),
                session("misc", 0),
            )
        compose.setContent { English { ExerciseSheet(sessions, onDismiss = {}) } }
        compose.onNodeWithText("All workouts").performClick()
        compose.onAllNodesWithText("Cycling").onLast().performClick()
        compose.onNode(hasText("Cycling") and hasClickAction()).assertIsDisplayed()
        capture("cycling-before-scroll")
        compose
            .onNode(hasScrollToIndexAction())
            .performScrollToNode(hasText("12.35", substring = true))
        compose
            .onAllNodesWithText("12.35", substring = true)
            .onLast()
            .performScrollTo()
            .assertIsDisplayed()
        capture("cycling-history-filter")
        compose
            .onNode(hasScrollToIndexAction())
            .performScrollToNode(hasText("Cycling") and hasClickAction())
        compose.onNode(hasText("Cycling") and hasClickAction()).performClick()
        compose.onNodeWithText("All workouts").performClick()
        compose.onNodeWithText("All workouts").assertIsDisplayed()
    }

    @Test
    fun swimStrokeCountAndStrengthRepetitionsRemainDistinct() {
        val swim =
            session("swim", 14001)
                .copy(count = 600, countType = 30002, minHeartRate = 65, maxSpeed = 2.3)
        val strength =
            session("strength", 10012).copy(title = "Leg session", count = 30, countType = 30004)
        compose.setContent {
            English {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    ExerciseRow(swim)
                    ExerciseRow(strength)
                }
            }
        }
        compose.onNodeWithText("Strokes: 600").assertIsDisplayed()
        compose.onAllNodesWithText("View details").onFirst().performClick()
        compose.onNodeWithText("Minimum heart rate: 65 bpm").performScrollTo().assertIsDisplayed()
        compose.onNodeWithText("Maximum speed: 8.28 km/h").performScrollTo().assertIsDisplayed()
        compose.onNodeWithText("Leg session").performScrollTo().assertIsDisplayed()
        compose.onNodeWithText("Repetitions: 30").performScrollTo().assertIsDisplayed()
        compose.onNodeWithText("0.00 km").assertDoesNotExist()
        capture("workout-counts")
    }
}
