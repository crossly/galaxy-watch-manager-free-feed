package dev.ricky.galaxywatchmanagerfree

import android.content.Context
import android.content.ContextWrapper
import android.content.SharedPreferences
import android.content.res.Configuration
import android.os.LocaleList
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.test.core.app.ApplicationProvider
import dev.ricky.galaxywatchmanagerfree.feature.WatchRepository
import dev.ricky.galaxywatchmanagerfree.ui.screens.SettingCategory
import dev.ricky.galaxywatchmanagerfree.ui.screens.SettingsCategoryContent
import dev.ricky.galaxywatchmanagerfree.ui.theme.WatchFreeTheme
import dev.ricky.galaxywatchmanagerfree.wcs.RfcommTransport
import dev.ricky.galaxywatchmanagerfree.wcs.WcsSession
import java.util.UUID
import org.junit.After
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test

/** Offline repositories use isolated preferences; no Bluetooth connection or watch queries. */
class AutoQuerySettingsTest {
    @get:Rule val compose = createComposeRule()
    private val app = ApplicationProvider.getApplicationContext<Context>()
    private val prefix = "query_test_${UUID.randomUUID()}_"
    private val originalAutoConnect =
        dev.ricky.galaxywatchmanagerfree.core.WatchController.autoConnectEnabled
    private val created = mutableSetOf<String>()
    private val repositories = mutableListOf<WatchRepository>()
    private val context =
        object : ContextWrapper(app) {
            override fun getSharedPreferences(name: String, mode: Int): SharedPreferences {
                val scoped = prefix + name
                created += scoped
                return super.getSharedPreferences(scoped, mode)
            }
        }

    private fun repository(address: String? = null): WatchRepository =
        WatchRepository(context, WcsSession(context, RfcommTransport(context), address)).also {
            repositories += it
        }

    @After
    fun cleanup() {
        repositories.forEach { it.close() }
        created.forEach { app.deleteSharedPreferences(it) }
        dev.ricky.galaxywatchmanagerfree.core.WatchController.autoConnectEnabled =
            originalAutoConnect
    }

    @Test
    fun settingsPersistAndPropagateAcrossDeviceAndOfflineRepositories() {
        val offline = repository()
        val device = repository("02:11:22:33:44:55")
        compose.runOnIdle {
            assertEquals(900, device.state.value.autoQueryIntervalSeconds)
            offline.setAutoQueryIntervalSeconds(60)
            offline.autoRefreshEnabled = false
            assertFalse(device.state.value.autoRefresh)
            assertEquals(60, device.state.value.autoQueryIntervalSeconds)
        }
        val reopened = repository("02:11:22:33:44:66")
        assertFalse(reopened.state.value.autoRefresh)
        assertEquals(60, reopened.state.value.autoQueryIntervalSeconds)
        compose.runOnIdle {
            reopened.autoRefreshEnabled = true
            assertTrue(offline.state.value.autoRefresh)
            assertTrue(device.state.value.autoRefresh)
        }
    }

    @Test
    fun englishDarkSettingsWorkOnNarrowScreenWithLargeText() {
        checkSettings("en", dark = true)
    }

    @Test
    fun chineseLightSettingsWorkOnNarrowScreenWithLargeText() {
        checkSettings("zh-CN", dark = false)
    }

    private fun checkSettings(locale: String, dark: Boolean) {
        val repo = repository()
        val configuration =
            Configuration(app.resources.configuration).apply {
                setLocales(LocaleList.forLanguageTags(locale))
            }
        val localized = app.createConfigurationContext(configuration)
        val strings = localized.resources
        compose.setContent {
            val density = LocalDensity.current.density
            val activityResults =
                requireNotNull(androidx.activity.compose.LocalActivityResultRegistryOwner.current)
            CompositionLocalProvider(
                androidx.activity.compose.LocalActivityResultRegistryOwner provides activityResults,
                LocalContext provides localized,
                LocalConfiguration provides configuration,
                LocalDensity provides Density(density, 1.5f),
            ) {
                WatchFreeTheme(darkTheme = dark) {
                    Box(Modifier.width(320.dp)) {
                        SettingsCategoryContent(
                            repo.state.collectAsState().value,
                            repo,
                            SettingCategory.DEVICE,
                        )
                    }
                }
            }
        }
        compose.onNodeWithTag("tag_auto_connect").performScrollTo().performClick()
        compose.runOnIdle {
            assertEquals(
                !originalAutoConnect,
                dev.ricky.galaxywatchmanagerfree.core.WatchController.autoConnectEnabled,
            )
            assertEquals(
                !originalAutoConnect,
                dev.ricky.galaxywatchmanagerfree.ui.screens.connection
                    .ConnectionPageModel(localized)
                    .state
                    .value
                    .autoConnect,
            )
        }

        val title = strings.getString(R.string.auto_query_interval)
        compose.onNodeWithText(title).performScrollTo().performClick()
        compose
            .onNodeWithText(strings.getString(R.string.auto_query_interval_seconds, 60))
            .performClick()
        compose.runOnIdle { assertEquals(60, repo.state.value.autoQueryIntervalSeconds) }
        compose
            .onNodeWithText(strings.getString(R.string.auto_query))
            .performScrollTo()
            .performClick()
        compose.runOnIdle { assertFalse(repo.state.value.autoRefresh) }
        compose.onNodeWithText(title).assertDoesNotExist()
    }
}
