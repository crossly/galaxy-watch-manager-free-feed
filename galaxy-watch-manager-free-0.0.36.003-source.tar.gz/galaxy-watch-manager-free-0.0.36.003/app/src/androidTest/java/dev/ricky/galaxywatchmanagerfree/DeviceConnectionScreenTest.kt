package dev.ricky.galaxywatchmanagerfree

import android.content.Context
import android.content.res.Configuration
import android.os.LocaleList
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.test.assertHasClickAction
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsOn
import androidx.compose.ui.test.assertIsSelected
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import dev.ricky.galaxywatchmanagerfree.feature.OnboardingStatus
import dev.ricky.galaxywatchmanagerfree.feature.WatchState
import dev.ricky.galaxywatchmanagerfree.ui.screens.connection.BondedWatch
import dev.ricky.galaxywatchmanagerfree.ui.screens.connection.ConnectionOwnership
import dev.ricky.galaxywatchmanagerfree.ui.screens.connection.ConnectionPageUiState
import dev.ricky.galaxywatchmanagerfree.ui.screens.connection.DeviceConnectionContent
import dev.ricky.galaxywatchmanagerfree.ui.theme.WatchFreeTheme
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class DeviceConnectionScreenTest {
    @get:Rule val compose = createComposeRule()
    private val app = ApplicationProvider.getApplicationContext<Context>()
    private var connected = false
    private var stopped = false
    private var resolved = false
    private var pickedMac = ""

    private fun render(
        status: OnboardingStatus = OnboardingStatus.IDLE,
        issue: Int? = null,
        englishLarge: Boolean = false,
        dark: Boolean = false,
        ownership: ConnectionOwnership = ConnectionOwnership.DIRECT,
        autoRefresh: Boolean = true,
    ) {
        val config =
            Configuration(app.resources.configuration).apply {
                if (englishLarge) {
                    setLocales(LocaleList.forLanguageTags("en"))
                    fontScale = 2f
                }
            }
        val localized = app.createConfigurationContext(config)
        compose.setContent {
            val density = LocalDensity.current
            CompositionLocalProvider(
                LocalContext provides localized,
                LocalConfiguration provides config,
                LocalDensity provides
                    Density(density.density, if (englishLarge) 2f else density.fontScale),
            ) {
                WatchFreeTheme(darkTheme = dark) {
                    Box(Modifier.width(320.dp).verticalScroll(rememberScrollState())) {
                        DeviceConnectionContent(
                            ui =
                                ConnectionPageUiState(
                                    watches =
                                        listOf(
                                            BondedWatch("Galaxy Watch6", "00:11:22:33:44:55"),
                                            BondedWatch("Galaxy Watch Ultra", "00:11:22:33:44:66"),
                                        ),
                                    selectedMac = "00:11:22:33:44:55",
                                    issueRes = issue,
                                    ownership = ownership,
                                ),
                            state =
                                WatchState(
                                    onboardingStatus = status,
                                    connected = status == OnboardingStatus.READY,
                                    sessionReady = status == OnboardingStatus.READY,
                                    autoRefresh = autoRefresh,
                                ),
                            status = status,
                            onRefresh = {},
                            onSelectWatch = { pickedMac = it },
                            onConnect = { connected = true },
                            onStop = { stopped = true },
                            onShowOnboarding = {},
                            onAutoConnectChange = {},
                            onAutoRefreshChange = {},
                            onAutoIntervalChange = {},
                            onResolvePlatform = { resolved = true },
                            showHandover = false,
                        )
                    }
                }
            }
        }
    }

    @Test
    fun connectActionRemainsReachableWithoutAdvancedOptions() {
        render()
        compose.onNodeWithTag("tag_connect_button").performScrollTo().performClick()
        assertTrue(connected)
        compose.onNodeWithTag("tag_connection_advanced").assertDoesNotExist()
    }

    @Test
    fun identityAcquisitionCanBeStoppedBeforeTransportConnects() {
        render(OnboardingStatus.ACQUIRING_IDENTITY)
        compose.onNodeWithTag("tag_stop_connection").performScrollTo().performClick()
        assertTrue(stopped)
    }

    @Test
    fun readyConnectionCanBeStopped() {
        render(OnboardingStatus.READY)
        compose.onNodeWithTag("tag_stop_connection").performScrollTo().performClick()
        assertTrue(stopped)
    }

    @Test
    fun failedVerificationOffersRetry() {
        render(OnboardingStatus.ERROR)
        compose
            .onNodeWithText(app.getString(R.string.connection_status_failed))
            .performScrollTo()
            .assertIsDisplayed()
        compose.onNodeWithTag("tag_connect_button").performScrollTo().performClick()
        assertTrue(connected)
    }

    @Test
    fun platformIssueExplainsRecoveryAndDisablesConnection() {
        render(issue = R.string.conn_permission_needed)
        compose.onNodeWithTag("tag_resolve_platform").performScrollTo().performClick()
        assertTrue(resolved)
        compose.onNodeWithTag("tag_connect_button").assertDoesNotExist()
    }

    @Test fun englishLargeTextLightThemeReachesConnectionHelp() = checkLargeText(false)

    @Test fun englishLargeTextDarkThemeReachesConnectionHelp() = checkLargeText(true)

    @Test
    fun preparedHandoverWaitsForUserWithoutProgressOrStop() {
        render(OnboardingStatus.PREPARING_HANDOVER)
        compose.onNodeWithTag("tag_connection_progress").assertDoesNotExist()
        compose.onNodeWithTag("tag_stop_connection").assertDoesNotExist()
        compose.onNodeWithTag("tag_connect_button").assertDoesNotExist()
        compose
            .onNodeWithText(app.getString(R.string.connection_status_preparing))
            .assertIsDisplayed()
    }

    @Test
    fun officialAppOwnershipExplainsPausedAutoConnectAndOffersTakeBack() {
        render(ownership = ConnectionOwnership.OFFICIAL_APPS)
        compose.onNodeWithTag("tag_auto_connect").assertIsOn()
        compose.onNodeWithTag("tag_auto_connect_paused").assertIsDisplayed()
        compose
            .onNodeWithTag("tag_take_connection_back")
            .assertHasClickAction()
            .performScrollTo()
            .performClick()
        compose
            .onNodeWithText(app.getString(R.string.connection_status_official_apps))
            .assertIsDisplayed()
    }

    @Test
    fun queryIntervalIsHiddenWhenAutomaticQueriesAreDisabled() {
        render(autoRefresh = false)
        compose.onNodeWithText(app.getString(R.string.auto_query_interval)).assertDoesNotExist()
    }

    @Test
    fun queryIntervalAppearsWhenAutomaticQueriesAreEnabled() {
        render(autoRefresh = true)
        compose
            .onNodeWithText(app.getString(R.string.auto_query_interval))
            .performScrollTo()
            .assertIsDisplayed()
    }

    @Test
    fun selectedWatchCanBeChangedFromTheSelectionSheet() {
        render()
        compose.onNodeWithTag("tag_choose_watch").performScrollTo().performClick()
        compose.onNodeWithTag("tag_device_00:11:22:33:44:55").assertIsSelected()
        compose.onNodeWithTag("tag_device_00:11:22:33:44:66").performScrollTo().performClick()
        assertEquals("00:11:22:33:44:66", pickedMac)
        compose.onNodeWithTag("tag_device_00:11:22:33:44:66").assertDoesNotExist()
    }

    private fun checkLargeText(dark: Boolean) {
        render(englishLarge = true, dark = dark)
        compose.onNodeWithTag("tag_show_onboarding").performScrollTo().assertIsDisplayed()
        compose.onNodeWithTag("tag_auto_connect").performScrollTo().assertIsDisplayed()
    }
}
