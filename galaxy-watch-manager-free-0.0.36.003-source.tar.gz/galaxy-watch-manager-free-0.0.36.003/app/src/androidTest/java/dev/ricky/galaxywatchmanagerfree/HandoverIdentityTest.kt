package dev.ricky.galaxywatchmanagerfree

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import dev.ricky.galaxywatchmanagerfree.core.AutoConnectResult
import dev.ricky.galaxywatchmanagerfree.core.WatchController
import dev.ricky.galaxywatchmanagerfree.feature.DeviceIdentityStore
import dev.ricky.galaxywatchmanagerfree.feature.DeviceScope
import dev.ricky.galaxywatchmanagerfree.feature.IdentityEvent
import dev.ricky.galaxywatchmanagerfree.feature.OnboardingStatus
import java.util.UUID
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/**
 * 交接（临时停用官方连接管理 App）身份契约。
 *
 * 待定身份必须：跨进程存活、永不被当作已确认身份、取消/换目标即清除、经 WCS 验证后不再待定； 准备期间前台与粘性重启都不得自动连接。
 */
@RunWith(AndroidJUnit4::class)
class HandoverIdentityTest {
    private val app = ApplicationProvider.getApplicationContext<Context>()
    private val macs = mutableSetOf<String>()
    private var originalSavedMac: String? = null
    private var originalEnabled = false

    @Before
    fun setUp() {
        WatchController.init(app)
        originalSavedMac = WatchController.savedMac
        originalEnabled = WatchController.enabled
        // Application.onCreate may already have auto-started a real connection.
        WatchController.stopConnection(app)
        WatchController.resetProcessStateForTest()
    }

    @After
    fun tearDown() {
        WatchController.resetProcessStateForTest()
        // Restore the real selection before stop() rebuilds the offline repository.
        WatchController.savedMac = originalSavedMac
        WatchController.enabled = originalEnabled
        WatchController.stop()
        macs.forEach { mac ->
            DeviceIdentityStore(app, mac).transition(IdentityEvent.ClearHandover)
            app.deleteSharedPreferences(prefsName(mac))
        }
    }

    @Test
    fun pendingHandoverSurvivesProcessRestartAndIsNeverConfirmed() {
        val mac = newMac()
        assertTrue(
            DeviceIdentityStore(app, mac).transition(IdentityEvent.BeginHandover("abcdef12"))
        )

        // A new store instance reads the same device-scoped prefs, as after process death.
        val restarted = DeviceIdentityStore(app, mac)
        assertTrue(restarted.handoverPreparing)
        assertEquals("abcdef12", restarted.pendingHandoverNode)
        assertTrue(restarted.hasPendingHandover)
        assertEquals("", restarted.confirmedPhoneNode)
        assertEquals("", restarted.candidatePhoneNode)
        assertEquals("", restarted.effectivePhoneNode)
        assertFalse(restarted.hasStoredPhoneNode)
        assertEquals(DeviceIdentityStore.IdentityPhase.PENDING, restarted.phase)
    }

    @Test
    fun cancellingHandoverDropsPendingIdentityAcrossInstances() {
        val mac = newMac()
        val store = DeviceIdentityStore(app, mac)
        store.transition(IdentityEvent.BeginHandover("12345678"))
        assertTrue(store.transition(IdentityEvent.StageCandidatePhoneNode("12345678")))

        store.transition(IdentityEvent.ClearHandover)

        val restarted = DeviceIdentityStore(app, mac)
        assertFalse(restarted.handoverPreparing)
        assertFalse(restarted.hasPendingHandover)
        assertEquals("", restarted.pendingHandoverNode)
        assertEquals("", restarted.candidatePhoneNode)
        assertEquals("", restarted.confirmedPhoneNode)
        assertEquals(DeviceIdentityStore.IdentityPhase.NONE, restarted.phase)
    }

    @Test
    fun confirmedIdentityIsNoLongerPending() {
        val mac = newMac()
        val store = DeviceIdentityStore(app, mac)
        store.transition(IdentityEvent.StagePendingHandover("87654321"))
        assertTrue(store.hasPendingHandover)

        assertTrue(store.transition(IdentityEvent.ConfirmPhoneNode("87654321")))

        val restarted = DeviceIdentityStore(app, mac)
        assertEquals("87654321", restarted.confirmedPhoneNode)
        assertFalse(restarted.hasPendingHandover)
        assertFalse(restarted.handoverPreparing)
        assertEquals("", restarted.pendingHandoverNode)
    }

    @Test
    fun leavingPreparationKeepsPendingUnverifiedUntilWatchProof() {
        val mac = newMac()
        val store = DeviceIdentityStore(app, mac)
        store.transition(IdentityEvent.BeginHandover("abcdef12"))

        // continueHandover only clears the pause; the node stays pending.
        assertTrue(store.transition(IdentityEvent.EndHandoverPreparation))

        val restarted = DeviceIdentityStore(app, mac)
        assertFalse(restarted.handoverPreparing)
        assertEquals("abcdef12", restarted.pendingHandoverNode)
        assertEquals("", restarted.confirmedPhoneNode)
        assertEquals("", restarted.effectivePhoneNode)
    }

    @Test
    fun preparePersistsTheLiveCandidateBeforePausing() {
        val mac = newMac()
        val store = DeviceIdentityStore(app, mac)
        assertTrue(store.transition(IdentityEvent.StageCandidatePhoneNode("abcdef12")))
        WatchController.enabled = true
        WatchController.savedMac = mac
        WatchController.resetProcessStateForTest()

        assertTrue(WatchController.prepareHandover(app))

        // The volatile candidate must be captured durably before the connection is stopped.
        assertEquals("abcdef12", store.pendingHandoverNode)
        assertEquals("", store.confirmedPhoneNode)
        assertTrue(store.handoverPreparing)
    }

    @Test
    fun switchingTargetClearsOnlyThePreviousPendingHandover() {
        val oldMac = newMac()
        val nextMac = newMac()
        val oldStore = DeviceIdentityStore(app, oldMac)
        oldStore.transition(IdentityEvent.BeginHandover("abcdef12"))
        // The next target is itself preparing, so startService refuses without touching Bluetooth.
        assertTrue(
            DeviceIdentityStore(app, nextMac).transition(IdentityEvent.BeginHandover("12345678"))
        )

        WatchController.enabled = true
        WatchController.savedMac = oldMac
        WatchController.resetProcessStateForTest()

        assertFalse(WatchController.switchTarget(app, nextMac))

        // Foreground/startup auto connect never bypasses the paused preparation.
        assertEquals(
            AutoConnectResult.PAUSED_BY_USER,
            WatchController.autoConnect(app, force = true),
        )
        assertEquals(AutoConnectResult.PAUSED_BY_USER, WatchController.resumeAutoConnect(app))
        assertFalse(oldStore.handoverPreparing)
        assertFalse(oldStore.hasPendingHandover)
        assertEquals("", oldStore.pendingHandoverNode)
        assertEquals("12345678", DeviceIdentityStore(app, nextMac).pendingHandoverNode)
    }

    @Test
    fun preparingBlocksForegroundAndStickyRestartsWithoutLosingIdentity() {
        val mac = newMac()
        val store = DeviceIdentityStore(app, mac)
        assertTrue(store.transition(IdentityEvent.ConfirmPhoneNode("abcdef12")))
        WatchController.enabled = true
        WatchController.savedMac = mac
        WatchController.resetProcessStateForTest()

        assertTrue(WatchController.prepareHandover(app))
        assertEquals(
            OnboardingStatus.PREPARING_HANDOVER,
            WatchController.connectionProgress.value.status,
        )
        assertEquals(mac, WatchController.connectionProgress.value.mac)
        assertEquals("abcdef12", store.pendingHandoverNode)
        assertTrue(store.handoverPreparing)
        // Paused before RFCOMM: the verified node is durable-pending, not a live candidate.
        assertEquals("", store.candidatePhoneNode)
        assertEquals("abcdef12", store.confirmedPhoneNode)
        // Foreground/manual start is refused while preparing.
        assertFalse(WatchController.startService(app, mac))

        // Process restart: process-local pause is gone, the durable preparing flag still blocks.
        WatchController.resetProcessStateForTest()
        WatchController.enabled = true
        assertNull(WatchController.admitServiceStart(mac, null))

        WatchController.cancelHandover(app)

        WatchController.resetProcessStateForTest()
        WatchController.enabled = true
        assertFalse(store.handoverPreparing)
        assertFalse(store.hasPendingHandover)
        // The previously verified identity survives cancellation and allows a normal restart.
        assertEquals("abcdef12", store.confirmedPhoneNode)
        assertNotNull(WatchController.admitServiceStart(mac, null))
    }

    @Test
    fun manualNodeDuringPreparationOnlyUpdatesPendingIdentity() {
        val mac = newMac()
        val store = DeviceIdentityStore(app, mac)
        store.transition(IdentityEvent.BeginHandover())
        WatchController.savedMac = mac
        WatchController.resetProcessStateForTest()
        WatchController.enabled = true

        assertTrue(WatchController.connectWithNode(app, mac, "1234abcd"))

        assertEquals("1234abcd", store.pendingHandoverNode)
        assertTrue(store.handoverPreparing)
        assertEquals("", store.candidatePhoneNode)
        assertNull(WatchController.admitServiceStart(mac, null))
    }

    @Test
    fun continueWithoutPendingOrConfirmedIdentityIsRejected() {
        val mac = newMac()
        WatchController.savedMac = mac
        WatchController.resetProcessStateForTest()

        assertFalse(WatchController.continueHandover(app))
    }

    @Test
    fun restoringOfficialAppsBlocksAutoConnectAfterProcessRestart() {
        val mac = newMac()
        val store = DeviceIdentityStore(app, mac)
        assertTrue(store.transition(IdentityEvent.ConfirmPhoneNode("abcdef12")))
        WatchController.savedMac = mac
        WatchController.enabled = true

        assertTrue(WatchController.releaseConnectionToOfficialApps(app))
        WatchController.resetProcessStateForTest()

        assertTrue(DeviceIdentityStore(app, mac).releasedToOfficialApps)
        assertEquals(
            AutoConnectResult.PAUSED_FOR_OFFICIAL_APPS,
            WatchController.resumeAutoConnect(app),
        )
        assertEquals(
            AutoConnectResult.PAUSED_FOR_OFFICIAL_APPS,
            WatchController.autoConnect(app, force = true),
        )
        assertEquals("abcdef12", DeviceIdentityStore(app, mac).confirmedPhoneNode)
    }

    @Test
    fun restoringOfficialAppsBlocksStickyServiceAfterProcessRestart() {
        val mac = newMac()
        assertTrue(
            DeviceIdentityStore(app, mac).transition(IdentityEvent.ConfirmPhoneNode("abcdef12"))
        )
        WatchController.savedMac = mac
        WatchController.enabled = true

        assertTrue(WatchController.releaseConnectionToOfficialApps(app))
        WatchController.resetProcessStateForTest()
        WatchController.enabled = true

        assertTrue(DeviceIdentityStore(app, mac).releasedToOfficialApps)
        assertNull(WatchController.admitServiceStart(mac, null))
    }

    @Test
    fun reclaimingFromOfficialAppsClearsDurablePause() {
        val mac = newMac()
        val store = DeviceIdentityStore(app, mac)
        assertTrue(store.transition(IdentityEvent.ConfirmPhoneNode("abcdef12")))
        assertEquals(DeviceIdentityStore.IdentityPhase.CONFIRMED, store.phase)

        assertTrue(store.transition(IdentityEvent.ReleaseToOfficialApps))
        assertTrue(store.releasedToOfficialApps)
        assertEquals(DeviceIdentityStore.IdentityPhase.RELEASED, store.phase)
        assertEquals(
            DeviceIdentityStore.IdentityPhase.RELEASED,
            DeviceIdentityStore(app, mac).phase,
        )
        store.transition(IdentityEvent.ReclaimFromOfficialApps)
        assertFalse(store.releasedToOfficialApps)
        assertEquals(DeviceIdentityStore.IdentityPhase.CONFIRMED, store.phase)
    }

    private fun newMac(): String {
        val hex = UUID.randomUUID().toString().replace("-", "").take(10)
        val mac = "02:" + hex.chunked(2).joinToString(":")
        macs += mac
        return mac
    }

    private fun prefsName(mac: String): String =
        DeviceScope.preferences(DeviceIdentityStore.PREFS_BASE, mac)
}
