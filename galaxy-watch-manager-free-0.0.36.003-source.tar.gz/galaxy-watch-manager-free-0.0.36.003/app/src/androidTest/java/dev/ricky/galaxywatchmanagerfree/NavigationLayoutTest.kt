package dev.ricky.galaxywatchmanagerfree

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsOff
import androidx.compose.ui.test.assertIsOn
import androidx.compose.ui.test.assertIsSelected
import androidx.compose.ui.test.junit4.StateRestorationTester
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.test.core.app.ApplicationProvider
import dev.ricky.galaxywatchmanagerfree.ui.HomeScreen
import dev.ricky.galaxywatchmanagerfree.ui.theme.ThemeController
import dev.ricky.galaxywatchmanagerfree.ui.theme.WatchFreeTheme
import org.junit.After
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test

class NavigationLayoutTest {
    @get:Rule val compose = createComposeRule()
    private val app = ApplicationProvider.getApplicationContext<Context>()
    private var originalStyle = ThemeController.NAVIGATION_FLOATING
    private var originalGlassEffect = false

    @Before
    fun rememberAppearance() {
        ThemeController.init(app)
        originalStyle = ThemeController.navigationStyle.value
        originalGlassEffect = ThemeController.glassEffect.value
    }

    @After
    fun restoreAppearance() {
        ThemeController.setNavigationStyle(app, originalStyle)
        ThemeController.setGlassEffect(app, originalGlassEffect)
    }

    @Test
    fun restoredSettingsSubpageKeepsRootNavigationHidden() {
        checkRestoredDetail(ThemeController.NAVIGATION_FLOATING)
    }

    @Test
    fun fixedNavigationStaysHiddenAfterDetailRestoration() {
        checkRestoredDetail(ThemeController.NAVIGATION_FIXED)
    }

    private fun checkRestoredDetail(style: Int) {
        ThemeController.setNavigationStyle(app, style)
        val restoration = StateRestorationTester(compose)
        restoration.setContent { WatchFreeTheme { HomeScreen() } }
        compose.onNodeWithTag("tag_nav_SETTINGS").performClick()
        compose.onNodeWithText(app.getString(R.string.language)).performClick()
        assertNavigationHidden()
        restoration.emulateSavedInstanceStateRestore()
        assertNavigationHidden()
        compose.onNodeWithText(app.getString(R.string.language_english)).assertExists()
    }

    @Test
    fun changingNavigationInAppearancePreservesSettingsAndSelectedTab() {
        ThemeController.setNavigationStyle(app, ThemeController.NAVIGATION_FLOATING)
        val restoration = StateRestorationTester(compose)
        restoration.setContent { WatchFreeTheme { HomeScreen() } }
        compose.onNodeWithTag("tag_nav_SETTINGS").performClick()
        compose.onNodeWithText(app.getString(R.string.appearance)).performClick()
        compose.onNodeWithTag("tag_navigation_style_fixed").performScrollTo().performClick()
        assertNavigationHidden()
        compose.onNodeWithTag("tag_navigation_style_fixed").assertIsSelected()
        restoration.emulateSavedInstanceStateRestore()
        compose.onNodeWithTag("tag_navigation_style_fixed").performScrollTo().assertIsSelected()
        compose.onNodeWithContentDescription(app.getString(R.string.back)).performClick()
        compose.onNodeWithTag("tag_navigation_fixed").assertIsDisplayed()
        compose.onNodeWithTag("tag_nav_SETTINGS").assertIsSelected()
        compose.onNodeWithTag("tag_nav_HEALTH").performClick()
        compose.onNodeWithTag("tag_nav_HEALTH").assertIsSelected()
        val navigationTop =
            compose.onNodeWithTag("tag_navigation_fixed").fetchSemanticsNode().boundsInRoot.top
        val contentBottom =
            compose.onNodeWithTag("block_grid").fetchSemanticsNode().boundsInRoot.bottom
        assertTrue(
            "Fixed navigation reserves its own layout space",
            contentBottom <= navigationTop + 1f,
        )
        compose.runOnIdle {
            ThemeController.setNavigationStyle(app, ThemeController.NAVIGATION_FLOATING)
        }
        compose.onNodeWithTag("tag_navigation_floating").assertIsDisplayed()
        compose.onNodeWithTag("tag_nav_HEALTH").assertIsSelected()
    }

    @Test
    fun glassEffectCanBeEnabledFromAppearanceAndSurvivesStateRestore() {
        ThemeController.setNavigationStyle(app, ThemeController.NAVIGATION_FLOATING)
        ThemeController.setGlassEffect(app, false)
        val restoration = StateRestorationTester(compose)
        restoration.setContent { WatchFreeTheme { HomeScreen() } }
        compose.onNodeWithTag("tag_nav_SETTINGS").performClick()
        compose.onNodeWithText(app.getString(R.string.appearance)).performClick()
        compose.onNodeWithTag("tag_glass_effect").performScrollTo().assertIsOff().performClick()
        compose.onNodeWithTag("tag_glass_effect").assertIsOn()
        assertTrue(ThemeController.glassEffect.value)
        restoration.emulateSavedInstanceStateRestore()
        compose.onNodeWithTag("tag_glass_effect").performScrollTo().assertIsOn()
    }

    private fun assertNavigationHidden() {
        compose.onNodeWithTag("tag_navigation_floating").assertDoesNotExist()
        compose.onNodeWithTag("tag_navigation_fixed").assertDoesNotExist()
    }
}
