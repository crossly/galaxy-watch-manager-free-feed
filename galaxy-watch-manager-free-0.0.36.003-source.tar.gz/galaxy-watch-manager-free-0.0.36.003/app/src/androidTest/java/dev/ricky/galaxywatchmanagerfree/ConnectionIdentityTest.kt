package dev.ricky.galaxywatchmanagerfree

import android.content.Context
import android.content.ContextWrapper
import android.content.SharedPreferences
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import dev.ricky.galaxywatchmanagerfree.feature.DeviceIdentityStore
import dev.ricky.galaxywatchmanagerfree.feature.DeviceScope
import dev.ricky.galaxywatchmanagerfree.feature.IdentityEvent
import dev.ricky.galaxywatchmanagerfree.feature.LogBus
import dev.ricky.galaxywatchmanagerfree.feature.WatchRepository
import dev.ricky.galaxywatchmanagerfree.wcs.CompanionProfile
import dev.ricky.galaxywatchmanagerfree.wcs.DataMapEncoder
import dev.ricky.galaxywatchmanagerfree.wcs.RfcommTransport
import dev.ricky.galaxywatchmanagerfree.wcs.WcsFrame
import dev.ricky.galaxywatchmanagerfree.wcs.WcsPaths
import dev.ricky.galaxywatchmanagerfree.wcs.WcsSession
import dev.ricky.galaxywatchmanagerfree.wcs.WearDataSnapshot
import java.io.File
import java.util.UUID
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ConnectionIdentityTest {
    @Test
    fun dataItemOwnerCannotReplacePairedWatchNode() {
        val app = ApplicationProvider.getApplicationContext<Context>()
        val prefix = "dataitem_identity_${UUID.randomUUID()}_"
        val names = mutableSetOf<String>()
        val context =
            object : ContextWrapper(app) {
                override fun getSharedPreferences(name: String, mode: Int): SharedPreferences {
                    names += prefix + name
                    return super.getSharedPreferences(prefix + name, mode)
                }
            }
        val address = "02:00:00:00:00:73"
        val identity = DeviceIdentityStore(context, address)
        identity.transition(IdentityEvent.ConfirmPhoneNode("c0ffee12"))
        identity.transition(IdentityEvent.SaveWatchNode("7e57c0de"))
        val session = WcsSession(context, RfcommTransport(context), address)
        try {
            for (owner in listOf("c0ffee12", "ba5eba11")) {
                val frame =
                    WcsFrame.wearPathFrame(
                        path = "wear://$owner${WcsPaths.SET_INFO_WATCH_NAME}",
                        dataItems =
                            listOf(
                                DataMapEncoder.encode(
                                    mapOf("stringName" to "Other name", "from" to "watch")
                                )
                            ),
                        senderPkg = CompanionProfile.WATCH7.packageName,
                        nodeId = "7e57c0de",
                    )
                session.onEnvelopeReceived(frame.copyOfRange(4, frame.size))
                assertEquals("7e57c0de", session.watchNode)
            }
        } finally {
            session.close()
            names.forEach { app.deleteSharedPreferences(it) }
        }
    }

    @Test
    fun restoredPhoneOriginNameReachesWriteWithoutBecomingConfirmedState() {
        val app = ApplicationProvider.getApplicationContext<Context>()
        val prefix = "name_snapshot_${UUID.randomUUID()}_"
        val names = mutableSetOf<String>()
        val files = File(app.cacheDir, prefix).apply { check(mkdirs()) }
        val context =
            object : ContextWrapper(app) {
                override fun getFilesDir(): File = files

                override fun getSharedPreferences(name: String, mode: Int): SharedPreferences {
                    names += prefix + name
                    return super.getSharedPreferences(prefix + name, mode)
                }
            }
        val address = "02:00:00:00:00:74"
        val identity = DeviceIdentityStore(context, address)
        identity.transition(IdentityEvent.ConfirmPhoneNode("c0ffee12"))
        identity.transition(IdentityEvent.SaveWatchNode("7e57c0de"))
        context
            .getSharedPreferences("watchfree_aliases", Context.MODE_PRIVATE)
            .edit()
            .putString("watch_alias_$address", "Saved name")
            .commit()
        val uri = "wear://7e57c0de${WcsPaths.SET_INFO_WATCH_NAME}"
        val frame =
            WcsFrame.wearPathFrame(
                path = uri,
                dataItems =
                    listOf(
                        DataMapEncoder.encode(
                            mapOf(
                                "from" to "phone",
                                "key" to "stringName",
                                "stringName" to "Earlier name",
                                "type" to 3L,
                                "time" to 123L,
                            )
                        )
                    ),
                senderPkg = CompanionProfile.WATCH7.packageName,
                nodeId = "c0ffee12",
                seqId = 42L,
            )
        val snapshot = WearDataSnapshot()
        assertTrue(snapshot.accept(frame.copyOfRange(4, frame.size)))
        File(files, "wear-data-c0ffee12_7e57c0de.json").writeText(snapshot.encode())
        val session = WcsSession(context, RfcommTransport(context), address)
        val repository = WatchRepository(context, session)
        try {
            val writeLog = "→ 写入设置 $uri "
            val writesBefore = LogBus.lines.value.count { it.contains(writeLog) }
            val nodeInfo = WcsFrame.nodeInfoFrame("7e57c0de", "Synthetic watch", 123L)
            session.onEnvelopeReceived(nodeInfo.copyOfRange(4, nodeInfo.size))
            assertTrue(repository.state.value.sessionReady)
            assertEquals("Saved name", repository.state.value.watchAlias)
            assertFalse(
                repository.state.value.settingItems.containsKey(
                    WcsPaths.SET_INFO_WATCH_NAME.trimStart('/')
                )
            )
            assertEquals(writesBefore + 1, LogBus.lines.value.count { it.contains(writeLog) })
            assertTrue(LogBus.lines.value.any { it.contains(writeLog) && it.endsWith("队列失败") })
        } finally {
            repository.close()
            names.forEach { app.deleteSharedPreferences(it) }
            files.deleteRecursively()
        }
    }

    @Test
    fun pairedWatchCannotInheritAnotherWatchsGlobalAlias() {
        val app = ApplicationProvider.getApplicationContext<Context>()
        val prefix = "alias_isolation_${UUID.randomUUID()}_"
        val names = mutableSetOf<String>()
        val context =
            object : ContextWrapper(app) {
                override fun getSharedPreferences(name: String, mode: Int): SharedPreferences {
                    names += prefix + name
                    return super.getSharedPreferences(prefix + name, mode)
                }
            }
        val firstAddress = "02:00:00:00:00:75"
        val secondAddress = "02:00:00:00:00:76"
        context
            .getSharedPreferences("watchfree_aliases", Context.MODE_PRIVATE)
            .edit()
            .putString("watch_alias_last", "First synthetic watch")
            .putString("watch_alias_$firstAddress", "First synthetic watch")
            .commit()
        val first =
            WatchRepository(context, WcsSession(context, RfcommTransport(context), firstAddress))
        val second =
            WatchRepository(context, WcsSession(context, RfcommTransport(context), secondAddress))
        try {
            assertEquals("First synthetic watch", first.state.value.watchAlias)
            assertEquals("", second.state.value.watchAlias)
            assertNull(first.notificationSession)
            assertNull(second.notificationSession)
        } finally {
            first.close()
            second.close()
            names.forEach { app.deleteSharedPreferences(it) }
        }
    }

    @Test
    fun candidateIsVolatileDeviceScopedAndCannotReplaceConfirmedUntilVerified() {
        val app = ApplicationProvider.getApplicationContext<Context>()
        val prefix = "identity_${UUID.randomUUID()}_"
        val names = mutableSetOf<String>()
        val context =
            object : ContextWrapper(app) {
                override fun getSharedPreferences(name: String, mode: Int): SharedPreferences {
                    names += prefix + name
                    return super.getSharedPreferences(prefix + name, mode)
                }
            }
        val firstMac = "02:00:00:00:00:01"
        val secondMac = "02:00:00:00:00:02"
        val first = DeviceIdentityStore(context, firstMac)
        val second = DeviceIdentityStore(context, secondMac)
        try {
            first.transition(IdentityEvent.ConfirmPhoneNode("abcdef12"))
            assertTrue(first.transition(IdentityEvent.StageCandidatePhoneNode("12345678")))
            assertEquals(DeviceIdentityStore.IdentityPhase.CANDIDATE, first.phase)
            assertEquals("abcdef12", first.confirmedPhoneNode)
            assertEquals("12345678", first.effectivePhoneNode)
            assertEquals("", second.candidatePhoneNode)
            val disk =
                context.getSharedPreferences(
                    DeviceScope.preferences(DeviceIdentityStore.PREFS_BASE, firstMac),
                    0,
                )
            assertEquals("abcdef12", disk.getString("phone_node", ""))
            assertFalse(disk.contains("candidate_phone_node"))
            first.transition(IdentityEvent.ClearCandidatePhoneNode)
            assertEquals("abcdef12", first.effectivePhoneNode)
            assertTrue(first.transition(IdentityEvent.StageCandidatePhoneNode("87654321")))
            assertEquals("abcdef12", first.confirmedPhoneNode)
            assertFalse(first.transition(IdentityEvent.StageCandidatePhoneNode("abcdef123456")))
            assertEquals("87654321", first.candidatePhoneNode)
            first.transition(IdentityEvent.ConfirmPhoneNode("87654321"))
            assertEquals("87654321", first.confirmedPhoneNode)
            assertEquals("", first.candidatePhoneNode)
            assertEquals("", second.confirmedPhoneNode)
        } finally {
            first.transition(IdentityEvent.ClearCandidatePhoneNode)
            second.transition(IdentityEvent.ClearCandidatePhoneNode)
            names.forEach { app.deleteSharedPreferences(it) }
        }
    }
}
