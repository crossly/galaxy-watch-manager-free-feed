package dev.ricky.galaxywatchmanagerfree

import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.res.Configuration
import android.os.LocaleList
import android.provider.Settings
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.test.assertIsOn
import androidx.compose.ui.test.assertTextContains
import androidx.compose.ui.test.hasScrollToIndexAction
import androidx.compose.ui.test.hasText
import androidx.compose.ui.test.isToggleable
import androidx.compose.ui.test.junit4.StateRestorationTester
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performTextInput
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.test.core.app.ApplicationProvider
import dev.ricky.galaxywatchmanagerfree.feature.NotificationFilterConfig
import dev.ricky.galaxywatchmanagerfree.feature.NotificationFilterMode
import dev.ricky.galaxywatchmanagerfree.feature.NotificationFilterPreferences
import dev.ricky.galaxywatchmanagerfree.ui.screens.NotificationAppFilterScreen
import dev.ricky.galaxywatchmanagerfree.ui.screens.PermissionsSettingsScreen
import dev.ricky.galaxywatchmanagerfree.ui.theme.WatchFreeTheme
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Rule
import org.junit.Test

class NotificationSettingsUiTest {
    @get:Rule val compose = createComposeRule()
    private val app = ApplicationProvider.getApplicationContext<Context>()
    private val syntheticPackage = "example.synthetic.notificationtest"
    private var original = NotificationFilterConfig()

    @Before
    fun saveFilter() {
        NotificationFilterPreferences.init(app)
        original = NotificationFilterPreferences.config.value
    }

    @After
    fun restoreFilter() {
        NotificationFilterPreferences.config.value.packages.forEach {
            NotificationFilterPreferences.setSelected(it, false)
        }
        original.packages.forEach { NotificationFilterPreferences.setSelected(it, true) }
        NotificationFilterPreferences.setMode(original.mode)
    }

    @Test
    fun englishDarkFilterSupportsSearchEmptySelectionAndRestoration() {
        checkFilter("en", dark = true)
    }

    @Test
    fun chineseLightFilterSupportsSearchEmptySelectionAndRestoration() {
        checkFilter("zh-CN", dark = false)
    }

    private fun checkFilter(locale: String, dark: Boolean) {
        original.packages.forEach { NotificationFilterPreferences.setSelected(it, false) }
        NotificationFilterPreferences.setSelected(syntheticPackage, true)
        NotificationFilterPreferences.setMode(NotificationFilterMode.SELECTED)
        val localized = localizedContext(locale)
        val restoration = StateRestorationTester(compose)
        restoration.setContent { NarrowTheme(localized, dark) { NotificationAppFilterScreen() } }
        val search = localized.getString(R.string.notification_filter_search)
        scrollToText(search).performTextInput(syntheticPackage)
        val appRow = hasText(syntheticPackage) and isToggleable()
        fun awaitApp() {
            compose.waitUntil(10_000) {
                try {
                    compose.onNode(hasScrollToIndexAction()).performScrollToNode(appRow)
                    true
                } catch (_: AssertionError) {
                    false
                }
            }
        }
        awaitApp()
        compose.onNode(appRow).assertIsOn()
        restoration.emulateSavedInstanceStateRestore()
        scrollToText(search).assertTextContains(syntheticPackage)
        awaitApp()
        compose.onNode(appRow).assertIsOn().performClick()
        scrollToText(localized.getString(R.string.notification_filter_none)).assertExists()
        compose.runOnIdle {
            val config = NotificationFilterPreferences.config.value
            assertEquals(NotificationFilterMode.SELECTED, config.mode)
            assertFalse(config.allows(syntheticPackage))
            assertFalse(config.allows("example.synthetic.other"))
            val saved =
                app.getSharedPreferences("watchfree_notification_filter", Context.MODE_PRIVATE)
            assertEquals("SELECTED", saved.getString("mode", null))
            assertTrue(saved.getStringSet("packages", null).orEmpty().isEmpty())
        }
        scrollToText(localized.getString(R.string.notification_filter_selected_only)).performClick()
        compose.runOnIdle {
            assertTrue(NotificationFilterPreferences.config.value.allows("example.synthetic.other"))
        }
    }

    private fun scrollToText(text: String): androidx.compose.ui.test.SemanticsNodeInteraction {
        compose.onNode(hasScrollToIndexAction()).performScrollToNode(hasText(text))
        return compose.onNodeWithText(text)
    }

    @Test
    fun englishLightPermissionsRemainScrollableAndOpenInstallSettings() {
        checkPermissions("en", dark = false)
    }

    @Test
    fun chineseDarkPermissionsRemainScrollableAndOpenInstallSettings() {
        checkPermissions("zh-CN", dark = true)
    }

    private fun checkPermissions(locale: String, dark: Boolean) {
        val launched = mutableListOf<Intent>()
        val localized = localizedContext(locale)
        val recording =
            object : ContextWrapper(localized) {
                override fun startActivity(intent: Intent) {
                    launched += intent
                }
            }
        compose.setContent { NarrowTheme(recording, dark) { PermissionsSettingsScreen() } }
        scrollToText(localized.getString(R.string.permissions_install)).performClick()
        compose.runOnIdle {
            assertEquals(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, launched.single().action)
            assertEquals("package:${app.packageName}", launched.single().dataString)
        }
        scrollToText(localized.getString(R.string.open_autostart_settings)).assertExists()
    }

    private fun localizedContext(locale: String): Context =
        app.createConfigurationContext(
            Configuration(app.resources.configuration).apply {
                setLocales(LocaleList.forLanguageTags(locale))
            }
        )

    @androidx.compose.runtime.Composable
    private fun NarrowTheme(
        context: Context,
        dark: Boolean,
        content: @androidx.compose.runtime.Composable () -> Unit,
    ) {
        val density = LocalDensity.current.density
        val activityResults =
            requireNotNull(androidx.activity.compose.LocalActivityResultRegistryOwner.current)
        CompositionLocalProvider(
            androidx.activity.compose.LocalActivityResultRegistryOwner provides activityResults,
            LocalContext provides context,
            LocalConfiguration provides context.resources.configuration,
            LocalDensity provides Density(density, 2f),
        ) {
            WatchFreeTheme(darkTheme = dark) { Box(Modifier.width(320.dp)) { content() } }
        }
    }
}
