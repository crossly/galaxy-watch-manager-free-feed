package dev.ricky.galaxywatchmanagerfree

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import dev.ricky.galaxywatchmanagerfree.feature.LayoutPage
import dev.ricky.galaxywatchmanagerfree.feature.PageBlock
import dev.ricky.galaxywatchmanagerfree.ui.PageLayoutController
import dev.ricky.galaxywatchmanagerfree.ui.components.EditableBlockGrid
import dev.ricky.galaxywatchmanagerfree.ui.components.GroupedCard
import dev.ricky.galaxywatchmanagerfree.ui.theme.WatchFreeTheme
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Rule
import org.junit.Test

class BlockEditingTest {
    @get:Rule val compose = createComposeRule()

    @Before
    fun reset() {
        LayoutPage.entries.forEach(PageLayoutController::reset)
    }

    @After
    fun cleanup() {
        LayoutPage.entries.forEach(PageLayoutController::reset)
    }

    @Test
    fun longPressDragsTheActualCardAndPersistsItsNewPosition() {
        compose.setContent {
            WatchFreeTheme {
                EditableBlockGrid(LayoutPage.OVERVIEW, editing = true) { placement ->
                    GroupedCard {
                        Text(stringResource(placement.block.labelRes))
                        Spacer(Modifier.height(60.dp))
                    }
                }
            }
        }
        val source = compose.onNodeWithTag("block_CONNECTION")
        val from = source.fetchSemanticsNode().boundsInRoot.center
        val to = compose.onNodeWithTag("block_BATTERY").fetchSemanticsNode().boundsInRoot.center
        source.performTouchInput {
            val origin = center
            down(origin)
            moveBy(Offset.Zero, delayMillis = 700)
            for (step in 1..16) moveTo(origin + (to - from) * (step / 16f), delayMillis = 32)
            moveBy(Offset.Zero, delayMillis = 100)
            up()
        }
        compose.waitForIdle()
        assertEquals(
            PageBlock.BATTERY,
            PageLayoutController.layouts.value.getValue(LayoutPage.OVERVIEW).first().block,
        )
    }

    @Test
    fun compactCardsCanBeDraggedAcrossColumns() {
        compose.setContent {
            WatchFreeTheme {
                EditableBlockGrid(LayoutPage.HEALTH, editing = true) { placement ->
                    GroupedCard {
                        Text(stringResource(placement.block.labelRes))
                        Spacer(Modifier.height(40.dp))
                    }
                }
            }
        }
        val source = compose.onNodeWithTag("block_HEART_RATE")
        val from = source.fetchSemanticsNode().boundsInRoot.center
        val to = compose.onNodeWithTag("block_STRESS").fetchSemanticsNode().boundsInRoot.center
        source.performTouchInput {
            val origin = center
            down(origin)
            moveBy(Offset.Zero, delayMillis = 700)
            for (step in 1..16) moveTo(origin + (to - from) * (step / 16f), delayMillis = 32)
            up()
        }
        compose.waitForIdle()
        val order = PageLayoutController.layouts.value.getValue(LayoutPage.HEALTH).map { it.block }
        assertTrue(order.indexOf(PageBlock.STRESS) < order.indexOf(PageBlock.HEART_RATE))
    }

    @Test
    fun windowAndFontChangesReflowCardsWithoutChangingSavedPreferences() {
        PageLayoutController.change(LayoutPage.HEALTH, PageBlock.ECG, wide = true)
        PageLayoutController.change(LayoutPage.HEALTH, PageBlock.BP, visible = false)
        val saved = PageLayoutController.layouts.value.getValue(LayoutPage.HEALTH)
        val width = mutableStateOf(360.dp)
        val scale = mutableStateOf(1f)
        val editing = mutableStateOf(false)
        compose.setContent {
            val density = LocalDensity.current.density
            CompositionLocalProvider(LocalDensity provides Density(density, scale.value)) {
                WatchFreeTheme {
                    Box(Modifier.width(width.value)) {
                        EditableBlockGrid(
                            LayoutPage.HEALTH,
                            editing = editing.value,
                            unavailableBlocks =
                                PageBlock.entries.toSet() -
                                    setOf(
                                        PageBlock.HEART_RATE,
                                        PageBlock.STRESS,
                                        PageBlock.ECG,
                                        PageBlock.BP,
                                    ),
                        ) { placement ->
                            GroupedCard { Text(placement.block.name) }
                        }
                    }
                }
            }
        }
        val heart = compose.onNodeWithTag("block_HEART_RATE")
        val stress = compose.onNodeWithTag("block_STRESS")
        assertTrue(
            heart.fetchSemanticsNode().boundsInRoot.right <=
                stress.fetchSemanticsNode().boundsInRoot.left
        )
        compose.runOnIdle {
            width.value = 320.dp
            scale.value = 2f
            editing.value = true
        }
        assertTrue(
            heart.fetchSemanticsNode().boundsInRoot.bottom <=
                stress.fetchSemanticsNode().boundsInRoot.top
        )
        compose.onNodeWithTag("block_ECG").assertIsDisplayed()
        compose.onNodeWithTag("block_BP").assertDoesNotExist()
        compose.runOnIdle {
            assertEquals(saved, PageLayoutController.layouts.value.getValue(LayoutPage.HEALTH))
            width.value = 360.dp
            scale.value = 1f
            editing.value = false
        }
        assertTrue(
            heart.fetchSemanticsNode().boundsInRoot.right <=
                stress.fetchSemanticsNode().boundsInRoot.left
        )
        assertEquals(saved, PageLayoutController.layouts.value.getValue(LayoutPage.HEALTH))
    }

    @Test
    fun editingBlocksBusinessClicksAndMinusCanBeAddedBack() {
        var businessClicks = 0
        compose.setContent {
            WatchFreeTheme {
                EditableBlockGrid(LayoutPage.OVERVIEW, editing = true) {
                    GroupedCard {
                        Button(onClick = { businessClicks++ }) { Text("business") }
                        Spacer(Modifier.height(30.dp))
                    }
                }
            }
        }
        compose.onNodeWithTag("block_CONNECTION").performClick()
        assertEquals(0, businessClicks)
        compose.onNodeWithContentDescription("Remove Device connection").performClick()
        assertFalse(
            PageLayoutController.layouts.value
                .getValue(LayoutPage.OVERVIEW)
                .first { it.block == PageBlock.CONNECTION }
                .visible
        )
        compose.onNodeWithTag("block_grid").performScrollToNode(hasText("Device connection"))
        compose.onNodeWithText("Device connection").performClick()
        assertTrue(PageLayoutController.layouts.value.getValue(LayoutPage.OVERVIEW).last().visible)
        assertEquals(
            PageBlock.CONNECTION,
            PageLayoutController.layouts.value.getValue(LayoutPage.OVERVIEW).last().block,
        )
    }
}
