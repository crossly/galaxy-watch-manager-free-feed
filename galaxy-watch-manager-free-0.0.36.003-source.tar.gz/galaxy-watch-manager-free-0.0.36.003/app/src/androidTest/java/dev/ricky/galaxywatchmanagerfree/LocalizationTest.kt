package dev.ricky.galaxywatchmanagerfree

import android.content.Context
import android.content.res.Configuration
import android.os.LocaleList
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import dev.ricky.galaxywatchmanagerfree.core.uiText
import dev.ricky.galaxywatchmanagerfree.feature.SettingLabels
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class LocalizationTest {
    private fun context(tag: String): Context {
        val app = ApplicationProvider.getApplicationContext<Context>()
        val configuration = Configuration(app.resources.configuration)
        configuration.setLocales(LocaleList.forLanguageTags(tag))
        return app.createConfigurationContext(configuration)
    }

    @Test
    fun selectedLanguageResolvesLabelsAndExistingStateWithoutFrozenTranslations() {
        val en = context("en").resources
        val zh = context("zh-CN").resources
        val message = uiText(R.string.update_available, "0.0.10")
        assertEquals("Version 0.0.10 is available", message.resolve(en))
        assertEquals("发现新版本 0.0.10", message.resolve(zh))
        assertEquals("Overview", en.getString(R.string.overview))
        assertEquals("概览", zh.getString(R.string.overview))
        val enLabels = SettingLabels(en.configuration.locales[0]) { en.getString(it) }
        val zhLabels = SettingLabels(zh.configuration.locales[0]) { zh.getString(it) }
        val path = "/w_module_sec_watch_setting/display/screen_time_out/selected_item"
        assertEquals("Screen timeout · Current option", enLabels.describe(path).title)
        assertEquals("屏幕关闭时间 · 当前选项", zhLabels.describe(path).title)
    }

    @Test
    fun englishAndChineseSelectTheCorrectPluralForms() {
        val en = context("en").resources
        val zh = context("zh-CN").resources
        assertEquals("1 floor", en.getQuantityString(R.plurals.floors_count, 1, 1))
        assertEquals("2 floors", en.getQuantityString(R.plurals.floors_count, 2, 2))
        assertEquals("1 层", zh.getQuantityString(R.plurals.floors_count, 1, 1))
        assertEquals("2 层", zh.getQuantityString(R.plurals.floors_count, 2, 2))
    }

    @Test
    fun everyShippedStringFormatsUsingAndroidResourcesInBothLanguages() {
        val format = Regex("%%|%(?:(\\d+)\\$)?[-#+ 0,(]*\\d*(?:\\.\\d+)?([sdfoxXeEgGcCbBhH])")
        for (tag in listOf("en", "zh-CN")) {
            val resources = context(tag).resources
            for (field in R.string::class.java.fields) {
                val id = field.getInt(null)
                val value = resources.getString(id)
                val conversions = format.findAll(value).filter { it.value != "%%" }.toList()
                if (conversions.isEmpty()) continue
                val count = conversions.maxOf { it.groupValues[1].toInt() }
                val arguments = Array<Any>(count) { "sample" }
                for (conversion in conversions) {
                    arguments[conversion.groupValues[1].toInt() - 1] =
                        when (conversion.groupValues[2].lowercase()) {
                            "d",
                            "o",
                            "x" -> 3
                            "f",
                            "e",
                            "g" -> 3.5
                            "c" -> 'A'
                            else -> "sample"
                        }
                }
                try {
                    resources.getString(id, *arguments)
                } catch (error: Exception) {
                    throw AssertionError("$tag/${field.name} cannot be formatted", error)
                }
            }
        }
    }
}
