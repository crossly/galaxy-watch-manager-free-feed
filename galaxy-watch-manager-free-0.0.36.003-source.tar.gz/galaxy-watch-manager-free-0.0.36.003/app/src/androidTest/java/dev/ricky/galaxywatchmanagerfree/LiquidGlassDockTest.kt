package dev.ricky.galaxywatchmanagerfree

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toPixelMap
import androidx.compose.ui.test.assertIsSelected
import androidx.compose.ui.test.captureToImage
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performTouchInput
import androidx.compose.ui.unit.dp
import dev.ricky.galaxywatchmanagerfree.ui.HomeTab
import dev.ricky.galaxywatchmanagerfree.ui.components.FloatingNavigationBar
import dev.ricky.galaxywatchmanagerfree.ui.components.liquidGlassSource
import dev.ricky.galaxywatchmanagerfree.ui.components.rememberLiquidGlassBackdrop
import dev.ricky.galaxywatchmanagerfree.ui.theme.WatchFreeTheme
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test

class LiquidGlassDockTest {
    @get:Rule val compose = createComposeRule()
    private var current by mutableStateOf(HomeTab.DASHBOARD)
    private var background by mutableStateOf(Color.Red)
    private val selections = mutableListOf<HomeTab>()

    private fun showDock(glass: Boolean = true) {
        compose.setContent {
            WatchFreeTheme {
                val backdrop = rememberLiquidGlassBackdrop()
                Box(Modifier.fillMaxSize()) {
                    Box(Modifier.fillMaxSize().liquidGlassSource(backdrop).background(background))
                    FloatingNavigationBar(
                        currentTab = current,
                        onTabSelected = {
                            current = it
                            selections += it
                        },
                        navigationHeight = 62.dp,
                        bottomInset = 24.dp,
                        glassEffect = glass,
                        backdrop = backdrop,
                        modifier = Modifier.align(Alignment.BottomCenter),
                    )
                }
            }
        }
    }

    @Test
    fun heldFingerCanCrossAllTabsAndCommitsOnlyOnRelease() {
        showDock()
        val dock = compose.onNodeWithTag("tag_navigation_floating")
        dock.performTouchInput { down(Offset(width * 0.125f, height / 2f)) }
        val dockBounds = dock.fetchSemanticsNode().boundsInRoot
        val lensBounds =
            compose.onNodeWithTag("tag_navigation_lens").fetchSemanticsNode().boundsInRoot
        assertTrue("The lifted lens keeps a top margin", lensBounds.top > dockBounds.top)
        assertTrue("The lifted lens keeps a bottom margin", lensBounds.bottom < dockBounds.bottom)
        for (fraction in listOf(0.375f, 0.625f, 0.875f)) {
            dock.performTouchInput { moveTo(Offset(width * fraction, height / 2f), 200) }
            compose.onNodeWithTag("tag_nav_DASHBOARD").assertIsSelected()
            compose.runOnIdle { assertTrue(selections.isEmpty()) }
        }
        dock.performTouchInput {
            advanceEventTime(150)
            up()
        }
        compose.onNodeWithTag("tag_nav_SETTINGS").assertIsSelected()
        compose.runOnIdle { assertEquals(listOf(HomeTab.SETTINGS), selections) }
    }

    @Test
    fun cancellationRestoresSelectionAndAccessibilityClickStillWorks() {
        showDock()
        val dock = compose.onNodeWithTag("tag_navigation_floating")
        dock.performTouchInput {
            down(Offset(width * 0.125f, height / 2f))
            moveTo(Offset(width * 0.875f, height / 2f), 400)
            cancel()
        }
        compose.onNodeWithTag("tag_nav_DASHBOARD").assertIsSelected()
        compose.runOnIdle { assertTrue(selections.isEmpty()) }
        compose.onNodeWithTag("tag_nav_HEALTH").performClick().assertIsSelected()
        compose.runOnIdle { assertEquals(listOf(HomeTab.HEALTH), selections) }
    }

    @Test
    fun glassReadsLivePageInsteadOfAnOpaqueSurfaceOrFrozenCapture() {
        showDock()
        val dock = compose.onNodeWithTag("tag_navigation_floating")
        val red = dock.captureToImage().toPixelMap()
        compose.runOnIdle { background = Color.Blue }
        compose.waitForIdle()
        val blue = dock.captureToImage().toPixelMap()
        // Between destinations, away from icons, labels, selection and the optical rim.
        val x = (red.width * 0.5f).toInt()
        val y = (red.height * 0.45f).toInt()
        assertTrue(
            "Red page must remain visible through the glass",
            red[x, y].red > blue[x, y].red + 0.08f,
        )
        assertTrue("A changed page must update the glass", blue[x, y].blue > red[x, y].blue + 0.08f)
    }

    @Test
    fun plainFloatingNavigationSharesDragBehavior() {
        showDock(glass = false)
        compose.onNodeWithTag("tag_navigation_floating").performTouchInput {
            down(Offset(width * 0.125f, height / 2f))
            moveTo(Offset(width * 0.625f, height / 2f), 400)
            advanceEventTime(150)
            up()
        }
        compose.onNodeWithTag("tag_nav_HEALTH").assertIsSelected()
        compose.runOnIdle { assertEquals(listOf(HomeTab.HEALTH), selections) }
    }
}
