package dev.ricky.galaxywatchmanagerfree

import android.content.Context
import android.content.ContextWrapper
import android.content.SharedPreferences
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import dev.ricky.galaxywatchmanagerfree.feature.LocalSleepAnalyzer
import java.util.UUID
import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class LocalSleepAnalyzerRetryTest {
    @Test
    fun failedUnchangedSensorInputIsNotRescheduledButCorrectedInputCanRetry() {
        val app = ApplicationProvider.getApplicationContext<Context>()
        val prefix = "sleep_retry_${UUID.randomUUID()}_"
        val names = mutableSetOf<String>()
        val context =
            object : ContextWrapper(app) {
                override fun getSharedPreferences(name: String, mode: Int): SharedPreferences {
                    val scoped = prefix + name
                    names += scoped
                    return super.getSharedPreferences(scoped, mode)
                }
            }
        try {
            val analyzer = LocalSleepAnalyzer(context, "02:00:00:00:00:73")
            val now = System.currentTimeMillis()
            val record =
                JSONObject()
                    .put("datauuid", "sleep")
                    .put("start_time", now - 3_600_000L)
                    .put("end_time", now)
            val sensor = JSONObject().put("sleep_uuid", "sleep").put("data", "")
            assertTrue(analyzer.needsAnalysis(record, sensor))
            assertNull(analyzer.analyze(record, sensor))
            repeat(12) { assertFalse(analyzer.needsAnalysis(record, sensor)) }
            assertTrue(
                analyzer.needsAnalysis(
                    record,
                    JSONObject(sensor.toString()).put("data", "corrected"),
                )
            )
        } finally {
            names.forEach { app.deleteSharedPreferences(it) }
        }
    }
}
