package dev.ricky.galaxywatchmanagerfree

import android.content.Context
import android.content.ContextWrapper
import android.content.SharedPreferences
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import dev.ricky.galaxywatchmanagerfree.feature.HealthPacket
import dev.ricky.galaxywatchmanagerfree.feature.HealthRepository
import dev.ricky.galaxywatchmanagerfree.feature.HeartRateLog
import dev.ricky.galaxywatchmanagerfree.feature.WatchState
import dev.ricky.galaxywatchmanagerfree.wcs.RfcommTransport
import dev.ricky.galaxywatchmanagerfree.wcs.WcsPaths
import dev.ricky.galaxywatchmanagerfree.wcs.WcsSession
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class HealthPersistenceConcurrencyTest {
    @Test
    fun overlappingSyncPacketsBothSurviveRestartWhenTheFirstDiskWriteIsSlow() {
        val app = ApplicationProvider.getApplicationContext<Context>()
        val prefix = "health_race_${UUID.randomUUID()}_"
        val names = ConcurrentHashMap.newKeySet<String>()
        val armed = AtomicBoolean(false)
        val commits = AtomicInteger()
        val firstWrite = CountDownLatch(1)
        val releaseFirstWrite = CountDownLatch(1)
        val secondFinished = CountDownLatch(1)
        val context =
            object : ContextWrapper(app) {
                override fun getSharedPreferences(name: String, mode: Int): SharedPreferences {
                    val scoped = prefix + name
                    names += scoped
                    val prefs = super.getSharedPreferences(scoped, mode)
                    if (!name.startsWith("watchfree_health")) return prefs
                    return object : SharedPreferences by prefs {
                        override fun edit(): SharedPreferences.Editor {
                            val editor = prefs.edit()
                            return object : SharedPreferences.Editor by editor {
                                override fun putString(key: String, value: String?) = apply {
                                    editor.putString(key, value)
                                }

                                override fun putStringSet(key: String, value: Set<String>?) =
                                    apply {
                                        editor.putStringSet(key, value)
                                    }

                                override fun putInt(key: String, value: Int) = apply {
                                    editor.putInt(key, value)
                                }

                                override fun putLong(key: String, value: Long) = apply {
                                    editor.putLong(key, value)
                                }

                                override fun putFloat(key: String, value: Float) = apply {
                                    editor.putFloat(key, value)
                                }

                                override fun putBoolean(key: String, value: Boolean) = apply {
                                    editor.putBoolean(key, value)
                                }

                                override fun remove(key: String) = apply { editor.remove(key) }

                                override fun clear() = apply { editor.clear() }

                                override fun commit(): Boolean {
                                    if (armed.get() && commits.incrementAndGet() == 1) {
                                        firstWrite.countDown()
                                        check(releaseFirstWrite.await(5, TimeUnit.SECONDS))
                                    }
                                    return editor.commit()
                                }
                            }
                        }
                    }
                }
            }
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        val executor = Executors.newFixedThreadPool(2)
        fun repository(state: MutableStateFlow<WatchState>): HealthRepository =
            HealthRepository(
                context,
                WcsSession(context, RfcommTransport(context), "02:00:00:00:00:71"),
                scope,
                state,
                isActive = { true },
                onMeasurementPreferences = {},
            )
        try {
            val state = MutableStateFlow(WatchState())
            val repo = repository(state)
            repo.restore()
            val now = System.currentTimeMillis()
            armed.set(true)
            val first =
                executor.submit {
                    repo.handleMessage(
                        packet("first", now - 120_000, 60),
                        HealthPacket.Direction.FROM_WATCH,
                    )
                }
            assertTrue(firstWrite.await(5, TimeUnit.SECONDS))
            val second =
                executor.submit {
                    try {
                        repo.handleMessage(
                            packet("second", now - 60_000, 90),
                            HealthPacket.Direction.FROM_WATCH,
                        )
                    } finally {
                        secondFinished.countDown()
                    }
                }
            // Without serialized ingestion, the second packet writes a newer cache before
            // the blocked first commit overwrites it with the older snapshot.
            secondFinished.await(1, TimeUnit.SECONDS)
            releaseFirstWrite.countDown()
            first.get(5, TimeUnit.SECONDS)
            second.get(5, TimeUnit.SECONDS)
            armed.set(false)
            val restored = MutableStateFlow(WatchState())
            repository(restored).restore()
            assertEquals(
                listOf(60, 90),
                restored.value.heartRateHistory.values.flatten().sortedBy { it.ts }.map { it.bpm },
            )
        } finally {
            releaseFirstWrite.countDown()
            executor.shutdownNow()
            scope.cancel()
            names.forEach { app.deleteSharedPreferences(it) }
        }
    }

    private fun packet(id: String, timestamp: Long, bpm: Int): JSONObject {
        val payload =
            JSONArray()
                .put(
                    JSONObject()
                        .put(
                            "message_info",
                            JSONArray()
                                .put(JSONObject().put("action", WcsPaths.HEALTH_ACTION_SYNC_DATA)),
                        )
                )
                .put(
                    JSONObject()
                        .put(
                            HeartRateLog.MODULE,
                            JSONArray()
                                .put(
                                    JSONObject()
                                        .put("datauuid", id)
                                        .put("start_time", timestamp)
                                        .put("heart_rate", bpm)
                                ),
                        )
                )
        return JSONObject()
            .put("message", WcsPaths.HEALTH_MSG_REQUEST)
            .put("body", HealthRepository.encodeHealthBody(payload.toString()))
    }
}
