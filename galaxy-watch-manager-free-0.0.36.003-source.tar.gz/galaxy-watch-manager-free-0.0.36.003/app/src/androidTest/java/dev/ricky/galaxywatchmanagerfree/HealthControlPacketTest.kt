package dev.ricky.galaxywatchmanagerfree

import android.content.Context
import android.content.ContextWrapper
import android.content.SharedPreferences
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import dev.ricky.galaxywatchmanagerfree.feature.HealthCapability
import dev.ricky.galaxywatchmanagerfree.feature.HealthPacket
import dev.ricky.galaxywatchmanagerfree.feature.HealthRepository
import dev.ricky.galaxywatchmanagerfree.feature.HealthStepParser
import dev.ricky.galaxywatchmanagerfree.feature.LogBus
import dev.ricky.galaxywatchmanagerfree.feature.WatchState
import dev.ricky.galaxywatchmanagerfree.wcs.RfcommTransport
import dev.ricky.galaxywatchmanagerfree.wcs.WcsPaths
import dev.ricky.galaxywatchmanagerfree.wcs.WcsSession
import java.util.UUID
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class HealthControlPacketTest {
    @Test
    fun controlResponsesAndCompletionDoNotCreateOrRewriteTheHealthArchive() =
        withRepository { repo, prefs, state ->
            repeat(12) {
                repo.handleMessage(
                    packet("REQUEST_DATA", response = true),
                    HealthPacket.Direction.FROM_WATCH,
                )
                repo.handleMessage(packet("LOG_DATA"), HealthPacket.Direction.FROM_WATCH)
            }
            assertFalse(prefs().contains("health_records"))
            assertEquals(0L, state.value.lastHealthSyncTime)
            assertEquals("LOG_DATA", repo.packets.value.last().action)
        }

    @Test
    fun explicitlyEmptyRecordTableStillPersistsAsRealSyncData() =
        withRepository { repo, prefs, state ->
            val body =
                JSONArray()
                    .put(
                        JSONObject()
                            .put(
                                "message_info",
                                JSONArray().put(JSONObject().put("action", "SYNC_DATA")),
                            )
                    )
                    .put(JSONObject().put(HealthStepParser.MODULE_STEP_COUNT, JSONArray()))
            val packet =
                JSONObject()
                    .put("message", WcsPaths.HEALTH_MSG_REQUEST)
                    .put("body", HealthRepository.encodeHealthBody(body.toString()))
            repo.handleMessage(packet, HealthPacket.Direction.FROM_WATCH)
            assertTrue(prefs().contains("health_records"))
            assertTrue(state.value.lastHealthSyncTime > 0L)
        }

    @Test
    fun malformedHealthPacketsKeepTheirContentsOutOfRuntimeErrors() =
        withRepository { repo, prefs, _ ->
            val marker = "synthetic-private-health-row"
            val malformed = "{\"datauuid\":\"$marker\",\"measurement\":73.125,"
            repo.handleMessage(
                JSONObject()
                    .put("sequence_num", 731)
                    .put("message", WcsPaths.HEALTH_MSG_REQUEST)
                    .put("body", HealthRepository.encodeHealthBody(malformed)),
                HealthPacket.Direction.FROM_WATCH,
            )
            val error = LogBus.lines.value.last { it.contains("数据包解码失败") }
            assertTrue(error.contains("category=JSONException"))
            assertTrue(error.contains("seq=731"))
            assertFalse(error.contains(marker))
            assertFalse(error.contains("measurement"))
            assertFalse(error.contains("73.125"))
            assertFalse(prefs().contains("health_records"))
        }

    @Test
    fun vascularCapabilitySurvivesRestoreAndAnUnsupportedResponseHidesIt() =
        withRepository { repo, prefs, state ->
            fun capability(supported: Boolean) =
                JSONObject()
                    .put("capability_type", HealthCapability.RESPONSE_CAPABILITY)
                    .put("category", 40001)
                    .put(
                        "tracker_feature",
                        JSONObject()
                            .put(
                                "vascular_load_feature",
                                JSONObject()
                                    .put("version", 1001)
                                    .put("vascular_load_support", supported),
                            ),
                    )
            assertFalse(state.value.vascularLoadSupported)
            assertTrue(repo.handleCapability(capability(true)))
            assertTrue(state.value.vascularLoadSupported)
            assertTrue(prefs().getBoolean("vascular_load_supported", false))
            state.value = WatchState()
            repo.restore()
            assertTrue(state.value.vascularLoadSupported)
            repo.handleCapability(capability(false))
            assertFalse(state.value.vascularLoadSupported)
            state.value = WatchState(vascularLoadSupported = true)
            repo.restore()
            assertFalse(state.value.vascularLoadSupported)
        }

    @Test
    fun vascularSyncRecordsReachTheStateAndSurviveRestoreWithoutImplyingSupport() =
        withRepository { repo, _, state ->
            val module = dev.ricky.galaxywatchmanagerfree.feature.VascularLoadLog.MODULE
            val now = System.currentTimeMillis()
            fun row(id: String, time: Long, type: Int, value: Float) =
                JSONObject()
                    .put("datauuid", id)
                    .put("start_time", time)
                    .put("end_time", time)
                    .put("type", type)
                    .put("measurement", value)
            val body =
                JSONArray()
                    .put(
                        JSONObject()
                            .put(
                                "message_info",
                                JSONArray().put(JSONObject().put("action", "SYNC_DATA")),
                            )
                    )
                    .put(
                        JSONObject()
                            .put(
                                module,
                                JSONArray()
                                    .put(row("synthetic-baseline", now - 86_400_000, 2, 93.333336f))
                                    .put(row("synthetic-measurement", now - 60_000, 3, -8f)),
                            )
                    )
            repo.handleMessage(
                JSONObject()
                    .put("message", WcsPaths.HEALTH_MSG_REQUEST)
                    .put("body", HealthRepository.encodeHealthBody(body.toString())),
                HealthPacket.Direction.FROM_WATCH,
            )
            assertEquals(
                dev.ricky.galaxywatchmanagerfree.feature.VascularLoadLog.Band.HIGHER,
                state.value.vascularLoad.latest?.band,
            )
            assertFalse(state.value.vascularLoadSupported)
            state.value = WatchState()
            repo.restore()
            assertTrue(state.value.vascularLoad.baselineComplete)
            assertEquals(2, state.value.vascularLoad.records.size)
            assertEquals(-8f, state.value.vascularLoad.latest!!.measurement!!, 0.001f)
            assertFalse(state.value.vascularLoadSupported)
        }

    private fun packet(action: String, response: Boolean = false): JSONObject =
        JSONObject()
            .put(
                "message",
                if (response) WcsPaths.HEALTH_MSG_RESPONSE else WcsPaths.HEALTH_MSG_REQUEST,
            )
            .put(
                "body",
                HealthRepository.encodeHealthBody(
                    JSONArray()
                        .put(
                            JSONObject()
                                .put(
                                    "message_info",
                                    JSONArray().put(JSONObject().put("action", action)),
                                )
                        )
                        .toString()
                ),
            )

    private fun withRepository(
        test: (HealthRepository, () -> SharedPreferences, MutableStateFlow<WatchState>) -> Unit
    ) {
        val app = ApplicationProvider.getApplicationContext<Context>()
        val prefix = "health_control_${UUID.randomUUID()}_"
        val names = mutableSetOf<String>()
        lateinit var healthPrefs: SharedPreferences
        val context =
            object : ContextWrapper(app) {
                override fun getSharedPreferences(name: String, mode: Int): SharedPreferences {
                    val scoped = prefix + name
                    names += scoped
                    return super.getSharedPreferences(scoped, mode).also {
                        if (name.startsWith("watchfree_health")) healthPrefs = it
                    }
                }
            }
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        val session = WcsSession(context, RfcommTransport(context), "02:00:00:00:00:72")
        try {
            val state = MutableStateFlow(WatchState())
            val repo = HealthRepository(context, session, scope, state, { true }, {})
            repo.restore()
            test(repo, { healthPrefs }, state)
        } finally {
            scope.cancel()
            session.close()
            names.forEach { app.deleteSharedPreferences(it) }
        }
    }
}
