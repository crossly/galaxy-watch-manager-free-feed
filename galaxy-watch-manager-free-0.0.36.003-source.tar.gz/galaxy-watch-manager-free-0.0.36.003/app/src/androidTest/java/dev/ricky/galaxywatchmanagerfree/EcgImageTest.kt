package dev.ricky.galaxywatchmanagerfree

import android.content.Context
import android.graphics.BitmapFactory
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import dev.ricky.galaxywatchmanagerfree.core.EcgImageRenderer
import dev.ricky.galaxywatchmanagerfree.core.GalleryImage
import dev.ricky.galaxywatchmanagerfree.feature.monitor.EcgRecord
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class EcgImageTest {
    @Test
    fun completeWaveformRendersMultipleRowsAndSavesAPngInMediaStore() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val row =
            EcgRecord(
                "image-test",
                1_790_000_000_000,
                75,
                1,
                waveform = FloatArray(15_000) { if (it == 14_999) .8f else 0f },
            )
        val bitmap = EcgImageRenderer.render(row, "ECG test", "0.04 s / 0.1 mV")
        try {
            assertEquals(1400, bitmap.width)
            assertTrue(bitmap.height > 1800)
            val uri =
                GalleryImage.save(context, bitmap, "ECG-test-${System.currentTimeMillis()}.png")
            try {
                val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                context.contentResolver.openInputStream(uri)!!.use {
                    BitmapFactory.decodeStream(it, null, options)
                }
                assertEquals(bitmap.width, options.outWidth)
                assertEquals(bitmap.height, options.outHeight)
            } finally {
                context.contentResolver.delete(uri, null, null)
            }
        } finally {
            bitmap.recycle()
        }
    }
}
