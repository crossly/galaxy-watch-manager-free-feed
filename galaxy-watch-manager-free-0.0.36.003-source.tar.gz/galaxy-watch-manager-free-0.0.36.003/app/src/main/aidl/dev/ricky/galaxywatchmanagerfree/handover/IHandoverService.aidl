// Privileged (Shizuku user service) operations for the official companion handover.
//
// The service runs as shell UID. It accepts only the fixed companion allowlist and a concrete
// Android user id; it never enumerates packages and never executes commands.
package dev.ricky.galaxywatchmanagerfree.handover;

interface IHandoverService {
    // Reserved by Shizuku: called when the user service is removed.
    void destroy() = 16777114;

    // Bumped whenever this interface or its enabled-state policy changes.
    int getApiVersion() = 1;

    // One entry per allowlisted package: "<package>|<installed:0/1>|<state>".
    // state is PackageManager.COMPONENT_ENABLED_STATE_* or -1 when unknown/not installed.
    String[] getPackageStates(int userId) = 2;

    // Exact current enabled state for one allowlisted package.
    int getEnabledState(String packageName, int userId) = 3;

    // Sets one allowlisted package to DEFAULT/ENABLED/DISABLED_USER, verifies the result and
    // returns the observed state. Throws SecurityException/IllegalStateException on failure.
    int setEnabledState(String packageName, int state, int userId) = 4;
}
