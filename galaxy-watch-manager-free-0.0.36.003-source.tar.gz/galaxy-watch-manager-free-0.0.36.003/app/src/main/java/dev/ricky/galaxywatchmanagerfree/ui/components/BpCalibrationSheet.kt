package dev.ricky.galaxywatchmanagerfree.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.feature.WatchRepository
import dev.ricky.galaxywatchmanagerfree.feature.WatchState
import dev.ricky.galaxywatchmanagerfree.feature.monitor.BpCalibrationStep
import dev.ricky.galaxywatchmanagerfree.ui.theme.AlertCrimson
import dev.ricky.galaxywatchmanagerfree.ui.theme.CardBorder
import dev.ricky.galaxywatchmanagerfree.ui.theme.CardSurface
import dev.ricky.galaxywatchmanagerfree.ui.theme.EmeraldCharging
import dev.ricky.galaxywatchmanagerfree.ui.theme.HealthBloodPressure
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextPrimary
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BpCalibrationSheet(state: WatchState, repo: WatchRepository, onDismiss: () -> Unit) {
    val step = state.monitorState.bpCalibrationStep
    if (step == BpCalibrationStep.Idle) return

    val context = LocalContext.current
    val strings = context.resources

    AppBottomSheet(
        onDismissRequest = {
            if (step is BpCalibrationStep.Completed) {
                repo.monitor.resetBpCalibrationStep()
            } else {
                repo.monitor.cancelBpCalibration()
            }
            onDismiss()
        }
    ) {
        Column(
            modifier =
                Modifier.fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 24.dp)
                    .padding(bottom = 36.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp),
        ) {
            when (step) {
                is BpCalibrationStep.Idle -> Unit
                is BpCalibrationStep.Preparing -> {
                    CalibrationHeader(
                        title = strings.getString(R.string.bp_calibration_workflow_title),
                        round = step.round,
                        onClose = {
                            repo.monitor.cancelBpCalibration()
                            onDismiss()
                        },
                    )
                    GroupedCard(innerPadding = 20.dp) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                        ) {
                            Box(
                                modifier =
                                    Modifier.size(44.dp)
                                        .background(
                                            HealthBloodPressure.copy(alpha = 0.15f),
                                            CircleShape,
                                        ),
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(
                                    Icons.Default.Speed,
                                    contentDescription = null,
                                    tint = HealthBloodPressure,
                                )
                            }
                            Text(
                                strings.getString(R.string.bp_calibration_prepare_desc),
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextPrimary,
                                modifier = Modifier.weight(1f),
                            )
                        }
                    }
                    Button(
                        onClick = { repo.monitor.startBpCalibrationMeasurement() },
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        colors =
                            ButtonDefaults.buttonColors(
                                containerColor = HealthBloodPressure,
                                contentColor = TextPrimary,
                            ),
                        shape = RoundedCornerShape(16.dp),
                    ) {
                        Text(
                            strings.getString(R.string.bp_calibration_start_measurement),
                            fontWeight = FontWeight.SemiBold,
                        )
                    }
                    OutlinedButton(
                        onClick = {
                            repo.monitor.cancelBpCalibration()
                            onDismiss()
                        },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        shape = RoundedCornerShape(16.dp),
                    ) {
                        Text(
                            strings.getString(R.string.bp_calibration_cancel),
                            color = TextSecondary,
                        )
                    }
                }
                is BpCalibrationStep.Measuring -> {
                    CalibrationHeader(
                        title = strings.getString(R.string.bp_calibration_workflow_title),
                        round = step.round,
                        onClose = {
                            repo.monitor.cancelBpCalibration()
                            onDismiss()
                        },
                    )
                    GroupedCard(innerPadding = 28.dp) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(20.dp),
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(56.dp),
                                color = HealthBloodPressure,
                                strokeWidth = 4.dp,
                            )
                            Text(
                                strings.getString(R.string.bp_calibration_measuring_desc),
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextPrimary,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            )
                        }
                    }
                    OutlinedButton(
                        onClick = {
                            repo.monitor.cancelBpCalibration()
                            onDismiss()
                        },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        shape = RoundedCornerShape(16.dp),
                    ) {
                        Text(
                            strings.getString(R.string.bp_calibration_cancel),
                            color = TextSecondary,
                        )
                    }
                }
                is BpCalibrationStep.WaitingCuffInput -> {
                    CalibrationHeader(
                        title = strings.getString(R.string.bp_calibration_cuff_input_title),
                        round = step.round,
                        onClose = {
                            repo.monitor.cancelBpCalibration()
                            onDismiss()
                        },
                    )

                    var systolicText by remember { mutableStateOf("") }
                    var diastolicText by remember { mutableStateOf("") }
                    var showError by remember { mutableStateOf(false) }

                    if (step.heartRate > 0) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier =
                                Modifier.background(CardSurface, RoundedCornerShape(12.dp))
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                        ) {
                            Icon(
                                Icons.Default.Favorite,
                                contentDescription = null,
                                tint = AlertCrimson,
                                modifier = Modifier.size(18.dp),
                            )
                            Text(
                                String.format(
                                    strings.getString(R.string.bp_calibration_hr_reading),
                                    step.heartRate,
                                ),
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextPrimary,
                            )
                        }
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedTextField(
                            value = systolicText,
                            onValueChange = {
                                systolicText = it.filter { ch -> ch.isDigit() }
                                showError = false
                            },
                            label = {
                                Text(strings.getString(R.string.bp_calibration_systolic_label))
                            },
                            placeholder = { Text("120") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors =
                                OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = HealthBloodPressure,
                                    unfocusedBorderColor = CardBorder,
                                    focusedLabelColor = HealthBloodPressure,
                                ),
                        )

                        OutlinedTextField(
                            value = diastolicText,
                            onValueChange = {
                                diastolicText = it.filter { ch -> ch.isDigit() }
                                showError = false
                            },
                            label = {
                                Text(strings.getString(R.string.bp_calibration_diastolic_label))
                            },
                            placeholder = { Text("80") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors =
                                OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = HealthBloodPressure,
                                    unfocusedBorderColor = CardBorder,
                                    focusedLabelColor = HealthBloodPressure,
                                ),
                        )
                    }

                    if (showError) {
                        Text(
                            strings.getString(R.string.bp_calibration_invalid_readings),
                            color = AlertCrimson,
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }

                    Button(
                        onClick = {
                            val sys = systolicText.toIntOrNull()
                            val dia = diastolicText.toIntOrNull()
                            if (
                                sys != null &&
                                    dia != null &&
                                    sys in 50..250 &&
                                    dia in 30..180 &&
                                    sys > dia
                            ) {
                                repo.monitor.submitBpCalibrationCuff(sys, dia)
                            } else {
                                showError = true
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        colors =
                            ButtonDefaults.buttonColors(
                                containerColor = HealthBloodPressure,
                                contentColor = TextPrimary,
                            ),
                        shape = RoundedCornerShape(16.dp),
                    ) {
                        Text(
                            strings.getString(R.string.bp_calibration_submit),
                            fontWeight = FontWeight.SemiBold,
                        )
                    }

                    OutlinedButton(
                        onClick = {
                            repo.monitor.cancelBpCalibration()
                            onDismiss()
                        },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        shape = RoundedCornerShape(16.dp),
                    ) {
                        Text(
                            strings.getString(R.string.bp_calibration_cancel),
                            color = TextSecondary,
                        )
                    }
                }
                is BpCalibrationStep.Submitting -> {
                    CalibrationHeader(
                        title = strings.getString(R.string.bp_calibration_workflow_title),
                        round = step.round,
                        onClose = {
                            repo.monitor.cancelBpCalibration()
                            onDismiss()
                        },
                    )
                    GroupedCard(innerPadding = 28.dp) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(48.dp),
                                color = HealthBloodPressure,
                                strokeWidth = 3.dp,
                            )
                            Text(
                                strings.getString(R.string.bp_calibration_submitting_desc),
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextPrimary,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            )
                        }
                    }
                }
                is BpCalibrationStep.Completed -> {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            strings.getString(R.string.bp_calibration_completed_title),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                        )
                        FilledTonalIconButton(
                            onClick = {
                                repo.monitor.resetBpCalibrationStep()
                                onDismiss()
                            }
                        ) {
                            Icon(Icons.Default.Close, contentDescription = null)
                        }
                    }

                    GroupedCard(innerPadding = 24.dp) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Box(
                                modifier =
                                    Modifier.size(64.dp)
                                        .background(
                                            EmeraldCharging.copy(alpha = 0.15f),
                                            CircleShape,
                                        ),
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(
                                    Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = EmeraldCharging,
                                    modifier = Modifier.size(36.dp),
                                )
                            }
                            Text(
                                strings.getString(R.string.bp_calibration_completed_desc),
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextPrimary,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            )
                        }
                    }

                    Button(
                        onClick = {
                            repo.monitor.resetBpCalibrationStep()
                            onDismiss()
                        },
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        colors =
                            ButtonDefaults.buttonColors(
                                containerColor = HealthBloodPressure,
                                contentColor = TextPrimary,
                            ),
                        shape = RoundedCornerShape(16.dp),
                    ) {
                        Text(
                            strings.getString(R.string.bp_calibration_done),
                            fontWeight = FontWeight.SemiBold,
                        )
                    }
                }
                is BpCalibrationStep.Failed -> {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            strings.getString(R.string.bp_calibration_workflow_title),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                        )
                        FilledTonalIconButton(
                            onClick = {
                                repo.monitor.resetBpCalibrationStep()
                                onDismiss()
                            }
                        ) {
                            Icon(Icons.Default.Close, contentDescription = null)
                        }
                    }

                    GroupedCard(innerPadding = 24.dp) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Box(
                                modifier =
                                    Modifier.size(56.dp)
                                        .background(AlertCrimson.copy(alpha = 0.15f), CircleShape),
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(
                                    Icons.Default.ErrorOutline,
                                    contentDescription = null,
                                    tint = AlertCrimson,
                                    modifier = Modifier.size(32.dp),
                                )
                            }
                            Text(
                                step.reason.resolve(strings),
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextPrimary,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            )
                        }
                    }

                    Button(
                        onClick = { repo.monitor.startBpCalibrationMeasurement() },
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        colors =
                            ButtonDefaults.buttonColors(
                                containerColor = HealthBloodPressure,
                                contentColor = TextPrimary,
                            ),
                        shape = RoundedCornerShape(16.dp),
                    ) {
                        Text(
                            strings.getString(R.string.bp_calibration_retry),
                            fontWeight = FontWeight.SemiBold,
                        )
                    }

                    OutlinedButton(
                        onClick = {
                            repo.monitor.cancelBpCalibration()
                            onDismiss()
                        },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        shape = RoundedCornerShape(16.dp),
                    ) {
                        Text(
                            strings.getString(R.string.bp_calibration_cancel),
                            color = TextSecondary,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CalibrationHeader(title: String, round: Int, onClose: () -> Unit) {
    val context = LocalContext.current
    val strings = context.resources
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column {
            Text(
                title,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
            )
            Spacer(Modifier.height(2.dp))
            Text(
                String.format(strings.getString(R.string.bp_calibration_round_format), round),
                style = MaterialTheme.typography.labelMedium,
                color = HealthBloodPressure,
                fontWeight = FontWeight.Medium,
            )
        }
        FilledTonalIconButton(onClick = onClose) {
            Icon(Icons.Default.Close, contentDescription = null)
        }
    }
}
