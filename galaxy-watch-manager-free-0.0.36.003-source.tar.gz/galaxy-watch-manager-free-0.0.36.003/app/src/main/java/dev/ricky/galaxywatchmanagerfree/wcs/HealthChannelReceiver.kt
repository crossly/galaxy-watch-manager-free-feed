package dev.ricky.galaxywatchmanagerfree.wcs

import dev.ricky.galaxywatchmanagerfree.feature.LogBus
import java.io.ByteArrayOutputStream

/** Receive-only Wear Channel API (inner tag 16), limited to Samsung Health sync. */
class HealthChannelReceiver(
    private val send: (ByteArray) -> Boolean,
    private val deliver: (String, ByteArray) -> Unit,
    private val log: (String) -> Unit,
    private val accepts: (String, String?) -> Boolean = { path, packageName ->
        path.startsWith(WcsPaths.HEALTH_MESSAGE) &&
            packageName in setOf(WcsPaths.PKG_SHEALTH, "com.samsung.android.wear.shealth")
    },
) {
    private data class Stream(
        val path: String,
        val createdAt: Long = System.currentTimeMillis(),
        val bytes: ByteArrayOutputStream = ByteArrayOutputStream(),
        var next: Long = 0,
        var finished: Boolean = false,
    )

    private val streams = linkedMapOf<Long, Stream>()

    @Synchronized
    fun reset() {
        streams.clear()
    }

    @Synchronized
    fun receive(request: ByteArray) {
        val channel = Proto.parse(request)
        val now = System.currentTimeMillis()
        streams.entries.removeAll {
            val expired = now - it.value.createdAt > 120_000
            if (expired)
                LogBus.debug {
                    "[HealthChannel] expired id=${it.key} path=${it.value.path} bytes=${it.value.bytes.size()} next=${it.value.next}"
                }
            expired
        }
        if ((channel.num(6) ?: 0) > 1 || (channel.num(7) ?: 0) != 0L) return
        channel.nested(2)?.let { control ->
            val id = control.num(2) ?: return
            when (control.num(1) ?: 1) {
                1L -> {
                    val path = control.text(6) ?: return
                    if (!accepts(path, control.text(4))) return
                    if (streams.size >= 4 && !streams.containsKey(id)) {
                        val evicted = streams.keys.first()
                        streams.remove(evicted)
                        LogBus.debug { "[HealthChannel] evicted id=$evicted reason=stream_limit" }
                    }
                    streams.getOrPut(id) { Stream(path) }
                    val ack =
                        Proto.integer(1, 2) +
                            Proto.fixed64(2, id) +
                            Proto.integer(3, 0) +
                            Proto.integer(8, 0)
                    val queued =
                        send(Proto.bytes(2, ack) + Proto.integer(6, 0) + Proto.integer(7, 0))
                    LogBus.debug { "[HealthChannel] OPEN ACK id=$id path=$path queued=$queued" }
                    if (!queued) log("[HealthChannel] OPEN ACK enqueue failed id=$id")
                }
                3L -> {
                    val known = streams.remove(id) != null
                    LogBus.debug { "[HealthChannel] CLOSE id=$id known=$known" }
                }
            }
        }
        channel.nested(3)?.let { data ->
            val header = data.nested(1) ?: return
            val id = header.num(1) ?: return
            val stream =
                streams[id]
                    ?: run {
                        LogBus.debug { "[HealthChannel] rejected id=$id reason=unknown_stream" }
                        return
                    }
            val sequence = header.num(3) ?: 0
            if (sequence < 0 || header.num(2) != 1L) {
                LogBus.debug {
                    "[HealthChannel] rejected id=$id seq=$sequence reason=invalid_header type=${header.num(2)}"
                }
                return
            }
            val last = data.num(3) == 1L
            if (sequence > stream.next) {
                LogBus.debug {
                    "[HealthChannel] rejected id=$id seq=$sequence expected=${stream.next} reason=sequence_gap"
                }
                return
            }
            if (sequence == stream.next && !stream.finished) {
                val payload = data.raw(2) ?: byteArrayOf()
                if (payload.size > 65536 || stream.bytes.size() + payload.size > 8 * 1024 * 1024) {
                    streams.remove(id)
                    log("[HealthChannel] rejected oversized stream id=$id")
                    LogBus.error(
                        "[HealthChannel] 拒绝过大流: id=$id chunk=${payload.size}B accumulated=${stream.bytes.size()}B"
                    )
                    return
                }
                stream.bytes.write(payload)
                stream.next++
                LogBus.debug {
                    "[HealthChannel] 收到分块 id=$id seq=$sequence chunk=${payload.size}B (累计=${stream.bytes.size()}B, last=$last)"
                }
            }
            val ackHeader = Proto.fixed64(1, id) + Proto.integer(2, 0) + Proto.integer(3, sequence)
            val ack = Proto.bytes(1, ackHeader) + Proto.integer(2, if (last) 1 else 0)
            val queued = send(Proto.bytes(4, ack) + Proto.integer(6, 0) + Proto.integer(7, 0))
            LogBus.debug { "[HealthChannel] ACK id=$id seq=$sequence last=$last queued=$queued" }
            if (!queued) log("[HealthChannel] ACK enqueue failed id=$id seq=$sequence")
            if (last && !stream.finished && sequence == stream.next - 1) {
                stream.finished = true
                val payload = stream.bytes.toByteArray()
                log("[HealthChannel] COMPLETE id=$id bytes=${payload.size} chunks=${stream.next}")
                LogBus.debug {
                    "[HealthChannel] 流传输完成 id=$id path=${stream.path} bytes=${payload.size} chunks=${stream.next}"
                }
                deliver(stream.path, payload)
                stream.bytes.reset()
            }
        }
    }
}
