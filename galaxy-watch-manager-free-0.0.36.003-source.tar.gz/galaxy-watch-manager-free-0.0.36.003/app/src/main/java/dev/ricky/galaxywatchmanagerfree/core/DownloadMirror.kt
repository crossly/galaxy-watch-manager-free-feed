package dev.ricky.galaxywatchmanagerfree.core

import java.net.URI

enum class DownloadMirror(val id: String, val baseUrl: String) {
    OFF("off", ""),
    GH_PROXY("gh-proxy", "https://gh-proxy.com/"),
    GH_PROXY_NET("ghproxy-net", "https://ghproxy.net/"),
    GH_FAST("ghfast-top", "https://ghfast.top/");

    val host: String
        get() = baseUrl.removePrefix("https://").removeSuffix("/")

    companion object {
        private val PROXIED_HOSTS = setOf("github.com", "raw.githubusercontent.com")

        fun fromPreference(value: String?): DownloadMirror =
            entries.firstOrNull { it.id == value } ?: OFF

        /** 前缀式改写为 `https://<镜像>/<原地址>`；非 GitHub、非 HTTP(S) 与无法解析的地址原样返回。 */
        fun rewrite(url: String, mirror: DownloadMirror): String {
            if (mirror == OFF) return url
            val uri = runCatching { URI(url) }.getOrNull() ?: return url
            if (uri.scheme != "https" && uri.scheme != "http") return url
            if (uri.host?.lowercase() !in PROXIED_HOSTS) return url
            return mirror.baseUrl + url
        }
    }
}
