package dev.ricky.galaxywatchmanagerfree.core

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Build
import dev.ricky.galaxywatchmanagerfree.feature.IdentityEvent
import dev.ricky.galaxywatchmanagerfree.feature.LogBus
import dev.ricky.galaxywatchmanagerfree.feature.WatchRepository
import dev.ricky.galaxywatchmanagerfree.service.WatchConnectionService
import dev.ricky.galaxywatchmanagerfree.wcs.RfcommTransport
import dev.ricky.galaxywatchmanagerfree.wcs.WcsSession

/** 自动连接的尝试结果，用于 UI 与日志。 */
enum class AutoConnectResult {
    STARTED,
    ALREADY_RUNNING,
    PAUSED_BY_USER,
    PAUSED_FOR_OFFICIAL_APPS,
    RECENTLY_TRIED,
    BLUETOOTH_OFF,
    PERMISSION_MISSING,
    NO_PAIRED_WATCH,
    BACKGROUND_RESTRICTED,
}

/** 全局连接控制器（进程内单例）。 */
enum class HandshakeMode {
    CREDENTIAL,
    REPLAY,
    LAB,
}

data class ConnectionProgress(
    val mac: String = "",
    val status: dev.ricky.galaxywatchmanagerfree.feature.OnboardingStatus =
        dev.ricky.galaxywatchmanagerfree.feature.OnboardingStatus.IDLE,
    val candidateNode: String = "",
)

/**
 * 连接生命周期（显式化）：[WatchController] 内部状态机，[OnboardingStatus] 是其 UI 投影。
 *
 * 每个阶段携带可选节点负载；所有迁移经 [WatchController.transition] 单一入口，避免状态散落在
 * 各方法与回调里。资源句柄（transport/session/repo/receiver）仍由 [ConnectionRequestGate] 代际与
 * [WatchController.repositoryRevision] 守护，不作为阶段的一部分。
 */
private sealed interface ConnectionPhase {
    val node: String
        get() = ""

    val status: dev.ricky.galaxywatchmanagerfree.feature.OnboardingStatus

    data object Idle : ConnectionPhase {
        override val status = dev.ricky.galaxywatchmanagerfree.feature.OnboardingStatus.IDLE
    }

    data object AcquiringIdentity : ConnectionPhase {
        override val status =
            dev.ricky.galaxywatchmanagerfree.feature.OnboardingStatus.ACQUIRING_IDENTITY
    }

    data object IdentityMissing : ConnectionPhase {
        override val status =
            dev.ricky.galaxywatchmanagerfree.feature.OnboardingStatus.IDENTITY_MISSING
    }

    data class PreparingHandover(override val node: String = "") : ConnectionPhase {
        override val status =
            dev.ricky.galaxywatchmanagerfree.feature.OnboardingStatus.PREPARING_HANDOVER
    }

    data object Connecting : ConnectionPhase {
        override val status = dev.ricky.galaxywatchmanagerfree.feature.OnboardingStatus.CONNECTING
    }

    data object VerifyingIdentity : ConnectionPhase {
        override val status =
            dev.ricky.galaxywatchmanagerfree.feature.OnboardingStatus.VERIFYING_IDENTITY
    }

    data object Ready : ConnectionPhase {
        override val status = dev.ricky.galaxywatchmanagerfree.feature.OnboardingStatus.READY
    }

    data object Failed : ConnectionPhase {
        override val status = dev.ricky.galaxywatchmanagerfree.feature.OnboardingStatus.ERROR
    }
}

object WatchController {
    private val requestGate = ConnectionRequestGate()
    private var activeRequest: ConnectionRequestGate.Request? = null
    private var activeMac: String? = null
    private val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val _connectionProgress = kotlinx.coroutines.flow.MutableStateFlow(ConnectionProgress())
    val connectionProgress: kotlinx.coroutines.flow.StateFlow<ConnectionProgress> =
        _connectionProgress

    @Volatile private var phase: ConnectionPhase = ConnectionPhase.Idle

    /** 连接状态机的单一迁移入口：[phase] 是当前阶段，[connectionProgress] 是其 UI 投影。 */
    private fun transition(next: ConnectionPhase) {
        phase = next
        _connectionProgress.value = ConnectionProgress(savedMac.orEmpty(), next.status, next.node)
    }

    private fun owns(request: ConnectionRequestGate.Request): Boolean =
        requestGate.isCurrent(request)

    private const val PREFS = "watchfree"
    private const val KEY_MAC = "watch_mac"
    private const val AUTO_RETRY_MS = 15_000L

    private val receiveExecutor =
        java.util.concurrent.Executors.newSingleThreadExecutor { task ->
            Thread(task, "wcs-receiver").apply { isDaemon = true }
        }
    private var receiver: SessionReceiveQueue? = null
    private var repositoryRevision = 0L
    @Volatile private var transport: RfcommTransport? = null
    @Volatile
    private var wearApiTransport: dev.ricky.galaxywatchmanagerfree.wcs.WearApiTransport? = null
    @Volatile private var session: WcsSession? = null
    @Volatile private var repo: WatchRepository? = null
    @Volatile private var fallbackRepo: WatchRepository? = null
    @Volatile private var appContext: Context? = null
    private val _repositoryState = kotlinx.coroutines.flow.MutableStateFlow<WatchRepository?>(null)
    val repositoryState: kotlinx.coroutines.flow.StateFlow<WatchRepository?> = _repositoryState

    /** 永久非空 Repository：未建立连接时返回 fallback 离线实例 */
    val repository: WatchRepository
        get() =
            repo
                ?: fallbackRepo
                ?: synchronized(this) {
                    val ctx = appContext ?: error("WatchController not initialized")
                    val dummyTransport = RfcommTransport(ctx, null)
                    val dummySession = WcsSession(ctx, dummyTransport, savedMac)
                    WatchRepository(ctx, dummySession).also { fallbackRepo = it }
                }

    /** 调试：回放帧数上限（0=全部） */
    @Volatile var replayFrameLimit: Int = 0

    /** 字段实验模式 */
    @Volatile var labMode: Int = 0

    /** lab 模式是否只发 NodeInfo 一帧（隔离实验用） */
    @Volatile var labOnly: Boolean = false

    /** 首次重连等待（毫秒） */
    @Volatile var initialBackoffMs: Long = 2000L

    /** 本进程内用户主动断开后暂停自动重连；下次启动应用时恢复。 */
    @Volatile private var pausedThisSession: Boolean = false
    @Volatile private var lastAutoAttemptAt: Long = 0L

    /** 握手策略 */
    @Volatile var handshakeMode: HandshakeMode = HandshakeMode.CREDENTIAL
    val isRunning: Boolean
        get() = activeRequest != null || transport != null

    fun init(context: Context) {
        val app = context.applicationContext
        appContext = app
        dev.ricky.galaxywatchmanagerfree.feature.DevicePreferences.rememberLegacyOwner(
            app,
            savedMac,
        )
        val persistedMac = savedMac
        if (!persistedMac.isNullOrBlank()) {
            val store =
                dev.ricky.galaxywatchmanagerfree.feature.DeviceIdentityStore(app, persistedMac)
            // 进程被杀后待定身份仍在；恢复可观察状态，但绝不自动连接。
            if (store.handoverPreparing) {
                transition(ConnectionPhase.PreparingHandover(store.pendingHandoverNode))
            }
        }
        if (fallbackRepo == null) {
            val dummyTransport = RfcommTransport(app, null)
            val dummySession = WcsSession(app, dummyTransport, savedMac)
            fallbackRepo = WatchRepository(app, dummySession)
            _repositoryState.value = fallbackRepo
        }
    }

    /** 测试接缝：模拟进程重启（清除进程内请求与自动连接暂停标记）。 */
    @androidx.annotation.VisibleForTesting
    internal fun resetProcessStateForTest() {
        pausedThisSession = false
        lastAutoAttemptAt = 0L
        requestGate.invalidate()
        activeRequest = null
        activeMac = null
    }

    @Synchronized
    fun startService(context: Context, mac: String? = null): Boolean {
        val app = context.applicationContext
        val target = mac ?: savedMac ?: return false
        val store = dev.ricky.galaxywatchmanagerfree.feature.DeviceIdentityStore(app, target)
        if (store.handoverPreparing) {
            savedMac = target
            if (store.hasPendingHandover) {
                transition(ConnectionPhase.PreparingHandover(store.pendingHandoverNode))
                LogBus.log("[交接] 交接准备未完成，暂不自动连接")
                return false
            }
            // 交接准备中还没有身份：只获取并暂存，绝不进入 RFCOMM。
            val request = beginRequest(target)
            transition(ConnectionPhase.PreparingHandover())
            fetchIdentity(request)
            return true
        }
        val existing = activeRequest
        if (existing != null && owns(existing) && existing.mac.equals(target, true)) return true
        val request = beginRequest(target)
        return if (store.effectivePhoneNode.isBlank()) {
            fetchIdentity(request)
            true
        } else {
            launchService(app, request)
        }
    }

    private fun beginRequest(mac: String): ConnectionRequestGate.Request {
        appContext?.let {
            dev.ricky.galaxywatchmanagerfree.feature
                .DeviceIdentityStore(it, mac)
                .transition(IdentityEvent.ReclaimFromOfficialApps)
        }
        stop()
        savedMac = mac
        enabled = true
        pausedThisSession = false
        return requestGate.begin(mac).also { activeRequest = it }
    }

    private fun launchService(context: Context, request: ConnectionRequestGate.Request): Boolean {
        if (!owns(request)) return false
        transition(ConnectionPhase.Connecting)
        val started =
            runCatching {
                    context.startForegroundService(
                        WatchConnectionService.startIntent(context, request.mac, request.generation)
                    )
                }
                .onFailure { LogBus.log("启动前台服务失败: ${it.javaClass.simpleName}") }
                .isSuccess
        if (!started) failRequest(request, ConnectionPhase.Failed)
        return started
    }

    @Synchronized
    fun stopService(context: Context) {
        enabled = false
        pausedThisSession = true
        stop()
        runCatching { context.stopService(Intent(context, WatchConnectionService::class.java)) }
    }

    // Auto-connect and discovery

    /** 用户设置：是否在应用启动/回到前台时自动连接已配对的手表 */
    var autoConnectEnabled: Boolean
        get() = prefs()?.getBoolean("auto_connect", true) ?: true
        set(value) {
            prefs()?.edit()?.putBoolean("auto_connect", value)?.apply()
        }

    /** 进程启动时调用：清除上一次的主动断开手势，然后尝试连接。 */
    fun resumeAutoConnect(context: Context): AutoConnectResult {
        pausedThisSession = false
        return autoConnect(context, force = true)
    }

    /** 用户明确要求重新接管连接；解除“官方应用独占”后再走正常自动发现。 */
    @Synchronized
    fun connectManually(context: Context): AutoConnectResult {
        val app = context.applicationContext
        appContext = app
        savedMac?.let {
            dev.ricky.galaxywatchmanagerfree.feature
                .DeviceIdentityStore(app, it)
                .transition(IdentityEvent.ReclaimFromOfficialApps)
        }
        pausedThisSession = false
        return autoConnect(app, force = true)
    }

    /** 从系统已配对列表中找手表并连接。名称匹配只是排序启发式，无法证明对端 真的支持 WCS；真正可用与否仍以握手结果为准。 */
    @SuppressLint("MissingPermission")
    @Synchronized
    fun autoConnect(context: Context, force: Boolean = false): AutoConnectResult {
        val app = context.applicationContext
        appContext = app
        if (transport != null) return AutoConnectResult.ALREADY_RUNNING
        if (!autoConnectEnabled) return AutoConnectResult.PAUSED_BY_USER
        if (pausedThisSession && !force) return AutoConnectResult.PAUSED_BY_USER
        val pendingMac = savedMac
        if (pendingMac != null) {
            val pendingStore =
                dev.ricky.galaxywatchmanagerfree.feature.DeviceIdentityStore(app, pendingMac)
            if (pendingStore.releasedToOfficialApps) {
                LogBus.log("[自动连接] 官方应用已恢复并独占连接，等待用户显式连接")
                return AutoConnectResult.PAUSED_FOR_OFFICIAL_APPS
            }
            if (pendingStore.handoverPreparing) {
                LogBus.log("[自动连接] 设备处于应用交接准备状态，跳过自动连接")
                return AutoConnectResult.PAUSED_BY_USER
            }
        }
        val now = System.currentTimeMillis()
        if (!force && now - lastAutoAttemptAt < AUTO_RETRY_MS)
            return AutoConnectResult.RECENTLY_TRIED
        lastAutoAttemptAt = now

        if (
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                app.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) !=
                    PackageManager.PERMISSION_GRANTED
        ) {
            LogBus.log("[自动连接] 缺少蓝牙权限，授权后会重试")
            return AutoConnectResult.PERMISSION_MISSING
        }

        val adapter =
            (app.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
                ?: BluetoothAdapter.getDefaultAdapter()
                ?: return AutoConnectResult.BLUETOOTH_OFF
        if (!adapter.isEnabled) {
            LogBus.log("[自动连接] 蓝牙未开启")
            return AutoConnectResult.BLUETOOTH_OFF
        }

        val bonded =
            runCatching { adapter.bondedDevices.orEmpty().toList() }
                .getOrElse {
                    LogBus.log("[自动连接] 读取配对列表失败: ${it.javaClass.simpleName}")
                    return AutoConnectResult.PERMISSION_MISSING
                }
        val candidates = bonded.map { WatchDiscovery.Candidate(it.name, it.address) }
        val target = WatchDiscovery.pick(candidates, savedMac)
        if (target == null) {
            LogBus.log("[自动连接] 已配对设备中没有识别出手表（共 ${bonded.size} 个），请在设置里手动选择")
            return AutoConnectResult.NO_PAIRED_WATCH
        }

        val handoverStore =
            dev.ricky.galaxywatchmanagerfree.feature.DeviceIdentityStore(app, target.address)
        if (handoverStore.releasedToOfficialApps) {
            savedMac = target.address
            LogBus.log("[自动连接] 官方应用已恢复并独占连接，等待用户显式连接")
            return AutoConnectResult.PAUSED_FOR_OFFICIAL_APPS
        }
        if (handoverStore.handoverPreparing) {
            savedMac = target.address
            LogBus.log("[自动连接] 设备处于应用交接准备状态，等待用户显式继续连接")
            return AutoConnectResult.PAUSED_BY_USER
        }

        val name = target.name ?: "未知手表"
        val reused = savedMac?.equals(target.address, ignoreCase = true) == true
        savedMac = target.address
        LogBus.log("[自动连接] 选中 $name / ${target.address}${if (reused) "（上次使用）" else "（按名称匹配）"}，开始连接")
        if (startService(app, target.address)) return AutoConnectResult.STARTED
        LogBus.log("[自动连接] 前台服务被系统拒绝，打开应用后会重试")
        return AutoConnectResult.BACKGROUND_RESTRICTED
    }

    /** 诊断：通过 GMS Wearable MessageClient 直接发一条消息 */
    fun wearApiSend(path: String, payload: ByteArray) {
        wearApiTransport?.send(path, payload) { ok ->
            LogBus.debug("[WearApi→] $path (${payload.size}B) ok=$ok")
        } ?: LogBus.log("[WearApi] 传输层未启动，先执行 startWearApi")
    }

    /** 诊断：重新枚举已连接的 Wear 节点 */
    fun wearApiRefresh() {
        wearApiTransport?.refreshNodes()
    }

    fun startWearApi(context: Context) {
        val app = context.applicationContext
        appContext = app
        wearApiTransport?.stop()
        wearApiTransport =
            dev.ricky.galaxywatchmanagerfree.wcs.WearApiTransport(app).apply {
                onConnectionStateListener = { connected, name, error ->
                    if (connected) {
                        repository.onWearApiConnected(name, targetNodeId)
                    } else {
                        repository.onWearApiDisconnected(error)
                    }
                }
                onMessageListener = { path, data, _ -> repository.handleWearApiMessage(path, data) }
                start()
            }
    }

    private fun prefs(): SharedPreferences? =
        appContext?.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    var savedMac: String?
        get() = prefs()?.getString(KEY_MAC, null)
        set(value) {
            val previous = prefs()?.getString(KEY_MAC, null)
            prefs()?.edit()?.putString(KEY_MAC, value)?.apply()
            val ctx = appContext
            if (ctx != null && !previous.isNullOrBlank() && !previous.equals(value, true)) {
                // 换目标即放弃上一个设备的交接流程，避免待定身份跨设备滞留。
                dev.ricky.galaxywatchmanagerfree.feature
                    .DeviceIdentityStore(ctx, previous)
                    .transition(IdentityEvent.ClearHandover)
            }
        }

    var enabled: Boolean
        get() = prefs()?.getBoolean("enabled", false) ?: false
        set(value) {
            prefs()?.edit()?.putBoolean("enabled", value)?.apply()
        }

    var forwardNotifications: Boolean
        get() = prefs()?.getBoolean("forward_notifications", true) ?: true
        set(value) {
            prefs()?.edit()?.putBoolean("forward_notifications", value)?.apply()
        }

    @Volatile
    private var localNodeProvider: dev.ricky.galaxywatchmanagerfree.feature.LocalNodeProvider? =
        null

    @SuppressLint("MissingPermission")
    fun resolveDevice(mac: String): BluetoothDevice? {
        val ctx = appContext ?: return null
        val adapter =
            (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
                ?: BluetoothAdapter.getDefaultAdapter()
                ?: return null
        if (!adapter.isEnabled) return null
        return runCatching { adapter.getRemoteDevice(mac) }.getOrNull()
    }

    @Synchronized
    fun acquireIdentity(mac: String? = null, onFinished: ((Boolean, String) -> Unit)? = null) {
        val target = mac ?: savedMac ?: return
        fetchIdentity(beginRequest(target), onFinished)
    }

    private fun fetchIdentity(
        request: ConnectionRequestGate.Request,
        onFinished: ((Boolean, String) -> Unit)? = null,
    ) {
        val ctx = appContext ?: return
        transition(ConnectionPhase.AcquiringIdentity)
        val provider = dev.ricky.galaxywatchmanagerfree.feature.GmsLocalNodeProvider(ctx)
        localNodeProvider = provider
        provider.fetchLocalNode { result ->
            mainHandler.post {
                synchronized(this) {
                    if (!owns(request)) return@synchronized
                    provider.shutdown()
                    localNodeProvider = null
                    when (result) {
                        is dev.ricky.galaxywatchmanagerfree.feature.LocalNodeResult.Success -> {
                            val store =
                                dev.ricky.galaxywatchmanagerfree.feature.DeviceIdentityStore(
                                    ctx,
                                    request.mac,
                                )
                            if (store.handoverPreparing) {
                                // 交接准备：只落盘待定身份，绝不自动进入 RFCOMM。
                                store.transition(IdentityEvent.StagePendingHandover(result.nodeId))
                                transition(ConnectionPhase.PreparingHandover(result.nodeId))
                                LogBus.log("[交接] 已暂存待验证身份 ${result.nodeId}，连接保持暂停")
                                onFinished?.invoke(true, result.nodeId)
                            } else {
                                store.transition(
                                    IdentityEvent.StageCandidatePhoneNode(result.nodeId)
                                )
                                onFinished?.invoke(true, result.nodeId)
                                launchService(ctx, request)
                            }
                        }
                        is dev.ricky.galaxywatchmanagerfree.feature.LocalNodeResult.Failure -> {
                            LogBus.log("[身份] 获取失败: ${result.reason}")
                            failRequest(request, ConnectionPhase.IdentityMissing)
                            onFinished?.invoke(false, result.reason)
                        }
                    }
                }
            }
        }
    }

    @Synchronized
    fun connectWithNode(context: Context, mac: String, node: String): Boolean {
        val clean = dev.ricky.galaxywatchmanagerfree.feature.DeviceIdentityStore.normalizeNode(node)
        if (!dev.ricky.galaxywatchmanagerfree.feature.DeviceIdentityStore.isValidNode(clean))
            return false
        val app = context.applicationContext
        appContext = app
        val store = dev.ricky.galaxywatchmanagerfree.feature.DeviceIdentityStore(app, mac)
        if (store.handoverPreparing) {
            // 交接期间手工输入只更新待定身份，保持暂停。
            if (!store.transition(IdentityEvent.StagePendingHandover(clean))) return false
            savedMac = mac
            transition(ConnectionPhase.PreparingHandover(clean))
            return true
        }
        val request = beginRequest(mac)
        store.transition(IdentityEvent.StageCandidatePhoneNode(clean))
        return launchService(app, request)
    }

    @Synchronized
    fun switchTarget(context: Context, mac: String): Boolean {
        val app = context.applicationContext
        val previous = savedMac ?: activeRequest?.mac
        if (!previous.isNullOrBlank() && !previous.equals(mac, ignoreCase = true)) {
            // 换目标即放弃上一个设备的交接流程，避免待定身份跨设备滞留。
            dev.ricky.galaxywatchmanagerfree.feature
                .DeviceIdentityStore(app, previous)
                .transition(IdentityEvent.ClearHandover)
        }
        stopService(app)
        return startService(app, mac)
    }

    /**
     * 进入官方连接管理 App 交接准备：把已知身份落盘为待定身份并暂停当前连接。
     *
     * 不阻塞等待：已有身份（进程内候选或已确认身份）时立即返回 true；没有任何身份时启动 GMS 本机节点获取， 成功后由 [fetchIdentity] 暂存待定身份并停在
     * PREPARING_HANDOVER，不会自动进入 RFCOMM。待定身份必须由 [continueHandover] 显式继续，并经 WCS 现场验证后才能成为已确认身份。
     *
     * @return false 仅表示当前没有可选目标设备。
     */
    @Synchronized
    fun prepareHandover(context: Context): Boolean {
        val app = context.applicationContext
        appContext = app
        val target = savedMac?.takeIf { it.isNotBlank() } ?: activeRequest?.mac ?: return false
        val store = dev.ricky.galaxywatchmanagerfree.feature.DeviceIdentityStore(app, target)
        val seed = store.effectivePhoneNode.ifBlank { store.pendingHandoverNode }
        val pendingReady = store.transition(IdentityEvent.BeginHandover(seed.ifBlank { null }))
        savedMac = target
        // 先落盘再断开：stop() 会清掉进程内候选，但待定身份必须活下来。
        stopService(app)
        if (pendingReady) {
            transition(ConnectionPhase.PreparingHandover(store.pendingHandoverNode))
            LogBus.log("[交接] 已暂存待验证身份 ${store.pendingHandoverNode}，连接已暂停")
            return true
        }
        val request = beginRequest(target)
        transition(ConnectionPhase.PreparingHandover())
        fetchIdentity(request)
        return true
    }

    /**
     * 显式继续交接：把待定身份作为本次会话的进程内候选，恢复自动连接并进入正常 WCS 验证。
     *
     * 待定身份不会在这里直接变成已确认身份；只有手表现场证明成功后才会固化。
     */
    @Synchronized
    fun continueHandover(context: Context): Boolean {
        val app = context.applicationContext
        appContext = app
        val target = savedMac?.takeIf { it.isNotBlank() } ?: activeRequest?.mac ?: return false
        val store = dev.ricky.galaxywatchmanagerfree.feature.DeviceIdentityStore(app, target)
        val node =
            store.pendingHandoverNode.ifBlank {
                store.confirmedPhoneNode.ifBlank { store.effectivePhoneNode }
            }
        if (node.isBlank()) return false
        store.transition(IdentityEvent.EndHandoverPreparation)
        val request = beginRequest(target)
        store.transition(IdentityEvent.StageCandidatePhoneNode(node))
        LogBus.log("[交接] 使用待验证身份 $node 继续连接")
        return launchService(app, request)
    }

    /** 取消交接准备：清除待定身份并停止连接，本会话不再自动重连。 */
    @Synchronized
    fun cancelHandover(context: Context) {
        val app = context.applicationContext
        appContext = app
        val target = savedMac?.takeIf { it.isNotBlank() } ?: activeRequest?.mac
        target?.let {
            dev.ricky.galaxywatchmanagerfree.feature
                .DeviceIdentityStore(app, it)
                .transition(IdentityEvent.ClearHandover)
        }
        stopService(app)
        LogBus.log("[交接] 已取消交接准备")
    }

    fun retryConnection(context: Context): Boolean {
        val mac = savedMac ?: return false
        stopService(context)
        return startService(context, mac)
    }

    fun stopConnection(context: Context) {
        stopService(context)
    }

    @Synchronized
    fun releaseConnectionToOfficialApps(context: Context): Boolean {
        val app = context.applicationContext
        appContext = app
        val target = savedMac ?: activeRequest?.mac
        val released =
            target?.let {
                dev.ricky.galaxywatchmanagerfree.feature
                    .DeviceIdentityStore(app, it)
                    .transition(IdentityEvent.ReleaseToOfficialApps)
            } ?: false
        stopService(app)
        LogBus.log(if (released) "[交接] 已停止本应用并持久交还连接给官方应用" else "[交接] 已停止本应用；没有可记录的设备目标")
        return released
    }

    @Synchronized
    fun admitServiceStart(mac: String, generation: Long?): Long? {
        val ctx = appContext ?: return null
        val store = dev.ricky.galaxywatchmanagerfree.feature.DeviceIdentityStore(ctx, mac)
        // 交接准备期间连粘性重启也必须拒绝；显式继续会先清掉该标记。
        if (store.handoverPreparing) return null
        if (store.releasedToOfficialApps) return null
        if (!enabled || pausedThisSession) return null
        if (generation != null) return generation.takeIf { requestGate.matches(it, mac) }
        // A process restart may restore only a previously verified binding.
        if (activeRequest != null) return null
        if (store.confirmedPhoneNode.isBlank()) return null
        return requestGate.begin(mac).also { activeRequest = it }.generation
    }

    @Synchronized
    fun startFromService(mac: String, generation: Long) {
        if (!requestGate.matches(generation, mac) || !enabled) return
        startTransport(mac, activeRequest ?: return)
    }

    @Synchronized
    fun stopIfCurrent(generation: Long) {
        val request = activeRequest ?: return
        if (request.generation == generation && owns(request)) stop()
    }

    @Synchronized
    private fun failRequest(request: ConnectionRequestGate.Request, failed: ConnectionPhase) {
        if (!owns(request)) return
        stop()
        transition(failed)
        appContext?.stopService(Intent(appContext, WatchConnectionService::class.java))
    }

    fun start(mac: String) {
        appContext?.let { startService(it, mac) }
    }

    @SuppressLint("MissingPermission")
    @Synchronized
    private fun startTransport(mac: String, request: ConnectionRequestGate.Request) {
        val ctx = appContext ?: return
        if (!owns(request) || transport != null) return
        val device = resolveDevice(mac)
        if (device == null) {
            LogBus.log("无法解析设备 $mac（蓝牙是否开启？）")
            failRequest(request, ConnectionPhase.Failed)
            return
        }
        LogBus.log("启动连接：${device.name ?: "?"} / $mac")

        val t = RfcommTransport(ctx, device)
        var activeSession: WcsSession? = null
        var activeRepository: WatchRepository? = null
        val receive =
            SessionReceiveQueue(
                executor = receiveExecutor,
                isActive = { owns(request) },
                onClosed = {
                    activeRepository?.close()
                    activeSession?.close()
                },
                onFailure = { error ->
                    LogBus.error("接收处理失败", error)
                    mainHandler.post { failRequest(request, ConnectionPhase.Failed) }
                },
            )

        t.setListener(
            object : RfcommTransport.Listener {
                override fun onConnected() {
                    receive.await {
                        activeRepository?.onTransportState(true)
                        synchronized(WatchController) {
                            if (owns(request)) {
                                transition(ConnectionPhase.VerifyingIdentity)
                                LogBus.log("RFCOMM 已连接")
                            }
                        }
                    }
                }

                override fun onDisconnected(reason: String) {
                    receive.await {
                        activeRepository?.onTransportState(false)
                        synchronized(WatchController) {
                            if (owns(request)) {
                                transition(ConnectionPhase.Connecting)
                                LogBus.log("断开：$reason")
                            }
                        }
                    }
                }

                override fun onEnvelope(body: ByteArray) {
                    if (
                        !receive.submit(body.size) { activeSession?.onEnvelopeReceived(body) } &&
                            owns(request)
                    ) {
                        throw java.io.IOException("接收队列已关闭")
                    }
                }

                override fun onLog(line: String) {
                    LogBus.log(line)
                }
            }
        )

        activeMac = mac
        transport = t
        receiver = receive
        savedMac = mac
        receive.submit {
            val previous =
                synchronized(this) {
                    if (!owns(request)) return@submit
                    fallbackRepo
                }
            previous?.close()
            if (!owns(request)) return@submit
            val s = WcsSession(ctx, t, mac, isActive = { owns(request) })
            activeSession = s
            val r = WatchRepository(ctx, s, isCurrent = { owns(request) })
            activeRepository = r
            s.onIdentityVerified = {
                mainHandler.post {
                    synchronized(this) { if (owns(request)) transition(ConnectionPhase.Ready) }
                }
            }
            synchronized(this) {
                if (!owns(request)) return@submit
                fallbackRepo = null
                session = s
                repo = r
                _repositoryState.value = r
                t.start()
            }
        }
        mainHandler.postDelayed(
            {
                synchronized(this) {
                    if (owns(request) && phase !is ConnectionPhase.Ready) {
                        failRequest(request, ConnectionPhase.Failed)
                    }
                }
            },
            30_000L,
        )
    }

    @Synchronized
    fun stop() {
        val stoppedMac = activeRequest?.mac ?: activeMac
        requestGate.invalidate()
        activeRequest = null
        appContext?.let { ctx ->
            stoppedMac?.let {
                dev.ricky.galaxywatchmanagerfree.feature
                    .DeviceIdentityStore(ctx, it)
                    .transition(IdentityEvent.ClearCandidatePhoneNode)
            }
        }
        activeMac = null
        transition(ConnectionPhase.Idle)
        (localNodeProvider as? dev.ricky.galaxywatchmanagerfree.feature.GmsLocalNodeProvider)
            ?.shutdown()
        localNodeProvider = null
        wearApiTransport?.stop()
        wearApiTransport = null
        if (transport == null && repo == null && receiver == null) return
        val revision = ++repositoryRevision
        val previous = repo
        val offline = fallbackRepo
        previous?.deactivate()
        offline?.deactivate()
        receiver?.close()
        receiver = null
        transport?.setListener(null)
        transport?.stop()
        transport = null
        session = null
        repo = null
        fallbackRepo = previous ?: offline
        receiveExecutor.execute {
            previous?.close()
            offline?.close()
            val ctx =
                synchronized(this) {
                    if (revision != repositoryRevision || isRunning) return@execute
                    appContext
                } ?: return@execute
            val restored =
                WatchRepository(ctx, WcsSession(ctx, RfcommTransport(ctx, null), savedMac))
            val published =
                synchronized(this) {
                    if (revision != repositoryRevision || isRunning) false
                    else {
                        fallbackRepo = restored
                        _repositoryState.value = restored
                        true
                    }
                }
            if (!published) restored.close()
        }
        LogBus.log("已停止")
    }
}
