package dev.ricky.galaxywatchmanagerfree.wcs

/**
 * 极简 protobuf 编解码器。
 *
 * WCS 的消息通常使用 varint / length-delimited；Wear Channel 的 channelId 使用 fixed64，因此也保留 fixed64 / fixed32
 * 数值。
 */
object Proto {

    private const val WIRE_VARINT = 0
    private const val WIRE_FIXED64 = 1
    private const val WIRE_LEN = 2
    private const val WIRE_FIXED32 = 5

    // Encoding

    fun varint(value: Long): ByteArray {
        var v = value
        val out = ArrayList<Byte>(10)
        while (true) {
            val b = (v and 0x7F).toInt()
            v = v ushr 7
            if (v != 0L) {
                out.add((b or 0x80).toByte())
            } else {
                out.add(b.toByte())
                return out.toByteArray()
            }
        }
    }

    fun tag(field: Int, wire: Int): ByteArray = varint(((field shl 3) or wire).toLong())

    fun bytes(field: Int, data: ByteArray): ByteArray =
        tag(field, WIRE_LEN) + varint(data.size.toLong()) + data

    fun string(field: Int, s: String): ByteArray = bytes(field, s.toByteArray(Charsets.UTF_8))

    fun integer(field: Int, v: Long): ByteArray = tag(field, WIRE_VARINT) + varint(v)

    fun fixed64(field: Int, value: Long): ByteArray =
        tag(field, WIRE_FIXED64) + ByteArray(8) { (value ushr (it * 8)).toByte() }

    // Decoding

    /** 解析结果：field -> 值列表（ByteArray 或 Long） */
    class Message(val fields: Map<Int, List<Any>>) {
        fun raw(field: Int): ByteArray? = fields[field]?.firstOrNull() as? ByteArray

        fun text(field: Int): String? = raw(field)?.toString(Charsets.UTF_8)

        fun num(field: Int): Long? = fields[field]?.firstOrNull() as? Long

        fun has(field: Int): Boolean = fields.containsKey(field)

        fun nested(field: Int): Message? = raw(field)?.let { parse(it) }
    }

    fun parse(buf: ByteArray): Message {
        val out = LinkedHashMap<Int, MutableList<Any>>()
        var i = 0
        while (i < buf.size) {
            val (key, ni) = readVarint(buf, i) ?: break
            i = ni
            val field = (key ushr 3).toInt()
            val wire = (key and 7L).toInt()
            if (field == 0) break
            when (wire) {
                WIRE_VARINT -> {
                    val (v, n2) = readVarint(buf, i) ?: break
                    i = n2
                    out.getOrPut(field) { ArrayList() }.add(v)
                }
                WIRE_LEN -> {
                    val (len, n2) = readVarint(buf, i) ?: break
                    i = n2
                    // 先以 Long 检查剩余空间，再缩窄和相加，避免溢出或按畸形长度分配内存。
                    if (len < 0 || len > (buf.size - i).toLong()) break
                    val end = i + len.toInt()
                    out.getOrPut(field) { ArrayList() }.add(buf.copyOfRange(i, end))
                    i = end
                }
                WIRE_FIXED64 -> {
                    if (buf.size - i < 8) break
                    var value = 0L
                    for (j in 0 until 8) value =
                        value or ((buf[i + j].toLong() and 255) shl (j * 8))
                    out.getOrPut(field) { ArrayList() }.add(value)
                    i += 8
                }
                WIRE_FIXED32 -> {
                    if (buf.size - i < 4) break
                    var value = 0L
                    for (j in 0 until 4) value =
                        value or ((buf[i + j].toLong() and 255) shl (j * 8))
                    out.getOrPut(field) { ArrayList() }.add(value)
                    i += 4
                }
                else -> break
            }
        }
        return Message(out)
    }

    private fun readVarint(buf: ByteArray, start: Int): Pair<Long, Int>? {
        var shift = 0
        var value = 0L
        var i = start
        while (i < buf.size) {
            val b = buf[i].toInt() and 0xFF
            value = value or ((b and 0x7F).toLong() shl shift)
            shift += 7
            i++
            if (b and 0x80 == 0) return value to i
            if (shift > 63) return null
        }
        return null
    }

    // Utilities

    fun toHex(b: ByteArray): String {
        val sb = StringBuilder(b.size * 2)
        for (x in b) sb.append("%02x".format(x.toInt() and 0xFF))
        return sb.toString()
    }

    fun fromHex(s: String): ByteArray {
        val clean = s.replace(" ", "").replace("\n", "")
        require(clean.length % 2 == 0) { "hex length must be even" }
        return ByteArray(clean.length / 2) {
            ((Character.digit(clean[it * 2], 16) shl 4) or Character.digit(clean[it * 2 + 1], 16))
                .toByte()
        }
    }
}
