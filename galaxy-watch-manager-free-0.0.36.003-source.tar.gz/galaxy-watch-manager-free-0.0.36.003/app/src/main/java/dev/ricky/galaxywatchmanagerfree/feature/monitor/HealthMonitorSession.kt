package dev.ricky.galaxywatchmanagerfree.feature.monitor

import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.core.UiText
import dev.ricky.galaxywatchmanagerfree.core.uiText
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

/**
 * Transport handshake and durable result sync; reconnecting never invents personal profile/consent.
 */
class HealthMonitorSession(
    private val scope: CoroutineScope,
    private val send: (String, JSONObject) -> Boolean,
    private val launchRemoteActivity:
        ((String, String, String?, List<String>, Map<String, Any>) -> Boolean)? =
        null,
    private val onEcgReceived: (EcgRecord) -> Boolean = { false },
    private val onBpReceived: (BpRecord) -> Boolean = { false },
    private val log: (String) -> Unit = {},
    private val onBpConfigurationsReceived: (List<JSONObject>) -> Boolean = { false },
    private val nowMillis: () -> Long = System::currentTimeMillis,
) {
    enum class Connection {
        DISCONNECTED,
        CONNECTING,
        READY,
    }

    enum class BpReviewStage {
        IDLE,
        AWAITING_INFORMATION,
        AWAITING_SYNC,
    }

    data class State(
        val connection: Connection = Connection.DISCONNECTED,
        val ecgActivated: Boolean = false,
        val bpActivated: Boolean = false,
        val lastEcg: EcgRecord? = null,
        val lastBp: BpRecord? = null,
        val information: Map<HealthMonitorProtocol.Channel, String> = emptyMap(),
        val bpReviewStage: BpReviewStage = BpReviewStage.IDLE,
        val bpReviewedInformation: String? = null,
        val bpCalibrationStep: BpCalibrationStep = BpCalibrationStep.Idle,
        val receivedCount: Int = 0,
        val error: UiText? = null,
    ) {
        val bpInformationPending: Boolean
            get() = bpReviewStage == BpReviewStage.AWAITING_INFORMATION

        val bpSyncPending: Boolean
            get() = bpReviewStage == BpReviewStage.AWAITING_SYNC
    }

    private val mutableState = MutableStateFlow(State())
    val state = mutableState.asStateFlow()
    private val sequence = AtomicInteger(1)
    private var timeout: Job? = null
    private var bpInformationTimeout: Job? = null
    private var bpSyncTimeout: Job? = null
    private var syncBpAfterInformation = false
    private val pendingActivation = mutableMapOf<Int, Pair<HealthMonitorProtocol.Channel, String>>()
    private val supported =
        listOf(HealthMonitorProtocol.Channel.ECG, HealthMonitorProtocol.Channel.BP)

    @Synchronized
    fun connect() {
        if (state.value.connection != Connection.DISCONNECTED) return
        timeout?.cancel()
        mutableState.update {
            it.copy(connection = Connection.CONNECTING, information = emptyMap(), error = null)
        }
        if (
            !send(HealthMonitorProtocol.PLAIN_CONNECTION, JSONObject().put("action", "connection"))
        ) {
            mutableState.update {
                it.copy(
                    connection = Connection.DISCONNECTED,
                    error = uiText(R.string.monitor_connection_unavailable),
                )
            }
            finishBpReview()
            return
        }
        log("[健康监测器] 请求明文传输握手")
        timeout =
            scope.launch {
                delay(10_000)
                synchronized(this@HealthMonitorSession) {
                    if (state.value.connection == Connection.CONNECTING) {
                        mutableState.update {
                            it.copy(
                                connection = Connection.DISCONNECTED,
                                error = uiText(R.string.monitor_handshake_timeout),
                            )
                        }
                        finishBpReview()
                        log("[健康监测器] 握手未确认")
                    }
                }
            }
    }

    @Synchronized
    fun disconnect() {
        timeout?.cancel()
        finishBpReview()
        pendingActivation.clear()
        mutableState.update {
            it.copy(
                connection = Connection.DISCONNECTED,
                ecgActivated = false,
                bpActivated = false,
                information = emptyMap(),
                bpReviewedInformation = null,
                bpCalibrationStep = BpCalibrationStep.Idle,
                error = null,
            )
        }
    }

    /** One explicit status check, continued after the transport handshake without polling. */
    @Synchronized
    fun reviewBp(syncRecords: Boolean = true): Boolean {
        syncBpAfterInformation = syncBpAfterInformation || syncRecords
        if (state.value.bpReviewStage != BpReviewStage.IDLE) return true
        mutableState.update {
            it.copy(
                information = it.information - HealthMonitorProtocol.Channel.BP,
                bpReviewStage = BpReviewStage.AWAITING_INFORMATION,
                bpReviewedInformation = null,
                error = null,
            )
        }
        if (state.value.connection == Connection.READY) return requestBpInformation()
        connect()
        return state.value.connection != Connection.DISCONNECTED
    }

    private fun requestBpInformation(): Boolean {
        if (!request(HealthMonitorProtocol.Channel.BP, "information")) {
            finishBpReview()
            mutableState.update { it.copy(error = uiText(R.string.monitor_connection_unavailable)) }
            return false
        }
        bpInformationTimeout?.cancel()
        bpInformationTimeout =
            scope.launch {
                delay(10_000)
                synchronized(this@HealthMonitorSession) {
                    if (state.value.bpReviewStage == BpReviewStage.AWAITING_INFORMATION) {
                        finishBpReview()
                        mutableState.update {
                            it.copy(error = uiText(R.string.monitor_bp_information_unconfirmed))
                        }
                    }
                }
            }
        return true
    }

    private fun finishBpReview() {
        bpInformationTimeout?.cancel()
        bpInformationTimeout = null
        bpSyncTimeout?.cancel()
        bpSyncTimeout = null
        syncBpAfterInformation = false
        mutableState.update { it.copy(bpReviewStage = BpReviewStage.IDLE) }
    }

    private fun requestReviewedBpSync() {
        mutableState.update { it.copy(bpReviewStage = BpReviewStage.AWAITING_SYNC) }
        if (!requestSync(HealthMonitorProtocol.Channel.BP)) {
            finishBpReview()
            mutableState.update { it.copy(error = uiText(R.string.monitor_connection_unavailable)) }
            return
        }
        bpSyncTimeout =
            scope.launch {
                delay(15_000)
                synchronized(this@HealthMonitorSession) {
                    if (state.value.bpReviewStage == BpReviewStage.AWAITING_SYNC) {
                        finishBpReview()
                        mutableState.update {
                            it.copy(error = uiText(R.string.monitor_bp_sync_unconfirmed))
                        }
                    }
                }
            }
    }

    /** Explicit user action: ask the watch to enter Samsung's own calibration flow. */
    @Synchronized
    fun startBpCalibration(): Boolean {
        var dispatched = false
        if (state.value.connection == Connection.READY) {
            dispatched =
                request(HealthMonitorProtocol.Channel.BP, "do_calibration", endpoint = "measuring")
        }
        mutableState.update {
            it.copy(
                error = if (dispatched) null else uiText(R.string.monitor_connection_unavailable)
            )
        }
        return dispatched
    }

    /** 启动完整的三轮袖带血压校准编排流程（第 1 轮准备） */
    @Synchronized
    fun startBpCalibrationWorkflow(): Boolean {
        if (state.value.connection != Connection.READY) {
            connect()
            mutableState.update { it.copy(error = uiText(R.string.connecting_to_health_monitor)) }
            return false
        }
        mutableState.update {
            it.copy(bpCalibrationStep = BpCalibrationStep.Preparing(round = 1), error = null)
        }
        val seq = sequence.incrementAndGet()
        val sent =
            send(
                HealthMonitorProtocol.Channel.BP.path,
                HealthMonitorProtocol.prepareCalibration(seq),
            )
        if (!sent) {
            mutableState.update {
                it.copy(
                    bpCalibrationStep =
                        BpCalibrationStep.Failed(uiText(R.string.monitor_connection_unavailable)),
                    error = uiText(R.string.monitor_connection_unavailable),
                )
            }
        }
        return sent
    }

    /** 触发当前轮次的光学 PPG 采样（30 秒） */
    @Synchronized
    fun startBpCalibrationMeasurement(): Boolean {
        if (state.value.connection != Connection.READY) {
            mutableState.update { it.copy(error = uiText(R.string.monitor_connection_unavailable)) }
            return false
        }
        val step = state.value.bpCalibrationStep
        val round = if (step is BpCalibrationStep.Preparing) step.round else 1
        mutableState.update {
            it.copy(bpCalibrationStep = BpCalibrationStep.Measuring(round = round), error = null)
        }
        val seq = sequence.incrementAndGet()
        val sent =
            send(HealthMonitorProtocol.Channel.BP.path, HealthMonitorProtocol.startCalibration(seq))
        if (!sent) {
            mutableState.update {
                it.copy(
                    bpCalibrationStep =
                        BpCalibrationStep.Failed(uiText(R.string.monitor_connection_unavailable)),
                    error = uiText(R.string.monitor_connection_unavailable),
                )
            }
        }
        return sent
    }

    /** 提交本轮物理血压计袖带测量值 */
    @Synchronized
    fun submitBpCalibrationCuff(systolic: Int, diastolic: Int): Boolean {
        val step = state.value.bpCalibrationStep
        if (step !is BpCalibrationStep.WaitingCuffInput) return false
        if (state.value.connection != Connection.READY) {
            mutableState.update { it.copy(error = uiText(R.string.monitor_connection_unavailable)) }
            return false
        }
        mutableState.update {
            it.copy(
                bpCalibrationStep = BpCalibrationStep.Submitting(round = step.round),
                error = null,
            )
        }
        val seq = sequence.incrementAndGet()
        val sent =
            send(
                HealthMonitorProtocol.Channel.BP.path,
                HealthMonitorProtocol.updateCalibration(
                    sequence = seq,
                    refSystolic = systolic,
                    refDiastolic = diastolic,
                    nth = step.round,
                    datauuid = step.dataUuid,
                ),
            )
        if (!sent) {
            mutableState.update {
                it.copy(
                    bpCalibrationStep =
                        BpCalibrationStep.Failed(uiText(R.string.monitor_connection_unavailable)),
                    error = uiText(R.string.monitor_connection_unavailable),
                )
            }
        }
        return sent
    }

    /** 取消当前血压校准 */
    @Synchronized
    fun cancelBpCalibration(): Boolean {
        if (state.value.bpCalibrationStep == BpCalibrationStep.Idle) return false
        mutableState.update { it.copy(bpCalibrationStep = BpCalibrationStep.Idle) }
        if (state.value.connection != Connection.READY) return true
        val seq = sequence.incrementAndGet()
        return send(
            HealthMonitorProtocol.Channel.BP.path,
            HealthMonitorProtocol.cancelCalibration(seq),
        )
    }

    /** 重置校准步骤（用于完成或错误后关闭界面） */
    @Synchronized
    fun resetBpCalibrationStep() {
        mutableState.update { it.copy(bpCalibrationStep = BpCalibrationStep.Idle) }
    }

    /** Explicit user action only. The existing watch profile and BP calibration are untouched. */
    @Synchronized
    fun activateEcg(wristPosition: String = "left"): Boolean {
        require(wristPosition in setOf("left", "right"))
        val terms = sequence.incrementAndGet()
        val onboarding = sequence.incrementAndGet()
        val sentTerms =
            send(
                "/992",
                HealthMonitorProtocol.termsAndCondition(HealthMonitorProtocol.Channel.ECG, terms),
            )
        if (sentTerms) {
            pendingActivation[terms] = HealthMonitorProtocol.Channel.ECG to "terms_and_condition"
        }
        val sentOnboarding =
            send("/992", HealthMonitorProtocol.ecgOnboarding(onboarding, wristPosition))
        if (sentOnboarding) {
            pendingActivation[onboarding] = HealthMonitorProtocol.Channel.ECG to "onboarding"
        }
        val sent = sentTerms || sentOnboarding
        if (state.value.connection != Connection.READY) connect()
        return sent
    }

    /**
     * Explicit user action: accepts BP terms and conditions on watch without physical Samsung
     * phone.
     */
    @Synchronized
    fun activateBp(): Boolean {
        val terms = sequence.incrementAndGet()
        val sent =
            send(
                HealthMonitorProtocol.Channel.BP.path,
                HealthMonitorProtocol.termsAndCondition(HealthMonitorProtocol.Channel.BP, terms),
            )
        if (sent) {
            pendingActivation[terms] = HealthMonitorProtocol.Channel.BP to "terms_and_condition"
        }
        if (state.value.connection != Connection.READY) connect()
        return sent
    }

    private fun markReady() {
        val wasReady = state.value.connection == Connection.READY
        timeout?.cancel()
        mutableState.update {
            it.copy(
                connection = Connection.READY,
                error = null,
                receivedCount = it.receivedCount + 1,
            )
        }
        log("[健康监测器] 明文传输握手已确认")
        if (!wasReady) supported.forEach { request(it, "connection") }
        if (!wasReady && state.value.bpReviewStage == BpReviewStage.AWAITING_INFORMATION)
            requestBpInformation()
    }

    @Synchronized
    fun receive(path: String, bytes: ByteArray) {
        try {
            val packet = JSONObject(bytes.toString(Charsets.UTF_8))
            if (path == HealthMonitorProtocol.PLAIN_CONNECTION) {
                if (packet.optString("action") != "connection") return
                markReady()
                return
            }
            val channel = HealthMonitorProtocol.Channel.fromPath(path) ?: return
            if (path == channel.controlPath) {
                val type = packet.optString("type")
                if (type == "disable") {
                    // Watch confirmed disable on unused channel (e.g. 994c APNEA) — proves
                    // Wearable transport and monitor daemon are READY
                    if (state.value.connection != Connection.READY) {
                        markReady()
                    }
                } else if (type == "request_connection") {
                    // A recovery request is evidence that the watch has no session. It is never
                    // READY.
                    if (state.value.connection == Connection.READY) disconnect()
                    connect()
                }
                return
            }
            if (state.value.connection == Connection.CONNECTING) {
                markReady()
            }
            val message = HealthMonitorProtocol.decode(packet)
            if (message.type == "DATA") {
                receiveSync(channel, message.body)
                return
            }
            mutableState.update { it.copy(receivedCount = it.receivedCount + 1) }
            log("[健康监测器] ${channel.name} ${message.message} action=${message.action}")
            if (message.action == "information") {
                if (state.value.connection != Connection.READY) return
                val bp = channel == HealthMonitorProtocol.Channel.BP
                // Older SHM versions generate their own sequence, rather than echoing ours.
                // A response outside an active review must not revive a timed-out status.
                if (
                    bp &&
                        message.message == "RESPONSE" &&
                        state.value.bpReviewStage != BpReviewStage.AWAITING_INFORMATION
                )
                    return
                if (
                    message.message == "RESPONSE" &&
                        message.result.isNotBlank() &&
                        !message.result.equals("success", ignoreCase = true)
                ) {
                    if (bp) finishBpReview()
                    mutableState.update {
                        it.copy(
                            information = it.information - channel,
                            bpReviewedInformation = if (bp) null else it.bpReviewedInformation,
                            error =
                                uiText(
                                    if (bp) R.string.monitor_bp_information_unconfirmed
                                    else R.string.monitor_ecg_information_unconfirmed
                                ),
                        )
                    }
                    return
                }
                check(message.data.length() > 0) { "Empty information" }
                val syncBp =
                    bp &&
                        state.value.bpReviewStage == BpReviewStage.AWAITING_INFORMATION &&
                        syncBpAfterInformation
                if (bp && state.value.bpReviewStage == BpReviewStage.AWAITING_INFORMATION)
                    finishBpReview()
                mutableState.update {
                    it.copy(
                        information = it.information + (channel to message.data.toString()),
                        bpReviewedInformation = if (bp) null else it.bpReviewedInformation,
                        error = null,
                    )
                }
                if (message.message == "REQUEST" && channel in supported) {
                    val acknowledged =
                        send(
                            channel.path,
                            HealthMonitorProtocol.informationResponse(channel, message.sequence),
                        )
                    if (!acknowledged) {
                        mutableState.update {
                            it.copy(error = uiText(R.string.monitor_connection_unavailable))
                        }
                        return
                    }
                    if (!syncBp && (!bp || !state.value.bpSyncPending)) requestSync(channel)
                }
                if (syncBp) requestReviewedBpSync()
            }
            val pending = pendingActivation[message.sequence]
            if (message.message == "RESPONSE" && pending == (channel to message.action)) {
                pendingActivation.remove(message.sequence)
                if (message.result.equals("success", true)) {
                    if (
                        channel == HealthMonitorProtocol.Channel.ECG &&
                            message.action == "onboarding"
                    ) {
                        mutableState.update { it.copy(ecgActivated = true) }
                    } else if (channel == HealthMonitorProtocol.Channel.BP)
                        mutableState.update { it.copy(bpActivated = true) }
                } else
                    mutableState.update {
                        it.copy(error = uiText(R.string.monitor_activation_unconfirmed))
                    }
            }
            if (channel == HealthMonitorProtocol.Channel.BP) {
                when (message.action) {
                    "prepare_calibration" -> {
                        val currentStep = state.value.bpCalibrationStep
                        if (currentStep !is BpCalibrationStep.Preparing) {
                            log("[健康监测器] 忽略过期的 prepare_calibration 回调：当前步骤为 $currentStep")
                            return
                        }
                        val currentRound = currentStep.round
                        if (message.result.equals("success", ignoreCase = true)) {
                            mutableState.update {
                                it.copy(
                                    bpCalibrationStep = BpCalibrationStep.Preparing(currentRound),
                                    error = null,
                                )
                            }
                        } else {
                            mutableState.update {
                                it.copy(
                                    bpCalibrationStep =
                                        BpCalibrationStep.Failed(
                                            uiText(R.string.bp_calibration_measurement_failed),
                                            round = currentRound,
                                        )
                                )
                            }
                        }
                    }
                    "start_calibration" -> {
                        val currentStep = state.value.bpCalibrationStep
                        if (currentStep !is BpCalibrationStep.Measuring) {
                            log("[健康监测器] 忽略过期的 start_calibration 回调：当前步骤为 $currentStep")
                            return
                        }
                        val currentRound = currentStep.round
                        if (message.result.equals("success", ignoreCase = true)) {
                            val dataUuid = message.data.optString("datauuid")
                            val hr = message.data.optInt("hr", 0)
                            if (dataUuid.isNotBlank()) {
                                mutableState.update {
                                    it.copy(
                                        bpCalibrationStep =
                                            BpCalibrationStep.WaitingCuffInput(
                                                round = currentRound,
                                                dataUuid = dataUuid,
                                                heartRate = hr,
                                            ),
                                        error = null,
                                    )
                                }
                            } else {
                                mutableState.update {
                                    it.copy(
                                        bpCalibrationStep =
                                            BpCalibrationStep.Failed(
                                                uiText(R.string.bp_calibration_measurement_failed),
                                                round = currentRound,
                                            )
                                    )
                                }
                            }
                        } else {
                            val errorRes =
                                when (message.result.lowercase(Locale.ROOT)) {
                                    "screen_off",
                                    "lock_screen" -> R.string.bp_calibration_error_lock_screen
                                    "cancel",
                                    "cancelled" -> R.string.bp_calibration_error_cancelled
                                    "no_permission" -> R.string.bp_calibration_error_no_permission
                                    else -> R.string.bp_calibration_measurement_failed
                                }
                            mutableState.update {
                                it.copy(
                                    bpCalibrationStep =
                                        BpCalibrationStep.Failed(
                                            uiText(errorRes),
                                            round = currentRound,
                                        )
                                )
                            }
                        }
                    }
                    "update_calibration" -> {
                        val currentStep = state.value.bpCalibrationStep
                        if (currentStep !is BpCalibrationStep.Submitting) {
                            log("[健康监测器] 忽略过期的 update_calibration 回调：当前步骤为 $currentStep")
                            return
                        }
                        val currentRound = currentStep.round
                        if (message.result.equals("success", ignoreCase = true)) {
                            if (currentRound < 3) {
                                val nextRound = currentRound + 1
                                mutableState.update {
                                    it.copy(
                                        bpCalibrationStep =
                                            BpCalibrationStep.Preparing(round = nextRound),
                                        error = null,
                                    )
                                }
                                val seq = sequence.incrementAndGet()
                                send(
                                    HealthMonitorProtocol.Channel.BP.path,
                                    HealthMonitorProtocol.prepareCalibration(seq),
                                )
                            } else {
                                val isRecalibration =
                                    BpCalibrationStatus.from(
                                        state.value.information[HealthMonitorProtocol.Channel.BP],
                                        nowMillis(),
                                    ) != BpCalibrationStatus.State.REQUIRED
                                val seq = sequence.incrementAndGet()
                                send(
                                    HealthMonitorProtocol.Channel.BP.path,
                                    HealthMonitorProtocol.initialCalibration(
                                        seq,
                                        isRecalibration = isRecalibration,
                                    ),
                                )
                            }
                        } else {
                            mutableState.update {
                                it.copy(
                                    bpCalibrationStep =
                                        BpCalibrationStep.Failed(
                                            uiText(R.string.bp_calibration_update_failed),
                                            round = currentRound,
                                        )
                                )
                            }
                        }
                    }
                    "initial_calibration",
                    "re_calibration" -> {
                        val currentStep = state.value.bpCalibrationStep
                        if (
                            currentStep !is BpCalibrationStep.Submitting || currentStep.round != 3
                        ) {
                            log("[健康监测器] 忽略过期的 ${message.action} 回调：当前步骤为 $currentStep")
                            return
                        }
                        if (message.result.equals("success", ignoreCase = true)) {
                            mutableState.update {
                                it.copy(
                                    bpCalibrationStep = BpCalibrationStep.Completed,
                                    error = null,
                                )
                            }
                            if (state.value.connection == Connection.READY) {
                                reviewBp(syncRecords = true)
                            }
                        } else {
                            mutableState.update {
                                it.copy(
                                    bpCalibrationStep =
                                        BpCalibrationStep.Failed(
                                            uiText(R.string.bp_calibration_finalize_failed),
                                            round = 3,
                                        )
                                )
                            }
                        }
                    }
                    "cancel_calibration" -> {
                        val currentStep = state.value.bpCalibrationStep
                        if (currentStep is BpCalibrationStep.Failed) {
                            mutableState.update {
                                it.copy(bpCalibrationStep = BpCalibrationStep.Idle)
                            }
                        }
                    }
                }
            }
        } catch (error: Exception) {
            if (HealthMonitorProtocol.Channel.fromPath(path) == HealthMonitorProtocol.Channel.BP) {
                finishBpReview()
                mutableState.update {
                    it.copy(
                        information = it.information - HealthMonitorProtocol.Channel.BP,
                        bpReviewedInformation = null,
                    )
                }
            }
            mutableState.update { it.copy(error = uiText(R.string.monitor_parse_failed)) }
            log("[健康监测器] 解析失败 path=$path bytes=${bytes.size} ${error.javaClass.simpleName}")
        }
    }

    /** Opens the watch's own BP measurement flow; it does not change calibration or profile. */
    @Synchronized
    fun startBpMeasurement(): Boolean =
        if (state.value.connection != Connection.READY) {
            mutableState.update { it.copy(error = uiText(R.string.monitor_connection_unavailable)) }
            false
        } else if (
            state.value.bpInformationPending ||
                BpCalibrationStatus.from(
                    state.value.information[HealthMonitorProtocol.Channel.BP],
                    nowMillis(),
                ) != BpCalibrationStatus.State.CURRENT
        ) {
            mutableState.update {
                it.copy(error = uiText(R.string.bp_measurement_needs_calibration))
            }
            false
        } else {
            val dispatched =
                request(HealthMonitorProtocol.Channel.BP, "do_measure", endpoint = "measuring")
            mutableState.update {
                it.copy(
                    error =
                        if (dispatched) null else uiText(R.string.monitor_connection_unavailable)
                )
            }
            dispatched
        }

    @Synchronized
    fun requestSync(channel: HealthMonitorProtocol.Channel): Boolean {
        if (state.value.connection != Connection.READY || channel !in supported) return false
        return send(
            channel.path,
            HealthMonitorProtocol.syncRequest(channel, sequence.incrementAndGet()),
        )
    }

    /**
     * Channel jobs are already gzip decoded and carry message_info.id, independent of outer
     * sequence.
     */
    @Synchronized
    fun receiveSync(channel: HealthMonitorProtocol.Channel, body: JSONObject) {
        val id: Int
        val rows: JSONArray
        try {
            val info = body.getJSONObject("message_info")
            if (info.optString("action") != "SYNC_DATA" || info.optString("type") == "RESPONSE")
                return
            id = info.getInt("id")
            rows = body.getJSONArray("data")
        } catch (_: Exception) {
            if (channel == HealthMonitorProtocol.Channel.BP) finishBpReview()
            mutableState.update {
                it.copy(
                    bpReviewedInformation =
                        if (channel == HealthMonitorProtocol.Channel.BP) null
                        else it.bpReviewedInformation,
                    error = uiText(R.string.monitor_parse_failed),
                )
            }
            return
        }
        var persisted = channel in supported
        var recordCount = 0
        try {
            val module =
                if (channel == HealthMonitorProtocol.Channel.ECG) "com.samsung.health.ecg"
                else "com.samsung.health.bp"
            val records = mutableListOf<JSONObject>()
            val configurations = mutableListOf<JSONObject>()
            for (i in 0 until rows.length()) {
                val row = rows.getJSONObject(i)
                val named = if (row.has(module)) row.getJSONArray(module) else null
                val configuration =
                    if (
                        channel == HealthMonitorProtocol.Channel.BP &&
                            row.has("com.samsung.health.bp.configuration")
                    )
                        row.getJSONArray("com.samsung.health.bp.configuration")
                    else null
                if (named != null) {
                    repeat(named.length()) { records += named.getJSONObject(it) }
                }
                if (configuration != null) {
                    repeat(configuration.length()) {
                        configurations += configuration.getJSONObject(it)
                    }
                }
                if (named == null && configuration == null) records += row
            }
            if (configurations.isNotEmpty()) {
                check(onBpConfigurationsReceived(configurations)) {
                    "BP configuration persistence failed"
                }
            }
            recordCount = records.size
            for (row in records) {
                if (channel == HealthMonitorProtocol.Channel.ECG) {
                    val record = EcgRecord.parse(row) ?: error("Invalid ECG row")
                    check(onEcgReceived(record)) { "ECG persistence failed" }
                    mutableState.update { it.copy(lastEcg = record) }
                } else if (channel == HealthMonitorProtocol.Channel.BP) {
                    val record = BpRecord.parse(row) ?: error("Invalid BP row")
                    check(onBpReceived(record)) { "BP persistence failed" }
                    mutableState.update { it.copy(lastBp = record) }
                }
            }
        } catch (error: Exception) {
            persisted = false
            if (channel == HealthMonitorProtocol.Channel.BP) finishBpReview()
            mutableState.update {
                it.copy(
                    bpReviewedInformation =
                        if (channel == HealthMonitorProtocol.Channel.BP) null
                        else it.bpReviewedInformation,
                    error = uiText(R.string.monitor_save_failed),
                )
            }
            log("[健康监测器] ${channel.name} 同步未保存 ${error.javaClass.simpleName}")
        }
        if (persisted) {
            val activeReviewSync = state.value.bpSyncPending
            val finalChunk =
                body.optJSONObject("device_info")?.optBoolean("is_last_chunk", true) != false
            val acknowledged =
                send(channel.path, HealthMonitorProtocol.syncResponse(channel, id, true))
            val reviewed =
                acknowledged &&
                    channel == HealthMonitorProtocol.Channel.BP &&
                    activeReviewSync &&
                    finalChunk
            if (channel == HealthMonitorProtocol.Channel.BP && (!acknowledged || reviewed)) {
                finishBpReview()
            }
            mutableState.update {
                it.copy(
                    receivedCount = it.receivedCount + recordCount,
                    bpReviewedInformation =
                        if (reviewed) it.information[HealthMonitorProtocol.Channel.BP]
                        else it.bpReviewedInformation,
                    error =
                        if (acknowledged) null else uiText(R.string.monitor_connection_unavailable),
                )
            }
            log("[健康监测器] ${channel.name} 同步已落盘 id=$id records=$recordCount")
            if (
                acknowledged &&
                    channel == HealthMonitorProtocol.Channel.BP &&
                    !activeReviewSync &&
                    finalChunk &&
                    state.value.connection == Connection.READY
            ) {
                reviewBp(syncRecords = false)
            }
        }
    }

    @Synchronized
    fun request(
        channel: HealthMonitorProtocol.Channel,
        action: String,
        data: JSONObject = JSONObject(),
        endpoint: String = "common",
    ): Boolean {
        if (state.value.connection != Connection.READY) return false
        return send(
            channel.path,
            HealthMonitorProtocol.request(
                channel,
                action,
                sequence.incrementAndGet(),
                data,
                endpoint,
            ),
        )
    }
}
