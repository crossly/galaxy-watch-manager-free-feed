package dev.ricky.galaxywatchmanagerfree.ui.screens

import android.content.res.Resources
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Watch
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.feature.NotificationBarConfig
import dev.ricky.galaxywatchmanagerfree.feature.NotificationBarPreferences
import dev.ricky.galaxywatchmanagerfree.feature.WatchState
import dev.ricky.galaxywatchmanagerfree.ui.components.GroupedCard
import dev.ricky.galaxywatchmanagerfree.ui.components.GroupedDivider
import dev.ricky.galaxywatchmanagerfree.ui.components.SectionHeader
import dev.ricky.galaxywatchmanagerfree.ui.components.SettingSwitchRow
import dev.ricky.galaxywatchmanagerfree.ui.components.StatusOrb
import dev.ricky.galaxywatchmanagerfree.ui.theme.CardBorder
import dev.ricky.galaxywatchmanagerfree.ui.theme.CardSurfaceElevated
import dev.ricky.galaxywatchmanagerfree.ui.theme.ElectricBlue
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextPrimary
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextSecondary
import java.text.NumberFormat
import java.util.Locale

/** 手机常驻状态栏通知个性化设置页面。 支持用户自定义是否在状态栏展示电量、心率、步数、卡路里、睡眠、距离与压力等实时指标。 */
@Composable
fun NotificationBarSettingsScreen(state: WatchState, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val strings = context.resources
    val config by NotificationBarPreferences.config.collectAsState()

    fun update(mutate: (NotificationBarConfig) -> NotificationBarConfig) {
        val next = mutate(config)
        NotificationBarPreferences.update(context, next)
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        // 效果预览卡片
        item {
            SectionHeader(strings.getString(R.string.notification_bar_preview))
            GroupedCard(cornerRadius = 24.dp, innerPadding = 18.dp) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        StatusOrb(
                            icon = Icons.Default.NotificationsActive,
                            color = ElectricBlue,
                            active = state.sessionReady,
                        )
                        Spacer(Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            // 标题：自定义昵称优先
                            val title =
                                state.displayName.ifBlank { strings.getString(R.string.app_name) }
                            Text(
                                text = title,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary,
                            )
                            Spacer(Modifier.height(2.dp))
                            val statusText =
                                when {
                                    state.sessionReady ->
                                        strings.getString(R.string.notif_connection_ready)
                                    state.connected ->
                                        strings.getString(R.string.notif_connection_connecting)
                                    else -> strings.getString(R.string.notif_service_running)
                                }
                            Text(
                                text = statusText,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                            )
                        }
                    }

                    Spacer(Modifier.height(14.dp))

                    // 模拟通知内容预览条
                    val previewMetrics = buildMetricsPreview(state, config, strings)
                    Box(
                        modifier =
                            Modifier.fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(CardSurfaceElevated)
                                .border(0.5.dp, CardBorder, RoundedCornerShape(12.dp))
                                .padding(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Watch,
                                contentDescription = null,
                                tint = ElectricBlue,
                                modifier = Modifier.size(18.dp),
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = previewMetrics,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextPrimary,
                                lineHeight = 18.sp,
                            )
                        }
                    }

                    Spacer(Modifier.height(10.dp))
                    Text(
                        text = strings.getString(R.string.notification_bar_nickname_tip),
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary,
                        lineHeight = 16.sp,
                    )
                }
            }
        }

        // 显示指标开关列表
        item {
            SectionHeader(strings.getString(R.string.notification_bar_metrics_group))
            GroupedCard(innerPadding = 16.dp) {
                // 手表电量
                SettingSwitchRow(
                    title = strings.getString(R.string.notification_bar_battery),
                    subtitle = strings.getString(R.string.notification_bar_battery_desc),
                    checked = config.showBattery,
                    onCheckedChange = { checked -> update { it.copy(showBattery = checked) } },
                )
                GroupedDivider()

                // 实时心率
                SettingSwitchRow(
                    title = strings.getString(R.string.notification_bar_heart_rate),
                    subtitle = strings.getString(R.string.notification_bar_heart_rate_desc),
                    checked = config.showHeartRate,
                    onCheckedChange = { checked -> update { it.copy(showHeartRate = checked) } },
                )
                GroupedDivider()

                // 今日步数
                SettingSwitchRow(
                    title = strings.getString(R.string.notification_bar_steps),
                    subtitle = strings.getString(R.string.notification_bar_steps_desc),
                    checked = config.showSteps,
                    onCheckedChange = { checked -> update { it.copy(showSteps = checked) } },
                )
                GroupedDivider()

                // 卡路里消耗
                SettingSwitchRow(
                    title = strings.getString(R.string.notification_bar_calories),
                    subtitle = strings.getString(R.string.notification_bar_calories_desc),
                    checked = config.showCalories,
                    onCheckedChange = { checked -> update { it.copy(showCalories = checked) } },
                )
                GroupedDivider()

                // 睡眠时长
                SettingSwitchRow(
                    title = strings.getString(R.string.notification_bar_sleep),
                    subtitle = strings.getString(R.string.notification_bar_sleep_desc),
                    checked = config.showSleep,
                    onCheckedChange = { checked -> update { it.copy(showSleep = checked) } },
                )
                GroupedDivider()

                // 活动距离
                SettingSwitchRow(
                    title = strings.getString(R.string.notification_bar_distance),
                    subtitle = strings.getString(R.string.notification_bar_distance_desc),
                    checked = config.showDistance,
                    onCheckedChange = { checked -> update { it.copy(showDistance = checked) } },
                )
                GroupedDivider()

                // 压力指数
                SettingSwitchRow(
                    title = strings.getString(R.string.notification_bar_stress),
                    subtitle = strings.getString(R.string.notification_bar_stress_desc),
                    checked = config.showStress,
                    onCheckedChange = { checked -> update { it.copy(showStress = checked) } },
                )
            }
        }
    }
}

private fun buildMetricsPreview(
    state: WatchState,
    config: NotificationBarConfig,
    strings: Resources,
): String {
    val numberFormat = NumberFormat.getIntegerInstance(strings.configuration.locales[0])
    val parts = mutableListOf<String>()

    val battery = state.batteryLevel.takeIf { it in 0..100 } ?: 82
    val heartRate = state.latestHeartRate?.bpm ?: state.lastHeartRate.takeIf { it > 0 } ?: 72
    val steps = state.todaySteps.takeIf { it >= 0 } ?: 6540
    val goal = state.stepGoal.takeIf { it > 0 } ?: 8000
    val progress = ((steps.toLong() * 100L) / goal).coerceIn(0L, 100L).toInt()
    val calories = state.todayCalories.takeIf { it > 0f }?.toInt() ?: 380
    val sleepMinutes =
        state.sleep?.displayMinutes
            ?: state.sleepSessions.maxByOrNull { it.endMillis }?.displayMinutes
            ?: state.weekSleep.lastOrNull()?.takeIf { it > 0 }
            ?: 445
    val distanceMeters = state.todayDistanceMeters.takeIf { it > 0f } ?: 4500f
    val stress = state.latestStress?.score?.toInt() ?: state.lastStressScore.takeIf { it > 0 } ?: 35

    if (config.showBattery) {
        parts.add(strings.getString(R.string.notif_battery_metric, battery))
    }
    if (config.showHeartRate) {
        parts.add(strings.getString(R.string.notif_heart_rate_metric, heartRate))
    }
    if (config.showSteps) {
        parts.add(
            strings.getString(
                R.string.notif_steps_metric,
                numberFormat.format(steps),
                numberFormat.format(goal),
                progress,
            )
        )
    }
    if (config.showCalories) {
        parts.add(strings.getString(R.string.notif_calories_metric, calories))
    }
    if (config.showSleep) {
        val h = sleepMinutes / 60
        val m = sleepMinutes % 60
        parts.add(strings.getString(R.string.notif_sleep_metric, h, m))
    }
    if (config.showDistance) {
        val km = distanceMeters / 1000f
        parts.add(
            strings.getString(
                R.string.notif_distance_metric,
                String.format(Locale.getDefault(), "%.1f", km),
            )
        )
    }
    if (config.showStress) {
        parts.add(strings.getString(R.string.notif_stress_metric, stress))
    }

    return if (parts.isEmpty()) {
        strings.getString(R.string.notif_service_running)
    } else {
        parts.joinToString(" · ")
    }
}
