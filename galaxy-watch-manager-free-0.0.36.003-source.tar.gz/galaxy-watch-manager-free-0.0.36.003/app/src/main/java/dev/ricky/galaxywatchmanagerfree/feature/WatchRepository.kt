package dev.ricky.galaxywatchmanagerfree.feature

import android.content.Context
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.core.UiNotify
import dev.ricky.galaxywatchmanagerfree.feature.monitor.HealthMonitorProtocol
import dev.ricky.galaxywatchmanagerfree.feature.monitor.HealthMonitorSession
import dev.ricky.galaxywatchmanagerfree.wcs.WcsFrame
import dev.ricky.galaxywatchmanagerfree.wcs.WcsPaths
import dev.ricky.galaxywatchmanagerfree.wcs.WcsSession
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

class WatchRepository(
    private val context: Context,
    private val session: WcsSession,
    private val isCurrent: () -> Boolean = { true },
) : WcsSession.Observer {

    private val queryPrefs = context.getSharedPreferences("watchfree_sync", Context.MODE_PRIVATE)
    private var queryPolicy =
        AutoQueryPolicy.fromPreferences(
            queryPrefs.getBoolean("enabled", true),
            queryPrefs.getInt("interval_seconds", AutoQueryPolicy.DEFAULT_INTERVAL_SECONDS),
        )
    private val _state =
        MutableStateFlow(
            WatchState(
                watchNode = session.watchNode,
                phoneNode = session.phoneNode,
                autoRefresh = queryPolicy.enabled,
                autoQueryIntervalSeconds = queryPolicy.intervalSeconds,
            )
        )
    val state: StateFlow<WatchState> = _state.asStateFlow()

    private val _apps = MutableStateFlow<List<String>>(emptyList())
    val apps: StateFlow<List<String>> = _apps.asStateFlow()

    private val _watchfaceOrder = MutableStateFlow<List<Int>>(emptyList())
    val watchfaceOrder: StateFlow<List<Int>> = _watchfaceOrder.asStateFlow()

    private val closed = java.util.concurrent.atomic.AtomicBoolean(false)
    private val resourcesClosed = java.util.concurrent.atomic.AtomicBoolean(false)

    private fun isActive(): Boolean = !closed.get() && isCurrent()

    @Volatile private var connectionGeneration = Any()

    val notificationSession: Any?
        get() = connectionGeneration.takeIf { isActive() && _state.value.sessionReady }

    private val backgroundScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val refresh =
        RefreshCoordinator(
            scope = backgroundScope,
            onRunning = { running -> _state.update { it.copy(refreshing = running) } },
            onLog = LogBus::log,
        )

    val healthMeasurements: HealthMeasurements =
        HealthMeasurements(
            context = context,
            peerAddress = session.peerAddress.orEmpty(),
            scope = backgroundScope,
            watchNode = { session.watchNode },
            send = { packet ->
                isActive() &&
                    _state.value.sessionReady &&
                    session.sendRawJson(
                        WcsPaths.HEALTH_MESSAGE,
                        packet,
                        senderPkg = WcsPaths.PKG_SHEALTH,
                        senderNode = WcsPaths.SIGNATURE_SHEALTH,
                    )
            },
            requestReadback = { healthRepo.requestRecovery() },
        )

    /** 健康数据管线（采样解析、本地档案、投影、持久化、同步握手）。 */
    private val healthRepo: HealthRepository =
        HealthRepository(
            context = context,
            session = session,
            scope = backgroundScope,
            state = _state,
            isActive = ::isActive,
            onMeasurementPreferences = healthMeasurements::receivePreferences,
            onSyncStatus = { status ->
                if (
                    status == HealthSyncCoordinator.Status.IDLE ||
                        status == HealthSyncCoordinator.Status.TIMED_OUT ||
                        status == HealthSyncCoordinator.Status.DISCONNECTED
                ) {
                    refresh.confirm(RefreshCoordinator.Target.HEALTH)
                }
            },
        )

    private val autoQueries =
        AutoQueryCoordinator(
            scope = backgroundScope,
            queryBattery = {
                runCatching { requestBattery() }.onFailure { LogBus.error("[自动查询] 电量请求失败", it) }
            },
            queryHealth = { healthRepo.requestSync() },
            initialPolicy = queryPolicy,
        )
    private val queryPreferenceListener =
        android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key == "enabled" || key == "interval_seconds") {
                applyQueryPolicy(
                    AutoQueryPolicy.fromPreferences(
                        queryPrefs.getBoolean("enabled", true),
                        queryPrefs.getInt(
                            "interval_seconds",
                            AutoQueryPolicy.DEFAULT_INTERVAL_SECONDS,
                        ),
                    )
                )
            }
        }

    /** 最近 25 个健康数据包（诊断用）。 */
    val health: StateFlow<List<HealthPacket>> = healthRepo.packets

    private val settingCommands =
        SettingCommands(
            backgroundScope,
            onDebug = LogBus::debug,
            onError = { failure ->
                when (failure) {
                    SettingCommands.Failure.SEND_FAILED -> {
                        UiNotify.show(R.string.settings_send_failed)
                    }
                    SettingCommands.Failure.UNCONFIRMED -> {
                        // Wear OS 默认抑制发自手机端的 DataItem 回声，仅记日志，不弹失败 Toast
                    }
                }
                if (failure == SettingCommands.Failure.UNCONFIRMED) LogBus.debug("[设置] $failure")
                else LogBus.error("[设置] $failure")
            },
        )
    private val watchNameSync =
        WatchNameSync(
            scope = backgroundScope,
            initialAlias = getStoredAlias(),
            watchNode = { session.watchNode },
            requestRead = { session.requestSettingValue(WcsPaths.SET_INFO_WATCH_NAME) },
            write = session::writeSettingItem,
            onName = { name ->
                _state.update { it.copy(watchAlias = name) }
                persistDeviceSnapshot()
            },
            onResult = { result ->
                UiNotify.show(
                    when (result) {
                        WatchNameSync.Result.PENDING -> R.string.rename_pending
                        WatchNameSync.Result.LOCAL_ONLY -> R.string.rename_local_only
                        WatchNameSync.Result.CONFIRMED -> R.string.rename_success
                        WatchNameSync.Result.SEND_FAILED -> R.string.settings_send_failed
                        WatchNameSync.Result.SOURCE_UNAVAILABLE ->
                            R.string.rename_source_unavailable
                        WatchNameSync.Result.SUBMITTED -> R.string.rename_submitted
                    }
                )
            },
            onDebug = LogBus::debug,
        )

    val monitor =
        HealthMonitorSession(
            backgroundScope,
            send = { path, packet ->
                session.sendRawJson(
                    path,
                    packet,
                    senderPkg = HealthMonitorProtocol.PACKAGE,
                    senderNode = HealthMonitorProtocol.SIGNATURE,
                )
            },
            launchRemoteActivity = { pkg, action, cls, categories, extras ->
                session.launchRemoteActivity(pkg, action, cls, categories, extras)
            },
            onEcgReceived = healthRepo::onEcgReceived,
            onBpReceived = healthRepo::onBpReceived,
            onBpConfigurationsReceived = healthRepo::onBpConfigurationsReceived,
            log = LogBus::log,
        )
    private val startupSync =
        StartupSyncCoordinator(
            scope = backgroundScope,
            request = { target ->
                when (target) {
                    StartupSyncCoordinator.Target.WATCH_FACE -> requestActiveWatchface()
                    StartupSyncCoordinator.Target.DEVICE_INFO -> requestFeature()
                    StartupSyncCoordinator.Target.BATTERY -> requestBatteryDetails()
                    StartupSyncCoordinator.Target.WATCH_FACE_ORDER -> requestWatchfaceOrder()
                }
            },
            onPending = { pending, running ->
                _state.update {
                    it.copy(
                        startupSyncing = running,
                        watchfaceRefreshing =
                            running && StartupSyncCoordinator.Target.WATCH_FACE in pending,
                    )
                }
            },
            onLog = LogBus::log,
        )
    private var dayResetJob: Job? = null

    private fun restoreDeviceSnapshot() {
        val prefs =
            context.getSharedPreferences(
                "watchfree_device_${session.watchNode}",
                Context.MODE_PRIVATE,
            )
        _state.update { DeviceSnapshot.restore(prefs.getString("snapshot", null), it) }
        _watchfaceOrder.value = _state.value.watchfaceFavoriteIds
    }

    private fun persistDeviceSnapshot() {
        context
            .getSharedPreferences("watchfree_device_${session.watchNode}", Context.MODE_PRIVATE)
            .edit()
            .putString("snapshot", DeviceSnapshot.encode(_state.value))
            .apply()
    }

    @android.annotation.SuppressLint("MissingPermission")
    private fun readBluetoothAlias(peerAddress: String?): String? {
        if (peerAddress.isNullOrBlank()) return null
        return try {
            val adapter = android.bluetooth.BluetoothAdapter.getDefaultAdapter() ?: return null
            val device = adapter.getRemoteDevice(peerAddress)
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                device.alias
            } else {
                val method = device.javaClass.getMethod("getAlias")
                method.invoke(device) as? String
            }
        } catch (_: Throwable) {
            null
        }
    }

    @android.annotation.SuppressLint("MissingPermission")
    private fun writeBluetoothAlias(peerAddress: String?, alias: String): Boolean {
        if (peerAddress.isNullOrBlank()) return false
        return try {
            val adapter = android.bluetooth.BluetoothAdapter.getDefaultAdapter() ?: return false
            val device = adapter.getRemoteDevice(peerAddress)
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                device.setAlias(alias) == android.bluetooth.BluetoothStatusCodes.SUCCESS
            } else {
                val method = device.javaClass.getMethod("setAlias", String::class.java)
                (method.invoke(device, alias) as? Boolean) ?: true
            }
        } catch (_: Throwable) {
            false
        }
    }

    private fun getStoredAlias(): String {
        val prefs = context.getSharedPreferences("watchfree_aliases", Context.MODE_PRIVATE)
        val address = session.peerAddress.orEmpty().trim().uppercase()
        if (address.isBlank()) return ""
        return prefs.getString("watch_alias_$address", "").orEmpty()
    }

    private fun saveStoredAlias(alias: String) {
        val prefs = context.getSharedPreferences("watchfree_aliases", Context.MODE_PRIVATE)
        val address = session.peerAddress.orEmpty().trim().uppercase()
        if (address.isBlank()) return
        prefs.edit().putString("watch_alias_$address", alias).apply()
    }

    private fun loadWatchAlias(): String {
        val btAlias = readBluetoothAlias(session.peerAddress)?.takeIf { it.isNotBlank() }
        val storedAlias = getStoredAlias().takeIf { it.isNotBlank() }
        return storedAlias ?: btAlias ?: _state.value.watchAlias.takeIf { it.isNotBlank() } ?: ""
    }

    fun setWatchAlias(name: String) {
        if (!isActive()) return
        val trimmed = name.trim().take(32)
        if (trimmed.isBlank()) return
        saveStoredAlias(trimmed)
        writeBluetoothAlias(session.peerAddress, trimmed)
        watchNameSync.rename(trimmed)
    }

    init {
        queryPrefs.registerOnSharedPreferenceChangeListener(queryPreferenceListener)
        session.observer = this
        restoreDeviceSnapshot()
        val initialAlias = loadWatchAlias()
        if (initialAlias.isNotBlank()) {
            _state.update { it.copy(watchAlias = initialAlias) }
        }
        healthRepo.restore()
        healthRepo.scheduleSleepAnalysis()
        backgroundScope.launch {
            monitor.state.collect { mState -> _state.update { it.copy(monitorState = mState) } }
        }
    }

    /** 连接控制器释放旧会话时必须同时释放调度器和设备护理线程。 */
    // Do not hold this monitor while waiting for SHM: its persistence callbacks acquire it.
    internal fun deactivate() {
        closed.set(true)
        session.observer = null
        watchNameSync.disconnect()
        _state.update { it.copy(connected = false, sessionReady = false) }
    }

    fun close() {
        deactivate()
        if (!resourcesClosed.compareAndSet(false, true)) return
        queryPrefs.unregisterOnSharedPreferenceChangeListener(queryPreferenceListener)
        session.observer = null
        monitor.disconnect()
        healthMeasurements.close()
        synchronized(this) {
            refresh.stop()
            startupSync.stop()
            healthRepo.stopSyncPhases()
            settingCommands.clear()
            autoQueries.stop()
            backgroundScope.cancel()
            refreshUsers.set(0)
            dcQueue.shutdownNow()
        }
        session.close()
    }

    fun healthExportSnapshot(): HealthExportSnapshot =
        healthRepo.exportSnapshot().copy(collectionSettings = healthMeasurements.exportSettings())

    fun setStepGoal(value: Int?) = healthRepo.setStepGoal(value)

    fun addManualNap(startMillis: Long, endMillis: Long): Boolean =
        healthRepo.addManualNap(startMillis, endMillis)

    fun removeManualNap(startMillis: Long, endMillis: Long): Boolean =
        healthRepo.removeManualNap(startMillis, endMillis)

    fun manualNaps(): List<SleepParser.ManualNap> = healthRepo.manualNaps()

    fun requestHealthSync() = healthRepo.requestSync()

    fun requestHealthModule(
        module: String,
        fromStartOfDay: Boolean = true,
        hours: Int = 0,
    ): Boolean = healthRepo.requestModule(module, fromStartOfDay, hours)

    fun requestHealthRecovery(): Boolean = healthRepo.requestRecovery()

    fun requestVascularLoadSync(): Boolean = healthRepo.requestVascularLoadSync()

    private fun receiveHealthMessage(json: JSONObject) {
        if (!healthMeasurements.handleMessage(json)) {
            healthRepo.handleMessage(json, HealthPacket.Direction.FROM_WATCH)
        }
    }

    fun onWearApiConnected(nodeName: String, nodeId: String) {
        onLog("WearApi: 已连上手表 $nodeName ($nodeId)")
    }

    fun onWearApiDisconnected(error: String? = null) {
        onLog("WearApi: 手表节点已断开${error?.let { ": $it" }.orEmpty()}")
    }

    fun handleWearApiMessage(path: String, data: ByteArray) {
        val payload = data.toString(Charsets.UTF_8)
        val json = runCatching { JSONObject(payload) }.getOrNull()
        if (json != null) {
            when (path) {
                WcsPaths.INTERNAL_FEATURE -> applyFeature(json)
                WcsPaths.INTERNAL_STATUS -> applyStatus(json)
                WcsPaths.STF -> applyStf(json)
                WcsPaths.INDICATOR_BATTERY,
                WcsPaths.INDICATOR_BATTERY_RSP -> applyIndicatorBattery(json)
                else ->
                    if (path.startsWith(WcsPaths.HEALTH_MESSAGE)) {
                        receiveHealthMessage(json)
                    }
            }
        }
        LogBus.debug { "[WearApi←] path=$path bytes=${data.size} parsed=${json != null}" }
    }

    override fun onSessionReady() {
        if (!isActive()) return
        _state.update { state ->
            state.copy(
                sessionReady = true,
                watchNode = session.watchNode,
                phoneNode = session.phoneNode,
                onboardingStatus = OnboardingStatus.VERIFYING_IDENTITY,
                onboardingMessage = "",
            )
        }
        LogBus.log("会话已就绪，优先查询表盘、设备资料和电池状态")
        startupSync.start()
        session.publishCapabilities()
        watchNameSync.connect()
        backgroundScope.launch {
            delay(1500)
            if (_state.value.sessionReady) monitor.connect()
        }
        healthRepo.resetDayIfNeeded()
        if (dayResetJob?.isActive != true) {
            dayResetJob =
                backgroundScope.launch {
                    while (true) {
                        delay(60_000)
                        healthRepo.resetDayIfNeeded()
                    }
                }
        }
        healthRepo.startSyncPhases()
        autoQueries.start()
    }

    override fun onIdentityRequired() {
        _state.update {
            it.copy(onboardingStatus = OnboardingStatus.IDENTITY_MISSING, onboardingMessage = "")
        }
        UiNotify.show(R.string.phone_node_required, long = true)
    }

    override fun onWatchNodeChanged(node: String) {
        _state.update { state -> state.copy(watchNode = node) }
        restoreDeviceSnapshot()
    }

    override fun onLog(line: String) {
        LogBus.log(line)
    }

    override fun onHandshake(msg: WcsFrame.Incoming) {
        // NodeInfo 里带设备名
        if (msg is WcsFrame.Incoming.NodeInfo && !msg.deviceName.isNullOrBlank()) {
            val alias = loadWatchAlias()
            _state.update { state ->
                state.copy(
                    deviceName = msg.deviceName!!,
                    watchAlias = alias.ifBlank { state.watchAlias },
                )
            }
        }
    }

    override fun onWearPath(msg: WcsFrame.Incoming.WearPath) {
        if (!isActive()) return
        val (_, cleanPath) = WcsFrame.splitWearPath(msg.path)
        val dataMap = msg.dataMap
        LogBus.debug { "[仓库←] DataItem path=$cleanPath data=${LogBus.describe(dataMap)}" }
        if (dataMap.isEmpty()) return
        // Samsung's alternate DataClient carrier uses the same outer health JSON.
        if (cleanPath.startsWith(WcsPaths.HEALTH_MESSAGE + "/wearable_to_mobile")) {
            val payload = dataMap["data_payload_key"] as? String
            if (payload != null) {
                runCatching { receiveHealthMessage(JSONObject(payload)) }
                    .onFailure { LogBus.error("[健康] DataItem 消息解析失败", it) }
            } else if (dataMap["is_support_data_asset_key"] == true) {
                LogBus.log("[健康] 收到 Asset 引用，当前固件正常同步应使用 Channel；此载体尚未实现")
            }
            return
        }
        val dataMapId = (dataMap["dataMapId"] as? Number)?.toInt() ?: 0

        // 1. 电池与设备护理 (c_devicecare/battery/...)
        if (cleanPath.startsWith("/c_devicecare/battery")) {
            if (dataMapId == WcsPaths.DC_MAP_BATTERY_SETTING) {
                applyBatterySetting(dataMap)
            } else {
                applyDeviceCareBattery(cleanPath, dataMapId, dataMap)
            }
            return
        }

        // 2. 内存 (c_devicecare/memory/...)
        if (cleanPath.startsWith("/c_devicecare/memory")) {
            applyDeviceCareMemory(dataMapId, dataMap)
            return
        }

        // 3. 手表系统设置 (w_module_sec_watch_setting/...)
        if (cleanPath.startsWith("/w_module_sec_watch_setting")) {
            applyWatchSetting(msg.path, dataMap)
            return
        }
    }

    /** 电池保护设置（dataMapId=206, key_battery_setting_status=[protect, chargingInfo, autoPowerOn]） */
    private fun applyBatterySetting(dataMap: Map<String, Any>) {
        val dataMapId = (dataMap["dataMapId"] as? Number)?.toInt() ?: 0
        @Suppress("UNCHECKED_CAST") val data = (dataMap["data"] as? Map<String, Any>) ?: dataMap
        val arr = data["key_battery_setting_status"]
        val values: List<Int> =
            when (arr) {
                is List<*> -> arr.mapNotNull { (it as? Number)?.toInt() }
                is Number -> listOf(arr.toInt())
                else -> emptyList()
            }
        if (values.isEmpty()) {
            LogBus.debug { "[电池设置] id=$dataMapId 无状态数组 data=${LogBus.describe(dataMap)}" }
            return
        }
        settingCommands.confirm(WcsPaths.DEVICECARE_BATTERY_SETTING, values[0] == 1)
        _state.update { state ->
            state.copy(
                batteryProtection = values.getOrElse(0) { -1 },
                showChargingInfo = values.getOrElse(1) { -1 },
                autoPowerOn = values.getOrElse(2) { -1 },
            )
        }
        LogBus.debug {
            "[电池设置] 保护=${values.getOrElse(0) { -1 }} 充电信息=${values.getOrElse(1) { -1 }} 自动开机=${values.getOrElse(2) { -1 }}"
        }
        refresh.confirm(RefreshCoordinator.Target.BATTERY_SETTING)
    }

    /**
     * DeviceCare 电池数据。
     *
     * 官方 schema（BatteryUsageResponseCmd.setBatteryUsageStatsData）： data.dartbattery_info =
     * {battery_level, status, time_remaining, rut_psm_off, rut_psm_on, psm_status,
     * time_since_charged, wearable_psm_control_restricted, wearable_protected_fully,
     * usage_time_for_full_charge} 部分推送（dataMapId=200 的 change 事件）会把这些字段直接平铺在 data 下。
     */
    private fun applyDeviceCareBattery(path: String, dataMapId: Int, dataMap: Map<String, Any>) {
        @Suppress("UNCHECKED_CAST") val data = (dataMap["data"] as? Map<String, Any>) ?: dataMap
        @Suppress("UNCHECKED_CAST") val info = (data["battery_info"] as? Map<String, Any>) ?: data

        if ((info["battery_level"] as? Number)?.toInt() in 0..100) {
            startupSync.confirm(StartupSyncCoordinator.Target.BATTERY)
            refresh.confirm(RefreshCoordinator.Target.BATTERY)
        }
        if (hasDeviceCareBatteryPayload(info)) {
            when (dataMapId) {
                WcsPaths.DC_MAP_BATTERY_BASE_INFO ->
                    refresh.confirm(RefreshCoordinator.Target.BATTERY_DETAILS)
                WcsPaths.DC_MAP_BATTERY_USAGE ->
                    refresh.confirm(RefreshCoordinator.Target.BATTERY_USAGE)
            }
        }
        (info["psm_status"] as? Boolean)?.let { settingCommands.confirm(WcsPaths.SET_PSM, it) }
        val before = _state.value
        _state.update { current ->
            var s = current
            (info["battery_level"] as? Number)?.toInt()?.let {
                if (it in 0..100) s = s.copy(batteryLevel = it)
            }
            (info["psm_status"] as? Boolean)?.let {
                s = s.copy(psmMode = it)
                psmKnown = true
            }
            (info["status"] as? Number)?.toInt()?.let {
                // Android BatteryManager：2=充电中 3=放电中 4=未充电 5=已充满
                s = s.copy(batteryStatus = it, charging = it == 2 || it == 5)
            }
            (info["time_remaining"] as? Number)?.toLong()?.let {
                s = s.copy(chargeTimeRemainingMs = it)
            }
            s = s.withBatteryEstimates(info)
            (info["wearable_psm_control_restricted"] as? Number)?.toInt()?.let {
                s = s.copy(psmControlRestricted = it != 0)
            }

            // 有可清理应用列表时顺带记下（dataMapId=200/202）
            @Suppress("UNCHECKED_CAST")
            val appList = data["app_usage_list"] as? List<Map<String, Any>>
            if (appList != null) {
                val apps = LinkedHashMap<String, Long>()
                val cleanable = ArrayList<String>()
                appList.forEach { a ->
                    val pkg = a["package"] as? String ?: return@forEach
                    apps[pkg] = ((a["memory_used"] as? Number)?.toLong() ?: 0L)
                    val isCleanable = (a["cleanable"] as? Boolean) ?: true
                    if (isCleanable) cleanable.add(pkg)
                }
                if (apps.isNotEmpty()) {
                    s =
                        s.copy(
                            ramApps = apps,
                            ramCleanableApps = cleanable.ifEmpty { apps.keys.toList() },
                        )
                }
            }

            s
        }
        val s = _state.value
        if (s != before) {
            LogBus.debug {
                "[设备护理] $path id=$dataMapId 电量=${s.batteryLevel}% status=${s.batteryStatus} " +
                    "PSM=${s.psmMode} 常规=${s.remainingNormalMin}min 省电=${s.remainingPsmMin}min " +
                    "estimatesReceived=${s.normalBatteryEstimateReceived}/${s.psmBatteryEstimateReceived} " +
                    "rut_psm_off=${info["rut_psm_off"]}(${info["rut_psm_off"]?.javaClass?.simpleName ?: "missing"}) " +
                    "rut_psm_on=${info["rut_psm_on"]}(${info["rut_psm_on"]?.javaClass?.simpleName ?: "missing"}) " +
                    "keys=${info.keys}"
            }
        }
    }

    /**
     * DeviceCare 内存数据（MemoryUsageRespondCmd）。 data = {mem_total, mem_available,
     * memory_usage_list:[{package,name,uid,memory_used,cleanable}]}
     */
    private fun applyDeviceCareMemory(dataMapId: Int, dataMap: Map<String, Any>) {
        @Suppress("UNCHECKED_CAST") val data = (dataMap["data"] as? Map<String, Any>) ?: dataMap
        val total = (data["mem_total"] as? Number)?.toLong() ?: 0L
        val available = (data["mem_available"] as? Number)?.toLong() ?: 0L
        if (total <= 0) {
            LogBus.debug { "[设备护理] 内存响应无 mem_total data=${LogBus.describe(dataMap)}" }
            return
        }
        val mb = 1024L * 1024L
        val (apps, cleanable) = parseDeviceCareMemory(dataMap)
        _state.update { state ->
            state.copy(
                ramTotalMb = total / mb,
                ramAvailableMb = available / mb,
                ramUsedMb = (total - available) / mb,
                ramApps = apps,
                ramCleanableApps = cleanable,
            )
        }
        LogBus.debug {
            "[设备护理] 内存 id=$dataMapId 已用 ${(total - available) / mb}MB / 共 ${total / mb}MB，" +
                "应用数=${apps.size} data=${LogBus.describe(dataMap)}"
        }
        if (dataMapId == WcsPaths.DC_MAP_MEMORY_USAGE) {
            refresh.confirm(RefreshCoordinator.Target.MEMORY)
        }
    }

    /**
     * 系统设置同步（setting_info / 单项推送）。
     *
     * 手表推送的 DataMap 两种形态： 带元数据：{from=watch, key=intLevel, intLevel=103, type=1, time=...} 只有值：
     * {from=watch, booleanIsChecked=false, time=...}（accessibility 类） 两者都归一化为
     * SettingItem（path/key/type/value），供 UI 直接读写。
     */
    private fun applyWatchSetting(uri: String, dataMap: Map<String, Any>) {
        val (_, path) = WcsFrame.splitWearPath(uri)
        if (path == WcsPaths.SET_INFO_WATCH_NAME) watchNameSync.receive(uri, dataMap)
        val item = WatchSettingSchema.decode(path, dataMap) ?: return
        markSynced()
        val clean = item.path
        val rawValue = item.value
        val spec = WatchSettingSchema.spec(clean)
        if (spec?.path == WcsPaths.SET_INFO_WATCH_NAME) {
            _state.update { it.copy(settingItems = it.settingItems + (clean to item)) }
            return
        }
        if (settingCommands.hasPending(clean)) {
            LogBus.debug { "[设置] 手表反馈 $clean {${item.key}=$rawValue} from=${dataMap["from"]}" }
        }

        // 下发值与回包值类型可能不同（PSM 下发 Boolean、回包 0/1），归一后再确认一次
        if (!settingCommands.confirm(clean, rawValue)) {
            spec?.kind?.canonicalize(rawValue)?.let { settingCommands.confirm(clean, it) }
        }
        _state.update { state -> state.copy(settingItems = state.settingItems + (clean to item)) }

        // 常见核心设置同步到顶层状态，便于 UI 快速响应与双向绑定（映射表见 WatchSettingSchema）
        if (spec === WatchSettingSchema.PSM) psmKnown = true
        val apply = spec?.apply
        if (apply != null && spec.kind.accepts(rawValue)) {
            _state.update { state -> apply(state, rawValue) }
        }
        if (clean == WcsPaths.SET_INFO.trimStart('/')) {
            refresh.confirm(RefreshCoordinator.Target.SETTINGS)
        }
    }

    override fun onMonitorChannel(path: String, payload: ByteArray) {
        if (!isActive()) return
        val channel = HealthMonitorProtocol.Channel.fromPath(path) ?: return
        try {
            val jobs =
                dev.ricky.galaxywatchmanagerfree.feature.monitor.MonitorChannelFrames.decode(
                    payload
                )
            LogBus.debug("[健康监测器] $path 收到 ${jobs.size} 个同步任务 bytes=${payload.size}")
            jobs.forEach { monitor.receiveSync(channel, it) }
        } catch (error: Exception) {
            LogBus.error("[健康监测器] Channel 解码失败 bytes=${payload.size}", error)
        }
    }

    override fun onMessage(msg: WcsFrame.Incoming.Wearable) {
        if (!isActive()) return
        if (
            msg.path == HealthMonitorProtocol.PLAIN_CONNECTION ||
                HealthMonitorProtocol.Channel.fromPath(msg.path) != null
        ) {
            monitor.receive(msg.path, msg.payloadRaw)
            return
        }
        val json = runCatching { JSONObject(msg.payload) }.getOrNull() ?: return
        when (msg.path) {
            WcsPaths.INTERNAL_FEATURE ->
                if (msg.envType == WcsFrame.TYPE_RESPONSE) {
                    applyFeature(json)
                }
            WcsPaths.INTERNAL_STATUS ->
                if (msg.envType == WcsFrame.TYPE_RESPONSE) {
                    applyStatus(json)
                }
            WcsPaths.STF -> applyStf(json)
            WcsPaths.INDICATOR_BATTERY_RSP,
            WcsPaths.INDICATOR_BATTERY -> applyIndicatorBattery(json)
            WcsPaths.DEVICECARE_BATTERY_BASE -> {
                val lvl = json.optInt("battery_level", json.optInt("level", -1))
                if (lvl in 0..100) {
                    _state.update { state -> state.copy(batteryLevel = lvl) }
                    refresh.confirm(RefreshCoordinator.Target.BATTERY)
                    refresh.confirm(RefreshCoordinator.Target.BATTERY_DETAILS)
                }
            }
            WcsPaths.DEVICECARE_BATTERY_PSM -> {
                val psm = json.optInt("extraData", -1)
                if (psm >= 0) {
                    psmKnown = true
                    settingCommands.confirm(WcsPaths.SET_PSM, psm == 1)
                    _state.update { state -> state.copy(psmMode = (psm == 1)) }
                    LogBus.log("[PSM] 手表确认：${if (psm == 1) "已开启省电" else "已退出省电"}")
                }
            }
            WcsPaths.SYSUI_APPS -> applyApps(json)
            WcsPaths.WATCHFACE_SYSUI -> applyWatchfaceMessage(json)
            WcsPaths.HEALTH_CAPABILITY -> healthRepo.handleCapability(json)
            WcsPaths.FIND_MY_WATCH -> applyFindMyWatch(json)
            else -> {
                if (msg.path.startsWith(WcsPaths.HEALTH_MESSAGE)) {
                    receiveHealthMessage(json)
                }
            }
        }
    }

    private val refreshUsers = java.util.concurrent.atomic.AtomicInteger(0)
    var autoRefreshEnabled: Boolean
        get() = state.value.autoRefresh
        set(value) = updateQueryPolicy(enabled = value)

    fun setAutoQueryIntervalSeconds(value: Int) {
        require(value in AutoQueryPolicy.INTERVALS_SECONDS)
        updateQueryPolicy(intervalSeconds = value)
    }

    @Synchronized
    private fun updateQueryPolicy(enabled: Boolean? = null, intervalSeconds: Int? = null) {
        if (!isActive()) return
        val value =
            queryPolicy.copy(
                enabled = enabled ?: queryPolicy.enabled,
                intervalSeconds = intervalSeconds ?: queryPolicy.intervalSeconds,
            )
        applyQueryPolicy(value)
        queryPrefs
            .edit()
            .putBoolean("enabled", value.enabled)
            .putInt("interval_seconds", value.intervalSeconds)
            .apply()
    }

    @Synchronized
    private fun applyQueryPolicy(value: AutoQueryPolicy) {
        if (!isActive()) return
        queryPolicy = value
        LogBus.debug(
            "[自动查询] enabled=${value.enabled} intervalSeconds=${value.intervalSeconds} visibleUsers=${refreshUsers.get()}"
        )
        _state.update {
            it.copy(autoRefresh = value.enabled, autoQueryIntervalSeconds = value.intervalSeconds)
        }
        autoQueries.configure(value)
    }

    @Synchronized
    fun startAutoRefresh() {
        refreshUsers.incrementAndGet()
        autoQueries.setVisible(true)
    }

    @Synchronized
    fun stopAutoRefresh() {
        if (refreshUsers.decrementAndGet() <= 0) {
            refreshUsers.set(0)
            autoQueries.setVisible(false)
        }
    }

    /** 任意状态数据落地时更新时间戳 */
    private fun markSynced() {
        val now = System.currentTimeMillis()
        if (now - _state.value.lastSyncAt > 500) {
            _state.update { state -> state.copy(lastSyncAt = now) }
        }
    }

    fun onTransportState(connected: Boolean) {
        LogBus.debug(
            "[仓库] transport=$connected previousReady=${_state.value.sessionReady} active=${isActive()}"
        )
        _state.update { state ->
            state.copy(
                connected = connected,
                sessionReady = if (connected) state.sessionReady else false,
            )
        }
        if (connected) {
            session.onTransportConnected()
        } else {
            connectionGeneration = Any()
            refresh.stop()
            settingCommands.clear()
            watchNameSync.disconnect()
            monitor.disconnect()
            psmKnown = false
            startupSync.stop()
            autoQueries.stop()
            healthRepo.stopSyncPhases()
            dayResetJob?.cancel()
            dayResetJob = null
        }
    }

    fun refreshAll(): Boolean {
        if (closed.get() || !_state.value.canRefresh) return false
        return refresh.request { token ->
            fun deviceCare(target: RefreshCoordinator.Target, tag: String, send: () -> Unit) {
                val queued = dc(tag, isCurrent = { refresh.isPending(token, target) }, block = send)
                if (!queued) refresh.confirm(target)
            }
            requestFeature()
            requestStatus()
            requestBattery()
            deviceCare(RefreshCoordinator.Target.BATTERY_DETAILS, "battery/base_info") {
                session.sendBatteryBaseInfoReq()
            }
            deviceCare(RefreshCoordinator.Target.BATTERY_USAGE, "battery/refresh") {
                session.sendBatteryRefreshReq()
            }
            deviceCare(RefreshCoordinator.Target.BATTERY_SETTING, "battery/setting(read)") {
                session.sendBatterySettingReq()
            }
            deviceCare(RefreshCoordinator.Target.MEMORY, "memory/usage") {
                session.sendMemoryUsageReq()
            }
            requestSettingInfo()
            requestApps()
            requestWatchfaceOrder()
            if (
                !requestHealthSync() &&
                    _state.value.healthSyncStatus != HealthSyncCoordinator.Status.SYNCING
            ) {
                refresh.confirm(RefreshCoordinator.Target.HEALTH)
            }
            requestActiveWatchface()
        }
    }

    fun requestFeature() {
        session.sendJson(
            WcsPaths.INTERNAL_FEATURE,
            WcsPaths.MSG_FEATURE_EXCHANGE,
            2,
            session.buildPhoneFeature(),
        )
    }

    fun requestStatus() {
        session.sendJson(
            WcsPaths.INTERNAL_STATUS,
            WcsPaths.MSG_STATUS_EXCHANGE,
            2,
            session.buildPhoneStatus(),
        )
    }

    private fun applyFeature(json: JSONObject) {
        val d = json.optJSONObject("data") ?: json
        _state.update { state ->
            state.copy(
                modelNumber = d.optString("modelNumber", state.modelNumber),
                modelName = d.optString("modelName", state.modelName),
                deviceName = d.optString("deviceName", state.deviceName),
                firmware = d.optString("buildId", state.firmware),
                androidVersion = d.optString("androidVersion", state.androidVersion),
                batteryLevel = d.optInt("batteryLevel", state.batteryLevel),
                batteryCapacityMah = d.optString("batteryCapacity", state.batteryCapacityMah),
                esimSupported = d.optBoolean("esimSupport", state.esimSupported),
                eid = d.optString("eid", state.eid),
                actionButton = d.optBoolean("actionButton", state.actionButton),
                featureInfoReceived = true,
            )
        }
        if (_state.value.modelNumber.isNotBlank() || _state.value.modelName.isNotBlank()) {
            startupSync.confirm(StartupSyncCoordinator.Target.DEVICE_INFO)
            persistDeviceSnapshot()
        }
        if (d.optString("modelNumber").isNotBlank() || d.optString("modelName").isNotBlank()) {
            refresh.confirm(RefreshCoordinator.Target.FEATURE)
        }
    }

    private fun applyStatus(json: JSONObject) {
        val d = json.optJSONObject("data") ?: json
        _state.update { state ->
            state.copy(
                wearOs = d.optString("wearos", state.wearOs),
                wearing = d.optBoolean("wearingState", state.wearing),
                imei = d.optString("imei", state.imei),
                eid = d.optString("eid", state.eid).ifBlank { state.eid },
            )
        }
        _state.update { state -> state.copy(sessionReady = true) }
        persistDeviceSnapshot()
        if (listOf("wearos", "wearingState", "imei", "eid").any(d::has)) {
            refresh.confirm(RefreshCoordinator.Target.STATUS)
        }
    }

    fun requestBattery() {
        session.sendJson(WcsPaths.STF, "stf_battery_req", 1, JSONObject())
        session.sendEmpty(WcsPaths.BATTERY_STATE_REQUEST)
    }

    private val dcQueue: java.util.concurrent.ExecutorService =
        java.util.concurrent.Executors.newSingleThreadExecutor { r ->
            Thread(r, "devicecare-q").apply { isDaemon = true }
        }
    private val dcGapMs = 1500L
    @Volatile private var lastDcAt = 0L

    @Volatile private var psmKnown = false

    private fun dc(tag: String, isCurrent: () -> Boolean = { true }, block: () -> Unit): Boolean {
        if (dcQueue.isShutdown || !isActive() || !_state.value.sessionReady) return false
        val generation = connectionGeneration
        try {
            dcQueue.execute {
                try {
                    if (!isActive() || generation !== connectionGeneration || !isCurrent())
                        return@execute
                    val wait = dcGapMs - (System.currentTimeMillis() - lastDcAt)
                    LogBus.debug(
                        "[设备护理] queued=$tag throttleMs=${wait.coerceAtLeast(0)} ready=${_state.value.sessionReady}"
                    )
                    if (wait in 1..dcGapMs) Thread.sleep(wait)
                    if (
                        !isActive() ||
                            generation !== connectionGeneration ||
                            !_state.value.sessionReady ||
                            Thread.currentThread().isInterrupted ||
                            !isCurrent()
                    )
                        return@execute
                    lastDcAt = System.currentTimeMillis()
                    LogBus.debug("[设备护理→] $tag")
                    runCatching(block).onFailure { LogBus.error("[设备护理] $tag 失败", it) }
                } catch (_: InterruptedException) {
                    Thread.currentThread().interrupt()
                }
            }
            return true
        } catch (_: java.util.concurrent.RejectedExecutionException) {
            return false
        }
    }

    /** 主动刷新电池详细信息 (DeviceCare base_info) */
    fun requestBatteryDetails() {
        dc("battery/base_info") { session.sendBatteryBaseInfoReq() }
    }

    /** 拉取电池用量与续航估算 (dataMapId=202，含 rut_psm_off / rut_psm_on) */
    fun requestBatteryUsage() {
        dc("battery/refresh") { session.sendBatteryRefreshReq() }
    }

    /** 读取电池保护设置 (dataMapId=206) */
    fun requestBatterySetting() {
        dc("battery/setting(read)") { session.sendBatterySettingReq() }
    }

    /** 设置电池保护模式（充电上限 80% 等）；withSettings=false 时只改保护开关 */
    fun setBatteryProtection(enabled: Boolean) {
        val sent =
            settingCommands.submit(
                WcsPaths.DEVICECARE_BATTERY_SETTING,
                enabled,
                enqueue = { action -> dc("battery/setting(write)", block = action) },
            ) {
                session.sendBatterySetting(
                    protection = if (enabled) 1 else 0,
                    showChargingInfo = -1,
                    autoPowerOn = -1,
                )
            }
        if (sent) {
            _state.update { it.copy(batteryProtection = if (enabled) 1 else 0) }
            UiNotify.show(R.string.setting_sent_pending)
        }
    }

    /** 切换手表省电模式 (PSM) */
    fun setPowerSavingMode(enabled: Boolean) {
        if (
            psmKnown &&
                _state.value.psmMode == enabled &&
                !settingCommands.hasPending(WcsPaths.SET_PSM)
        )
            return
        val sent =
            settingCommands.submit(
                WcsPaths.SET_PSM,
                enabled,
                retries = 2,
                enqueue = { action -> dc("battery/psm=$enabled", block = action) },
            ) {
                session.sendPsmMode(enabled)
            }
        if (sent) {
            _state.update { it.copy(psmMode = enabled) }
            UiNotify.show(R.string.setting_sent_pending)
        }
    }

    /** 请求内存信息 */
    fun requestMemory() {
        dc("memory/usage") { session.sendMemoryUsageReq() }
    }

    /** 一键清理手表后台应用内存 */
    fun cleanRam(apps: List<String>? = null) {
        val targets =
            apps ?: _state.value.ramCleanableApps.ifEmpty { _state.value.ramApps.keys.toList() }
        dc("memory/clean") {
            session.sendMemoryClean(targets)
            dcQueue.execute {
                try {
                    Thread.sleep(1200)
                    if (_state.value.sessionReady) requestMemory()
                } catch (_: InterruptedException) {
                    Thread.currentThread().interrupt()
                }
            }
        }
    }

    private fun applyStf(json: JSONObject) {
        if (json.optString("msg_id") != WcsPaths.MSG_STF_BATTERY_RSP) return
        val inner = runCatching { JSONObject(json.optString("data")) }.getOrNull() ?: return
        val level = inner.optInt("batteryLevel", -1)
        if (level in 0..100) {
            _state.update { state -> state.copy(batteryLevel = level) }
            markSynced()
            refresh.confirm(RefreshCoordinator.Target.BATTERY)
        }
    }

    private fun applyIndicatorBattery(json: JSONObject) {
        val level = json.optInt("batteryLevel", json.optInt("level", -1))
        if (level in 0..100) {
            _state.update { state -> state.copy(batteryLevel = level) }
            markSynced()
            refresh.confirm(RefreshCoordinator.Target.BATTERY)
        }
        val charging = json.optBoolean("charging", json.optBoolean("isCharging", false))
        _state.update { state -> state.copy(charging = charging) }
    }

    fun setAod(enabled: Boolean) {
        updateSetting("w_module_sec_watch_setting/display/always_on_display", enabled)
    }

    fun setWakeOnWrist(enabled: Boolean) {
        updateSetting("w_module_sec_watch_setting/display/wake_on_wrist_raised", enabled)
    }

    fun setBrightness(level: Int) {
        val clamped = level.coerceIn(0, 100)
        updateSetting("w_module_sec_watch_setting/display/brightness", clamped)
    }

    fun setOutdoorMode(enabled: Boolean) {
        updateSetting("w_module_sec_watch_setting/display/outdoor_mode", enabled)
    }

    fun setScreenTimeout(item: Int) {
        updateSetting("w_module_sec_watch_setting/display/screen_time_out/selected_item", item)
    }

    fun setGrayscale(enabled: Boolean) {
        updateSetting("w_module_sec_watch_setting_accessibility/grayscale", enabled)
    }

    fun setHighContrastFonts(enabled: Boolean) {
        updateSetting("w_module_sec_watch_setting_accessibility/high_contrast_fonts", enabled)
    }

    fun setMuteAllSounds(enabled: Boolean) {
        updateSetting("w_module_sec_watch_setting_accessibility/mute_all_sound", enabled)
    }

    fun setSyncDnd(enabled: Boolean) {
        updateSetting("w_module_sec_watch_setting/phone/dnd/sync_do_not_disturb/enabled", enabled)
    }

    fun setWakeOnTouch(enabled: Boolean) {
        setBool(WcsPaths.SET_DISPLAY_WAKE_TOUCH, enabled)
    }

    fun setWakeOnBezel(enabled: Boolean) {
        setBool(WcsPaths.SET_DISPLAY_WAKE_BEZEL, enabled)
    }

    fun setTouchSound(enabled: Boolean) {
        setBool(WcsPaths.SET_SOUND_TOUCH, enabled)
    }

    fun setChargingSound(enabled: Boolean) {
        setBool(WcsPaths.SET_SOUND_CHARGING, enabled)
    }

    fun setGestureAnswer(enabled: Boolean) {
        setBool(WcsPaths.SET_ADV_GESTURE_ANSWER, enabled)
    }

    fun setGestureDismiss(enabled: Boolean) {
        setBool(WcsPaths.SET_ADV_GESTURE_DISMISS, enabled)
    }

    fun setQuickLaunch(enabled: Boolean) {
        setBool("w_module_sec_watch_setting/advanced/labs/quicklaunch/support", enabled)
    }

    fun setWristOrientation(rightWrist: Boolean) {
        setInt(WcsPaths.SET_GENERAL_WRIST, if (rightWrist) 1 else 0)
    }

    fun setNegativeColors(enabled: Boolean) {
        setBool("w_module_sec_watch_setting/accessibility/negative_colors", enabled)
    }

    fun setRemoveAnimations(enabled: Boolean) {
        setBool("w_module_sec_watch_setting/accessibility/remove_animations", enabled)
    }

    /** 找手表：响铃与振动 */
    fun startFindingWatch() {
        _state.update { state -> state.copy(findWatch = FindWatchStatus.RINGING) }
        session.sendJson(
            WcsPaths.FIND_MY_WATCH,
            WcsPaths.MSG_FMW_CURRENT_STATE_REQ,
            1,
            null,
            extra = JSONObject().put("connection_type", 0),
        )
        session.sendRawJson(
            WcsPaths.FIND_MY_WATCH,
            JSONObject()
                .put("msg_id", WcsPaths.MSG_FMW_START_ALERT_REQ)
                .put("deviceId", session.watchNode)
                .put("connection_type", 0),
        )
        session.sendRawJson(
            WcsPaths.FIND_MY_WATCH,
            JSONObject()
                .put("msg_id", WcsPaths.MSG_FMW_FIND_REQ)
                .put("deviceId", session.watchNode)
                .put("connection_type", 0),
        )
        LogBus.log("[找手表] 已下发响铃指令")
    }

    /** 停止找手表 */
    fun stopFindingWatch() {
        _state.update { state -> state.copy(findWatch = FindWatchStatus.IDLE) }
        session.sendRawJson(
            WcsPaths.FIND_MY_WATCH,
            JSONObject()
                .put("msg_id", WcsPaths.MSG_FMW_STOP_ALERT_REQ)
                .put("deviceId", session.watchNode)
                .put("connection_type", 0),
        )
        LogBus.log("[找手表] 已下发停止响铃指令")
    }

    private fun applyFindMyWatch(json: JSONObject) {
        val msgId = json.optString("msg_id").ifEmpty { json.optString("msgId") }
        when (msgId) {
            WcsPaths.MSG_FMW_FINISH_ALERT_REQ -> {
                _state.update { it.copy(findWatch = FindWatchStatus.IDLE) }
                session.sendRawJson(
                    WcsPaths.FIND_MY_WATCH,
                    JSONObject()
                        .put("msg_id", WcsPaths.MSG_FMW_FINISH_ALERT_RSP)
                        .put("result", true)
                        .put("deviceId", session.watchNode),
                )
                LogBus.log("[找手表] 手表端已手动停止响铃")
            }
            WcsPaths.MSG_FMW_STOP_ALERT_RSP -> {
                if (json.optBoolean("result", true)) {
                    _state.update { it.copy(findWatch = FindWatchStatus.IDLE) }
                }
            }
            WcsPaths.MSG_FMW_START_ALERT_RSP -> {
                if (!json.optBoolean("result", true)) {
                    _state.update { it.copy(findWatch = FindWatchStatus.FAILED) }
                    LogBus.log("[找手表] 手表启动响铃失败")
                }
            }
        }
    }

    /** 兼容旧接口 */
    fun findMyWatch() {
        if (_state.value.isFindingWatch) {
            stopFindingWatch()
        } else {
            startFindingWatch()
        }
    }

    fun syncNotificationFeatures() {
        session.sendJson(
            WcsPaths.NOTI_BRIDGE,
            WcsPaths.MSG_NOTIFICATION_FEATURE_EXCHANGE,
            0,
            JSONObject()
                .put("version", "1.0.0")
                .put("voip", true)
                .put("mutePending", true)
                .put("multiUser", true)
                .put("phoneActiveStatus", false),
        )
        session.sendJson(
            WcsPaths.NOTI_SETTINGS,
            WcsPaths.MSG_NOTIFICATION_SETTINGS_FEATURE_EXCHANGE,
            0,
            JSONObject()
                .put("version", "1.0.0")
                .put("enhancedPhoneAlertMute", 2)
                .put("showDetails", true)
                .put("showAppsManage", true)
                .put("enhancedReadNotificationAloud", true),
            sender = "mobile",
        )
        session.sendJson(
            WcsPaths.NOTI_SETTINGS,
            WcsPaths.MSG_NOTIFICATION_SETTINGS,
            1,
            JSONObject()
                .put("alerts_on_watch", 0)
                .put("alerts_on_phone", 1)
                .put("notification_indicator", true)
                .put("notification_aloud", false)
                .put("read_notification_aloud_v2", 0)
                .put("show_with_details", true)
                .put("turn_on_screen", true)
                .put("turn_on_for_new_apps", false),
            sender = "mobile",
        )
    }

    /** 下发允许通知的应用白名单 */
    fun setAllowedPackages(packages: List<String>) {
        val arr = JSONArray()
        packages.forEach { pkg ->
            arr.put(
                JSONObject().put("userId", 0).put("packageName", pkg).put("packageType", "mobile")
            )
        }
        session.sendJson(
            WcsPaths.NOTI_SETTINGS,
            WcsPaths.MSG_NOTIFICATION_ALLOWED_PACKAGES,
            1,
            JSONObject().put("list", arr),
            sender = "mobile",
        )
    }

    /**
     * 转发一条通知到手表。
     *
     * 实测格式（NotificationBridge.MessageBuilder.buildIntentNotification）：
     * {"msgId":"mobile_send_intent_notification","msgType":4,
     * "data":{"package_name","title","body","tag","time"}}
     */
    fun postNotification(
        packageName: String,
        title: String,
        body: String,
        tag: String = "",
        time: Long = System.currentTimeMillis(),
        appName: String? = null,
        identity: NotificationIdentity = NotificationIdentity.generated(packageName, tag),
    ): Boolean {
        return session.writeBridgerNotification(
            packageName = packageName,
            title = title,
            text = body,
            identity = identity,
            appName = appName ?: packageName,
            whenMillis = time,
        )
    }

    /** 诊断：向任意 path 发送任意消息体，用于协议探针实验 */
    fun probe(path: String, msgId: String, msgType: Int, data: JSONObject?) {
        session.sendJson(path, msgId, msgType, data)
        LogBus.debug {
            "[PROBE→] $path msgId=$msgId msgType=$msgType data=${LogBus.describe(data)}"
        }
    }

    fun sendTestNotification(title: String? = null, text: String? = null): Boolean {
        val strings = dev.ricky.galaxywatchmanagerfree.core.AppLanguage.context(context).resources
        val ok =
            postNotification(
                packageName = "dev.ricky.galaxywatchmanagerfree",
                title = title ?: strings.getString(R.string.app_name),
                body = text ?: strings.getString(R.string.test_notification_body),
                tag = "test_${System.currentTimeMillis()}",
                appName = "Galaxy Watch Manager Free",
            )
        LogBus.log("[通知] 测试通知已排队=$ok")
        return ok
    }

    /** 向 Wear OS 系统 Bridger 下发标准通知 */
    fun sendBridgerNotification(
        packageName: String = "com.tencent.mm",
        title: String,
        text: String,
        appName: String? = null,
    ): Boolean {
        return session.writeBridgerNotification(
            packageName = packageName,
            title = title,
            text = text,
            appName = appName,
        )
    }

    fun requestSettingInfo() {
        session.sendEmpty(WcsPaths.SET_INFO_REQ)
        session.sendJson(WcsPaths.SET_FEATURE, "feature", 0, JSONObject())
    }

    private val WRITE_RETRIES = 0

    fun settingItems(): Map<String, SettingItem> = _state.value.settingItems

    fun updateSetting(path: String, value: Any, keyHint: String? = null) {
        val clean = path.trimStart('/')
        val spec = WatchSettingSchema.spec(clean)
        if (spec?.path == WcsPaths.SET_INFO_WATCH_NAME) {
            if (value is String) setWatchAlias(value)
            return
        }
        // 优先级：手表上报过的真实 key > 规格表 > 调用方提示 > 兜底猜测
        val item = _state.value.settingItems[clean]
        val key = item?.key ?: spec?.key ?: keyHint ?: guessKey(clean, value)
        val type =
            item?.type
                ?: when (value) {
                    is Boolean -> 0L
                    is Number -> 1L
                    is String -> 3L
                    is List<*> -> 5L
                    is Map<*, *> -> 9L
                    else -> 3L
                }
        val sent =
            settingCommands.submit(
                clean,
                value,
                retries = WRITE_RETRIES,
                readBack = { session.requestSettingValue(clean) },
            ) {
                session.writeSetting(clean, key, value)
            }
        if (sent) {
            val optimisticItem = SettingItem(clean, key, type, value)
            _state.update { state ->
                val next = state.copy(settingItems = state.settingItems + (clean to optimisticItem))
                spec?.apply?.invoke(next, value) ?: next
            }
            UiNotify.show(R.string.setting_sent_pending)
        }
    }

    fun setBool(path: String, value: Boolean) = updateSetting(path, value)

    fun setInt(path: String, value: Int) = updateSetting(path, value)

    /** 未登记进 [WatchSettingSchema] 的路径才走到这里；新设置项应优先补表。 */
    private fun guessKey(path: String, value: Any): String =
        when {
            value is Boolean -> "booleanIsChecked"
            value is String -> "stringName"
            value is List<*> -> "arrayItemList"
            path.endsWith("selected_item") || path.contains("selected_") -> "intSelectedItem"
            path.endsWith("psm") -> "key_psm_status"
            else -> "intLevel"
        }

    fun requestApps() {
        session.sendJson(WcsPaths.SYSUI_APPS, WcsPaths.MSG_APPS_ORDER, 0, JSONObject())
    }

    private fun applyApps(json: JSONObject) {
        val d = json.optJSONObject("data") ?: return
        val arr = d.optJSONArray("apps") ?: return
        val out = ArrayList<String>()
        for (i in 0 until arr.length()) {
            val folder = arr.optJSONObject(i) ?: continue
            val items = folder.optJSONArray("items") ?: continue
            for (k in 0 until items.length()) {
                val it = items.optJSONObject(k) ?: continue
                val pkg = it.optString("packageName")
                if (pkg.isNotEmpty()) out.add(pkg)
            }
        }
        _apps.value = out
        refresh.confirm(RefreshCoordinator.Target.APPS)
    }

    fun requestWatchfaceOrder() {
        LogBus.debug("[表盘→] 查询表盘收藏列表")
        session.sendJson(WcsPaths.WATCHFACE_SYSUI, WcsPaths.MSG_WATCHFACE_ORDER, 0, JSONObject())
    }

    /** 查询手表当前生效的活跃表盘 */
    fun requestActiveWatchface() {
        LogBus.debug("[表盘→] 查询当前活跃表盘")
        session.sendJson(
            WcsPaths.WATCHFACE_SYSUI,
            WcsPaths.MSG_CHANGE_ACTIVE_WATCHFACE,
            0,
            JSONObject(),
        )
    }

    /** 设置手表当前活跃表盘（切换表盘） */
    fun setActiveWatchface(pkg: String, cls: String): Boolean {
        if (!_state.value.sessionReady) return false
        val name = WatchFacePresets.find(pkg, cls)?.enName ?: pkg
        LogBus.log("[表盘→] 切换表盘为 $name ($pkg)")
        val payload = JSONObject().put("packageName", pkg).put("className", cls)
        val queued =
            session.sendJson(
                WcsPaths.WATCHFACE_SYSUI,
                WcsPaths.MSG_CHANGE_ACTIVE_WATCHFACE,
                1,
                payload,
            )
        LogBus.debug { "[表盘] activate package=$pkg class=$cls queued=$queued" }
        if (!queued) return false

        // Keep the last confirmed face visible until a valid query/state response arrives.
        // 800ms 后向手表查询确认实际生效状态
        backgroundScope.launch {
            delay(800)
            runCatching { requestActiveWatchface() }.onFailure { LogBus.error("[表盘] 查询确认失败", it) }
        }
        return true
    }

    fun setActiveWatchface(preset: WatchFacePreset): Boolean =
        setActiveWatchface(preset.packageName, preset.className)

    /**
     * 设置表盘排序方式。
     *
     * 手表端 `WatchfaceApiStub.setWatchfaceOrderTypeWithSync(type)` 的映射： 0 →
     * {"isWatchSortByRecentsEnabled":false,"WatchFaceOrderType":"custom"} 1 →
     * {"isWatchSortByRecentsEnabled":true ,"WatchFaceOrderType":"recent"} 2 →
     * {"isWatchSortByRecentsEnabled":false,"WatchFaceOrderType":"alphabetic"} msgType=1 为写请求；手表处理后回
     * msgType=3 + result。
     */
    fun setWatchfaceOrderType(mode: String): Boolean {
        val type =
            when (mode) {
                WcsPaths.ORDER_TYPE_RECENT -> 1
                WcsPaths.ORDER_TYPE_ALPHABETIC -> 2
                else -> 0
            }
        val payload =
            JSONObject()
                .put("isWatchSortByRecentsEnabled", type == 1)
                .put("WatchFaceOrderType", mode)
        LogBus.log("[表盘→] 设置排序方式：$mode (type=$type)")
        session.sendJson(WcsPaths.WATCHFACE_SYSUI, WcsPaths.MSG_WATCHFACE_ORDER_TYPE, 1, payload)
        // 写完后重新拉一次排序结果做确认
        backgroundScope.launch {
            delay(700)
            runCatching { requestWatchfaceOrder() }.onFailure { LogBus.error("[表盘] 排序确认失败", it) }
        }
        return true
    }

    /** 用户点了「在手表上编辑表盘」的引导（清掉标记） */
    fun clearWatchfaceEditRequest() {
        _state.update { state -> state.copy(watchfaceEditRequested = false) }
    }

    private fun applyWatchfaceMessage(json: JSONObject) {
        val msgId = json.optString("msgId")
        val msgType = json.optInt("msgType", -1)
        val data = json.optJSONObject("data") ?: JSONObject()
        when (msgId) {
            WcsPaths.MSG_CHANGE_ACTIVE_WATCHFACE,
            "change_active_watchface" -> {
                val now = System.currentTimeMillis()
                val before = _state.value
                _state.update { DeviceSnapshot.applyWatchface(it, json, now) }
                val updated = _state.value
                if (updated.watchfaceUpdatedAt != before.watchfaceUpdatedAt) {
                    startupSync.confirm(StartupSyncCoordinator.Target.WATCH_FACE)
                    refresh.confirm(RefreshCoordinator.Target.WATCH_FACE)
                    persistDeviceSnapshot()
                    LogBus.log("[表盘] 当前活跃表盘：${updated.activeWatchfacePkg}")
                }
            }
            WcsPaths.MSG_WATCHFACE_ORDER,
            "watchface_order" -> {
                val arr = data.optJSONArray("favoriteIdOrderList")
                val orderType = data.optString("WatchFaceOrderType").ifBlank { null }
                val list =
                    if (arr != null) (0 until arr.length()).map { arr.optInt(it) } else emptyList()
                _watchfaceOrder.value = list
                _state.update { state ->
                    state.copy(watchfaceOrderType = orderType, watchfaceFavoriteIds = list)
                }
                if (arr != null || orderType != null) {
                    startupSync.confirm(StartupSyncCoordinator.Target.WATCH_FACE_ORDER)
                    refresh.confirm(RefreshCoordinator.Target.WATCH_FACE_ORDER)
                    persistDeviceSnapshot()
                }
                LogBus.debug { "[表盘] 收藏表盘列表：$list, orderType=$orderType" }
            }
            WcsPaths.MSG_WATCHFACE_ORDER_TYPE -> {
                val orderType = data.optString("WatchFaceOrderType").ifBlank { null }
                val result = json.optInt("result", 0)
                if (msgType == 3) {
                    LogBus.log("[表盘] 排序方式写入回执 result=$result orderType=${orderType ?: "-"}")
                }
            }
            WcsPaths.MSG_WATCHFACE_LAUNCH -> {
                if (msgType == 3) {
                    val result = json.optInt("result", 0)
                    val reason = json.optInt("reason", 0)
                    LogBus.log("[表盘] 编辑请求回执 result=$result reason=$reason")
                } else {
                    // 手表请求手机侧打开表盘编辑器：我们无法远程编辑，改为提示用户在手表上操作
                    LogBus.log("[表盘] 手表请求「在手机上编辑表盘」(msgType=$msgType)")
                    _state.update { state -> state.copy(watchfaceEditRequested = true) }
                }
            }
            WcsPaths.MSG_ADDABLE_WATCHFACE_INFO -> {
                val badges = data.optString("watchfaceBadgeList").ifBlank { null }
                LogBus.log("[表盘] 可添加表盘信息：badges=${badges ?: "-"}")
            }
        }
    }

    fun requestMediaState() {
        session.sendBytes(WcsPaths.MEDIA_UPDATE, Proto.EMPTY_MEDIA_QUERY)
    }
}

internal fun WatchState.withBatteryEstimates(info: Map<String, Any>): WatchState {
    var state = this
    (info["rut_psm_off"] as? Number)?.toInt()?.let {
        state = state.copy(remainingNormalMin = it, normalBatteryEstimateReceived = true)
    }
    (info["rut_psm_on"] as? Number)?.toInt()?.let {
        state = state.copy(remainingPsmMin = it, psmBatteryEstimateReceived = true)
    }
    return state
}

private val DEVICE_CARE_BATTERY_PAYLOAD_FIELDS =
    setOf(
        "status",
        "time_remaining",
        "rut_psm_off",
        "rut_psm_on",
        "psm_status",
        "time_since_charged",
        "wearable_psm_control_restricted",
        "wearable_protected_fully",
        "usage_time_for_full_charge",
    )

/** Metadata-only DataMap frames must not complete a battery detail refresh. */
internal fun hasDeviceCareBatteryPayload(info: Map<String, Any>): Boolean =
    (info["battery_level"] as? Number)?.toInt() in 0..100 ||
        DEVICE_CARE_BATTERY_PAYLOAD_FIELDS.any { info[it] is Number || info[it] is Boolean }

/** 解析 DeviceCare 内存数据中的应用占用与可清理名单 */
internal fun parseDeviceCareMemory(
    dataMap: Map<String, Any>
): Pair<Map<String, Long>, List<String>> {
    @Suppress("UNCHECKED_CAST") val data = (dataMap["data"] as? Map<String, Any>) ?: dataMap
    val mb = 1024L * 1024L
    val apps = LinkedHashMap<String, Long>()
    val cleanable = ArrayList<String>()
    val rawList = data["memory_usage_list"]
    @Suppress("UNCHECKED_CAST")
    val list =
        when (rawList) {
            is List<*> -> rawList.filterIsInstance<Map<String, Any>>()
            is Map<*, *> -> listOf(rawList as Map<String, Any>)
            else -> emptyList()
        }
    list.forEach { a ->
        val pkg = a["package"] as? String ?: return@forEach
        val used = (a["memory_used"] as? Number)?.toLong() ?: 0L
        if (used > 0) {
            apps[pkg] = used / mb
            val isCleanable = (a["cleanable"] as? Boolean) ?: true
            if (isCleanable) cleanable.add(pkg)
        }
    }
    return apps to cleanable.ifEmpty { apps.keys.toList() }
}

/** 媒体 RPC 用的最小 protobuf 载荷 */
private object Proto {
    /** /adaptive_media_bridging/rpc/media_update 的空查询（实测等价形态） */
    val EMPTY_MEDIA_QUERY: ByteArray = byteArrayOf(0x12, 0x00, 0x22, 0x02, 0x08, 0x01)
}
