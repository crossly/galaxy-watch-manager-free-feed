package dev.ricky.galaxywatchmanagerfree.feature

import dev.ricky.galaxywatchmanagerfree.wcs.WcsPaths
import org.json.JSONObject

internal class HealthMessagePipeline(
    private val isActive: () -> Boolean,
    private val mergeAndProject: (HealthPacket, receivedSync: Boolean, now: Long) -> Boolean,
    private val persist: (heartRateReportTime: Long?) -> Boolean,
    private val onDecoded: (HealthPacket) -> Unit = {},
) {
    private var pending = false

    data class AckCursor(val sequenceNum: Int, val action: String)

    sealed interface Result {
        data class Completed(
            val packet: HealthPacket,
            val persisted: Boolean,
            val ackCursor: AckCursor?,
        ) : Result

        data class DecodeFailed(val error: Exception) : Result

        data object PersistenceFailed : Result

        data object Skipped : Result
    }

    fun process(request: JSONObject, direction: HealthPacket.Direction, now: Long): Result {
        if (!isActive()) return Result.Skipped
        val body = request.optString("body")
        if (body.isEmpty()) return Result.Skipped
        val packet =
            try {
                decode(request, direction)
            } catch (error: Exception) {
                return Result.DecodeFailed(error)
            }
        if (!isActive()) return Result.Skipped
        onDecoded(packet)
        if (!isActive()) return Result.Skipped
        val isRequest =
            direction == HealthPacket.Direction.FROM_WATCH &&
                request.optString("message") == WcsPaths.HEALTH_MSG_REQUEST
        val receivedSync = isRequest && packet.action == WcsPaths.HEALTH_ACTION_SYNC_DATA
        val needsPersistence =
            pending ||
                packet.chunks.isNotEmpty() ||
                packet.action == WcsPaths.HEALTH_ACTION_SYNC_DATA
        if (needsPersistence) {
            // Failed or cancelled ingestion must keep later control packets behind the same write.
            pending = true
            if (!mergeAndProject(packet, receivedSync, now) || !isActive()) return Result.Skipped
            val receivedHeart =
                receivedSync && packet.chunks[HeartRateLog.MODULE].orEmpty().isNotEmpty()
            if (!persist(if (receivedHeart) now else null)) return Result.PersistenceFailed
            pending = false
        }
        val cursor =
            if (isActive() && isRequest && packet.action.isNotEmpty())
                AckCursor(packet.sequenceNum, packet.action)
            else null
        return Result.Completed(packet, persisted = needsPersistence, ackCursor = cursor)
    }

    private fun decode(request: JSONObject, direction: HealthPacket.Direction): HealthPacket {
        val decoded = HealthJson.entries(request.optString("body"))
        val entries = (0 until decoded.length()).mapNotNull { decoded.optJSONObject(it) }
        var action = ""
        var moduleList: String? = null
        var deviceModel: String? = null
        val chunks = linkedMapOf<String, List<JSONObject>>()
        for (entry in entries) {
            entry.optJSONArray("message_info")?.optJSONObject(0)?.let {
                action = it.optString("action")
                moduleList = it.optString("request_module_list").ifBlank { null }
            }
            entry.optJSONArray("device_info")?.let {
                deviceModel = it.optJSONObject(0)?.optString("device")
            }
            val keys = entry.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                if (key == "message_info" || key == "device_info") continue
                val rows = entry.optJSONArray(key) ?: continue
                chunks[key] =
                    chunks[key].orEmpty() +
                        (0 until rows.length()).mapNotNull { rows.optJSONObject(it) }
            }
        }
        return HealthPacket(
            direction,
            request.optInt("sequence_num"),
            action,
            moduleList,
            deviceModel,
            chunks,
            entries,
        )
    }
}
