package dev.ricky.galaxywatchmanagerfree.feature

import androidx.compose.runtime.Immutable
import org.json.JSONObject

/** Immutable snapshot of watch state used as the single source of truth for UI. */
@Immutable
data class WatchState(
    val connected: Boolean = false,
    val sessionReady: Boolean = false,
    val watchNode: String = "",
    val deviceName: String = "",
    val watchAlias: String = "",
    val modelNumber: String = "",
    val modelName: String = "",
    val firmware: String = "",
    val androidVersion: String = "",
    val wearOs: String = "",
    val batteryLevel: Int = -1,
    val batteryCapacityMah: String = "",
    val psmMode: Boolean = false,
    /** 2=charging, 3=discharging, 4=not charging, 5=full (BatteryManager) */
    val batteryStatus: Int = -1,
    val chargeTimeRemainingMs: Long = 0L,
    val remainingNormalMin: Int = 0,
    val remainingPsmMin: Int = 0,
    val normalBatteryEstimateReceived: Boolean = false,
    val psmBatteryEstimateReceived: Boolean = false,
    val psmControlRestricted: Boolean = false,
    val ramTotalMb: Long = 0L,
    val ramUsedMb: Long = 0L,
    val ramAvailableMb: Long = 0L,
    val ramApps: Map<String, Long> = emptyMap(),
    val ramCleanableApps: List<String> = emptyList(),
    /** 0=off, 1=on (dataMapId=206 key_battery_setting_status[0]) */
    val batteryProtection: Int = -1,
    val showChargingInfo: Int = -1,
    val autoPowerOn: Int = -1,
    val wearing: Boolean = false,
    val charging: Boolean = false,
    val esimSupported: Boolean = false,
    val eid: String = "",
    val imei: String = "",
    val actionButton: Boolean = false,
    val featureInfoReceived: Boolean = false,
    val settingItems: Map<String, SettingItem> = emptyMap(),
    val findWatch: FindWatchStatus = FindWatchStatus.IDLE,
    val brightness: Int = -1,
    val aodEnabled: Boolean = false,
    val wakeOnWrist: Boolean = false,
    val outdoorMode: Boolean = false,
    val screenTimeoutItem: Int = -1,
    val wakeOnTouch: Boolean = false,
    val wakeOnBezel: Boolean = false,
    val touchSound: Boolean = false,
    val chargingSound: Boolean = false,
    val gestureAnswer: Boolean = false,
    val gestureDismiss: Boolean = false,
    val quickLaunch: Boolean = false,
    val wristRight: Boolean = false,
    val negativeColors: Boolean = false,
    val removeAnimations: Boolean = false,
    val grayscaleEnabled: Boolean = false,
    val highContrastFonts: Boolean = false,
    val muteAllSounds: Boolean = false,
    val syncDnd: Boolean = false,
    val phoneNode: String = "",
    val startupSyncing: Boolean = false,
    val refreshing: Boolean = false,
    val watchfaceRefreshing: Boolean = false,
    val watchfaceUpdatedAt: Long = 0L,
    val activeWatchfacePkg: String? = null,
    val activeWatchfaceCls: String? = null,
    val activeWatchfaceFavoriteId: Int = -1,
    val activeWatchfacePreviewPath: String? = null,
    val watchfaceOrderType: String? = null,
    val watchfaceFavoriteIds: List<Int> = emptyList(),
    val watchfaceEditRequested: Boolean = false,
    val todaySteps: Int = -1,
    val todayCalories: Float = -1f,
    val todayDistanceMeters: Float = -1f,
    val stepGoal: Int = HealthGoals.DEFAULT_STEP_GOAL,
    val stepGoalSource: HealthGoals.Source = HealthGoals.Source.DEFAULT,
    val todayHours: List<Int> = emptyList(),
    val streakDays: Int = 0,
    val weekSteps: List<Int> = emptyList(),
    val dailyHistory: Map<String, HealthTimeline.Day> = emptyMap(),
    val sleepHistory: Map<String, Int> = emptyMap(),
    val sleep: SleepParser.Session? = null,
    val sleepSessions: List<SleepParser.Session> = emptyList(),
    val allSleepSessions: List<SleepParser.Session> = emptyList(),
    val sleepDays: Map<String, List<SleepParser.Session>> = emptyMap(),
    val sleepAnalysisRunning: Boolean = false,
    val weekSleep: List<Int> = emptyList(),
    val heartRatePoints: List<HeartRateLog.Point> = emptyList(),
    val heartRateHistory: Map<String, List<HeartRateLog.Point>> = emptyMap(),
    val heartRateDays: Map<String, HeartRateLog.Stats> = emptyMap(),
    val latestHeartRate: HeartRateLog.Point? = null,
    val heartRateWeek: List<HeartRateLog.Stats?> = emptyList(),
    val metricSamples: Map<HealthMetric, List<HealthMetricLog.Sample>> = emptyMap(),
    val vascularLoadSupported: Boolean = false,
    val vascularLoad: VascularLoadLog.Snapshot = VascularLoadLog.Snapshot(),
    val todayFloors: Int = -1,
    val exercises: List<ExerciseLog.Session> = emptyList(),
    val ecgRecords: List<dev.ricky.galaxywatchmanagerfree.feature.monitor.EcgRecord> = emptyList(),
    val bpRecords: List<dev.ricky.galaxywatchmanagerfree.feature.monitor.BpRecord> = emptyList(),
    val monitorState: dev.ricky.galaxywatchmanagerfree.feature.monitor.HealthMonitorSession.State =
        dev.ricky.galaxywatchmanagerfree.feature.monitor.HealthMonitorSession.State(),
    val lastHeartRate: Int = -1,
    val lastHeartRateReportTime: Long = 0L,
    val lastStressScore: Int = -1,
    val latestStress: StressLog.Point? = null,
    val stressHistory: Map<String, List<StressLog.Point>> = emptyMap(),
    val stressDays: Map<String, StressLog.Stats> = emptyMap(),
    val lastHealthSyncTime: Long = 0L,
    val healthSyncStatus: HealthSyncCoordinator.Status = HealthSyncCoordinator.Status.DISCONNECTED,
    val lastSyncAt: Long = 0L,
    val autoRefresh: Boolean = true,
    val autoQueryIntervalSeconds: Int = AutoQueryPolicy.DEFAULT_INTERVAL_SECONDS,
    val onboardingStatus: OnboardingStatus = OnboardingStatus.IDLE,
    val onboardingCandidateNode: String = "",
    val onboardingMessage: String = "",
) {
    val refreshInProgress: Boolean
        get() =
            refreshing || startupSyncing || healthSyncStatus == HealthSyncCoordinator.Status.SYNCING

    val canRefresh: Boolean
        get() = sessionReady && !refreshInProgress

    val isFindingWatch: Boolean
        get() = findWatch == FindWatchStatus.RINGING

    val displayName: String
        get() = watchAlias.ifBlank { deviceName.substringBefore(" (").ifBlank { "Galaxy Watch" } }
}

enum class OnboardingStatus {
    IDLE,
    ACQUIRING_IDENTITY,
    IDENTITY_MISSING,
    PREPARING_HANDOVER,
    CONNECTING,
    VERIFYING_IDENTITY,
    READY,
    ERROR,
}

enum class FindWatchStatus {
    IDLE,
    RINGING,
    FAILED,
}

/** Normalized setting item (type: 0=Boolean, 1=Int, 3=String, 5=Array). */
data class SettingItem(val path: String, val key: String, val type: Long, val value: Any) {
    val isBool: Boolean
        get() = value is Boolean || type == 0L

    val isInt: Boolean
        get() = value is Number || type == 1L

    val display: String
        get() =
            when (value) {
                is Boolean -> value.toString()
                is List<*> -> "List(${value.size})"
                else -> value.toString()
            }
}

/** 健康同步包（Samsung Health /samsung_health/wearable_message） */
data class HealthPacket(
    val direction: Direction,
    val sequenceNum: Int,
    val action: String,
    val moduleList: String?,
    val deviceModel: String?,
    val chunks: Map<String, List<JSONObject>>,
    val raw: List<JSONObject>,
) {
    enum class Direction {
        FROM_WATCH,
        FROM_PHONE,
    }
}
