package dev.ricky.galaxywatchmanagerfree.service

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import dev.ricky.galaxywatchmanagerfree.MainActivity
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.core.WatchController
import dev.ricky.galaxywatchmanagerfree.feature.ConnectionNotificationSnapshot
import dev.ricky.galaxywatchmanagerfree.feature.ConnectionNotificationState
import dev.ricky.galaxywatchmanagerfree.feature.LogBus
import dev.ricky.galaxywatchmanagerfree.feature.NotificationBarConfig
import dev.ricky.galaxywatchmanagerfree.feature.NotificationBarPreferences
import java.text.NumberFormat
import java.util.Locale
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

/** 常驻前台服务：维持与手表的 RFCOMM 长连接。 */
class WatchConnectionService : Service() {

    private var ownerGeneration: Long? = null
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var notificationJob: Job? = null

    override fun onCreate() {
        super.onCreate()
        NotificationBarPreferences.init(this)
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            WatchController.stopConnection(this)
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        startForegroundCompat()

        intent?.let {
            if (it.hasExtra("rn")) {
                WatchController.replayFrameLimit = it.getIntExtra("rn", 0)
                WatchController.handshakeMode =
                    dev.ricky.galaxywatchmanagerfree.core.HandshakeMode.REPLAY
            }
            if (it.hasExtra("labOnly"))
                WatchController.labOnly = it.getBooleanExtra("labOnly", true)
            if (it.hasExtra("backoff"))
                WatchController.initialBackoffMs = it.getLongExtra("backoff", 2000L)
            if (it.hasExtra("lab")) {
                WatchController.labMode = it.getIntExtra("lab", 0)
                WatchController.handshakeMode =
                    dev.ricky.galaxywatchmanagerfree.core.HandshakeMode.LAB
            }
            if (it.getBooleanExtra("replay", false)) {
                WatchController.handshakeMode =
                    dev.ricky.galaxywatchmanagerfree.core.HandshakeMode.REPLAY
            }
        }
        val mac = intent?.getStringExtra(EXTRA_MAC) ?: WatchController.savedMac
        LogBus.debug(
            "[SVC] onStartCommand mac=$mac enabled=${WatchController.enabled} flags=$flags startId=$startId"
        )
        if (mac.isNullOrBlank()) {
            LogBus.debug("[SVC] No saved watch; stopping idle service")
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf(startId)
            return START_NOT_STICKY
        }
        val generation =
            WatchController.admitServiceStart(
                mac,
                intent
                    ?.takeIf { it.hasExtra(EXTRA_GENERATION) }
                    ?.getLongExtra(EXTRA_GENERATION, -1L),
            )
        if (generation == null) {
            LogBus.debug("[SVC] Ignoring cancelled or superseded connection request")
            if (ownerGeneration == null) {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf(startId)
            }
            return START_NOT_STICKY
        }
        ownerGeneration = generation
        observeNotificationState()
        if (intent?.getBooleanExtra("wearApi", false) == true) WatchController.startWearApi(this)
        WatchController.startFromService(mac, generation)
        return START_STICKY
    }

    override fun onDestroy() {
        notificationJob?.cancel()
        serviceScope.cancel()
        ownerGeneration?.let { WatchController.stopIfCurrent(it) }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun startForegroundCompat() {
        val pi =
            PendingIntent.getActivity(
                this,
                0,
                Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
        val notif = buildNotification(currentNotificationSnapshot(), pi)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
        } else {
            startForeground(NOTIF_ID, notif)
        }
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java) ?: return
        val localized = dev.ricky.galaxywatchmanagerfree.core.AppLanguage.context(this)
        nm.createNotificationChannel(
            NotificationChannel(
                    CHANNEL_ID,
                    localized.getString(R.string.notif_channel_service),
                    NotificationManager.IMPORTANCE_LOW,
                )
                .apply {
                    setSound(null, null)
                    enableVibration(false)
                    setShowBadge(false)
                }
        )
    }

    private fun observeNotificationState() {
        notificationJob?.cancel()
        notificationJob =
            serviceScope.launch {
                var lastSnapshot: ConnectionNotificationSnapshot? = null
                combine(WatchController.repositoryState, NotificationBarPreferences.config) {
                        repo,
                        config ->
                        repo to config
                    }
                    .collectLatest { (repository, config) ->
                        if (repository == null) {
                            val snapshot = currentNotificationSnapshot(config)
                            if (snapshot != lastSnapshot) {
                                lastSnapshot = snapshot
                                publishNotification(snapshot)
                            }
                            return@collectLatest
                        }
                        repository.state.collect { state ->
                            val snapshot =
                                ConnectionNotificationSnapshot.from(state, config = config)
                            if (snapshot != lastSnapshot) {
                                lastSnapshot = snapshot
                                publishNotification(snapshot)
                            }
                        }
                    }
            }
    }

    private fun currentNotificationSnapshot(
        config: NotificationBarConfig = NotificationBarPreferences.current()
    ): ConnectionNotificationSnapshot {
        val state = WatchController.repositoryState.value?.state?.value
        return if (state == null) {
            ConnectionNotificationSnapshot.from(
                state = dev.ricky.galaxywatchmanagerfree.feature.WatchState(),
                config = config,
            )
        } else {
            ConnectionNotificationSnapshot.from(state = state, config = config)
        }
    }

    private fun publishNotification(snapshot: ConnectionNotificationSnapshot) {
        if (
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) !=
                    PackageManager.PERMISSION_GRANTED
        ) {
            return
        }
        val manager = getSystemService(NotificationManager::class.java) ?: return
        runCatching {
                manager.notify(
                    NOTIF_ID,
                    buildNotification(
                        snapshot,
                        PendingIntent.getActivity(
                            this,
                            0,
                            Intent(this, MainActivity::class.java),
                            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
                        ),
                    ),
                )
            }
            .onFailure { LogBus.error("[SVC] 更新常驻通知失败", it) }
    }

    private fun buildNotification(
        snapshot: ConnectionNotificationSnapshot,
        contentIntent: PendingIntent,
    ): Notification {
        val localized = dev.ricky.galaxywatchmanagerfree.core.AppLanguage.context(this)
        val title = snapshot.deviceName.ifBlank { localized.getString(R.string.app_name) }
        val metrics = notificationMetrics(snapshot, localized.resources)
        val status =
            when (snapshot.connection) {
                ConnectionNotificationState.READY ->
                    localized.getString(R.string.notif_connection_ready)
                ConnectionNotificationState.CONNECTING ->
                    localized.getString(R.string.notif_connection_connecting)
                ConnectionNotificationState.WAITING ->
                    localized.getString(R.string.notif_service_running)
            }
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(metrics)
            .setSubText(status)
            .setStyle(Notification.BigTextStyle().bigText(metrics))
            .setSmallIcon(R.drawable.ic_stat_watch)
            .setContentIntent(contentIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()
    }

    private fun notificationMetrics(
        snapshot: ConnectionNotificationSnapshot,
        strings: android.content.res.Resources,
    ): String {
        val numberFormat = NumberFormat.getIntegerInstance(strings.configuration.locales[0])
        val parts = mutableListOf<String>()
        val cfg = snapshot.config

        if (cfg.showBattery && snapshot.batteryLevel != null) {
            parts.add(strings.getString(R.string.notif_battery_metric, snapshot.batteryLevel))
        }

        if (cfg.showHeartRate) {
            if (snapshot.heartRate != null) {
                parts.add(strings.getString(R.string.notif_heart_rate_metric, snapshot.heartRate))
            } else {
                parts.add(strings.getString(R.string.notif_heart_rate_unknown))
            }
        }

        if (cfg.showSteps) {
            when {
                snapshot.steps == null -> parts.add(strings.getString(R.string.notif_steps_unknown))
                snapshot.stepGoal != null && snapshot.stepProgressPercent != null ->
                    parts.add(
                        strings.getString(
                            R.string.notif_steps_metric,
                            numberFormat.format(snapshot.steps),
                            numberFormat.format(snapshot.stepGoal),
                            snapshot.stepProgressPercent,
                        )
                    )
                else ->
                    parts.add(
                        strings.getString(
                            R.string.notif_steps_only,
                            numberFormat.format(snapshot.steps),
                        )
                    )
            }
        }

        if (cfg.showCalories && snapshot.calories != null && snapshot.calories > 0f) {
            parts.add(strings.getString(R.string.notif_calories_metric, snapshot.calories.toInt()))
        }

        if (cfg.showSleep && snapshot.sleepMinutes != null && snapshot.sleepMinutes > 0) {
            val h = snapshot.sleepMinutes / 60
            val m = snapshot.sleepMinutes % 60
            parts.add(strings.getString(R.string.notif_sleep_metric, h, m))
        }

        if (cfg.showDistance && snapshot.distanceMeters != null && snapshot.distanceMeters > 0f) {
            val km = snapshot.distanceMeters / 1000f
            parts.add(
                strings.getString(
                    R.string.notif_distance_metric,
                    String.format(Locale.getDefault(), "%.1f", km),
                )
            )
        }

        if (cfg.showStress && snapshot.stressScore != null && snapshot.stressScore > 0) {
            parts.add(strings.getString(R.string.notif_stress_metric, snapshot.stressScore))
        }

        return if (parts.isEmpty()) {
            strings.getString(R.string.notif_service_running)
        } else {
            parts.joinToString(" · ")
        }
    }

    companion object {
        const val CHANNEL_ID = "watch_connection"
        const val NOTIF_ID = 1001
        const val ACTION_STOP = "dev.ricky.galaxywatchmanagerfree.STOP"
        const val EXTRA_MAC = "mac"
        const val EXTRA_GENERATION = "connection_generation"

        fun startIntent(context: android.content.Context, mac: String?, generation: Long): Intent =
            Intent(context, WatchConnectionService::class.java)
                .putExtra(EXTRA_MAC, mac)
                .putExtra(EXTRA_GENERATION, generation)
    }
}
