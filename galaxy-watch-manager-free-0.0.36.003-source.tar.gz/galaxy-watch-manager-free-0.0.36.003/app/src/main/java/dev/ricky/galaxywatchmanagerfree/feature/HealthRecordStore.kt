package dev.ricky.galaxywatchmanagerfree.feature

import java.time.ZoneId
import org.json.JSONArray
import org.json.JSONObject

/**
 * Retained health records, shared by Message/Channel/DataItem ingestion. Upsert whole revisions
 * before deriving statistics; never merge already-aggregated averages.
 */
class HealthRecordStore(private val onRestoreFailure: (String) -> Unit = {}) {
    private val modules = linkedMapOf<String, LinkedHashMap<String, JSONObject>>()

    companion object {
        const val SCHEMA_VERSION = 1

        fun retentionDays(module: String): Int? =
            if (
                module in
                    setOf(
                        ExerciseLog.MODULE,
                        ExerciseLog.MODULE_ALIAS,
                        ExerciseLog.MODULE_ROUTINE,
                        ExerciseLog.MODULE_CUSTOM,
                        VascularLoadLog.MODULE,
                    )
            )
                null
            else 30

        fun recordLimit(module: String): Int = if (module == HeartRateLog.MODULE) 20_000 else 8_000

        private val supported =
            setOf(
                HealthStepParser.MODULE_STEP_COUNT,
                HealthStepParser.MODULE_DAY_SUMMARY,
                "com.samsung.shealth.tracker.heart_rate",
                "com.samsung.shealth.stress",
                VascularLoadLog.MODULE,
                SleepParser.MODULE_SLEEP,
                SleepParser.MODULE_SLEEP_LEGACY,
                SleepParser.MODULE_SLEEP_DATA,
                SleepParser.MODULE_SLEEP_STAGE,
                SleepParser.MODULE_SLEEP_STAGE_LEGACY,
                SleepParser.MODULE_SLEEP_RAW,
                SleepParser.MODULE_SLEEP_COMBINED,
                "com.samsung.shealth.floors_climbed",
                "com.samsung.health.floors_climbed",
                "com.samsung.shealth.exercise",
                "com.samsung.health.exercise",
                ExerciseLog.MODULE_ROUTINE,
                ExerciseLog.MODULE_CUSTOM,
                "com.samsung.shealth.service_preferences",
                "com.samsung.shealth.tracker.pedometer_recommendation",
            ) + HealthMetric.entries.flatMap { it.moduleKeys }

        private val identityFields =
            listOf(
                "datauuid",
                "deviceuuid",
                "start_time",
                "end_time",
                "day_time",
                "create_time",
                "update_time",
            )

        /**
         * All modules use the same normalized metadata before identity/revision/retention checks.
         */
        private fun normalized(record: JSONObject): JSONObject =
            JSONObject(record.toString()).apply {
                identityFields.forEach { name ->
                    if (has(name) && !isNull(name) && optString(name).isNotBlank()) return@forEach
                    val alias =
                        record
                            .keys()
                            .asSequence()
                            .filter { it.endsWith(".$name") }
                            .sorted()
                            .firstOrNull { !record.isNull(it) && record.optString(it).isNotBlank() }
                    if (alias != null) put(name, record.get(alias))
                }
            }

        fun identity(record: JSONObject): String {
            if (record.has("datauuid") && !record.isNull("datauuid")) {
                val direct = record.optString("datauuid")
                if (direct.isNotBlank()) return direct
            }
            return normalizedIdentity(normalized(record))
        }

        /** Callers that already normalized the row must not pay for another JSON round trip. */
        private fun normalizedIdentity(value: JSONObject): String {
            value
                .optString("datauuid")
                .takeIf { it.isNotBlank() }
                ?.let {
                    return it
                }
            if (!value.has("start_time") && value.optString("custom_id").isNotBlank())
                return "custom:${value.optString("custom_id")}"
            val parts =
                listOf("key", "deviceuuid", "start_time", "end_time", "day_time").map {
                    value.optString(it)
                }
            if (parts[0].isNotBlank() || parts.drop(2).any { it.isNotBlank() })
                return parts.joinToString("|")
            // Unidentified rows must not all overwrite one another under an empty key.
            return value.keys().asSequence().sorted().joinToString("|") { "$it=${value.opt(it)}" }
        }

        private fun revision(record: JSONObject): Long =
            listOf("update_time", "create_time").firstNotNullOfOrNull { key ->
                if (!record.has(key) || record.isNull(key)) null
                else record.optDouble(key, Double.NaN).takeIf { it.isFinite() }?.toLong()
            } ?: 0L

        /** Select whole revisions before expanding bins to discard stale alias bins. */
        fun newestRevisions(rows: List<Pair<String, JSONObject>>): List<Pair<String, JSONObject>> =
            rows
                .groupBy { identity(it.second) }
                .values
                .mapNotNull { revisions -> revisions.maxByOrNull { revision(it.second) } }

        private fun time(record: JSONObject): Long =
            listOf("end_time", "start_time", "day_time", "create_time", "update_time")
                .firstNotNullOfOrNull {
                    // `day_time` is often yyyyMMdd (e.g. 20261029), not epoch millis; a value
                    // below 2000-01-01 is not a usable retention timestamp.
                    record.optLong(it).takeIf { ts -> ts >= 946_684_800_000L }
                } ?: 0L
    }

    fun merge(chunks: Map<String, List<JSONObject>>, now: Long) {
        chunks.forEach { (module, incoming) ->
            if (module !in supported) return@forEach
            val rows = modules.getOrPut(module) { linkedMapOf() }
            incoming.forEach { incomingRecord ->
                val record = normalized(incomingRecord)
                val id = normalizedIdentity(record)
                val old = rows[id]
                if (old == null || revision(record) >= revision(old)) rows[id] = record
            }
        }
        modules.forEach { (module, rows) ->
            retentionDays(module)?.let { days ->
                val cutoff = now - days * 24L * 3_600_000
                rows.entries.removeAll { time(it.value) in 1 until cutoff }
            }
            val cap = recordLimit(module)
            if (rows.size > cap)
                rows.entries
                    .sortedByDescending { time(it.value) }
                    .drop(cap)
                    .forEach { rows.remove(it.key) }
        }
    }

    fun hasModule(key: String): Boolean = modules.containsKey(key)

    fun records(vararg keys: String): List<JSONObject> =
        keys.flatMap { modules[it]?.values.orEmpty() }

    fun recordsFor(metric: HealthMetric): List<JSONObject> =
        newestRevisions(
                metric.moduleKeys.flatMap { module ->
                    modules[module]?.values.orEmpty().map { module to it }
                }
            )
            .map { it.second }

    fun todaySteps(now: Long, zone: ZoneId = ZoneId.systemDefault()): List<JSONObject> =
        records(HealthStepParser.MODULE_STEP_COUNT).filter {
            HealthStepParser.isSameLocalDay(HealthStepParser.recordStartTime(it), now, zone)
        }

    fun replaceTodaySteps(
        records: List<JSONObject>,
        now: Long,
        zone: ZoneId = ZoneId.systemDefault(),
    ) {
        val rows = modules.getOrPut(HealthStepParser.MODULE_STEP_COUNT) { linkedMapOf() }
        rows.entries.removeAll {
            HealthStepParser.isSameLocalDay(HealthStepParser.recordStartTime(it.value), now, zone)
        }
        records.forEach { record ->
            val value = normalized(record)
            rows[normalizedIdentity(value)] = value
        }
    }

    fun encode(): String =
        JSONObject()
            .apply {
                put("version", SCHEMA_VERSION)
                put(
                    "modules",
                    JSONObject().apply {
                        modules.forEach { (module, rows) ->
                            put(module, JSONArray(rows.values.toList()))
                        }
                    },
                )
            }
            .toString()

    fun restore(raw: String?, now: Long): Boolean {
        if (raw.isNullOrBlank()) return true
        return try {
            val root = JSONObject(raw)
            require(root.optInt("version") == SCHEMA_VERSION) { "Unsupported health cache schema" }
            val data = root.getJSONObject("modules")
            val chunks =
                data.keys().asSequence().associateWith { module ->
                    val array = data.getJSONArray(module)
                    (0 until array.length()).mapNotNull(array::optJSONObject)
                }
            val restored = HealthRecordStore()
            restored.merge(chunks, now)
            modules.clear()
            modules.putAll(restored.modules)
            true
        } catch (error: Exception) {
            onRestoreFailure("健康缓存无法恢复：${error.javaClass.simpleName}")
            false
        }
    }
}
