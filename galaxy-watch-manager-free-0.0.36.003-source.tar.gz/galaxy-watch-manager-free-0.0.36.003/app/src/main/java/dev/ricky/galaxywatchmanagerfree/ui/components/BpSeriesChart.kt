package dev.ricky.galaxywatchmanagerfree.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.feature.monitor.BpRecord
import dev.ricky.galaxywatchmanagerfree.ui.theme.*

/** A numeric BP series; a single reading is a pair of points, never an invented waveform. */
@Composable
fun BpSeriesChart(records: List<BpRecord>, modifier: Modifier = Modifier) {
    val ordered = records.sortedBy { it.startTime }
    if (ordered.isEmpty()) return
    val systolicColor = HealthBloodPressure
    val diastolicColor = HealthBloodPressureSecondary
    val gridColor = CardBorder
    val minimum =
        ((ordered.minOf { minOf(it.systolic, it.diastolic) } - 10) / 10 * 10).coerceAtLeast(0)
    val maximum = (ordered.maxOf { maxOf(it.systolic, it.diastolic) } + 19) / 10 * 10
    Column(modifier.fillMaxWidth()) {
        Text(
            stringResource(R.string.bp_series_caption),
            style = MaterialTheme.typography.labelMedium,
            color = TextSecondary,
        )
        Text(
            "$minimum–$maximum mmHg",
            style = MaterialTheme.typography.labelSmall,
            color = TextTertiary,
        )
        Canvas(Modifier.fillMaxWidth().height(120.dp)) {
            val inset = 12.dp.toPx()
            val width = (size.width - 2 * inset).coerceAtLeast(1f)
            val height = size.height - 2 * inset
            fun y(value: Int) =
                inset + height * (maximum - value) / (maximum - minimum).coerceAtLeast(1)
            val first = ordered.first().startTime
            val duration = ordered.last().startTime - first
            fun x(record: BpRecord) =
                if (duration == 0L) size.width / 2
                else inset + width * ((record.startTime - first).toDouble() / duration).toFloat()
            repeat(4) { line ->
                val py = inset + height * line / 3
                drawLine(gridColor, Offset(inset, py), Offset(size.width - inset, py))
            }
            ordered.forEachIndexed { index, record ->
                val sys = Offset(x(record), y(record.systolic))
                val dia = Offset(x(record), y(record.diastolic))
                if (index > 0) {
                    val previous = ordered[index - 1]
                    drawLine(
                        systolicColor,
                        Offset(x(previous), y(previous.systolic)),
                        sys,
                        2.dp.toPx(),
                        StrokeCap.Round,
                    )
                    drawLine(
                        diastolicColor,
                        Offset(x(previous), y(previous.diastolic)),
                        dia,
                        2.dp.toPx(),
                        StrokeCap.Round,
                    )
                }
                drawCircle(systolicColor, 4.dp.toPx(), sys)
                drawCircle(diastolicColor, 4.dp.toPx(), dia)
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(
                formatClock(ordered.first().startTime),
                style = MaterialTheme.typography.labelSmall,
                color = TextTertiary,
            )
            if (ordered.size > 1)
                Text(
                    formatClock(ordered.last().startTime),
                    style = MaterialTheme.typography.labelSmall,
                    color = TextTertiary,
                )
        }
    }
}
