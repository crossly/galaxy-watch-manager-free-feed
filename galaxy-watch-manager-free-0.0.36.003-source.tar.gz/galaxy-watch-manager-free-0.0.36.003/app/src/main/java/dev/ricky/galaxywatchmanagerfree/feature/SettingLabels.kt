package dev.ricky.galaxywatchmanagerfree.feature

import dev.ricky.galaxywatchmanagerfree.R

/** User-facing labels; protocol identifiers stay available separately for diagnostics. */
class SettingLabels(
    private val locale: java.util.Locale = java.util.Locale.getDefault(),
    private val getString: (Int) -> String,
) {
    private fun text(id: Int, vararg args: Any): String =
        if (args.isEmpty()) getString(id) else String.format(locale, getString(id), *args)

    data class Label(
        val title: String,
        val category: String,
        val known: Boolean,
        val description: String,
    )

    private val sections =
        mapOf(
            "display" to R.string.display,
            "sound_settings" to R.string.sounds_and_vibration,
            "advanced" to R.string.buttons_and_gestures,
            "general" to R.string.setting_general,
            "phone" to R.string.setting_phone_integration,
            "bedtime" to R.string.setting_sleep_mode,
            "securitysetting" to R.string.setting_security,
            "info" to R.string.setting_device_information,
            "feature" to R.string.setting_device_capabilities,
            "account" to R.string.setting_account,
            "apps" to R.string.settings_apps,
            "psm" to R.string.power_saving,
        )
    private val words =
        mapOf(
            "always_on_display" to R.string.always_on_display,
            "disabled" to R.string.setting_unavailable_status,
            "brightness" to R.string.screen_brightness,
            "brightness_max_level" to R.string.setting_maximum_brightness,
            "font_size" to R.string.setting_font_size,
            "font_size_max" to R.string.setting_maximum_font_size,
            "font_style" to R.string.setting_font_style,
            "screen_time_out" to R.string.setting_screen_timeout,
            "outdoor_mode" to R.string.setting_outdoor_brightness,
            "touch_sensitivity" to R.string.setting_touch_sensitivity,
            "wake_on_wrist_raised" to R.string.raise_to_wake,
            "wake_on_touch_screen" to R.string.touch_to_wake,
            "wake_on_turning_bezel" to R.string.rotate_bezel_to_wake,
            "bold_font" to R.string.setting_bold_text,
            "auto_low_brightness" to R.string.setting_auto_dim,
            "show_charging_info" to R.string.setting_show_charging_information,
            "show_last_app" to R.string.setting_show_last_app,
            "selected_item" to R.string.setting_current_option,
            "selected_value" to R.string.setting_current_value,
            "selected_name" to R.string.setting_current_name,
            "selected_package" to R.string.setting_current_app,
            "list" to R.string.setting_available_items,
            "sound_mode" to R.string.setting_sound_mode,
            "volume" to R.string.setting_volume,
            "ringtone" to R.string.setting_ringtone,
            "name" to R.string.setting_name,
            "media" to R.string.setting_media,
            "notifications" to R.string.notifications,
            "system" to R.string.setting_system,
            "accessibility" to R.string.setting_accessibility,
            "ai_assistant" to R.string.setting_voice_assistant,
            "bixby" to R.string.setting_bixby_voice_assistant,
            "digital_assistant" to R.string.setting_digital_assistant,
            "vibration_intensity" to R.string.setting_vibration_intensity,
            "vibration_type" to R.string.setting_vibration_pattern,
            "vibration_with_sound" to R.string.setting_vibrate_while_ringing,
            "vibration_feedback" to R.string.setting_touch_vibration_feedback,
            "notification_sound" to R.string.setting_notification_sound,
            "notification_vibration" to R.string.setting_notification_vibration,
            "ringtone_vibration" to R.string.setting_call_vibration,
            "system_sounds" to R.string.setting_system_sounds,
            "system_vibration" to R.string.setting_system_vibration,
            "touch_sound" to R.string.setting_touch_sound,
            "charging_sound" to R.string.charging_sound,
            "unlock_sound" to R.string.setting_unlock_sound,
            "hourly_chime" to R.string.setting_hourly_chime,
            "dialing_keypad_tone" to R.string.setting_dial_pad_tones,
            "dialing_keypad" to R.string.setting_dial_pad,
            "samsung_keyboard" to R.string.setting_samsung_keyboard,
            "ticking_sound" to R.string.setting_ticking_sound,
            "charging" to R.string.setting_charging,
            "on_off" to R.string.setting_switch,
            "enabled" to R.string.setting_enabled_status,
            "schedule_info" to R.string.setting_schedule,
            "watch_schedule_info" to R.string.setting_watch_schedule,
            "lifestyle_info" to R.string.setting_routine_information,
            "mode_info" to R.string.setting_mode_information,
            "sync_bedtime_mode" to R.string.setting_sync_sleep_mode,
            "turn_on_now" to R.string.setting_turn_on_now,
            "turn_on_scheduled" to R.string.setting_turn_on_as_scheduled,
            "action_button" to R.string.setting_quick_button,
            "how_to_start_action" to R.string.setting_action_trigger,
            "selected_health_id" to R.string.setting_selected_health_feature_id,
            "siren" to R.string.setting_siren,
            "double_press" to R.string.setting_double_press_home_button,
            "press_and_hold" to R.string.setting_press_and_hold_home_button,
            "recents_key" to R.string.setting_back_button,
            "gestures" to R.string.setting_gestures,
            "answer_calls" to R.string.setting_answer_calls,
            "dismiss_alerts_and_reject_calls" to R.string.setting_dismiss_alerts_and_reject_calls,
            "quick_action" to R.string.setting_quick_gesture,
            "alarm_alerts" to R.string.setting_alarm_alerts,
            "calendar_alerts" to R.string.setting_calendar_alerts,
            "reminder_alerts" to R.string.setting_reminders,
            "media_controller" to R.string.setting_media_controls,
            "watchface" to R.string.watch_faces,
            "setting" to R.string.settings,
            "second_action_detail_setting" to R.string.setting_second_action_details,
            "second_action_enabled" to R.string.setting_enable_second_action,
            "raise_to_talk" to R.string.setting_raise_to_talk,
            "labs" to R.string.setting_labs,
            "quicklaunch" to R.string.setting_quick_launch,
            "launch_package" to R.string.setting_launch_app,
            "list_apps" to R.string.setting_available_apps,
            "list_features" to R.string.setting_available_features,
            "feature_list" to R.string.setting_feature_list,
            "support" to R.string.setting_support_status,
            "theater_mode" to R.string.setting_theater_mode,
            "status_indicator" to R.string.setting_status_indicator,
            "disconnection_alert" to R.string.setting_disconnection_alert,
            "dont_get_alarm" to R.string.setting_dismiss_alerts,
            "sa_place_address" to R.string.setting_place_address,
            "support_app_background_update" to R.string.setting_background_updates_supported,
            "media_control" to R.string.setting_media_controls,
            "auto_launch_media_controls" to R.string.setting_auto_launch_media_controls,
            "show_ongoing_icon" to R.string.setting_show_ongoing_media_icon,
            "orientation" to R.string.setting_orientation,
            "selected_wrist" to R.string.setting_wrist,
            "selected_button_position" to R.string.setting_button_position,
            "touch_bezel" to R.string.setting_touch_bezel,
            "touch_bezel_feedback" to R.string.setting_bezel_touch_feedback,
            "quick_responses" to R.string.setting_quick_replies,
            "custom_responses" to R.string.setting_custom_replies,
            "smart_reply" to R.string.setting_smart_replies,
            "transfer_watch" to R.string.setting_transfer_watch,
            "phone_switching_available" to R.string.setting_allow_new_phone_connection,
            "is_pattern" to R.string.setting_pattern_lock_status,
            "is_3p_enabled" to R.string.setting_third_party_input_supported,
            "is_orientation_menu_visible_in_watch" to
                R.string.setting_show_orientation_menu_on_watch,
            "input" to R.string.setting_input,
            "default_keyboard_list" to R.string.setting_available_keyboards,
            "message_suggestion" to R.string.setting_message_suggestions,
            "selected_default_keyboard" to R.string.setting_default_keyboard,
            "keyboard_settings" to R.string.setting_keyboard_settings,
            "auto_capitalize" to R.string.setting_auto_capitalize,
            "auto_replace_languages" to R.string.setting_auto_replace_languages,
            "auto_space_languages" to R.string.setting_auto_spacing_languages,
            "continuous_input" to R.string.setting_continuous_input,
            "delete_languages" to R.string.setting_remove_languages,
            "double_tap_space_bar_to_add_period" to
                R.string.setting_double_tap_space_to_add_a_period,
            "downloaded_languages" to R.string.setting_downloaded_languages,
            "enable_text_shortcuts" to R.string.setting_text_shortcuts,
            "input_type_list" to R.string.setting_available_input_methods,
            "selected_input_type" to R.string.setting_current_input_method,
            "is_swipe_controls_menu_enabled" to R.string.setting_enable_swipe_controls_menu,
            "is_swipe_controls_menu_visible_in_watch" to
                R.string.setting_show_swipe_controls_menu_on_watch,
            "is_text_shortcuts_supported_in_watch" to
                R.string.setting_text_shortcuts_supported_on_watch,
            "languages_list" to R.string.setting_available_languages,
            "predictive_text" to R.string.setting_predictive_text,
            "reorder_languages" to R.string.setting_language_order,
            "sound" to R.string.setting_key_sounds,
            "vibration" to R.string.setting_key_vibration,
            "update_languages" to R.string.setting_update_languages,
            "use_languages" to R.string.setting_languages_in_use,
            "voice_privacy_policy" to R.string.setting_voice_privacy_policy,
            "languages" to R.string.setting_language,
            "tts_available_language_list" to R.string.setting_available_speech_languages,
            "tts_downloadable_language_list" to R.string.setting_downloadable_speech_languages,
            "tts_language_list" to R.string.setting_speech_language_list,
            "tts_network_permission_required" to
                R.string.setting_network_permission_needed_for_speech,
            "tts_preferred_engine_list" to R.string.setting_available_speech_engines,
            "tts_selected_language" to R.string.setting_speech_language,
            "tts_selected_preferred_engine" to R.string.setting_speech_engine,
            "tts_speech_rate" to R.string.setting_speech_rate,
            "wrist_detection" to R.string.setting_wrist_detection,
            "dnd" to R.string.setting_do_not_disturb,
            "sync_do_not_disturb" to R.string.setting_sync_do_not_disturb,
            "dnd_turn_on_now" to R.string.setting_turn_on_do_not_disturb_now,
            "duration" to R.string.setting_duration,
            "policy" to R.string.setting_do_not_disturb_rules,
            "application_info" to R.string.setting_app_information,
            "background_activity" to R.string.setting_background_activity,
            "legal_info" to R.string.setting_legal_information,
            "diagnostic_data" to R.string.setting_diagnostic_data,
            "setting_info" to R.string.setting_device_settings_information,
            "watch_name" to R.string.setting_watch_name,
            "setting_info_nal" to R.string.setting_settings_permission_status,
            "setting_info_support_feature" to R.string.setting_device_feature_support,
            "auto_backup" to R.string.setting_auto_backup,
            "selfdiagnostics" to R.string.setting_device_diagnostics,
            "account" to R.string.setting_account_information,
            "psm" to R.string.power_saving,
            "grayscale" to R.string.grayscale,
            "high_contrast_fonts" to R.string.setting_high_contrast_text,
            "mute_all_sound" to R.string.setting_mute_all_sounds,
            "mute_all_sounds" to R.string.setting_mute_all_sounds,
            "negative_colors" to R.string.setting_invert_colors,
            "remove_animations" to R.string.setting_reduce_animations,
            "reduce_transparency_and_blur" to R.string.setting_reduce_transparency_and_blur,
            "color_correction_enabled" to R.string.setting_color_correction,
            "color_lens_enabled" to R.string.setting_color_filter,
            "color_lens_opacity" to R.string.setting_color_filter_opacity,
            "talkback" to R.string.setting_screen_reader,
            "auto_scanning" to R.string.setting_auto_scan,
            "ignore_repeated_touches" to R.string.setting_ignore_repeated_touches,
            "ignore_repeated_touches_time" to R.string.setting_repeated_touch_interval,
            "lr_sound_balance" to R.string.setting_left_right_sound_balance,
            "mono_audio" to R.string.setting_mono_audio,
            "quick_activation" to R.string.setting_quick_activation,
            "quick_activation_availability" to R.string.setting_quick_activation_availability,
            "tap_duration" to R.string.setting_touch_duration,
            "tap_duration_time" to R.string.setting_touch_duration_2,
            "triple_tap_magnify" to R.string.setting_triple_tap_magnification,
            "universal_gestures" to R.string.setting_universal_gestures,
            "universal_gesture_availability" to R.string.setting_universal_gestures_availability,
            "universal_gesture_tutorial_availability" to
                R.string.setting_gesture_tutorial_available,
            "first_tutorial_completed" to R.string.setting_first_tutorial_completed,
            "vibration_watch_enabled" to R.string.setting_vibration_watch,
            "triple_press_availability" to R.string.setting_triple_press_button_availability,
            "accessibility_installed_applications" to R.string.setting_installed_accessibility_apps,
            "accessibility_installed_applications_enabled" to
                R.string.setting_enabled_accessibility_apps,
            "activation" to R.string.setting_activation_method,
            "clench" to R.string.setting_clench,
            "double_clench" to R.string.setting_double_clench,
            "pinch" to R.string.setting_pinch,
            "double_pinch" to R.string.setting_double_pinch,
            "in_and_out" to R.string.setting_in_and_out_movement,
            "favorites_action" to R.string.setting_favorite_actions,
            "focus_indicator_color" to R.string.setting_focus_indicator_color,
            "cursor_color" to R.string.setting_cursor_color,
            "cursor_speed" to R.string.setting_cursor_speed,
            "delay_time_before_action" to R.string.setting_delay_before_action,
            "number_of_scan" to R.string.setting_scan_count,
            "scanning_speed" to R.string.setting_scan_speed,
            "time_to_take_action" to R.string.setting_time_to_take_action,
            "touch_and_hold_delay" to R.string.setting_touch_and_hold_delay,
            "vibration_speed" to R.string.setting_vibration_speed,
            "vibration_watch_type" to R.string.setting_vibration_watch_style,
            "color_correction_color_type" to R.string.setting_color_correction_type,
            "color_lens_color_type" to R.string.setting_color_filter_color,
            "favorites_action_list" to R.string.setting_favorite_actions_list,
            "accessibility_enabled" to R.string.setting_accessibility_shortcuts,
            "color_correction_type" to R.string.setting_color_correction_type,
            "color_lens_type" to R.string.setting_color_filter_color,
        )

    private fun translate(segment: String): String? {
        words[segment]?.let {
            return text(it)
        }
        if (segment.startsWith("selected_"))
            return translate(segment.removePrefix("selected_"))?.let {
                text(R.string.setting_current_option_2, it)
            }
        if (segment.endsWith("_list"))
            return translate(segment.removeSuffix("_list"))?.let {
                text(R.string.setting_available_items_2, it)
            }
        if (segment.startsWith("triple_press_"))
            return translate(segment.removePrefix("triple_press_").removeSuffix("_enabled"))?.let {
                text(R.string.setting_triple_press_button, it)
            }
        if (segment.startsWith("two_finger_triple_tap_"))
            return translate(
                    segment.removePrefix("two_finger_triple_tap_").removeSuffix("_enabled")
                )
                ?.let { text(R.string.setting_two_finger_triple_tap, it) }
        return null
    }

    fun describe(path: String): Label {
        val normalized = "/" + path.trimStart('/')
        val accessibility = normalized.startsWith("/w_module_sec_watch_setting_accessibility/")
        val parts =
            normalized
                .substringAfter("/w_module_sec_watch_setting")
                .removePrefix("_accessibility")
                .trim('/')
                .split('/')
                .filter { it.isNotBlank() }
        val category =
            if (accessibility) text(R.string.setting_accessibility)
            else
                sections[parts.firstOrNull()]?.let { text(it) }
                    ?: text(R.string.setting_device_settings)
        val fields = if (accessibility || parts.size == 1) parts else parts.drop(1)
        val translated = fields.map { translate(it) }
        val known = translated.isNotEmpty() && translated.all { it != null }
        val title =
            if (known) translated.filterNotNull().joinToString(" · ")
            else text(R.string.setting_unrecognized_setting)
        val description =
            when {
                fields.lastOrNull()?.contains("list") == true ->
                    text(R.string.setting_options_explanation)
                fields.lastOrNull()?.contains("support") == true ||
                    fields.lastOrNull()?.contains("availability") == true ->
                    text(R.string.setting_support_explanation)
                !known -> text(R.string.setting_unknown_explanation)
                else -> ""
            }
        return Label(title, category, known, description)
    }

    fun value(item: SettingItem): String =
        when (val value = item.value) {
            is Boolean -> if (value) text(R.string.on) else text(R.string.off)
            is List<*> ->
                if (value.isEmpty()) text(R.string.setting_no_available_items)
                else text(R.string.setting_items, value.size)
            is Number ->
                when {
                    item.path.endsWith("/sound_mode") ->
                        listOf(
                                text(R.string.setting_mute),
                                text(R.string.setting_vibrate),
                                text(R.string.setting_sound),
                            )
                            .getOrNull(value.toInt())
                            ?: text(R.string.setting_option, value.toInt())
                    item.path.endsWith("/selected_wrist") ->
                        if (value.toInt() == 1) text(R.string.right_wrist)
                        else text(R.string.left_wrist)
                    item.path.endsWith("/selected_button_position") ->
                        if (value.toInt() == 1) text(R.string.setting_right)
                        else text(R.string.setting_left)
                    item.path.contains("selected_") ->
                        text(R.string.setting_option_watch_id, value.toInt())
                    else -> value.toString()
                }
            else ->
                when (value.toString().lowercase()) {
                    "true",
                    "on",
                    "enabled" -> text(R.string.on)
                    "false",
                    "off",
                    "disabled" -> text(R.string.off)
                    "vibrate",
                    "vibration" -> text(R.string.setting_vibrate)
                    "sound",
                    "normal",
                    "ring" -> text(R.string.setting_sound)
                    "silent",
                    "mute" -> text(R.string.setting_mute)
                    "left" -> text(R.string.setting_left)
                    "right" -> text(R.string.setting_right)
                    "" -> text(R.string.not_set)
                    else -> value.toString()
                }
        }
}
