package dev.ricky.galaxywatchmanagerfree.ui.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Accent families exposed by appearance settings. */
enum class AccentFamily {
    SYSTEM,
    BLUE,
    VIOLET,
    MINT;

    companion object {
        fun fromPreference(value: Int): AccentFamily =
            when (value) {
                ThemeController.COLOR_BLUE -> BLUE
                ThemeController.COLOR_VIOLET -> VIOLET
                ThemeController.COLOR_MINT -> MINT
                else -> SYSTEM
            }
    }
}

@Immutable
data class WfPalette(
    val deepCanvas: Color,
    val surfaceDark: Color,
    val cardSurface: Color,
    val cardSurfaceElevated: Color,
    val cardBorder: Color,
    val cardBorderGlow: Color,
    val surfaceContainerLow: Color,
    val surfaceContainer: Color,
    val surfaceContainerHigh: Color,
    val primaryContainer: Color,
    val onPrimaryContainer: Color,
    val electricBlue: Color,
    val electricBlueGlow: Color,
    val healthSteps: Color,
    val healthHeart: Color,
    val healthStress: Color,
    val healthSleep: Color,
    val healthOxygen: Color,
    val healthTemperature: Color,
    val healthRespiratory: Color,
    val healthHrv: Color,
    val healthBloodPressure: Color,
    val healthBloodPressureSecondary: Color,
    val sleepDeep: Color,
    val sleepLight: Color,
    val sleepRem: Color,
    val sleepAwake: Color,
    val emeraldCharging: Color,
    val emeraldGlow: Color,
    val warningAmber: Color,
    val alertCrimson: Color,
    val offMuted: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textTertiary: Color,
    val textDisabled: Color,
    val terminalBg: Color,
)

// Seed fallback: a neutral violet Material palette, also used below Android 12.
val LightScheme =
    lightColorScheme(
        primary = Color(0xFF65558F),
        onPrimary = Color.White,
        primaryContainer = Color(0xFFE9DDFF),
        onPrimaryContainer = Color(0xFF211047),
        secondary = Color(0xFF625B71),
        tertiary = Color(0xFF7D5260),
        surface = Color(0xFFFCFCFC),
        surfaceBright = Color(0xFFFFFFFF),
        surfaceContainerLow = Color(0xFFF6F6F6),
        surfaceContainer = Color(0xFFF0F0F0),
        surfaceContainerHigh = Color(0xFFEAEAEA),
        surfaceContainerHighest = Color(0xFFE4E4E4),
        onSurface = Color(0xFF1B1B1F),
        onSurfaceVariant = Color(0xFF46464F),
        outline = Color(0xFF777680),
        outlineVariant = Color(0xFFC7C5D0),
        background = Color(0xFFF6F6F6),
        onBackground = Color(0xFF1B1B1F),
    )
val DarkScheme =
    darkColorScheme(
        primary = Color(0xFFCFBDFF),
        onPrimary = Color(0xFF36275D),
        primaryContainer = Color(0xFF4D3D75),
        onPrimaryContainer = Color(0xFFE9DDFF),
        secondary = Color(0xFFCBC2DB),
        tertiary = Color(0xFFEFB8C8),
        surface = Color(0xFF121316),
        surfaceBright = Color(0xFF38393D),
        surfaceContainerLow = Color(0xFF1A1B1E),
        surfaceContainer = Color(0xFF1E1F22),
        surfaceContainerHigh = Color(0xFF292A2D),
        surfaceContainerHighest = Color(0xFF343538),
        onSurface = Color(0xFFE4E1E6),
        onSurfaceVariant = Color(0xFFC7C5D0),
        outline = Color(0xFF918F9A),
        outlineVariant = Color(0xFF46464F),
        background = Color(0xFF121316),
        onBackground = Color(0xFFE4E1E6),
    )

private data class Hsl(val hue: Float, val saturation: Float, val lightness: Float)

private data class HealthHueProfile(
    val steps: Float,
    val heart: Float,
    val stress: Float,
    val sleep: Float,
    val sleepRem: Float,
    val oxygen: Float,
    val temperature: Float,
    val respiratory: Float,
    val hrv: Float,
    val bloodPressure: Float,
)

private data class HealthColors(
    val steps: Color,
    val heart: Color,
    val stress: Color,
    val sleep: Color,
    val sleepDeep: Color,
    val sleepLight: Color,
    val sleepRem: Color,
    val sleepAwake: Color,
    val oxygen: Color,
    val temperature: Color,
    val respiratory: Color,
    val hrv: Color,
    val bloodPressure: Color,
    val bloodPressureSecondary: Color,
)

/** Theme roles for the page, cards and inset blocks. */
fun paletteFor(
    scheme: ColorScheme,
    dark: Boolean,
    accentFamily: AccentFamily = AccentFamily.SYSTEM,
): WfPalette =
    with(scheme) {
        val success = if (dark) Color(0xFF6FDEA2) else Color(0xFF15804A)
        val health = healthPaletteFor(scheme, dark, accentFamily)
        WfPalette(
            deepCanvas = if (dark) surface else surfaceContainer,
            surfaceDark = if (dark) surfaceContainerHigh else surfaceBright,
            cardSurface = if (dark) surfaceContainer else surfaceBright,
            cardSurfaceElevated = if (dark) surfaceContainerHigh else surfaceContainer,
            cardBorder = outlineVariant,
            cardBorderGlow = outlineVariant,
            surfaceContainerLow = surfaceContainerLow,
            surfaceContainer = surfaceContainer,
            surfaceContainerHigh = surfaceContainerHigh,
            primaryContainer = primaryContainer,
            onPrimaryContainer = onPrimaryContainer,
            electricBlue = primary,
            electricBlueGlow = primary.copy(alpha = 0.12f),
            healthSteps = health.steps,
            healthHeart = health.heart,
            healthStress = health.stress,
            healthSleep = health.sleep,
            healthOxygen = health.oxygen,
            healthTemperature = health.temperature,
            healthRespiratory = health.respiratory,
            healthHrv = health.hrv,
            healthBloodPressure = health.bloodPressure,
            healthBloodPressureSecondary = health.bloodPressureSecondary,
            sleepDeep = health.sleepDeep,
            sleepLight = health.sleepLight,
            sleepRem = health.sleepRem,
            sleepAwake = health.sleepAwake,
            emeraldCharging = success,
            emeraldGlow = success.copy(alpha = 0.12f),
            warningAmber = if (dark) Color(0xFFE9C16C) else Color(0xFF795900),
            alertCrimson = error,
            offMuted = onSurface.copy(alpha = 0.38f),
            textPrimary = onSurface,
            textSecondary = onSurfaceVariant,
            textTertiary = onSurfaceVariant.copy(alpha = 0.8f),
            textDisabled = onSurface.copy(alpha = 0.38f),
            terminalBg = if (dark) surface else surfaceContainerLow,
        )
    }

private fun healthPaletteFor(
    scheme: ColorScheme,
    dark: Boolean,
    family: AccentFamily,
): HealthColors {
    val profile =
        when (family) {
            AccentFamily.BLUE ->
                HealthHueProfile(
                    steps = 38f,
                    heart = 348f,
                    stress = 176f,
                    sleep = 232f,
                    sleepRem = 268f,
                    oxygen = 192f,
                    temperature = 25f,
                    respiratory = 187f,
                    hrv = 275f,
                    bloodPressure = 348f,
                )
            AccentFamily.VIOLET ->
                HealthHueProfile(
                    steps = 10f,
                    heart = 330f,
                    stress = 158f,
                    sleep = 276f,
                    sleepRem = 308f,
                    oxygen = 184f,
                    temperature = 42f,
                    respiratory = 168f,
                    hrv = 310f,
                    bloodPressure = 326f,
                )
            AccentFamily.MINT ->
                HealthHueProfile(
                    steps = 58f,
                    heart = 6f,
                    stress = 169f,
                    sleep = 208f,
                    sleepRem = 242f,
                    oxygen = 177f,
                    temperature = 34f,
                    respiratory = 194f,
                    hrv = 228f,
                    bloodPressure = 8f,
                )
            AccentFamily.SYSTEM ->
                HealthHueProfile(
                    steps = 36f,
                    heart = 346f,
                    stress = 169f,
                    sleep = 246f,
                    sleepRem = 280f,
                    oxygen = 192f,
                    temperature = 28f,
                    respiratory = 186f,
                    hrv = 278f,
                    bloodPressure = 346f,
                )
        }
    val anchor = scheme.primary.toHsl()
    val pull = if (family == AccentFamily.SYSTEM) 0.22f else 0.045f
    val saturationLift =
        ((anchor.saturation - 0.55f) * if (family == AccentFamily.SYSTEM) 0.18f else 0.05f)
            .coerceIn(-0.06f, 0.08f)
    val lightnessLift =
        ((anchor.lightness - 0.5f) * if (family == AccentFamily.SYSTEM) 0.04f else 0.01f).coerceIn(
            -0.02f,
            0.02f,
        )
    val familySaturation =
        when (family) {
            AccentFamily.BLUE -> 0.025f
            AccentFamily.VIOLET -> -0.015f
            AccentFamily.MINT -> 0.01f
            AccentFamily.SYSTEM -> 0f
        }
    val familyLightness =
        when (family) {
            AccentFamily.BLUE -> -0.012f
            AccentFamily.VIOLET -> 0.005f
            AccentFamily.MINT -> 0.012f
            AccentFamily.SYSTEM -> 0f
        }

    fun color(
        hue: Float,
        saturation: Float,
        darkLightness: Float,
        lightLightness: Float,
        rolePull: Float = pull,
    ): Color =
        fromHsl(
            hue = harmonizeHue(hue, anchor.hue, rolePull),
            saturation = (saturation + saturationLift + familySaturation).coerceIn(0.34f, 0.82f),
            lightness =
                ((if (dark) darkLightness else lightLightness) + lightnessLift + familyLightness)
                    .coerceIn(0.28f, 0.82f),
        )

    val sleepDeep = color(profile.sleep, 0.62f, 0.70f, 0.38f)
    return HealthColors(
        steps = color(profile.steps, 0.70f, 0.72f, 0.41f),
        heart = color(profile.heart, 0.64f, 0.74f, 0.44f, rolePull = pull * 0.65f),
        stress = color(profile.stress, 0.55f, 0.69f, 0.37f),
        sleep = color(profile.sleep, 0.60f, 0.73f, 0.41f),
        sleepDeep = sleepDeep,
        sleepLight = color(profile.sleep + 8f, 0.43f, 0.79f, 0.53f, rolePull = pull * 0.6f),
        sleepRem =
            color(
                profile.sleepRem,
                0.57f,
                0.77f,
                0.45f,
                rolePull = if (family == AccentFamily.SYSTEM) pull * 0.4f else pull * 0.7f,
            ),
        sleepAwake = if (dark) Color(0xFFE9C16C) else Color(0xFF795900),
        oxygen = color(profile.oxygen, 0.60f, 0.72f, 0.38f),
        temperature = color(profile.temperature, 0.66f, 0.73f, 0.39f),
        respiratory = color(profile.respiratory, 0.55f, 0.70f, 0.36f),
        hrv = color(profile.hrv, 0.58f, 0.74f, 0.42f),
        bloodPressure = color(profile.bloodPressure, 0.63f, 0.73f, 0.43f),
        bloodPressureSecondary =
            color(profile.bloodPressure + 6f, 0.48f, 0.80f, 0.53f, rolePull = pull * 0.6f),
    )
}

private fun Color.toHsl(): Hsl {
    val maxChannel = max(red, max(green, blue))
    val minChannel = min(red, min(green, blue))
    val delta = maxChannel - minChannel
    val lightness = (maxChannel + minChannel) / 2f
    if (delta < 0.0001f) return Hsl(0f, 0f, lightness)
    val saturation =
        if (lightness > 0.5f) delta / (2f - maxChannel - minChannel)
        else delta / (maxChannel + minChannel)
    val hue =
        when (maxChannel) {
            red -> 60f * (((green - blue) / delta) % 6f)
            green -> 60f * (((blue - red) / delta) + 2f)
            else -> 60f * (((red - green) / delta) + 4f)
        }
    return Hsl(normalizeHue(hue), saturation.coerceIn(0f, 1f), lightness)
}

private fun fromHsl(hue: Float, saturation: Float, lightness: Float, alpha: Float = 1f): Color {
    val chroma = (1f - abs(2f * lightness - 1f)) * saturation
    val section = normalizeHue(hue) / 60f
    val secondary = chroma * (1f - abs(section % 2f - 1f))
    val (r, g, b) =
        when {
            section < 1f -> Triple(chroma, secondary, 0f)
            section < 2f -> Triple(secondary, chroma, 0f)
            section < 3f -> Triple(0f, chroma, secondary)
            section < 4f -> Triple(0f, secondary, chroma)
            section < 5f -> Triple(secondary, 0f, chroma)
            else -> Triple(chroma, 0f, secondary)
        }
    val match = lightness - chroma / 2f
    return Color(
        red = (r + match).coerceIn(0f, 1f),
        green = (g + match).coerceIn(0f, 1f),
        blue = (b + match).coerceIn(0f, 1f),
        alpha = alpha,
    )
}

private fun harmonizeHue(baseHue: Float, anchorHue: Float, amount: Float): Float {
    val delta = ((baseHue - anchorHue + 540f) % 360f) - 180f
    return normalizeHue(baseHue - delta * amount.coerceIn(0f, 1f))
}

private fun normalizeHue(hue: Float): Float = ((hue % 360f) + 360f) % 360f

fun accentSwatchColor(family: AccentFamily, dark: Boolean): Color =
    when (family) {
        AccentFamily.BLUE -> if (dark) Color(0xFFA3C9FF) else Color(0xFF1762AC)
        AccentFamily.VIOLET -> if (dark) Color(0xFFD2BCFF) else Color(0xFF6B5290)
        AccentFamily.MINT -> if (dark) Color(0xFF70DAC1) else Color(0xFF006B58)
        AccentFamily.SYSTEM -> if (dark) DarkScheme.primary else LightScheme.primary
    }

val DarkPalette = paletteFor(DarkScheme, true, AccentFamily.VIOLET)
val LightPalette = paletteFor(LightScheme, false, AccentFamily.VIOLET)
val LocalWfPalette = staticCompositionLocalOf { DarkPalette }
val WfColors: WfPalette
    @Composable @ReadOnlyComposable get() = LocalWfPalette.current
val DeepCanvas: Color
    @Composable @ReadOnlyComposable get() = WfColors.deepCanvas
val SurfaceDark: Color
    @Composable @ReadOnlyComposable get() = WfColors.surfaceDark
val CardSurface: Color
    @Composable @ReadOnlyComposable get() = WfColors.cardSurface
val CardSurfaceElevated: Color
    @Composable @ReadOnlyComposable get() = WfColors.cardSurfaceElevated
val CardBorder: Color
    @Composable @ReadOnlyComposable get() = WfColors.cardBorder
val CardBorderGlow: Color
    @Composable @ReadOnlyComposable get() = WfColors.cardBorderGlow
val SurfaceContainerLow: Color
    @Composable @ReadOnlyComposable get() = WfColors.surfaceContainerLow
val SurfaceContainer: Color
    @Composable @ReadOnlyComposable get() = WfColors.surfaceContainer
val SurfaceContainerHigh: Color
    @Composable @ReadOnlyComposable get() = WfColors.surfaceContainerHigh
val PrimaryContainer: Color
    @Composable @ReadOnlyComposable get() = WfColors.primaryContainer
val OnPrimaryContainer: Color
    @Composable @ReadOnlyComposable get() = WfColors.onPrimaryContainer
val ElectricBlue: Color
    @Composable @ReadOnlyComposable get() = WfColors.electricBlue
val ElectricBlueGlow: Color
    @Composable @ReadOnlyComposable get() = WfColors.electricBlueGlow
val HealthSteps: Color
    @Composable @ReadOnlyComposable get() = WfColors.healthSteps
val HealthHeart: Color
    @Composable @ReadOnlyComposable get() = WfColors.healthHeart
val HealthStress: Color
    @Composable @ReadOnlyComposable get() = WfColors.healthStress
val HealthSleep: Color
    @Composable @ReadOnlyComposable get() = WfColors.healthSleep
val HealthOxygen: Color
    @Composable @ReadOnlyComposable get() = WfColors.healthOxygen
val HealthTemperature: Color
    @Composable @ReadOnlyComposable get() = WfColors.healthTemperature
val HealthRespiratory: Color
    @Composable @ReadOnlyComposable get() = WfColors.healthRespiratory
val HealthHrv: Color
    @Composable @ReadOnlyComposable get() = WfColors.healthHrv
val HealthBloodPressure: Color
    @Composable @ReadOnlyComposable get() = WfColors.healthBloodPressure
val HealthBloodPressureSecondary: Color
    @Composable @ReadOnlyComposable get() = WfColors.healthBloodPressureSecondary
val SleepDeep: Color
    @Composable @ReadOnlyComposable get() = WfColors.sleepDeep
val SleepLight: Color
    @Composable @ReadOnlyComposable get() = WfColors.sleepLight
val SleepRem: Color
    @Composable @ReadOnlyComposable get() = WfColors.sleepRem
val SleepAwake: Color
    @Composable @ReadOnlyComposable get() = WfColors.sleepAwake
val EmeraldCharging: Color
    @Composable @ReadOnlyComposable get() = WfColors.emeraldCharging
val EmeraldGlow: Color
    @Composable @ReadOnlyComposable get() = WfColors.emeraldGlow
val WarningAmber: Color
    @Composable @ReadOnlyComposable get() = WfColors.warningAmber
val AlertCrimson: Color
    @Composable @ReadOnlyComposable get() = WfColors.alertCrimson
val OffMuted: Color
    @Composable @ReadOnlyComposable get() = WfColors.offMuted
val TextPrimary: Color
    @Composable @ReadOnlyComposable get() = WfColors.textPrimary
val TextSecondary: Color
    @Composable @ReadOnlyComposable get() = WfColors.textSecondary
val TextTertiary: Color
    @Composable @ReadOnlyComposable get() = WfColors.textTertiary
val TextDisabled: Color
    @Composable @ReadOnlyComposable get() = WfColors.textDisabled
val TerminalBg: Color
    @Composable @ReadOnlyComposable get() = WfColors.terminalBg

/** Tints a card with the current theme's coordinated functional hue. */
@Composable
fun tonalSurface(accent: Color, strength: Float = 0.10f): Color =
    androidx.compose.ui.graphics.lerp(WfColors.cardSurface, accent, strength)
