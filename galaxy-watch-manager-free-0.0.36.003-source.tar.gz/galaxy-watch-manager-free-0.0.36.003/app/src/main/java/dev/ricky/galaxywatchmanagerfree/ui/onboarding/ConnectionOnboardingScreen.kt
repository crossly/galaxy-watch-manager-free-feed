package dev.ricky.galaxywatchmanagerfree.ui.onboarding

import android.Manifest
import android.app.Activity
import android.content.ContextWrapper
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.listSaver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.app.ActivityCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.core.ConnectionProgress
import dev.ricky.galaxywatchmanagerfree.core.OnboardingController
import dev.ricky.galaxywatchmanagerfree.core.UiNotify
import dev.ricky.galaxywatchmanagerfree.core.WatchController
import dev.ricky.galaxywatchmanagerfree.feature.DeviceIdentityStore
import dev.ricky.galaxywatchmanagerfree.feature.OnboardingStatus
import dev.ricky.galaxywatchmanagerfree.feature.onboarding.CompanionApps
import dev.ricky.galaxywatchmanagerfree.feature.onboarding.CompanionEnvironment
import dev.ricky.galaxywatchmanagerfree.feature.onboarding.detectCompanionEnvironment
import dev.ricky.galaxywatchmanagerfree.ui.components.CompanionHandoverCard
import dev.ricky.galaxywatchmanagerfree.ui.components.GroupedCard
import dev.ricky.galaxywatchmanagerfree.ui.screens.connection.AndroidBondedWatchSource
import dev.ricky.galaxywatchmanagerfree.ui.screens.connection.BondedWatchResult
import dev.ricky.galaxywatchmanagerfree.ui.screens.connection.BondedWatchSource
import dev.ricky.galaxywatchmanagerfree.ui.screens.connection.ConnectionPageUiState
import dev.ricky.galaxywatchmanagerfree.ui.screens.connection.WatchPickerSheet
import dev.ricky.galaxywatchmanagerfree.ui.theme.DeepCanvas
import dev.ricky.galaxywatchmanagerfree.ui.theme.ElectricBlue
import dev.ricky.galaxywatchmanagerfree.ui.theme.EmeraldCharging
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextPrimary
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextSecondary
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextTertiary
import dev.ricky.galaxywatchmanagerfree.ui.theme.WarningAmber
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext

/** 引导页面的可保存本地状态：步骤与依附于步骤流的副状态合并为单一来源。 */
private data class OnboardingUiState(
    val step: OnboardingStep = OnboardingStep.CHECK,
    val routedMac: String? = null,
    val releaseReviewedMac: String? = null,
    val acquiringForRelease: Boolean = false,
    val forceIdentityRead: Boolean = false,
    val choosingWatch: Boolean = false,
    val permissionDenied: Boolean = false,
)

private val OnboardingUiStateSaver =
    listSaver<OnboardingUiState, String>(
        save = {
            listOf(
                it.step.name,
                it.routedMac.orEmpty(),
                it.releaseReviewedMac.orEmpty(),
                it.acquiringForRelease.toString(),
                it.forceIdentityRead.toString(),
                it.choosingWatch.toString(),
                it.permissionDenied.toString(),
            )
        },
        restore = { parts ->
            OnboardingUiState(
                step = OnboardingStep.valueOf(parts[0]),
                routedMac = parts[1].takeIf { it.isNotEmpty() },
                releaseReviewedMac = parts[2].takeIf { it.isNotEmpty() },
                acquiringForRelease = parts[3].toBoolean(),
                forceIdentityRead = parts[4].toBoolean(),
                choosingWatch = parts[5].toBoolean(),
                permissionDenied = parts[6].toBoolean(),
            )
        },
    )

@Composable
fun ConnectionOnboardingScreen(onClose: () -> Unit) {
    val context = LocalContext.current
    val appContext = context.applicationContext
    val source = remember(appContext) { AndroidBondedWatchSource(appContext) }
    ConnectionOnboardingScreen(
        onClose = onClose,
        watchSource = source,
        readEnvironment = { detectCompanionEnvironment(appContext) },
        onFinish = {
            OnboardingController.finish(context)
            WatchController.autoConnect(context, force = true)
            onClose()
        },
    )
}

@Composable
internal fun ConnectionOnboardingScreen(
    onClose: () -> Unit,
    watchSource: BondedWatchSource,
    readEnvironment: () -> CompanionEnvironment,
    connectionProgress: StateFlow<ConnectionProgress> = WatchController.connectionProgress,
    onFinish: () -> Unit = onClose,
) {
    val context = LocalContext.current
    val appContext = context.applicationContext
    var refreshToken by remember { mutableIntStateOf(0) }
    var identityToken by remember { mutableIntStateOf(0) }
    var environment by remember { mutableStateOf<CompanionEnvironment?>(null) }
    var bonded by remember { mutableStateOf(BondedWatchResult(emptyList())) }
    var loading by remember { mutableStateOf(true) }
    var selectedMac by rememberSaveable { mutableStateOf(WatchController.savedMac.orEmpty()) }
    var ui by
        rememberSaveable(stateSaver = OnboardingUiStateSaver) {
            mutableStateOf(OnboardingUiState())
        }
    val step = ui.step
    val progress by connectionProgress.collectAsState()
    val status =
        if (progress.mac.equals(selectedMac, true)) progress.status else OnboardingStatus.IDLE
    val activity =
        remember(context) {
            generateSequence(context) { (it as? ContextWrapper)?.baseContext }
                .filterIsInstance<Activity>()
                .firstOrNull()
        }
    val permissionLauncher =
        rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            ui =
                ui.copy(
                    permissionDenied =
                        !granted &&
                            activity?.let {
                                !ActivityCompat.shouldShowRequestPermissionRationale(
                                    it,
                                    Manifest.permission.BLUETOOTH_CONNECT,
                                )
                            } == true
                )
            refreshToken++
        }

    LaunchedEffect(watchSource, refreshToken) {
        loading = true
        val detected = withContext(Dispatchers.IO) { readEnvironment() }
        val result = watchSource.load()
        environment = detected
        bonded = result
        // An unreadable adapter says nothing about whether the saved device is still bonded.
        if (result.issueRes == null) {
            val resolved = resolveSelectedMac(result.watches, selectedMac)
            if (!resolved.equals(selectedMac, true)) {
                if (WatchController.isRunning) WatchController.stopConnection(context)
                selectedMac = resolved
                ui = ui.copy(acquiringForRelease = false, forceIdentityRead = false)
            }
            if (!WatchController.savedMac.orEmpty().equals(resolved, true)) {
                WatchController.savedMac = resolved.takeIf { it.isNotBlank() }
            }
        }
        identityToken++
        loading = false
    }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                refreshToken++
                identityToken++
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    val store =
        remember(selectedMac, appContext) {
            selectedMac.takeIf { it.isNotBlank() }?.let { DeviceIdentityStore(appContext, it) }
        }
    val pendingNode =
        remember(store, progress, identityToken) { store?.pendingHandoverNode.orEmpty() }
    val confirmedNode =
        remember(store, progress, identityToken) { store?.confirmedPhoneNode.orEmpty() }
    val handoverPreparing =
        remember(store, progress, identityToken) { store?.handoverPreparing == true }
    val releasedToOfficialApps =
        remember(store, progress, identityToken) { store?.releasedToOfficialApps == true }
    val hasIdentity = pendingNode.isNotBlank() || confirmedNode.isNotBlank()
    val selectedWatch = bonded.watches.firstOrNull { it.mac.equals(selectedMac, true) }
    val hasPairedWatch = selectedWatch != null && bonded.issueRes == null && !loading
    val selectedName = selectedWatch?.name.orEmpty()
    val currentEnvironment = environment ?: CompanionEnvironment(null, false, false)
    val checkAction =
        resolveCheckAction(
            permissionMissing = bonded.issueRes == R.string.conn_permission_needed,
            bluetoothUnavailable =
                bonded.issueRes == R.string.conn_bluetooth_off ||
                    bonded.issueRes == R.string.conn_bluetooth_unavailable,
            hasGoogleWear = currentEnvironment.hasGoogleWear,
            wearEnabled = currentEnvironment.wearEnabled,
            hasBondedDevices = bonded.watches.isNotEmpty(),
            hasSelectedWatch = hasPairedWatch,
        )
    val needsRelease =
        (handoverPreparing || releasedToOfficialApps || pendingNode.isNotBlank()) &&
            ui.releaseReviewedMac != selectedMac

    fun go(next: OnboardingStep) {
        ui = ui.copy(step = next)
    }

    fun refreshEnvironment() {
        refreshToken++
        identityToken++
    }

    fun openBluetooth() {
        if (
            runCatching {
                    context.startActivity(
                        Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
                .isFailure
        )
            UiNotify.show(R.string.handover_open_settings_failed)
    }

    fun acquireIdentity() {
        if (!hasPairedWatch) {
            go(OnboardingStep.CHECK)
            return
        }
        // prepareHandover seeds the durable pause from any known identity, so a forced read
        // below still only stages a pending node and never enters RFCOMM.
        val hadKnownIdentity =
            pendingNode.isNotBlank() ||
                confirmedNode.isNotBlank() ||
                store?.candidatePhoneNode.orEmpty().isNotBlank()
        val forceRead = ui.forceIdentityRead
        WatchController.savedMac = selectedMac
        ui = ui.copy(releaseReviewedMac = null, acquiringForRelease = true)
        if (!WatchController.prepareHandover(context)) {
            ui = ui.copy(acquiringForRelease = false)
            UiNotify.show(R.string.handover_prepare_failed)
            return
        }
        // An explicit re-read must not reuse the seeded value; a first read already started one.
        if (forceRead && hadKnownIdentity) WatchController.acquireIdentity(selectedMac)
        identityToken++
    }

    LaunchedEffect(loading, selectedMac, status, identityToken, step) {
        if (loading) return@LaunchedEffect
        if (bonded.issueRes != null || !hasPairedWatch) {
            ui = ui.copy(routedMac = null)
            if (step != OnboardingStep.CHECK && step != OnboardingStep.INSTALL) {
                go(OnboardingStep.CHECK)
            }
            return@LaunchedEffect
        }
        if (ui.routedMac != selectedMac) {
            ui = ui.copy(routedMac = selectedMac)
            go(
                if (
                    status == OnboardingStatus.CONNECTING ||
                        status == OnboardingStatus.VERIFYING_IDENTITY
                ) {
                    OnboardingStep.CONNECT
                } else {
                    initialOnboardingStep(
                        ready = status == OnboardingStatus.READY,
                        handoverPreparing = handoverPreparing,
                        hasPendingIdentity = pendingNode.isNotBlank(),
                        hasConfirmedIdentity = confirmedNode.isNotBlank(),
                    )
                }
            )
            return@LaunchedEffect
        }
        when {
            status == OnboardingStatus.READY -> go(OnboardingStep.DONE)
            // A seeded pending node must not end the read early: only a finished read that is
            // sitting in the durable pause means the new identity is ready for release.
            ui.acquiringForRelease &&
                pendingNode.isNotBlank() &&
                status == OnboardingStatus.PREPARING_HANDOVER &&
                step == OnboardingStep.IDENTITY -> {
                ui = ui.copy(acquiringForRelease = false, forceIdentityRead = false)
                go(OnboardingStep.RELEASE)
            }
            step == OnboardingStep.RELEASE &&
                (status == OnboardingStatus.CONNECTING ||
                    status == OnboardingStatus.VERIFYING_IDENTITY) -> go(OnboardingStep.CONNECT)
        }
    }

    BackHandler(enabled = true) {
        if (ui.choosingWatch) ui = ui.copy(choosingWatch = false)
        else if (step != OnboardingStep.CHECK && step != OnboardingStep.DONE)
            go(OnboardingStep.CHECK)
        else {
            OnboardingController.close()
            onClose()
        }
    }

    Column(Modifier.fillMaxSize().background(DeepCanvas).statusBarsPadding()) {
        OnboardingHeader(
            step = step,
            canGoBack = step != OnboardingStep.CHECK && step != OnboardingStep.DONE,
            onBack = { go(OnboardingStep.CHECK) },
            onSkip = onFinish,
        )
        LinearProgressIndicator(
            progress = { (stepIndex(step) + 1) / 5f },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
        )
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item {
                if (step != OnboardingStep.DONE) {
                    OutlinedButton(
                        onClick = { ui = ui.copy(choosingWatch = true) },
                        enabled =
                            !loading && bonded.issueRes == null && bonded.watches.isNotEmpty(),
                        modifier = Modifier.fillMaxWidth().testTag("tag_onboarding_choose_watch"),
                    ) {
                        Text(
                            context.getString(
                                if (selectedName.isBlank()) R.string.connection_choose_watch
                                else R.string.connection_change_current_watch
                            )
                        )
                    }
                    Spacer(Modifier.height(16.dp))
                }
                when (step) {
                    OnboardingStep.CHECK ->
                        CheckStep(currentEnvironment, bonded, loading, selectedName)
                    OnboardingStep.INSTALL ->
                        InstallStep(
                            environment = currentEnvironment,
                            onOpenManager = {
                                if (
                                    !CompanionApps.openPackage(
                                        context,
                                        CompanionApps.WATCH_MANAGER,
                                    ) &&
                                        !CompanionApps.openStore(
                                            context,
                                            CompanionApps.WATCH_MANAGER,
                                        )
                                ) {
                                    UiNotify.show(R.string.handover_open_settings_failed)
                                }
                            },
                            onOpenWear = {
                                val wear = currentEnvironment.wearPackage ?: CompanionApps.WEAR_INTL
                                if (
                                    !CompanionApps.openPackage(context, wear) &&
                                        !CompanionApps.openStore(context, wear)
                                ) {
                                    UiNotify.show(R.string.handover_open_settings_failed)
                                }
                            },
                            onOpenManagerDetails = {
                                if (
                                    !CompanionApps.openAppDetails(
                                        context,
                                        CompanionApps.WATCH_MANAGER,
                                    )
                                ) {
                                    UiNotify.show(R.string.handover_open_settings_failed)
                                }
                            },
                            onOpenBluetooth = ::openBluetooth,
                        )
                    OnboardingStep.IDENTITY ->
                        IdentityStep(
                            status,
                            confirmedNode,
                            pendingNode,
                            hasPairedWatch,
                            selectedName,
                        )
                    OnboardingStep.RELEASE ->
                        ReleaseStep(selectedMac, selectedName) {
                            identityToken++
                            if (store?.releasedToOfficialApps == true)
                                ui = ui.copy(releaseReviewedMac = null)
                            refreshToken++
                        }
                    OnboardingStep.CONNECT ->
                        ConnectStep(status, handoverPreparing, releasedToOfficialApps, hasIdentity)
                    OnboardingStep.DONE -> DoneStep(selectedName)
                }
            }
        }
        OnboardingActions(
            step = step,
            checkAction = checkAction,
            loading = loading,
            permissionDenied = ui.permissionDenied,
            environment = currentEnvironment,
            hasIdentity = hasIdentity,
            hasPairedWatch = hasPairedWatch,
            needsRelease = needsRelease,
            status = status,
            onCheckContinue = {
                if (checkAction == OnboardingCheckAction.CONTINUE) go(OnboardingStep.IDENTITY)
                else go(OnboardingStep.INSTALL)
            },
            onRefresh = {
                refreshEnvironment()
                go(OnboardingStep.CHECK)
            },
            onGrantPermission = {
                if (ui.permissionDenied) {
                    if (!CompanionApps.openAppDetails(context, context.packageName)) {
                        UiNotify.show(R.string.handover_open_settings_failed)
                    }
                } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    permissionLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT)
                }
            },
            onSelectWatch = { ui = ui.copy(choosingWatch = true) },
            onOpenBluetooth = ::openBluetooth,
            onOpenWearDetails = {
                if (
                    currentEnvironment.wearPackage?.let {
                        CompanionApps.openAppDetails(context, it)
                    } != true
                ) {
                    UiNotify.show(R.string.handover_open_settings_failed)
                }
            },
            onAcquire = ::acquireIdentity,
            onNextToConnect = {
                ui = ui.copy(releaseReviewedMac = selectedMac)
                go(OnboardingStep.CONNECT)
            },
            onBackToRelease = { go(OnboardingStep.RELEASE) },
            onReacquire = {
                // A remembered value may be the wrong one; ask the next acquisition to re-read it.
                ui = ui.copy(forceIdentityRead = true)
                go(OnboardingStep.IDENTITY)
            },
            onConnect = {
                if (needsRelease) go(OnboardingStep.RELEASE)
                else if (!hasIdentity) go(OnboardingStep.IDENTITY)
                else if (hasPairedWatch) {
                    WatchController.savedMac = selectedMac
                    val started =
                        if (
                            handoverPreparing || pendingNode.isNotBlank() || releasedToOfficialApps
                        ) {
                            WatchController.continueHandover(context)
                        } else WatchController.startService(context, selectedMac)
                    identityToken++
                    if (!started) UiNotify.show(R.string.handover_continue_failed)
                } else go(OnboardingStep.CHECK)
            },
            onFinish = onFinish,
        )
    }
    if (ui.choosingWatch) {
        WatchPickerSheet(
            ui =
                ConnectionPageUiState(
                    watches = bonded.watches,
                    issueRes = bonded.issueRes,
                    loading = loading,
                    selectedMac = selectedMac,
                ),
            connectedMac = progress.mac.takeIf { status == OnboardingStatus.READY }.orEmpty(),
            onRefresh = ::refreshEnvironment,
            onSelect = { mac ->
                if (!mac.equals(selectedMac, true)) {
                    if (WatchController.isRunning) WatchController.stopConnection(context)
                    selectedMac = mac
                    WatchController.savedMac = mac
                    ui =
                        ui.copy(
                            releaseReviewedMac = null,
                            acquiringForRelease = false,
                            forceIdentityRead = false,
                        )
                    identityToken++
                }
                ui = ui.copy(choosingWatch = false)
            },
            onOpenBluetooth = ::openBluetooth,
            onDismiss = { ui = ui.copy(choosingWatch = false) },
        )
    }
}

@Composable
private fun OnboardingHeader(
    step: OnboardingStep,
    canGoBack: Boolean,
    onBack: () -> Unit,
    onSkip: () -> Unit,
) {
    val strings = LocalContext.current.resources
    Row(
        modifier = Modifier.fillMaxWidth().padding(start = 8.dp, end = 8.dp, top = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (canGoBack) {
            IconButton(onClick = onBack, modifier = Modifier.testTag("tag_onboarding_back")) {
                Icon(
                    Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = strings.getString(R.string.back),
                    tint = TextSecondary,
                )
            }
        } else {
            Spacer(Modifier.width(48.dp))
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                strings.getString(R.string.onboarding_flow_title),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
            )
            Text(
                strings.getString(R.string.onboarding_flow_subtitle),
                style = MaterialTheme.typography.labelSmall,
                color = TextTertiary,
            )
            Text(
                strings.getString(R.string.onboarding_step_progress, stepIndex(step) + 1, 5),
                style = MaterialTheme.typography.labelSmall,
                color = ElectricBlue,
            )
        }
        TextButton(onClick = onSkip, modifier = Modifier.testTag("tag_onboarding_skip")) {
            Text(strings.getString(R.string.onboarding_skip))
        }
    }
}

@Composable
private fun CheckStep(
    environment: CompanionEnvironment,
    bonded: BondedWatchResult,
    loading: Boolean,
    watchName: String,
) {
    val strings = LocalContext.current.resources
    GroupedCard {
        Text(
            strings.getString(R.string.onboarding_step_check),
            style = MaterialTheme.typography.titleSmall,
            color = TextPrimary,
        )
        Spacer(Modifier.height(8.dp))
        if (loading) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(8.dp))
                Text(
                    strings.getString(R.string.onboarding_check_loading),
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    modifier = Modifier.testTag("tag_onboarding_check_loading"),
                )
            }
            return@GroupedCard
        }
        InfoRow(
            ok = environment.hasGoogleWear && environment.wearEnabled,
            text =
                when {
                    !environment.hasGoogleWear ->
                        strings.getString(R.string.onboarding_check_wear_missing)
                    !environment.wearEnabled -> strings.getString(R.string.onboarding_wear_disabled)
                    else ->
                        strings.getString(
                            R.string.onboarding_check_wear_installed,
                            environment.wearPackage.orEmpty(),
                        )
                },
        )
        InfoRow(
            ok = environment.managerInstalled,
            text =
                strings.getString(
                    R.string.onboarding_check_manager,
                    strings.getString(
                        if (environment.managerInstalled) R.string.onboarding_installed
                        else R.string.onboarding_not_installed
                    ),
                ),
        )
        if (bonded.issueRes != null) {
            Text(
                strings.getString(bonded.issueRes),
                style = MaterialTheme.typography.bodySmall,
                color = WarningAmber,
                modifier = Modifier.testTag("tag_onboarding_platform_issue"),
            )
        } else {
            InfoRow(
                ok = watchName.isNotBlank(),
                text =
                    when {
                        bonded.watches.isEmpty() ->
                            strings.getString(R.string.no_paired_devices_found)
                        watchName.isBlank() ->
                            strings.getString(R.string.onboarding_check_no_selection)
                        else -> strings.getString(R.string.onboarding_check_paired, watchName)
                    },
            )
        }
        Spacer(Modifier.height(10.dp))
        Text(
            strings.getString(
                if (environment.hasGoogleWear) R.string.onboarding_reuse_explained
                else R.string.onboarding_install_needed
            ),
            style = MaterialTheme.typography.bodySmall,
            color = if (environment.hasGoogleWear) TextSecondary else WarningAmber,
        )
    }
}

@Composable
private fun InstallStep(
    environment: CompanionEnvironment,
    onOpenManager: () -> Unit,
    onOpenWear: () -> Unit,
    onOpenManagerDetails: () -> Unit,
    onOpenBluetooth: () -> Unit,
) {
    val strings = LocalContext.current.resources
    GroupedCard {
        Text(
            strings.getString(R.string.onboarding_install_title),
            style = MaterialTheme.typography.titleSmall,
            color = TextPrimary,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            strings.getString(R.string.onboarding_install_body),
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary,
        )
        Spacer(Modifier.height(12.dp))
        OutlinedButton(
            onClick = onOpenManager,
            modifier = Modifier.fillMaxWidth().testTag("tag_onboarding_open_manager"),
        ) {
            Text(
                strings.getString(
                    if (environment.managerInstalled) R.string.onboarding_open_manager
                    else R.string.onboarding_install_manager
                )
            )
        }
        OutlinedButton(
            onClick = onOpenWear,
            modifier = Modifier.fillMaxWidth().testTag("tag_onboarding_open_wear"),
        ) {
            Text(
                strings.getString(
                    if (environment.hasGoogleWear) R.string.onboarding_open_wear
                    else R.string.onboarding_install_wear
                )
            )
        }
        if (environment.managerInstalled) {
            TextButton(onClick = onOpenManagerDetails) {
                Text(strings.getString(R.string.handover_app_details))
            }
        }
        TextButton(
            onClick = onOpenBluetooth,
            modifier = Modifier.fillMaxWidth().testTag("tag_onboarding_open_bluetooth"),
        ) {
            Text(strings.getString(R.string.conn_open_bluetooth_settings))
        }
    }
}

@Composable
private fun IdentityStep(
    status: OnboardingStatus,
    confirmedNode: String,
    pendingNode: String,
    hasPairedWatch: Boolean,
    selectedName: String,
) {
    val strings = LocalContext.current.resources
    GroupedCard {
        Text(
            strings.getString(R.string.onboarding_identity_title),
            style = MaterialTheme.typography.titleSmall,
            color = TextPrimary,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            strings.getString(R.string.onboarding_identity_body),
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary,
        )
        Spacer(Modifier.height(10.dp))
        if (!hasPairedWatch) {
            InfoRow(ok = false, text = strings.getString(R.string.connection_desc_select_watch))
        } else {
            InfoRow(ok = true, text = selectedName)
            // A stored identity never hides the state of a new read: the user asked for a fresh
            // value, and its success, failure or progress must stay visible next to the old one.
            if (confirmedNode.isNotBlank()) {
                InfoRow(ok = true, text = strings.getString(R.string.identity_acquired_success))
            }
            if (pendingNode.isNotBlank()) {
                CandidateIdentityRow(pendingNode)
            }
            when (status) {
                OnboardingStatus.ACQUIRING_IDENTITY ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            strokeWidth = 2.dp,
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            strings.getString(R.string.connection_status_acquiring_identity),
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary,
                        )
                    }
                OnboardingStatus.IDENTITY_MISSING ->
                    InfoRow(
                        ok = false,
                        text = strings.getString(R.string.onboarding_identity_missing),
                    )
                OnboardingStatus.ERROR ->
                    InfoRow(ok = false, text = strings.getString(R.string.conn_verification_failed))
                else -> Unit
            }
        }
    }
}

@Composable
private fun CandidateIdentityRow(node: String) {
    val strings = LocalContext.current.resources
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Icon(
            imageVector = Icons.Default.Info,
            contentDescription = null,
            tint = TextSecondary,
            modifier = Modifier.size(16.dp),
        )
        Spacer(Modifier.width(8.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                strings.getString(R.string.connection_identity_pending),
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
            )
            SelectionContainer {
                Text(
                    node,
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = FontFamily.Monospace,
                    color = TextTertiary,
                )
            }
        }
    }
}

@Composable
private fun ReleaseStep(
    selectedMac: String,
    selectedName: String,
    onConnectionOwnershipChanged: () -> Unit,
) {
    val strings = LocalContext.current.resources
    GroupedCard {
        Text(
            strings.getString(R.string.onboarding_release_title),
            style = MaterialTheme.typography.titleSmall,
            color = TextPrimary,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            strings.getString(R.string.onboarding_release_body),
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary,
        )
    }
    if (selectedMac.isNotBlank()) {
        Spacer(Modifier.height(16.dp))
        CompanionHandoverCard(
            selectedMac = selectedMac,
            selectedDeviceName = selectedName,
            onConnectionOwnershipChanged = onConnectionOwnershipChanged,
        )
    }
}

@Composable
private fun ConnectStep(
    status: OnboardingStatus,
    handoverPreparing: Boolean,
    releasedToOfficialApps: Boolean,
    hasIdentity: Boolean,
) {
    val strings = LocalContext.current.resources
    val busy =
        status == OnboardingStatus.ACQUIRING_IDENTITY ||
            status == OnboardingStatus.CONNECTING ||
            status == OnboardingStatus.VERIFYING_IDENTITY
    val waiting = !busy && (handoverPreparing || status == OnboardingStatus.PREPARING_HANDOVER)
    val description =
        when {
            status == OnboardingStatus.IDENTITY_MISSING || !hasIdentity ->
                R.string.onboarding_identity_missing
            status == OnboardingStatus.ERROR -> R.string.connection_desc_failed
            status == OnboardingStatus.ACQUIRING_IDENTITY -> R.string.connection_desc_acquiring
            busy -> R.string.connection_desc_connecting
            waiting -> R.string.onboarding_connect_pending_handover
            releasedToOfficialApps -> R.string.connection_desc_official_apps
            status == OnboardingStatus.IDLE -> R.string.onboarding_connect_body
            else -> R.string.connection_desc_connected
        }
    GroupedCard {
        Text(
            strings.getString(R.string.onboarding_connect_title),
            style = MaterialTheme.typography.titleSmall,
            color = TextPrimary,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            strings.getString(description),
            style = MaterialTheme.typography.bodySmall,
            color =
                if (status == OnboardingStatus.ERROR || status == OnboardingStatus.IDENTITY_MISSING)
                    WarningAmber
                else TextSecondary,
            modifier = Modifier.testTag("tag_onboarding_connect_status"),
        )
        if (waiting) {
            Text(
                strings.getString(R.string.connection_status_preparing),
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
                modifier = Modifier.testTag("tag_onboarding_waiting_handover"),
            )
        }
        if (busy) {
            Spacer(Modifier.height(10.dp))
            CircularProgressIndicator(
                modifier = Modifier.size(18.dp).testTag("tag_onboarding_connect_progress"),
                strokeWidth = 2.dp,
            )
        }
    }
}

@Composable
private fun DoneStep(selectedName: String) {
    val strings = LocalContext.current.resources
    GroupedCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.Default.CheckCircle,
                contentDescription = null,
                tint = EmeraldCharging,
                modifier = Modifier.size(28.dp),
            )
            Spacer(Modifier.width(10.dp))
            Column {
                Text(
                    strings.getString(R.string.onboarding_done_title),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                )
                if (selectedName.isNotBlank())
                    Text(
                        selectedName,
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary,
                    )
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(
            strings.getString(R.string.onboarding_done_body),
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary,
        )
    }
}

@Composable
private fun OnboardingActions(
    step: OnboardingStep,
    checkAction: OnboardingCheckAction,
    loading: Boolean,
    permissionDenied: Boolean,
    environment: CompanionEnvironment,
    hasIdentity: Boolean,
    hasPairedWatch: Boolean,
    needsRelease: Boolean,
    status: OnboardingStatus,
    onCheckContinue: () -> Unit,
    onRefresh: () -> Unit,
    onGrantPermission: () -> Unit,
    onSelectWatch: () -> Unit,
    onOpenBluetooth: () -> Unit,
    onOpenWearDetails: () -> Unit,
    onAcquire: () -> Unit,
    onNextToConnect: () -> Unit,
    onBackToRelease: () -> Unit,
    onReacquire: () -> Unit,
    onConnect: () -> Unit,
    onFinish: () -> Unit,
) {
    val strings = LocalContext.current.resources
    val busy =
        status == OnboardingStatus.ACQUIRING_IDENTITY ||
            status == OnboardingStatus.CONNECTING ||
            status == OnboardingStatus.VERIFYING_IDENTITY
    Column(
        Modifier.fillMaxWidth().navigationBarsPadding().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))
        Spacer(Modifier.height(4.dp))
        when (step) {
            OnboardingStep.CHECK -> {
                val label =
                    when (checkAction) {
                        OnboardingCheckAction.GRANT_PERMISSION ->
                            if (permissionDenied) R.string.conn_open_app_settings
                            else R.string.onboarding_action_grant_permission
                        OnboardingCheckAction.OPEN_BLUETOOTH ->
                            R.string.conn_open_bluetooth_settings
                        OnboardingCheckAction.OPEN_WEAR_DETAILS -> R.string.handover_app_details
                        OnboardingCheckAction.SHOW_PAIRING_GUIDE -> R.string.onboarding_view_steps
                        OnboardingCheckAction.SELECT_WATCH -> R.string.connection_choose_watch
                        OnboardingCheckAction.CONTINUE -> R.string.onboarding_continue
                    }
                Button(
                    onClick = {
                        when (checkAction) {
                            OnboardingCheckAction.GRANT_PERMISSION -> onGrantPermission()
                            OnboardingCheckAction.OPEN_BLUETOOTH -> onOpenBluetooth()
                            OnboardingCheckAction.OPEN_WEAR_DETAILS -> onOpenWearDetails()
                            OnboardingCheckAction.SELECT_WATCH -> onSelectWatch()
                            OnboardingCheckAction.SHOW_PAIRING_GUIDE,
                            OnboardingCheckAction.CONTINUE -> onCheckContinue()
                        }
                    },
                    enabled = !loading,
                    modifier = Modifier.fillMaxWidth().testTag("tag_onboarding_primary"),
                ) {
                    Text(strings.getString(label))
                }
                TextButton(
                    onClick = onRefresh,
                    enabled = !loading,
                    modifier = Modifier.fillMaxWidth().testTag("tag_onboarding_recheck"),
                ) {
                    Text(strings.getString(R.string.onboarding_recheck))
                }
            }
            OnboardingStep.INSTALL -> {
                Button(
                    onClick = onRefresh,
                    enabled = !loading,
                    modifier = Modifier.fillMaxWidth().testTag("tag_onboarding_primary"),
                ) {
                    Text(strings.getString(R.string.onboarding_recheck))
                }
                if (checkAction == OnboardingCheckAction.CONTINUE) {
                    TextButton(
                        onClick = onCheckContinue,
                        modifier = Modifier.fillMaxWidth().testTag("tag_onboarding_continue_flow"),
                    ) {
                        Text(strings.getString(R.string.onboarding_continue))
                    }
                }
            }
            OnboardingStep.IDENTITY -> {
                val action =
                    when {
                        !environment.hasGoogleWear -> onCheckContinue
                        !environment.wearEnabled -> onOpenWearDetails
                        hasPairedWatch -> onAcquire
                        else -> onOpenBluetooth
                    }
                val label =
                    when {
                        !environment.hasGoogleWear -> R.string.onboarding_view_steps
                        !environment.wearEnabled -> R.string.handover_app_details
                        hasPairedWatch -> R.string.action_acquire_identity
                        else -> R.string.conn_open_bluetooth_settings
                    }
                Button(
                    onClick = action,
                    enabled = !busy && !loading,
                    modifier = Modifier.fillMaxWidth().testTag("tag_onboarding_primary"),
                ) {
                    Text(strings.getString(label))
                }
                if (hasIdentity) {
                    TextButton(
                        onClick = onBackToRelease,
                        enabled = !busy && !loading,
                        modifier = Modifier.fillMaxWidth().testTag("tag_onboarding_continue_flow"),
                    ) {
                        Text(strings.getString(R.string.onboarding_release_title))
                    }
                }
            }
            OnboardingStep.RELEASE -> {
                Button(
                    onClick = if (hasIdentity) onNextToConnect else onReacquire,
                    enabled = !busy && !loading && hasPairedWatch,
                    modifier = Modifier.fillMaxWidth().testTag("tag_onboarding_primary"),
                ) {
                    Text(
                        strings.getString(
                            if (hasIdentity) R.string.onboarding_release_action
                            else R.string.action_acquire_identity
                        )
                    )
                }
            }
            OnboardingStep.CONNECT -> {
                Button(
                    onClick = onConnect,
                    enabled = !busy && !loading && hasPairedWatch,
                    modifier = Modifier.fillMaxWidth().testTag("tag_onboarding_primary"),
                ) {
                    Text(
                        strings.getString(
                            when {
                                !hasIdentity -> R.string.action_acquire_identity
                                needsRelease -> R.string.onboarding_release_title
                                status == OnboardingStatus.ERROR -> R.string.conn_retry
                                else -> R.string.connect_watch
                            }
                        )
                    )
                }
                TextButton(
                    onClick = onBackToRelease,
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth().testTag("tag_onboarding_back_to_release"),
                ) {
                    Text(strings.getString(R.string.onboarding_release_title))
                }
                TextButton(
                    onClick = onReacquire,
                    enabled = !busy && !loading,
                    modifier = Modifier.fillMaxWidth().testTag("tag_onboarding_reacquire"),
                ) {
                    Text(strings.getString(R.string.action_acquire_identity))
                }
            }
            OnboardingStep.DONE -> {
                Button(
                    onClick = onFinish,
                    modifier = Modifier.fillMaxWidth().testTag("tag_onboarding_finish"),
                ) {
                    Text(strings.getString(R.string.onboarding_done_action))
                }
            }
        }
    }
}

@Composable
private fun InfoRow(ok: Boolean, text: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            imageVector = if (ok) Icons.Default.CheckCircle else Icons.Default.Warning,
            contentDescription = null,
            tint = if (ok) EmeraldCharging else WarningAmber,
            modifier = Modifier.size(16.dp),
        )
        Spacer(Modifier.width(8.dp))
        Text(text, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
    }
}
