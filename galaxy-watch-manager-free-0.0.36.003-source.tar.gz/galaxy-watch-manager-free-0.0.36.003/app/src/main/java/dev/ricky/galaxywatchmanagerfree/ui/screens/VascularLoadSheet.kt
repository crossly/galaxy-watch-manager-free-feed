package dev.ricky.galaxywatchmanagerfree.ui.screens

import androidx.annotation.StringRes
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MonitorHeart
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.ProgressBarRangeInfo
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.progressBarRangeInfo
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.feature.VascularLoadLog
import dev.ricky.galaxywatchmanagerfree.ui.components.AppBottomSheet
import dev.ricky.galaxywatchmanagerfree.ui.components.GroupedCard
import dev.ricky.galaxywatchmanagerfree.ui.components.GroupedCardRow
import dev.ricky.galaxywatchmanagerfree.ui.components.GroupedDivider
import dev.ricky.galaxywatchmanagerfree.ui.components.SheetToolbar
import dev.ricky.galaxywatchmanagerfree.ui.components.chartProbe
import dev.ricky.galaxywatchmanagerfree.ui.components.drawReadingCurve
import dev.ricky.galaxywatchmanagerfree.ui.theme.CardBorder
import dev.ricky.galaxywatchmanagerfree.ui.theme.CardSurface
import dev.ricky.galaxywatchmanagerfree.ui.theme.HealthBloodPressure
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextPrimary
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextSecondary
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextTertiary
import dev.ricky.galaxywatchmanagerfree.ui.theme.tonalSurface
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.time.temporal.ChronoUnit
import kotlin.math.roundToInt

@StringRes
private fun vascularBandLabel(band: VascularLoadLog.Band): Int =
    when (band) {
        VascularLoadLog.Band.HIGHER -> R.string.vascular_load_higher
        VascularLoadLog.Band.SLIGHTLY_HIGHER -> R.string.vascular_load_slightly_higher
        VascularLoadLog.Band.STEADY -> R.string.vascular_load_steady
        VascularLoadLog.Band.SLIGHTLY_LOWER -> R.string.vascular_load_slightly_lower
        VascularLoadLog.Band.LOWER -> R.string.vascular_load_lower
        VascularLoadLog.Band.OUT_OF_RANGE_UNKNOWN -> R.string.vascular_load_unknown
        VascularLoadLog.Band.NOT_ENOUGH_DATA -> R.string.vascular_load_insufficient
    }

@StringRes
private fun vascularRecordLabel(entry: VascularLoadLog.Entry): Int =
    when (entry.type) {
        VascularLoadLog.Type.RESET -> R.string.vascular_load_baseline_reset
        VascularLoadLog.Type.BASELINE ->
            if (entry.measurement != null) R.string.vascular_load_baseline_complete
            else R.string.vascular_load_building_baseline
        VascularLoadLog.Type.MEASUREMENT -> vascularBandLabel(entry.band)
    }

@StringRes
private fun vascularStatus(data: VascularLoadLog.Snapshot): Int =
    when {
        !data.baselineComplete -> R.string.vascular_load_building_baseline
        data.latest == null -> R.string.vascular_load_baseline_complete
        else -> vascularBandLabel(data.latest.band)
    }

@Composable
fun VascularLoadCard(data: VascularLoadLog.Snapshot, wide: Boolean = false, onClick: () -> Unit) {
    HealthSummary(
        title = stringResource(R.string.vascular_load),
        value = stringResource(vascularStatus(data)),
        unit = stringResource(R.string.vascular_load_relative),
        icon = Icons.Default.MonitorHeart,
        accent = HealthBloodPressure,
        modifier = Modifier.fillMaxWidth(),
        wide = wide,
        wrapValue = true,
        indicator = {
            if (data.baselineComplete)
                VascularLoadScale(data.latest?.band, surface = tonalSurface(HealthBloodPressure))
            else VascularBaselineProgress(data.baselineNights)
        },
        onClick = onClick,
    )
}

@Composable
private fun VascularBaselineProgress(nights: Int) {
    val completed = nights.coerceIn(0, 3)
    val description = stringResource(R.string.vascular_load_baseline_progress, completed)
    Row(
        Modifier.fillMaxWidth().testTag("vascular_load_baseline_progress").semantics {
            contentDescription = description
            progressBarRangeInfo = ProgressBarRangeInfo(completed.toFloat(), 0f..3f, 2)
        },
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        repeat(3) { index ->
            Box(
                Modifier.weight(1f)
                    .height(6.dp)
                    .clip(CircleShape)
                    .background(
                        HealthBloodPressure.copy(alpha = if (index < completed) 1f else .14f)
                    )
            )
        }
    }
}

@Composable
private fun VascularLoadScale(
    band: VascularLoadLog.Band?,
    showLabels: Boolean = false,
    surface: Color = CardSurface,
) {
    val active =
        when (band) {
            VascularLoadLog.Band.LOWER -> 0
            VascularLoadLog.Band.SLIGHTLY_LOWER -> 1
            VascularLoadLog.Band.STEADY -> 2
            VascularLoadLog.Band.SLIGHTLY_HIGHER -> 3
            VascularLoadLog.Band.HIGHER -> 4
            else -> null
        }
    val accent = HealthBloodPressure
    Column {
        Canvas(Modifier.fillMaxWidth().height(20.dp).testTag("vascular_load_scale")) {
            val gap = 4.dp.toPx()
            val segment = (size.width - gap * 4) / 5
            repeat(5) { index ->
                drawRoundRect(
                    accent.copy(alpha = if (index == active) .65f else .16f),
                    topLeft = Offset(index * (segment + gap), size.height / 2 - 3.dp.toPx()),
                    size = Size(segment, 6.dp.toPx()),
                    cornerRadius = CornerRadius(3.dp.toPx()),
                )
            }
            active?.let { index ->
                val center = Offset(index * (segment + gap) + segment / 2, size.height / 2)
                drawCircle(surface, 7.dp.toPx(), center)
                drawCircle(accent, 4.dp.toPx(), center)
            }
        }
        if (showLabels) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                        R.string.vascular_load_lower,
                        R.string.vascular_load_steady,
                        R.string.vascular_load_higher,
                    )
                    .forEachIndexed { index, label ->
                        Text(
                            stringResource(label),
                            modifier = Modifier.weight(1f),
                            style = MaterialTheme.typography.labelSmall,
                            color = TextTertiary,
                            textAlign =
                                when (index) {
                                    0 -> TextAlign.Start
                                    1 -> TextAlign.Center
                                    else -> TextAlign.End
                                },
                        )
                    }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VascularLoadSheet(
    data: VascularLoadLog.Snapshot,
    onDismiss: () -> Unit,
    onRefresh: (() -> Unit)? = null,
    syncing: Boolean = false,
) {
    val batches =
        remember(data.records) { data.records.sortedByDescending { it.endMillis }.chunked(12) }
    AppBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
    ) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
            SheetToolbar(stringResource(R.string.vascular_load), onDismiss) {
                if (onRefresh != null) {
                    val label = stringResource(if (syncing) R.string.syncing else R.string.sync)
                    IconButton(onClick = onRefresh, enabled = !syncing) {
                        if (syncing)
                            CircularProgressIndicator(
                                modifier =
                                    Modifier.size(20.dp).semantics { contentDescription = label },
                                strokeWidth = 2.dp,
                            )
                        else Icon(Icons.Default.Refresh, label)
                    }
                }
            }
            LazyColumn(
                modifier = Modifier.fillMaxWidth().testTag("vascular_load_detail"),
                contentPadding = PaddingValues(top = 8.dp, bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                item { VascularLoadOverview(data) }
                item {
                    GroupedCard {
                        Text(
                            stringResource(R.string.past_7_days),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary,
                        )
                        Spacer(Modifier.height(12.dp))
                        VascularLoadChart(data.records)
                    }
                }
                item {
                    Column(Modifier.padding(horizontal = 4.dp)) {
                        Text(
                            stringResource(R.string.vascular_load_about),
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary,
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            stringResource(R.string.vascular_load_disclaimer),
                            style = MaterialTheme.typography.bodySmall,
                            color = TextTertiary,
                        )
                    }
                }
                item {
                    Text(
                        stringResource(R.string.history_2),
                        modifier = Modifier.padding(horizontal = 4.dp),
                        style = MaterialTheme.typography.titleSmall,
                        color = TextPrimary,
                    )
                }
                if (batches.isEmpty()) {
                    item {
                        GroupedCard {
                            Text(
                                stringResource(R.string.vascular_load_empty),
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary,
                            )
                        }
                    }
                }
                items(batches, key = { it.first().id }) { batch ->
                    GroupedCard(innerPadding = 0.dp) {
                        batch.forEachIndexed { index, entry ->
                            if (index > 0) GroupedDivider(startIndent = 16.dp)
                            GroupedCardRow(
                                title = stringResource(vascularRecordLabel(entry)),
                                subtitle = vascularRecordDate(entry),
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun VascularLoadOverview(data: VascularLoadLog.Snapshot) {
    val accent = HealthBloodPressure
    val surface = tonalSurface(accent)
    GroupedCard(backgroundColor = surface, accent = accent, innerPadding = 20.dp) {
        if (data.baselineComplete) {
            data.latest?.let { entry ->
                Text(
                    vascularRecordDate(entry),
                    style = MaterialTheme.typography.labelMedium,
                    color = TextSecondary,
                )
                Spacer(Modifier.height(8.dp))
            }
        }
        Text(
            stringResource(vascularStatus(data)),
            modifier = Modifier.testTag("vascular_load_status"),
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.SemiBold,
            color = TextPrimary,
        )
        Spacer(Modifier.height(4.dp))
        Text(
            stringResource(R.string.vascular_load_relative),
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary,
        )
        Spacer(Modifier.height(20.dp))
        if (data.baselineComplete) {
            VascularLoadScale(data.latest?.band, showLabels = true, surface = surface)
        } else {
            VascularBaselineProgress(data.baselineNights)
            Spacer(Modifier.height(12.dp))
            Text(
                stringResource(R.string.vascular_load_baseline_progress, data.baselineNights),
                style = MaterialTheme.typography.titleSmall,
                color = TextPrimary,
            )
            Spacer(Modifier.height(8.dp))
            Text(
                stringResource(R.string.vascular_load_baseline_help),
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
            )
        }
    }
}

@Composable
private fun vascularRecordDate(entry: VascularLoadLog.Entry): String {
    val locale = LocalConfiguration.current.locales[0]
    return entry.trackingDate.format(
        DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM).withLocale(locale)
    )
}

internal fun vascularChartDays(
    records: List<VascularLoadLog.Entry>,
    today: LocalDate,
): List<VascularLoadLog.Entry?> {
    val firstDay = today.minusDays(6)
    val latestByDay =
        records
            .filter { it.trackingDate in firstDay..today }
            .groupBy { it.trackingDate }
            .mapValues { (_, entries) ->
                entries.maxWith(
                    compareBy<VascularLoadLog.Entry> { it.endMillis }
                        .thenBy { if (it.type == VascularLoadLog.Type.RESET) 1 else 0 }
                )
            }
    return List(7) { latestByDay[firstDay.plusDays(it.toLong())] }
}

@Composable
private fun VascularLoadChart(
    records: List<VascularLoadLog.Entry>,
    today: LocalDate = LocalDate.now(),
) {
    val firstDay = today.minusDays(6)
    val days = remember(records, today) { vascularChartDays(records, today) }
    val points = days.filterNotNull().filter { it.chartValue != null }
    if (points.isEmpty()) {
        Text(
            stringResource(
                if (days.any { it != null }) R.string.vascular_load_chart_no_results
                else R.string.no_records_in_the_past_7_days
            ),
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary,
        )
        return
    }
    val positions = points.map { (ChronoUnit.DAYS.between(firstDay, it.trackingDate) + .5f) / 7f }
    val runs =
        remember(days, records) {
            val result = mutableListOf<MutableList<VascularLoadLog.Entry>>()
            val controls = records.filter { it.type != VascularLoadLog.Type.MEASUREMENT }
            var previous: VascularLoadLog.Entry? = null
            days.forEach { entry ->
                if (entry?.type != VascularLoadLog.Type.MEASUREMENT || entry.chartValue == null) {
                    previous = null
                } else {
                    val before = previous
                    val interrupted =
                        before == null ||
                            controls.any {
                                it.endMillis > before.endMillis && it.endMillis <= entry.endMillis
                            }
                    if (interrupted) result.add(mutableListOf(entry)) else result.last().add(entry)
                    previous = entry
                }
            }
            result
        }
    var selectedId by rememberSaveable { mutableStateOf<String?>(null) }
    val selectedIndex = points.indexOfFirst { it.id == selectedId }.takeIf { it >= 0 }
    val selected = selectedIndex?.let(points::get)
    val accent = HealthBloodPressure
    val grid = CardBorder.copy(alpha = .45f)
    val surface = CardSurface
    val description = stringResource(R.string.vascular_load_chart_description)
    val fontScale = LocalDensity.current.fontScale
    val plotHeight = 184.dp * maxOf(1f, fontScale / 1.3f)
    val locale = LocalConfiguration.current.locales[0]
    val dateFormat =
        DateTimeFormatter.ofPattern(
            android.text.format.DateFormat.getBestDateTimePattern(locale, "MMMd"),
            locale,
        )

    Column {
        Text(
            stringResource(
                R.string.vascular_load_chart_period,
                firstDay.format(dateFormat),
                today.format(dateFormat),
            ),
            style = MaterialTheme.typography.labelMedium,
            color = TextTertiary,
        )
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Column(Modifier.weight(.3f).height(plotHeight).padding(vertical = 8.dp)) {
                listOf(
                        R.string.vascular_load_higher,
                        null,
                        R.string.vascular_load_steady,
                        null,
                        R.string.vascular_load_lower,
                    )
                    .forEach { label ->
                        Box(
                            Modifier.weight(1f).fillMaxWidth(),
                            contentAlignment = Alignment.CenterEnd,
                        ) {
                            label?.let {
                                Text(
                                    stringResource(it),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextTertiary,
                                    textAlign = TextAlign.End,
                                )
                            }
                        }
                    }
            }
            Column(Modifier.weight(.7f)) {
                Canvas(
                    Modifier.fillMaxWidth()
                        .height(plotHeight)
                        .testTag("vascular_load_chart")
                        .semantics { contentDescription = description }
                        .chartProbe(
                            positions,
                            selectedIndex,
                            label = stringResource(R.string.vascular_load),
                            readings =
                                points.map { entry ->
                                    stringResource(
                                        R.string.vascular_load_chart_reading,
                                        vascularRecordDate(entry),
                                        stringResource(vascularRecordLabel(entry)),
                                    )
                                },
                        ) { index ->
                            selectedId = index?.let { points[it].id }
                        }
                ) {
                    val inset = 8.dp.toPx()
                    val usable = size.height - inset * 2
                    val baseline = inset + usable / 2
                    fun point(entry: VascularLoadLog.Entry) =
                        Offset(
                            size.width *
                                (ChronoUnit.DAYS.between(firstDay, entry.trackingDate) + .5f) / 7f,
                            inset + (5f - entry.chartValue!!) / 5f * usable,
                        )
                    repeat(5) { band ->
                        drawRect(
                            accent.copy(alpha = if (band == 2) .09f else .035f),
                            topLeft = Offset(0f, inset + usable * band / 5),
                            size = Size(size.width, usable / 5),
                        )
                    }
                    (1..4).forEach { level ->
                        val y = inset + usable * level / 5
                        drawLine(
                            grid,
                            Offset(0f, y),
                            Offset(size.width, y),
                            strokeWidth = .5.dp.toPx(),
                        )
                    }
                    (1..6).forEach { day ->
                        val x = size.width * day / 7
                        drawLine(
                            grid.copy(alpha = .2f),
                            Offset(x, inset),
                            Offset(x, size.height - inset),
                            .5.dp.toPx(),
                        )
                    }
                    drawLine(
                        accent.copy(alpha = .4f),
                        Offset(0f, baseline),
                        Offset(size.width, baseline),
                        1.dp.toPx(),
                        pathEffect =
                            PathEffect.dashPathEffect(floatArrayOf(4.dp.toPx(), 4.dp.toPx())),
                    )
                    runs.forEach { run ->
                        drawReadingCurve(run.map(::point), accent, size.height - inset, null)
                    }
                    selectedIndex?.let { index ->
                        val center = point(points[index])
                        drawLine(
                            accent.copy(alpha = .4f),
                            Offset(center.x, inset),
                            Offset(center.x, size.height - inset),
                            1.dp.toPx(),
                        )
                        drawCircle(accent.copy(alpha = .16f), 10.dp.toPx(), center)
                    }
                    points.forEach { entry ->
                        val center = point(entry)
                        drawCircle(surface, 6.dp.toPx(), center)
                        if (entry.type == VascularLoadLog.Type.BASELINE)
                            drawCircle(accent, 4.dp.toPx(), center, style = Stroke(1.5.dp.toPx()))
                        else drawCircle(accent, 4.dp.toPx(), center)
                    }
                }
                Spacer(Modifier.height(8.dp))
                BoxWithConstraints(Modifier.fillMaxWidth()) {
                    val ticks =
                        if (maxWidth / fontScale < 210.dp) listOf(0, 2, 4, 6) else (0..6).toList()
                    Layout(
                        content = {
                            ticks.forEach { day ->
                                Text(
                                    firstDay.plusDays(day.toLong()).dayOfMonth.toString(),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextTertiary,
                                    maxLines = 1,
                                    softWrap = false,
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { measurables, constraints ->
                        val labels =
                            measurables.map {
                                it.measure(constraints.copy(minWidth = 0, minHeight = 0))
                            }
                        layout(constraints.maxWidth, labels.maxOf { it.height }) {
                            labels.forEachIndexed { index, label ->
                                val x =
                                    constraints.maxWidth * (ticks[index] + .5f) / 7 -
                                        label.width / 2f
                                label.place(
                                    x.roundToInt().coerceIn(0, constraints.maxWidth - label.width),
                                    0,
                                )
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Box(
            Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(accent.copy(alpha = .08f))
                .padding(horizontal = 12.dp, vertical = 10.dp)
        ) {
            Text(
                if (selected == null) stringResource(R.string.vascular_load_chart_hint)
                else
                    stringResource(
                        R.string.vascular_load_chart_reading,
                        vascularRecordDate(selected),
                        stringResource(vascularRecordLabel(selected)),
                    ),
                modifier = Modifier.testTag("vascular_load_chart_reading"),
                style = MaterialTheme.typography.labelMedium,
                color = TextSecondary,
            )
        }
    }
}
