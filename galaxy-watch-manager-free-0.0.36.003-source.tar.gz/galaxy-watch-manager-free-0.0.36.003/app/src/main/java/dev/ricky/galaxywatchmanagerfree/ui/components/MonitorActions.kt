package dev.ricky.galaxywatchmanagerfree.ui.components

import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.core.UiNotify
import dev.ricky.galaxywatchmanagerfree.feature.monitor.HealthMonitorProtocol
import dev.ricky.galaxywatchmanagerfree.feature.monitor.HealthMonitorSession

/** ECG and BP use the same connection and send-result feedback. */
fun requestMonitorSync(
    monitor: HealthMonitorSession,
    channel: HealthMonitorProtocol.Channel,
    sessionReady: Boolean,
) {
    if (!sessionReady) {
        UiNotify.show(R.string.watch_disconnected)
    } else if (monitor.state.value.connection != HealthMonitorSession.Connection.READY) {
        monitor.connect()
        UiNotify.show(
            if (monitor.state.value.connection == HealthMonitorSession.Connection.DISCONNECTED)
                R.string.request_not_sent_check_the_watch_connection
            else R.string.connecting_to_health_monitor
        )
    } else {
        val sent = monitor.requestSync(channel)
        UiNotify.show(
            when {
                !sent -> R.string.request_not_sent_check_the_watch_connection
                channel == HealthMonitorProtocol.Channel.ECG -> R.string.syncing_ecg_records
                else -> R.string.syncing_bp_records
            }
        )
    }
}
