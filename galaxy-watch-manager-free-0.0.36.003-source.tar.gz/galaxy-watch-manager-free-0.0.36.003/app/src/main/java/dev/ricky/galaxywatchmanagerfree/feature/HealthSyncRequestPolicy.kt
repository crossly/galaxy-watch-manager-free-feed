package dev.ricky.galaxywatchmanagerfree.feature

import java.time.Instant
import java.time.ZoneId

/** Select request windows independently of protocol encoding and Android storage. */
class HealthSyncRequestPolicy(lastRecoveryAt: Long = 0L) {
    var lastRecoveryAt: Long = lastRecoveryAt
        private set

    data class Plan(val lastSyncTime: Long, val startTime: Long, val recovery: Boolean)

    @Synchronized
    fun plan(
        now: Long,
        lastSyncTime: Long,
        needsRecovery: Boolean,
        forceRecovery: Boolean = false,
        windowStart: Long? = null,
        zone: ZoneId = ZoneId.systemDefault(),
    ): Plan {
        // Explicit history pulls bypass the peer cursor but keep their requested lower bound.
        if (windowStart != null) return Plan(0L, windowStart.coerceIn(0L, now), false)
        val today = Instant.ofEpochMilli(now).atZone(zone).toLocalDate()
        val previousDay = Instant.ofEpochMilli(lastRecoveryAt).atZone(zone).toLocalDate()
        val mayRecover =
            lastRecoveryAt <= 0L ||
                now < lastRecoveryAt ||
                today != previousDay ||
                now - lastRecoveryAt >= RECOVERY_RETRY_MS
        if (forceRecovery || needsRecovery && mayRecover) return Plan(0L, 0L, true)
        val start =
            if (lastSyncTime > 0L) lastSyncTime.coerceAtMost(now)
            else today.atStartOfDay(zone).toInstant().toEpochMilli()
        return Plan(start, start, false)
    }

    @Synchronized
    fun onSent(plan: Plan, now: Long) {
        if (plan.recovery) lastRecoveryAt = now
    }

    companion object {
        const val RECOVERY_RETRY_MS = 60 * 60_000L
    }
}
