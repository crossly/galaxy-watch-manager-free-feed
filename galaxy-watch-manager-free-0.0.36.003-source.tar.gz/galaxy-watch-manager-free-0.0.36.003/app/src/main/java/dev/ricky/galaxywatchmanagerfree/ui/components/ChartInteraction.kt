package dev.ricky.galaxywatchmanagerfree.ui.components

import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.key.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextTertiary
import java.text.NumberFormat
import java.time.Instant
import java.time.ZoneId
import kotlin.math.abs

/** A fixed 00:00-24:00 axis uses local clock time, including 23/25-hour days. */
internal fun chartDayFraction(timestamp: Long, zone: ZoneId): Float =
    Instant.ofEpochMilli(timestamp).atZone(zone).toLocalTime().toSecondOfDay() / 86_400f

internal fun nearestChartIndex(positions: List<Float>, fraction: Float): Int? =
    positions.indices.minByOrNull { abs(positions[it] - fraction) }

@Composable
internal fun Modifier.chartProbe(
    positions: List<Float>,
    selectedIndex: Int?,
    label: String,
    readings: List<String>,
    onSelect: (Int?) -> Unit,
): Modifier {
    val currentSelection = rememberUpdatedState(selectedIndex)
    val select = rememberUpdatedState(onSelect)
    return chartReadingNavigation(label, readings, selectedIndex, onSelect)
        .pointerInput(positions) {
            if (positions.isEmpty()) return@pointerInput
            detectTapGestures { offset ->
                val fraction = (offset.x / size.width.coerceAtLeast(1)).coerceIn(0f, 1f)
                val current = currentSelection.value?.let(positions::getOrNull)
                select.value(
                    if (current != null && abs(current - fraction) * size.width < 32.dp.toPx()) null
                    else nearestChartIndex(positions, fraction)
                )
            }
        }
        .pointerInput(positions) {
            if (positions.isEmpty()) return@pointerInput
            fun selectAt(x: Float) {
                val fraction = (x / size.width.coerceAtLeast(1)).coerceIn(0f, 1f)
                select.value(nearestChartIndex(positions, fraction))
            }
            detectHorizontalDragGestures(
                onDragStart = { selectAt(it.x) },
                onHorizontalDrag = { change, _ ->
                    change.consume()
                    selectAt(change.position.x)
                },
            )
        }
}

@Composable
internal fun Modifier.chartReadingNavigation(
    label: String,
    readings: List<String>,
    selectedIndex: Int?,
    onSelect: (Int?) -> Unit,
): Modifier {
    val previous = stringResource(R.string.chart_previous_reading)
    val next = stringResource(R.string.chart_next_reading)
    val clear = stringResource(R.string.chart_clear_selection)
    val first = stringResource(R.string.chart_select_first)
    val description = stringResource(R.string.chart_readings_description, label, readings.size)
    val selection = selectedIndex?.takeIf { it in readings.indices }
    val state =
        when {
            readings.isEmpty() -> stringResource(R.string.chart_no_readings)
            selection == null -> stringResource(R.string.chart_no_selection)
            else ->
                stringResource(
                    R.string.chart_selected_reading,
                    readings[selection],
                    selection + 1,
                    readings.size,
                )
        }
    fun move(delta: Int): Boolean {
        val target = selection?.plus(delta) ?: if (delta > 0) 0 else readings.lastIndex
        if (target !in readings.indices) return false
        onSelect(target)
        return true
    }
    return semantics {
            contentDescription = description
            stateDescription = state
            if (readings.isNotEmpty()) {
                onClick(label = if (selection == null) first else clear) {
                    onSelect(if (selection == null) 0 else null)
                    true
                }
                customActions = buildList {
                    if (selection == null || selection > 0)
                        add(CustomAccessibilityAction(previous) { move(-1) })
                    if (selection == null || selection < readings.lastIndex)
                        add(CustomAccessibilityAction(next) { move(1) })
                    if (selection != null)
                        add(
                            CustomAccessibilityAction(clear) {
                                onSelect(null)
                                true
                            }
                        )
                }
            }
        }
        .onKeyEvent { event ->
            if (event.type != KeyEventType.KeyDown || readings.isEmpty()) false
            else
                when (event.key) {
                    Key.DirectionRight -> move(1)
                    Key.DirectionLeft -> move(-1)
                    Key.MoveHome -> {
                        onSelect(0)
                        true
                    }
                    Key.MoveEnd -> {
                        onSelect(readings.lastIndex)
                        true
                    }
                    Key.Enter,
                    Key.NumPadEnter,
                    Key.Spacebar -> {
                        onSelect(if (selection == null) 0 else null)
                        true
                    }
                    Key.Escape ->
                        if (selection != null) {
                            onSelect(null)
                            true
                        } else false
                    else -> false
                }
        }
        .focusable()
}

@Composable
internal fun ChartTimeAxis() {
    val locale = LocalConfiguration.current.locales[0]
    val numberFormat =
        androidx.compose.runtime.remember(locale) {
            NumberFormat.getIntegerInstance(locale).apply {
                minimumIntegerDigits = 2
                isGroupingUsed = false
            }
        }
    val color = TextTertiary
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val hours =
            if (maxWidth / LocalDensity.current.fontScale < 300.dp) listOf(0, 12, 24)
            else listOf(0, 6, 12, 18, 24)
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            hours.forEach { hour ->
                Text(
                    text = "${numberFormat.format(hour)}:${numberFormat.format(0)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = color,
                    fontFamily = FontFamily.Monospace,
                    maxLines = 1,
                )
            }
        }
    }
}
