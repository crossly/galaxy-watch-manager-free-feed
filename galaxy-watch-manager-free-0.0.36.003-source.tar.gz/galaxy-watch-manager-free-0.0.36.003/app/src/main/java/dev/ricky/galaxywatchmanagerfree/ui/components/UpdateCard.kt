package dev.ricky.galaxywatchmanagerfree.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import dev.ricky.galaxywatchmanagerfree.BuildConfig
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.core.ApkIntegrity
import dev.ricky.galaxywatchmanagerfree.core.ApkUpdater
import dev.ricky.galaxywatchmanagerfree.core.AppUpdate
import dev.ricky.galaxywatchmanagerfree.core.DownloadMirror
import dev.ricky.galaxywatchmanagerfree.core.UiNotify
import dev.ricky.galaxywatchmanagerfree.core.UpdateChecker
import dev.ricky.galaxywatchmanagerfree.ui.theme.AlertCrimson
import dev.ricky.galaxywatchmanagerfree.ui.theme.CardSurfaceElevated
import dev.ricky.galaxywatchmanagerfree.ui.theme.ElectricBlue
import dev.ricky.galaxywatchmanagerfree.ui.theme.EmeraldCharging
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextSecondary
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextTertiary
import java.text.SimpleDateFormat
import java.util.Date

private const val QQ_GROUP_ID = "377803838"

/**
 * 关于与更新：版本、手动/自动检查、后台下载进度与安装入口。
 *
 * 发现新版本后自动下载，校验摘要与签名后才提供安装按钮；失败保留发布页入口。 检查周期保存在 [UpdateChecker] 偏好中，默认 12 小时。
 */
@Composable
fun UpdateCard(context: Context, modifier: Modifier = Modifier) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources

    val state by UpdateChecker.state.collectAsState()
    val update by ApkUpdater.state.collectAsState()
    LaunchedEffect(context) { UpdateChecker.restoreChannel(context) }
    val checking = state.status == UpdateChecker.Status.CHECKING
    val available = state.status == UpdateChecker.Status.UPDATE_AVAILABLE
    val info = state.info
    val canDownload = available && info != null && !info.apkUrl.isNullOrBlank()
    val downloading =
        update.phase == ApkUpdater.Phase.DOWNLOADING || update.phase == ApkUpdater.Phase.VERIFYING
    val statusMessage = state.message?.resolve(strings).orEmpty()
    val downloadMessage = update.message?.resolve(strings).orEmpty()
    val lastChecked =
        state.checkedAt
            .takeIf { it > 0 }
            ?.let {
                strings.getString(
                    R.string.last_check_time,
                    SimpleDateFormat("yyyy-MM-dd HH:mm", strings.configuration.locales[0])
                        .format(Date(it)),
                )
            }

    fun openReleasePage() {
        val url = state.info?.pageUrl ?: UpdateChecker.RELEASES_URL
        runCatching {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    fun openQqGroup() {
        val groupLink =
            "mqqapi://card/show_pslcard?src_type=internal&version=1&uin=$QQ_GROUP_ID&card_type=group"
        runCatching {
                context.startActivity(
                    Intent(Intent.ACTION_VIEW, Uri.parse(groupLink))
                        .setPackage("com.tencent.mobileqq")
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
            .onFailure { UiNotify.show(R.string.qq_unavailable) }
    }

    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        GroupedCard(innerPadding = 0.dp) {
            GroupedCardRow(
                title =
                    strings.getString(
                        R.string.current_version,
                        BuildConfig.VERSION_NAME,
                        BuildConfig.VERSION_CODE,
                    ),
                icon = Icons.Default.SystemUpdate,
                iconBackground = ElectricBlue.copy(alpha = 0.14f),
            )
            GroupedDivider()
            SettingChoiceRow(
                title = strings.getString(R.string.update_channel),
                options =
                    listOf(
                        strings.getString(R.string.update_channel_stable),
                        strings.getString(R.string.update_channel_nightly),
                    ),
                selectedIndex = state.channel.ordinal,
                onSelect = { index ->
                    UpdateChecker.setChannel(context, AppUpdate.Channel.entries[index])
                },
            )
            GroupedDivider()
            GroupedCardRow(
                title =
                    strings.getString(
                        if (checking) R.string.checking else R.string.check_for_updates
                    ),
                subtitle =
                    listOfNotNull(statusMessage.ifEmpty { null }, lastChecked).joinToString(" · "),
                icon = Icons.Default.Refresh,
                showChevron = true,
                enabled = !checking && !update.busy,
                onClick = { UpdateChecker.check(context) },
                trailing = {
                    if (checking)
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            strokeWidth = 2.dp,
                        )
                },
            )
            if (available) {
                GroupedDivider()
                GroupedCardRow(
                    title =
                        strings.getString(R.string.update_available, info?.versionName.orEmpty()),
                    subtitle = info?.notes?.take(280),
                    icon = Icons.Default.SystemUpdate,
                    iconTint = EmeraldCharging,
                    iconBackground = EmeraldCharging.copy(alpha = 0.14f),
                    trailing = {
                        TextButton(
                            onClick = {
                                when (update.phase) {
                                    ApkUpdater.Phase.READY,
                                    ApkUpdater.Phase.AWAITING_INSTALL_PERMISSION,
                                    ApkUpdater.Phase.INSTALLING -> ApkUpdater.install(context)
                                    ApkUpdater.Phase.DOWNLOADING,
                                    ApkUpdater.Phase.VERIFYING -> {}
                                    else ->
                                        info?.let {
                                            ApkUpdater.download(context, it, autoInstall = false)
                                        }
                                }
                            },
                            enabled = canDownload && !downloading,
                        ) {
                            Text(
                                strings.getString(
                                    when (update.phase) {
                                        ApkUpdater.Phase.READY,
                                        ApkUpdater.Phase.AWAITING_INSTALL_PERMISSION,
                                        ApkUpdater.Phase.INSTALLING -> R.string.install
                                        ApkUpdater.Phase.ERROR -> R.string.download_again
                                        ApkUpdater.Phase.DOWNLOADING -> R.string.downloading
                                        ApkUpdater.Phase.VERIFYING -> R.string.verifying
                                        ApkUpdater.Phase.IDLE -> R.string.download_now
                                    }
                                )
                            )
                        }
                    },
                )
                if (canDownload && update.phase != ApkUpdater.Phase.IDLE) {
                    Column(
                        Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, bottom = 14.dp)
                    ) {
                        if (downloading) {
                            LinearProgressIndicator(
                                progress = {
                                    if (
                                        update.phase == ApkUpdater.Phase.VERIFYING ||
                                            update.total <= 0L
                                    )
                                        0.35f
                                    else update.progress
                                },
                                modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
                                color = ElectricBlue,
                                trackColor = CardSurfaceElevated,
                            )
                            Spacer(Modifier.height(6.dp))
                        }
                        if (downloadMessage.isNotEmpty()) {
                            Text(
                                downloadMessage,
                                style = MaterialTheme.typography.labelSmall,
                                color =
                                    when (update.phase) {
                                        ApkUpdater.Phase.READY -> EmeraldCharging
                                        ApkUpdater.Phase.ERROR -> AlertCrimson
                                        else -> TextSecondary
                                    },
                                fontFamily = FontFamily.Monospace,
                            )
                        }
                        if (downloading && update.total > 0L) {
                            Spacer(Modifier.height(2.dp))
                            Text(
                                ApkIntegrity.sizeText(update.downloaded) +
                                    " / " +
                                    ApkIntegrity.sizeText(update.total),
                                style = MaterialTheme.typography.labelSmall,
                                color = TextTertiary,
                                fontFamily = FontFamily.Monospace,
                            )
                        }
                    }
                }
                GroupedDivider()
                GroupedCardRow(
                    title = strings.getString(R.string.release_page),
                    icon = Icons.AutoMirrored.Filled.OpenInNew,
                    showChevron = true,
                    onClick = { openReleasePage() },
                )
            }
        }

        Text(
            strings.getString(
                if (state.channel == AppUpdate.Channel.NIGHTLY) R.string.update_channel_nightly_hint
                else R.string.update_channel_stable_hint
            ),
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary,
            modifier = Modifier.padding(horizontal = 16.dp),
        )
        var autoHours by remember { mutableIntStateOf(UpdateChecker.autoCheckHours(context)) }
        val options = UpdateChecker.AUTO_HOURS_OPTIONS
        SectionHeader(strings.getString(R.string.auto_update_section))
        GroupedCard(innerPadding = 0.dp) {
            SettingChoiceRow(
                title = strings.getString(R.string.auto_check_updates_title),
                options =
                    options.map { hours ->
                        if (hours <= UpdateChecker.AUTO_HOURS_DISABLED) {
                            strings.getString(R.string.update_never)
                        } else {
                            strings.getQuantityString(R.plurals.update_hours_interval, hours, hours)
                        }
                    },
                selectedIndex = options.indexOf(autoHours).coerceAtLeast(0),
                onSelect = { index ->
                    val hours = options.getOrElse(index) { UpdateChecker.DEFAULT_AUTO_HOURS }
                    autoHours = hours
                    UpdateChecker.setAutoCheckHours(context, hours)
                },
            )
        }
        Text(
            strings.getString(
                if (autoHours <= UpdateChecker.AUTO_HOURS_DISABLED) {
                    R.string.auto_check_updates_disabled_hint
                } else {
                    R.string.auto_check_updates_hint
                }
            ),
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary,
            modifier = Modifier.padding(horizontal = 16.dp),
        )

        var mirror by remember { mutableStateOf(UpdateChecker.mirror(context)) }
        SectionHeader(strings.getString(R.string.update_mirror_section))
        GroupedCard(innerPadding = 0.dp) {
            SettingChoiceRow(
                title = strings.getString(R.string.update_mirror_title),
                options = DownloadMirror.entries.map { item -> mirrorLabel(strings, item) },
                selectedIndex = DownloadMirror.entries.indexOf(mirror).coerceAtLeast(0),
                onSelect = { index ->
                    val selected = DownloadMirror.entries.getOrElse(index) { DownloadMirror.OFF }
                    mirror = selected
                    UpdateChecker.setMirror(context, selected)
                },
            )
        }
        Text(
            strings.getString(R.string.update_mirror_hint),
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary,
            modifier = Modifier.padding(horizontal = 16.dp),
        )

        SectionHeader(strings.getString(R.string.contact_us))
        GroupedCard(innerPadding = 0.dp) {
            GroupedCardRow(
                title = strings.getString(R.string.qq_group, QQ_GROUP_ID),
                subtitle = strings.getString(R.string.qq_group_hint),
                icon = Icons.Default.Groups,
                iconTint = ElectricBlue,
                iconBackground = ElectricBlue.copy(alpha = 0.14f),
                showChevron = true,
                onClick = { openQqGroup() },
            )
        }
    }
}

private fun mirrorLabel(strings: android.content.res.Resources, mirror: DownloadMirror): String =
    when (mirror) {
        DownloadMirror.OFF -> strings.getString(R.string.update_mirror_off)
        else -> mirror.host
    }
