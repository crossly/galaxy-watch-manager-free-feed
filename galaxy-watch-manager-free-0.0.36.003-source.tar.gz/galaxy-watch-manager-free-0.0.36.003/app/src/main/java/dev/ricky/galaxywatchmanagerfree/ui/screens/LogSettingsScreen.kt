package dev.ricky.galaxywatchmanagerfree.ui.screens

import android.content.ClipData
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.core.UiNotify
import dev.ricky.galaxywatchmanagerfree.feature.LogBus
import dev.ricky.galaxywatchmanagerfree.ui.components.GroupedCard
import dev.ricky.galaxywatchmanagerfree.ui.components.SettingSwitchRow
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextPrimary
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextSecondary
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun LogSettingsScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val enabled by LogBus.debugEnabled.collectAsState()
    val runtime by LogBus.lines.collectAsState()
    val debug by LogBus.debugLines.collectAsState()
    val storageError by LogBus.storageError.collectAsState()
    var showDebug by rememberSaveable { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    fun failure(error: Exception) {
        LogBus.error("[日志] 导出失败", error)
        UiNotify.show(R.string.log_export_failed)
    }
    val destination =
        rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) {
            uri ->
            if (uri != null && !busy)
                scope.launch {
                    busy = true
                    try {
                        val snapshot = LogBus.export(context)
                        withContext(Dispatchers.IO) {
                            context.contentResolver.openOutputStream(uri, "wt")?.use { output ->
                                snapshot.inputStream().use { it.copyTo(output) }
                            } ?: error("Log export destination unavailable")
                        }
                        UiNotify.show(R.string.log_export_saved)
                    } catch (cancelled: CancellationException) {
                        throw cancelled
                    } catch (error: Exception) {
                        failure(error)
                    } finally {
                        busy = false
                    }
                }
        }
    val entries =
        remember(runtime, debug, showDebug) {
            (if (showDebug) debug else runtime).takeLast(100).asReversed()
        }
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            GroupedCard {
                SettingSwitchRow(
                    title = stringResource(R.string.enable_debug_logs),
                    subtitle = stringResource(R.string.debug_logs_description),
                    checked = enabled,
                    onCheckedChange = { LogBus.setDebugEnabled(context, it) },
                    modifier = Modifier.testTag("tag_debug_logs"),
                )
                Spacer(Modifier.height(12.dp))
                Text(
                    stringResource(R.string.log_storage_description),
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodySmall,
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    stringResource(R.string.log_privacy_description),
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodySmall,
                )
                if (storageError) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        stringResource(R.string.log_storage_failed),
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        enabled = !busy,
                        onClick = {
                            destination.launch("watchfree-logs-${System.currentTimeMillis()}.txt")
                        },
                        modifier = Modifier.weight(1f).testTag("tag_save_logs"),
                    ) {
                        Text(stringResource(R.string.log_export_file))
                    }
                    OutlinedButton(
                        enabled = !busy,
                        modifier = Modifier.weight(1f).testTag("tag_share_logs"),
                        onClick = {
                            scope.launch {
                                busy = true
                                try {
                                    val file = LogBus.export(context)
                                    val uri =
                                        FileProvider.getUriForFile(
                                            context,
                                            context.packageName + ".fileprovider",
                                            file,
                                        )
                                    val intent =
                                        Intent(Intent.ACTION_SEND)
                                            .setType("text/plain")
                                            .putExtra(Intent.EXTRA_STREAM, uri)
                                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    intent.clipData = ClipData.newRawUri("diagnostic logs", uri)
                                    context.startActivity(
                                        Intent.createChooser(
                                            intent,
                                            context.getString(R.string.log_export_file),
                                        )
                                    )
                                } catch (cancelled: CancellationException) {
                                    throw cancelled
                                } catch (error: Exception) {
                                    failure(error)
                                } finally {
                                    busy = false
                                }
                            }
                        },
                    ) {
                        Text(stringResource(R.string.log_share_file))
                    }
                }
                if (busy) {
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = !showDebug,
                    onClick = { showDebug = false },
                    label = { Text(stringResource(R.string.runtime_logs)) },
                )
                FilterChip(
                    selected = showDebug,
                    onClick = { showDebug = true },
                    label = { Text(stringResource(R.string.debug_logs)) },
                )
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { LogBus.clear() }, enabled = !busy) {
                    Text(stringResource(R.string.clear))
                }
            }
        }
        if (entries.isEmpty()) {
            item {
                Text(
                    stringResource(R.string.log_empty),
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
        }
        items(entries.size) { index ->
            GroupedCard(innerPadding = 12.dp) {
                Text(
                    entries[index],
                    fontFamily = FontFamily.Monospace,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextPrimary,
                    maxLines = 8,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}
