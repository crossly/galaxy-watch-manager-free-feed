package dev.ricky.galaxywatchmanagerfree.feature

import android.content.Context
import dev.ricky.galaxywatchmanagerfree.wcs.CompanionProfile
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/** Device-scoped verified identities. Unverified candidates live only in this process. */
class DeviceIdentityStore(context: Context, val peerAddress: String?) {

    /** 交接待定身份可与已确认身份共存；阶段优先呈现尚未完成的交接。 */
    enum class IdentityPhase {
        NONE,
        CANDIDATE,
        PENDING,
        CONFIRMED,
        RELEASED,
    }

    private val scope = DeviceScope.preferences(PREFS_BASE, peerAddress)
    private val prefs = context.getSharedPreferences(scope, Context.MODE_PRIVATE)
    private val legacyPeer =
        DeviceScope.canImportLegacy(peerAddress, DevicePreferences.legacyOwner(context))

    val hasStoredPhoneNode: Boolean
        get() = prefs.getString(KEY_PHONE_NODE, null)?.let(::isValidNode) == true

    val confirmedPhoneNode: String
        get() =
            prefs.getString(KEY_PHONE_NODE, null)?.takeIf(::isValidNode)
                ?: if (legacyPeer)
                    dev.ricky.galaxywatchmanagerfree.wcs.WcsSession.PREFERRED_PHONE_NODE
                else ""

    val candidatePhoneNode: String
        get() = candidates[scope].orEmpty()

    val effectivePhoneNode: String
        get() = candidatePhoneNode.ifBlank { confirmedPhoneNode }

    val confirmedWatchNode: String
        get() =
            prefs.getString(KEY_WATCH_NODE, null)
                ?: if (legacyPeer) dev.ricky.galaxywatchmanagerfree.wcs.WcsPaths.FALLBACK_NODE
                else ""

    val confirmedPluginPackage: String?
        get() = CompanionProfile.fromPackage(prefs.getString(KEY_PLUGIN_PACKAGE, null))?.packageName

    private fun savePluginProfile(profile: CompanionProfile) {
        prefs.edit().putString(KEY_PLUGIN_PACKAGE, profile.packageName).apply()
    }

    /**
     * 应用交接（临时停用官方连接管理 App）期间显式暂存的手机节点。
     *
     * 与 [candidatePhoneNode] 不同：候选只在当前进程内有效、必须经 WCS 现场验证；这里的待定身份落在本设备域的 SharedPreferences
     * 里，可以在进程重启后继续使用，但在手表现场证明之前绝不视为已确认身份。
     */
    val pendingHandoverNode: String
        get() =
            prefs
                .getString(KEY_PENDING_PHONE_NODE, null)
                ?.let(::normalizeNode)
                ?.takeIf(::isValidNode)
                .orEmpty()

    val hasPendingHandover: Boolean
        get() = pendingHandoverNode.isNotBlank()

    /** 交接准备中：阻止自动连接与常驻服务的粘性重启，直到显式继续或取消。 */
    val handoverPreparing: Boolean
        get() = prefs.getBoolean(KEY_HANDOVER_PREPARING, false)

    /** 官方应用恢复后由其独占连接；只有用户显式连接或重新交接时才解除。 */
    val releasedToOfficialApps: Boolean
        get() = prefs.getBoolean(KEY_RELEASED_TO_OFFICIAL_APPS, false)

    val phoneName: String?
        get() = prefs.getString(KEY_PHONE_NAME, null)

    /** 从持久化键与进程内候选推导的当前身份阶段。 */
    val phase: IdentityPhase
        get() =
            when {
                releasedToOfficialApps -> IdentityPhase.RELEASED
                hasPendingHandover || handoverPreparing -> IdentityPhase.PENDING
                candidatePhoneNode.isNotBlank() -> IdentityPhase.CANDIDATE
                confirmedPhoneNode.isNotBlank() -> IdentityPhase.CONFIRMED
                else -> IdentityPhase.NONE
            }

    /** BeginHandover 的返回值表示待定身份可用，其他事件保留各操作的原返回语义。 */
    fun transition(event: IdentityEvent): Boolean =
        when (event) {
            is IdentityEvent.BeginHandover -> beginHandoverPreparation(event.node)
            is IdentityEvent.StagePendingHandover -> stagePendingHandover(event.node)
            IdentityEvent.EndHandoverPreparation -> endHandoverPreparation()
            IdentityEvent.ClearHandover -> {
                clearHandover()
                true
            }
            IdentityEvent.ReleaseToOfficialApps -> releaseToOfficialApps()
            IdentityEvent.ReclaimFromOfficialApps -> {
                reclaimFromOfficialApps()
                true
            }
            is IdentityEvent.StageCandidatePhoneNode -> stageCandidatePhoneNode(event.node)
            IdentityEvent.ClearCandidatePhoneNode -> {
                clearCandidatePhoneNode()
                true
            }
            is IdentityEvent.ConfirmPhoneNode -> confirmPhoneNode(event.node, event.name)
            is IdentityEvent.SaveWatchNode -> saveWatchNode(event.node)
            is IdentityEvent.SavePluginProfile -> {
                savePluginProfile(event.profile)
                true
            }
        }

    /**
     * 进入交接准备并暂存身份。返回 true 表示已有可用的待定身份（无需再次获取）。
     *
     * [node] 为空时只置位准备标记，等异步身份获取成功后再调用 [stagePendingHandover]。
     */
    private fun beginHandoverPreparation(node: String? = null): Boolean {
        val normalized = node?.let(::normalizeNode)?.takeIf(::isValidNode)
        // 交接状态必须在进程被杀前落盘；这里用 commit 而不是 apply。
        prefs
            .edit()
            .putBoolean(KEY_HANDOVER_PREPARING, true)
            .apply { if (normalized != null) putString(KEY_PENDING_PHONE_NODE, normalized) }
            .commit()
        return hasPendingHandover
    }

    /** 暂存（或替换）尚未验证的交接身份；准备标记保持置位。 */
    private fun stagePendingHandover(node: String): Boolean {
        val normalized = normalizeNode(node)
        if (!isValidNode(normalized)) return false
        prefs
            .edit()
            .putString(KEY_PENDING_PHONE_NODE, normalized)
            .putBoolean(KEY_HANDOVER_PREPARING, true)
            .commit()
        return true
    }

    /** 退出交接准备（显式继续连接时调用）。待定身份保留，直到 WCS 现场验证成功或用户取消。 */
    private fun endHandoverPreparation(): Boolean {
        if (!handoverPreparing) return false
        prefs.edit().putBoolean(KEY_HANDOVER_PREPARING, false).commit()
        return true
    }

    /** 取消交接：丢弃待定身份、准备标记与进程内候选。 */
    private fun clearHandover() {
        prefs
            .edit()
            .remove(KEY_PENDING_PHONE_NODE)
            .remove(KEY_RELEASED_TO_OFFICIAL_APPS)
            .putBoolean(KEY_HANDOVER_PREPARING, false)
            .commit()
        candidates.remove(scope)
    }

    /** 把连接交还给官方应用。该状态必须跨进程存活，否则系统清理后台后本应用会在启动时 重新连接并与刚恢复的官方应用争抢 RFCOMM。 */
    private fun releaseToOfficialApps(): Boolean {
        candidates.remove(scope)
        return prefs
            .edit()
            .remove(KEY_PENDING_PHONE_NODE)
            .putBoolean(KEY_HANDOVER_PREPARING, false)
            .putBoolean(KEY_RELEASED_TO_OFFICIAL_APPS, true)
            .commit()
    }

    /** 用户显式重新连接本应用时解除官方应用独占状态。 */
    private fun reclaimFromOfficialApps() {
        if (releasedToOfficialApps) {
            prefs.edit().putBoolean(KEY_RELEASED_TO_OFFICIAL_APPS, false).apply()
        }
    }

    private fun stageCandidatePhoneNode(node: String): Boolean {
        val normalized = normalizeNode(node)
        if (!isValidNode(normalized)) return false
        candidates[scope] = normalized
        return true
    }

    private fun clearCandidatePhoneNode() {
        candidates.remove(scope)
    }

    private fun confirmPhoneNode(node: String, name: String? = null): Boolean {
        val normalized = normalizeNode(node)
        if (!isValidNode(normalized)) return false
        prefs
            .edit()
            .putString(KEY_PHONE_NODE, normalized)
            .apply { if (!name.isNullOrBlank()) putString(KEY_PHONE_NAME, name.trim()) }
            .remove(KEY_PENDING_PHONE_NODE)
            .putBoolean(KEY_HANDOVER_PREPARING, false)
            .apply()
        candidates.remove(scope, normalized)
        return true
    }

    private fun saveWatchNode(node: String): Boolean {
        val normalized = normalizeNode(node)
        if (!isValidNode(normalized) || normalized == effectivePhoneNode) return false
        prefs.edit().putString(KEY_WATCH_NODE, normalized).apply()
        return true
    }

    companion object {
        const val PREFS_BASE = "watchfree_pairing"
        const val KEY_PHONE_NODE = "phone_node"
        const val KEY_WATCH_NODE = "watch_node"
        private const val KEY_PLUGIN_PACKAGE = "plugin_package"
        const val KEY_PHONE_NAME = "phone_name"
        const val KEY_PENDING_PHONE_NODE = "handover_pending_node"
        const val KEY_HANDOVER_PREPARING = "handover_preparing"
        const val KEY_RELEASED_TO_OFFICIAL_APPS = "released_to_official_apps"
        private val candidates = ConcurrentHashMap<String, String>()

        fun normalizeNode(node: String): String = node.trim().lowercase(Locale.ROOT)

        fun isValidNode(node: String): Boolean = node.matches(Regex("[0-9a-f]{7,8}"))
    }
}

/** 身份与交接的显式迁移事件：[DeviceIdentityStore.transition] 的唯一输入。 */
sealed interface IdentityEvent {
    data class BeginHandover(val node: String? = null) : IdentityEvent

    data class StagePendingHandover(val node: String) : IdentityEvent

    data object EndHandoverPreparation : IdentityEvent

    data object ClearHandover : IdentityEvent

    data object ReleaseToOfficialApps : IdentityEvent

    data object ReclaimFromOfficialApps : IdentityEvent

    data class StageCandidatePhoneNode(val node: String) : IdentityEvent

    data object ClearCandidatePhoneNode : IdentityEvent

    data class ConfirmPhoneNode(val node: String, val name: String? = null) : IdentityEvent

    data class SaveWatchNode(val node: String) : IdentityEvent

    data class SavePluginProfile(val profile: CompanionProfile) : IdentityEvent
}
