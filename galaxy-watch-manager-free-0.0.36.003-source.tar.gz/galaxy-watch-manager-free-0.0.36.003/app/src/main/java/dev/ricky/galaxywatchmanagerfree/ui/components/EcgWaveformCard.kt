package dev.ricky.galaxywatchmanagerfree.ui.components

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.core.*
import dev.ricky.galaxywatchmanagerfree.feature.monitor.EcgRecord
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun EcgWaveformCard(record: EcgRecord) {
    val context = LocalContext.current
    val strings = context.resources
    val scope = rememberCoroutineScope()
    var saving by remember(record.id) { mutableStateOf(false) }
    fun save() {
        if (saving || record.waveform.isEmpty()) return
        saving = true
        val caption =
            strings.getString(
                R.string.ecg_image_caption,
                formatMonitorRecordTime(record.startTime),
                record.heartRate.takeIf { it > 0 }?.toString() ?: "—",
                strings.getString(record.classificationRes),
            )
        val scale = strings.getString(R.string.ecg_scale_caption)
        scope.launch {
            try {
                withContext(Dispatchers.IO) {
                    val bitmap = EcgImageRenderer.render(record, caption, scale)
                    try {
                        GalleryImage.save(
                            context,
                            bitmap,
                            "ECG-${record.startTime}-${System.currentTimeMillis()}.png",
                        )
                    } finally {
                        bitmap.recycle()
                    }
                }
                UiNotify.show(R.string.ecg_image_saved)
            } catch (cancelled: kotlinx.coroutines.CancellationException) {
                throw cancelled
            } catch (_: OutOfMemoryError) {
                UiNotify.show(R.string.ecg_image_failed)
            } catch (error: Exception) {
                dev.ricky.galaxywatchmanagerfree.feature.LogBus.log(
                    "[ECG image] ${error.javaClass.simpleName}"
                )
                UiNotify.show(R.string.ecg_image_failed)
            } finally {
                saving = false
            }
        }
    }
    val permission =
        rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) save() else UiNotify.show(R.string.ecg_image_failed)
        }
    GroupedCard {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    stringResource(R.string.ecg_waveform),
                    style = MaterialTheme.typography.titleMedium,
                )
                Text(
                    formatMonitorRecordTime(record.startTime),
                    style = MaterialTheme.typography.labelMedium,
                )
            }
            FilledTonalIconButton(
                enabled = !saving && record.waveform.isNotEmpty(),
                onClick = {
                    if (
                        Build.VERSION.SDK_INT < 29 &&
                            context.checkSelfPermission(
                                Manifest.permission.WRITE_EXTERNAL_STORAGE
                            ) != PackageManager.PERMISSION_GRANTED
                    )
                        permission.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    else save()
                },
            ) {
                if (saving) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                else Icon(Icons.Default.Download, stringResource(R.string.save_ecg_image))
            }
        }
        Spacer(Modifier.height(12.dp))
        key(record.id) {
            EcgWaveformChart(waveform = record.waveform, sampleRate = record.sampleRate)
        }
    }
}
