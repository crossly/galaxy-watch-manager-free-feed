package dev.ricky.galaxywatchmanagerfree.ui.screens

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.core.UiNotify
import dev.ricky.galaxywatchmanagerfree.feature.HealthArchive
import dev.ricky.galaxywatchmanagerfree.feature.WatchRepository
import dev.ricky.galaxywatchmanagerfree.ui.components.GroupedCard
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextPrimary
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextSecondary
import java.io.File
import java.time.ZoneId
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun HealthExportSettings(repo: WatchRepository) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    fun failure(error: Exception) {
        dev.ricky.galaxywatchmanagerfree.feature.LogBus.error("[Health export] Failed", error)
        UiNotify.show(R.string.export_failed)
    }
    val destination =
        rememberLauncherForActivityResult(
            ActivityResultContracts.CreateDocument("application/zip")
        ) { uri ->
            if (uri != null && !busy)
                scope.launch {
                    busy = true
                    try {
                        withContext(Dispatchers.IO) {
                            val snapshot = repo.healthExportSnapshot()
                            context.contentResolver.openOutputStream(uri, "wt")?.use {
                                HealthArchive.write(
                                    it,
                                    snapshot,
                                    System.currentTimeMillis(),
                                    ZoneId.systemDefault(),
                                )
                            } ?: error("Export destination unavailable")
                        }
                        UiNotify.show(R.string.export_saved)
                    } catch (cancelled: kotlinx.coroutines.CancellationException) {
                        runCatching {
                            android.provider.DocumentsContract.deleteDocument(
                                context.contentResolver,
                                uri,
                            )
                        }
                        throw cancelled
                    } catch (error: Exception) {
                        runCatching {
                            android.provider.DocumentsContract.deleteDocument(
                                context.contentResolver,
                                uri,
                            )
                        }
                        failure(error)
                    } finally {
                        busy = false
                    }
                }
        }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        GroupedCard {
            Text(
                stringResource(R.string.export_health_description),
                style = MaterialTheme.typography.bodyMedium,
                color = TextPrimary,
            )
            Spacer(Modifier.height(12.dp))
            Text(
                stringResource(R.string.export_health_scope),
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
            )
            Spacer(Modifier.height(12.dp))
            Button(
                enabled = !busy,
                onClick = {
                    destination.launch("galaxy-watch-health-${System.currentTimeMillis()}.zip")
                },
            ) {
                Text(stringResource(R.string.export_save_file))
            }
            OutlinedButton(
                enabled = !busy,
                onClick = {
                    scope.launch {
                        busy = true
                        var pending: File? = null
                        try {
                            val file =
                                withContext(Dispatchers.IO) {
                                    val directory =
                                        File(context.cacheDir, "health_exports").apply {
                                            check(isDirectory || mkdirs())
                                        }
                                    directory
                                        .listFiles()
                                        ?.filter {
                                            System.currentTimeMillis() - it.lastModified() >
                                                24 * 3_600_000L
                                        }
                                        ?.forEach { it.delete() }
                                    File(directory, "health-${System.currentTimeMillis()}.zip")
                                        .also { output ->
                                            pending = output
                                            output.outputStream().use {
                                                HealthArchive.write(
                                                    it,
                                                    repo.healthExportSnapshot(),
                                                    System.currentTimeMillis(),
                                                    ZoneId.systemDefault(),
                                                )
                                            }
                                        }
                                }
                            val uri =
                                FileProvider.getUriForFile(
                                    context,
                                    context.packageName + ".fileprovider",
                                    file,
                                )
                            val share =
                                Intent(Intent.ACTION_SEND)
                                    .setType("application/zip")
                                    .putExtra(Intent.EXTRA_STREAM, uri)
                                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            share.clipData =
                                android.content.ClipData.newRawUri("health export", uri)
                            context.startActivity(
                                Intent.createChooser(
                                    share,
                                    context.getString(R.string.export_health_data),
                                )
                            )
                            pending = null
                        } catch (cancelled: kotlinx.coroutines.CancellationException) {
                            pending?.delete()
                            throw cancelled
                        } catch (error: Exception) {
                            pending?.delete()
                            failure(error)
                        } finally {
                            busy = false
                        }
                    }
                },
            ) {
                Text(stringResource(R.string.export_share_file))
            }
            if (busy) {
                CircularProgressIndicator(Modifier.size(24.dp))
                Text(
                    stringResource(R.string.export_building),
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                )
            }
        }
    }
}
