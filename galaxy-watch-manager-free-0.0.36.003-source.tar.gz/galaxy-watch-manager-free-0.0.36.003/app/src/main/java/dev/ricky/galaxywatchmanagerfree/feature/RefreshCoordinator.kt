package dev.ricky.galaxywatchmanagerfree.feature

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** Owns one manual refresh through dispatch, device replies and the health sync handshake. */
class RefreshCoordinator(
    private val scope: CoroutineScope,
    private val onRunning: (Boolean) -> Unit,
    private val onLog: (String) -> Unit = {},
) {
    enum class Target {
        FEATURE,
        STATUS,
        BATTERY,
        BATTERY_DETAILS,
        BATTERY_USAGE,
        BATTERY_SETTING,
        MEMORY,
        SETTINGS,
        APPS,
        WATCH_FACE_ORDER,
        HEALTH,
        WATCH_FACE,
    }

    /** 一次刷新的相位：IDLE → DISPATCHING（同步派发中）→ AWAITING（等待设备回包）。 */
    private enum class Phase {
        IDLE,
        DISPATCHING,
        AWAITING,
    }

    private var generation = 0L
    private var phase = Phase.IDLE
    private val pending = mutableSetOf<Target>()
    private var timeout: Job? = null

    fun request(send: (Long) -> Unit): Boolean {
        val token =
            synchronized(this) {
                if (phase != Phase.IDLE) return false
                phase = Phase.DISPATCHING
                pending.addAll(Target.entries)
                onRunning(true)
                val current = ++generation
                timeout =
                    scope.launch {
                        delay(DEVICE_TIMEOUT_MS)
                        synchronized(this@RefreshCoordinator) {
                            if (!isActive || phase == Phase.IDLE || generation != current)
                                return@launch
                            val missing = pending.filter { it != Target.HEALTH }
                            pending.removeAll(missing.toSet())
                            if (missing.isNotEmpty()) {
                                onLog("[刷新] 部分设备查询未回包，不自动重试：$missing")
                            }
                            finishIfComplete()
                        }
                    }
                current
            }
        try {
            // Sending may enter the health coordinator or DeviceCare queue; never hold our lock.
            send(token)
        } catch (error: Exception) {
            synchronized(this) { if (phase != Phase.IDLE && generation == token) stop() }
            onLog("[刷新] 请求失败：${error.javaClass.simpleName}")
            return false
        } finally {
            synchronized(this) {
                if (phase != Phase.IDLE && generation == token) {
                    phase = Phase.AWAITING
                    finishIfComplete()
                }
            }
        }
        return true
    }

    @Synchronized
    fun isPending(token: Long, target: Target): Boolean =
        phase != Phase.IDLE && generation == token && target in pending

    @Synchronized
    fun confirm(target: Target) {
        if (phase == Phase.IDLE) return
        pending.remove(target)
        finishIfComplete()
    }

    private fun finishIfComplete() {
        if (phase == Phase.AWAITING && pending.isEmpty()) stop()
    }

    @Synchronized
    fun stop() {
        generation++
        timeout?.cancel()
        timeout = null
        pending.clear()
        val wasActive = phase != Phase.IDLE
        phase = Phase.IDLE
        if (wasActive) onRunning(false)
    }

    companion object {
        // Health has its own renewable 60-second chunk timeout; do not truncate it here.
        const val DEVICE_TIMEOUT_MS = 30_000L
    }
}
