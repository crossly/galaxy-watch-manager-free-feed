package dev.ricky.galaxywatchmanagerfree.feature

import dev.ricky.galaxywatchmanagerfree.R
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import org.json.JSONArray
import org.json.JSONObject

/**
 * 单次测量的健康指标（血氧 / 皮肤温度 / 呼吸频率 / HRV）的解析与统计。
 *
 * 这些模块都是一次一条记录，字段固定，语义相同，因此共用一个轻量管线： 记录 → 采样点 → 去重排序 → 按天汇总 → 图表。字段名取自三星健康的模块字典， 同时兼容
 * `com.samsung.health.*` 长名。
 */
enum class HealthMetric(
    val moduleKeys: List<String>,
    @androidx.annotation.StringRes val labelRes: Int,
    @androidx.annotation.StringRes val unitRes: Int,
    val decimals: Int,
    val validMin: Float,
    val validMax: Float,
    private val valueKeys: List<String>,
) {
    SPO2(
        moduleKeys =
            listOf(
                "com.samsung.shealth.tracker.oxygen_saturation",
                "com.samsung.shealth.oxygen_saturation",
                "com.samsung.health.oxygen_saturation",
            ),
        labelRes = R.string.metric_spo2,
        unitRes = R.string.unit_percent,
        decimals = 0,
        validMin = 50f,
        validMax = 100f,
        valueKeys = listOf("spo2", "com.samsung.health.oxygen_saturation.spo2"),
    ),
    SKIN_TEMP(
        moduleKeys =
            listOf("com.samsung.shealth.skin_temperature", "com.samsung.health.skin_temperature"),
        labelRes = R.string.metric_skin_temp,
        unitRes = R.string.unit_celsius,
        decimals = 1,
        validMin = 20f,
        validMax = 42f,
        valueKeys = listOf("temperature", "mean", "com.samsung.health.skin_temperature.temperature"),
    ),
    RESPIRATORY(
        moduleKeys =
            listOf("com.samsung.shealth.respiratory_rate", "com.samsung.health.respiratory_rate"),
        labelRes = R.string.metric_respiratory,
        unitRes = R.string.unit_breaths_per_minute,
        decimals = 0,
        validMin = 4f,
        validMax = 60f,
        valueKeys =
            listOf(
                "breath_rate",
                "respiratory_rate",
                "average",
                "com.samsung.health.respiratory_rate.breath_rate",
            ),
    ),
    HRV(
        moduleKeys = listOf("com.samsung.health.hrv", "com.samsung.shealth.hrv"),
        labelRes = R.string.metric_hrv,
        unitRes = R.string.unit_milliseconds,
        decimals = 0,
        validMin = 1f,
        validMax = 300f,
        valueKeys =
            listOf("rmssd", "sdnn", "com.samsung.health.hrv.rmssd", "com.samsung.health.hrv.sdnn"),
    );

    fun readings(record: JSONObject): List<Pair<String, Float>> {
        val values =
            valueKeys.mapNotNull { key ->
                if (!record.has(key) || record.isNull(key)) return@mapNotNull null
                val raw = record.optDouble(key, Double.NaN)
                if (!raw.isFinite() || raw < validMin || raw > validMax) null
                else key to raw.toFloat()
            }
        return if (this == HRV) values.distinctBy { it.first.substringAfterLast('.') }
        else values.take(1)
    }

    fun valueOf(record: JSONObject): Float? = readings(record).firstOrNull()?.second

    fun format(value: Float): String =
        if (decimals == 0) "%.0f".format(value) else "%.${decimals}f".format(value)
}

object HealthMetricLog {

    data class Sample(val ts: Long, val value: Float)

    data class Stats(val min: Float, val avg: Float, val max: Float, val count: Int) {
        fun format(metric: HealthMetric, value: Float): String = metric.format(value)
    }

    data class Daily(val samples: List<Sample>, val stats: Stats?)

    fun daily(samples: List<Sample>, day: LocalDate, zone: ZoneId = ZoneId.systemDefault()): Daily {
        val selected = onDay(samples, day, zone)
        return Daily(selected, stats(selected))
    }

    private fun tsOf(record: JSONObject): Long =
        listOf(
                "start_time",
                "com.samsung.health.oxygen_saturation.start_time",
                "com.samsung.health.skin_temperature.start_time",
                "com.samsung.health.respiratory_rate.start_time",
                "com.samsung.health.hrv.start_time",
                "create_time",
                "update_time",
            )
            .firstNotNullOfOrNull { key -> record.optLong(key, 0L).takeIf { it > 0L } } ?: 0L

    fun samples(metric: HealthMetric, records: List<JSONObject>): List<Sample> =
        records.flatMap { record ->
            val bins =
                HealthJson.array(record.opt("binning_data"))
                    ?: HealthJson.array(record.opt("binning"))
            val detail =
                if (bins == null) emptyList()
                else
                    (0 until bins.length()).mapNotNull { i ->
                        val item = bins.optJSONObject(i) ?: return@mapNotNull null
                        val ts = tsOf(item)
                        val value = metric.valueOf(item)
                        if (ts <= 0 || value == null) null else Sample(ts, value)
                    }
            if (detail.isNotEmpty()) detail
            else {
                val ts = tsOf(record)
                val value = metric.valueOf(record)
                if (ts <= 0L || value == null) emptyList() else listOf(Sample(ts, value))
            }
        }

    /** 保留最近 [keepDays] 天、最多 [cap] 个点，按时间去重排序 */
    fun merge(
        existing: List<Sample>,
        incoming: List<Sample>,
        nowMillis: Long,
        keepDays: Int = 7,
        cap: Int = 6000,
    ): List<Sample> {
        val cutoff = nowMillis - keepDays * 24L * 3_600_000L
        return (existing + incoming)
            .filter { it.ts in cutoff..nowMillis }
            .associateBy { it.ts }
            .values
            .sortedBy { it.ts }
            .takeLast(cap)
    }

    fun stats(samples: List<Sample>): Stats? {
        if (samples.isEmpty()) return null
        val values = samples.map { it.value }
        return Stats(
            min = values.min(),
            avg = (values.sum() / values.size),
            max = values.max(),
            count = values.size,
        )
    }

    fun latest(samples: List<Sample>): Sample? = samples.maxByOrNull { it.ts }

    fun dayOf(ts: Long, zone: ZoneId = ZoneId.systemDefault()): String =
        runCatching { Instant.ofEpochMilli(ts).atZone(zone).toLocalDate().toString() }
            .getOrDefault("")

    fun onDay(
        samples: List<Sample>,
        day: LocalDate,
        zone: ZoneId = ZoneId.systemDefault(),
    ): List<Sample> = samples.filter { dayOf(it.ts, zone) == day.toString() }.sortedBy { it.ts }

    /** 最近 7 天每日均值（升序，缺数据为 null） */
    fun weekly(
        samples: List<Sample>,
        today: LocalDate,
        zone: ZoneId = ZoneId.systemDefault(),
    ): List<Float?> =
        (6 downTo 0).map { offset ->
            val day = today.minusDays(offset.toLong())
            stats(onDay(samples, day, zone))?.avg
        }

    fun encode(samples: List<Sample>): String {
        val array = JSONArray()
        samples.forEach { array.put(JSONArray().put(it.ts).put(it.value.toDouble())) }
        return array.toString()
    }

    fun decode(raw: String?): List<Sample> {
        if (raw.isNullOrBlank()) return emptyList()
        val array = runCatching { JSONArray(raw) }.getOrNull() ?: return emptyList()
        return (0 until array.length()).mapNotNull { index ->
            val item = array.optJSONArray(index) ?: return@mapNotNull null
            val ts = item.optLong(0)
            val value = item.optDouble(1, Double.NaN)
            if (ts <= 0L || value.isNaN()) null else Sample(ts, value.toFloat())
        }
    }

    /** 从报文里按指标抓取对应模块的记录 */
    fun recordsFor(metric: HealthMetric, chunks: Map<String, List<JSONObject>>): List<JSONObject> =
        metric.moduleKeys.flatMap { chunks[it].orEmpty() }
}

/** 楼层：手表按区间上报 `floor_count`，当日累计需要用 `datauuid` 去重后逐个相加。 */
object FloorsLog {

    private fun tsOf(record: JSONObject): Long =
        listOf(
                "start_time",
                "com.samsung.health.floors_climbed.start_time",
                "create_time",
                "update_time",
            )
            .firstNotNullOfOrNull { key -> record.optLong(key, 0L).takeIf { it > 0L } } ?: 0L

    private fun countOf(record: JSONObject): Int? =
        listOf(
                "floor_count",
                "com.samsung.health.floors_climbed.floor_count",
                "floor",
                "count",
                "floors",
            )
            .firstNotNullOfOrNull { key ->
                if (!record.has(key) || record.isNull(key)) null
                else
                    record
                        .optDouble(key, Double.NaN)
                        .takeIf { it.isFinite() && it in 0.0..500.0 }
                        ?.toInt()
            }

    fun identityOf(record: JSONObject): String {
        val uuid =
            record.optString(
                "datauuid",
                record.optString("com.samsung.health.floors_climbed.datauuid"),
            )
        if (uuid.isNotBlank()) return uuid
        return "t_" + tsOf(record) + "_" + (countOf(record)?.toString() ?: "unknown")
    }

    /** null 表示今天没有有效测量，明确的 0 仍为有效测量。 */
    fun todayTotal(
        records: List<JSONObject>,
        nowMillis: Long,
        zone: ZoneId = ZoneId.systemDefault(),
    ): Int? {
        var total = 0
        var measured = false
        val seen = linkedSetOf<String>()
        records.forEach { record ->
            val ts = tsOf(record)
            if (ts <= 0L || !HealthStepParser.isSameLocalDay(ts, nowMillis, zone)) return@forEach
            val count = countOf(record) ?: return@forEach
            if (!seen.add(identityOf(record))) return@forEach
            measured = true
            total += count
        }
        return total.takeIf { measured }
    }

    /** 累加当日楼层。只接受今天的记录，已计入的记录身份写入 [seen]。 */
    fun accumulate(
        current: Int,
        seen: MutableSet<String>,
        records: List<JSONObject>,
        nowMillis: Long,
        zone: ZoneId = ZoneId.systemDefault(),
    ): Int {
        var total = current
        records.forEach { record ->
            val ts = tsOf(record)
            if (ts <= 0L || !HealthStepParser.isSameLocalDay(ts, nowMillis, zone)) return@forEach
            val count = countOf(record) ?: return@forEach
            if (!seen.add(identityOf(record))) return@forEach
            total += count
        }
        return total
    }

    fun trimSeen(seen: LinkedHashSet<String>, keep: Int = 300, limit: Int = 400) {
        if (seen.size <= limit) return
        val iterator = seen.iterator()
        while (seen.size > keep && iterator.hasNext()) {
            iterator.next()
            iterator.remove()
        }
    }
}
