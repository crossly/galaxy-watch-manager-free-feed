package dev.ricky.galaxywatchmanagerfree.wcs

import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.util.Base64
import org.json.JSONArray
import org.json.JSONObject

/** Only sources with a complete retained copy may expose replication cursors. */
class WearDataSnapshot(
    private val maxItems: Int = MAX_ITEMS,
    private val maxBytes: Int = MAX_TOTAL_BYTES,
) {
    companion object {
        const val MAX_ITEMS = 10_000
        const val MAX_TOTAL_BYTES = 8 * 1024 * 1024
        const val MAX_ENCODED_BYTES = 16 * 1024 * 1024
        private const val MAX_SOURCE_CHARS = 256 * 1024
        private const val SCHEMA = 2
        private const val LEGACY_SCHEMA = 1

        /** Over-limit files require a full sync instead of an unbounded allocation. */
        fun readEncoded(input: InputStream, limit: Int = MAX_ENCODED_BYTES): String? {
            require(limit > 0) { "limit must be positive" }
            val output = ByteArrayOutputStream(minOf(limit, 64 * 1024))
            val buffer = ByteArray(16 * 1024)
            var total = 0
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                if (read == 0) continue
                total += read
                if (total > limit) return null
                output.write(buffer, 0, read)
            }
            return output.toByteArray().toString(Charsets.UTF_8)
        }
    }

    private data class Entry(
        val key: String,
        val envelope: ByteArray,
        val source: String,
        val sequence: Long,
        val deleted: Boolean,
    )

    private val items = linkedMapOf<String, Entry>()
    private val highestSequences = linkedMapOf<String, Long>()
    private val completeCursors = linkedMapOf<String, Long>()
    private val incomplete = linkedSetOf<String>()
    private var totalBytes = 0
    private var sourceChars = 0
    private var fullSyncRequired = false

    init {
        require(maxItems > 0) { "maxItems must be positive" }
        require(maxBytes > 0) { "maxBytes must be positive" }
    }

    @Synchronized
    fun accept(envelope: ByteArray): Boolean {
        val item = WcsFrame.decode(envelope) as? WcsFrame.Incoming.WearPath ?: return false
        val source = item.sourceNode?.takeIf { it.isNotBlank() } ?: return false
        val sequence = item.sequence?.takeIf { it >= 0 } ?: return false
        val key = "${item.senderPkg}|${item.path}"
        val previous = items[key]
        if (previous?.source == source && sequence < previous.sequence) return false
        // Full dumps can replay older revisions for keys missing from an incomplete source.
        if (
            previous == null &&
                source !in incomplete &&
                sequence < (highestSequences[source] ?: -1L)
        )
            return false

        if (rememberSource(source)) {
            highestSequences[source] = maxOf(highestSequences[source]!!, sequence)
        }
        if (previous != null) removeEntry(key)
        if (envelope.size > maxBytes) {
            markIncomplete(source)
            return true
        }
        items[key] = Entry(key, envelope.copyOf(), source, sequence, item.deleted)
        totalBytes += envelope.size
        if (!fullSyncRequired && source !in incomplete) {
            completeCursors[source] = highestSequences[source]!!
        }
        evictForLimits(incomingSource = source, incomingKey = key)
        return true
    }

    private fun evictForLimits(incomingSource: String, incomingKey: String) {
        while (items.size > maxItems || totalBytes > maxBytes) {
            val victim =
                items.entries.firstOrNull { it.value.deleted && it.key != incomingKey }
                    ?: items.entries.firstOrNull {
                        (fullSyncRequired || it.value.source in incomplete) && it.key != incomingKey
                    }
                    ?: items.entries.firstOrNull {
                        it.value.source == incomingSource && it.key != incomingKey
                    }
                    ?: items.entries.firstOrNull { it.key != incomingKey }
                    ?: return
            removeEntry(victim.key)
            if (!victim.value.deleted) markIncomplete(victim.value.source)
        }
    }

    private fun removeEntry(key: String) {
        val removed = items.remove(key) ?: return
        totalBytes -= removed.envelope.size
    }

    private fun rememberSource(source: String): Boolean {
        if (fullSyncRequired) return false
        if (source in highestSequences) return true
        if (highestSequences.size >= MAX_ITEMS || source.length > MAX_SOURCE_CHARS - sourceChars) {
            requireFullSync()
            return false
        }
        sourceChars += source.length
        highestSequences[source] = -1L
        return true
    }

    private fun requireFullSync() {
        fullSyncRequired = true
        highestSequences.clear()
        completeCursors.clear()
        incomplete.clear()
        sourceChars = 0
    }

    private fun markIncomplete(source: String) {
        if (!rememberSource(source)) return
        completeCursors.remove(source)
        incomplete.add(source)
    }

    @Synchronized
    fun cursors(): Map<String, Long> = completeCursors.filterKeys { it !in incomplete }.toMap()

    @Synchronized
    fun incompleteSources(): Set<String> =
        if (fullSyncRequired) items.values.mapTo(linkedSetOf()) { it.source }
        else incomplete.toSet()

    @Synchronized fun envelopes(): List<ByteArray> = items.values.map { it.envelope.copyOf() }

    @Synchronized fun storedBytes(): Long = totalBytes.toLong()

    @Synchronized
    fun encode(): String {
        val itemArray =
            JSONArray(items.values.map { Base64.getEncoder().encodeToString(it.envelope) })
        val cursorArray =
            JSONArray(
                completeCursors
                    .filterKeys { it !in incomplete }
                    .map { (source, sequence) ->
                        JSONObject().put("source", source).put("sequence", sequence)
                    }
            )
        return JSONObject()
            .put("schema", SCHEMA)
            .put("items", itemArray)
            .put("cursors", cursorArray)
            .put("incomplete", JSONArray(incomplete.toList()))
            .put("full_sync", fullSyncRequired)
            .toString()
    }

    /** Restores a snapshot atomically; malformed or over-budget input leaves an empty store. */
    @Synchronized
    fun restore(encoded: String?): Boolean {
        clearState()
        if (encoded.isNullOrEmpty() || encoded.length > MAX_ENCODED_BYTES) return false
        val restored =
            runCatching {
                    val json = JSONObject(encoded)
                    when (json.opt("schema")) {
                        LEGACY_SCHEMA -> restoreLegacy(json)
                        SCHEMA -> restoreCurrent(json)
                        else -> false
                    }
                }
                .getOrDefault(false)
        if (!restored) clearState()
        return restored
    }

    // Schema 1 may have silently pruned items, so none of its cursors are trusted.
    private fun restoreLegacy(json: JSONObject): Boolean {
        val array = json.optJSONArray("items") ?: return false
        val start = maxOf(0, array.length() - maxItems)
        val loaded = ArrayList<Entry>(array.length() - start)
        var bytes = 0
        val keys = HashSet<String>()
        for (index in start until array.length()) {
            val entry = decodeEntry(array.optString(index)) ?: return false
            if (!keys.add(entry.key)) return false
            bytes += entry.envelope.size
            if (bytes > maxBytes) return false
            loaded.add(entry)
        }
        applyEntries(loaded)
        highestSequences.keys.forEach { incomplete.add(it) }
        return true
    }

    private fun restoreCurrent(json: JSONObject): Boolean {
        val array = json.optJSONArray("items") ?: return false
        if (array.length() > maxItems) return false
        val loaded = ArrayList<Entry>(array.length())
        var bytes = 0
        val keys = HashSet<String>()
        for (index in 0 until array.length()) {
            val entry = decodeEntry(array.optString(index)) ?: return false
            if (!keys.add(entry.key)) return false
            bytes += entry.envelope.size
            if (bytes > maxBytes) return false
            loaded.add(entry)
        }
        applyEntries(loaded)
        val fullSync = json.opt("full_sync")
        if (fullSync != null && fullSync !is Boolean) return false
        if (fullSync == true) requireFullSync()

        val cursorArray = json.optJSONArray("cursors") ?: return false
        if (cursorArray.length() > MAX_ITEMS) return false
        for (index in 0 until cursorArray.length()) {
            val cursor = cursorArray.optJSONObject(index) ?: return false
            val source =
                (cursor.opt("source") as? String)?.takeIf { it.isNotBlank() } ?: return false
            val sequence =
                when (val value = cursor.opt("sequence")) {
                    is Int -> value.toLong()
                    is Long -> value
                    else -> return false
                }
            if (sequence < 0 || sequence < (highestSequences[source] ?: -1L)) return false
            if (rememberSource(source)) {
                if (completeCursors.put(source, sequence) != null) return false
                highestSequences[source] = sequence
            }
        }
        val incompleteArray = json.optJSONArray("incomplete") ?: return false
        if (incompleteArray.length() > MAX_ITEMS) return false
        for (index in 0 until incompleteArray.length()) {
            val source =
                (incompleteArray.opt(index) as? String)?.takeIf { it.isNotBlank() } ?: return false
            markIncomplete(source)
        }
        // Items without explicit completeness metadata cannot justify an incremental cursor.
        highestSequences.keys.filterNot { it in completeCursors }.forEach { incomplete.add(it) }
        completeCursors.keys.removeAll(incomplete)
        return true
    }

    private fun decodeEntry(encoded: String): Entry? {
        val envelope =
            runCatching { Base64.getDecoder().decode(encoded) }.getOrNull() ?: return null
        val item = WcsFrame.decode(envelope) as? WcsFrame.Incoming.WearPath ?: return null
        val source = item.sourceNode?.takeIf { it.isNotBlank() } ?: return null
        val sequence = item.sequence?.takeIf { it >= 0 } ?: return null
        return Entry(
            key = "${item.senderPkg}|${item.path}",
            envelope = envelope,
            source = source,
            sequence = sequence,
            deleted = item.deleted,
        )
    }

    private fun applyEntries(entries: List<Entry>) {
        clearState()
        entries.forEach { entry ->
            items[entry.key] = entry
            totalBytes += entry.envelope.size
            if (rememberSource(entry.source)) {
                highestSequences[entry.source] =
                    maxOf(highestSequences[entry.source]!!, entry.sequence)
            }
        }
    }

    private fun clearState() {
        items.clear()
        highestSequences.clear()
        completeCursors.clear()
        incomplete.clear()
        totalBytes = 0
        sourceChars = 0
        fullSyncRequired = false
    }
}
