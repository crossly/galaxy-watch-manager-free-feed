package dev.ricky.galaxywatchmanagerfree.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.feature.HealthGoals
import dev.ricky.galaxywatchmanagerfree.ui.components.AppBottomSheet
import dev.ricky.galaxywatchmanagerfree.ui.theme.CardBorder
import dev.ricky.galaxywatchmanagerfree.ui.theme.CardSurface
import dev.ricky.galaxywatchmanagerfree.ui.theme.ElectricBlue
import dev.ricky.galaxywatchmanagerfree.ui.theme.HealthSteps
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextPrimary
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextSecondary
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextTertiary

/**
 * 每日步数目标设置。
 *
 * 取值范围与 Samsung Health 的每日活动目标一致：1,000～50,000 步、100 步进。 保存后只影响本机的进度展示，不会回写手表设置。
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StepGoalSheet(
    current: Int,
    canReset: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (Int) -> Unit,
    onReset: () -> Unit,
) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var value by rememberSaveable { mutableIntStateOf(HealthGoals.normalize(current)) }

    AppBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        centerInWideWindow = true,
    ) {
        Column(
            modifier =
                Modifier.fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp)
                    .padding(top = 22.dp, bottom = 28.dp)
        ) {
            Text(
                strings.getString(R.string.daily_step_goal),
                style = androidx.compose.material3.MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                strings.getString(R.string.used_for_daily_progress_and_goal_streaks),
                style = androidx.compose.material3.MaterialTheme.typography.labelMedium,
                color = TextTertiary,
            )

            Spacer(modifier = Modifier.height(18.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    text = "%,d".format(value),
                    style = androidx.compose.material3.MaterialTheme.typography.displayLarge,
                    fontWeight = FontWeight.Bold,
                    color = HealthSteps,
                    fontFamily = FontFamily.Monospace,
                )
                Text(
                    text = strings.getString(R.string.steps_2),
                    style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    modifier = Modifier.padding(bottom = 8.dp),
                )
            }

            Slider(
                value = value.toFloat(),
                onValueChange = { value = HealthGoals.normalize(it.toInt()) },
                valueRange =
                    HealthGoals.MIN_STEP_GOAL.toFloat()..HealthGoals.MAX_STEP_GOAL.toFloat(),
                steps =
                    (HealthGoals.MAX_STEP_GOAL - HealthGoals.MIN_STEP_GOAL) /
                        HealthGoals.STEP_INCREMENT - 1,
                colors =
                    SliderDefaults.colors(
                        thumbColor = HealthSteps,
                        activeTrackColor = HealthSteps,
                        inactiveTrackColor = CardBorder,
                    ),
                modifier = Modifier.padding(top = 6.dp),
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(
                    "1,000",
                    style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                    color = TextTertiary,
                    fontFamily = FontFamily.Monospace,
                )
                Text(
                    "50,000",
                    style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                    color = TextTertiary,
                    fontFamily = FontFamily.Monospace,
                )
            }

            Spacer(modifier = Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                HealthGoals.PRESETS.forEach { preset ->
                    val selected = preset == value
                    Box(
                        modifier =
                            Modifier.weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(
                                    if (selected) HealthSteps.copy(alpha = 0.16f) else CardSurface
                                )
                                .border(
                                    1.dp,
                                    if (selected) HealthSteps.copy(alpha = 0.5f) else CardBorder,
                                    RoundedCornerShape(10.dp),
                                )
                                .clickable { value = preset }
                                .padding(vertical = 9.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            text =
                                if (preset >= 1000) "%,d".format(preset / 1000) + "k"
                                else "$preset",
                            style = androidx.compose.material3.MaterialTheme.typography.labelMedium,
                            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                            color = if (selected) HealthSteps else TextSecondary,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (canReset) {
                    Box(
                        modifier =
                            Modifier.clip(RoundedCornerShape(12.dp))
                                .border(1.dp, CardBorder, RoundedCornerShape(12.dp))
                                .clickable { onReset() }
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            strings.getString(R.string.use_watch_goal),
                            style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        )
                    }
                }
                Box(
                    modifier =
                        Modifier.weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(ElectricBlue)
                            .clickable { onConfirm(value) }
                            .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        strings.getString(R.string.save),
                        style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        color = androidx.compose.material3.MaterialTheme.colorScheme.onPrimary,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    )
                }
            }
        }
    }
}
