package dev.ricky.galaxywatchmanagerfree.ui.components

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

/** Keep the curve within each pair of readings so smoothing cannot invent extrema. */
internal fun smoothChartPath(points: List<Offset>): Path =
    Path().apply {
        if (points.isNotEmpty()) {
            moveTo(points.first().x, points.first().y)
            for (index in 0 until points.lastIndex) {
                val current = points[index]
                val next = points[index + 1]
                val middleX = (current.x + next.x) / 2f
                cubicTo(middleX, current.y, middleX, next.y, next.x, next.y)
            }
        }
    }

internal fun DrawScope.drawReadingCurve(
    points: List<Offset>,
    color: Color,
    baseline: Float,
    selectedIndex: Int?,
) {
    if (points.isEmpty()) return
    val path = smoothChartPath(points)
    if (points.size > 1) {
        val area =
            Path().apply {
                addPath(path)
                lineTo(points.last().x, baseline)
                lineTo(points.first().x, baseline)
                close()
            }
        drawPath(
            area,
            Brush.verticalGradient(
                listOf(color.copy(alpha = 0.32f), color.copy(alpha = 0.015f)),
                startY = 0f,
                endY = baseline,
            ),
        )
        drawPath(path, color, style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round))
    }
    if (points.size <= 48) {
        points.forEach { drawCircle(color.copy(alpha = 0.78f), 2.dp.toPx(), it) }
    }
    selectedIndex
        ?.let { points.getOrNull(it) }
        ?.let { point ->
            drawLine(
                color.copy(alpha = 0.5f),
                Offset(point.x, 0f),
                Offset(point.x, baseline),
                strokeWidth = 1.2.dp.toPx(),
            )
            drawCircle(color.copy(alpha = 0.24f), 6.dp.toPx(), point)
            drawCircle(color, 3.6.dp.toPx(), point)
        }
}
