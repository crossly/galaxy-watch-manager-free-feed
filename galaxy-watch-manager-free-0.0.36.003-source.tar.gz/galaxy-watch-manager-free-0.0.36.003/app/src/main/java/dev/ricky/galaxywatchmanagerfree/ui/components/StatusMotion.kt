package dev.ricky.galaxywatchmanagerfree.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.currentStateAsState
import kotlin.math.*

/** Only compose repeating transitions while their status is active and the screen is visible. */
@Composable
private fun motionEnabled(active: Boolean): Boolean {
    val lifecycle by LocalLifecycleOwner.current.lifecycle.currentStateAsState()
    return active &&
        lifecycle.isAtLeast(Lifecycle.State.STARTED) &&
        android.animation.ValueAnimator.areAnimatorsEnabled()
}

@Composable
fun StatusOrb(icon: ImageVector, color: Color, active: Boolean, modifier: Modifier = Modifier) {
    val enabled = motionEnabled(active)
    val rotation =
        if (enabled) {
            val transition = rememberInfiniteTransition(label = "StatusMotion")
            val phase by
                transition.animateFloat(
                    0f,
                    360f,
                    infiniteRepeatable(tween(6_000, easing = LinearEasing)),
                    label = "StatusRotation",
                )
            phase
        } else 0f
    Box(modifier.size(56.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val radius = size.minDimension / 2
            val shape =
                Path().apply {
                    for (i in 0..120) {
                        val angle = i * 2 * PI / 120
                        val r = radius * (0.9f + 0.09f * cos(6 * angle).toFloat())
                        val x = center.x + r * cos(angle).toFloat()
                        val y = center.y + r * sin(angle).toFloat()
                        if (i == 0) moveTo(x, y) else lineTo(x, y)
                    }
                    close()
                }
            rotate(rotation) { drawPath(shape, color.copy(alpha = if (active) 0.2f else 0.12f)) }
        }
        Icon(icon, null, tint = color, modifier = Modifier.size(27.dp))
    }
}

/** A moving highlight over the real charge level. It is never shown while discharging. */
@Composable
fun ChargeProgress(
    progress: Float,
    charging: Boolean,
    color: Color,
    track: Color,
    modifier: Modifier = Modifier,
    height: Dp = 12.dp,
) {
    val moving = motionEnabled(charging)
    val phase =
        if (moving) {
            val transition = rememberInfiniteTransition(label = "Charging")
            val value by
                transition.animateFloat(
                    -0.3f,
                    1.3f,
                    infiniteRepeatable(tween(1_800, easing = LinearEasing)),
                    label = "ChargingSweep",
                )
            value
        } else -1f
    Box(modifier.fillMaxWidth().height(height).clip(CircleShape).background(track)) {
        Canvas(Modifier.fillMaxWidth(progress.coerceIn(0f, 1f)).fillMaxHeight()) {
            drawRect(color)
            if (moving) {
                val x = phase * size.width
                drawRect(
                    Brush.linearGradient(
                        listOf(
                            Color.Transparent,
                            Color.White.copy(alpha = 0.65f),
                            Color.Transparent,
                        ),
                        start = androidx.compose.ui.geometry.Offset(x - size.width * 0.2f, 0f),
                        end =
                            androidx.compose.ui.geometry.Offset(x + size.width * 0.2f, size.height),
                    )
                )
            }
        }
    }
}
