/*
 * Adapted from chen08209/FlClash lib/ui/navigation_dock.dart, commit
 * 7fd417fb9a9a277c6a9339a8ac87f907df7c25f7. GPL-3.0-only.
 * Android adaptation: Compose pointer events, springs and accessibility semantics.
 * See assets/licenses/FLCLASH-NOTICE.txt.
 */
package dev.ricky.galaxywatchmanagerfree.ui.components

import android.os.Build
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.ricky.galaxywatchmanagerfree.ui.HomeTab
import dev.ricky.galaxywatchmanagerfree.ui.theme.SurfaceDark
import kotlin.math.abs
import kotlinx.coroutines.flow.first

/** FLClash's mobile dock: preview on press/drag, commit once on release. */
@Composable
fun FloatingNavigationBar(
    currentTab: HomeTab,
    onTabSelected: (HomeTab) -> Unit,
    navigationHeight: Dp,
    bottomInset: Dp,
    glassEffect: Boolean,
    backdrop: LiquidGlassBackdrop,
    modifier: Modifier = Modifier,
) {
    val dark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
    val shape = RoundedCornerShape(50)
    Box(
        modifier
            .fillMaxWidth()
            .padding(start = 21.dp, end = 21.dp, top = 8.dp, bottom = bottomInset),
        contentAlignment = Alignment.Center,
    ) {
        BoxWithConstraints(
            Modifier.widthIn(max = 360.dp)
                .fillMaxWidth()
                .testTag("tag_navigation_floating")
                .height(navigationHeight)
                .shadow(
                    10.dp,
                    shape,
                    clip = false,
                    ambientColor = Color.Black.copy(alpha = 0.08f),
                    spotColor = Color.Black.copy(alpha = 0.12f),
                )
        ) {
            val itemWidth = (maxWidth - 8.dp) / HomeTab.entries.size
            val itemHeight = maxHeight - 8.dp
            if (glassEffect) {
                LiquidGlassDock(backdrop, dark, Modifier.fillMaxSize()) { dockBackdrop ->
                    DockDestinations(
                        currentTab,
                        onTabSelected,
                        itemWidth,
                        itemHeight,
                        dark,
                        glassEffect,
                        dockBackdrop,
                    )
                }
            } else {
                Box(Modifier.fillMaxSize().background(SurfaceDark, shape)) {
                    DockDestinations(
                        currentTab,
                        onTabSelected,
                        itemWidth,
                        itemHeight,
                        dark,
                        glassEffect,
                        null,
                    )
                }
            }
        }
    }
}

@Composable
private fun DockDestinations(
    currentTab: HomeTab,
    onTabSelected: (HomeTab) -> Unit,
    itemWidth: Dp,
    itemHeight: Dp,
    dark: Boolean,
    glass: Boolean,
    backdrop: LiquidGlassBackdrop?,
) {
    val strings = LocalContext.current.resources
    val density = LocalDensity.current
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    val haptics = LocalHapticFeedback.current
    val onSelect by rememberUpdatedState(onTabSelected)
    val pitchPx = with(density) { itemWidth.toPx() }
    val paddingPx = with(density) { 4.dp.toPx() }
    val geometry = remember(pitchPx, rtl) { DockGeometry(pitchPx, HomeTab.entries.size, rtl) }
    var pressedPosition by remember { mutableStateOf<Float?>(null) }
    var pressSequence by remember { mutableIntStateOf(0) }
    val lift = remember { Animatable(0f) }
    // A short tap still completes the lift before it falls, as FLClash's _dropLift does.
    LaunchedEffect(pressSequence) {
        if (pressSequence == 0) return@LaunchedEffect
        lift.animateTo(1f, spring(dampingRatio = 0.78f, stiffness = 650f))
        snapshotFlow { pressedPosition == null }.first { it }
        lift.animateTo(0f, spring(dampingRatio = 0.82f, stiffness = 300f))
    }
    val targetPosition = pressedPosition ?: currentTab.ordinal.toFloat()
    val position by
        animateFloatAsState(
            targetPosition,
            spring(
                dampingRatio = if (pressedPosition != null) 0.92f else 0.78f,
                stiffness = if (pressedPosition != null) 1800f else 420f,
            ),
            label = "DockLensPosition",
        )
    val raised = lift.value.coerceIn(0f, 1f)
    val jelly = (abs(targetPosition - position) * 0.08f).coerceAtMost(0.12f) * raised
    val lensWidth = (itemWidth - 4.dp + 8.dp * raised) * (1f + jelly)
    val lensHeight = (itemHeight - 4.dp + 8.dp * raised) * (1f - jelly * 0.6f)
    val lensX = itemWidth * (position + 0.5f) - lensWidth / 2
    val lensY = (itemHeight - lensHeight) / 2
    val highlighted = geometry.indexAt(pressedPosition ?: currentTab.ordinal.toFloat())
    val shape = RoundedCornerShape(50)
    val contentBackdrop = rememberLiquidGlassBackdrop()
    val refractContent =
        glass && raised > 0.001f && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
    val cutout =
        if (refractContent)
            with(density) {
                val left =
                    if (rtl)
                        itemWidth.toPx() * HomeTab.entries.size - lensX.toPx() - lensWidth.toPx()
                    else lensX.toPx()
                RoundRect(
                    left,
                    lensY.toPx(),
                    left + lensWidth.toPx(),
                    lensY.toPx() + lensHeight.toPx(),
                    lensHeight.toPx() / 2f,
                    lensHeight.toPx() / 2f,
                )
            }
        else null

    Box(
        Modifier.fillMaxSize()
            .pointerInput(geometry, paddingPx) {
                awaitEachGesture {
                    val down = awaitFirstDown(pass = PointerEventPass.Initial)
                    down.consume()
                    val tracker = VelocityTracker()
                    tracker.addPosition(down.uptimeMillis, down.position)
                    val initialX = down.position.x
                    var dragging = false
                    var lastIndex = geometry.indexAt(geometry.positionAt(initialX - paddingPx))
                    pressedPosition = lastIndex.toFloat()
                    pressSequence++
                    try {
                        while (true) {
                            val event = awaitPointerEvent(PointerEventPass.Initial)
                            val change = event.changes.firstOrNull { it.id == down.id } ?: break
                            if (change.isConsumed) break
                            tracker.addPosition(change.uptimeMillis, change.position)
                            if (!change.pressed) {
                                val index =
                                    geometry.releaseIndex(
                                        pressedPosition ?: lastIndex.toFloat(),
                                        tracker.calculateVelocity().x,
                                        lastIndex,
                                        dragging,
                                    )
                                change.consume()
                                onSelect(HomeTab.entries[index])
                                break
                            }
                            if (abs(change.position.x - initialX) >= viewConfiguration.touchSlop) {
                                dragging = true
                            }
                            if (dragging) {
                                val next = geometry.positionAt(change.position.x - paddingPx)
                                val index = geometry.indexAt(next)
                                if (index != lastIndex) {
                                    haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    lastIndex = index
                                }
                                pressedPosition = next
                            }
                            change.consume()
                        }
                    } finally {
                        // Cancellation restores the committed page without navigating.
                        pressedPosition = null
                    }
                }
            }
            .padding(4.dp)
    ) {
        Box(
            Modifier.offset { IntOffset(lensX.roundToPx(), lensY.roundToPx()) }
                .wrapContentSize(Alignment.TopStart, unbounded = true)
                .requiredSize(lensWidth, lensHeight)
                .testTag("tag_navigation_lens")
                .shadow(3.dp * raised, shape, clip = false)
        ) {
            if (glass && backdrop != null) {
                LiquidGlassLens(backdrop, dark, raised, Modifier.fillMaxSize())
            } else {
                Box(
                    Modifier.fillMaxSize()
                        .clip(shape)
                        .background(
                            if (dark) MaterialTheme.colorScheme.surfaceContainerHighest
                            else MaterialTheme.colorScheme.surfaceContainer
                        )
                )
            }
        }
        Row(
            Modifier.fillMaxSize()
                .then(
                    if (refractContent) Modifier.liquidGlassSource(contentBackdrop, cutout)
                    else Modifier
                )
        ) {
            HomeTab.entries.forEach { tab ->
                val selected = currentTab == tab
                val color by
                    animateColorAsState(
                        if (highlighted == tab.ordinal) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.onSurfaceVariant,
                        label = "DockDestinationColor",
                    )
                Column(
                    Modifier.weight(1f)
                        .fillMaxHeight()
                        .clip(shape)
                        .testTag("tag_nav_${tab.name}")
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            role = Role.Tab,
                        ) {
                            pressSequence++
                            onSelect(tab)
                        }
                        .semantics(mergeDescendants = true) {
                            this.selected = selected
                            role = Role.Tab
                        },
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(tab.icon, null, tint = color, modifier = Modifier.size(26.dp))
                        Text(
                            strings.getString(tab.titleRes),
                            style = MaterialTheme.typography.labelSmall,
                            lineHeight = 14.sp,
                            color = color,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                            textAlign = TextAlign.Center,
                        )
                    }
                }
            }
        }
        if (refractContent) {
            LiquidGlassLensContent(
                contentBackdrop,
                dark,
                raised,
                Modifier.offset { IntOffset(lensX.roundToPx(), lensY.roundToPx()) }
                    .wrapContentSize(Alignment.TopStart, unbounded = true)
                    .requiredSize(lensWidth, lensHeight),
            )
        }
    }
}
