package dev.ricky.galaxywatchmanagerfree.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.core.UiNotify
import dev.ricky.galaxywatchmanagerfree.feature.WatchRepository
import dev.ricky.galaxywatchmanagerfree.feature.WatchState
import dev.ricky.galaxywatchmanagerfree.feature.monitor.BpCalibrationStatus
import dev.ricky.galaxywatchmanagerfree.feature.monitor.HealthMonitorProtocol
import dev.ricky.galaxywatchmanagerfree.feature.monitor.HealthMonitorSession
import dev.ricky.galaxywatchmanagerfree.ui.theme.AlertCrimson
import dev.ricky.galaxywatchmanagerfree.ui.theme.HealthBloodPressure
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextSecondary
import kotlinx.coroutines.delay
import org.json.JSONObject

@Composable
fun BpCalibrationCard(state: WatchState, repo: WatchRepository) {
    val context = LocalContext.current
    val strings = context.resources
    val lifecycleOwner = LocalLifecycleOwner.current
    val information = state.monitorState.information[HealthMonitorProtocol.Channel.BP]
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var clockRevision by remember { mutableIntStateOf(0) }
    val calibrationStatus = BpCalibrationStatus.from(information, now)
    val busy = state.monitorState.bpInformationPending || state.monitorState.bpSyncPending

    // A completed watch calibration uploads data over the BP channel. On return, query the
    // watch-owned calibration state and retained records without involving a phone SHM app.
    LaunchedEffect(repo, state.sessionReady, lifecycleOwner) {
        if (state.sessionReady) {
            lifecycleOwner.lifecycle.repeatOnLifecycle(Lifecycle.State.RESUMED) {
                repo.monitor.reviewBp()
            }
        }
    }
    LaunchedEffect(information, clockRevision) {
        now = System.currentTimeMillis()
        val calibratedAt =
            information?.let {
                runCatching { JSONObject(it).optLong("calibration_time") }.getOrNull()
            }
        val expiry = calibratedAt?.let(BpCalibrationStatus::expiryTime)
        if (expiry != null && expiry > now) {
            delay(expiry - now)
            now = System.currentTimeMillis()
        }
    }
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) clockRevision++
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    fun requestAction(action: () -> Boolean, successMessage: Int, longMessage: Boolean = false) {
        when {
            !state.sessionReady -> UiNotify.show(R.string.watch_disconnected)
            action() -> {
                if (state.monitorState.connection != HealthMonitorSession.Connection.READY) {
                    repo.monitor.connect()
                }
                UiNotify.show(successMessage, long = longMessage)
            }
            else -> {
                repo.monitor.connect()
                UiNotify.show(R.string.request_not_sent_check_the_watch_connection)
            }
        }
    }

    fun startWatchCalibration() {
        when {
            !state.sessionReady -> UiNotify.show(R.string.watch_disconnected)
            else -> {
                val sent = repo.monitor.startBpCalibrationWorkflow()
                if (
                    !sent && state.monitorState.connection != HealthMonitorSession.Connection.READY
                ) {
                    repo.monitor.connect()
                    UiNotify.show(R.string.connecting_to_health_monitor)
                }
            }
        }
    }

    fun refreshWatchBp() {
        when {
            !state.sessionReady -> UiNotify.show(R.string.watch_disconnected)
            repo.monitor.reviewBp() ->
                UiNotify.show(
                    if (state.monitorState.connection == HealthMonitorSession.Connection.READY)
                        R.string.bp_status_refresh_requested
                    else R.string.connecting_to_health_monitor
                )
            else -> UiNotify.show(R.string.request_not_sent_check_the_watch_connection)
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        GroupedCard(innerPadding = 0.dp) {
            GroupedCardRow(
                title =
                    strings.getString(
                        when (calibrationStatus) {
                            BpCalibrationStatus.State.CURRENT -> R.string.start_watch_bp_measurement
                            BpCalibrationStatus.State.EXPIRED -> R.string.recalibrate_blood_pressure
                            BpCalibrationStatus.State.TERMS_REQUIRED -> R.string.continue_bp_setup
                            BpCalibrationStatus.State.REQUIRED -> R.string.open_cuff_calibration
                            BpCalibrationStatus.State.SERVICE_UNAVAILABLE ->
                                R.string.bp_is_currently_unavailable_on_the_watch
                            BpCalibrationStatus.State.UNKNOWN ->
                                R.string.check_calibration_and_open_setup
                        }
                    ),
                subtitle =
                    strings.getString(
                        when (calibrationStatus) {
                            BpCalibrationStatus.State.CURRENT -> R.string.bp_calibration_current
                            BpCalibrationStatus.State.EXPIRED -> R.string.bp_calibration_expired
                            BpCalibrationStatus.State.TERMS_REQUIRED -> R.string.bp_terms_required
                            BpCalibrationStatus.State.REQUIRED -> R.string.bp_cuff_required
                            BpCalibrationStatus.State.SERVICE_UNAVAILABLE ->
                                R.string.bp_service_unavailable
                            BpCalibrationStatus.State.UNKNOWN -> R.string.bp_check_setup
                        }
                    ),
                icon = Icons.Default.Speed,
                iconTint = HealthBloodPressure,
                enabled =
                    !busy &&
                        state.sessionReady &&
                        calibrationStatus != BpCalibrationStatus.State.SERVICE_UNAVAILABLE,
                onClick = {
                    val current = BpCalibrationStatus.from(information)
                    when (current) {
                        BpCalibrationStatus.State.CURRENT -> {
                            requestAction(
                                repo.monitor::startBpMeasurement,
                                R.string.measurement_requested_check_your_watch,
                            )
                        }
                        BpCalibrationStatus.State.TERMS_REQUIRED -> {
                            val sent = repo.monitor.activateBp()
                            UiNotify.show(
                                if (sent)
                                    strings.getString(R.string.bp_setup_requested_check_your_watch)
                                else strings.getString(R.string.connecting_to_health_monitor)
                            )
                        }
                        else -> {
                            startWatchCalibration()
                        }
                    }
                },
            )
            GroupedDivider()
            GroupedCardRow(
                title = strings.getString(R.string.bp_calibrate_on_watch),
                subtitle = strings.getString(R.string.bp_calibration_explanation),
                icon = Icons.Default.Speed,
                iconTint = HealthBloodPressure,
                enabled =
                    !busy &&
                        state.sessionReady &&
                        calibrationStatus != BpCalibrationStatus.State.SERVICE_UNAVAILABLE,
                onClick = ::startWatchCalibration,
            )
            GroupedDivider()
            GroupedCardRow(
                title = strings.getString(R.string.bp_refresh_calibration),
                subtitle = strings.getString(R.string.bp_refresh_calibration_detail),
                icon = Icons.Default.Refresh,
                iconTint = HealthBloodPressure,
                enabled = !busy && state.sessionReady,
                onClick = ::refreshWatchBp,
            )
        }
        if (busy) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                Text(
                    strings.getString(R.string.bp_reading_watch_status),
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                )
            }
        }
        state.monitorState.error?.let {
            Text(
                it.resolve(strings),
                color = AlertCrimson,
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }

    if (
        state.monitorState.bpCalibrationStep !=
            dev.ricky.galaxywatchmanagerfree.feature.monitor.BpCalibrationStep.Idle
    ) {
        BpCalibrationSheet(
            state = state,
            repo = repo,
            onDismiss = { repo.monitor.resetBpCalibrationStep() },
        )
    }
}
