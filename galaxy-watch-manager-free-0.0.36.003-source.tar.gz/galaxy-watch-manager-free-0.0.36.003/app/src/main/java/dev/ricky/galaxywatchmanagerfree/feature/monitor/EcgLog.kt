package dev.ricky.galaxywatchmanagerfree.feature.monitor

import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.feature.HealthJson
import java.util.Base64
import org.json.JSONArray
import org.json.JSONObject

data class EcgRecord(
    val id: String,
    val startTime: Long,
    val heartRate: Int,
    val classification: Int,
    val sampleRate: Double = 500.0,
    val waveform: FloatArray = FloatArray(0),
) {
    val classificationRes: Int
        get() = classificationLabelRes(classification)

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is EcgRecord) return false
        return id == other.id &&
            startTime == other.startTime &&
            heartRate == other.heartRate &&
            classification == other.classification &&
            sampleRate == other.sampleRate &&
            waveform.contentEquals(other.waveform)
    }

    override fun hashCode(): Int {
        var result = id.hashCode()
        result = 31 * result + startTime.hashCode()
        result = 31 * result + heartRate
        result = 31 * result + classification
        result = 31 * result + sampleRate.hashCode()
        result = 31 * result + waveform.contentHashCode()
        return result
    }

    companion object {
        fun classificationLabelRes(type: Int): Int =
            when (type) {
                1 -> R.string.ecg_sinus
                2 -> R.string.ecg_afib
                0 -> R.string.ecg_poor_signal
                3 -> R.string.ecg_inconclusive
                11 -> R.string.ecg_sinus_fast
                12 -> R.string.ecg_afib_fast
                in 4..10 -> R.string.ecg_inconclusive
                else -> R.string.ecg_unrecognized
            }

        fun parse(
            record: JSONObject,
            chartRecords: Map<String, JSONObject> = emptyMap(),
        ): EcgRecord? {
            val uuid =
                record.optString("datauuid", record.optString("data_uuid")).ifBlank {
                    return null
                }
            val startTime = record.optLong("start_time", record.optLong("create_time", 0L))
            if (startTime <= 0L) return null
            val hr = record.optInt("avg_hr", record.optInt("heart_rate", -1))
            val classification =
                record.optInt("classification", record.optInt("classifications", 3))
            val sampleRate = record.optDouble("sample_rate", 500.0)

            // 波形数据可内嵌在 record 中，或在随附的 chartRecords 中
            val chartObj = chartRecords[uuid] ?: record
            val rawWaveform = chartObj.optString("value", chartObj.optString("data"))
            val points =
                if (record.has("report")) decodeReport(record.getString("report"))
                else decodeWaveform(rawWaveform)

            return EcgRecord(
                id = uuid,
                startTime = startTime,
                heartRate = hr,
                classification = classification,
                sampleRate = if (sampleRate > 0) sampleRate else 500.0,
                waveform = points,
            )
        }

        /** Watch x90.getJsonObject: Base64(zlib(big-endian float64[])), not JSON text. */
        fun decodeReport(encoded: String): FloatArray {
            require(encoded.length <= 4 * 1024 * 1024) { "ECG report exceeds input limit" }
            val decoded = Base64.getDecoder().decode(encoded)
            val bytes = MonitorCompression.inflate(decoded, 8 * 120_000)
            require(bytes.isNotEmpty() && bytes.size % 8 == 0) { "Invalid ECG report length" }
            val values = java.nio.ByteBuffer.wrap(bytes).order(java.nio.ByteOrder.BIG_ENDIAN)
            return FloatArray(bytes.size / 8) {
                val value = values.double
                require(value.isFinite() && value.toFloat().isFinite()) { "Invalid ECG sample" }
                value.toFloat()
            }
        }

        /**
         * 解码 ECG 点阵。
         *
         * 格式两种：
         * 1. gzip Base64 编码的字符串；
         * 2. 解码后为 `"[0.012, 0.015, -0.003, ...]"` 或逗号分隔纯数值。
         */
        fun decodeWaveform(encoded: String): FloatArray {
            if (encoded.isBlank()) return FloatArray(0)
            val text = runCatching { HealthJson.inflateJson(encoded) }.getOrDefault(encoded).trim()
            val clean =
                if (text.startsWith("[") && text.endsWith("]")) {
                    text.substring(1, text.length - 1)
                } else text
            if (clean.isBlank()) return FloatArray(0)
            val parts = clean.split(',')
            val result = FloatArray(parts.size)
            var count = 0
            for (p in parts) {
                val f = p.trim().toFloatOrNull()
                if (f != null && f.isFinite()) {
                    result[count++] = f
                }
            }
            return if (count == result.size) result else result.copyOf(count)
        }
    }
}

object EcgLog {
    fun encodeWaveform(waveform: FloatArray): String {
        if (waveform.isEmpty()) return ""
        val buffer =
            java.nio.ByteBuffer.allocate(waveform.size * 4).order(java.nio.ByteOrder.BIG_ENDIAN)
        for (f in waveform) buffer.putFloat(f)
        val compressed = MonitorCompression.deflate(buffer.array())
        return Base64.getEncoder().encodeToString(compressed)
    }

    fun decodeCompressedWaveform(b64: String): FloatArray {
        if (b64.isBlank()) return FloatArray(0)
        val compressed =
            runCatching { Base64.getDecoder().decode(b64) }.getOrNull() ?: return FloatArray(0)
        val bytes =
            runCatching { MonitorCompression.inflate(compressed, 4 * 120_000) }.getOrNull()
                ?: return FloatArray(0)
        if (bytes.size % 4 != 0) return FloatArray(0)
        val buffer = java.nio.ByteBuffer.wrap(bytes).order(java.nio.ByteOrder.BIG_ENDIAN)
        return FloatArray(bytes.size / 4) { buffer.float }
    }

    fun encode(records: List<EcgRecord>): String {
        val array = JSONArray()
        records.forEach { r ->
            val obj =
                JSONObject()
                    .put("id", r.id)
                    .put("start_time", r.startTime)
                    .put("avg_hr", r.heartRate)
                    .put("classification", r.classification)
                    .put("sample_rate", r.sampleRate)
            if (r.waveform.isNotEmpty()) {
                obj.put("waveform_b64", encodeWaveform(r.waveform))
            }
            array.put(obj)
        }
        return array.toString()
    }

    fun decode(raw: String?): List<EcgRecord> {
        if (raw.isNullOrBlank()) return emptyList()
        val array = runCatching { JSONArray(raw) }.getOrNull() ?: return emptyList()
        val out = ArrayList<EcgRecord>(array.length())
        for (i in 0 until array.length()) {
            val obj = array.optJSONObject(i) ?: continue
            val id = obj.optString("id")
            if (id.isBlank()) continue
            val time = obj.optLong("start_time")
            if (time <= 0L) continue
            val wave =
                if (obj.has("waveform_b64")) {
                    decodeCompressedWaveform(obj.getString("waveform_b64"))
                } else {
                    val waveArr = obj.optJSONArray("waveform")
                    if (waveArr != null) {
                        FloatArray(waveArr.length()) { waveArr.optDouble(it).toFloat() }
                    } else FloatArray(0)
                }
            out.add(
                EcgRecord(
                    id = id,
                    startTime = time,
                    heartRate = obj.optInt("avg_hr", -1),
                    classification = obj.optInt("classification", 3),
                    sampleRate = obj.optDouble("sample_rate", 500.0),
                    waveform = wave,
                )
            )
        }
        return out.sortedByDescending { it.startTime }
    }

    fun merge(
        existing: List<EcgRecord>,
        incoming: List<EcgRecord>,
        maxKeep: Int = 100,
    ): List<EcgRecord> {
        val byId = LinkedHashMap<String, EcgRecord>()
        (existing + incoming).sortedBy { it.startTime }.forEach { byId[it.id] = it }
        return byId.values.sortedByDescending { it.startTime }.take(maxKeep)
    }
}
