/*
 * Android/Compose adaptation of FLClash's liquid_glass.dart and liquid_glass.frag.
 * Upstream: chen08209/FlClash, commit 7fd417fb9a9a277c6a9339a8ac87f907df7c25f7.
 * Modified for this project: GPU display-list capture, persistent selected lens and Android fallbacks.
 * SPDX-License-Identifier: GPL-3.0-only
 * See assets/licenses/FLCLASH-NOTICE.txt and FLCLASH-LICENSE.txt.
 */
package dev.ricky.galaxywatchmanagerfree.ui.components

import android.graphics.RenderEffect
import android.graphics.RuntimeShader
import android.graphics.Shader
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import dev.ricky.galaxywatchmanagerfree.R
import kotlin.math.ceil

/** A GPU display list, not a screen bitmap. The dock is outside the captured page tree. */
@Stable
class LiquidGlassBackdrop internal constructor(internal val layer: GraphicsLayer) {
    internal var origin by mutableStateOf(Offset.Zero)
    internal var revision by mutableIntStateOf(0)
        private set

    private var sequence = 0

    internal fun captured() {
        // Reading the snapshot counter here would subscribe the source to its own draws.
        revision = ++sequence
    }
}

@Composable
fun rememberLiquidGlassBackdrop(): LiquidGlassBackdrop {
    val layer = rememberGraphicsLayer()
    return remember(layer) { LiquidGlassBackdrop(layer) }
}

fun Modifier.liquidGlassSource(backdrop: LiquidGlassBackdrop, cutout: RoundRect? = null): Modifier =
    onGloballyPositioned { backdrop.origin = it.positionInRoot() }
        .drawWithContent {
            backdrop.layer.record { this@drawWithContent.drawContent() }
            if (cutout == null) {
                drawLayer(backdrop.layer)
            } else {
                clipPath(Path().apply { addRoundRect(cutout) }, ClipOp.Difference) {
                    drawLayer(backdrop.layer)
                }
            }
            backdrop.captured()
        }

@Composable
fun LiquidGlassDock(
    backdrop: LiquidGlassBackdrop,
    dark: Boolean,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.(LiquidGlassBackdrop) -> Unit,
) {
    val dockBackdrop = rememberLiquidGlassBackdrop()
    val scheme = MaterialTheme.colorScheme
    val tint =
        if (dark) lerp(scheme.surfaceContainer, Color.White, 0.07f).copy(alpha = 0.28f)
        else lerp(scheme.surface, Color.White, 0.15f).copy(alpha = 0.22f)
    Box(modifier) {
        LiquidGlassPane(
            backdrop = backdrop,
            output = dockBackdrop,
            tint = tint,
            dark = dark,
            style = GlassPaneStyle.PILL,
            lift = 1f,
            modifier = Modifier.fillMaxSize(),
        )
        content(dockBackdrop)
    }
}

/** The selected lens stays refractive at rest and clears further while pressed. */
@Composable
fun LiquidGlassLens(
    backdrop: LiquidGlassBackdrop,
    dark: Boolean,
    lift: Float,
    modifier: Modifier = Modifier,
) {
    val scheme = MaterialTheme.colorScheme
    LiquidGlassPane(
        backdrop = backdrop,
        tint = scheme.primary.copy(alpha = (if (dark) 0.12f else 0.08f) * (1f - lift)),
        dark = dark,
        style = GlassPaneStyle.LENS,
        lift = 0.65f + 0.35f * lift,
        modifier = modifier,
    )
}

/** A separate glyph capture keeps the optical warp from smearing the dock and text together. */
@Composable
fun LiquidGlassLensContent(
    backdrop: LiquidGlassBackdrop,
    dark: Boolean,
    lift: Float,
    modifier: Modifier,
) {
    LiquidGlassPane(
        backdrop = backdrop,
        tint = MaterialTheme.colorScheme.primary,
        dark = dark,
        style = GlassPaneStyle.CONTENT,
        lift = lift,
        modifier = modifier,
    )
}

private enum class GlassPaneStyle {
    PILL,
    LENS,
    CONTENT,
}

@Composable
private fun LiquidGlassPane(
    backdrop: LiquidGlassBackdrop,
    tint: Color,
    dark: Boolean,
    style: GlassPaneStyle,
    lift: Float,
    modifier: Modifier,
    output: LiquidGlassBackdrop? = null,
) {
    val context = LocalContext.current
    val program = remember {
        context.resources.openRawResource(R.raw.liquid_glass).bufferedReader().use { it.readText() }
    }
    val shader =
        remember(program) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) GlassShader(program)
            else null
        }
    val effectLayer = rememberGraphicsLayer()
    val hazeLayer = rememberGraphicsLayer()
    val ownResultLayer = rememberGraphicsLayer()
    val resultLayer = output?.layer ?: ownResultLayer
    var position by remember { mutableStateOf(Offset.Zero) }
    Box(
        modifier
            .onGloballyPositioned { position = it.positionInRoot() }
            .clip(RoundedCornerShape(50))
            .drawWithCache {
                // Capture past the rim so blur/refraction never sample a clipped pill edge.
                val apron = ceil(48.dp.toPx())
                val expanded =
                    IntSize(
                        ceil(size.width + 2 * apron).toInt(),
                        ceil(size.height + 2 * apron).toInt(),
                    )
                val hazeBlur =
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        RenderEffect.createBlurEffect(
                                15.6.dp.toPx(),
                                15.6.dp.toPx(),
                                Shader.TileMode.CLAMP,
                            )
                            .asComposeRenderEffect()
                    } else null
                onDrawBehind {
                    backdrop.revision
                    val shift = backdrop.origin - position + Offset(apron, apron)
                    val atlas =
                        style == GlassPaneStyle.PILL &&
                            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                    if (atlas) {
                        hazeLayer.record(size = expanded) {
                            translate(shift.x, shift.y) { drawLayer(backdrop.layer) }
                        }
                        hazeLayer.renderEffect = hazeBlur
                    }
                    effectLayer.record(
                        size = if (atlas) IntSize(expanded.width, expanded.height * 2) else expanded
                    ) {
                        translate(shift.x, shift.y) { drawLayer(backdrop.layer) }
                        if (atlas) {
                            // Like FLClash's capture atlas: clear and Gaussian backdrops in
                            // one child shader, so wide frost needs only one texture read.
                            translate(top = expanded.height.toFloat()) { drawLayer(hazeLayer) }
                        }
                    }
                    effectLayer.renderEffect =
                        when {
                            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU ->
                                shader!!
                                    .effect(
                                        size.width / density,
                                        size.height / density,
                                        density,
                                        apron,
                                        expanded.height.toFloat(),
                                        tint,
                                        dark,
                                        style,
                                        lift,
                                    )
                                    .asComposeRenderEffect()
                            Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> hazeBlur
                            else -> null
                        }
                    resultLayer.record(size = expanded) {
                        // The raised lens reads the completed dock and the page around it.
                        if (output != null) {
                            translate(shift.x, shift.y) { drawLayer(backdrop.layer) }
                        }
                        drawLayer(effectLayer)
                        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
                            drawRoundRect(
                                tint.copy(
                                    alpha =
                                        when {
                                            style == GlassPaneStyle.CONTENT -> 0f
                                            style == GlassPaneStyle.LENS -> tint.alpha
                                            Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
                                                tint.alpha
                                            else -> 0.92f
                                        }
                                ),
                                topLeft = Offset(apron, apron),
                                size = this@drawWithCache.size,
                                cornerRadius = CornerRadius(this@drawWithCache.size.height / 2f),
                            )
                        }
                    }
                    output?.origin = position - Offset(apron, apron)
                    translate(-apron, -apron) { drawLayer(resultLayer) }
                    output?.captured()
                }
            }
    )
}

@RequiresApi(Build.VERSION_CODES.TIRAMISU)
private class GlassShader(program: String) {
    private val shader = RuntimeShader(program)

    fun effect(
        width: Float,
        height: Float,
        density: Float,
        padding: Float,
        hazeOffset: Float,
        tint: Color,
        dark: Boolean,
        style: GlassPaneStyle,
        lift: Float,
    ): RenderEffect {
        val pill = style == GlassPaneStyle.PILL
        val content = style == GlassPaneStyle.CONTENT
        shader.setFloatUniform("uSize", width, height)
        shader.setFloatUniform("uDensity", density)
        shader.setFloatUniform("uPadding", padding)
        shader.setFloatUniform("uHazeOffset", hazeOffset)
        shader.setFloatUniform(
            "uTint",
            tint.red,
            tint.green,
            tint.blue,
            if (content) 0f else tint.alpha,
        )
        shader.setFloatUniform("uContent", if (content) lift else 0f)
        shader.setFloatUniform(
            "uOptics",
            if (pill) 60f else if (content) 14f * lift else -4.3f * lift,
            if (pill) (if (dark) 1.45f else 1.5f) else 1f,
            if (!pill && dark) 1f + 0.33f * lift else 1f,
        )
        shader.setFloatUniform("uBevel", if (pill) 20f else (if (content) 11.2f else 5.5f) * lift)
        shader.setFloatUniform("uHaze", if (pill) 0.72f else 0f)
        shader.setFloatUniform(
            "uLight",
            if (content) 0f
            else if (pill) (if (dark) 0.45f else 0.75f) else (if (dark) 0.3f else 0.6f) * lift,
            if (pill) 1.3f else 1.1f,
            if (!pill && !content) 0.045f * lift else 0f,
        )
        shader.setFloatUniform(
            "uEdge",
            if (content) 0f else if (pill) (if (dark) 0.12f else 0.3f) else 0.42f * lift,
            if (pill) 0f else (if (content) 3.6f else 6.5f) * lift,
            if (pill) 0f else (if (content) 2.5f else 1.5f) * lift,
        )
        shader.setFloatUniform("uContrast", if (!pill) 0f else if (dark) -0.4f else 0.4f)
        return RenderEffect.createRuntimeShaderEffect(shader, "backdrop")
    }
}
