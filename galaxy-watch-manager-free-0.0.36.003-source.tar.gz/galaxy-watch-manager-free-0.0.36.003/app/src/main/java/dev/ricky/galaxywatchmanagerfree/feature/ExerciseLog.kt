package dev.ricky.galaxywatchmanagerfree.feature

import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import org.json.JSONArray
import org.json.JSONObject

object ExerciseLog {
    const val MODULE = "com.samsung.shealth.exercise"
    const val MODULE_ALIAS = "com.samsung.health.exercise"
    const val MODULE_ROUTINE = "com.samsung.shealth.exercise.routine"
    const val MODULE_CUSTOM = "com.samsung.shealth.exercise.custom_exercise"

    data class Session(
        val id: String,
        val typeCode: Int,
        val startMillis: Long,
        val endMillis: Long,
        val durationMinutes: Int,
        val calories: Int,
        val distanceMeters: Double,
        val avgHeartRate: Int,
        val maxHeartRate: Int,
        val durationMillis: Long = durationMinutes * 60_000L,
        val sourceType: Int = -1,
        val stepCount: Int = -1,
        val locationPayloadPresent: Boolean = false,
        val locationPointCount: Int = 0,
        val title: String = "",
        val count: Int = -1,
        val countType: Int = -1,
        val minHeartRate: Int = -1,
        val meanSpeed: Double = -1.0,
        val maxSpeed: Double = -1.0,
        val altitudeGain: Double = -1.0,
        val altitudeLoss: Double = -1.0,
        val routineId: String = "",
    ) {
        val typeNameRes: Int
            get() = typeNameRes(typeCode)

        val autoDetected: Boolean
            get() = sourceType == 4

        val icon: ImageVector
            get() = ExerciseTypes.icon(typeCode, countType)

        val accentColor: Color
            @Composable get() = ExerciseTypes.accentColor(typeCode, countType)
    }

    fun typeNameRes(code: Int): Int = ExerciseTypes.nameRes(code)

    private fun value(record: JSONObject, name: String): Any? =
        sequenceOf(name, "com.samsung.health.exercise.$name")
            .map { record.opt(it) }
            .firstOrNull { it != null && it != JSONObject.NULL }

    private fun number(record: JSONObject, name: String, missing: Double = -1.0): Double =
        value(record, name)?.toString()?.toDoubleOrNull()?.takeIf { it.isFinite() } ?: missing

    private fun text(record: JSONObject, name: String): String =
        value(record, name)?.toString().orEmpty()

    fun parse(
        records: List<JSONObject>,
        customRecords: List<JSONObject> = emptyList(),
    ): List<Session> {
        val customNames =
            customRecords.associate { text(it, "custom_id") to text(it, "custom_name") }
        return records.mapNotNull { record ->
            val start = number(record, "start_time", 0.0).toLong()
            val end = number(record, "end_time", 0.0).toLong()
            val duration =
                number(record, "duration", 0.0).toLong().takeIf { it > 0L }
                    ?: (end - start).coerceAtLeast(0L)
            if (start <= 0L || duration <= 0L) return@mapNotNull null
            val type = number(record, "exercise_type").toInt()
            val id = text(record, "datauuid").ifBlank { "ex_${start}_$type" }
            val location =
                sequenceOf("location_data", "location_data_internal", "location")
                    .map { value(record, it) }
                    .firstOrNull {
                        it != null && it.toString().isNotBlank() && it.toString() != "[]"
                    }
            val points = HealthJson.array(location)
            val pointCount =
                if (points == null) 0
                else
                    (0 until points.length()).count { index ->
                        val point = points.optJSONObject(index) ?: return@count false
                        val lat = point.optDouble("latitude", Double.NaN)
                        val lon = point.optDouble("longitude", Double.NaN)
                        lat in -90.0..90.0 && lon in -180.0..180.0 && (lat != 0.0 || lon != 0.0)
                    }
            val countType = number(record, "count_type").toInt()
            val count = number(record, "count").toInt()
            Session(
                id = id,
                typeCode = type,
                startMillis = start,
                endMillis = if (end > start) end else start + duration,
                durationMinutes = (duration / 60_000L).toInt(),
                calories = number(record, "calorie").toInt(),
                distanceMeters = number(record, "distance"),
                avgHeartRate = number(record, "mean_heart_rate").toInt(),
                maxHeartRate = number(record, "max_heart_rate").toInt(),
                durationMillis = duration,
                sourceType = number(record, "source_type").toInt(),
                stepCount = if (countType == 30001) count else -1,
                locationPayloadPresent = location != null,
                locationPointCount = pointCount,
                title =
                    text(record, "title").ifBlank {
                        customNames[text(record, "custom_id")].orEmpty()
                    },
                count = count,
                countType = countType,
                minHeartRate = number(record, "min_heart_rate").toInt(),
                meanSpeed = number(record, "mean_speed"),
                maxSpeed = number(record, "max_speed"),
                altitudeGain = number(record, "altitude_gain"),
                altitudeLoss = number(record, "altitude_loss"),
                routineId = text(record, "routine_datauuid"),
            )
        }
    }

    fun parseRoutines(
        records: List<JSONObject>,
        customRecords: List<JSONObject> = emptyList(),
    ): List<Session> =
        parse(
            records.map { record ->
                JSONObject(record.toString()).apply {
                    put("exercise_type", 51005)
                    mapOf(
                            "duration" to "total_duration",
                            "calorie" to "total_calorie",
                            "distance" to "total_distance",
                            "mean_heart_rate" to "total_average_hr",
                            "max_heart_rate" to "total_max_hr",
                            "min_heart_rate" to "total_min_hr",
                        )
                        .forEach { (target, source) ->
                            if (record.has(source)) put(target, record.get(source))
                        }
                }
            },
            customRecords,
        )

    fun topLevel(sessions: List<Session>): List<Session> {
        val routineIds = sessions.filter { it.typeCode == 51005 }.map { it.id }.toSet()
        return sessions.filter { it.routineId !in routineIds || it.routineId == it.id }
    }

    fun merge(existing: List<Session>, incoming: List<Session>, keep: Int = 8000): List<Session> {
        val byId = LinkedHashMap<String, Session>()
        (existing + incoming).forEach { byId[it.id] = it }
        return byId.values.sortedByDescending { it.startMillis }.take(keep)
    }

    fun encode(sessions: List<Session>): String =
        JSONArray()
            .apply {
                sessions.forEach { session ->
                    put(
                        JSONArray()
                            .put(session.id)
                            .put(session.typeCode)
                            .put(session.startMillis)
                            .put(session.endMillis)
                            .put(session.durationMinutes)
                            .put(session.calories)
                            .put(session.distanceMeters)
                            .put(session.avgHeartRate)
                            .put(session.maxHeartRate)
                            .put(session.durationMillis)
                            .put(session.sourceType)
                            .put(session.stepCount)
                            .put(session.locationPayloadPresent)
                            .put(session.locationPointCount)
                            .put(session.title)
                            .put(session.count)
                            .put(session.countType)
                            .put(session.minHeartRate)
                            .put(session.meanSpeed)
                            .put(session.maxSpeed)
                            .put(session.altitudeGain)
                            .put(session.altitudeLoss)
                            .put(session.routineId)
                    )
                }
            }
            .toString()

    fun decode(raw: String?): List<Session> {
        if (raw.isNullOrBlank()) return emptyList()
        val array = runCatching { JSONArray(raw) }.getOrNull() ?: return emptyList()
        return (0 until array.length()).mapNotNull { index ->
            val item = array.optJSONArray(index) ?: return@mapNotNull null
            val start = item.optLong(2)
            if (start <= 0L) return@mapNotNull null
            Session(
                id = item.optString(0),
                typeCode = item.optInt(1, -1),
                startMillis = start,
                endMillis = item.optLong(3),
                durationMinutes = item.optInt(4),
                calories = item.optInt(5, -1),
                distanceMeters = item.optDouble(6, -1.0),
                avgHeartRate = item.optInt(7, -1),
                maxHeartRate = item.optInt(8, -1),
                durationMillis = item.optLong(9, item.optInt(4) * 60_000L),
                sourceType = item.optInt(10, -1),
                stepCount = item.optInt(11, -1),
                locationPayloadPresent = item.optBoolean(12, false),
                locationPointCount = item.optInt(13, 0),
                title = item.optString(14),
                count = item.optInt(15, -1),
                countType = item.optInt(16, -1),
                minHeartRate = item.optInt(17, -1),
                meanSpeed = item.optDouble(18, -1.0),
                maxSpeed = item.optDouble(19, -1.0),
                altitudeGain = item.optDouble(20, -1.0),
                altitudeLoss = item.optDouble(21, -1.0),
                routineId = item.optString(22),
            )
        }
    }

    fun todaySummary(
        sessions: List<Session>,
        today: java.time.LocalDate,
        zone: java.time.ZoneId = java.time.ZoneId.systemDefault(),
    ): Triple<Int, Int, Int> {
        val selected =
            topLevel(sessions).filter {
                HealthMetricLog.dayOf(it.startMillis, zone) == today.toString()
            }
        return Triple(
            selected.size,
            selected.sumOf { it.durationMinutes },
            selected.sumOf { it.calories.coerceAtLeast(0) },
        )
    }
}
