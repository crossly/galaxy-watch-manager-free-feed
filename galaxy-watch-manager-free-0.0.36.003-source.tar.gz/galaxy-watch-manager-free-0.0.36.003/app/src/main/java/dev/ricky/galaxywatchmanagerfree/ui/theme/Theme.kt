package dev.ricky.galaxywatchmanagerfree.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Shared typography for headings, controls, measurements and captions.
private val AppTypography =
    Typography(
        displayLarge =
            TextStyle(fontSize = 40.sp, lineHeight = 44.sp, fontWeight = FontWeight.Bold),
        headlineLarge =
            TextStyle(fontSize = 34.sp, lineHeight = 41.sp, fontWeight = FontWeight.Bold),
        headlineMedium =
            TextStyle(fontSize = 28.sp, lineHeight = 34.sp, fontWeight = FontWeight.Bold),
        headlineSmall =
            TextStyle(fontSize = 24.sp, lineHeight = 30.sp, fontWeight = FontWeight.SemiBold),
        titleLarge = TextStyle(fontSize = 20.sp, lineHeight = 25.sp),
        titleMedium =
            TextStyle(fontSize = 17.sp, lineHeight = 22.sp, fontWeight = FontWeight.SemiBold),
        titleSmall =
            TextStyle(fontSize = 15.sp, lineHeight = 20.sp, fontWeight = FontWeight.SemiBold),
        bodyLarge = TextStyle(fontSize = 17.sp, lineHeight = 22.sp),
        bodyMedium = TextStyle(fontSize = 15.sp, lineHeight = 20.sp),
        bodySmall = TextStyle(fontSize = 13.sp, lineHeight = 18.sp),
        labelLarge =
            TextStyle(fontSize = 15.sp, lineHeight = 20.sp, fontWeight = FontWeight.SemiBold),
        labelMedium = TextStyle(fontSize = 12.sp, lineHeight = 16.sp),
        labelSmall = TextStyle(fontSize = 11.sp, lineHeight = 13.sp),
    )

private val AppShapes =
    Shapes(
        extraSmall = RoundedCornerShape(4.dp),
        small = RoundedCornerShape(8.dp),
        medium = RoundedCornerShape(16.dp),
        large = RoundedCornerShape(24.dp),
        extraLarge = RoundedCornerShape(34.dp),
    )

private data class AccentSchemeColors(
    val primary: Long,
    val onPrimary: Long,
    val primaryContainer: Long,
    val onPrimaryContainer: Long,
    val secondary: Long,
    val onSecondary: Long,
    val secondaryContainer: Long,
    val onSecondaryContainer: Long,
    val tertiary: Long,
    val onTertiary: Long,
    val tertiaryContainer: Long,
    val onTertiaryContainer: Long,
)

private fun presetAccentColors(selectedColor: Int, dark: Boolean): AccentSchemeColors? =
    when (selectedColor) {
        ThemeController.COLOR_BLUE ->
            if (dark) {
                AccentSchemeColors(
                    0xFFA3C9FF,
                    0xFF003063,
                    0xFF15477E,
                    0xFFD3E4FF,
                    0xFFA8C8F0,
                    0xFF0A355B,
                    0xFF254A70,
                    0xFFD2E4FF,
                    0xFF82D3E8,
                    0xFF003640,
                    0xFF004E5C,
                    0xFFB5EBF7,
                )
            } else {
                AccentSchemeColors(
                    0xFF1762AC,
                    0xFFFFFFFF,
                    0xFFD3E4FF,
                    0xFF003063,
                    0xFF3E638C,
                    0xFFFFFFFF,
                    0xFFD3E4FF,
                    0xFF001D36,
                    0xFF00687A,
                    0xFFFFFFFF,
                    0xFFC4E7F2,
                    0xFF001F26,
                )
            }
        ThemeController.COLOR_MINT ->
            if (dark) {
                AccentSchemeColors(
                    0xFF70DAC1,
                    0xFF00382E,
                    0xFF005142,
                    0xFF8DF7DD,
                    0xFF8CDBCB,
                    0xFF00382E,
                    0xFF174F45,
                    0xFFA8F2DC,
                    0xFF8DCFCB,
                    0xFF003733,
                    0xFF20554C,
                    0xFFB8F0E5,
                )
            } else {
                AccentSchemeColors(
                    0xFF006B58,
                    0xFFFFFFFF,
                    0xFF8DF7DD,
                    0xFF002118,
                    0xFF39685F,
                    0xFFFFFFFF,
                    0xFFB9F0E1,
                    0xFF00201A,
                    0xFF2D625A,
                    0xFFFFFFFF,
                    0xFFC0EDE5,
                    0xFF00201A,
                )
            }
        ThemeController.COLOR_VIOLET ->
            if (dark) {
                AccentSchemeColors(
                    0xFFD2BCFF,
                    0xFF3B245F,
                    0xFF523B77,
                    0xFFEBDDFF,
                    0xFFC9B7DD,
                    0xFF342A42,
                    0xFF4A3F5E,
                    0xFFE9DFF5,
                    0xFFE2B8CF,
                    0xFF482535,
                    0xFF5E3C4C,
                    0xFFFFD8E8,
                )
            } else {
                AccentSchemeColors(
                    0xFF6B5290,
                    0xFFFFFFFF,
                    0xFFEBDDFF,
                    0xFF251141,
                    0xFF625B71,
                    0xFFFFFFFF,
                    0xFFE8DDF0,
                    0xFF201A25,
                    0xFF7D5260,
                    0xFFFFFFFF,
                    0xFFF5D9E7,
                    0xFF31101F,
                )
            }
        else -> null
    }

@Composable
fun WatchFreeTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    val context = LocalContext.current
    val selectedColor by ThemeController.color.collectAsState()
    // 取色只在 context 或明暗切换时重建：`dynamicXColorScheme` 每次组合都返回新实例，
    // 不缓存会让下面的 remember 永不命中，整棵 palette 每帧重算。
    val systemScheme =
        remember(context, darkTheme) {
            when {
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && darkTheme ->
                    dynamicDarkColorScheme(context)
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> dynamicLightColorScheme(context)
                darkTheme -> DarkScheme
                else -> LightScheme
            }
        }
    val scheme =
        remember(systemScheme, selectedColor, darkTheme) {
            if (selectedColor == ThemeController.COLOR_SYSTEM) systemScheme
            else {
                val base = if (darkTheme) DarkScheme else LightScheme
                val colors = checkNotNull(presetAccentColors(selectedColor, darkTheme))
                base.copy(
                    primary = Color(colors.primary),
                    onPrimary = Color(colors.onPrimary),
                    primaryContainer = Color(colors.primaryContainer),
                    onPrimaryContainer = Color(colors.onPrimaryContainer),
                    secondary = Color(colors.secondary),
                    onSecondary = Color(colors.onSecondary),
                    secondaryContainer = Color(colors.secondaryContainer),
                    onSecondaryContainer = Color(colors.onSecondaryContainer),
                    tertiary = Color(colors.tertiary),
                    onTertiary = Color(colors.onTertiary),
                    tertiaryContainer = Color(colors.tertiaryContainer),
                    onTertiaryContainer = Color(colors.onTertiaryContainer),
                )
            }
        }
    val accentFamily = AccentFamily.fromPreference(selectedColor)
    val palette =
        remember(scheme, darkTheme, accentFamily) { paletteFor(scheme, darkTheme, accentFamily) }
    CompositionLocalProvider(LocalWfPalette provides palette) {
        MaterialTheme(
            colorScheme = scheme,
            typography = AppTypography,
            shapes = AppShapes,
            content = content,
        )
    }
}
