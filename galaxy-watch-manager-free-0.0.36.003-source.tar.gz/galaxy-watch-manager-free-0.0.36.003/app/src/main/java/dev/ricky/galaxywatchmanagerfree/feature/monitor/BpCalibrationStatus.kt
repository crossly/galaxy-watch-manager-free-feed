package dev.ricky.galaxywatchmanagerfree.feature.monitor

import java.util.Calendar
import org.json.JSONObject

/** Parses only fields reported by Samsung Health Monitor's BP information message. */
object BpCalibrationStatus {
    enum class State {
        UNKNOWN,
        SERVICE_UNAVAILABLE,
        TERMS_REQUIRED,
        REQUIRED,
        EXPIRED,
        CURRENT,
    }

    fun from(information: String?, nowMillis: Long = System.currentTimeMillis()): State {
        val data =
            information?.let { runCatching { JSONObject(it) }.getOrNull() } ?: return State.UNKNOWN
        if (data.optString("is_service_available").equals("false", true)) {
            return State.SERVICE_UNAVAILABLE
        }
        if (!data.optBoolean("tnc", false)) return State.TERMS_REQUIRED
        if (data.optBoolean("need_to_recal", false)) return State.REQUIRED
        val calibratedAt = data.optLong("calibration_time", 0L)
        if (calibratedAt <= 0L) return State.REQUIRED
        val expiresAt = expiryTime(calibratedAt) ?: Long.MAX_VALUE
        return if (nowMillis >= expiresAt) State.EXPIRED else State.CURRENT
    }

    /** Samsung resets to local midnight and adds 28 calendar days (DST aware). */
    fun expiryTime(calibratedAt: Long): Long? {
        if (calibratedAt <= 0L) return null
        return runCatching {
                Calendar.getInstance()
                    .apply {
                        timeInMillis = calibratedAt
                        set(Calendar.HOUR_OF_DAY, 0)
                        set(Calendar.MINUTE, 0)
                        set(Calendar.SECOND, 0)
                        set(Calendar.MILLISECOND, 0)
                        add(Calendar.DAY_OF_YEAR, 28)
                    }
                    .timeInMillis
            }
            .getOrNull()
    }
}
