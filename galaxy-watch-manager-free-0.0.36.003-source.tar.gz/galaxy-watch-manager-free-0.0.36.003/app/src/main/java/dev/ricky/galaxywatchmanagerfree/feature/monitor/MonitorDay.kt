package dev.ricky.galaxywatchmanagerfree.feature.monitor

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

object MonitorDay {
    fun contains(time: Long, day: LocalDate, zone: ZoneId): Boolean =
        time > 0 && Instant.ofEpochMilli(time).atZone(zone).toLocalDate() == day
}
