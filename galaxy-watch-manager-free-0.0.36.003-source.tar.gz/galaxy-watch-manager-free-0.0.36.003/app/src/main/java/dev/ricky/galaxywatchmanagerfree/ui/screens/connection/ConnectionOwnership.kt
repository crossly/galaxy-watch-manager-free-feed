package dev.ricky.galaxywatchmanagerfree.ui.screens.connection

/** Which side currently owns the watch's Bluetooth connection. */
enum class ConnectionOwnership {
    NONE,
    DIRECT,
    OFFICIAL_APPS,
    HANDOVER,
}

internal fun resolveConnectionOwnership(
    hasDevice: Boolean,
    handoverPreparing: Boolean,
    releasedToOfficialApps: Boolean,
): ConnectionOwnership =
    when {
        !hasDevice -> ConnectionOwnership.NONE
        handoverPreparing -> ConnectionOwnership.HANDOVER
        releasedToOfficialApps -> ConnectionOwnership.OFFICIAL_APPS
        else -> ConnectionOwnership.DIRECT
    }
