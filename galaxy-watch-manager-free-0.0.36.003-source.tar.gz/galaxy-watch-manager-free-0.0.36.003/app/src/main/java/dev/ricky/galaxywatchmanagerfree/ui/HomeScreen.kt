package dev.ricky.galaxywatchmanagerfree.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarDefaults
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.core.AutoConnectResult
import dev.ricky.galaxywatchmanagerfree.core.WatchController
import dev.ricky.galaxywatchmanagerfree.ui.components.FloatingNavigationBar
import dev.ricky.galaxywatchmanagerfree.ui.components.LocalRootPageBottomPadding
import dev.ricky.galaxywatchmanagerfree.ui.components.PageToolbar
import dev.ricky.galaxywatchmanagerfree.ui.components.liquidGlassSource
import dev.ricky.galaxywatchmanagerfree.ui.components.rememberLiquidGlassBackdrop
import dev.ricky.galaxywatchmanagerfree.ui.screens.DashboardTab
import dev.ricky.galaxywatchmanagerfree.ui.screens.HealthTab
import dev.ricky.galaxywatchmanagerfree.ui.screens.SettingsTab
import dev.ricky.galaxywatchmanagerfree.ui.screens.WatchFaceScreen
import dev.ricky.galaxywatchmanagerfree.ui.theme.DeepCanvas
import dev.ricky.galaxywatchmanagerfree.ui.theme.ElectricBlue
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextDisabled
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextTertiary
import dev.ricky.galaxywatchmanagerfree.ui.theme.ThemeController

/** 自动连接结果给用户的简短说明 */
internal fun autoConnectMessage(
    result: AutoConnectResult,
    strings: android.content.res.Resources,
): String =
    when (result) {
        AutoConnectResult.STARTED -> strings.getString(R.string.watch_connection_started)
        AutoConnectResult.ALREADY_RUNNING ->
            strings.getString(R.string.a_connection_is_already_running)
        AutoConnectResult.PAUSED_BY_USER ->
            strings.getString(R.string.auto_connect_is_off_enable_it_in_settings)
        AutoConnectResult.PAUSED_FOR_OFFICIAL_APPS ->
            strings.getString(R.string.connection_paused_for_official_apps)
        AutoConnectResult.RECENTLY_TRIED ->
            strings.getString(R.string.please_wait_before_trying_again)
        AutoConnectResult.BLUETOOTH_OFF ->
            strings.getString(R.string.turn_on_bluetooth_on_your_phone)
        AutoConnectResult.PERMISSION_MISSING ->
            strings.getString(R.string.connection_permission_required)
        AutoConnectResult.NO_PAIRED_WATCH -> strings.getString(R.string.connection_no_paired_watch)
        AutoConnectResult.BACKGROUND_RESTRICTED ->
            strings.getString(R.string.connection_background_restricted)
    }

enum class HomeTab(@androidx.annotation.StringRes val titleRes: Int, val icon: ImageVector) {
    DASHBOARD(R.string.overview, Icons.Outlined.Dashboard),
    HEALTH(R.string.health, Icons.Outlined.FavoriteBorder),
    SETTINGS(R.string.settings, Icons.Outlined.Settings),
}

/**
 * Three root pages, with a floating or fixed phone dock and separate settings / watch-face routes.
 */
@Composable
fun HomeScreen() {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources

    val activeRepository by WatchController.repositoryState.collectAsStateWithLifecycle()
    val repo = activeRepository ?: return
    val context = LocalContext.current
    val tabStates = androidx.compose.runtime.saveable.rememberSaveableStateHolder()
    var currentTab by rememberSaveable { mutableStateOf(HomeTab.DASHBOARD) }
    var settingsDetail by remember { mutableStateOf(false) }
    var showWatchFaceScreen by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf(false) }

    // 根导航悬浮底板高度与系统导航栏留白只计算一次，同时用于底板和页面底部预留。
    val navigationStyle by ThemeController.navigationStyle.collectAsStateWithLifecycle()
    val glassEffect by ThemeController.glassEffect.collectAsStateWithLifecycle()
    val floatingNavigation = navigationStyle != ThemeController.NAVIGATION_FIXED
    val navigationVisible = !showWatchFaceScreen && !settingsDetail
    val liquidGlassActive = glassEffect && floatingNavigation && navigationVisible
    val glassBackdrop = rememberLiquidGlassBackdrop()
    val dockHeight =
        with(androidx.compose.ui.platform.LocalDensity.current) {
            (14.sp.toDp() + 34.dp).coerceAtLeast(62.dp)
        }
    val navigationBarInset =
        WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding().coerceAtLeast(21.dp)
    val rootBottomPadding =
        if (floatingNavigation) {
            8.dp + dockHeight + navigationBarInset + 16.dp
        } else {
            16.dp
        }
    val onTabSelected: (HomeTab) -> Unit = {
        editing = false
        currentTab = it
    }
    BackHandler(enabled = editing) { editing = false }

    // 二级页面下按返回键退回概览页
    BackHandler(enabled = showWatchFaceScreen) { showWatchFaceScreen = false }

    // 可见性仅控制电量周期查询；后台健康同步由全局自动查询策略统一调度。
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    DisposableEffect(repo, lifecycleOwner) {
        var refreshing = false
        fun stopRefreshing() {
            if (refreshing) {
                refreshing = false
                repo.stopAutoRefresh()
            }
        }
        val observer =
            androidx.lifecycle.LifecycleEventObserver { _, event ->
                when (event) {
                    androidx.lifecycle.Lifecycle.Event.ON_START ->
                        if (!refreshing) {
                            refreshing = true
                            repo.startAutoRefresh()
                        }
                    androidx.lifecycle.Lifecycle.Event.ON_STOP -> stopRefreshing()
                    else -> Unit
                }
            }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            stopRefreshing()
        }
    }

    Box(Modifier.fillMaxSize().background(DeepCanvas)) {
        Column(
            modifier =
                Modifier.fillMaxSize()
                    .then(
                        if (liquidGlassActive) Modifier.liquidGlassSource(glassBackdrop)
                        else Modifier
                    )
                    .background(DeepCanvas)
                    .statusBarsPadding()
        ) {
            // 顶部状态栏（二级页面自带专用返回顶栏）
            if (!showWatchFaceScreen && currentTab != HomeTab.SETTINGS) {
                PageToolbar(
                    title =
                        if (editing)
                            strings.getString(
                                R.string.edit_page_title,
                                strings.getString(currentTab.titleRes),
                            )
                        else strings.getString(currentTab.titleRes)
                ) {
                    if (currentTab == HomeTab.DASHBOARD && !editing) {
                        RefreshAction(repo.state) { refresh ->
                            FilledTonalIconButton(
                                onClick = { repo.refreshAll() },
                                enabled = refresh.canRefresh,
                                modifier = Modifier.testTag("tag_refresh_all"),
                            ) {
                                if (refresh.refreshInProgress) {
                                    CircularProgressIndicator(
                                        modifier =
                                            Modifier.size(20.dp).semantics {
                                                contentDescription =
                                                    strings.getString(R.string.syncing)
                                            },
                                        color = ElectricBlue,
                                        strokeWidth = 2.dp,
                                    )
                                } else {
                                    Icon(
                                        Icons.Default.Refresh,
                                        strings.getString(R.string.refresh),
                                        tint =
                                            if (refresh.canRefresh) TextTertiary else TextDisabled,
                                    )
                                }
                            }
                        }
                    }
                    if (currentTab == HomeTab.DASHBOARD || currentTab == HomeTab.HEALTH) {
                        FilledTonalIconButton(onClick = { editing = !editing }) {
                            Icon(
                                if (editing) Icons.Default.Check else Icons.Default.Edit,
                                strings.getString(
                                    if (editing) R.string.finish_editing else R.string.edit_blocks
                                ),
                                tint = TextTertiary,
                            )
                        }
                    }
                }
            }

            // Root tabs replace content atomically. Outgoing pages must never remain
            // composed while the selected tab changes its toolbar / content insets.
            Box(modifier = Modifier.weight(1f)) {
                if (showWatchFaceScreen) {
                    WatchPageState(repo.state, WatchPage.WATCH_FACE) { pageState ->
                        WatchFaceScreen(
                            state = pageState,
                            repo = repo,
                            onBack = { showWatchFaceScreen = false },
                        )
                    }
                } else {
                    CompositionLocalProvider(
                        LocalRootPageBottomPadding provides rootBottomPadding
                    ) {
                        tabStates.SaveableStateProvider(currentTab) {
                            when (currentTab) {
                                HomeTab.DASHBOARD ->
                                    WatchPageState(repo.state, WatchPage.DASHBOARD) { pageState ->
                                        DashboardTab(
                                            state = pageState,
                                            repo = repo,
                                            editing = editing,
                                            onNavigateWatchFace = { showWatchFaceScreen = true },
                                        )
                                    }
                                HomeTab.HEALTH ->
                                    WatchPageState(repo.state, WatchPage.HEALTH) { pageState ->
                                        HealthTab(state = pageState, repo = repo, editing = editing)
                                    }
                                HomeTab.SETTINGS ->
                                    WatchPageState(repo.state, WatchPage.SETTINGS) { pageState ->
                                        SettingsTab(
                                            state = pageState,
                                            repo = repo,
                                            onDetailChanged = { settingsDetail = it },
                                        )
                                    }
                            }
                        }
                    }
                }
            }

            androidx.compose.animation.AnimatedVisibility(
                visible = navigationVisible && !floatingNavigation,
                enter =
                    androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(180)),
                exit =
                    androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(120)),
            ) {
                WatchFreeFixedBottomBar(currentTab, onTabSelected = onTabSelected)
            }
        }
        androidx.compose.animation.AnimatedVisibility(
            visible = navigationVisible && floatingNavigation,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(180)),
            exit = androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(120)),
        ) {
            FloatingNavigationBar(
                currentTab = currentTab,
                onTabSelected = onTabSelected,
                navigationHeight = dockHeight,
                bottomInset = navigationBarInset,
                glassEffect = liquidGlassActive,
                backdrop = glassBackdrop,
            )
        }
    }
}

/** Fixed Material3 navigation, laid out below the scrolling body instead of over it. */
@Composable
private fun WatchFreeFixedBottomBar(currentTab: HomeTab, onTabSelected: (HomeTab) -> Unit) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources
    NavigationBar(
        modifier = Modifier.testTag("tag_navigation_fixed"),
        windowInsets = NavigationBarDefaults.windowInsets,
    ) {
        HomeTab.entries.forEach { tab ->
            NavigationBarItem(
                selected = currentTab == tab,
                onClick = { onTabSelected(tab) },
                icon = { Icon(tab.icon, null, modifier = Modifier.size(24.dp)) },
                modifier = Modifier.testTag("tag_nav_${tab.name}"),
                label = {
                    Text(
                        strings.getString(tab.titleRes),
                        maxLines = 1,
                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    )
                },
                alwaysShowLabel = true,
            )
        }
    }
}
