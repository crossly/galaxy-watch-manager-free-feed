package dev.ricky.galaxywatchmanagerfree.feature

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Queries needed by the first screen, independently of UI refreshes and health's bulk sync. */
class StartupSyncCoordinator(
    private val scope: CoroutineScope,
    private val request: (Target) -> Unit,
    private val onPending: (Set<Target>, Boolean) -> Unit = { _, _ -> },
    private val onLog: (String) -> Unit = {},
) {
    enum class Target { WATCH_FACE, DEVICE_INFO, BATTERY, WATCH_FACE_ORDER }
    private val pending = linkedSetOf<Target>()
    private var task: Job? = null
    private var active = false
    private var generation = 0L

    fun start() {
        val token = synchronized(this) {
            if (active) return
            active = true
            pending.clear()
            pending.addAll(Target.entries)
            onPending(pending.toSet(), true)
            ++generation
        }
        // Enqueue critical RPCs before the transport starts its bulk DataItem dump.
        // Never hold this monitor while request() enters the repository's DeviceCare queue.
        sendPending(token)
        synchronized(this) {
            if (!active || generation != token) return
            task = scope.launch {
                for (wait in listOf(2_000L, 4_000L, 8_000L)) {
                    delay(wait)
                    if (synchronized(this@StartupSyncCoordinator) { pending.isEmpty() || generation != token }) break
                    sendPending(token)
                }
                synchronized(this@StartupSyncCoordinator) {
                    if (generation == token) onPending(pending.toSet(), false)
                }
            }
        }
    }

    private fun sendPending(token: Long) {
        val targets = synchronized(this) { if (!active || generation != token) emptyList() else pending.toList() }
        targets.forEach { target ->
            if (synchronized(this) { !active || generation != token }) return
            runCatching { request(target) }.onFailure { onLog("[启动同步] $target 查询失败：${it.message}") }
        }
    }

    @Synchronized
    fun confirm(target: Target) {
        if (!active) return
        if (pending.remove(target)) onPending(pending.toSet(), pending.isNotEmpty() && task?.isActive == true)
    }

    @Synchronized
    fun stop() {
        active = false
        generation++
        task?.cancel()
        task = null
        pending.clear()
        onPending(emptySet(), false)
    }
}
