package dev.ricky.galaxywatchmanagerfree.feature

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Tracks requested values separately from confirmed device state. New writes replace old retries.
 */
class SettingCommands(
    private val scope: CoroutineScope,
    private val onPending: ((Map<String, Any>) -> Unit)? = null,
    private val onError: (Failure) -> Unit,
    private val onDebug: (String) -> Unit = {},
    private val onConfirmed: (String, Any) -> Unit = { _, _ -> },
) {
    enum class Failure {
        SEND_FAILED,
        UNCONFIRMED,
    }

    private data class Request(
        val value: Any,
        var job: Job? = null,
        val startedNanos: Long = System.nanoTime(),
    )

    private val pending = linkedMapOf<String, Request>()

    @Synchronized
    fun submit(
        path: String,
        value: Any,
        retries: Int = 0,
        readBack: () -> Unit = {},
        enqueue: ((() -> Unit) -> Boolean)? = null,
        send: () -> Boolean,
    ): Boolean {
        val replaced = pending.remove(path)
        replaced?.job?.cancel()
        onDebug(
            "[设置→] path=$path value=$value type=${value.javaClass.simpleName} retries=$retries replaced=${replaced != null}"
        )
        val request = Request(value)
        pending[path] = request
        publish()
        return dispatch(path, request, retries, readBack, enqueue, send)
    }

    private fun dispatch(
        path: String,
        request: Request,
        retries: Int,
        readBack: () -> Unit,
        enqueue: ((() -> Unit) -> Boolean)?,
        send: () -> Boolean,
    ): Boolean {
        var sent = true
        val action: () -> Unit = {
            synchronized(this) {
                if (pending[path] === request) {
                    sent =
                        try {
                            trySend(send)
                        } catch (cancelled: CancellationException) {
                            if (pending[path] === request) {
                                pending.remove(path)
                                publish()
                            }
                            throw cancelled
                        }
                    if (!sent) {
                        fail(path, request, Failure.SEND_FAILED)
                    } else if (pending[path] === request) {
                        readBack()
                        if (pending[path] === request) {
                            request.job =
                                scope.launch {
                                    delay(CONFIRM_TIMEOUT_MS)
                                    synchronized(this@SettingCommands) {
                                        if (pending[path] !== request) return@launch
                                        onDebug(
                                            "[设置] path=$path confirmation timeout retries=$retries"
                                        )
                                        if (retries > 0) {
                                            dispatch(
                                                path,
                                                request,
                                                retries - 1,
                                                readBack,
                                                enqueue,
                                                send,
                                            )
                                        } else {
                                            fail(path, request, Failure.UNCONFIRMED)
                                        }
                                    }
                                }
                        }
                    }
                }
            }
        }
        val accepted =
            if (enqueue != null) trySend { enqueue(action) }
            else {
                action()
                sent
            }
        onDebug("[设置→] path=$path queued=$accepted pending=${pending.size}")
        if (!accepted) fail(path, request, Failure.SEND_FAILED)
        return accepted
    }

    private fun fail(path: String, request: Request, failure: Failure) {
        if (pending[path] !== request) return
        pending.remove(path)?.job?.cancel()
        publish()
        onError(failure)
    }

    @Synchronized
    fun confirm(path: String, value: Any): Boolean {
        val request = pending[path] ?: return false
        val matches =
            if (value is Number && request.value is Number) {
                value.toDouble() == request.value.toDouble()
            } else value == request.value
        onDebug(
            "[设置←] path=$path requested=${request.value} actual=$value matches=$matches elapsedMs=${(System.nanoTime() - request.startedNanos) / 1_000_000}"
        )
        if (!matches) return false
        pending.remove(path)?.job?.cancel()
        publish()
        onConfirmed(path, value)
        return true
    }

    @Synchronized fun isPending(path: String, value: Any): Boolean = pending[path]?.value == value

    @Synchronized fun hasPending(path: String): Boolean = pending.containsKey(path)

    @Synchronized
    fun clear() {
        onDebug("[设置] cancel pending=${pending.keys}")
        pending.values.forEach { it.job?.cancel() }
        pending.clear()
        publish()
    }

    private fun trySend(send: () -> Boolean): Boolean =
        try {
            send()
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            false
        }

    private fun publish() {
        onPending?.invoke(pending.mapValues { it.value.value })
    }

    companion object {
        const val CONFIRM_TIMEOUT_MS = 4_000L
    }
}
