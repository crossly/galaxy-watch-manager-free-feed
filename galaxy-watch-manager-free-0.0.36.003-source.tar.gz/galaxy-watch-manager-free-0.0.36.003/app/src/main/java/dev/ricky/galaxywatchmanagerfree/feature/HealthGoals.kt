package dev.ricky.galaxywatchmanagerfree.feature

/**
 * 每日步数目标的解析与进度计算（纯逻辑）。
 *
 * 规则取自 Samsung Health 的「每日活动目标」：
 *  - 默认 6,000 步（手表报文 `pedometer_day_summary.recommendation` 实测就是 6000）；
 *  - 可调范围 1,000–50,000 步，步进 100（官方目标选择器同为 1,000～50,000 的 100 步进）；
 *  - 目标来源优先级：用户在本机设定的值 → 手表同步的目标 → 手表建议值 → 默认值。
 */
object HealthGoals {

    const val DEFAULT_STEP_GOAL = 6_000
    const val MIN_STEP_GOAL = 1_000
    const val MAX_STEP_GOAL = 50_000
    const val STEP_INCREMENT = 100

    val PRESETS = listOf(4_000, 6_000, 8_000, 10_000, 12_000)

    enum class Source { LOCAL, WATCH, DEFAULT }

    data class Resolved(val goal: Int, val source: Source)

    /** 收敛到合法范围并对齐 100 步进 */
    fun normalize(value: Int): Int {
        val clamped = value.coerceIn(MIN_STEP_GOAL, MAX_STEP_GOAL)
        val aligned = ((clamped + STEP_INCREMENT / 2) / STEP_INCREMENT) * STEP_INCREMENT
        return aligned.coerceIn(MIN_STEP_GOAL, MAX_STEP_GOAL)
    }

    /**
     * 目标优先级：本机设定 > 手表目标 > 手表建议 > 默认 6000。
     * 0 或非法值视为「没有这个来源」。
     */
    fun resolve(localGoal: Int, watchGoal: Int, recommendation: Int): Resolved {
        if (localGoal in MIN_STEP_GOAL..MAX_STEP_GOAL) return Resolved(normalize(localGoal), Source.LOCAL)
        if (watchGoal in MIN_STEP_GOAL..MAX_STEP_GOAL) return Resolved(normalize(watchGoal), Source.WATCH)
        if (recommendation in MIN_STEP_GOAL..MAX_STEP_GOAL) {
            return Resolved(normalize(recommendation), Source.DEFAULT)
        }
        return Resolved(DEFAULT_STEP_GOAL, Source.DEFAULT)
    }

    /** 完成度 0f～1f（超额完成也封顶在 1，避免环形进度越界） */
    fun progress(steps: Int, goal: Int): Float {
        if (steps <= 0 || goal <= 0) return 0f
        return (steps.toFloat() / goal).coerceIn(0f, 1f)
    }

    /** 距离目标还差多少步，已达标返回 0 */
    fun remaining(steps: Int, goal: Int): Int {
        if (goal <= 0) return 0
        return (goal - steps).coerceAtLeast(0)
    }

    fun achieved(steps: Int, goal: Int): Boolean = goal > 0 && steps >= goal
}
