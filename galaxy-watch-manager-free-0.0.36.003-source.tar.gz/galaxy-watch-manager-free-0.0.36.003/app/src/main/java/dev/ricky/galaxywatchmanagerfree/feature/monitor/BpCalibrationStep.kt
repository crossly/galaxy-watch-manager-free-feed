package dev.ricky.galaxywatchmanagerfree.feature.monitor

import dev.ricky.galaxywatchmanagerfree.core.UiText

/**
 * 手机驱动的三星健康血压校准状态机步骤。
 *
 * 完整校准由手机端驱动 3 轮测量：
 * 1. [Preparing]：手机通知手表打开准备页面（prepare_calibration），提示绑好袖带。
 * 2. [Measuring]：用户点击开始后，手表启动 30 秒光学采样（start_calibration）。
 * 3. [WaitingCuffInput]：手表采样成功回传 datauuid 与心率，等待用户录入真实袖带血压。
 * 4. [Submitting]：向手表更新袖带读数（update_calibration）。前两轮进入下一轮准备，第三轮自动发送合并指令（initial_calibration）。
 * 5. [Completed]：手表本地 native 算法合并成功，校准完成。
 * 6. [Failed]：测量或更新失败，可重试。
 */
sealed interface BpCalibrationStep {
    data object Idle : BpCalibrationStep

    data class Preparing(val round: Int) : BpCalibrationStep

    data class Measuring(val round: Int) : BpCalibrationStep

    data class WaitingCuffInput(val round: Int, val dataUuid: String, val heartRate: Int) :
        BpCalibrationStep

    data class Submitting(val round: Int) : BpCalibrationStep

    data object Completed : BpCalibrationStep

    data class Failed(val reason: UiText, val round: Int = 1) : BpCalibrationStep
}
