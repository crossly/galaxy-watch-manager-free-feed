package dev.ricky.galaxywatchmanagerfree.feature

import java.io.OutputStream
import java.io.OutputStreamWriter
import java.nio.charset.StandardCharsets
import java.security.DigestOutputStream
import java.security.MessageDigest
import java.time.Instant
import java.time.ZoneId
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import org.json.JSONArray
import org.json.JSONObject

data class HealthExportSnapshot(
    val state: WatchState,
    val sourceRecords: JSONObject,
    val retainedCache: JSONObject = JSONObject(),
    val manualNaps: List<SleepParser.ManualNap> = emptyList(),
    val localSleepResults: JSONObject = JSONObject(),
    val collectionSettings: JSONObject = JSONObject(),
    val dataLocalDate: String? = null,
)

/**
 * Portable, versioned archive. No translated keys, implicit units, pairing secrets or invented
 * samples.
 */
object HealthArchive {
    const val SCHEMA = "galaxy-watch-manager-free.health.v3"

    /** Android's optString renders an explicit JSON null as the text "null". */
    internal fun datasetText(row: JSONObject, key: String): String? =
        if (row.isNull(key)) null else row.optString(key).takeIf(String::isNotBlank)

    fun write(
        output: OutputStream,
        snapshot: HealthExportSnapshot,
        exportedAt: Long,
        zone: ZoneId,
    ) {
        val state = snapshot.state
        val data = HealthExportData(snapshot, zone)
        val entries = JSONArray()
        val datasets = JSONObject()
        ZipOutputStream(output).use { zip ->
            fun entry(name: String, body: (java.io.Writer) -> Unit) {
                zip.putNextEntry(ZipEntry(name))
                val digest = MessageDigest.getInstance("SHA-256")
                val writer =
                    OutputStreamWriter(DigestOutputStream(zip, digest), StandardCharsets.UTF_8)
                body(writer)
                writer.flush()
                zip.closeEntry()
                entries.put(
                    JSONObject()
                        .put("path", name)
                        .put("sha256", digest.digest().joinToString("") { "%02x".format(it) })
                )
            }
            fun json(name: String, value: Any) {
                entry(name) { it.write(value.toString()) }
                if (name == "schema.json") return
                val rows =
                    when {
                        value is JSONArray ->
                            HealthExportData.objects(value).map { row ->
                                row.optJSONObject("session") ?: row
                            }
                        else -> emptyList()
                    }
                val starts = rows.mapNotNull { datasetText(it, "start_time") }.map(Instant::parse)
                val ends = rows.mapNotNull { datasetText(it, "end_time") }.map(Instant::parse)
                val dates =
                    if (name == "sleep_history.json")
                        (value as JSONObject).keys().asSequence().toList()
                    else
                        rows.mapNotNull { row ->
                            datasetText(row, "local_date")
                                ?: datasetText(row, "tracking_local_date")
                        }
                val count =
                    when {
                        name == "snapshot.json" -> 1
                        name == "source_records.json" ->
                            snapshot.sourceRecords.optJSONObject("modules")?.let { modules ->
                                modules.keys().asSequence().sumOf {
                                    modules.getJSONArray(it).length()
                                }
                            } ?: 0
                        value is JSONArray -> value.length()
                        value is JSONObject -> value.length()
                        else -> 0
                    }
                datasets.put(
                    name,
                    JSONObject()
                        .put("record_count", count)
                        .put("first_start_time", starts.minOrNull()?.toString() ?: JSONObject.NULL)
                        .put(
                            "last_end_time",
                            (ends + starts).maxOrNull()?.toString() ?: JSONObject.NULL,
                        )
                        .put("first_local_date", dates.minOrNull() ?: JSONObject.NULL)
                        .put("last_local_date", dates.maxOrNull() ?: JSONObject.NULL)
                        .put("coverage", "retained_only"),
                )
            }
            fun csvRow(writer: java.io.Writer, vararg cells: Any?) {
                writer.write(
                    cells.joinToString(",") { cell ->
                        val value = cell?.toString().orEmpty()
                        "\"" + value.replace("\"", "\"\"") + "\""
                    } + "\r\n"
                )
            }
            fun time(millis: Long): String = Instant.ofEpochMilli(millis).toString()
            val measurements = data.measurements
            json("measurements.json", measurements)
            entry("measurements.csv") { writer ->
                val columns =
                    arrayOf(
                        "record_id",
                        "type",
                        "start_time",
                        "start_time_epoch_ms",
                        "value",
                        "unit",
                        "source",
                        "source_module",
                        "source_record_id",
                        "source_revision_epoch_ms",
                        "source_field",
                        "method",
                        "minimum_value",
                        "maximum_value",
                    )
                csvRow(writer, *columns)
                HealthExportData.objects(measurements).forEach { row ->
                    csvRow(
                        writer,
                        *columns
                            .map { key -> row.opt(key).takeUnless { it == JSONObject.NULL } }
                            .toTypedArray(),
                    )
                }
            }
            json("source_records.json", snapshot.sourceRecords)
            json("retained_cache.json", snapshot.retainedCache)
            json("activity_intervals.json", data.activityIntervals)
            json("floors.json", data.floors)
            json("vascular_load.json", data.vascularLoad)
            json("collection_settings.json", snapshot.collectionSettings)
            val daily = data.dailyActivity
            json("daily_activity.json", daily)
            entry("daily_activity.csv") { writer ->
                val columns =
                    arrayOf(
                        "local_date",
                        "steps",
                        "active_energy_kcal",
                        "distance_m",
                        "source",
                        "coverage",
                    )
                csvRow(writer, *columns)
                HealthExportData.objects(daily).forEach { row ->
                    csvRow(
                        writer,
                        *columns
                            .map { key -> row.opt(key).takeUnless { it == JSONObject.NULL } }
                            .toTypedArray(),
                    )
                }
            }
            val rawExercises = data.records(ExerciseLog.MODULE, ExerciseLog.MODULE_ALIAS)
            val rawRoutines = data.records(ExerciseLog.MODULE_ROUTINE)
            val customExercises = data.records(ExerciseLog.MODULE_CUSTOM).map { it.second }
            val workouts =
                (state.exercises +
                        ExerciseLog.parse(rawExercises.map { it.second }, customExercises) +
                        ExerciseLog.parseRoutines(rawRoutines.map { it.second }, customExercises))
                    .associateBy { it.id }
                    .values
                    .toList()
            val topLevel = ExerciseLog.topLevel(workouts).map { it.id }.toSet()
            fun known(value: Number, minimum: Double = 0.0): Any =
                value.takeIf { it.toDouble().isFinite() && it.toDouble() >= minimum }
                    ?: JSONObject.NULL
            json(
                "workouts.json",
                JSONArray(
                    workouts.map { row ->
                        val original =
                            (rawExercises + rawRoutines).firstOrNull {
                                it.second.optString("datauuid") == row.id
                            }
                        JSONObject()
                            .put("record_id", row.id)
                            .put("samsung_type_code", row.typeCode)
                            .put("start_time", time(row.startMillis))
                            .put("start_time_epoch_ms", row.startMillis)
                            .put("end_time", time(row.endMillis))
                            .put("active_duration_ms", row.durationMillis)
                            .put("distance_m", known(row.distanceMeters))
                            .put("energy_kcal", known(row.calories))
                            .put("average_heart_rate_bpm", known(row.avgHeartRate, 1.0))
                            .put("max_heart_rate_bpm", known(row.maxHeartRate, 1.0))
                            .put("min_heart_rate_bpm", known(row.minHeartRate, 1.0))
                            .put("steps", known(row.stepCount))
                            .put(
                                "auto_detected",
                                if (row.sourceType >= 0) row.autoDetected else JSONObject.NULL,
                            )
                            .put("source_type", known(row.sourceType))
                            .put("title", row.title.takeIf { it.isNotBlank() } ?: JSONObject.NULL)
                            .put("count", known(row.count))
                            .put("count_type", known(row.countType))
                            .put("mean_speed_m_per_s", known(row.meanSpeed))
                            .put("max_speed_m_per_s", known(row.maxSpeed))
                            .put("altitude_gain_m", known(row.altitudeGain))
                            .put("altitude_loss_m", known(row.altitudeLoss))
                            .put(
                                "routine_id",
                                row.routineId.takeIf { it.isNotBlank() } ?: JSONObject.NULL,
                            )
                            .put("is_top_level", row.id in topLevel)
                            .put("location_payload_present", row.locationPayloadPresent)
                            .put("location_point_count", row.locationPointCount)
                            .put("source", if (original == null) "retained_app_cache" else "watch")
                            .put("source_module", original?.first ?: JSONObject.NULL)
                            .put(
                                "source_revision_epoch_ms",
                                original?.second?.optLong("update_time")?.takeIf { it > 0 }
                                    ?: JSONObject.NULL,
                            )
                    }
                ),
            )
            json(
                "blood_pressure.json",
                JSONArray().apply {
                    state.bpRecords.forEach { row ->
                        put(
                            JSONObject()
                                .put("record_id", row.id)
                                .put("start_time", time(row.startTime))
                                .put("systolic_mmHg", row.systolic)
                                .put("diastolic_mmHg", row.diastolic)
                                .put(
                                    "pulse_bpm",
                                    row.heartRate.takeIf { it > 0 } ?: JSONObject.NULL,
                                )
                        )
                    }
                },
            )
            val daySessions = state.sleepSessions.ifEmpty { listOfNotNull(state.sleep) }
            json("latest_sleep.json", JSONArray(listOfNotNull(state.sleep).map(data::sleepJson)))
            json("latest_sleep_sessions.json", JSONArray(daySessions.map(data::sleepJson)))
            json("sleep_sessions.json", JSONArray(data.sleepSessions.map(data::sleepJson)))
            json(
                "manual_naps.json",
                JSONArray(snapshot.manualNaps.map { data.sleepJson(SleepParser.manualSession(it)) }),
            )
            json("local_sleep_analysis.json", data.localSleepAnalysis)
            json(
                "sleep_history.json",
                JSONObject(state.sleepHistory + SleepParser.historyByDay(data.sleepSessions, zone)),
            )
            val heartDays =
                (HeartRateLog.decodeDays(snapshot.retainedCache.optString("hr_days")) +
                        state.heartRateDays)
                    .toMutableMap()
            val heartPoints =
                HealthExportData.objects(measurements)
                    .filter { it.getString("type") == "heart_rate" }
                    .map { row ->
                        val bpm = row.getInt("value")
                        HeartRateLog.Point(
                            row.getLong("start_time_epoch_ms"),
                            bpm,
                            row.optInt("minimum_value", bpm),
                            row.optInt("maximum_value", bpm),
                        )
                    }
                    .associateBy { it.ts }
                    .values
                    .toList()
            HeartRateLog.byDay(heartPoints, zone).forEach { (date, points) ->
                HeartRateLog.stats(points)?.let { stats ->
                    if (stats.count >= (heartDays[date]?.count ?: 0)) heartDays[date] = stats
                }
            }
            json(
                "heart_rate_daily.json",
                JSONArray(
                    heartDays.toSortedMap().map { (date, stats) ->
                        JSONObject()
                            .put("local_date", date)
                            .put("minimum_bpm", stats.min)
                            .put("average_bpm", stats.avg)
                            .put("maximum_bpm", stats.max)
                            .put("sample_count", stats.count)
                    }
                ),
            )
            val stressDays =
                (StressLog.decodeDays(snapshot.retainedCache.optString("stress_days")) +
                        state.stressDays)
                    .toMutableMap()
            val stressPoints =
                HealthExportData.objects(measurements)
                    .filter { it.getString("type") == "stress" }
                    .map { row ->
                        val score = row.getDouble("value").toFloat()
                        StressLog.Point(
                            row.getLong("start_time_epoch_ms"),
                            score,
                            row.optDouble("minimum_value", score.toDouble()).toFloat(),
                            row.optDouble("maximum_value", score.toDouble()).toFloat(),
                        )
                    }
                    .associateBy { it.ts }
                    .values
                    .toList()
            StressLog.byDay(stressPoints, zone).forEach { (date, points) ->
                StressLog.stats(points)?.let { stats ->
                    if (stats.count >= (stressDays[date]?.count ?: 0)) stressDays[date] = stats
                }
            }
            json(
                "stress_daily.json",
                JSONArray(
                    stressDays.toSortedMap().map { (date, stats) ->
                        JSONObject()
                            .put("local_date", date)
                            .put("minimum_score", stats.min)
                            .put("average_score", stats.avg)
                            .put("maximum_score", stats.max)
                            .put("sample_count", stats.count)
                    }
                ),
            )
            val ecg = JSONArray()
            state.ecgRecords.forEachIndexed { index, row ->
                val file = if (row.waveform.isNotEmpty()) "ecg/record-${index + 1}.csv" else null
                ecg.put(
                    JSONObject()
                        .put("record_id", row.id)
                        .put("start_time", time(row.startTime))
                        .put("start_time_epoch_ms", row.startTime)
                        .put(
                            "average_heart_rate_bpm",
                            row.heartRate.takeIf { it > 0 } ?: JSONObject.NULL,
                        )
                        .put("samsung_classification_code", row.classification)
                        .put("sample_rate_hz", row.sampleRate)
                        .put("sample_count", row.waveform.size)
                        .put("voltage_unit", "mV")
                        .put("waveform_file", file ?: JSONObject.NULL)
                        .put("source", "watch_samsung_health_monitor")
                )
                if (file != null)
                    entry(file) { writer ->
                        csvRow(writer, "sample_index", "time_offset_seconds", "voltage_mV")
                        row.waveform.forEachIndexed { sample, value ->
                            require(
                                value.isFinite() && row.sampleRate.isFinite() && row.sampleRate > 0
                            )
                            csvRow(writer, sample, sample / row.sampleRate, value)
                        }
                    }
            }
            json("ecg.json", ecg)
            val exportDate = Instant.ofEpochMilli(exportedAt).atZone(zone).toLocalDate().toString()
            val dataDate =
                data.dateKey(snapshot.dataLocalDate ?: snapshot.retainedCache.optString("day"))
            val floorsDate =
                data.dateKey(snapshot.retainedCache.optString("floors_day")) ?: dataDate
            json(
                "snapshot.json",
                JSONObject()
                    .put("last_health_sync_epoch_ms", state.lastHealthSyncTime)
                    .put("today_local_date", exportDate)
                    .put("data_local_date", dataDate ?: JSONObject.NULL)
                    .put("data_day_steps", state.todaySteps.takeIf { it >= 0 } ?: JSONObject.NULL)
                    .put("data_day_floors", state.todayFloors.takeIf { it >= 0 } ?: JSONObject.NULL)
                    .put("floors_local_date", floorsDate ?: JSONObject.NULL)
                    .put(
                        "today_steps",
                        state.todaySteps.takeIf { it >= 0 && dataDate == exportDate }
                            ?: JSONObject.NULL,
                    )
                    .put(
                        "today_floors",
                        state.todayFloors.takeIf { it >= 0 && floorsDate == exportDate }
                            ?: JSONObject.NULL,
                    )
                    .put("last_stress_time", state.latestStress?.ts?.let(::time) ?: JSONObject.NULL)
                    .put(
                        "last_stress_score",
                        state.lastStressScore.takeIf { it >= 0 } ?: JSONObject.NULL,
                    )
                    .put("step_goal", state.stepGoal)
                    .put("step_goal_source", state.stepGoalSource.name),
            )
            json("schema.json", HealthExportSchema.document)
            entry("README.md") { it.write(README) }
            zip.putNextEntry(ZipEntry("manifest.json"))
            zip.write(
                JSONObject()
                    .put("schema", SCHEMA)
                    .put("exported_at", time(exportedAt))
                    .put("time_zone", zone.id)
                    .put("watch_model", state.modelNumber)
                    .put("measurement_count", measurements.length())
                    .put("ecg_count", state.ecgRecords.size)
                    .put("bp_count", state.bpRecords.size)
                    .put("files", entries)
                    .put("scope", "retained_local_current_device")
                    .put("datasets", datasets)
                    .put(
                        "source_modules",
                        JSONObject().apply {
                            val modules =
                                snapshot.sourceRecords.optJSONObject("modules") ?: JSONObject()
                            modules.keys().asSequence().sorted().forEach { module ->
                                val rows = data.records(module).map { it.second }
                                val timestamps =
                                    rows.flatMap { row ->
                                        listOf("start_time", "end_time").mapNotNull { key ->
                                            row.optLong(key).takeIf { it >= 946_684_800_000L }
                                        }
                                    }
                                put(
                                    module,
                                    JSONObject()
                                        .put("record_count", rows.size)
                                        .put(
                                            "first_time",
                                            timestamps.minOrNull()?.let(::time) ?: JSONObject.NULL,
                                        )
                                        .put(
                                            "last_time",
                                            timestamps.maxOrNull()?.let(::time) ?: JSONObject.NULL,
                                        )
                                        .put(
                                            "retention_days",
                                            HealthRecordStore.retentionDays(module)
                                                ?: JSONObject.NULL,
                                        )
                                        .put("record_limit", HealthRecordStore.recordLimit(module))
                                        .put("previously_truncated", "unknown"),
                                )
                            }
                        },
                    )
                    .put(
                        "retention",
                        JSONObject()
                            .put("raw_default_days", 30)
                            .put("ecg_record_limit", 100)
                            .put("bp_record_limit", 100)
                            .put("export_applies_additional_trimming", false)
                            .put("previously_deleted_data", "unavailable")
                            .put("manual_naps", "all_retained")
                            .put("local_sleep_analysis", "all_retained_versions"),
                    )
                    .put(
                        "sync",
                        JSONObject()
                            .put("status", state.healthSyncStatus.name)
                            .put(
                                "last_health_sync_epoch_ms",
                                state.lastHealthSyncTime.takeIf { it > 0 } ?: JSONObject.NULL,
                            )
                            .put("historical_completeness", "unknown"),
                    )
                    .toString(2)
                    .toByteArray(StandardCharsets.UTF_8)
            )
            zip.closeEntry()
        }
    }

    private val README =
        """
        # Galaxy Watch Manager Free health export
        Schema: galaxy-watch-manager-free.health.v3
        Read manifest.json first. schema.json maps every JSON file to a machine-readable definition.
        Each listed file includes a SHA-256 of its uncompressed bytes. datasets reports counts and retained
        timestamp/date ranges; sync status never proves complete watch history. Previous truncation is unknown.
        UTF-8 JSON and RFC 4180 CSV; decimal separator is a dot. Timestamps use UTC ISO 8601;
        epoch fields are milliseconds. time_zone is export context, not the original zone of every measurement.
        measurements.json/csv includes all eligible retained history, independent of UI windows. BP pairs
        share record_id. Source module/record/revision and source fields are included when known. IDs for
        raw-derived quantities are stable per source record, sample time and method; cached-only provenance
        and revisions can be unknown. HRV method is rmssd, sdnn or unknown; never convert one into another.
        Stress uses Samsung raw score, not the scaled display score. Skin temperature is not core temperature.
        activity_intervals, daily_activity and raw steps are alternative views; do not add them together.
        Daily coverage is explicit; ambiguous legacy zeros remain null. No missing measurement is fabricated.
        workouts includes routine_id and is_top_level; sum top-level sessions to avoid parent/child duplication.
        sleep_sessions includes all retained canonical sessions, including manual naps. manual_naps preserves
        every manual interval; local_sleep_analysis preserves every cached inference version and its source.
        These are overlapping views, not extra independent sleep. Latest sleep files are display snapshots.
        Sleep score is the watch quality; computed_score is the local 1.4.24 night score (1-99 or null).
        computed_score_algorithm identifies that calculation even when score_source is watch. The current
        local algorithm is computed_shealth_1_4_24; incomplete stages have no computed score or algorithm.
        v3 replaces the v2 computed_v1 formula and score_source value; compare local scores by algorithm.
        source_records retains original module fields and revisions, including compressed sensor payloads;
        retained_cache preserves older cached data. Raw-only or invalid/unrecognized fields are not lost.
        collection_settings distinguishes confirmed values, pending intent and last received watch revisions.
        snapshot.data_local_date identifies the data day; today fields remain null when that date is stale.
        ecg.json references complete waveform CSVs in mV with sample index and time offset at the supplied rate.
        Only data retained on this phone for the selected device is exported. Raw records normally retain
        30 days with per-module limits (exercise and vascular load have no time cutoff); ECG/BP retain 100.
        Vascular band applies only to measurement rows; baseline and reset rows have null band.
        Export adds no retention trimming. Unsynchronized or deleted data cannot be reconstructed.
        This package contains sensitive health data; share it only as intended.
        This ZIP is a portable dataset, NOT an Apple Health import file or an app-restoration backup.
        Authorized platform importers are separate work. Apple ECG and appleSleepingWristTemperature objects
        are read-only; third-party samples cannot be inserted. Health Connect HRV is RMSSD; Apple HRV is SDNN.
        Huawei and HONOR require their own platform authorization. No vendor-app or watch-backfill guarantee.
    """
            .trimIndent()
}
