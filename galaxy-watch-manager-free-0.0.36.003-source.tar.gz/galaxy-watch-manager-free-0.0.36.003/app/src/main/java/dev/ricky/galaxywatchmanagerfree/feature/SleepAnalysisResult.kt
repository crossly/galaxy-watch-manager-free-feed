package dev.ricky.galaxywatchmanagerfree.feature

import org.json.JSONObject

/** Converts verified 30-second inference epochs into the same model as received sleep stages. */
object SleepAnalysisResult {
    const val SOURCE = "local_sensor_v1"

    fun apply(session: SleepParser.Session, result: JSONObject): SleepParser.Session {
        val points = result.getJSONArray("stages")
        require(points.length() in 1..2880)
        val segments = ArrayList<SleepParser.Segment>()
        var previousEnd = 0L
        for (i in 0 until points.length()) {
            val point = points.getJSONArray(i)
            val start = point.getLong(0)
            val end = start + 30_000L
            require(start > 0 && start >= session.startMillis && end <= session.endMillis)
            require(previousEnd == 0L || start == previousEnd)
            val stage = when (point.getInt(1)) {
                0 -> SleepParser.Stage.DEEP
                1 -> SleepParser.Stage.LIGHT
                2 -> SleepParser.Stage.AWAKE
                3 -> SleepParser.Stage.REM
                else -> error("Unsupported inferred sleep stage")
            }
            val last = segments.lastOrNull()
            if (last?.stage == stage) segments[segments.lastIndex] = last.copy(endMillis = end)
            else segments.add(SleepParser.Segment(start, end, stage))
            previousEnd = end
        }
        return session.copy(startMillis = segments.first().startMillis, endMillis = segments.last().endMillis,
            segments = segments, efficiency = null, reportedSleepMinutes = null,
            analysisSource = SOURCE, recordedEndMillis = session.endMillis)
    }
}
