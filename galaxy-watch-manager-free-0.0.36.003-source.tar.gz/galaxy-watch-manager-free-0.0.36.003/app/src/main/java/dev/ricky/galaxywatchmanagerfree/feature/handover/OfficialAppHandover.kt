package dev.ricky.galaxywatchmanagerfree.feature.handover

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import android.os.Process
import dev.ricky.galaxywatchmanagerfree.BuildConfig
import dev.ricky.galaxywatchmanagerfree.handover.IHandoverService
import java.util.concurrent.Callable
import java.util.concurrent.ExecutionException
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import rikka.shizuku.Shizuku

/**
 * Optional, reversible handover of the watch's Bluetooth channel from the official companion apps.
 * - Ordinary use never needs Shizuku: this class is only constructed by the handover card.
 * - Disabling and restoring both require [ShizukuAccess.AVAILABLE] and a bound shell user service.
 * - Before anything is disabled, the exact enabled state of every app that is about to change is
 *   committed to [HandoverSnapshotStore]. Old entries are never overwritten.
 * - Every privileged package name is re-checked against [OfficialCompanionApp] inside the shell
 *   process; no command string is ever built or executed.
 * - All package operations are serialized; shell calls run on a dedicated worker with a bounded
 *   asynchronous wait, so the UI thread never executes a Binder package call.
 */
class OfficialAppHandover(context: Context) {

    private val appContext = context.applicationContext
    private val store = HandoverSnapshotStore(appContext)
    private val io = Dispatchers.IO
    // UserHandle.getIdentifier()/myUserHandle() are not public SDK APIs; an app UID is
    // userId * PER_USER_RANGE + appId, so this is the same concrete user without reflection.
    private val userId = Process.myUid() / PER_USER_RANGE

    private val _state = MutableStateFlow(OfficialHandoverState())
    val state: StateFlow<OfficialHandoverState> = _state.asStateFlow()

    /** 运行→关闭延迟→已关闭 的显式生命周期；见 [close] 与 [finishOperation]。 */
    private enum class HandoverLifecycle {
        STOPPED,
        STARTING,
        IDLE,
        OPERATING,
        CLOSING_DEFERRED,
    }

    private var scope = newScope()
    @Volatile private var serviceExecutor: ExecutorService = newServiceExecutor()

    @Volatile private var service: IHandoverService? = null
    @Volatile private var bound = false
    @Volatile private var lifecycle = HandoverLifecycle.STOPPED

    private val bindLock = Any()
    private var connectWaiter: CompletableDeferred<IHandoverService?>? = null

    private val serviceArgs =
        Shizuku.UserServiceArgs(
                ComponentName(appContext.packageName, HandoverUserService::class.java.name)
            )
            .daemon(false)
            .processNameSuffix(PROCESS_NAME_SUFFIX)
            .tag(SERVICE_TAG)
            .version(SERVICE_API_VERSION)
            .debuggable(BuildConfig.DEBUG)

    private val connection =
        object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
                val connected = binder?.let { IHandoverService.Stub.asInterface(it) }
                service = connected
                synchronized(bindLock) {
                    connectWaiter?.complete(connected)
                    connectWaiter = null
                }
                if (connected != null) scope.launch { refresh() }
            }

            override fun onServiceDisconnected(name: ComponentName?) {
                service = null
                synchronized(bindLock) {
                    connectWaiter?.complete(null)
                    connectWaiter = null
                }
                _state.update {
                    it.copy(
                        access = detectAccess(),
                        busy = false,
                        message = "Shizuku shell service disconnected",
                    )
                }
            }
        }

    private val permissionListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == REQUEST_PERMISSION_CODE) {
                val granted = grantResult == PackageManager.PERMISSION_GRANTED
                _state.update {
                    it.copy(
                        access = detectAccess(),
                        busy = false,
                        message = if (granted) null else "Shizuku permission was denied",
                    )
                }
                if (granted) scope.launch { refresh() }
            }
        }

    private val binderReceivedListener =
        Shizuku.OnBinderReceivedListener {
            _state.update { it.copy(access = detectAccess()) }
            scope.launch { refresh() }
        }

    private val binderDeadListener =
        Shizuku.OnBinderDeadListener {
            service = null
            synchronized(bindLock) {
                connectWaiter?.complete(null)
                connectWaiter = null
            }
            _state.update {
                it.copy(access = detectAccess(), busy = false, message = "Shizuku stopped")
            }
        }

    fun start() {
        if (lifecycle != HandoverLifecycle.STOPPED) return
        lifecycle = HandoverLifecycle.STARTING
        scope = newScope()
        if (serviceExecutor.isShutdown) serviceExecutor = newServiceExecutor()
        Shizuku.addRequestPermissionResultListener(permissionListener)
        Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
        Shizuku.addBinderDeadListener(binderDeadListener)
        scope.launch { refresh() }
    }

    fun close() {
        if (lifecycle == HandoverLifecycle.STOPPED) return
        // A disable/restore transaction may still be rolling back on its own coroutine. Releasing
        // the shell binding or the worker now would cut that rollback short.
        if (
            lifecycle == HandoverLifecycle.OPERATING ||
                lifecycle == HandoverLifecycle.CLOSING_DEFERRED
        ) {
            lifecycle = HandoverLifecycle.CLOSING_DEFERRED
            return
        }
        performClose()
    }

    private fun performClose() {
        lifecycle = HandoverLifecycle.STOPPED
        runCatching { Shizuku.removeRequestPermissionResultListener(permissionListener) }
        runCatching { Shizuku.removeBinderReceivedListener(binderReceivedListener) }
        runCatching { Shizuku.removeBinderDeadListener(binderDeadListener) }
        service = null
        synchronized(bindLock) {
            connectWaiter?.cancel()
            connectWaiter = null
        }
        if (bound) {
            runCatching {
                if (Shizuku.pingBinder()) {
                    Shizuku.unbindUserService(serviceArgs, connection, false)
                }
            }
            bound = false
        }
        scope.cancel()
        serviceExecutor.shutdownNow()
    }

    private fun finishOperation() {
        when (lifecycle) {
            HandoverLifecycle.OPERATING -> lifecycle = HandoverLifecycle.IDLE
            HandoverLifecycle.CLOSING_DEFERRED -> performClose()
            else -> Unit
        }
    }

    fun requestAuthorization() {
        scope.launch {
            _state.update { it.copy(busy = true) }
            try {
                val access = withContext(io) { detectAccess() }
                when (access) {
                    ShizukuAccess.AVAILABLE -> {
                        _state.update { it.copy(access = access, message = null) }
                        refresh()
                    }
                    ShizukuAccess.NOT_INSTALLED ->
                        _state.update {
                            it.copy(
                                access = access,
                                message =
                                    "Shizuku is not installed; use the manual app-details steps.",
                            )
                        }
                    ShizukuAccess.NOT_RUNNING ->
                        _state.update {
                            it.copy(
                                access = access,
                                message =
                                    "Shizuku is installed but not running; start it, then retry.",
                            )
                        }
                    ShizukuAccess.UNSUPPORTED ->
                        _state.update {
                            it.copy(
                                access = access,
                                message =
                                    "This Shizuku server is too old; use the manual app-details steps.",
                            )
                        }
                    ShizukuAccess.NEEDS_PERMISSION,
                    ShizukuAccess.DENIED -> {
                        withContext(io) { Shizuku.requestPermission(REQUEST_PERMISSION_CODE) }
                        _state.update { it.copy(access = access, message = null) }
                    }
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Throwable) {
                _state.update {
                    it.copy(message = "Could not request Shizuku permission: ${describe(error)}")
                }
            } finally {
                _state.update { it.copy(busy = false) }
            }
        }
    }

    suspend fun refresh() {
        operationMutex.withLock {
            _state.update { it.copy(busy = true) }
            try {
                publish(queryApps())
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Throwable) {
                _state.update { it.copy(message = "Could not read app states: ${describe(error)}") }
            } finally {
                _state.update { it.copy(busy = false) }
                if (lifecycle == HandoverLifecycle.STARTING) lifecycle = HandoverLifecycle.IDLE
            }
        }
    }

    suspend fun disableOfficialApps(): Boolean =
        operationMutex.withLock {
            lifecycle = HandoverLifecycle.OPERATING
            _state.update { it.copy(busy = true) }
            var journalBefore: HandoverJournal? = null
            var journalAfter: HandoverJournal? = null
            var shellForRollback: IHandoverService? = null
            val attempted = ArrayList<String>()
            try {
                val access = withContext(io) { detectAccess() }
                if (access != ShizukuAccess.AVAILABLE) {
                    publish(queryApps())
                    _state.update {
                        it.copy(message = "Shizuku permission is required to disable apps")
                    }
                    return@withLock false
                }

                val remote = withContext(io) { queryRemoteStates() }
                if (remote == null) {
                    publish(queryApps())
                    _state.update {
                        it.copy(
                            message = "Shizuku shell service did not respond; nothing was disabled"
                        )
                    }
                    return@withLock false
                }
                val shell = service
                if (shell == null) {
                    publish(queryApps())
                    _state.update {
                        it.copy(
                            message = "Shizuku shell service is unavailable; nothing was disabled"
                        )
                    }
                    return@withLock false
                }
                shellForRollback = shell

                val before = withContext(io) { store.load() }
                journalBefore = before
                val enableStates =
                    OfficialCompanionApp.entries.mapNotNull { app ->
                        val observed = remote[app.packageName] ?: return@mapNotNull null
                        if (observed.installed && HandoverPolicy.canDisable(observed.state)) {
                            app.packageName to observed.state
                        } else {
                            null
                        }
                    }
                val after = before.snapshot(enableStates.toMap())
                journalAfter = after

                if (enableStates.isEmpty()) {
                    publish(queryApps())
                    return@withLock true
                }

                // Commit the restore point before changing any package. This runs on every
                // attempt: a previously failed commit must not be assumed durable just because
                // SharedPreferences already updated its in-memory copy.
                if (!withContext(io) { store.save(after) }) {
                    journalAfter = null
                    publish(queryApps())
                    _state.update {
                        it.copy(message = "Could not save the restore point; nothing was disabled")
                    }
                    return@withLock false
                }

                var failure: String? = null
                for ((packageName, _) in enableStates) {
                    attempted += packageName
                    val observed =
                        callService(shell) {
                            shell.setEnabledState(
                                packageName,
                                HandoverPolicy.DISABLE_TARGET,
                                userId,
                            )
                        }
                    if (observed != HandoverPolicy.DISABLE_TARGET) {
                        failure =
                            "$packageName did not stay disabled (observed ${observed ?: "no response"})"
                        break
                    }
                }

                if (failure == null) {
                    val result = queryApps()
                    publish(result)
                    return@withLock true
                }

                // Roll back every package this attempt touched, including the failing one. The
                // journal is kept for any package whose rollback cannot be verified.
                val rollback = rollbackDisable(shell, attempted, after, before)
                val result = queryApps()
                publish(result)
                _state.update {
                    it.copy(message = rollbackMessage(failure ?: "Disable failed", rollback))
                }
                return@withLock false
            } catch (cancelled: CancellationException) {
                // Rotation/navigation cancels the UI scope. Restore what this attempt already
                // disabled before the shell binding is released.
                val shell = shellForRollback
                val after = journalAfter
                val before = journalBefore
                if (shell != null && after != null && before != null && attempted.isNotEmpty()) {
                    withContext(NonCancellable) {
                        runCatching { rollbackDisable(shell, attempted, after, before) }
                    }
                }
                throw cancelled
            } catch (error: Throwable) {
                // A Binder/timeout exception outside the per-package loop must not skip rollback.
                val before = journalBefore
                val after = journalAfter
                val shell = shellForRollback
                val rollback =
                    if (
                        before != null && after != null && shell != null && attempted.isNotEmpty()
                    ) {
                        try {
                            rollbackDisable(shell, attempted, after, before)
                        } catch (cancelled: CancellationException) {
                            throw cancelled
                        } catch (_: Throwable) {
                            RollbackOutcome(problems = attempted, saved = false)
                        }
                    } else {
                        null
                    }
                publish(queryApps())
                _state.update {
                    it.copy(
                        message =
                            rollbackMessage(
                                "Could not disable official apps: ${describe(error)}",
                                rollback,
                            )
                    )
                }
                return@withLock false
            } finally {
                _state.update { it.copy(busy = false) }
                finishOperation()
            }
        }

    suspend fun restoreOfficialApps(): Boolean =
        operationMutex.withLock {
            lifecycle = HandoverLifecycle.OPERATING
            _state.update { it.copy(busy = true) }
            try {
                val journal = withContext(io) { store.load() }
                val local = withContext(io) { queryLocalStates() }
                val localFallbackRequired =
                    OfficialCompanionApp.entries.any { app ->
                        val observed = local[app.packageName]
                        observed?.installed == true &&
                            observed.state?.let(HandoverPolicy::needsRestore) == true
                    }
                if (journal.isEmpty && !localFallbackRequired) {
                    publish(queryApps())
                    return@withLock true
                }

                if (withContext(io) { detectAccess() } != ShizukuAccess.AVAILABLE) {
                    publish(queryApps())
                    _state.update {
                        it.copy(message = "Shizuku permission is required to restore apps")
                    }
                    return@withLock false
                }

                val remote = withContext(io) { queryRemoteStates() }
                val shell = service
                if (remote == null || shell == null) {
                    publish(queryApps())
                    _state.update {
                        it.copy(
                            message = "Shizuku shell service did not respond; nothing was restored"
                        )
                    }
                    return@withLock false
                }

                var remaining = journal
                val failures = mutableListOf<String>()
                for (app in OfficialCompanionApp.entries) {
                    val packageName = app.packageName
                    val original = journal.originalStates[packageName]
                    val observed = remote[packageName]
                    if (observed == null) {
                        if (original != null) failures += "$packageName: state unavailable"
                        continue
                    }
                    // An uninstalled package has no enabled override left to restore. Removing the
                    // entry also avoids a permanently failing restore point.
                    if (!observed.installed) {
                        if (original != null) {
                            remaining = remaining.without(setOf(packageName))
                        }
                        continue
                    }
                    val target = HandoverPolicy.restoreTarget(original, observed.state)
                    if (target == null) continue
                    if (observed.state == target) {
                        if (original != null) {
                            remaining = remaining.without(setOf(packageName))
                        }
                        continue
                    }

                    val set =
                        callService(shell) { shell.setEnabledState(packageName, target, userId) }
                    if (set == target) {
                        if (original != null) {
                            remaining = remaining.without(setOf(packageName))
                        }
                    } else {
                        failures +=
                            "$packageName: observed ${set ?: "no response"}, expected $target"
                    }
                }

                val saved = withContext(io) { store.save(remaining) }
                val result = queryApps()
                publish(result)
                val message =
                    when {
                        failures.isNotEmpty() ->
                            "Some apps could not be restored: ${failures.joinToString("; ")}"
                        !saved -> "Could not persist restore progress"
                        else -> null
                    }
                _state.update { it.copy(message = message) }
                return@withLock failures.isEmpty() && saved
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Throwable) {
                publish(queryApps())
                _state.update {
                    it.copy(message = "Could not restore official apps: ${describe(error)}")
                }
                return@withLock false
            } finally {
                _state.update { it.copy(busy = false) }
                finishOperation()
            }
        }

    private suspend fun rollbackDisable(
        shell: IHandoverService,
        attempted: List<String>,
        journalAfter: HandoverJournal,
        journalBefore: HandoverJournal,
    ): RollbackOutcome {
        val problems = mutableListOf<String>()
        var remaining = journalAfter
        for (packageName in attempted) {
            val original = journalAfter.originalStates[packageName] ?: continue
            val observed =
                callService(shell) { shell.setEnabledState(packageName, original, userId) }
            if (observed == original) {
                remaining = remaining.without(setOf(packageName))
            } else {
                problems += packageName
            }
        }
        val neverChanged = journalAfter.packages - journalBefore.packages - attempted.toSet()
        remaining = remaining.without(neverChanged)
        val saved =
            try {
                withContext(io) { store.save(remaining) }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Throwable) {
                false
            }
        return RollbackOutcome(problems = problems, saved = saved)
    }

    private fun rollbackMessage(base: String, outcome: RollbackOutcome?): String = buildString {
        append(base)
        if (outcome != null) {
            if (outcome.problems.isNotEmpty()) {
                append("; rollback failed for ${outcome.problems.joinToString()}")
            }
            if (!outcome.saved) append("; could not persist restore progress")
        }
    }

    private data class RollbackOutcome(val problems: List<String>, val saved: Boolean)

    private suspend fun publish(result: SnapshotResult) {
        _state.update {
            it.copy(
                access = result.access,
                apps = result.apps,
                hasRestorePoint = result.hasRestorePoint,
                message = result.warning,
            )
        }
    }

    private suspend fun queryApps(): SnapshotResult =
        withContext(io) {
            val access = detectAccess()
            val remote = if (access == ShizukuAccess.AVAILABLE) queryRemoteStates() else null
            val local = queryLocalStates()
            SnapshotResult(
                access = access,
                apps = mergeApps(remote, local),
                warning =
                    if (access == ShizukuAccess.AVAILABLE && remote == null) {
                        "Shizuku is allowed but its shell service did not respond; showing phone-reported states."
                    } else {
                        null
                    },
                hasRestorePoint = !store.load().isEmpty,
            )
        }

    private fun mergeApps(
        remote: Map<String, RemoteAppState>?,
        local: Map<String, LocalAppState>,
    ): List<OfficialAppStatus> =
        OfficialCompanionApp.entries.map { app ->
            val localState = local[app.packageName]
            val remoteState = remote?.get(app.packageName)
            val installed = remoteState?.installed ?: localState?.installed
            val state = remoteState?.state ?: localState?.state ?: EnabledState.UNKNOWN
            OfficialAppStatus(
                packageName = app.packageName,
                displayName = localState?.label?.takeIf { it.isNotBlank() } ?: app.fallbackName,
                enabled = installed != false && HandoverPolicy.isEnabled(state),
                installed = installed,
                enabledState = state,
            )
        }

    private suspend fun queryRemoteStates(): Map<String, RemoteAppState>? {
        val shell = ensureService() ?: return null
        return try {
            val api = callService(shell) { shell.apiVersion } ?: return null
            if (api != SERVICE_API_VERSION) return null

            val entries = callService(shell) { shell.getPackageStates(userId) } ?: return null
            val parsed = LinkedHashMap<String, RemoteAppState>()
            for (entry in entries) {
                val parts = entry.split('|')
                if (parts.size != 3) return null
                val app = OfficialCompanionApp.find(parts[0]) ?: return null
                val installed =
                    when (parts[1]) {
                        "1" -> true
                        "0" -> false
                        else -> return null
                    }
                val state = parts[2].toIntOrNull() ?: return null
                parsed[app.packageName] = RemoteAppState(installed = installed, state = state)
            }
            if (parsed.size != OfficialCompanionApp.entries.size) null else parsed
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (error: Throwable) {
            null
        }
    }

    private fun queryLocalStates(): Map<String, LocalAppState> {
        val packageManager = appContext.packageManager
        val result = LinkedHashMap<String, LocalAppState>()
        for (app in OfficialCompanionApp.entries) {
            var installed: Boolean? = null
            var label: String? = null
            try {
                val info = packageManager.getApplicationInfo(app.packageName, 0)
                installed = true
                label = runCatching { info.loadLabel(packageManager).toString() }.getOrNull()
            } catch (_: PackageManager.NameNotFoundException) {
                installed = false
            } catch (_: Exception) {
                installed = null
            }
            val state =
                if (installed == true) {
                    runCatching { packageManager.getApplicationEnabledSetting(app.packageName) }
                        .getOrNull()
                } else {
                    null
                }
            result[app.packageName] =
                LocalAppState(installed = installed, state = state, label = label)
        }
        return result
    }

    private suspend fun ensureService(): IHandoverService? {
        service?.let { existing -> if (existing.asBinder().isBinderAlive) return existing }

        val (waiter, owner) =
            synchronized(bindLock) {
                val existing = connectWaiter
                if (existing != null) {
                    existing to false
                } else {
                    val created = CompletableDeferred<IHandoverService?>()
                    connectWaiter = created
                    created to true
                }
            }

        if (owner) {
            val requested =
                try {
                    if (!Shizuku.pingBinder()) {
                        false
                    } else {
                        Shizuku.bindUserService(serviceArgs, connection)
                        bound = true
                        true
                    }
                } catch (_: Throwable) {
                    false
                }
            if (!requested) {
                synchronized(bindLock) { if (connectWaiter === waiter) connectWaiter = null }
                waiter.complete(null)
                return null
            }
        }

        val connected = withTimeoutOrNull(BIND_TIMEOUT_MS) { waiter.await() }
        if (connected == null) {
            synchronized(bindLock) { if (connectWaiter === waiter) connectWaiter = null }
        }
        return connected
    }

    private suspend fun <T> callService(shell: IHandoverService, block: () -> T): T? =
        withContext(io) {
            if (shell.asBinder() == null) return@withContext null
            val future =
                try {
                    serviceExecutor.submit(Callable<T> { block() })
                } catch (_: RejectedExecutionException) {
                    return@withContext null
                }
            try {
                future.get(CALL_TIMEOUT_MS, TimeUnit.MILLISECONDS)
            } catch (_: TimeoutException) {
                future.cancel(true)
                null
            } catch (_: ExecutionException) {
                null
            } catch (_: InterruptedException) {
                Thread.currentThread().interrupt()
                null
            } catch (_: Exception) {
                null
            }
        }

    private fun detectAccess(): ShizukuAccess {
        if (Shizuku.pingBinder()) {
            if (Shizuku.isPreV11()) return ShizukuAccess.UNSUPPORTED
            val version = runCatching { Shizuku.getVersion() }.getOrDefault(-1)
            if (version in 1..10) return ShizukuAccess.UNSUPPORTED
            val granted =
                runCatching { Shizuku.checkSelfPermission() }
                    .getOrDefault(PackageManager.PERMISSION_DENIED)
            if (granted == PackageManager.PERMISSION_GRANTED) return ShizukuAccess.AVAILABLE
            val deniedPermanently =
                runCatching { Shizuku.shouldShowRequestPermissionRationale() }.getOrDefault(false)
            return if (deniedPermanently) ShizukuAccess.DENIED else ShizukuAccess.NEEDS_PERMISSION
        }
        return if (isShizukuInstalled()) ShizukuAccess.NOT_RUNNING else ShizukuAccess.NOT_INSTALLED
    }

    private fun isShizukuInstalled(): Boolean =
        try {
            appContext.packageManager.getPackageInfo(SHIZUKU_PACKAGE, 0)
            true
        } catch (_: PackageManager.NameNotFoundException) {
            false
        } catch (_: Exception) {
            false
        }

    private fun newScope(): CoroutineScope =
        CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private fun newServiceExecutor(): ExecutorService =
        Executors.newSingleThreadExecutor { runnable ->
            Thread(runnable, "watchfree-handover-shell").apply { isDaemon = true }
        }

    private fun describe(error: Throwable): String =
        error.message?.takeIf { it.isNotBlank() } ?: error.javaClass.simpleName

    private data class RemoteAppState(val installed: Boolean, val state: Int)

    private data class LocalAppState(val installed: Boolean?, val state: Int?, val label: String?)

    private data class SnapshotResult(
        val access: ShizukuAccess,
        val apps: List<OfficialAppStatus>,
        val warning: String?,
        val hasRestorePoint: Boolean,
    )

    private companion object {
        // Calibration and manual recovery share the same process-wide package states.
        val operationMutex = Mutex()
        const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"
        const val REQUEST_PERMISSION_CODE = 4210
        const val SERVICE_API_VERSION = 1
        const val SERVICE_TAG = "watchfree-handover"
        const val PROCESS_NAME_SUFFIX = "handover"
        const val BIND_TIMEOUT_MS = 5_000L
        const val CALL_TIMEOUT_MS = 5_000L
        const val PER_USER_RANGE = 100_000
    }
}
