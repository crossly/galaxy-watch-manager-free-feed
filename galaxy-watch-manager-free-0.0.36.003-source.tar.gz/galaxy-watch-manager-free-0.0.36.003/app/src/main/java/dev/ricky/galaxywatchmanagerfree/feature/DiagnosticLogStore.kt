package dev.ricky.galaxywatchmanagerfree.feature

import java.io.File
import java.io.OutputStream

internal class DiagnosticLogStore(
    private val directory: File,
    private val maxBytes: Long = 2 * 1024 * 1024L,
) {
    private val current = File(directory, "watchfree.log")
    private val previous = File(directory, "watchfree.previous.log")

    fun append(entry: String) {
        check(directory.isDirectory || directory.mkdirs())
        val bytes = (entry + "\n").toByteArray(Charsets.UTF_8)
        require(bytes.size <= maxBytes) { "Log entry exceeds file limit" }
        if (current.length() + bytes.size > maxBytes) {
            check(!previous.exists() || previous.delete()) { "Cannot remove previous log" }
            check(current.renameTo(previous)) { "Cannot rotate log" }
        }
        current.appendBytes(bytes)
    }

    fun export(output: OutputStream, header: String) {
        output.write((header + "\n\n").toByteArray(Charsets.UTF_8))
        for (file in listOf(previous, current)) {
            if (file.isFile) file.inputStream().use { it.copyTo(output) }
        }
    }

    fun clear() {
        for (file in listOf(current, previous)) {
            check(!file.exists() || file.delete()) { "Cannot clear log" }
        }
    }
}
