package dev.ricky.galaxywatchmanagerfree.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.feature.HeartRateLog
import dev.ricky.galaxywatchmanagerfree.feature.WatchState
import dev.ricky.galaxywatchmanagerfree.ui.components.AppBottomSheet
import dev.ricky.galaxywatchmanagerfree.ui.components.DetailDayChip
import dev.ricky.galaxywatchmanagerfree.ui.components.DetailStatCell
import dev.ricky.galaxywatchmanagerfree.ui.components.GroupedCard
import dev.ricky.galaxywatchmanagerfree.ui.components.GroupedCardRow
import dev.ricky.galaxywatchmanagerfree.ui.components.GroupedDivider
import dev.ricky.galaxywatchmanagerfree.ui.components.HeartRateChart
import dev.ricky.galaxywatchmanagerfree.ui.components.HeartRateWeekBars
import dev.ricky.galaxywatchmanagerfree.ui.components.formatMonitorRecordTime
import dev.ricky.galaxywatchmanagerfree.ui.theme.HealthHeart
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextPrimary
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextSecondary
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextTertiary
import java.time.LocalDate
import java.time.ZoneId

/** 心率详情：明确区分测量时间、心率数据接收时间与整体健康同步时间；按本地日期查看真实 最低/平均/最高/次数、当日曲线及倒序读数列表。今日无数据时保留更早的最新测量并如实说明。 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HeartRateSheet(state: WatchState, onDismiss: () -> Unit) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val zone = remember { ZoneId.systemDefault() }
    val today = LocalDate.now(zone)
    val history = state.heartRateHistory
    val latest =
        state.latestHeartRate ?: history.values.asSequence().flatten().maxByOrNull { it.ts }
    val availableDays =
        remember(history, state.heartRateDays, today) {
            (history.keys + state.heartRateDays.keys)
                .mapNotNull { runCatching { LocalDate.parse(it) }.getOrNull() }
                .distinct()
                .sortedDescending()
        }
    val dayOptions =
        remember(availableDays, today) {
            (listOf(today) + availableDays).distinct().sortedDescending()
        }
    var selectedDayIso by rememberSaveable { mutableStateOf<String?>(null) }
    val selectedDay =
        selectedDayIso?.let { runCatching { LocalDate.parse(it) }.getOrNull() } ?: today
    val selectedPoints = history[selectedDay.toString()].orEmpty().sortedBy { it.ts }
    val selectedStats =
        state.heartRateDays[selectedDay.toString()] ?: HeartRateLog.stats(selectedPoints)
    var showAllReadings by remember(selectedDayIso) { mutableStateOf(false) }
    val newestFirst = selectedPoints.asReversed()
    val previewCount = 20
    val visibleReadings = if (showAllReadings) newestFirst else newestFirst.take(previewCount)
    val readingBatches = visibleReadings.chunked(20)
    val hasAnyHeartData =
        history.isNotEmpty() ||
            state.heartRateDays.isNotEmpty() ||
            state.heartRateWeek.any { it != null }

    AppBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        LazyColumn(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item {
                dev.ricky.galaxywatchmanagerfree.ui.components.SheetToolbar(
                    strings.getString(R.string.heart_rate),
                    onDismiss,
                )
            }

            // 最新一次真实测量：测量时间与接收/整体同步时间分开显示。
            item {
                GroupedCard(innerPadding = 16.dp) {
                    Text(
                        strings.getString(R.string.latest_measurement_2),
                        style = MaterialTheme.typography.labelMedium,
                        color = TextTertiary,
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(
                            text = latest?.let { "${it.bpm}" } ?: "—",
                            style = MaterialTheme.typography.headlineLarge,
                            fontWeight = FontWeight.Bold,
                            color = HealthHeart,
                            fontFamily = FontFamily.Monospace,
                        )
                        Text(
                            text = " " + strings.getString(R.string.bpm_2),
                            style = MaterialTheme.typography.labelMedium,
                            color = TextSecondary,
                            modifier = Modifier.padding(bottom = 6.dp),
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text =
                            if (latest != null)
                                strings.getString(
                                    R.string.metric_measured_at,
                                    formatMonitorRecordTime(latest.ts),
                                )
                            else strings.getString(R.string.no_measurement),
                        style = MaterialTheme.typography.bodySmall,
                        color = if (latest != null) TextSecondary else TextTertiary,
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text =
                            if (state.lastHeartRateReportTime > 0)
                                strings.getString(
                                    R.string.heart_rate_received_at,
                                    formatMonitorRecordTime(state.lastHeartRateReportTime),
                                )
                            else strings.getString(R.string.heart_rate_received_unknown),
                        style = MaterialTheme.typography.bodySmall,
                        color = TextTertiary,
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text =
                            strings.getString(
                                R.string.overall_health_sync,
                                if (state.lastHealthSyncTime > 0)
                                    formatMonitorRecordTime(state.lastHealthSyncTime)
                                else strings.getString(R.string.not_synced),
                            ),
                        style = MaterialTheme.typography.labelSmall,
                        color = TextTertiary,
                    )
                }
            }

            if (latest != null || hasAnyHeartData) {
                item {
                    GroupedCard(innerPadding = 16.dp) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Bottom,
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    strings.getString(R.string.heart_daily_statistics),
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary,
                                )
                                Text(
                                    if (selectedDay == today)
                                        strings.getString(R.string.heart_today_label)
                                    else selectedDay.toString(),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary,
                                )
                            }
                            if (selectedStats != null) {
                                Text(
                                    strings.getQuantityString(
                                        R.plurals.heart_readings_count,
                                        selectedStats.count,
                                        selectedStats.count,
                                    ),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = TextTertiary,
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(dayOptions, key = { it.toString() }) { day ->
                                DetailDayChip(
                                    day = day.toString(),
                                    selected = day == selectedDay,
                                    accent = HealthHeart,
                                    onClick = { selectedDayIso = day.toString() },
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(14.dp))
                        if (selectedStats != null) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                DetailStatCell(
                                    strings.getString(R.string.minimum),
                                    selectedStats.min.toString(),
                                    Modifier.weight(1f),
                                )
                                DetailStatCell(
                                    strings.getString(R.string.average),
                                    selectedStats.avg.toString(),
                                    Modifier.weight(1f),
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                DetailStatCell(
                                    strings.getString(R.string.maximum),
                                    selectedStats.max.toString(),
                                    Modifier.weight(1f),
                                )
                                DetailStatCell(
                                    strings.getString(R.string.heart_readings),
                                    selectedStats.count.toString(),
                                    Modifier.weight(1f),
                                )
                            }
                        } else {
                            Text(
                                if (selectedDay == today)
                                    strings.getString(R.string.heart_no_readings_today)
                                else
                                    strings.getString(
                                        R.string.heart_no_readings_on_day,
                                        selectedDay.toString(),
                                    ),
                                style = MaterialTheme.typography.bodySmall,
                                color = TextTertiary,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                            )
                        }
                    }
                }
            }

            if (selectedPoints.isNotEmpty()) {
                item {
                    GroupedCard(innerPadding = 16.dp) {
                        Text(
                            if (selectedDay == today) strings.getString(R.string.today_s_heart_rate)
                            else
                                strings.getString(R.string.heart_day_chart, selectedDay.toString()),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        HeartRateChart(points = selectedPoints, day = selectedDay)
                    }
                }
            }

            if (state.heartRateWeek.any { it != null }) {
                item {
                    GroupedCard(innerPadding = 16.dp) {
                        Text(
                            strings.getString(R.string.heart_rate_over_7_days),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        HeartRateWeekBars(days = state.heartRateWeek)
                    }
                }
            }

            if (selectedPoints.isNotEmpty()) {
                item {
                    Text(
                        strings.getString(R.string.heart_readings),
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        color = TextSecondary,
                        modifier = Modifier.padding(horizontal = 4.dp),
                    )
                }
                items(readingBatches, key = { it.first().ts }) { batch ->
                    GroupedCard(innerPadding = 0.dp) {
                        batch.forEachIndexed { index, point ->
                            if (index > 0) GroupedDivider()
                            GroupedCardRow(
                                title = "${point.bpm} ${strings.getString(R.string.bpm_2)}",
                                subtitle = formatMonitorRecordTime(point.ts),
                            )
                        }
                    }
                }
                if (newestFirst.size > previewCount) {
                    item {
                        Box(
                            modifier = Modifier.fillMaxWidth(),
                            contentAlignment = Alignment.Center,
                        ) {
                            TextButton(onClick = { showAllReadings = !showAllReadings }) {
                                Text(
                                    if (showAllReadings)
                                        strings.getString(R.string.heart_show_fewer_readings)
                                    else
                                        strings.getString(
                                            R.string.heart_view_all_readings,
                                            newestFirst.size,
                                        )
                                )
                            }
                        }
                    }
                }
            }

            if (!hasAnyHeartData && latest == null) {
                item {
                    GroupedCard {
                        Box(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 28.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                strings.getString(
                                    R.string.wear_the_watch_and_take_a_measurement_to_view
                                ),
                                style = MaterialTheme.typography.bodySmall,
                                color = TextTertiary,
                                textAlign = TextAlign.Center,
                            )
                        }
                    }
                }
            }
        }
    }
}
