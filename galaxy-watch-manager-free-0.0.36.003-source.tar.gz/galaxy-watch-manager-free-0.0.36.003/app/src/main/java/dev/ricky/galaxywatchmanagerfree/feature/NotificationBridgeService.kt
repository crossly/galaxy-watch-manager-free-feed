package dev.ricky.galaxywatchmanagerfree.feature

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import dev.ricky.galaxywatchmanagerfree.core.WatchController

/**
 * 抓取手机通知并转发到手表。
 *
 * 通过 Wear OS Bridger 的 wear://<phoneNode>/bridger/stream_item:* DataItem 下发。
 */
class NotificationBridgeService : NotificationListenerService() {

    private val forwarded = NotificationForwardingCache()

    override fun onListenerConnected() {
        super.onListenerConnected()
        LogBus.log("通知监听已连接")
        WatchController.repository.syncNotificationFeatures()
        activeNotifications?.forEach {
            if (it.packageName != packageName) {
                NotificationFilterPreferences.noteObserved(it.packageName)
            }
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val s = sbn ?: return
        val n = s.notification ?: return
        if (s.packageName != packageName) NotificationFilterPreferences.noteObserved(s.packageName)
        if (!WatchController.forwardNotifications) {
            LogBus.debug { "通知跳过 [${s.packageName} id=${s.id}]: 全局通知转发未开启" }
            return
        }
        if (s.packageName == packageName) {
            LogBus.debug { "通知跳过 [${s.packageName} id=${s.id}]: 自身应用事件" }
            return
        }

        val extras =
            n.extras
                ?: run {
                    LogBus.debug { "通知跳过 [${s.packageName} id=${s.id}]: 缺少 extras" }
                    return
                }
        // 跳过正在进行的（音乐播放器等常驻通知）与分组摘要
        if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) {
            LogBus.debug { "通知跳过 [${s.packageName} id=${s.id}]: 常驻进行中通知 (ONGOING)" }
            return
        }
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) {
            LogBus.debug { "通知跳过 [${s.packageName} id=${s.id}]: 分组摘要通知 (GROUP_SUMMARY)" }
            return
        }
        val isClearable =
            n.flags and Notification.FLAG_AUTO_CANCEL != 0 ||
                n.flags and Notification.FLAG_NO_CLEAR == 0
        if (!isClearable) {
            LogBus.debug { "通知跳过 [${s.packageName} id=${s.id}]: 不可清除通知 (NO_CLEAR)" }
            return
        }

        if (!NotificationFilterPreferences.config.value.allows(s.packageName)) {
            LogBus.debug { "通知跳过 [${s.packageName} id=${s.id}]: 不在允许应用列表" }
            return
        }

        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text =
            (extras.getCharSequence(Notification.EXTRA_TEXT)
                    ?: extras.getCharSequence(Notification.EXTRA_BIG_TEXT))
                ?.toString()
                .orEmpty()
        if (title.isBlank() && text.isBlank()) {
            LogBus.debug { "通知跳过 [${s.packageName} id=${s.id}]: 标题与内容均为空" }
            return
        }

        val uid =
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) s.uid
            else
                s.key.substringAfterLast('|').toIntOrNull()
                    ?: run {
                        LogBus.debug { "通知跳过 [${s.packageName} id=${s.id}]: 无法解析 uid" }
                        return
                    }
        val repository = WatchController.repository
        val target = repository.notificationSession ?: return
        val sent =
            forwarded.forward(target, s.key, "$title\u0000$text") {
                repository.notificationSession === target &&
                    repository.postNotification(
                        packageName = s.packageName,
                        title = title,
                        body = text,
                        tag = s.tag ?: "",
                        time = n.`when`.takeIf { it > 0 } ?: s.postTime,
                        identity = NotificationIdentity(s.packageName, s.id, s.tag, s.userId, uid),
                    )
            }
        when (sent) {
            true -> LogBus.debug { "通知已排队：[${s.packageName}] id=${s.id}" }
            false -> LogBus.debug { "通知转发入队失败：[${s.packageName}] id=${s.id}" }
            null -> LogBus.debug { "通知跳过 [${s.packageName} id=${s.id}]: 内容重复未变" }
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        val s = sbn ?: return
        forwarded.remove(s.key)
        LogBus.debug { "通知已移除：[${s.packageName}] id=${s.id}" }
    }
}
