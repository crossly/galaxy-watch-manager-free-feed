package dev.ricky.galaxywatchmanagerfree.core

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File

object GalleryImage {
    /** Caller requests WRITE_EXTERNAL_STORAGE only on API 26–28. Failed inserts are rolled back. */
    fun save(context: Context, bitmap: Bitmap, name: String): android.net.Uri {
        val resolver = context.contentResolver
        val values =
            ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                if (Build.VERSION.SDK_INT >= 29) {
                    put(
                        MediaStore.Images.Media.RELATIVE_PATH,
                        Environment.DIRECTORY_PICTURES + "/GalaxyWatchManagerFree",
                    )
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                } else {
                    @Suppress("DEPRECATION")
                    val directory =
                        File(
                            Environment.getExternalStoragePublicDirectory(
                                Environment.DIRECTORY_PICTURES
                            ),
                            "GalaxyWatchManagerFree",
                        )
                    check(directory.isDirectory || directory.mkdirs())
                    @Suppress("DEPRECATION")
                    put(MediaStore.Images.Media.DATA, File(directory, name).absolutePath)
                }
            }
        val uri =
            resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: error("MediaStore insert failed")
        try {
            resolver.openOutputStream(uri)?.use {
                check(bitmap.compress(Bitmap.CompressFormat.PNG, 100, it))
            } ?: error("MediaStore output unavailable")
            if (Build.VERSION.SDK_INT >= 29)
                resolver.update(
                    uri,
                    ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) },
                    null,
                    null,
                )
            return uri
        } catch (error: Throwable) {
            resolver.delete(uri, null, null)
            throw error
        }
    }
}
