package dev.ricky.galaxywatchmanagerfree.ui.screens.connection

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.core.WatchController
import dev.ricky.galaxywatchmanagerfree.core.WatchDiscovery
import dev.ricky.galaxywatchmanagerfree.feature.DeviceIdentityStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withContext

/** One bonded device row shown on the connection page. */
data class BondedWatch(val name: String, val mac: String)

/** Bonded-device read result: platform issue resource when the list cannot be read. */
data class BondedWatchResult(val watches: List<BondedWatch>, val issueRes: Int? = null)

/** Seam so the page state can be tested without a Bluetooth adapter. */
interface BondedWatchSource {
    suspend fun load(): BondedWatchResult
}

class AndroidBondedWatchSource(private val context: Context) : BondedWatchSource {
    override suspend fun load(): BondedWatchResult =
        withContext(Dispatchers.IO) {
            if (
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                    context.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) !=
                        PackageManager.PERMISSION_GRANTED
            ) {
                return@withContext BondedWatchResult(emptyList(), R.string.conn_permission_needed)
            }
            val adapter =
                (context.getSystemService(Context.BLUETOOTH_SERVICE)
                        as? android.bluetooth.BluetoothManager)
                    ?.adapter
            when {
                adapter == null ->
                    BondedWatchResult(emptyList(), R.string.conn_bluetooth_unavailable)
                !adapter.isEnabled -> BondedWatchResult(emptyList(), R.string.conn_bluetooth_off)
                else ->
                    runCatching {
                            val watches =
                                adapter.bondedDevices
                                    .map { device ->
                                        BondedWatch(device.name ?: device.address, device.address)
                                    }
                                    .sortedWith(
                                        compareByDescending<BondedWatch> {
                                                WatchDiscovery.score(it.name)
                                            }
                                            .thenBy { it.mac }
                                    )
                            BondedWatchResult(watches)
                        }
                        .getOrElse {
                            BondedWatchResult(emptyList(), R.string.conn_permission_needed)
                        }
            }
        }
}

/** Everything the connection page renders, independent of Compose and Android services. */
data class ConnectionPageUiState(
    val watches: List<BondedWatch> = emptyList(),
    val issueRes: Int? = null,
    val loading: Boolean = false,
    val selectedMac: String = "",
    val autoConnect: Boolean = true,
    val ownership: ConnectionOwnership = ConnectionOwnership.DIRECT,
) {
    val selectedWatch: BondedWatch?
        get() = watches.firstOrNull { it.mac.equals(selectedMac, ignoreCase = true) }
}

/**
 * Owns bonded-device selection and connection preferences; session state stays in
 * [WatchController].
 */
class ConnectionPageModel(
    private val context: Context,
    private val source: BondedWatchSource = AndroidBondedWatchSource(context),
) {
    private val _state =
        MutableStateFlow(
            ConnectionPageUiState(
                selectedMac = WatchController.savedMac.orEmpty(),
                autoConnect = WatchController.autoConnectEnabled,
                ownership = ownershipFor(WatchController.savedMac.orEmpty()),
            )
        )
    val state: StateFlow<ConnectionPageUiState> = _state.asStateFlow()

    suspend fun refresh() {
        _state.update { it.copy(loading = true) }
        val result = source.load()
        _state.update { current ->
            val saved = WatchController.savedMac.orEmpty()
            val candidate = current.selectedMac.ifBlank { saved }
            val selected =
                if (
                    candidate.isNotBlank() &&
                        result.watches.any { it.mac.equals(candidate, ignoreCase = true) }
                )
                    candidate
                else current.selectedMac
            current.copy(
                watches = result.watches,
                issueRes = result.issueRes,
                loading = false,
                autoConnect = WatchController.autoConnectEnabled,
                selectedMac = selected,
                ownership = ownershipFor(selected),
            )
        }
    }

    /** Re-read the durable handover flags after a card changes official-app ownership. */
    fun refreshConnectionOwnership() {
        _state.update { current ->
            current.copy(
                autoConnect = WatchController.autoConnectEnabled,
                ownership = ownershipFor(current.selectedMac),
            )
        }
    }

    /** Selecting a watch is explicit: it becomes the saved target and re-targets a live session. */
    fun select(mac: String) {
        if (mac.isBlank()) return
        _state.update { it.copy(selectedMac = mac, ownership = ownershipFor(mac)) }
        WatchController.savedMac = mac
        if (WatchController.isRunning) WatchController.switchTarget(context, mac)
    }

    fun setAutoConnect(enabled: Boolean) {
        WatchController.autoConnectEnabled = enabled
        _state.update { it.copy(autoConnect = enabled) }
    }

    private fun ownershipFor(mac: String): ConnectionOwnership {
        if (mac.isBlank()) return ConnectionOwnership.NONE
        val store = DeviceIdentityStore(context.applicationContext, mac)
        return resolveConnectionOwnership(
            hasDevice = true,
            handoverPreparing = store.handoverPreparing,
            releasedToOfficialApps = store.releasedToOfficialApps,
        )
    }
}
