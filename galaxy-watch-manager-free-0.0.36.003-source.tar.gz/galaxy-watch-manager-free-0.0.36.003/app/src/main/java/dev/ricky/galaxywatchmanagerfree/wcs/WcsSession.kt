package dev.ricky.galaxywatchmanagerfree.wcs

import android.content.Context
import android.os.Build
import dev.ricky.galaxywatchmanagerfree.BuildConfig
import dev.ricky.galaxywatchmanagerfree.core.HandshakeMode
import dev.ricky.galaxywatchmanagerfree.core.WatchController
import dev.ricky.galaxywatchmanagerfree.feature.DeviceIdentityStore
import dev.ricky.galaxywatchmanagerfree.feature.DevicePreferences
import dev.ricky.galaxywatchmanagerfree.feature.DeviceScope
import dev.ricky.galaxywatchmanagerfree.feature.IdentityEvent
import dev.ricky.galaxywatchmanagerfree.feature.LogBus
import dev.ricky.galaxywatchmanagerfree.feature.NotificationIdentity
import dev.ricky.galaxywatchmanagerfree.feature.monitor.HealthMonitorProtocol
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import kotlin.concurrent.thread
import org.json.JSONObject

/** WCS session layer: handshake state machine, frame routing, and request correlation. */
class WcsSession(
    private val context: Context,
    private val transport: RfcommTransport,
    val peerAddress: String? = null,
    private val isActive: () -> Boolean = { true },
) {
    interface Observer {
        fun onSessionReady()

        fun onWatchNodeChanged(node: String)

        fun onMessage(msg: WcsFrame.Incoming.Wearable)

        fun onWearPath(msg: WcsFrame.Incoming.WearPath)

        fun onHandshake(msg: WcsFrame.Incoming)

        fun onLog(line: String)

        fun onIdentityRequired() {}

        fun onMonitorChannel(path: String, payload: ByteArray) {}
    }

    @Volatile var observer: Observer? = null
    var onIdentityVerified: (() -> Unit)? = null
    private var handshakeWatchNode: String = ""
    private var identityVerified = false
    private val identityProbes = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()

    val identityStore =
        dev.ricky.galaxywatchmanagerfree.feature.DeviceIdentityStore(context, peerAddress)
    @Volatile
    private var pluginProfile =
        CompanionProfile.fromPackage(identityStore.confirmedPluginPackage)
            ?: CompanionProfile.WATCH7
    private val legacyPeer =
        DeviceScope.canImportLegacy(peerAddress, DevicePreferences.legacyOwner(context))

    /**
     * Legacy identity applies only to the explicitly migrated device, never arbitrary new peers.
     */
    @Volatile
    var watchNode: String = identityStore.confirmedWatchNode
        private set

    private val messageCounter = java.util.concurrent.atomic.AtomicLong(2L)

    // GMS ReorderingQueue drops messages with sequence <= max seen unless generation changes.
    private val sessionGeneration =
        java.util.concurrent.atomic.AtomicLong(((System.currentTimeMillis() / 1000) % 80000 + 10))

    // Phone node ID (8-char hex registered in watch pairing record).
    @Volatile
    var phoneNode: String = identityStore.effectivePhoneNode
        private set

    /** 确认并固化当前有效的候选身份（仅在业务成功验证后调用） */
    private fun confirmCandidateIdentity(): Boolean {
        if (!isActive() || !identityVerified) return false
        val candidate = identityStore.candidatePhoneNode
        if (candidate.isNotBlank() && candidate == phoneNode) {
            val confirmed =
                identityStore.transition(IdentityEvent.ConfirmPhoneNode(candidate, bluetoothName()))
            if (confirmed) {
                log("[身份] 候选手机节点 $candidate 验证成功，已固化为本设备身份")
            }
            return confirmed
        }
        return false
    }

    /** 握手就绪状态机（并发安全；事件 → 动作）。 */
    private val readiness = SessionReadiness()

    val ready: Boolean
        get() = readiness.ready

    /** 手表上报的设备名（来自对端 NodeInfo） */
    @Volatile
    var watchDeviceName: String = ""
        private set

    /** 手表 feature_exchange / status_exchange 的原始 JSON */
    @Volatile
    var watchFeature: JSONObject? = null
        private set

    @Volatile
    var watchStatus: JSONObject? = null
        private set

    private fun sendFrame(frame: ByteArray): Boolean = isActive() && transport.send(frame)

    fun sendJson(
        path: String,
        msgId: String,
        msgType: Int,
        data: JSONObject? = null,
        sender: String? = null,
        extra: JSONObject? = null,
        reason: Int = 0,
        result: Int = 0,
    ): Boolean {
        val obj = JSONObject()
        obj.put("msgId", msgId)
        obj.put("msgType", msgType)
        obj.put("deviceId", watchNode)
        obj.put("reason", reason)
        obj.put("result", result)
        if (sender != null) obj.put("sender", sender)
        if (data != null) obj.put("data", data) else obj.put("data", JSONObject())
        extra?.keys()?.forEach { k -> obj.put(k, extra.get(k)) }
        return sendRawJson(path, obj)
    }

    private fun canSend(path: String): Boolean {
        val reason =
            when {
                !isActive() -> "inactive_session"
                phoneNode.isBlank() -> "missing_phone_node"
                watchNode.isBlank() -> "missing_watch_node"
                else -> return true
            }
        LogBus.debug { "[WCS] TX rejected path=$path reason=$reason" }
        return false
    }

    @Synchronized
    fun sendRawJson(
        path: String,
        obj: JSONObject,
        type: Long = WcsFrame.TYPE_RESPONSE,
        senderPkg: String = pluginProfile.packageName,
        senderNode: String = WcsPaths.SIGNATURE_PLUGIN,
    ): Boolean {
        if (!canSend(path)) return false
        val curCode = messageCounter.getAndIncrement()
        val curGen = sessionGeneration.get()
        val frame =
            WcsFrame.jsonFrame(
                path = path,
                json = obj.toString(),
                senderPkg = senderPkg,
                senderNode = senderNode,
                destNode = watchNode,
                sourceNode = if (phoneNode.isNotEmpty()) phoneNode else PREFERRED_PHONE_NODE,
                type = type,
                code = curCode,
                generation = curGen,
            )
        val probe = path + ":" + obj.optString("msgId")
        if (path == WcsPaths.INTERNAL_FEATURE || path == WcsPaths.WATCHFACE_SYSUI)
            identityProbes.add(probe)
        val sent = sendFrame(frame)
        if (!sent) identityProbes.remove(probe)
        LogBus.debug {
            "[WCS] TX [$path] gen=$curGen code=$curCode sent=$sent payload=${LogBus.describe(obj)}"
        }
        return sent
    }

    /** 发送空 body 的路径消息（部分功能只认空 payload，如 setting_info_req） */
    @Synchronized
    fun sendEmpty(path: String) {
        if (!canSend(path)) return
        val curCode = messageCounter.getAndIncrement()
        val curGen = sessionGeneration.get()
        val frame =
            WcsFrame.jsonFrame(
                path = path,
                json = "{}",
                senderPkg = pluginProfile.packageName,
                senderNode = WcsPaths.SIGNATURE_PLUGIN,
                destNode = watchNode,
                sourceNode = if (phoneNode.isNotEmpty()) phoneNode else PREFERRED_PHONE_NODE,
                type = WcsFrame.TYPE_RESPONSE,
                code = curCode,
                generation = curGen,
            )
        val sent = sendFrame(frame)
        LogBus.debug { "[WCS] TX [$path] (empty) gen=$curGen code=$curCode sent=$sent" }
    }

    fun sendPsmMode(enabled: Boolean): Boolean {
        val json =
            JSONObject().put("msgId", 203).put("msgType", 1).put("extraData", if (enabled) 1 else 0)
        val sent = sendRawJson(WcsPaths.DEVICECARE_BATTERY_PSM, json)
        log("→ 发送省电模式指令: enabled=$enabled sent=$sent")
        return sent
    }

    /** 主动刷新电池详细信息 */
    fun sendBatteryBaseInfoReq() {
        val json = JSONObject().put("extraValue", "").put("msgId", 209)
        sendRawJson(WcsPaths.DEVICECARE_BATTERY_BASE, json)
        log("→ 发送电量详情刷新请求")
    }

    /** 拉取电池用量/续航（RefreshBatteryInfoMessage → dataMapId=202） */
    fun sendBatteryRefreshReq() {
        val json = JSONObject().put("extraValue", "").put("msgId", 202)
        sendRawJson(WcsPaths.DEVICECARE_BATTERY_REFRESH, json)
        log("→ 发送电池用量/续航刷新请求")
    }

    /** 读取电池保护设置（BatterySettingMessage → dataMapId=206） */
    fun sendBatterySettingReq() {
        val json =
            JSONObject()
                .put("extraData", org.json.JSONArray().put(-1).put(-1).put(-1))
                .put("msgId", 211)
                .put("msgType", 1)
        sendRawJson(WcsPaths.DEVICECARE_BATTERY_SETTING, json)
        log("→ 读取电池保护设置")
    }

    /** 写入电池保护设置：[保护模式阈值开关, 充电信息开关, 开机自启]（-1=不改） */
    fun sendBatterySetting(
        protection: Int = -1,
        showChargingInfo: Int = -1,
        autoPowerOn: Int = -1,
    ): Boolean {
        val json =
            JSONObject()
                .put(
                    "extraData",
                    org.json.JSONArray().put(protection).put(showChargingInfo).put(autoPowerOn),
                )
                .put("msgId", 211)
                .put("msgType", 1)
        val sent = sendRawJson(WcsPaths.DEVICECARE_BATTERY_SETTING, json)
        log(
            "→ 写入电池保护设置 protection=$protection charging=$showChargingInfo autoPowerOn=$autoPowerOn sent=$sent"
        )
        return sent
    }

    /**
     * 清理手表后台内存 (释放运行内存) 官方 MemoryCleanMessage = {"appName":[...],"msgId":303}（msgType 被 transient
     * 抛掉）
     */
    fun sendMemoryClean(apps: List<String> = emptyList()) {
        val json = JSONObject().put("appName", org.json.JSONArray(apps)).put("msgId", 303)
        sendRawJson(WcsPaths.DEVICECARE_MEMORY_CLEAN, json)
        log("→ 发送内存清理指令: apps=$apps")
    }

    /** 查询手表内存使用详情 */
    fun sendMemoryUsageReq() {
        val json = JSONObject().put("msgId", 301).put("msgType", 1)
        sendRawJson(WcsPaths.DEVICECARE_MEMORY_USAGE, json)
        log("→ 发送内存使用查询请求")
    }

    private val wearSeq = java.util.concurrent.atomic.AtomicLong(System.currentTimeMillis())

    fun writeSetting(cleanPath: String, key: String, value: Any): Boolean =
        writeSettingItem(
            "wear://$phoneNode/${cleanPath.trimStart('/')}",
            linkedMapOf(key to value, "from" to "phone", "time" to System.currentTimeMillis()),
        )

    fun writeSettingItem(uri: String, dataMap: Map<String, Any>): Boolean {
        val sourceNode = phoneNode
        if (sourceNode.isBlank()) return false
        val frame =
            WcsFrame.wearPathFrame(
                path = uri,
                dataItems = listOf(DataMapEncoder.encode(dataMap)),
                senderPkg = pluginProfile.packageName,
                nodeId = sourceNode,
                seqId = wearSeq.incrementAndGet(),
            )
        val ok = sendFrame(frame)
        log("→ 写入设置 $uri keys=${dataMap.keys} seq=${wearSeq.get()} → ${if (ok) "已排队" else "队列失败"}")
        return ok
    }

    /** 向 Wear OS 系统 Bridger 下发标准通知（通过 DataItem 同步到 /bridger/stream_item:...） */
    fun writeBridgerNotification(
        packageName: String = "com.tencent.mm",
        title: String,
        text: String,
        identity: NotificationIdentity = NotificationIdentity.generated(packageName),
        appName: String? = null,
        whenMillis: Long = System.currentTimeMillis(),
    ): Boolean {
        val authority = phoneNode
        if (authority.isBlank()) return false
        val wearUri = "wear://$authority/${identity.bridgerPath(authority)}"
        val dataMap =
            DataMapEncoder.encode(
                linkedMapOf(
                    "R_c,0" to 1L,
                    "R_c" to 1L,
                    "title_raw" to title,
                    "text_raw" to text,
                    "priority" to 1,
                    "notification_flags" to 0,
                    "user_id" to identity.userId,
                    "when" to whenMillis,
                    "show_when" to true,
                    "defaults" to 2,
                    "has_sound" to true,
                    "app_name" to (appName ?: packageName),
                    "from" to "phone",
                )
            )
        val frame =
            WcsFrame.wearPathFrame(
                path = wearUri,
                dataItems = listOf(dataMap),
                senderPkg = "com.samsung.android.wcs.extension",
                nodeId = authority,
                seqId = wearSeq.incrementAndGet(),
            )
        val ok = sendFrame(frame)
        log(
            "→ 下发 Bridger 通知 package=$packageName id=${identity.id} seq=${wearSeq.get()} queued=$ok"
        )
        return ok
    }

    fun requestSettingValue(cleanPath: String): Boolean {
        val path = "/${cleanPath.trimStart('/')}"
        val sent = sendBytes(WcsPaths.SET_DATAITEM_VALUE_REQ, path.toByteArray(Charsets.UTF_8))
        log("→ 回读设置 $path → ${if (sent) "已排队" else "队列失败"}")
        return sent
    }

    /**
     * 通过 Wear OS 标准远程 Intent 协议 (/remote_intent/rpc) 在手表上唤起 Activity。 支持 Galaxy Watch 6 / Watch 7
     * 全系 Wear OS，无需依赖三星独占手机服务。
     */
    fun launchRemoteActivity(
        packageName: String,
        action: String = "android.intent.action.MAIN",
        className: String? = null,
        categories: List<String> = emptyList(),
        extras: Map<String, Any> = emptyMap(),
    ): Boolean {
        val payload: Map<String, Any> = buildMap {
            put("action", action)
            put("package_name", packageName)
            if (!className.isNullOrBlank()) {
                put("class_name", className)
                put("component_name", "$packageName/$className")
            }
            if (categories.isNotEmpty()) {
                put("categories", categories.toTypedArray())
            }
            put("start_mode", 0) // ACTIVITY
            put(
                "com.google.android.clockwork.actions.RpcWithCallback.invocation_id",
                UUID.randomUUID().toString(),
            )
            if (extras.isNotEmpty()) {
                put("extras", extras)
            }
        }
        val data = DataMapEncoder.encode(payload)
        val sent = sendBytes("/remote_intent/rpc", data)
        log(
            "→ 远程启动应用 $packageName${if (className != null) "/$className" else ""} ($action) → ${if (sent) "已排队" else "队列失败"}"
        )
        return sent
    }

    /** 发送原始字节 payload（protobuf 类功能，如 /settings/rpc、/w_module_watchface/msg） */
    @Synchronized
    fun sendBytes(path: String, payload: ByteArray): Boolean {
        if (!canSend(path)) return false
        val code = messageCounter.getAndIncrement()
        val gen = sessionGeneration.get()
        val inner =
            WcsFrame.wearableMessage(
                path = path,
                payload = payload,
                senderPkg = pluginProfile.packageName,
                senderNode = WcsPaths.SIGNATURE_PLUGIN,
                destNode = watchNode,
                sourceNode = if (phoneNode.isNotEmpty()) phoneNode else PREFERRED_PHONE_NODE,
                code = code,
                generation = gen,
            )
        val sent = sendFrame(WcsFrame.envelope(inner, type = WcsFrame.TYPE_RESPONSE))
        LogBus.debug {
            "[WCS] TX Bytes [$path] gen=$gen code=$code sent=$sent payload=${LogBus.describe(payload)}"
        }
        return sent
    }

    /** 官方 hbk 的空心跳：inner=5a00，摘要由内容计算，不依赖配对凭据。 官方在读到非心跳后唤醒 writer，队列排空时按需发送心跳；当前另有 10s 定时兜底。 */
    fun keepaliveFrame(): ByteArray = WcsFrame.envelopeNoType(Proto.bytes(11, ByteArray(0)))

    private val healthChannels =
        HealthChannelReceiver(
            send = { request -> sendHealthChannelPacket(request) },
            deliver = { path, payload ->
                dispatchWearable(
                    WcsFrame.Incoming.Wearable(
                        null,
                        WcsFrame.TYPE_RESPONSE,
                        null,
                        WcsPaths.PKG_SHEALTH,
                        WcsPaths.SIGNATURE_SHEALTH,
                        phoneNode,
                        path,
                        payload.toString(Charsets.UTF_8),
                        payload,
                    )
                )
            },
            log = { log(it) },
        )

    private val monitorChannels =
        HealthChannelReceiver(
            send = { request ->
                sendHealthChannelPacket(
                    request,
                    HealthMonitorProtocol.PACKAGE,
                    HealthMonitorProtocol.SIGNATURE,
                )
            },
            deliver = { path, payload -> observer?.onMonitorChannel(path, payload) },
            log = ::log,
            accepts = { path, pkg ->
                path in setOf("/991d", "/992d") && pkg == HealthMonitorProtocol.PACKAGE
            },
        )

    @Synchronized
    private fun sendHealthChannelPacket(
        request: ByteArray,
        packageName: String = "com.samsung.android.wear.shealth",
        signature: String = WcsPaths.SIGNATURE_PLUGIN,
    ): Boolean {
        val wm =
            Proto.integer(1, messageCounter.getAndIncrement()) +
                Proto.string(2, packageName) +
                Proto.string(3, signature) +
                Proto.string(4, watchNode) +
                Proto.integer(5, 0) +
                Proto.string(6, "") +
                Proto.string(8, phoneNode) +
                Proto.bytes(9, request) +
                Proto.integer(10, sessionGeneration.get()) +
                Proto.integer(13, 1)
        val sent = sendFrame(WcsFrame.envelope(Proto.bytes(16, wm), type = WcsFrame.TYPE_RESPONSE))
        LogBus.debug {
            "[WCS] TX ChannelPacket pkg=$packageName sent=$sent ${LogBus.describe(request)}"
        }
        return sent
    }

    private fun assetFile(digest: String): android.util.AtomicFile {
        val key = "${phoneNode}_${watchNode}".replace(Regex("[^a-zA-Z0-9_]"), "_")
        val directory = java.io.File(context.filesDir, "wear-assets/$key").apply { mkdirs() }
        return android.util.AtomicFile(java.io.File(directory, digest))
    }

    private val wearAssets =
        WearAssetReceiver(
            persist = { digest, bytes ->
                val file = assetFile(digest)
                var stream: java.io.FileOutputStream? = null
                try {
                    stream = file.startWrite()
                    stream.write(bytes)
                    file.finishWrite(stream)
                    true
                } catch (_: Exception) {
                    file.failWrite(stream)
                    false
                }
            },
            contains = { digest ->
                runCatching {
                        assetFile(digest).openRead().use {
                            WcsFrame.messageDigest(it.readBytes()) == digest
                        }
                    }
                    .getOrDefault(false)
            },
            send = { inner -> sendFrame(WcsFrame.envelopeNoType(inner)) },
            log = ::log,
        )

    private val receivedPieces = WcsPieceAssembler(debug = LogBus::debug)
    private var dataItemStore: WearDataSnapshot? = null
    private var dataItemFile: android.util.AtomicFile? = null
    private val dataWriter =
        java.util.concurrent.Executors.newSingleThreadScheduledExecutor { task ->
            Thread(task, "wear-data-cache").apply { isDaemon = true }
        }
    private val dataWritePending = java.util.concurrent.atomic.AtomicBoolean(false)

    private fun restoreDataItems() {
        if (dataItemStore != null) return
        val key = "${phoneNode}_${watchNode}".replace(Regex("[^a-zA-Z0-9_]"), "_")
        val file = android.util.AtomicFile(java.io.File(context.filesDir, "wear-data-$key.json"))
        val store = WearDataSnapshot()
        val existed = file.baseFile.exists()
        val restored =
            runCatching {
                    file.openRead().use { input ->
                        val encoded = WearDataSnapshot.readEncoded(input) ?: return@use false
                        store.restore(encoded)
                    }
                }
                .getOrDefault(false)
        dataItemFile = file
        dataItemStore = store
        if (existed && !restored) {
            log("DataItem 快照无法恢复或超出大小上限，回退全量同步")
        }
        store.envelopes().forEach { envelope ->
            val item = WcsFrame.decode(envelope) as? WcsFrame.Incoming.WearPath ?: return@forEach
            if (!item.deleted && !item.path.contains(WcsPaths.HEALTH_MESSAGE))
                observer?.onWearPath(item)
        }
        log(
            "恢复 DataItem 快照 ${store.envelopes().size} 项，游标=${store.cursors()}，不完整来源=${store.incompleteSources()}"
        )
    }

    private fun cacheDataItem(envelope: ByteArray) {
        val store = dataItemStore ?: return
        val file = dataItemFile ?: return
        if (
            !store.accept(envelope) ||
                dataWriter.isShutdown ||
                !dataWritePending.compareAndSet(false, true)
        )
            return
        runCatching {
                dataWriter.schedule(
                    {
                        dataWritePending.set(false)
                        val bytes = store.encode().toByteArray(Charsets.UTF_8)
                        var stream: java.io.FileOutputStream? = null
                        try {
                            stream = file.startWrite()
                            stream.write(bytes)
                            file.finishWrite(stream)
                        } catch (error: Exception) {
                            file.failWrite(stream)
                            log("DataItem 快照写入失败：${error.message}")
                        }
                    },
                    250,
                    java.util.concurrent.TimeUnit.MILLISECONDS,
                )
            }
            .onFailure { dataWritePending.set(false) }
    }

    fun close() {
        dataWriter.shutdown()
    }

    fun onEnvelopeReceived(body: ByteArray) {
        if (!isActive()) return
        LogBus.debug { "[WCS] RX raw envelope ${body.size}B" }
        val assembled = receivedPieces.accept(body) ?: return
        val envelope = Proto.parse(assembled)
        val innerRaw = envelope.raw(1)
        if (innerRaw != null && wearAssets.receive(innerRaw)) {
            LogBus.debug { "[WCS] 匹配并消费 WearAsset" }
            return
        }
        val inner = innerRaw?.let(Proto::parse)
        val channelMessage = inner?.nested(16) ?: inner?.nested(10)
        channelMessage?.raw(9)?.let { request ->
            LogBus.debug { "[WCS] 分发通道消息 ${request.size}B" }
            healthChannels.receive(request)
            monitorChannels.receive(request)
            return
        }
        val msg =
            WcsFrame.decode(assembled)
                ?: run {
                    log("无法解析的信封 ${Proto.toHex(body.copyOfRange(0, minOf(24, body.size)))}")
                    return
                }
        when (msg) {
            is WcsFrame.Incoming.NodeInfo -> {
                log(
                    "RX NodeInfo node=${msg.nodeId} name=${msg.deviceName} " +
                        "wire=${msg.minimumProtocolVersion ?: 0}..${msg.protocolVersion ?: 0}"
                )
                val fromPeer = msg.nodeId != null && msg.nodeId != phoneNode
                if (fromPeer && DeviceIdentityStore.isValidNode(normaliseNode(msg.nodeId!!))) {
                    handshakeWatchNode = normaliseNode(msg.nodeId)
                    learnWatchNode(msg.nodeId)
                }
                msg.deviceName?.let { if (it.isNotBlank()) watchDeviceName = it }
                if (fromPeer) selectInitialPluginProfile(msg.deviceName)
                observer?.onHandshake(msg)
                if (fromPeer) onPeerNodeInfo()
            }
            is WcsFrame.Incoming.SyncStart -> {
                log(
                    "RX SyncStart seqId=${msg.peerSequence} version=${msg.version} cursors=${msg.cursors}"
                )
                // Cursor ordering carries no phone/watch roles and must never change identity.
                observer?.onHandshake(msg)

                // 收到对端同步起点，启动业务初始化；业务确认由后续 JSON 响应证明。
                val step = readiness.onSyncStart()
                if (step.activate) {
                    val newGen = sessionGeneration.incrementAndGet()
                    messageCounter.set(2L)
                    log("收到 SyncStart，开始业务初始化 (p2p / activation / status) gen=$newGen")
                    sendP2pFeature()
                    sendHandshake()
                    sendStatusExchange()
                }
                if (step.notifyReady) observer?.onSessionReady()
            }
            is WcsFrame.Incoming.WearPath -> {
                val (_, cleanPath) = WcsFrame.splitWearPath(msg.path)
                LogBus.debug {
                    "[WCS] RX WearPath $cleanPath items=${msg.dataItems.size} map=${LogBus.describe(msg.dataMap)}"
                }
                observer?.onHandshake(msg)
                observer?.onWearPath(msg)
                cacheDataItem(assembled)
            }
            is WcsFrame.Incoming.Heartbeat -> {
                LogBus.debug { "[WCS] RX Heartbeat" }
            }
            is WcsFrame.Incoming.Unknown -> {
                log("未知握手 inner fields=${msg.innerFields}")
                observer?.onHandshake(msg)
            }
            is WcsFrame.Incoming.Wearable -> dispatchWearable(msg)
        }
    }

    private fun dispatchWearable(msg: WcsFrame.Incoming.Wearable) {
        val (node, cleanPath) = WcsFrame.splitWearPath(msg.path)
        // The Bluetooth socket is bound to peerAddress. Require a fresh handshake peer and
        // destination match; when field 8 is present, require its source to match as well.
        val correctPeer =
            !peerAddress.isNullOrBlank() &&
                IdentityProof.matchesPeer(
                    handshakeWatchNode,
                    phoneNode,
                    msg.sourceNode,
                    msg.destNode,
                    node,
                )
        val json = runCatching { JSONObject(msg.payload) }.getOrNull()
        val rawMessageId = json?.optString("msgId").orEmpty()
        LogBus.debug {
            "[WCS] RX [$cleanPath] type=${msg.envType} code=${msg.code} payload=${if (json != null) LogBus.describe(json) else LogBus.describe(msg.payloadRaw)}"
        }
        if (
            correctPeer &&
                cleanPath == WcsPaths.INTERNAL_FEATURE &&
                IdentityProof.accepts(cleanPath, msg.payload)
        ) {
            val feature = json?.optJSONObject("data")
            val profile =
                listOf("modelNumber", "modelName", "deviceName").firstNotNullOfOrNull {
                    CompanionProfile.fromDeviceName(feature?.optString(it))
                }
            if (profile != null && profile != pluginProfile) selectPluginProfile(profile)
            if (identityVerified && profile != null)
                identityStore.transition(IdentityEvent.SavePluginProfile(profile))
        }
        if (
            !identityVerified &&
                isActive() &&
                correctPeer &&
                identityProbes.contains(cleanPath + ":" + rawMessageId) &&
                IdentityProof.accepts(cleanPath, msg.payload)
        ) {
            identityVerified = true
            confirmCandidateIdentity()
            identityStore.transition(IdentityEvent.SaveWatchNode(handshakeWatchNode))
            identityStore.transition(IdentityEvent.SavePluginProfile(pluginProfile))
            onIdentityVerified?.invoke()
        }

        // 手表回传的能力/状态，单独保存
        if (json != null) {
            when (cleanPath) {
                WcsPaths.INTERNAL_FEATURE ->
                    if (msg.envType == WcsFrame.TYPE_RESPONSE) {
                        watchFeature = json.optJSONObject("data") ?: json
                    }
                WcsPaths.INTERNAL_STATUS ->
                    if (msg.envType == WcsFrame.TYPE_RESPONSE) {
                        watchStatus = json.optJSONObject("data") ?: json
                        checkReady()
                    }
            }
        }

        // 通知 observer（用归一化路径重建对象，便于上层统一处理）
        val normalised = msg.copy(path = cleanPath)
        observer?.onMessage(normalised)
    }

    private fun learnWatchNode(node: String) {
        val n = normaliseNode(node)
        if (n.isEmpty() || n == phoneNode) return
        if (n != watchNode) {
            watchNode = n
            observer?.onWatchNodeChanged(n)
        }
    }

    private fun normaliseNode(s: String): String = DeviceIdentityStore.normalizeNode(s)

    @Suppress("DEPRECATION")
    private fun selectInitialPluginProfile(peerName: String?) {
        val installed =
            CompanionProfile.entries
                .filter {
                    runCatching { context.packageManager.getPackageInfo(it.packageName, 0) }
                        .isSuccess
                }
                .map { it.packageName }
        selectPluginProfile(
            CompanionProfile.resolve(peerName, identityStore.confirmedPluginPackage, installed)
        )
    }

    private fun selectPluginProfile(profile: CompanionProfile) {
        pluginProfile = profile
        log("WCS 插件身份 ${profile.packageName} (${profile.versionName})")
    }

    fun onTransportConnected() {
        if (!isActive()) return
        receivedPieces.reset()
        wearAssets.reset()
        healthChannels.reset()
        monitorChannels.reset()
        readiness.reset()
        handshakeWatchNode = ""
        identityVerified = false
        identityProbes.clear()
        val effective = identityStore.effectivePhoneNode
        if (effective != phoneNode) {
            phoneNode = effective
            dataItemStore = null
            dataItemFile = null
        }
        if (phoneNode.isBlank()) {
            observer?.onIdentityRequired()
            log("尚未配置手表已登记的手机节点；首次登记协议暂不支持")
            return
        }
        val mode =
            if (BuildConfig.DEBUG) WatchController.handshakeMode else HandshakeMode.CREDENTIAL
        when (mode) {
            HandshakeMode.REPLAY -> replayCapturedStream()
            HandshakeMode.LAB -> sendLabNodeInfo()
            HandshakeMode.CREDENTIAL -> {
                transport.keepaliveFrame = keepaliveFrame()
                sendCredentialNodeInfo()
                log("TX 历史 Connect/NodeInfo 样本 → 等待手表回帧")
                readyWatchdog()
            }
        }
    }

    /** 发送 NodeInfo。历史实机抓包帧已移除，旧版对端需要重新登记身份后走合成帧路径。 官方 hbr 会检查登记的节点 ID。 */
    fun sendCredentialNodeInfo() {
        if (phoneNode.isBlank()) return
        if (
            CREDENTIAL_FRAME_HEX.isNotEmpty() &&
                legacyPeer &&
                phoneNode == PREFERRED_PHONE_NODE &&
                !identityStore.hasStoredPhoneNode
        ) {
            sendFrame(Proto.fromHex(CREDENTIAL_FRAME_HEX))
        } else {
            sendFrame(
                WcsFrame.nodeInfoFrame(
                    phoneNode,
                    identityStore.phoneName ?: bluetoothName(),
                    System.currentTimeMillis() * 1_000_000L,
                )
            )
        }
    }

    /** 手表 8 秒内没有回 NodeInfo 时给出提示 */
    private fun readyWatchdog() {
        thread(isDaemon = true, name = "wcs-ready-watchdog") {
            try {
                Thread.sleep(8_000)
            } catch (_: InterruptedException) {
                return@thread
            }
            if (!ready) log("⚠ 8s 内未收到手表 NodeInfo 回帧")
        }
    }

    /** 手表回帧后的第二阶段握手：广播 peers，再下发激活/状态/能力。 只在第一次收到对端 NodeInfo 时执行。 */
    private fun onPeerNodeInfo() {
        val step = readiness.onPeerNodeInfo(hasPhoneNode = phoneNode.isNotBlank())
        if (step.isEmpty) return
        // Restore the durable DataItem snapshot before advertising its sync cursors.
        restoreDataItems()
        // The registered peer identity is enough to initialize WCS RPCs. Waiting for
        // SyncStart puts activation and core queries behind the peer's file stream.
        if (step.activate) {
            val newGen = sessionGeneration.incrementAndGet()
            messageCounter.set(2L)
            log("对端身份确认，优先初始化业务 gen=$newGen")
            sendP2pFeature()
            sendHandshake()
            sendStatusExchange()
        }
        if (step.notifyReady) observer?.onSessionReady()
        // 对齐官方 gyo.b 的第二阶段：发送 SyncStart (tag 8)。
        val syncCursors = dataItemSyncCursors(dataItemStore)
        val allocFrame =
            WcsFrame.syncStartFrame(
                remoteNode = if (watchNode.isNotEmpty()) watchNode else WcsPaths.FALLBACK_NODE,
                syncCursors = syncCursors,
            )
        sendFrame(allocFrame)
        log("TX SyncStart 增量游标=$syncCursors")
        publishCapabilities()
    }

    /** 向手表 GMS 广播 Health Monitor 所需的能力 DataItems (ECG/BP/IHRN/SLEEP) */
    fun publishCapabilities() {
        val authority = phoneNode
        if (authority.isBlank()) return
        HealthMonitorProtocol.CAPABILITIES.forEach { cap ->
            val path = HealthMonitorProtocol.capabilityPath(cap)
            val wearUri = "wear://$authority/$path"
            val frame =
                WcsFrame.wearPathFrame(
                    path = wearUri,
                    dataItems = listOf("s".toByteArray(Charsets.UTF_8)),
                    senderPkg = WcsPaths.PKG_GMS,
                    nodeId = authority,
                    seqId = wearSeq.incrementAndGet(),
                )
            sendFrame(frame)
        }
        log("已向手表广播 Health Monitor 能力 (ECG/BP/IHRN/SLEEP)")
    }

    /** LAB 模式的历史实机抓包夹具已移除，入口保留但不发送任何帧。 */
    private fun sendLabNodeInfo() {
        log("LAB 抓包夹具已移除，未发送任何帧")
    }

    /** 调试：回放实机抓到的手机→手表原始帧序列，用于验证手表接受度 */
    private fun replayCapturedStream() {
        val ctx = context
        val bytes =
            runCatching { ctx.assets.open("replay_p2w.bin").use { it.readBytes() } }.getOrNull()
                ?: run {
                    log("replay asset 缺失")
                    return
                }
        val limit = WatchController.replayFrameLimit
        var i = 0
        var n = 0
        while (i + 4 <= bytes.size && (limit <= 0 || n < limit)) {
            val len = LengthPrefix.readLength(bytes.copyOfRange(i, i + 4))
            if (len <= 0 || i + 4 + len > bytes.size) break
            sendFrame(bytes.copyOfRange(i, i + 4 + len))
            i += 4 + len
            n++
            Thread.sleep(30)
        }
        log("回放完成，共 $n 帧")
    }

    /** lab 模式下是否只发这一帧 */
    private val LAB_ONLY: Boolean
        get() = WatchController.labOnly

    /** 手表注册的是手机蓝牙名（如「荣耀Magic8 Pro」），必须保持一致 */
    @Suppress("MissingPermission")
    private fun bluetoothName(): String {
        val adapter =
            (context.getSystemService(android.content.Context.BLUETOOTH_SERVICE)
                    as? android.bluetooth.BluetoothManager)
                ?.adapter
        val n = runCatching { adapter?.name }.getOrNull()
        return if (!n.isNullOrBlank()) n else (Build.MODEL ?: "Android")
    }

    private fun sendP2pFeature() {
        sendJson(
            path = "/wcs_extension/internal/p2p",
            msgId = "wifi_p2p_feature",
            msgType = 2,
            data = JSONObject().put("address", "02:00:00:00:00:00"),
        )
    }

    private fun sendStatusExchange() {
        sendJson(
            path = WcsPaths.INTERNAL_STATUS,
            msgId = WcsPaths.MSG_STATUS_EXCHANGE,
            msgType = 2,
            data = buildPhoneStatus(),
        )
    }

    fun sendHandshake() {
        log("开始握手（仅激活） → $watchNode")
        // 仅发送设备激活指令，逐字节对齐抓包 #547
        sendJson(
            path = WcsPaths.INTERNAL_CONNECTION,
            msgId = WcsPaths.MSG_SET_DEVICE_ACTIVATION,
            msgType = 1,
            data = JSONObject().put("enable", true),
        )
    }

    private fun checkReady() {
        if (watchStatus == null) return
        if (readiness.onStatusReceived().notifyReady) {
            log("会话就绪（手表 node=$watchNode）")
            observer?.onSessionReady()
        }
    }

    @android.annotation.SuppressLint(
        "MissingPermission"
    ) // Adapter name access is guarded by runCatching.
    fun buildPhoneFeature(): JSONObject {
        val btName =
            runCatching { android.bluetooth.BluetoothAdapter.getDefaultAdapter()?.name }.getOrNull()
                ?: "Android"
        val tz = TimeZone.getDefault()
        return JSONObject()
            .put("deviceBtName", btName)
            .put("screenWidth", context.resources.displayMetrics.widthPixels.toString())
            .put("screenHeight", context.resources.displayMetrics.heightPixels.toString())
            .put("deviceName", "Galaxy S25 Ultra")
            .put("modelNumber", "SM-S938U1")
            .put("vender", "samsung")
            .put("isTablet", "false")
            .put("csc", "XAA")
            .put("locale", Locale.getDefault().toString())
            .put("timezone", tz.id)
            .put("time", System.currentTimeMillis())
            .put("sepLiteDevice", "false")
            .put("defaultAppMessage", defaultSmsPackage())
    }

    fun buildPhoneStatus(): JSONObject {
        val loc = Locale.getDefault()
        val tz = TimeZone.getDefault()
        return JSONObject()
            .put("localeLanguage", loc.language)
            .put("localeRegion", loc.country)
            .put("localeVariant", loc.variant ?: "")
            .put("localeUnicodeExtension", "")
            .put("localeScript", loc.script)
            .put("fbeMode", true)
            .put("pluginVersion", pluginProfile.versionName)
            .put("mcc", "")
            .put("mnc", "")
            .put("devicePlatform", "android")
            .put("devicePlatformVersion", Build.VERSION.RELEASE)
            .put("oneUiVersion", 0)
            .put("swVersion", Build.DISPLAY)
            .put("SDKVersion", Build.VERSION.SDK_INT.toString())
            .put("timezone", tz.id)
            .put("time", System.currentTimeMillis())
            .put("simCountry", loc.country.lowercase())
            .put("roamingStatus", false)
    }

    private fun defaultSmsPackage(): String =
        runCatching {
                val intent =
                    android.content
                        .Intent(android.content.Intent.ACTION_VIEW)
                        .setType("vnd.android-dir/mms-sms")
                context.packageManager.resolveActivity(intent, 0)?.activityInfo?.packageName
            }
            .getOrNull() ?: ""

    private fun log(s: String) {
        dev.ricky.galaxywatchmanagerfree.feature.LogBus.log("[WCS] $s")
    }

    companion object {
        /** 旧版对端的占位节点；真实节点由设备身份登记写入，不再内置抓包实测值。 */
        const val PREFERRED_PHONE_NODE = "0000000"

        /** 历史 NodeInfo 抓包夹具已移除；空值表示不再回放固定帧。 */
        const val CREDENTIAL_FRAME_HEX = ""
    }
}

/** SyncStart may only advertise cursors whose source still has a complete retained copy. */
internal fun dataItemSyncCursors(store: WearDataSnapshot?): Map<String, Long> =
    store?.cursors().orEmpty()
