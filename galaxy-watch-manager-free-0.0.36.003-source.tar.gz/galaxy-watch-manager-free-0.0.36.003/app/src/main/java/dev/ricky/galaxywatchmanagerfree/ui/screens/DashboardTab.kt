package dev.ricky.galaxywatchmanagerfree.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.core.UiNotify
import dev.ricky.galaxywatchmanagerfree.core.WatchController
import dev.ricky.galaxywatchmanagerfree.feature.LayoutPage
import dev.ricky.galaxywatchmanagerfree.feature.WatchRepository
import dev.ricky.galaxywatchmanagerfree.feature.WatchState
import dev.ricky.galaxywatchmanagerfree.ui.autoConnectMessage
import dev.ricky.galaxywatchmanagerfree.ui.components.*
import dev.ricky.galaxywatchmanagerfree.ui.theme.*

@Composable
fun DashboardTab(
    state: WatchState,
    repo: WatchRepository,
    modifier: Modifier = Modifier,
    onNavigateWatchFace: () -> Unit = {},
    editing: Boolean = false,
) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources

    val context = LocalContext.current
    var testCount by remember { mutableIntStateOf(0) }
    var showRenameDialog by remember { mutableStateOf(false) }
    var renameText by remember { mutableStateOf("") }
    EditableBlockGrid(page = LayoutPage.OVERVIEW, editing = editing, modifier = modifier) {
        placement ->
        when (placement.block) {
            dev.ricky.galaxywatchmanagerfree.feature.PageBlock.CONNECTION -> {
                Column(Modifier.fillMaxWidth()) {
                    GroupedCard(cornerRadius = 34.dp, innerPadding = 20.dp) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp),
                        ) {
                            WatchDeviceGraphic(state = state)
                            Column(Modifier.weight(1f)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                ) {
                                    Text(
                                        state.displayName,
                                        style =
                                            androidx.compose.material3.MaterialTheme.typography
                                                .titleLarge,
                                        lineHeight = 25.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = TextPrimary,
                                        maxLines = 1,
                                        overflow =
                                            androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f, fill = false),
                                    )
                                    IconButton(
                                        onClick = {
                                            renameText =
                                                state.watchAlias.ifBlank { state.displayName }
                                            showRenameDialog = true
                                        },
                                        modifier = Modifier.size(24.dp),
                                    ) {
                                        Icon(
                                            Icons.Default.Edit,
                                            strings.getString(R.string.rename_watch),
                                            tint = TextTertiary,
                                            modifier = Modifier.size(16.dp),
                                        )
                                    }
                                }
                                Text(
                                    if (state.startupSyncing)
                                        strings.getString(R.string.connected_updating_watch_status)
                                    else if (state.sessionReady)
                                        strings.getString(
                                            R.string.connected,
                                            if (state.wearing) strings.getString(R.string.worn)
                                            else strings.getString(R.string.not_worn),
                                        )
                                    else if (state.connected) strings.getString(R.string.connecting)
                                    else strings.getString(R.string.disconnected),
                                    style =
                                        androidx.compose.material3.MaterialTheme.typography
                                            .bodySmall,
                                    color = TextSecondary,
                                )
                            }
                            FilledTonalIconButton(
                                onClick = {
                                    if (state.connected) WatchController.stopService(context)
                                    else
                                        UiNotify.show(
                                            autoConnectMessage(
                                                WatchController.connectManually(context),
                                                strings,
                                            )
                                        )
                                }
                            ) {
                                Icon(
                                    if (state.connected) Icons.Default.LinkOff
                                    else Icons.Default.Bluetooth,
                                    if (state.connected) strings.getString(R.string.disconnect)
                                    else strings.getString(R.string.connect_watch),
                                )
                            }
                        }
                    }
                }
            }
            dev.ricky.galaxywatchmanagerfree.feature.PageBlock.BATTERY -> {
                Column(Modifier.fillMaxWidth()) { BatteryGaugeCard(state) }
            }
            dev.ricky.galaxywatchmanagerfree.feature.PageBlock.WATCH_FACE -> {
                Column(Modifier.fillMaxWidth()) {
                    WatchFaceSummaryCard(state, onClick = onNavigateWatchFace)
                }
            }
            dev.ricky.galaxywatchmanagerfree.feature.PageBlock.QUICK_CONTROLS -> {
                Column(Modifier.fillMaxWidth()) {
                    SectionHeader(strings.getString(R.string.quick_controls))
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            QuickControlTile(
                                if (state.isFindingWatch) strings.getString(R.string.stop_ringing)
                                else strings.getString(R.string.find_watch),
                                strings.getString(R.string.vibrate_and_ring),
                                Icons.Default.RingVolume,
                                state.isFindingWatch,
                                enabled = state.sessionReady,
                                onClick = { repo.findMyWatch() },
                                modifier = Modifier.weight(1f),
                            )
                            QuickControlTile(
                                strings.getString(R.string.power_saving),
                                if (state.psmMode) strings.getString(R.string.on)
                                else strings.getString(R.string.off),
                                Icons.Default.BatterySaver,
                                state.psmMode,
                                enabled = state.sessionReady && !state.psmControlRestricted,
                                onClick = { repo.setPowerSavingMode(!state.psmMode) },
                                modifier = Modifier.weight(1f),
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            QuickControlTile(
                                strings.getString(R.string.raise_to_wake),
                                if (state.wakeOnWrist) strings.getString(R.string.on)
                                else strings.getString(R.string.off),
                                Icons.Default.Watch,
                                state.wakeOnWrist,
                                enabled = state.sessionReady,
                                onClick = { repo.setWakeOnWrist(!state.wakeOnWrist) },
                                modifier = Modifier.weight(1f),
                            )
                            QuickControlTile(
                                strings.getString(R.string.sync_do_not_disturb),
                                if (state.syncDnd) strings.getString(R.string.on)
                                else strings.getString(R.string.off),
                                Icons.Default.DoNotDisturbOn,
                                state.syncDnd,
                                enabled = state.sessionReady,
                                onClick = { repo.setSyncDnd(!state.syncDnd) },
                                modifier = Modifier.weight(1f),
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            QuickControlTile(
                                strings.getString(R.string.test_notification),
                                if (testCount > 0)
                                    strings.getQuantityString(
                                        R.plurals.test_request_count,
                                        testCount,
                                        testCount,
                                    )
                                else strings.getString(R.string.send_a_notification_to_the_watch),
                                Icons.Default.NotificationsActive,
                                false,
                                activeColor = ElectricBlue,
                                enabled = state.sessionReady,
                                onClick = {
                                    if (repo.sendTestNotification()) {
                                        testCount++
                                        UiNotify.show(R.string.test_notification_sent)
                                    } else {
                                        UiNotify.show(R.string.request_send_failed)
                                    }
                                },
                                modifier = Modifier.weight(1f),
                            )
                            QuickControlTile(
                                strings.getString(R.string.grayscale),
                                if (state.grayscaleEnabled) strings.getString(R.string.on)
                                else strings.getString(R.string.off),
                                Icons.Default.FilterBAndW,
                                state.grayscaleEnabled,
                                activeColor = ElectricBlue,
                                enabled = state.sessionReady,
                                onClick = { repo.setGrayscale(!state.grayscaleEnabled) },
                                modifier = Modifier.weight(1f),
                            )
                        }
                    }
                }
            }
            dev.ricky.galaxywatchmanagerfree.feature.PageBlock.MEMORY -> {
                Column(Modifier.fillMaxWidth()) {
                    MemoryProgressCard(
                        state.ramUsedMb,
                        state.ramTotalMb,
                        state.ramAvailableMb,
                        onClean =
                            if (state.sessionReady && state.ramApps.isNotEmpty())
                                ({ repo.cleanRam() })
                            else null,
                    )
                }
            }
            dev.ricky.galaxywatchmanagerfree.feature.PageBlock.DEVICE_INFO -> {
                Column(Modifier.fillMaxWidth()) {
                    var expanded by rememberSaveable { mutableStateOf(false) }
                    val chevronRotation by
                        animateFloatAsState(
                            targetValue = if (expanded) 180f else 0f,
                            label = "deviceInfoChevron",
                        )
                    val summary =
                        listOf(
                                state.modelName,
                                state.wearOs.takeIf { it.isNotBlank() }?.let { "Wear OS $it" },
                            )
                            .filter { !it.isNullOrBlank() }
                            .joinToString(" · ")
                    GroupedCard(innerPadding = 0.dp) {
                        GroupedCardRow(
                            title = strings.getString(R.string.device_information),
                            subtitle = summary.ifBlank { null },
                            icon = Icons.Default.Info,
                            iconTint = TextSecondary,
                            iconBackground = CardSurfaceElevated,
                            onClick = { expanded = !expanded },
                            modifier =
                                Modifier.semantics {
                                        role = Role.Button
                                        stateDescription =
                                            strings.getString(
                                                if (expanded) R.string.action_collapse
                                                else R.string.action_expand
                                            )
                                    }
                                    .testTag("tag_device_info_expand"),
                            trailing = {
                                Icon(
                                    Icons.Default.ExpandMore,
                                    null,
                                    tint = TextTertiary,
                                    modifier = Modifier.size(20.dp).rotate(chevronRotation),
                                )
                            },
                        )
                        AnimatedVisibility(visible = expanded) {
                            Column(
                                Modifier.fillMaxWidth()
                                    .padding(start = 16.dp, end = 16.dp, bottom = 16.dp)
                            ) {
                                androidx.compose.foundation.text.selection.SelectionContainer {
                                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        DeviceInfo(
                                            strings.getString(R.string.device_name),
                                            state.deviceName,
                                        )
                                        DeviceInfo(
                                            strings.getString(R.string.model),
                                            state.modelNumber.ifBlank { state.modelName },
                                        )
                                        DeviceInfo(
                                            strings.getString(R.string.product_name),
                                            state.modelName,
                                        )
                                        DeviceInfo(
                                            strings.getString(R.string.system_version),
                                            state.wearOs
                                                .takeIf { it.isNotBlank() }
                                                ?.let { "Wear OS $it" }
                                                .orEmpty(),
                                        )
                                        DeviceInfo(
                                            strings.getString(R.string.android_version),
                                            state.androidVersion,
                                        )
                                        DeviceInfo(
                                            strings.getString(R.string.firmware_version),
                                            state.firmware,
                                        )
                                        DeviceInfo(
                                            strings.getString(R.string.battery_capacity),
                                            state.batteryCapacityMah
                                                .takeIf { it.isNotBlank() }
                                                ?.let {
                                                    if (it.contains("mAh", true)) it else "$it mAh"
                                                }
                                                .orEmpty(),
                                        )
                                        DeviceInfo(
                                            "eSIM",
                                            if (state.esimSupported)
                                                strings.getString(R.string.supported)
                                            else if (state.featureInfoReceived)
                                                strings.getString(R.string.not_supported)
                                            else
                                                strings.getString(
                                                    R.string.waiting_for_device_information
                                                ),
                                        )
                                        if (state.eid.isNotBlank()) DeviceInfo("EID", state.eid)
                                        if (state.imei.isNotBlank()) DeviceInfo("IMEI", state.imei)
                                        DeviceInfo(
                                            strings.getString(R.string.watch_node),
                                            state.watchNode,
                                        )
                                        DeviceInfo(
                                            strings.getString(R.string.phone_node),
                                            state.phoneNode,
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
            else -> Unit
        }
    }

    if (showRenameDialog) {
        AlertDialog(
            onDismissRequest = { showRenameDialog = false },
            title = {
                Text(
                    strings.getString(R.string.rename_watch),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimary,
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = renameText,
                        onValueChange = { if (it.length <= 32) renameText = it },
                        label = { Text(strings.getString(R.string.watch_nickname)) },
                        placeholder = { Text(strings.getString(R.string.rename_watch_hint)) },
                        singleLine = true,
                        maxLines = 1,
                        modifier = Modifier.fillMaxWidth(),
                        supportingText = {
                            Text(
                                strings.getString(R.string.max_characters, 32),
                                style = MaterialTheme.typography.bodySmall,
                                color = TextTertiary,
                            )
                        },
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val trimmed = renameText.trim()
                        if (trimmed.isNotBlank()) {
                            repo.setWatchAlias(trimmed)
                            showRenameDialog = false
                        }
                    },
                    enabled = renameText.isNotBlank(),
                ) {
                    Text(strings.getString(R.string.save))
                }
            },
            dismissButton = {
                TextButton(onClick = { showRenameDialog = false }) {
                    Text(strings.getString(R.string.cancel))
                }
            },
        )
    }
}

@Composable
private fun DeviceInfo(label: String, value: String) {
    Column {
        Text(
            label,
            style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
            color = TextSecondary,
        )
        Text(
            value.ifBlank { "—" },
            style = androidx.compose.material3.MaterialTheme.typography.bodyMedium,
            color = TextPrimary,
        )
    }
}
