package dev.ricky.galaxywatchmanagerfree.feature

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.annotation.StringRes
import dev.ricky.galaxywatchmanagerfree.R

/**
 * Chinese Android ROM background keep-alive and battery optimization assistant. Supports Xiaomi
 * (HyperOS/MIUI), Huawei/Honor (HarmonyOS/MagicOS), OPPO/OnePlus (ColorOS), vivo/iQOO (OriginOS),
 * Meizu (Flyme), Samsung (One UI), and generic AOSP.
 */
enum class RomBrand(val brandName: String, val systemName: String, @StringRes val guideRes: Int) {
    XIAOMI("Xiaomi / Redmi", "HyperOS / MIUI", R.string.rom_guide_xiaomi),
    HUAWEI("Huawei / Honor", "HarmonyOS / MagicOS", R.string.rom_guide_huawei),
    OPPO("OPPO / OnePlus / realme", "ColorOS / realme UI", R.string.rom_guide_oppo),
    VIVO("vivo / iQOO", "OriginOS / Funtouch OS", R.string.rom_guide_vivo),
    MEIZU("Meizu", "Flyme", R.string.rom_guide_meizu),
    SAMSUNG("Samsung", "One UI", R.string.rom_guide_samsung),
    GENERIC("Android", "AOSP", R.string.rom_guide_generic),
}

object KeepAliveHelper {

    fun detectRomBrand(
        manufacturer: String = Build.MANUFACTURER.orEmpty(),
        brand: String = Build.BRAND.orEmpty(),
    ): RomBrand {
        val m = manufacturer.lowercase()
        val b = brand.lowercase()
        val combined = "$m $b"
        return when {
            combined.contains("xiaomi") ||
                combined.contains("redmi") ||
                combined.contains("poco") -> RomBrand.XIAOMI
            combined.contains("huawei") || combined.contains("honor") -> RomBrand.HUAWEI
            combined.contains("oppo") ||
                combined.contains("oneplus") ||
                combined.contains("realme") -> RomBrand.OPPO
            combined.contains("vivo") || combined.contains("iqoo") -> RomBrand.VIVO
            combined.contains("meizu") -> RomBrand.MEIZU
            combined.contains("samsung") -> RomBrand.SAMSUNG
            else -> RomBrand.GENERIC
        }
    }

    /** Checks if the app is already exempt from system battery optimization (whitelisted). */
    fun isBatteryOptimizationIgnored(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true
        val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager ?: return false
        return pm.isIgnoringBatteryOptimizations(context.packageName)
    }

    /** Directly prompts the system battery optimization whitelist dialog or opens settings. */
    fun requestIgnoreBatteryOptimization(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true

        // 1. Try direct system exemption request dialog
        val directIntent =
            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = Uri.parse("package:${context.packageName}")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
        if (tryStartActivity(context, directIntent)) return true

        // 2. Fallback to battery optimization settings list
        val listIntent =
            Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
        if (tryStartActivity(context, listIntent)) return true

        // 3. Fallback to app details settings
        return openAppDetails(context)
    }

    /** Attempts to launch OEM-specific autostart and background protection manager activity. */
    fun openAutoStartSettings(context: Context): Boolean {
        val brand = detectRomBrand()
        val candidateIntents = buildCandidateIntents(context, brand)

        for (intent in candidateIntents) {
            if (tryStartActivity(context, intent)) {
                return true
            }
        }

        // Generic fallback to app details settings
        return openAppDetails(context)
    }

    fun openAppDetails(context: Context): Boolean {
        val appDetailsIntent =
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.parse("package:${context.packageName}")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
        return tryStartActivity(context, appDetailsIntent)
    }

    private fun buildCandidateIntents(context: Context, brand: RomBrand): List<Intent> {
        val intents = mutableListOf<Intent>()
        val pkg = context.packageName

        when (brand) {
            RomBrand.XIAOMI -> {
                // MIUI / HyperOS autostart permission center
                intents +=
                    Intent().apply {
                        component =
                            ComponentName(
                                "com.miui.securitycenter",
                                "com.miui.permcenter.autostart.AutoStartManagementActivity",
                            )
                    }
                intents +=
                    Intent("miui.intent.action.OP_AUTO_START").apply {
                        addCategory(Intent.CATEGORY_DEFAULT)
                    }
                // MIUI power keeper hidden app battery policy
                intents +=
                    Intent().apply {
                        component =
                            ComponentName(
                                "com.miui.powerkeeper",
                                "com.miui.powerkeeper.ui.HiddenAppsConfigActivity",
                            )
                        putExtra("package_name", pkg)
                        putExtra("package_label", context.getString(R.string.app_name))
                    }
            }
            RomBrand.HUAWEI -> {
                // HarmonyOS / EMUI startup manager
                intents +=
                    Intent().apply {
                        component =
                            ComponentName(
                                "com.huawei.systemmanager",
                                "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity",
                            )
                    }
                intents +=
                    Intent().apply {
                        component =
                            ComponentName(
                                "com.huawei.systemmanager",
                                "com.huawei.systemmanager.optimize.bootstart.BootStartActivity",
                            )
                    }
                intents +=
                    Intent().apply {
                        component =
                            ComponentName(
                                "com.huawei.systemmanager",
                                "com.huawei.systemmanager.appcontrol.activity.StartupAppControlActivity",
                            )
                    }
            }
            RomBrand.OPPO -> {
                // ColorOS autostart manager
                intents +=
                    Intent().apply {
                        component =
                            ComponentName(
                                "com.coloros.safecenter",
                                "com.coloros.safecenter.startupapp.StartupAppListActivity",
                            )
                    }
                intents +=
                    Intent().apply {
                        component =
                            ComponentName(
                                "com.oplus.safecenter",
                                "com.oplus.safecenter.startupapp.StartupAppListActivity",
                            )
                    }
                intents +=
                    Intent().apply {
                        component =
                            ComponentName(
                                "com.coloros.oppoguardelf",
                                "com.coloros.powermanager.fuelgaue.PowerUsageModelActivity",
                            )
                    }
            }
            RomBrand.VIVO -> {
                // OriginOS / Funtouch OS autostart
                intents +=
                    Intent().apply {
                        component =
                            ComponentName(
                                "com.iqoo.secure",
                                "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity",
                            )
                    }
                intents +=
                    Intent().apply {
                        component =
                            ComponentName(
                                "com.iqoo.secure",
                                "com.iqoo.secure.safeguard.PurviewTabActivity",
                            )
                    }
                intents +=
                    Intent().apply {
                        component =
                            ComponentName(
                                "com.vivo.abe",
                                "com.vivo.application.ups.activity.ManageWhiteListActivity",
                            )
                    }
            }
            RomBrand.MEIZU -> {
                intents +=
                    Intent().apply {
                        component =
                            ComponentName(
                                "com.meizu.safe",
                                "com.meizu.safe.permission.SmartBGActivity",
                            )
                    }
            }
            RomBrand.SAMSUNG -> {
                intents +=
                    Intent().apply {
                        component =
                            ComponentName(
                                "com.samsung.android.lool",
                                "com.samsung.android.sm.battery.ui.BatteryActivity",
                            )
                    }
            }
            RomBrand.GENERIC -> {
                // Will fallback to app details
            }
        }

        // Add standard flags to all candidates
        intents.forEach { it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
        return intents
    }

    private fun tryStartActivity(context: Context, intent: Intent): Boolean {
        return runCatching {
                val pm = context.packageManager
                if (intent.resolveActivity(pm) != null) {
                    context.startActivity(intent)
                    true
                } else {
                    false
                }
            }
            .getOrDefault(false)
    }
}
