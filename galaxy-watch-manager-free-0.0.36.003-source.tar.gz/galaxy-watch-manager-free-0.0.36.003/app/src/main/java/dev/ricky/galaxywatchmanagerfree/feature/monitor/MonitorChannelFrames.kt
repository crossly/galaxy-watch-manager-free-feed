package dev.ricky.galaxywatchmanagerfree.feature.monitor

import java.nio.ByteBuffer
import java.nio.ByteOrder
import org.json.JSONObject

/** Wear rr.c writes [uint32 BE length][zlib JSON] for each independent sync job. */
object MonitorChannelFrames {
    fun decode(bytes: ByteArray): List<JSONObject> {
        require(bytes.size <= 8 * 1024 * 1024) { "Monitor channel exceeds limit" }
        val input = ByteBuffer.wrap(bytes).order(ByteOrder.BIG_ENDIAN)
        val jobs = mutableListOf<JSONObject>()
        while (input.hasRemaining()) {
            require(input.remaining() >= 4) { "Truncated monitor job header" }
            val count = input.int
            require(count in 1..(8 * 1024 * 1024) && count <= input.remaining()) {
                "Invalid monitor job length"
            }
            require(jobs.size < 100) { "Too many monitor jobs" }
            val compressed = ByteArray(count).also(input::get)
            jobs +=
                JSONObject(
                    MonitorCompression.inflate(compressed, 4 * 1024 * 1024).toString(Charsets.UTF_8)
                )
        }
        return jobs
    }
}
