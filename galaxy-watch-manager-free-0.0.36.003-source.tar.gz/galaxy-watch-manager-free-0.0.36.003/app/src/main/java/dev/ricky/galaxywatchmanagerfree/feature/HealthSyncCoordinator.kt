package dev.ricky.galaxywatchmanagerfree.feature

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** 连接期间的健康同步调度。与页面生命周期无关；协议收发由调用方提供。 */
class HealthSyncCoordinator(
    private val scope: CoroutineScope,
    private val sendRequest: () -> Boolean,
    private val onStatus: (Status) -> Unit,
    private val onLog: (String) -> Unit = {},
) {
    enum class Status {
        DISCONNECTED,
        WAITING,
        SYNCING,
        IDLE,
        TIMED_OUT,
    }

    /** 内部静止相位；TIMED_OUT/IDLE 是发出的边沿事件，不改变静止相位。 */
    private enum class Phase {
        DISCONNECTED,
        WAITING,
        SYNCING,
    }

    private var phase = Phase.DISCONNECTED
    private var timeout: Job? = null

    /** Marks the session available; periodic requests belong to AutoQueryCoordinator. */
    @Synchronized
    fun start() {
        if (phase != Phase.DISCONNECTED) return
        phase = Phase.WAITING
        onStatus(Status.WAITING)
    }

    /** 自动、手动与全量刷新共享同一个入口，防止并发发起多次同步。 */
    @Synchronized
    fun request(send: () -> Boolean = sendRequest): Boolean {
        if (phase != Phase.WAITING) return false
        phase = Phase.SYNCING
        onStatus(Status.SYNCING)
        val sent =
            try {
                send()
            } catch (cancelled: CancellationException) {
                phase = Phase.WAITING
                onStatus(Status.TIMED_OUT)
                throw cancelled
            } catch (error: Exception) {
                onLog("[健康] 同步请求异常 category=${error.javaClass.simpleName}")
                false
            }
        if (!sent) {
            phase = Phase.WAITING
            onStatus(Status.TIMED_OUT)
            onLog("[健康] 请求未能入队，等待下次同步")
            return false
        }
        onLog("[健康] 已发起同步请求")
        armTimeout()
        return true
    }

    /** 仅对手表发来的 REQUEST 调用；SYNC_DATA 分块会延长超时，LOG_DATA 表示闭环。 */
    @Synchronized
    fun onWatchRequest(action: String) {
        if (phase == Phase.DISCONNECTED) return
        when (action) {
            "SYNC_DATA" -> {
                phase = Phase.SYNCING
                onStatus(Status.SYNCING)
                armTimeout()
            }
            "LOG_DATA" -> {
                phase = Phase.WAITING
                timeout?.cancel()
                timeout = null
                onStatus(Status.IDLE)
            }
        }
    }

    private fun armTimeout() {
        timeout?.cancel()
        timeout =
            scope.launch {
                delay(TIMEOUT_MS)
                synchronized(this@HealthSyncCoordinator) {
                    if (!isActive) return@synchronized
                    if (phase == Phase.DISCONNECTED) return@synchronized
                    phase = Phase.WAITING
                    onStatus(Status.TIMED_OUT)
                    onLog("[健康] 同步等待超时，可手动重试或等待下次自动同步")
                }
            }
    }

    @Synchronized
    fun stop() {
        phase = Phase.DISCONNECTED
        timeout?.cancel()
        timeout = null
        onStatus(Status.DISCONNECTED)
    }

    companion object {
        const val TIMEOUT_MS = 60_000L
    }
}
