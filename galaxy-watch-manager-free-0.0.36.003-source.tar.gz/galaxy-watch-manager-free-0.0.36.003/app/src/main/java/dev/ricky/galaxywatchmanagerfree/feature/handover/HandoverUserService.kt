package dev.ricky.galaxywatchmanagerfree.feature.handover

import android.content.pm.PackageManager
import android.os.IBinder
import dev.ricky.galaxywatchmanagerfree.handover.IHandoverService
import java.lang.reflect.InvocationTargetException
import java.lang.reflect.Method

/**
 * Shizuku user service: runs as shell (UID 2000) in a separate app_process.
 *
 * It talks to system_server through the hidden `IPackageManager` Binder. No shell command is ever
 * executed, no package is enumerated, and every incoming package name is checked against
 * [OfficialCompanionApp] here, independently from the UI-side checks.
 *
 * The class deliberately has no Context constructor: the service must not depend on an application
 * Context (a Shizuku user-service Context is not a normal Android application Context).
 */
class HandoverUserService : IHandoverService.Stub() {

    private val lock = Any()

    @Volatile private var cachedPackageManager: Any? = null

    @Volatile private var cachedMethods: PackageManagerMethods? = null

    override fun destroy() {
        System.exit(0)
    }

    override fun getApiVersion(): Int = API_VERSION

    override fun getPackageStates(userId: Int): Array<String> =
        synchronized(lock) {
            validateUser(userId)
            OfficialCompanionApp.entries
                .map { app ->
                    try {
                        "${app.packageName}|1|${getEnabledStateLocked(app.packageName, userId)}"
                    } catch (error: Throwable) {
                        if (isUnknownPackage(error)) {
                            "${app.packageName}|0|${EnabledState.UNKNOWN}"
                        } else {
                            throw IllegalStateException(
                                "Could not read enabled state for ${app.packageName}",
                                unwrap(error),
                            )
                        }
                    }
                }
                .toTypedArray()
        }

    override fun getEnabledState(packageName: String, userId: Int): Int =
        synchronized(lock) {
            requireAllowed(packageName)
            validateUser(userId)
            getEnabledStateLocked(packageName, userId)
        }

    override fun setEnabledState(packageName: String, state: Int, userId: Int): Int =
        synchronized(lock) {
            requireAllowed(packageName)
            validateUser(userId)
            if (!HandoverPolicy.canSet(state)) {
                throw IllegalArgumentException("Unsupported enabled state: $state")
            }

            val before = getEnabledStateLocked(packageName, userId)
            if (before == state) return@synchronized state

            setEnabledStateLocked(packageName, state, userId)
            val after = getEnabledStateLocked(packageName, userId)
            if (after != state) {
                throw IllegalStateException(
                    "Package $packageName did not reach enabled state $state (observed $after)"
                )
            }
            return@synchronized after
        }

    private fun getEnabledStateLocked(packageName: String, userId: Int): Int {
        val methods = packageManagerMethods()
        return try {
            methods.get.invoke(packageManager(), packageName, userId) as Int
        } catch (error: Throwable) {
            throw unwrap(error)
        }
    }

    private fun setEnabledStateLocked(packageName: String, state: Int, userId: Int) {
        val methods = packageManagerMethods()
        try {
            if (methods.setterArgumentCount == 5) {
                // Attribution only; the Binder calling UID is what the system enforces (shell).
                methods.set.invoke(packageManager(), packageName, state, 0, userId, SHELL_PACKAGE)
            } else {
                methods.set.invoke(packageManager(), packageName, state, 0, userId)
            }
        } catch (error: Throwable) {
            throw unwrap(error)
        }
    }

    private fun packageManagerMethods(): PackageManagerMethods {
        val existing = cachedMethods
        if (existing != null) return existing
        return synchronized(lock) {
            cachedMethods ?: loadMethods(packageManager()).also { cachedMethods = it }
        }
    }

    private fun packageManager(): Any =
        cachedPackageManager
            ?: synchronized(lock) {
                cachedPackageManager ?: loadPackageManager().also { cachedPackageManager = it }
            }

    private fun loadPackageManager(): Any {
        val serviceManager = Class.forName("android.os.ServiceManager")
        val binder =
            serviceManager.getMethod("getService", String::class.java).invoke(null, "package")
                as? IBinder ?: throw IllegalStateException("Android package service is unavailable")
        val stub = Class.forName("android.content.pm.IPackageManager\$Stub")
        return stub.getMethod("asInterface", IBinder::class.java).invoke(null, binder)
            ?: throw IllegalStateException("Could not obtain IPackageManager")
    }

    private fun loadMethods(packageManager: Any): PackageManagerMethods {
        val methods = packageManager.javaClass.methods
        val get =
            methods.firstOrNull { method ->
                method.name == "getApplicationEnabledSetting" &&
                    method.parameterTypes.size == 2 &&
                    method.parameterTypes[0] == String::class.java &&
                    method.parameterTypes[1].isIntType()
            }
                ?: throw IllegalStateException(
                    "IPackageManager.getApplicationEnabledSetting is missing"
                )

        val setFive =
            methods.firstOrNull { method ->
                method.name == "setApplicationEnabledSetting" &&
                    method.parameterTypes.size == 5 &&
                    method.parameterTypes[0] == String::class.java &&
                    method.parameterTypes[1].isIntType() &&
                    method.parameterTypes[2].isIntType() &&
                    method.parameterTypes[3].isIntType() &&
                    method.parameterTypes[4] == String::class.java
            }
        val setFour =
            methods.firstOrNull { method ->
                method.name == "setApplicationEnabledSetting" &&
                    method.parameterTypes.size == 4 &&
                    method.parameterTypes[0] == String::class.java &&
                    method.parameterTypes[1].isIntType() &&
                    method.parameterTypes[2].isIntType() &&
                    method.parameterTypes[3].isIntType()
            }
        val set =
            setFive
                ?: setFour
                ?: throw IllegalStateException(
                    "IPackageManager.setApplicationEnabledSetting is missing"
                )

        return PackageManagerMethods(
            get = get,
            set = set,
            setterArgumentCount = set.parameterTypes.size,
        )
    }

    private fun Class<*>.isIntType(): Boolean =
        this == Int::class.javaPrimitiveType || this == Int::class.java

    private fun requireAllowed(packageName: String) {
        if (!OfficialCompanionApp.isAllowed(packageName)) {
            throw SecurityException("Package is not an allowlisted companion app: $packageName")
        }
    }

    /** The app supplies its own user; all-users (-1) and out-of-range ids are rejected. */
    private fun validateUser(userId: Int) {
        if (userId < 0 || userId > MAX_USER_ID) {
            throw SecurityException("Invalid Android user id: $userId")
        }
    }

    private fun isUnknownPackage(error: Throwable): Boolean {
        var current: Throwable? = error
        while (current != null) {
            if (current is PackageManager.NameNotFoundException) return true
            if (
                current is IllegalArgumentException &&
                    current.message?.contains("Unknown package", ignoreCase = true) == true
            ) {
                return true
            }
            current = current.cause
        }
        return false
    }

    private fun unwrap(error: Throwable): Throwable {
        var current = error
        while (current is InvocationTargetException && current.cause != null) {
            current = current.cause!!
        }
        return current
    }

    private data class PackageManagerMethods(
        val get: Method,
        val set: Method,
        val setterArgumentCount: Int,
    )

    private companion object {
        const val API_VERSION = 1
        const val MAX_USER_ID = 99_999
        const val SHELL_PACKAGE = "com.android.shell"
    }
}
