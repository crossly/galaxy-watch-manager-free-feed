package dev.ricky.galaxywatchmanagerfree.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.core.UiNotify
import dev.ricky.galaxywatchmanagerfree.core.WatchController
import dev.ricky.galaxywatchmanagerfree.feature.NotificationFilterMode
import dev.ricky.galaxywatchmanagerfree.feature.NotificationFilterPreferences
import dev.ricky.galaxywatchmanagerfree.feature.WatchRepository
import dev.ricky.galaxywatchmanagerfree.feature.WatchState
import dev.ricky.galaxywatchmanagerfree.ui.components.*
import dev.ricky.galaxywatchmanagerfree.ui.theme.*

@Composable
fun NotificationsSettings(
    state: WatchState,
    repo: WatchRepository,
    onAppFilter: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val strings = context.resources

    fun checkPermission(): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)

    var permission by remember { mutableStateOf(checkPermission()) }
    var forwarding by remember { mutableStateOf(WatchController.forwardNotifications) }
    val filter by NotificationFilterPreferences.config.collectAsState()
    val noApps = filter.mode == NotificationFilterMode.SELECTED && filter.packages.isEmpty()
    val owner = LocalLifecycleOwner.current

    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                permission = checkPermission()
            }
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        // Status overview card
        item {
            val active = permission && forwarding && state.sessionReady && !noApps
            GroupedCard(cornerRadius = 24.dp, innerPadding = 18.dp) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    StatusOrb(
                        icon = Icons.Default.Notifications,
                        color = if (active) ElectricBlue else TextSecondary,
                        active = active,
                    )
                    Spacer(Modifier.width(16.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text =
                                when {
                                    !forwarding ->
                                        strings.getString(R.string.notification_forwarding_paused)
                                    noApps ->
                                        strings.getString(R.string.notification_filter_none_title)
                                    permission && state.sessionReady ->
                                        strings.getString(R.string.notification_forwarding_ready)
                                    !permission -> strings.getString(R.string.permission_required)
                                    else ->
                                        strings.getString(
                                            R.string.receive_notifications_on_your_watch
                                        )
                                },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary,
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text =
                                when {
                                    !forwarding ->
                                        strings.getString(
                                            R.string.notification_forwarding_explanation
                                        )
                                    noApps -> strings.getString(R.string.notification_filter_none)
                                    !permission ->
                                        strings.getString(R.string.notification_permission_guidance)
                                    !state.sessionReady ->
                                        strings.getString(R.string.notification_connection_guidance)
                                    else ->
                                        strings.getString(
                                            R.string.notification_connection_explanation
                                        )
                                },
                            style = MaterialTheme.typography.bodySmall,
                            lineHeight = 18.sp,
                            color = TextSecondary,
                        )
                    }
                }
            }
        }

        // Notification forwarding toggle
        item {
            SectionHeader(strings.getString(R.string.notification_settings))
            GroupedCard(innerPadding = 16.dp) {
                SettingSwitchRow(
                    title = strings.getString(R.string.forward_phone_notifications),
                    checked = forwarding,
                    subtitle =
                        strings.getString(R.string.send_new_phone_notifications_to_the_watch),
                    onCheckedChange = {
                        forwarding = it
                        WatchController.forwardNotifications = it
                    },
                )
            }
        }

        item {
            GroupedCard(innerPadding = 0.dp) {
                GroupedCardRow(
                    title = strings.getString(R.string.notification_filter_title),
                    subtitle =
                        if (filter.mode == NotificationFilterMode.ALL)
                            strings.getString(R.string.notification_filter_all)
                        else
                            strings.getString(
                                R.string.notification_filter_selected_count,
                                filter.packages.size,
                            ),
                    icon = Icons.Default.Apps,
                    showChevron = true,
                    onClick = onAppFilter,
                )
            }
        }

        // Permissions section
        item {
            SectionHeader(strings.getString(R.string.permissions))
            GroupedCard(innerPadding = 0.dp) {
                GroupedCardRow(
                    title = strings.getString(R.string.notification_access),
                    subtitle =
                        if (permission) strings.getString(R.string.granted)
                        else strings.getString(R.string.permission_required),
                    icon = if (permission) Icons.Default.VerifiedUser else Icons.Default.Lock,
                    iconTint = if (permission) EmeraldCharging else TextSecondary,
                    showChevron = true,
                    onClick = {
                        runCatching {
                            context.startActivity(
                                Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        }
                    },
                )
            }
        }

        // Test push & diagnostics section
        item {
            SectionHeader(strings.getString(R.string.advanced))
            GroupedCard(innerPadding = 0.dp) {
                GroupedCardRow(
                    title = strings.getString(R.string.test_notification),
                    subtitle =
                        if (state.sessionReady) {
                            strings.getString(R.string.send_a_notification_to_the_watch)
                        } else {
                            strings.getString(R.string.watch_disconnected)
                        },
                    icon = Icons.Default.NotificationsActive,
                    enabled = state.sessionReady,
                    onClick = {
                        UiNotify.show(
                            if (repo.sendTestNotification()) R.string.test_notification_sent
                            else R.string.request_send_failed
                        )
                    },
                )
            }
        }
    }
}
