package dev.ricky.galaxywatchmanagerfree.wcs

import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64

/** WCS protobuf envelope and WearableMessage frame encoder/decoder. */
object WcsFrame {

    const val QUEUE_DATA = 3L
    const val QUEUE_MESSAGE = 4L
    const val TYPE_REQUEST = QUEUE_DATA
    const val TYPE_RESPONSE = QUEUE_MESSAGE

    const val DEFAULT_CODE = 2L

    private val rng = SecureRandom()
    private val b64url = Base64.getUrlEncoder().withoutPadding()

    /** 官方 hbt.c/d + gyi.n：摘要覆盖序列化后的完整 inner 字节。 */
    fun messageDigest(inner: ByteArray): String =
        b64url.encodeToString(MessageDigest.getInstance("SHA-1").digest(inner))

    /** 仅供 LAB 构造错误摘要的负例；正常发送必须使用 messageDigest(inner)。 */
    fun newRequestId(): String = b64url.encodeToString(ByteArray(20).also(rng::nextBytes))

    // Frame assembly

    fun wearableMessage(
        path: String,
        payload: ByteArray,
        senderPkg: String,
        senderNode: String,
        destNode: String,
        sourceNode: String = "0000000",
        code: Long = DEFAULT_CODE,
        generation: Long = 4L,
    ): ByteArray {
        val body =
            Proto.integer(1, code) +
                Proto.string(2, senderPkg) +
                Proto.string(3, senderNode) +
                Proto.string(4, destNode) +
                Proto.integer(5, 0) +
                Proto.string(6, path) +
                Proto.bytes(7, payload) +
                Proto.string(8, sourceNode) +
                Proto.integer(10, generation) +
                Proto.integer(13, 1)
        return Proto.bytes(10, body)
    }

    /** Build a registered identity without byte-splicing a captured frame or reusing its digest. */
    fun nodeInfoFrame(nodeId: String, deviceName: String, timestamp: Long): ByteArray {
        require(nodeId.matches(Regex("[0-9a-f]{7,8}"))) { "Invalid registered node ID" }
        val node =
            Proto.string(1, nodeId) +
                Proto.string(2, deviceName) +
                Proto.integer(3, timestamp) +
                Proto.integer(4, 3) +
                Proto.integer(5, 1) +
                Proto.integer(6, 0)
        return envelopeNoType(Proto.bytes(7, node))
    }

    /** SyncStart V2 advertises durable replication cursors, never local/remote identity roles. */
    fun syncStartFrame(remoteNode: String, syncCursors: Map<String, Long> = emptyMap()): ByteArray {
        val body =
            Proto.integer(1, syncCursors[remoteNode] ?: -1L) +
                syncCursors.entries.fold(ByteArray(0)) { bytes, (node, sequence) ->
                    bytes + Proto.bytes(2, Proto.string(1, node) + Proto.integer(2, sequence))
                } +
                Proto.integer(3, 2L)
        val inner = Proto.bytes(8, body)

        return envelope(inner, type = TYPE_REQUEST)
    }

    fun envelope(
        inner: ByteArray,
        requestId: String = messageDigest(inner),
        type: Long = TYPE_REQUEST,
        f3: Long = 1,
        f4: Long = 1,
    ): ByteArray {
        val env =
            Proto.bytes(1, inner) +
                Proto.string(2, requestId) +
                Proto.integer(3, f3) +
                Proto.integer(4, f4) +
                Proto.integer(5, type)
        return LengthPrefix.pack(env)
    }

    /** 握手和心跳可不指定 queueId；f2 仍必须是内容摘要。 */
    fun envelopeNoType(inner: ByteArray, requestId: String = messageDigest(inner)): ByteArray {
        val env =
            Proto.bytes(1, inner) +
                Proto.string(2, requestId) +
                Proto.integer(3, 1) +
                Proto.integer(4, 1)
        return LengthPrefix.pack(env)
    }

    fun jsonFrame(
        path: String,
        json: String,
        senderPkg: String,
        senderNode: String,
        destNode: String,
        sourceNode: String = "0000000",
        type: Long = TYPE_RESPONSE,
        requestId: String? = null,
        code: Long = DEFAULT_CODE,
        generation: Long = 4L,
    ): ByteArray {
        val inner =
            wearableMessage(
                path,
                json.toByteArray(Charsets.UTF_8),
                senderPkg,
                senderNode,
                destNode,
                sourceNode,
                code = code,
                generation = generation,
            )
        return envelope(inner, requestId = requestId ?: messageDigest(inner), type = type)
    }

    /** 构造 Tag 9 DataItem 帧（用于向手表写入系统设置或数据项同步） */
    fun wearPathFrame(
        path: String,
        dataItems: List<ByteArray>,
        senderPkg: String,
        nodeId: String,
        seqId: Long = 2000L,
        type: Long = TYPE_REQUEST,
    ): ByteArray {
        var body = Proto.string(1, senderPkg) + Proto.string(2, path)
        dataItems.forEach { item -> body += Proto.bytes(4, item) }
        body +=
            Proto.integer(5, seqId) +
                Proto.integer(6, 0) +
                Proto.string(7, nodeId) +
                Proto.string(9, WcsPaths.SIGNATURE_PLUGIN) +
                Proto.integer(10, System.currentTimeMillis())

        val inner = Proto.bytes(9, body)
        return envelope(inner, type = type)
    }

    fun fromHex(s: String): ByteArray = Proto.fromHex(s)

    // Parsing

    sealed class Incoming {
        abstract val requestId: String?
        abstract val envType: Long?

        data class Wearable(
            override val requestId: String?,
            override val envType: Long?,
            val code: Long?,
            val senderPkg: String?,
            val senderNode: String?,
            val destNode: String?,
            val path: String,
            val payload: String,
            val payloadRaw: ByteArray,
            val sourceNode: String? = null,
        ) : Incoming()

        data class NodeInfo(
            override val requestId: String?,
            val nodeId: String?,
            val deviceName: String?,
            val timestamp: Long?,
            val kind: Long?,
            val protocolVersion: Long? = null,
            val minimumProtocolVersion: Long? = null,
        ) : Incoming() {
            override val envType: Long? = null
        }

        data class SyncStart(
            override val requestId: String?,
            val peerSequence: Long?,
            val cursors: Map<String, Long>,
            val version: Long?,
        ) : Incoming() {
            override val envType: Long? = null
        }

        data class WearPath(
            override val requestId: String?,
            override val envType: Long?,
            val senderPkg: String?,
            val path: String,
            val senderNode: String?,
            val dataItems: List<ByteArray> = emptyList(),
            val sourceNode: String? = null,
            val sequence: Long? = null,
            val deleted: Boolean = false,
        ) : Incoming() {
            /** 自动把所有 dataItems 解码合并为一个键值对 Map */
            val dataMap: Map<String, Any> by lazy {
                val merged = LinkedHashMap<String, Any>()
                dataItems.forEach { raw -> merged.putAll(DataMapDecoder.decode(raw)) }
                merged
            }
        }

        data class Heartbeat(override val requestId: String?) : Incoming() {
            override val envType: Long? = null
        }

        data class Unknown(
            override val requestId: String?,
            override val envType: Long?,
            val innerFields: List<Int>,
        ) : Incoming()
    }

    fun decode(envelopeBody: ByteArray): Incoming? {
        val env = Proto.parse(envelopeBody)
        val requestId = env.text(2)
        val envType = env.num(5)
        val innerRaw = env.raw(1) ?: return null
        val inner = Proto.parse(innerRaw)

        inner.nested(10)?.let { wm ->
            val raw = wm.raw(7) ?: ByteArray(0)
            val text = runCatching { raw.toString(Charsets.UTF_8) }.getOrDefault("")
            return Incoming.Wearable(
                requestId = requestId,
                envType = envType,
                code = wm.num(1),
                senderPkg = wm.text(2),
                senderNode = wm.text(3),
                destNode = wm.text(4),
                path = wm.text(6) ?: "",
                payload = text,
                payloadRaw = raw,
                sourceNode = wm.text(8),
            )
        }
        inner.nested(7)?.let { n ->
            return Incoming.NodeInfo(
                requestId = requestId,
                nodeId = n.text(1),
                deviceName = n.text(2),
                timestamp = n.num(3),
                kind = n.num(4),
                protocolVersion = n.num(5),
                minimumProtocolVersion = n.num(6),
            )
        }
        inner.nested(8)?.let { a ->
            val entries = a.fields[2].orEmpty().mapNotNull { it as? ByteArray }
            val cursors =
                entries
                    .mapNotNull { e ->
                        val m = Proto.parse(e)
                        val node = m.text(1) ?: return@mapNotNull null
                        val sequence = m.num(2) ?: return@mapNotNull null
                        node to sequence
                    }
                    .toMap()
            return Incoming.SyncStart(
                requestId = requestId,
                peerSequence = a.num(1),
                cursors = cursors,
                version = a.num(3),
            )
        }
        inner.nested(9)?.let { p ->
            val items = p.fields[4].orEmpty().mapNotNull { it as? ByteArray }
            return Incoming.WearPath(
                requestId = requestId,
                envType = envType,
                senderPkg = p.text(1),
                path = p.text(2) ?: "",
                senderNode = p.text(9),
                dataItems = items,
                sourceNode = p.text(7),
                sequence = p.num(5),
                deleted = p.num(6) == 1L,
            )
        }
        if (inner.has(11)) return Incoming.Heartbeat(requestId)
        return Incoming.Unknown(requestId, envType, inner.fields.keys.sorted())
    }

    /** 把 `wear://<node>/<path>` 归一化成 `/<path>`；同时返回路径里的 node */
    fun splitWearPath(path: String): Pair<String?, String> {
        if (!path.startsWith("wear://")) return null to path
        val rest = path.removePrefix("wear://")
        val slash = rest.indexOf('/')
        if (slash < 0) return rest to "/"
        return rest.substring(0, slash) to rest.substring(slash)
    }
}

/** Google Wear DataMap 纯 Kotlin 轻量解码器 (hqe / hqd / hqc / hqb proto)。 */
object DataMapDecoder {

    fun decode(raw: ByteArray): Map<String, Any> {
        val p = Proto.parse(raw)
        val entries = p.fields[1].orEmpty().mapNotNull { it as? ByteArray }
        return parseEntries(entries)
    }

    private fun parseEntries(entries: List<ByteArray>): Map<String, Any> {
        val out = LinkedHashMap<String, Any>()
        for (ent in entries) {
            val ep = Proto.parse(ent)
            val key = ep.text(1) ?: continue
            val valWrap = ep.nested(2) ?: continue
            decodeValue(valWrap)?.let { out[key] = it }
        }
        return out
    }

    /**
     * hqc{f1: type, f2: hqb value}。类型标签是权威：protobuf 会省略默认值（false / 0 / ""），
     * 因此按类型补齐默认值，不能靠“值字段是否存在”判断。
     */
    private fun decodeValue(valWrap: Proto.Message): Any? {
        val type = valWrap.num(1)?.takeIf { it != 0L } ?: DataMapEncoder.TYPE_BYTES
        val v = valWrap.nested(2) ?: EMPTY
        return when (type) {
            DataMapEncoder.TYPE_BYTES -> v.raw(1) ?: ByteArray(0)
            DataMapEncoder.TYPE_STRING -> v.text(2) ?: ""
            DataMapEncoder.TYPE_DOUBLE -> java.lang.Double.longBitsToDouble(v.num(3) ?: 0L)
            DataMapEncoder.TYPE_FLOAT -> java.lang.Float.intBitsToFloat((v.num(4) ?: 0L).toInt())
            DataMapEncoder.TYPE_INT64 -> v.num(5) ?: 0L
            DataMapEncoder.TYPE_INT32 -> (v.num(6) ?: 0L).toInt()
            DataMapEncoder.TYPE_FIXED32 -> (v.num(7) ?: 0L).toInt()
            DataMapEncoder.TYPE_BOOL -> (v.num(8) ?: 0L) != 0L
            DataMapEncoder.TYPE_MAP ->
                parseEntries(v.fields[9].orEmpty().mapNotNull { it as? ByteArray })
            DataMapEncoder.TYPE_ARRAY ->
                v.fields[10]
                    .orEmpty()
                    .mapNotNull { it as? ByteArray }
                    .map { decodeValue(Proto.parse(it)) }
            DataMapEncoder.TYPE_STRING_ARRAY ->
                v.fields[11].orEmpty().mapNotNull { (it as? ByteArray)?.toString(Charsets.UTF_8) }
            DataMapEncoder.TYPE_INT_ARRAY -> intArray(v)
            TYPE_VALUE_REFERENCE -> (v.num(14) ?: 0L).toInt()
            TYPE_NULL -> null
            else -> null
        }
    }

    /** type 12：int/long 数组，可能是 packed varint 单字段，也可能是重复 varint。 */
    private fun intArray(v: Proto.Message): List<Long> {
        val out = ArrayList<Long>()
        v.fields[12].orEmpty().forEach { field ->
            when (field) {
                is Long -> out += field
                is ByteArray -> unpackVarints(field, out)
            }
        }
        return out
    }

    private fun unpackVarints(buf: ByteArray, out: MutableList<Long>) {
        var i = 0
        while (i < buf.size) {
            var shift = 0
            var value = 0L
            var byte: Int
            do {
                if (i >= buf.size || shift > 63) return
                byte = buf[i++].toInt() and 0xFF
                value = value or ((byte and 0x7F).toLong() shl shift)
                shift += 7
            } while (byte and 0x80 != 0)
            out += value
        }
    }

    private const val TYPE_VALUE_REFERENCE = 13L
    private const val TYPE_NULL = 14L
    private val EMPTY = Proto.parse(ByteArray(0))
}

/** Google Wear DataMap protobuf encoder. */
object DataMapEncoder {

    const val TYPE_BYTES = 1L
    const val TYPE_STRING = 2L
    const val TYPE_DOUBLE = 3L
    const val TYPE_FLOAT = 4L
    const val TYPE_INT64 = 5L
    const val TYPE_INT32 = 6L
    const val TYPE_FIXED32 = 7L
    const val TYPE_BOOL = 8L
    const val TYPE_MAP = 9L
    const val TYPE_ARRAY = 10L
    const val TYPE_STRING_ARRAY = 11L
    const val TYPE_INT_ARRAY = 12L

    fun encode(map: Map<String, Any?>): ByteArray {
        var out = ByteArray(0)
        map.forEach { (k, v) -> if (v != null) out += Proto.bytes(1, entry(k, v)) }
        return out
    }

    fun entry(key: String, v: Any): ByteArray = Proto.string(1, key) + Proto.bytes(2, value(v))

    private fun value(v: Any): ByteArray {
        val encode: Pair<Long, ByteArray> =
            when (v) {
                is Boolean -> TYPE_BOOL to Proto.integer(8, if (v) 1L else 0L)
                is Int -> TYPE_INT32 to Proto.integer(6, v.toLong())
                is Long -> TYPE_INT64 to Proto.integer(5, v)
                is Float -> TYPE_FLOAT to Proto.integer(6, v.toLong())
                is Double -> TYPE_DOUBLE to Proto.integer(5, v.toLong())
                is ByteArray -> TYPE_BYTES to Proto.bytes(1, v)
                is Array<*> ->
                    TYPE_STRING_ARRAY to
                        v.fold(ByteArray(0)) { acc, e ->
                            if (e == null) acc else acc + Proto.string(11, e.toString())
                        }
                is List<*> ->
                    TYPE_ARRAY to
                        v.fold(ByteArray(0)) { acc, e ->
                            if (e == null) acc else acc + Proto.bytes(10, value(e))
                        }
                is Map<*, *> ->
                    TYPE_MAP to
                        encode(
                            v.entries
                                .mapNotNull { (k, vv) ->
                                    if (k is String && vv != null) k to vv else null
                                }
                                .toMap()
                        )
                else -> TYPE_STRING to Proto.string(2, v.toString())
            }
        return Proto.integer(1, encode.first) + Proto.bytes(2, encode.second)
    }
}

/** 4 字节大端长度前缀 */
object LengthPrefix {
    fun pack(body: ByteArray): ByteArray {
        val out = ByteArray(4 + body.size)
        val n = body.size
        out[0] = ((n ushr 24) and 0xFF).toByte()
        out[1] = ((n ushr 16) and 0xFF).toByte()
        out[2] = ((n ushr 8) and 0xFF).toByte()
        out[3] = (n and 0xFF).toByte()
        body.copyInto(out, 4)
        return out
    }

    fun readLength(b: ByteArray): Int =
        ((b[0].toInt() and 0xFF) shl 24) or
            ((b[1].toInt() and 0xFF) shl 16) or
            ((b[2].toInt() and 0xFF) shl 8) or
            (b[3].toInt() and 0xFF)
}
