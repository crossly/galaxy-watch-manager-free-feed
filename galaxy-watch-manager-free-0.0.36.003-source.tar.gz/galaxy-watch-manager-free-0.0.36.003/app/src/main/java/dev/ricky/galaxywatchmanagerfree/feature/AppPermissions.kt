package dev.ricky.galaxywatchmanagerfree.feature

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import dev.ricky.galaxywatchmanagerfree.core.ApkUpdater

enum class AppPermission {
    NEARBY_DEVICES,
    NOTIFICATION_ACCESS,
    APP_NOTIFICATIONS,
    BATTERY_OPTIMIZATION,
    INSTALL_PACKAGES,
    LEGACY_STORAGE;

    fun runtimePermissions(sdk: Int): List<String> =
        when (this) {
            NEARBY_DEVICES ->
                if (sdk >= 31)
                    listOf(
                        Manifest.permission.BLUETOOTH_CONNECT,
                        Manifest.permission.BLUETOOTH_SCAN,
                    )
                else emptyList()
            APP_NOTIFICATIONS ->
                if (sdk >= 33) listOf(Manifest.permission.POST_NOTIFICATIONS) else emptyList()
            LEGACY_STORAGE ->
                if (sdk <= 28) listOf(Manifest.permission.WRITE_EXTERNAL_STORAGE) else emptyList()
            else -> emptyList()
        }

    fun isGranted(context: Context): Boolean =
        when (this) {
            NOTIFICATION_ACCESS ->
                NotificationManagerCompat.getEnabledListenerPackages(context)
                    .contains(context.packageName)
            APP_NOTIFICATIONS -> NotificationManagerCompat.from(context).areNotificationsEnabled()
            BATTERY_OPTIMIZATION -> KeepAliveHelper.isBatteryOptimizationIgnored(context)
            INSTALL_PACKAGES -> ApkUpdater.canInstall(context)
            else ->
                runtimePermissions(Build.VERSION.SDK_INT).all {
                    ContextCompat.checkSelfPermission(context, it) ==
                        PackageManager.PERMISSION_GRANTED
                }
        }

    companion object {
        fun applicable(sdk: Int): List<AppPermission> = buildList {
            if (sdk >= 31) add(NEARBY_DEVICES)
            add(NOTIFICATION_ACCESS)
            add(APP_NOTIFICATIONS)
            add(BATTERY_OPTIMIZATION)
            add(INSTALL_PACKAGES)
            if (sdk <= 28) add(LEGACY_STORAGE)
        }
    }
}
