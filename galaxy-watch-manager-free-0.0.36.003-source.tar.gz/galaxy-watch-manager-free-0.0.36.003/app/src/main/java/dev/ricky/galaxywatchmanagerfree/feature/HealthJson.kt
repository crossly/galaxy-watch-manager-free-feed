package dev.ricky.galaxywatchmanagerfree.feature

import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.util.Base64
import java.util.zip.GZIPInputStream

/** Shared bounded decoder for health JSON and nested Base64(gzip(JSON)) fields. */
object HealthJson {
    private const val MAX_JSON_BYTES = 48 * 1024 * 1024
    private const val MAX_BLOB_BYTES = 8 * 1024 * 1024

    fun inflateJson(encoded: String, maxBytes: Int = MAX_JSON_BYTES): String {
        val raw = Base64.getDecoder().decode(encoded)
        return GZIPInputStream(ByteArrayInputStream(raw)).use { input ->
            val output = java.io.ByteArrayOutputStream()
            val buffer = ByteArray(16 * 1024)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                require(output.size().toLong() + count <= maxBytes) { "Health JSON exceeds $maxBytes bytes" }
                output.write(buffer, 0, count)
            }
            output.toString(Charsets.UTF_8.name())
        }
    }

    fun entries(body: String): JSONArray {
        val json = inflateJson(body).trim()
        return if (json.startsWith("[")) JSONArray(json) else JSONArray().put(JSONObject(json))
    }

    fun array(value: Any?): JSONArray? = when (value) {
        is JSONArray -> value
        is String -> runCatching {
            val text = value.trim()
            JSONArray(if (text.startsWith("[")) text else inflateJson(text, MAX_BLOB_BYTES))
        }.getOrNull()
        else -> null
    }
}
