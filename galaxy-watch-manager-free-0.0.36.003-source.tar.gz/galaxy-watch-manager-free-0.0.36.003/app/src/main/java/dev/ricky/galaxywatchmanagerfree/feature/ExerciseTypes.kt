package dev.ricky.galaxywatchmanagerfree.feature

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.DirectionsBike
import androidx.compose.material.icons.automirrored.filled.DirectionsRun
import androidx.compose.material.icons.automirrored.filled.DirectionsWalk
import androidx.compose.material.icons.filled.DownhillSkiing
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Kayaking
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pool
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.Sports
import androidx.compose.material.icons.filled.SportsScore
import androidx.compose.material.icons.filled.Terrain
import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.ui.theme.ElectricBlue
import dev.ricky.galaxywatchmanagerfree.ui.theme.HealthOxygen
import dev.ricky.galaxywatchmanagerfree.ui.theme.HealthSleep
import dev.ricky.galaxywatchmanagerfree.ui.theme.HealthSteps
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextSecondary

object ExerciseTypes {
    private val names =
        mapOf(
            -1 to R.string.workout_unclassified,
            0 to R.string.workout_0,
            1001 to R.string.workout_1001,
            1002 to R.string.workout_1002,
            1006 to R.string.workout_1006,
            1007 to R.string.workout_1007,
            1008 to R.string.workout_1008,
            2001 to R.string.workout_2001,
            2002 to R.string.workout_2002,
            2003 to R.string.workout_2003,
            3001 to R.string.workout_3001,
            3003 to R.string.workout_3003,
            4001 to R.string.workout_4001,
            4002 to R.string.workout_4002,
            4003 to R.string.workout_4003,
            4004 to R.string.workout_4004,
            4005 to R.string.workout_4005,
            4006 to R.string.workout_4006,
            5001 to R.string.workout_5001,
            5002 to R.string.workout_5002,
            6001 to R.string.workout_6001,
            6002 to R.string.workout_6002,
            6003 to R.string.workout_6003,
            6004 to R.string.workout_6004,
            6005 to R.string.workout_6005,
            7002 to R.string.workout_7002,
            7003 to R.string.workout_7003,
            8001 to R.string.workout_8001,
            8002 to R.string.workout_8002,
            8003 to R.string.workout_8003,
            8004 to R.string.workout_8004,
            9001 to R.string.workout_9001,
            9002 to R.string.workout_9002,
            10001 to R.string.workout_10001,
            10002 to R.string.workout_10002,
            10003 to R.string.workout_10003,
            10004 to R.string.workout_10004,
            10005 to R.string.workout_10005,
            10006 to R.string.workout_10006,
            10007 to R.string.workout_10007,
            10008 to R.string.workout_10008,
            10009 to R.string.workout_10009,
            10010 to R.string.workout_10010,
            10011 to R.string.workout_10011,
            10012 to R.string.workout_10012,
            10013 to R.string.workout_10013,
            10014 to R.string.workout_10014,
            10015 to R.string.workout_10015,
            10016 to R.string.workout_10016,
            10017 to R.string.workout_10017,
            10018 to R.string.workout_10018,
            10019 to R.string.workout_10019,
            10020 to R.string.workout_10020,
            10021 to R.string.workout_10021,
            10022 to R.string.workout_10022,
            10023 to R.string.workout_10023,
            10024 to R.string.workout_10024,
            10025 to R.string.workout_10025,
            10026 to R.string.workout_10026,
            10027 to R.string.workout_10027,
            10028 to R.string.workout_10028,
            10029 to R.string.workout_10029,
            11001 to R.string.workout_11001,
            11002 to R.string.workout_11002,
            11004 to R.string.workout_11004,
            11005 to R.string.workout_11005,
            11007 to R.string.workout_11007,
            11008 to R.string.workout_11008,
            11009 to R.string.workout_11009,
            12001 to R.string.workout_12001,
            13001 to R.string.workout_13001,
            13002 to R.string.workout_13002,
            13003 to R.string.workout_13003,
            13004 to R.string.workout_13004,
            13005 to R.string.workout_13005,
            14001 to R.string.workout_14001,
            14002 to R.string.workout_14002,
            14003 to R.string.workout_14003,
            14004 to R.string.workout_14004,
            14005 to R.string.workout_14005,
            14006 to R.string.workout_14006,
            14007 to R.string.workout_14007,
            14008 to R.string.workout_14008,
            14009 to R.string.workout_14009,
            14010 to R.string.workout_14010,
            14011 to R.string.workout_14011,
            14012 to R.string.workout_14012,
            14013 to R.string.workout_14013,
            15001 to R.string.workout_15001,
            15002 to R.string.workout_15002,
            15003 to R.string.workout_15003,
            15004 to R.string.workout_15004,
            15005 to R.string.workout_15005,
            15006 to R.string.workout_15006,
            15007 to R.string.workout_15007,
            16001 to R.string.workout_16001,
            16002 to R.string.workout_16002,
            16003 to R.string.workout_16003,
            16004 to R.string.workout_16004,
            16006 to R.string.workout_16006,
            16007 to R.string.workout_16007,
            16008 to R.string.workout_16008,
            16009 to R.string.workout_16009,
            51001 to R.string.workout_51001,
            51002 to R.string.workout_51002,
            51003 to R.string.workout_51003,
            51004 to R.string.workout_51004,
            51005 to R.string.workout_51005,
            51006 to R.string.workout_51006,
            51007 to R.string.workout_51007,
            51008 to R.string.workout_51008,
            51009 to R.string.workout_51009,
            51010 to R.string.workout_51010,
            99999 to R.string.workout_99999,
            999999 to R.string.workout_999999,
            9001002 to R.string.workout_9001002,
            9014001 to R.string.workout_9014001,
        )

    val supportedCodes: Set<Int> = names.keys

    fun nameRes(code: Int): Int = names[code] ?: R.string.workout_unknown

    enum class VisualCategory {
        WALKING,
        RUNNING,
        CYCLING,
        SWIMMING,
        FITNESS,
        OUTDOOR,
        WELLNESS,
        SPORTS,
        DANCING,
        WINTER,
        WATER,
        ROUTINE,
        MISC,
    }

    fun category(code: Int, countType: Int = -1): VisualCategory =
        when (code) {
            1001 -> VisualCategory.WALKING
            1002,
            1007,
            1008,
            15005,
            51007,
            9001002 -> VisualCategory.RUNNING
            11007,
            13004,
            15003,
            51008 -> VisualCategory.CYCLING
            14001,
            9014001,
            51009 -> VisualCategory.SWIMMING
            in 10004..10027,
            15001,
            15002,
            15004,
            15006,
            15007 -> VisualCategory.FITNESS
            11001,
            11009,
            13001,
            13002,
            13003,
            13005,
            51010 -> VisualCategory.OUTDOOR
            9001,
            9002,
            10001,
            12001 -> VisualCategory.WELLNESS
            in 2001..2003,
            in 3001..3003,
            in 4001..4006,
            in 5001..5002,
            in 6001..6005,
            in 7002..7003,
            11004,
            11005,
            11008 -> VisualCategory.SPORTS
            in 8001..8004 -> VisualCategory.DANCING
            in 16001..16009 -> VisualCategory.WINTER
            in 14002..14013 -> VisualCategory.WATER
            51005,
            51006 -> VisualCategory.ROUTINE
            else -> if (countType in 30001..30004) VisualCategory.FITNESS else VisualCategory.MISC
        }

    fun icon(code: Int, countType: Int = -1): ImageVector =
        when (category(code, countType)) {
            VisualCategory.WALKING -> Icons.AutoMirrored.Filled.DirectionsWalk
            VisualCategory.RUNNING -> Icons.AutoMirrored.Filled.DirectionsRun
            VisualCategory.CYCLING -> Icons.AutoMirrored.Filled.DirectionsBike
            VisualCategory.SWIMMING -> Icons.Default.Pool
            VisualCategory.FITNESS -> Icons.Default.FitnessCenter
            VisualCategory.OUTDOOR -> Icons.Default.Terrain
            VisualCategory.WELLNESS -> Icons.Default.SelfImprovement
            VisualCategory.SPORTS -> Icons.Default.Sports
            VisualCategory.DANCING -> Icons.Default.MusicNote
            VisualCategory.WINTER -> Icons.Default.DownhillSkiing
            VisualCategory.WATER -> Icons.Default.Kayaking
            VisualCategory.ROUTINE -> Icons.Default.Layers
            VisualCategory.MISC -> Icons.Default.SportsScore
        }

    @Composable
    @ReadOnlyComposable
    fun accentColor(code: Int, countType: Int = -1): Color {
        val dark = androidx.compose.material3.MaterialTheme.colorScheme.surface.luminance() < 0.5f
        return when (category(code, countType)) {
            VisualCategory.WALKING,
            VisualCategory.RUNNING -> HealthSteps
            VisualCategory.CYCLING -> ElectricBlue
            VisualCategory.SWIMMING -> HealthOxygen
            VisualCategory.FITNESS -> if (dark) Color(0xFFFB8500) else Color(0xFFD46B08)
            VisualCategory.OUTDOOR -> Color(0xFF2A9D8F)
            VisualCategory.WELLNESS -> HealthSleep
            VisualCategory.SPORTS -> if (dark) Color(0xFFFFB703) else Color(0xFFD48806)
            VisualCategory.DANCING -> Color(0xFFF72585)
            VisualCategory.WINTER -> if (dark) Color(0xFF48CAE4) else Color(0xFF096DD9)
            VisualCategory.WATER -> Color(0xFF0077B6)
            VisualCategory.ROUTINE -> Color(0xFF4361EE)
            VisualCategory.MISC -> TextSecondary
        }
    }
}
