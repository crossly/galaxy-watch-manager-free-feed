package dev.ricky.galaxywatchmanagerfree.core

import android.graphics.*
import android.text.StaticLayout
import android.text.TextPaint
import dev.ricky.galaxywatchmanagerfree.feature.monitor.EcgRecord
import java.util.Locale
import kotlin.math.*

/** Renders all samples in sequential 5-second strips; independent of the on-screen viewport. */
object EcgImageRenderer {
    fun render(record: EcgRecord, title: String, scaleLabel: String): Bitmap {
        require(record.waveform.isNotEmpty() && record.waveform.size <= 120_000)
        require(record.sampleRate.isFinite() && record.sampleRate > 0)
        require(record.waveform.all { it.isFinite() })
        val duration = record.waveform.size / record.sampleRate
        require(duration <= 240.0)
        val width = 1400
        val margin = 70f
        val secondsPerRow = 5.0
        val pxPerSecond = (width - margin * 2) / secondsPerRow.toFloat()
        val minor = pxPerSecond * .04f
        val mvScale = minor * 10
        val amplitude = record.waveform.maxOf { abs(it) }.coerceAtLeast(1f)
        val rowHeight = (amplitude * mvScale * 2 + 60).toInt().coerceAtLeast(260)
        val rows = ceil(duration / secondsPerRow).toInt().coerceAtLeast(1)
        val titlePaint =
            TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(35, 35, 40)
                textSize = 27f
            }
        val titleLayout =
            StaticLayout.Builder.obtain(
                    title,
                    0,
                    title.length,
                    titlePaint,
                    (width - 2 * margin).toInt(),
                )
                .build()
        val header = 170 + titleLayout.height
        val height = header.toLong() + rows.toLong() * (rowHeight + 50) + 50
        require(width * height <= 16_000_000L) { "ECG image exceeds memory budget" }
        val bitmap = Bitmap.createBitmap(width, height.toInt(), Bitmap.Config.ARGB_8888)
        try {
            val canvas = Canvas(bitmap)
            canvas.drawColor(Color.WHITE)
            val paint =
                Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.rgb(35, 35, 40)
                    textSize = 27f
                }
            canvas.save()
            canvas.translate(margin, 24f)
            titleLayout.draw(canvas)
            canvas.restore()
            paint.textSize = 22f
            canvas.drawText(
                "${record.id}  |  ${record.sampleRate} Hz  |  ${String.format(Locale.ROOT, "%.2f", duration)} s",
                margin,
                64f + titleLayout.height,
                paint,
            )
            paint.textSize = 18f
            canvas.drawText(scaleLabel, margin, 104f + titleLayout.height, paint)
            for (row in 0 until rows) {
                val top = header + row * (rowHeight + 50f)
                val start = row * secondsPerRow
                val end = min(duration, start + secondsPerRow)
                val center = top + rowHeight / 2
                paint.style = Paint.Style.STROKE
                var line = 0
                while (margin + line * minor <= width - margin) {
                    paint.color =
                        if (line % 5 == 0) Color.rgb(236, 175, 185) else Color.rgb(250, 220, 225)
                    paint.strokeWidth = if (line % 5 == 0) 1.2f else .6f
                    val x = margin + line * minor
                    canvas.drawLine(x, top, x, top + rowHeight, paint)
                    line++
                }
                line = -ceil(rowHeight / 2f / minor).toInt()
                while (center + line * minor <= top + rowHeight) {
                    val y = center + line * minor
                    if (y >= top) {
                        paint.color =
                            if (line % 5 == 0) Color.rgb(236, 175, 185)
                            else Color.rgb(250, 220, 225)
                        canvas.drawLine(margin, y, width - margin, y, paint)
                    }
                    line++
                }
                val path = Path()
                val from = (start * record.sampleRate).toInt()
                val until = ceil(end * record.sampleRate).toInt().coerceAtMost(record.waveform.size)
                for (sample in from until until) {
                    val x = margin + ((sample / record.sampleRate - start) * pxPerSecond).toFloat()
                    val y = center - record.waveform[sample] * mvScale
                    if (sample == from) path.moveTo(x, y) else path.lineTo(x, y)
                }
                paint.color = Color.rgb(160, 30, 60)
                paint.strokeWidth = 1.8f
                canvas.drawPath(path, paint)
                paint.style = Paint.Style.FILL
                paint.color = Color.DKGRAY
                paint.textSize = 20f
                canvas.drawText(
                    String.format(Locale.ROOT, "%.0f–%.2f s", start, end),
                    margin,
                    top - 12,
                    paint,
                )
            }
            return bitmap
        } catch (error: Throwable) {
            bitmap.recycle()
            throw error
        }
    }
}
