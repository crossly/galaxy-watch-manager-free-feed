package dev.ricky.galaxywatchmanagerfree.ui.onboarding

import dev.ricky.galaxywatchmanagerfree.core.WatchDiscovery
import dev.ricky.galaxywatchmanagerfree.ui.screens.connection.BondedWatch

enum class OnboardingStep {
    CHECK,
    INSTALL,
    IDENTITY,
    RELEASE,
    CONNECT,
    DONE,
}

/** Steps shown to the user; CHECK and INSTALL share the first indicator slot. */
internal fun stepIndex(step: OnboardingStep): Int =
    when (step) {
        OnboardingStep.CHECK,
        OnboardingStep.INSTALL -> 0
        OnboardingStep.IDENTITY -> 1
        OnboardingStep.RELEASE -> 2
        OnboardingStep.CONNECT -> 3
        OnboardingStep.DONE -> 4
    }

internal enum class OnboardingCheckAction {
    GRANT_PERMISSION,
    OPEN_BLUETOOTH,
    OPEN_WEAR_DETAILS,
    SHOW_PAIRING_GUIDE,
    SELECT_WATCH,
    CONTINUE,
}

internal fun resolveCheckAction(
    permissionMissing: Boolean,
    bluetoothUnavailable: Boolean,
    hasGoogleWear: Boolean,
    wearEnabled: Boolean,
    hasBondedDevices: Boolean,
    hasSelectedWatch: Boolean,
): OnboardingCheckAction =
    when {
        permissionMissing -> OnboardingCheckAction.GRANT_PERMISSION
        bluetoothUnavailable -> OnboardingCheckAction.OPEN_BLUETOOTH
        !hasGoogleWear -> OnboardingCheckAction.SHOW_PAIRING_GUIDE
        !wearEnabled -> OnboardingCheckAction.OPEN_WEAR_DETAILS
        !hasBondedDevices -> OnboardingCheckAction.SHOW_PAIRING_GUIDE
        !hasSelectedWatch -> OnboardingCheckAction.SELECT_WATCH
        else -> OnboardingCheckAction.CONTINUE
    }

internal fun resolveSelectedMac(watches: List<BondedWatch>, current: String): String {
    val trimmed = current.trim()
    if (trimmed.isNotEmpty() && watches.any { it.mac.equals(trimmed, ignoreCase = true) }) {
        return watches.first { it.mac.equals(trimmed, ignoreCase = true) }.mac
    }
    val candidates = watches.map { WatchDiscovery.Candidate(it.name, it.mac) }
    return WatchDiscovery.pick(candidates, null)?.address.orEmpty()
}

internal fun initialOnboardingStep(
    ready: Boolean,
    handoverPreparing: Boolean,
    hasPendingIdentity: Boolean,
    hasConfirmedIdentity: Boolean,
): OnboardingStep =
    when {
        ready -> OnboardingStep.DONE
        handoverPreparing || hasPendingIdentity -> OnboardingStep.RELEASE
        hasConfirmedIdentity -> OnboardingStep.CONNECT
        else -> OnboardingStep.CHECK
    }
