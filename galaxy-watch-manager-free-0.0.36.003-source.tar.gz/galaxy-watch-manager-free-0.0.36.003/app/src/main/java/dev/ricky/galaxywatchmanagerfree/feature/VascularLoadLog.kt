package dev.ricky.galaxywatchmanagerfree.feature

import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.temporal.ChronoUnit
import org.json.JSONObject

object VascularLoadLog {
    const val MODULE = "com.samsung.shealth.mean_arterial_pressure"

    enum class Type(val code: Int) {
        RESET(1),
        BASELINE(2),
        MEASUREMENT(3),
    }

    enum class Band {
        HIGHER,
        SLIGHTLY_HIGHER,
        STEADY,
        SLIGHTLY_LOWER,
        LOWER,
        OUT_OF_RANGE_UNKNOWN,
        NOT_ENOUGH_DATA,
    }

    data class Entry(
        val id: String,
        val startMillis: Long,
        val endMillis: Long,
        val type: Type,
        val measurement: Float?,
        val timeOffset: Long = 0L,
    ) {
        val band: Band
            get() = bandOf(if (type == Type.MEASUREMENT) measurement else null)

        val chartValue: Float?
            get() =
                when {
                    type == Type.BASELINE && measurement != null -> 2.5f
                    band in displayBands -> measurement?.let { 2.5f - 0.2f * it }
                    else -> null
                }

        val trackingDate: LocalDate
            get() {
                val local = Instant.ofEpochMilli(endMillis).atOffset(offset)
                return if (type != Type.RESET && local.toLocalTime() >= LocalTime.of(20, 30))
                    local.toLocalDate().plusDays(1)
                else local.toLocalDate()
            }

        private val offset: ZoneOffset
            get() = ZoneOffset.ofTotalSeconds((timeOffset / 1000).toInt())
    }

    data class Snapshot(
        val records: List<Entry> = emptyList(),
        val baseline: Entry? = null,
        val baselineComplete: Boolean = false,
        val latest: Entry? = null,
        val baselineNights: Int = 0,
    ) {
        val measurements: List<Entry>
            get() = records.filter { it.type == Type.MEASUREMENT }
    }

    private val displayBands =
        setOf(Band.HIGHER, Band.SLIGHTLY_HIGHER, Band.STEADY, Band.SLIGHTLY_LOWER, Band.LOWER)

    fun bandOf(value: Float?): Band =
        when {
            value == null -> Band.NOT_ENOUGH_DATA
            !value.isFinite() || value < -12.5f || value > 12.5f -> Band.OUT_OF_RANGE_UNKNOWN
            value < -7.5f -> Band.HIGHER
            value < -2.5f -> Band.SLIGHTLY_HIGHER
            value <= 2.5f -> Band.STEADY
            value <= 7.5f -> Band.SLIGHTLY_LOWER
            else -> Band.LOWER
        }

    fun parse(record: JSONObject): Entry? {
        fun key(name: String): String = if (record.has(name)) name else "$MODULE.$name"
        val type = Type.entries.firstOrNull { it.code == record.optInt(key("type")) } ?: return null
        val start = record.optLong(key("start_time"))
        val end = record.optLong(key("end_time"), start)
        val offset = record.optLong(key("time_offset"))
        if (start <= 0 || end < start || offset !in -64_800_000L..64_800_000L) return null
        val value =
            record.optDouble(key("measurement"), Double.NaN).toFloat().takeIf { it.isFinite() }
        return Entry(HealthRecordStore.identity(record), start, end, type, value, offset)
    }

    fun project(
        records: List<JSONObject>,
        now: Long = System.currentTimeMillis(),
        zone: ZoneId = ZoneId.systemDefault(),
    ): Snapshot {
        val entries =
            records
                .mapNotNull(::parse)
                .filter { it.endMillis <= now }
                .sortedWith(
                    compareBy<Entry> { it.endMillis }.thenBy { if (it.type == Type.RESET) 1 else 0 }
                )
        val controls = entries.filter { it.type != Type.MEASUREMENT }.asReversed()
        val control = controls.firstOrNull()
        val complete = control?.type == Type.BASELINE && control.measurement != null
        val baseline = control?.takeIf { complete }
        val latest =
            if (baseline == null) null
            else
                entries.lastOrNull {
                    it.type == Type.MEASUREMENT && it.endMillis >= baseline.endMillis
                }
        val current = Instant.ofEpochMilli(now).atZone(zone)
        val reference =
            if (current.toLocalTime() < LocalTime.of(13, 30)) current.toLocalDate()
            else current.toLocalDate().plusDays(1)
        fun fresh(entry: Entry, days: Long): Boolean =
            ChronoUnit.DAYS.between(entry.trackingDate, reference) <= days
        // Samsung counts the newest consecutive BASELINE rows, never inferred sleep nights.
        val nights =
            when {
                control == null || control.type == Type.RESET -> 0
                complete -> controls.takeWhile { it.type == Type.BASELINE }.take(3).size
                controls.getOrNull(1)?.let {
                    it.type == Type.BASELINE &&
                        ChronoUnit.DAYS.between(it.trackingDate, control.trackingDate) <= 12 &&
                        fresh(it, 13)
                } == true -> 2
                fresh(control, 12) -> 1
                else -> 0
            }
        return Snapshot(entries, baseline, complete, latest, nights)
    }
}
