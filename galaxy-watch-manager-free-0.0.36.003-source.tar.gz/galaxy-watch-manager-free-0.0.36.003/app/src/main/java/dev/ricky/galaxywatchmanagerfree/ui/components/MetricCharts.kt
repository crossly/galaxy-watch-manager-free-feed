package dev.ricky.galaxywatchmanagerfree.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.feature.HealthMetric
import dev.ricky.galaxywatchmanagerfree.feature.HealthMetricLog
import dev.ricky.galaxywatchmanagerfree.ui.theme.CardBorder
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextSecondary
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextTertiary

/** 指标折线图：横轴为当天时间（0–24 时），纵轴按数据范围自适应 */
@Composable
fun MetricLineChart(
    samples: List<HealthMetricLog.Sample>,
    metric: HealthMetric,
    accent: Color,
    modifier: Modifier = Modifier,
    day: java.time.LocalDate = java.time.LocalDate.now(),
    zone: java.time.ZoneId = java.time.ZoneId.systemDefault(),
) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources

    val sorted = remember(samples, day, zone) { HealthMetricLog.daily(samples, day, zone).samples }
    val gridColor = CardBorder.copy(alpha = 0.55f)
    val labelColor = TextTertiary
    val range = rememberAxisRange(sorted, metric)
    val positions = remember(sorted, zone) { sorted.map { chartDayFraction(it.ts, zone) } }
    var selectedSample by
        remember(sorted, day, zone) { mutableStateOf<HealthMetricLog.Sample?>(null) }

    Column(modifier = modifier.fillMaxWidth()) {
        if (selectedSample != null) {
            val sample = selectedSample!!
            val timeStr = formatClock(sample.ts, zone)
            Box(
                modifier =
                    Modifier.fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(accent.copy(alpha = 0.12f))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = timeStr,
                        style = androidx.compose.material3.MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = accent,
                        fontFamily = FontFamily.Monospace,
                    )
                    Text(
                        text =
                            "${metric.format(sample.value)} ${strings.getString(metric.unitRes)}",
                        style = androidx.compose.material3.MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = accent,
                        fontFamily = FontFamily.Monospace,
                    )
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
        }

        Canvas(
            modifier =
                Modifier.fillMaxWidth().height(132.dp).testTag("metric_chart").chartProbe(
                    positions,
                    sorted.indexOf(selectedSample).takeIf { it >= 0 },
                    label = strings.getString(metric.labelRes),
                    readings =
                        sorted.map {
                            "${formatClock(it.ts, zone)} · ${metric.format(it.value)} ${strings.getString(metric.unitRes)}"
                        },
                ) { index ->
                    selectedSample = index?.let(sorted::get)
                }
        ) {
            val low = range.start
            val high = range.endInclusive
            val usable = (size.height - 10.dp.toPx()).coerceAtLeast(1f)

            listOf(low, (low + high) / 2f, high).forEach { value ->
                val y = ((high - value) / (high - low) * usable).coerceIn(0f, usable)
                drawLine(gridColor, Offset(0f, y), Offset(size.width, y), strokeWidth = 1f)
            }
            listOf(0f, 6f, 12f, 18f, 24f).forEach { hour ->
                val x = size.width * hour / 24f
                drawLine(gridColor, Offset(x, 0f), Offset(x, usable), strokeWidth = 1f)
            }
            if (sorted.isEmpty()) return@Canvas

            val offsets =
                sorted.mapIndexed { index, sample ->
                    val y = ((high - sample.value) / (high - low) * usable).coerceIn(0f, usable)
                    Offset(size.width * positions[index], y)
                }
            drawReadingCurve(
                offsets,
                accent,
                usable,
                sorted.indexOf(selectedSample).takeIf { it >= 0 },
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        ChartTimeAxis()
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text =
                strings.getString(R.string.y_axis) +
                    metric.format(range.start) +
                    "–" +
                    metric.format(range.endInclusive) +
                    strings.getString(metric.unitRes),
            style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
            color = labelColor,
            fontFamily = FontFamily.Monospace,
        )
    }
}

/** 近 7 天均值柱状图（缺数据留空） */
@Composable
fun MetricWeekBars(
    values: List<Float?>,
    metric: HealthMetric,
    modifier: Modifier = Modifier,
    accent: Color? = null,
) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources

    val data = if (values.size == 7) values else List(7) { null }
    val known = data.filterNotNull()
    val today = java.time.LocalDate.now()
    val labels =
        (6 downTo 0).map { offset ->
            when (today.minusDays(offset.toLong()).dayOfWeek.value) {
                1 -> strings.getString(R.string.mon)
                2 -> strings.getString(R.string.tue)
                3 -> strings.getString(R.string.wed)
                4 -> strings.getString(R.string.thu)
                5 -> strings.getString(R.string.fri)
                6 -> strings.getString(R.string.sat)
                else -> strings.getString(R.string.sun)
            }
        }
    if (known.isEmpty()) {
        Text(
            strings.getString(R.string.no_records_in_the_past_7_days),
            style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
            color = TextTertiary,
        )
        return
    }
    val low = known.min()
    val high = known.max()
    val span = (high - low).takeIf { it > 0.0001f } ?: 1f
    val barColor = accent ?: dev.ricky.galaxywatchmanagerfree.ui.theme.HealthOxygen
    val track = CardBorder.copy(alpha = 0.4f)
    val labelColor = TextTertiary
    val secondary = TextSecondary

    Column(modifier = modifier.fillMaxWidth()) {
        Canvas(modifier = Modifier.fillMaxWidth().height(64.dp)) {
            val slot = size.width / 7f
            val barWidth = slot * 0.44f
            data.forEachIndexed { index, value ->
                val centerX = slot * index + slot / 2f
                if (value == null) {
                    drawLine(
                        track,
                        Offset(centerX, size.height - 1.dp.toPx()),
                        Offset(centerX, size.height - 1.dp.toPx()),
                        strokeWidth = 2.dp.toPx(),
                    )
                    return@forEachIndexed
                }
                val ratio = ((value - low) / span).coerceIn(0f, 1f)
                val height = (size.height * (0.25f + 0.75f * ratio)).coerceAtLeast(3.dp.toPx())
                drawRoundRect(
                    color = barColor.copy(alpha = if (index == data.lastIndex) 1f else 0.55f),
                    topLeft = Offset(centerX - barWidth / 2f, size.height - height),
                    size = Size(barWidth, height),
                    cornerRadius = CornerRadius(3.dp.toPx()),
                )
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            labels.forEachIndexed { index, label ->
                Text(
                    text = label,
                    style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                    color = if (index == labels.lastIndex) secondary else labelColor,
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center,
                )
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text =
                strings.getString(
                    R.string.y_axis_scales_to_the_7_day_range_unit,
                    strings.getString(metric.unitRes),
                ),
            style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
            color = labelColor,
            fontFamily = FontFamily.Monospace,
        )
    }
}

@Composable
private fun rememberAxisRange(
    samples: List<HealthMetricLog.Sample>,
    metric: HealthMetric,
): ClosedFloatingPointRange<Float> {
    return androidx.compose.runtime.remember(samples, metric) {
        val stats = HealthMetricLog.stats(samples)
        if (stats == null) {
            metric.validMin..(metric.validMin + metric.minimumSpan())
        } else {
            val needed = metric.minimumSpan()
            val span = (stats.max - stats.min).coerceAtLeast(needed)
            val center = (stats.min + stats.max) / 2f
            val half = span / 2f
            val low = (center - half).coerceAtLeast(metric.validMin)
            val high = (center + half).coerceAtMost(metric.validMax)
            if (high - low < needed) low..(low + needed).coerceAtMost(metric.validMax)
            else low..high
        }
    }
}

private fun HealthMetric.minimumSpan(): Float =
    when (this) {
        HealthMetric.SPO2 -> 6f
        HealthMetric.SKIN_TEMP -> 1.5f
        HealthMetric.RESPIRATORY -> 6f
        HealthMetric.HRV -> 30f
    }
