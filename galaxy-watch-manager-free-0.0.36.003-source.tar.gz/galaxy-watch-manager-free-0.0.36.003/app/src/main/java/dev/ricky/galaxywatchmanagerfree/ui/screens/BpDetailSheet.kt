package dev.ricky.galaxywatchmanagerfree.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.feature.WatchRepository
import dev.ricky.galaxywatchmanagerfree.feature.WatchState
import dev.ricky.galaxywatchmanagerfree.feature.monitor.BpRecord
import dev.ricky.galaxywatchmanagerfree.feature.monitor.HealthMonitorProtocol
import dev.ricky.galaxywatchmanagerfree.ui.components.BpCalibrationCard
import dev.ricky.galaxywatchmanagerfree.ui.components.GroupedCard
import dev.ricky.galaxywatchmanagerfree.ui.components.GroupedCardRow
import dev.ricky.galaxywatchmanagerfree.ui.components.GroupedDivider
import dev.ricky.galaxywatchmanagerfree.ui.components.MonitorRecordSheet
import dev.ricky.galaxywatchmanagerfree.ui.components.SectionHeader
import dev.ricky.galaxywatchmanagerfree.ui.components.formatMonitorRecordTime
import dev.ricky.galaxywatchmanagerfree.ui.theme.AlertCrimson
import dev.ricky.galaxywatchmanagerfree.ui.theme.EmeraldCharging
import dev.ricky.galaxywatchmanagerfree.ui.theme.HealthBloodPressure
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextPrimary
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextSecondary
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextTertiary
import dev.ricky.galaxywatchmanagerfree.ui.theme.WarningAmber

@Composable
fun BpDetailSheet(state: WatchState, repo: WatchRepository, onDismiss: () -> Unit) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources

    val records = state.bpRecords
    val latest = records.firstOrNull()
    val todayRecords =
        records.filter {
            dev.ricky.galaxywatchmanagerfree.feature.monitor.MonitorDay.contains(
                it.startTime,
                java.time.LocalDate.now(),
                java.time.ZoneId.systemDefault(),
            )
        }
    val visibleRecords = todayRecords.ifEmpty { listOfNotNull(latest) }
    val history = records.filter { row -> visibleRecords.none { it.id == row.id } }
    var selectedId by rememberSaveable { mutableStateOf<String?>(null) }
    val selected = records.firstOrNull { it.id == selectedId }
    val overviewScroll = rememberScrollState()

    fun triggerSync() =
        dev.ricky.galaxywatchmanagerfree.ui.components.requestMonitorSync(
            repo.monitor,
            HealthMonitorProtocol.Channel.BP,
            state.sessionReady,
        )

    MonitorRecordSheet(
        title =
            if (selected == null) strings.getString(R.string.blood_pressure_2)
            else strings.getString(R.string.blood_pressure_details),
        onDismiss = onDismiss,
        onBack = if (selected != null) ({ selectedId = null }) else null,
        onSync = { triggerSync() },
        canSync = state.sessionReady,
        syncDescription = strings.getString(R.string.sync_bp_records),
    ) {
        if (selected != null) {
            key(selected.id) {
                Column(
                    Modifier.weight(1f, fill = false)
                        .verticalScroll(rememberScrollState())
                        .padding(bottom = 32.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                ) {
                    BpResultCard(selected)
                }
            }
        } else {
            Column(
                Modifier.weight(1f, fill = false)
                    .verticalScroll(overviewScroll)
                    .padding(bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                if (latest != null) {
                    SectionHeader(
                        strings.getString(
                            if (todayRecords.isEmpty()) R.string.latest_measurement
                            else R.string.today_bp
                        )
                    )
                    visibleRecords.forEach { record -> key(record.id) { BpResultCard(record) } }
                    GroupedCard {
                        dev.ricky.galaxywatchmanagerfree.ui.components.BpSeriesChart(visibleRecords)
                    }
                } else {
                    GroupedCard(innerPadding = 18.dp) {
                        Icon(Icons.Default.Speed, null, tint = HealthBloodPressure)
                        Spacer(Modifier.height(12.dp))
                        Text(
                            strings.getString(R.string.no_bp_records),
                            style = androidx.compose.material3.MaterialTheme.typography.titleLarge,
                            color = TextPrimary,
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            strings.getString(R.string.bp_empty_guidance),
                            style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                        )
                    }
                }

                SectionHeader(
                    strings.getQuantityString(
                        R.plurals.monitor_history_count,
                        history.size,
                        history.size,
                    )
                )
                if (history.isNotEmpty()) {
                    GroupedCard(innerPadding = 0.dp) {
                        history.forEachIndexed { index, record ->
                            if (index > 0) GroupedDivider()
                            GroupedCardRow(
                                title = "${record.systolic} / ${record.diastolic} mmHg",
                                subtitle = formatMonitorRecordTime(record.startTime),
                                icon = Icons.Default.Speed,
                                iconTint = bpClassificationColor(record),
                                showChevron = true,
                                onClick = { selectedId = record.id },
                            )
                        }
                    }
                } else {
                    Text(
                        strings.getString(R.string.no_earlier_measurements),
                        style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                        color = TextTertiary,
                    )
                }

                SectionHeader(strings.getString(R.string.calibration_and_measurement))
                BpCalibrationCard(state, repo)
            }
        }
    }
}

@Composable
private fun BpResultCard(record: BpRecord) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources

    GroupedCard(innerPadding = 18.dp) {
        Text(
            strings.getString(R.string.blood_pressure_reading),
            style = androidx.compose.material3.MaterialTheme.typography.labelMedium,
            color = TextTertiary,
        )
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            BpPressureValue(
                strings.getString(R.string.systolic),
                record.systolic,
                Modifier.weight(1f),
            )
            BpPressureValue(
                strings.getString(R.string.diastolic),
                record.diastolic,
                Modifier.weight(1f),
            )
        }
        Spacer(Modifier.height(16.dp))
        Text(
            strings.getString(
                R.string.reading_category,
                strings.getString(record.classification.labelRes),
            ),
            style = androidx.compose.material3.MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
            color = bpClassificationColor(record),
        )
        Spacer(Modifier.height(6.dp))
        Text(
            if (record.heartRate > 0) strings.getString(R.string.pulse_bpm, record.heartRate)
            else strings.getString(R.string.no_pulse_data_received),
            style = androidx.compose.material3.MaterialTheme.typography.bodyMedium,
            color = TextSecondary,
        )
        Spacer(Modifier.height(6.dp))
        Text(
            formatMonitorRecordTime(record.startTime),
            style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
            color = TextSecondary,
        )
    }
}

@Composable
private fun BpPressureValue(label: String, value: Int, modifier: Modifier) {
    Column(modifier) {
        Text(
            label,
            style = androidx.compose.material3.MaterialTheme.typography.labelMedium,
            color = TextTertiary,
        )
        Text(
            value.toString(),
            style = androidx.compose.material3.MaterialTheme.typography.headlineLarge,
            fontWeight = FontWeight.Bold,
            color = TextPrimary,
        )
        Text(
            "mmHg",
            style = androidx.compose.material3.MaterialTheme.typography.labelMedium,
            color = TextSecondary,
        )
    }
}

@Composable
private fun bpClassificationColor(record: BpRecord): Color =
    when (record.classification) {
        BpRecord.Classification.NORMAL -> EmeraldCharging
        BpRecord.Classification.ELEVATED -> WarningAmber
        BpRecord.Classification.STAGE1,
        BpRecord.Classification.STAGE2 -> AlertCrimson
        BpRecord.Classification.LOW -> HealthBloodPressure
    }
