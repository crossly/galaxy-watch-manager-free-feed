package dev.ricky.galaxywatchmanagerfree.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextTertiary

/**
 * 屏幕网格按数值比例显示，不把 dp 当作设备实际毫米。
 *
 * 标准定标：
 * - 走纸速度 25 mm/s，电压增益 10 mm/mV
 * - 小格 1 mm (0.04 秒, 0.1 mV)，大格 5 mm (0.2 秒, 0.5 mV)
 * - 支持水平平滑手势滑动浏览完整 30 秒记录
 */
@Composable
fun EcgWaveformChart(
    waveform: FloatArray,
    modifier: Modifier = Modifier,
    sampleRate: Double = 500.0,
) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources

    if (waveform.isEmpty()) {
        Box(
            modifier =
                modifier
                    .fillMaxWidth()
                    .height(140.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(dev.ricky.galaxywatchmanagerfree.ui.theme.CardSurfaceElevated),
            contentAlignment = androidx.compose.ui.Alignment.Center,
        ) {
            Text(
                strings.getString(R.string.no_ecg_waveform_data),
                style = androidx.compose.material3.MaterialTheme.typography.labelMedium,
                color = TextTertiary,
            )
        }
        return
    }

    val scrollState = rememberScrollState()

    // 5 dp = 0.04 s, hence 125 dp/s. Sampling rate changes must not stretch the trace.
    val rate = sampleRate.takeIf { it.isFinite() && it > 0 } ?: return
    val dpPerSample = (125.0 / rate).toFloat()
    val chartWidthDp = (waveform.size * dpPerSample).coerceAtLeast(320f).dp
    val chartHeightDp = 160.dp
    val waveColor = dev.ricky.galaxywatchmanagerfree.ui.theme.HealthHeart
    val gridBg = dev.ricky.galaxywatchmanagerfree.ui.theme.CardSurfaceElevated
    val minorGrid = waveColor.copy(alpha = 0.12f)
    val majorGrid = waveColor.copy(alpha = 0.28f)

    Column(modifier = modifier.fillMaxWidth()) {
        Box(
            modifier =
                Modifier.fillMaxWidth()
                    .height(chartHeightDp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(gridBg)
                    .semantics {
                        contentDescription =
                            strings.getQuantityString(
                                R.plurals.ecg_waveform_description,
                                waveform.size,
                                waveform.size,
                                rate.toInt(),
                            )
                    }
                    .horizontalScroll(scrollState)
        ) {
            Canvas(
                modifier =
                    Modifier.width(chartWidthDp).height(chartHeightDp).drawWithCache {
                        val widthPx = size.width
                        val heightPx = size.height
                        val minorStep = 5.dp.toPx()
                        val midY = heightPx / 2f
                        val mvScale = 50.dp.toPx()

                        val path =
                            Path().apply {
                                for (i in waveform.indices) {
                                    val pointX = i * dpPerSample * density
                                    val pointY = midY - waveform[i] * mvScale
                                    if (i == 0) moveTo(pointX, pointY) else lineTo(pointX, pointY)
                                }
                            }

                        onDrawBehind {
                            drawRect(gridBg)

                            var x = 0f
                            var xCount = 0
                            while (x <= widthPx) {
                                val isMajor = (xCount % 5 == 0)
                                drawLine(
                                    color = if (isMajor) majorGrid else minorGrid,
                                    start = Offset(x, 0f),
                                    end = Offset(x, heightPx),
                                    strokeWidth = if (isMajor) 1.2f else 0.6f,
                                )
                                x += minorStep
                                xCount++
                            }

                            var y = 0f
                            var yCount = 0
                            while (y <= heightPx) {
                                val isMajor = (yCount % 5 == 0)
                                drawLine(
                                    color = if (isMajor) majorGrid else minorGrid,
                                    start = Offset(0f, y),
                                    end = Offset(widthPx, y),
                                    strokeWidth = if (isMajor) 1.2f else 0.6f,
                                )
                                y += minorStep
                                yCount++
                            }

                            drawPath(
                                path = path,
                                color = waveColor,
                                style = Stroke(width = 1.8.dp.toPx(), cap = StrokeCap.Round),
                            )
                        }
                    }
            ) {}
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = strings.getString(R.string.small_square_0_04_s_0_1_mv_large),
            style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
            color = TextTertiary,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(horizontal = 4.dp),
        )
    }
}
