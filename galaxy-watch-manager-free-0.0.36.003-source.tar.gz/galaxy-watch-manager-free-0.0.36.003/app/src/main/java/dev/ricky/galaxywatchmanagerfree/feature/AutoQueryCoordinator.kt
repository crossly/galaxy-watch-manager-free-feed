package dev.ricky.galaxywatchmanagerfree.feature

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * One periodic query loop per connected watch. Battery queries require a visible UI; health
 * synchronization continues in the background. Memory is deliberately absent from this interface.
 * Disabling periodic queries preserves the initial health read and explicit manual requests.
 */
class AutoQueryCoordinator(
    private val scope: CoroutineScope,
    private val queryBattery: () -> Unit,
    private val queryHealth: () -> Unit,
    initialPolicy: AutoQueryPolicy = AutoQueryPolicy(),
) {
    private var policy = validated(initialPolicy)
    private var connected = false
    private var visible = false
    private var initialRead: Job? = null
    private var polling: Job? = null
    private var generation = 0L

    @Synchronized
    fun start() {
        if (connected) return
        connected = true
        initialRead =
            scope.launch {
                delay(INITIAL_DELAY_MS)
                synchronized(this@AutoQueryCoordinator) { if (connected && isActive) queryHealth() }
            }
        restartPolling()
    }

    @Synchronized
    fun setVisible(value: Boolean) {
        visible = value
    }

    /** Changes restart the countdown, without repeating the initial read or interrupting a sync. */
    @Synchronized
    fun configure(value: AutoQueryPolicy) {
        val next = validated(value)
        if (next == policy) return
        policy = next
        restartPolling()
    }

    private fun restartPolling() {
        val currentGeneration = ++generation
        polling?.cancel()
        polling = null
        if (!connected || !policy.enabled) return
        val intervalMs = policy.intervalSeconds * 1_000L
        polling =
            scope.launch {
                while (isActive) {
                    delay(intervalMs)
                    synchronized(this@AutoQueryCoordinator) {
                        if (!isActive || !connected || generation != currentGeneration)
                            return@launch
                        if (visible) queryBattery()
                        queryHealth()
                    }
                }
            }
    }

    @Synchronized
    fun stop() {
        connected = false
        generation++
        initialRead?.cancel()
        initialRead = null
        polling?.cancel()
        polling = null
    }

    companion object {
        const val INITIAL_DELAY_MS = 3_000L

        private fun validated(policy: AutoQueryPolicy): AutoQueryPolicy =
            AutoQueryPolicy.fromPreferences(policy.enabled, policy.intervalSeconds)
    }
}
