package dev.ricky.galaxywatchmanagerfree.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import dev.ricky.galaxywatchmanagerfree.feature.WatchFacePreset
import dev.ricky.galaxywatchmanagerfree.feature.WatchFacePresets
import dev.ricky.galaxywatchmanagerfree.feature.WatchState
import dev.ricky.galaxywatchmanagerfree.ui.theme.ElectricBlue

enum class WatchModelKind {
    ULTRA,
    CLASSIC,
    STANDARD,
}

fun detectWatchModelKind(modelNumber: String, modelName: String): WatchModelKind {
    val upper = (modelNumber + " " + modelName).uppercase()
    return when {
        upper.contains("L700") || upper.contains("L705") || upper.contains("ULTRA") ->
            WatchModelKind.ULTRA
        upper.contains("R950") ||
            upper.contains("R955") ||
            upper.contains("R960") ||
            upper.contains("R965") ||
            upper.contains("R880") ||
            upper.contains("R885") ||
            upper.contains("R890") ||
            upper.contains("R895") ||
            upper.contains("CLASSIC") -> WatchModelKind.CLASSIC
        else -> WatchModelKind.STANDARD
    }
}

@Composable
fun WatchDeviceGraphic(state: WatchState, modifier: Modifier = Modifier) {
    WatchDeviceGraphic(
        modelName = state.modelName,
        modelNumber = state.modelNumber,
        active = state.startupSyncing || (state.connected && !state.sessionReady),
        modifier = modifier,
        preset = WatchFacePresets.find(state.activeWatchfacePkg, state.activeWatchfaceCls),
        previewPath = state.activeWatchfacePreviewPath,
    )
}

@Composable
fun WatchDeviceGraphic(
    modelName: String,
    modelNumber: String = "",
    active: Boolean = false,
    modifier: Modifier = Modifier,
    preset: WatchFacePreset? = null,
    previewPath: String? = null,
) {
    val kind = detectWatchModelKind(modelNumber, modelName)
    val shape = if (kind == WatchModelKind.ULTRA) RoundedCornerShape(15.dp) else CircleShape
    val screenSize = if (kind == WatchModelKind.STANDARD) 37.dp else 34.dp
    val rotation =
        if (active) {
            rememberInfiniteTransition(label = "WatchGraphicMotion")
                .animateFloat(
                    initialValue = 0f,
                    targetValue = 360f,
                    animationSpec = infiniteRepeatable(tween(4_000, easing = LinearEasing)),
                    label = "SyncRotation",
                )
                .value
        } else {
            0f
        }

    Box(modifier = modifier.size(52.dp), contentAlignment = Alignment.Center) {
        Box(
            Modifier.size(48.dp)
                .clip(shape)
                .background(
                    Brush.linearGradient(
                        listOf(Color(0xFF3E434B), Color(0xFF23262A), Color(0xFF141618))
                    )
                )
                .border(1.dp, Color(0xFF555B66), shape)
        )
        if (kind == WatchModelKind.CLASSIC) {
            Canvas(Modifier.size(48.dp)) {
                val center = Offset(size.width / 2, size.height / 2)
                val outerRadius = size.minDimension / 2 - 1.dp.toPx()
                val innerRadius = outerRadius - 2.dp.toPx()
                repeat(24) { index ->
                    val angle = Math.toRadians(index * 15.0)
                    val direction =
                        Offset(kotlin.math.cos(angle).toFloat(), kotlin.math.sin(angle).toFloat())
                    drawLine(
                        Color(0xFF6B7280),
                        center + direction * innerRadius,
                        center + direction * outerRadius,
                        strokeWidth = 0.7.dp.toPx(),
                    )
                }
            }
        }
        if (kind == WatchModelKind.ULTRA) {
            Box(
                Modifier.align(Alignment.CenterEnd)
                    .offset(x = 1.dp)
                    .size(width = 3.dp, height = 10.dp)
                    .clip(RoundedCornerShape(1.5.dp))
                    .background(Color(0xFFFF5722))
            )
        } else if (kind == WatchModelKind.STANDARD) {
            for (y in listOf((-8).dp, 8.dp)) {
                Box(
                    Modifier.align(Alignment.CenterEnd)
                        .offset(x = 1.dp, y = y)
                        .size(width = 2.5.dp, height = 7.dp)
                        .clip(RoundedCornerShape(1.dp))
                        .background(Color(0xFF5A616E))
                )
            }
        }
        WatchFacePreview(preset = preset, size = screenSize, previewPath = previewPath)
        if (active) {
            val syncColor = ElectricBlue
            Canvas(Modifier.size(screenSize)) {
                val inset = 1.dp.toPx()
                drawArc(
                    color = syncColor,
                    startAngle = rotation,
                    sweepAngle = 90f,
                    useCenter = false,
                    topLeft = Offset(inset, inset),
                    size =
                        androidx.compose.ui.geometry.Size(
                            size.width - 2 * inset,
                            size.height - 2 * inset,
                        ),
                    style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round),
                )
            }
        }
    }
}
