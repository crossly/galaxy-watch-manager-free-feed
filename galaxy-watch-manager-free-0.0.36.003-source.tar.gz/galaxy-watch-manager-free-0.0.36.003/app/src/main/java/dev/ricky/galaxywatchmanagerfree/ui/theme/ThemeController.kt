package dev.ricky.galaxywatchmanagerfree.ui.theme

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Persisted appearance mode, accent color, navigation style and glass material. */
object ThemeController {

    const val MODE_SYSTEM = 0
    const val MODE_LIGHT = 1
    const val MODE_DARK = 2

    private const val PREFS = "watchfree_theme"
    private const val KEY_MODE = "appearance_mode"
    private const val KEY_NAVIGATION_STYLE = "navigation_style"
    private const val KEY_GLASS_EFFECT = "glass_effect"

    private var prefs: android.content.SharedPreferences? = null

    const val COLOR_SYSTEM = 0
    const val COLOR_BLUE = 1
    const val COLOR_VIOLET = 2
    const val COLOR_MINT = 3

    const val NAVIGATION_FLOATING = 0
    const val NAVIGATION_FIXED = 1

    private val _navigationStyle = MutableStateFlow(NAVIGATION_FLOATING)
    val navigationStyle: StateFlow<Int> = _navigationStyle

    private val _glassEffect = MutableStateFlow(false)
    val glassEffect: StateFlow<Boolean> = _glassEffect

    private val _color = MutableStateFlow(COLOR_SYSTEM)
    val color: StateFlow<Int> = _color

    private val _mode = MutableStateFlow(MODE_SYSTEM)
    val mode: StateFlow<Int> = _mode

    fun init(context: Context) {
        if (prefs == null) {
            prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            _mode.value = prefs?.getInt(KEY_MODE, MODE_SYSTEM) ?: MODE_SYSTEM
            _color.value = prefs?.getInt("accent_color", COLOR_SYSTEM) ?: COLOR_SYSTEM
            _navigationStyle.value =
                if (prefs?.getInt(KEY_NAVIGATION_STYLE, NAVIGATION_FLOATING) == NAVIGATION_FIXED)
                    NAVIGATION_FIXED
                else NAVIGATION_FLOATING
            _glassEffect.value = prefs?.getBoolean(KEY_GLASS_EFFECT, false) ?: false
        }
    }

    fun setMode(context: Context, mode: Int) {
        init(context)
        prefs?.edit()?.putInt(KEY_MODE, mode)?.apply()
        _mode.value = mode
    }

    fun setColor(context: Context, color: Int) {
        init(context)
        val selected = color.coerceIn(COLOR_SYSTEM, COLOR_MINT)
        prefs?.edit()?.putInt("accent_color", selected)?.apply()
        _color.value = selected
    }

    fun setNavigationStyle(context: Context, style: Int) {
        init(context)
        val selected = if (style == NAVIGATION_FIXED) NAVIGATION_FIXED else NAVIGATION_FLOATING
        prefs?.edit()?.putInt(KEY_NAVIGATION_STYLE, selected)?.apply()
        _navigationStyle.value = selected
    }

    fun setGlassEffect(context: Context, enabled: Boolean) {
        init(context)
        prefs?.edit()?.putBoolean(KEY_GLASS_EFFECT, enabled)?.apply()
        _glassEffect.value = enabled
    }
}
