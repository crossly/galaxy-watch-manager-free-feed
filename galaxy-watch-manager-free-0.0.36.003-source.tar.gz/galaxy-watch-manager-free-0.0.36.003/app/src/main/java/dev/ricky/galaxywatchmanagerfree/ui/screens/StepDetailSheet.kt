package dev.ricky.galaxywatchmanagerfree.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.feature.HealthTimeline
import dev.ricky.galaxywatchmanagerfree.feature.WatchState
import dev.ricky.galaxywatchmanagerfree.ui.components.AppBottomSheet
import dev.ricky.galaxywatchmanagerfree.ui.components.GroupedCard
import dev.ricky.galaxywatchmanagerfree.ui.components.GroupedDivider
import dev.ricky.galaxywatchmanagerfree.ui.components.SegmentedTabs
import dev.ricky.galaxywatchmanagerfree.ui.components.WeekStepBars
import dev.ricky.galaxywatchmanagerfree.ui.components.pressFeedback
import dev.ricky.galaxywatchmanagerfree.ui.theme.CardBorder
import dev.ricky.galaxywatchmanagerfree.ui.theme.CardSurfaceElevated
import dev.ricky.galaxywatchmanagerfree.ui.theme.EmeraldCharging
import dev.ricky.galaxywatchmanagerfree.ui.theme.HealthSteps
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextDisabled
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextPrimary
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextSecondary
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextTertiary
import java.time.LocalDate

enum class StepViewTab(val titleRes: Int) {
    TODAY(R.string.today_s_activity),
    WEEK(R.string.past_7_days_2),
    HISTORY(R.string.history_2),
}

/** 步数与日常活动全功能详情面板 包含：今日 24 小时活动交互分布、近 7 天趋势比对、历史每日清单与连续达标。 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StepDetailSheet(state: WatchState, onDismiss: () -> Unit, onAdjustGoal: () -> Unit) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var selectedTab by remember { mutableStateOf(StepViewTab.TODAY) }
    var selectedHour by remember { mutableIntStateOf(-1) }

    val steps = state.todaySteps
    val goal = state.stepGoal
    val percent = if (goal > 0) ((steps * 100f) / goal).toInt() else 0
    val reached = goal > 0 && steps >= goal

    AppBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        LazyColumn(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item {
                dev.ricky.galaxywatchmanagerfree.ui.components.SheetToolbar(
                    strings.getString(R.string.steps_and_activity),
                    onDismiss,
                )
            }

            // 今日核心数据汇总卡片
            item {
                GroupedCard(innerPadding = 16.dp) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom,
                    ) {
                        Column {
                            Text(
                                strings.getString(R.string.today_s_total),
                                style =
                                    androidx.compose.material3.MaterialTheme.typography.labelMedium,
                                color = TextTertiary,
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Row(verticalAlignment = Alignment.Bottom) {
                                Text(
                                    text = if (steps >= 0) "%,d".format(steps) else "—",
                                    style =
                                        androidx.compose.material3.MaterialTheme.typography
                                            .headlineLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = if (reached) EmeraldCharging else TextPrimary,
                                    fontFamily = FontFamily.Monospace,
                                )
                                Text(
                                    text = strings.getString(R.string.steps_2),
                                    style =
                                        androidx.compose.material3.MaterialTheme.typography
                                            .bodySmall,
                                    color = TextSecondary,
                                    modifier = Modifier.padding(bottom = 6.dp),
                                )
                            }
                        }

                        Box(
                            modifier =
                                Modifier.clip(RoundedCornerShape(999.dp))
                                    .background(
                                        if (reached) EmeraldCharging.copy(alpha = 0.16f)
                                        else HealthSteps.copy(alpha = 0.12f)
                                    )
                                    .padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Text(
                                text =
                                    if (steps < 0) strings.getString(R.string.not_synced)
                                    else if (reached)
                                        strings.getString(R.string.goal_reached, percent)
                                    else strings.getString(R.string.goal, percent),
                                style =
                                    androidx.compose.material3.MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = if (reached) EmeraldCharging else HealthSteps,
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    HorizontalDivider(color = CardBorder.copy(alpha = 0.6f), thickness = 0.5.dp)
                    Spacer(modifier = Modifier.height(12.dp))

                    // 次要指标 3 列
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround,
                    ) {
                        SubMetric(
                            label = strings.getString(R.string.walking_distance),
                            modifier = Modifier.weight(1f),
                            value =
                                if (state.todayDistanceMeters >= 0)
                                    "%.2f".format(state.todayDistanceMeters / 1000f)
                                else "—",
                            unit = "km",
                        )
                        SubMetric(
                            label = strings.getString(R.string.active_energy),
                            modifier = Modifier.weight(1f),
                            value =
                                if (state.todayCalories >= 0) "%.0f".format(state.todayCalories)
                                else "—",
                            unit = "kcal",
                        )
                        SubMetric(
                            label = strings.getString(R.string.floors_climbed),
                            modifier = Modifier.weight(1f),
                            value = if (state.todayFloors >= 0) "${state.todayFloors}" else "—",
                            unit = strings.getString(R.string.floors_2),
                        )
                    }
                }
            }

            // 分段控制器：今日活动 | 近 7 天 | 历史记录
            item {
                SegmentedTabs(
                    items = StepViewTab.entries,
                    selectedItem = selectedTab,
                    onItemSelected = {
                        selectedTab = it
                        selectedHour = -1
                    },
                    labelOf = { strings.getString(it.titleRes) },
                )
            }

            // 分页内容渲染
            when (selectedTab) {
                StepViewTab.TODAY -> {
                    item {
                        TodayActivitySection(
                            hours = state.todayHours,
                            selectedHour = selectedHour,
                            onSelectHour = { selectedHour = if (selectedHour == it) -1 else it },
                        )
                    }
                }
                StepViewTab.WEEK -> {
                    item { WeekTrendSection(weekSteps = state.weekSteps, goal = state.stepGoal) }
                }
                StepViewTab.HISTORY -> {
                    item {
                        MilestoneStreakSection(streakDays = state.streakDays, todaySteps = steps)
                    }
                    val historyList = state.dailyHistory.entries.sortedByDescending { it.key }
                    if (historyList.isEmpty()) {
                        item {
                            GroupedCard {
                                Box(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 24.dp),
                                    contentAlignment = Alignment.Center,
                                ) {
                                    Text(
                                        text = strings.getString(R.string.activity_history_empty),
                                        style =
                                            androidx.compose.material3.MaterialTheme.typography
                                                .labelMedium,
                                        color = TextTertiary,
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                    )
                                }
                            }
                        }
                    } else {
                        items(historyList, key = { it.key }) { (dayKey, day) ->
                            HistoryDayRow(dayKey = dayKey, day = day, goal = state.stepGoal)
                        }
                    }
                }
            }

            // 底部调整目标按钮
            item {
                Box(
                    modifier =
                        Modifier.fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(CardSurfaceElevated)
                            .border(1.dp, CardBorder, RoundedCornerShape(14.dp))
                            .pressFeedback(onClick = onAdjustGoal)
                            .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = null,
                            tint = HealthSteps,
                            modifier = Modifier.size(16.dp),
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text =
                                strings
                                    .getString(R.string.daily_step_goal_current_steps)
                                    .format(goal),
                            style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold,
                            color = HealthSteps,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SubMetric(label: String, value: String, unit: String, modifier: Modifier = Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            label,
            style = androidx.compose.material3.MaterialTheme.typography.labelMedium,
            color = TextTertiary,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )
        Spacer(modifier = Modifier.height(2.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                text = value,
                style = androidx.compose.material3.MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                fontFamily = FontFamily.Monospace,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            )
            if (value != "—") {
                Text(
                    text = " $unit",
                    style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                    color = TextSecondary,
                    modifier = Modifier.padding(bottom = 2.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                )
            }
        }
    }
}

@Composable
private fun TodayActivitySection(hours: List<Int>, selectedHour: Int, onSelectHour: (Int) -> Unit) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources

    val max = hours.maxOrNull()?.coerceAtLeast(100) ?: 100
    val peakIndex = hours.indices.maxByOrNull { hours[it] } ?: -1
    val peakSteps = if (peakIndex >= 0) hours[peakIndex] else 0
    val activeHours = hours.count { it > 0 }

    GroupedCard(innerPadding = 16.dp) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                strings.getString(R.string.label_24_hour_activity),
                style = androidx.compose.material3.MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
            )
            if (selectedHour in 0..23) {
                Box(
                    modifier =
                        Modifier.clip(RoundedCornerShape(6.dp))
                            .background(HealthSteps.copy(alpha = 0.14f))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text =
                            strings.getQuantityString(
                                R.plurals.activity_hour_steps,
                                hours[selectedHour],
                                selectedHour,
                                selectedHour + 1,
                                hours[selectedHour],
                            ),
                        style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = HealthSteps,
                        fontFamily = FontFamily.Monospace,
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // 交互柱状图
        Row(
            modifier = Modifier.fillMaxWidth().height(120.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Bottom,
        ) {
            hours.forEachIndexed { i, steps ->
                val fraction = (steps.toFloat() / max).coerceIn(0.04f, 1f)
                val isSelected = i == selectedHour
                val isPeak = i == peakIndex && peakSteps > 0
                val barColor =
                    when {
                        isSelected -> HealthSteps
                        isPeak -> EmeraldCharging
                        steps > 0 -> HealthSteps.copy(alpha = 0.5f)
                        else -> CardSurfaceElevated
                    }

                Column(
                    modifier =
                        Modifier.weight(1f)
                            .padding(horizontal = 1.dp)
                            .pressFeedback(onClick = { onSelectHour(i) }),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Bottom,
                ) {
                    Box(
                        modifier =
                            Modifier.fillMaxWidth()
                                .height((100 * fraction).dp)
                                .clip(RoundedCornerShape(topStart = 3.dp, topEnd = 3.dp))
                                .background(barColor)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (i % 6 == 0) "$i" else "",
                        style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                        color = TextTertiary,
                        fontFamily = FontFamily.Monospace,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))
        GroupedDivider(startIndent = 0.dp)
        Spacer(modifier = Modifier.height(10.dp))

        // 最活跃时段说明
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Default.LocalFireDepartment,
                contentDescription = null,
                tint = EmeraldCharging,
                modifier = Modifier.size(15.dp),
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text =
                    if (peakSteps > 0) {
                        strings.getQuantityString(
                            R.plurals.activity_peak_summary,
                            activeHours,
                            peakIndex,
                            peakIndex + 1,
                            peakSteps,
                            activeHours,
                        )
                    } else {
                        strings.getString(R.string.no_active_period_recorded_today)
                    },
                style = androidx.compose.material3.MaterialTheme.typography.labelMedium,
                color = TextSecondary,
            )
        }
    }
}

@Composable
private fun WeekTrendSection(weekSteps: List<Int>, goal: Int) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources

    val total = weekSteps.sum()
    val avg = if (weekSteps.isNotEmpty()) total / weekSteps.size else 0
    val reachedDays = weekSteps.count { it >= goal }

    GroupedCard(innerPadding = 16.dp) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                strings.getString(R.string.steps_over_7_days),
                style = androidx.compose.material3.MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
            )
            Box(
                modifier =
                    Modifier.clip(RoundedCornerShape(6.dp))
                        .background(EmeraldCharging.copy(alpha = 0.12f))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text(
                    text = strings.getString(R.string.goal_reached_on_7_days, reachedDays),
                    style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = EmeraldCharging,
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // 7天柱状图
        WeekStepBars(steps = weekSteps, goal = goal)

        Spacer(modifier = Modifier.height(14.dp))
        GroupedDivider(startIndent = 0.dp)
        Spacer(modifier = Modifier.height(12.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    strings.getString(R.string.label_7_day_step_total),
                    style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                    color = TextTertiary,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = strings.getQuantityString(R.plurals.step_count, total, total),
                    style = androidx.compose.material3.MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    fontFamily = FontFamily.Monospace,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                )
            }
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    strings.getString(R.string.daily_average_steps),
                    style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                    color = TextTertiary,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = strings.getQuantityString(R.plurals.step_count, avg, avg),
                    style = androidx.compose.material3.MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = if (avg >= goal) EmeraldCharging else TextPrimary,
                    fontFamily = FontFamily.Monospace,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                )
            }
        }
    }
}

@Composable
private fun MilestoneStreakSection(streakDays: Int, todaySteps: Int) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources

    GroupedCard(innerPadding = 16.dp) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.EmojiEvents,
                    contentDescription = null,
                    tint = EmeraldCharging,
                    modifier = Modifier.size(18.dp),
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    strings.getString(R.string.goals_and_milestones),
                    style = androidx.compose.material3.MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                )
            }
            if (streakDays > 0) {
                Text(
                    text = strings.getString(R.string.day_goal_streak, streakDays),
                    style = androidx.compose.material3.MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = EmeraldCharging,
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 4 档里程碑徽章
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            HealthTimeline.MILESTONES.forEach { target ->
                val reached = todaySteps >= target
                Box(
                    modifier =
                        Modifier.weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                if (reached) EmeraldCharging.copy(alpha = 0.16f)
                                else CardSurfaceElevated
                            )
                            .border(
                                1.dp,
                                if (reached) EmeraldCharging.copy(alpha = 0.5f) else CardBorder,
                                RoundedCornerShape(10.dp),
                            )
                            .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "${target / 1000}K",
                            style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = if (reached) EmeraldCharging else TextTertiary,
                            fontFamily = FontFamily.Monospace,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        )
                        Text(
                            text =
                                if (reached) strings.getString(R.string.reached)
                                else strings.getString(R.string.not_reached),
                            style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                            color = if (reached) EmeraldCharging else TextDisabled,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HistoryDayRow(dayKey: String, day: HealthTimeline.Day, goal: Int) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources

    val reached = goal > 0 && day.steps >= goal
    GroupedCard(cornerRadius = 16.dp, innerPadding = 12.dp) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column {
                Text(
                    text = formatDayLabel(dayKey, strings),
                    style = androidx.compose.material3.MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimary,
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "%.2f km · %d kcal".format(day.distanceMeters / 1000f, day.calories),
                    style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                    color = TextTertiary,
                    fontFamily = FontFamily.Monospace,
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "%,d".format(day.steps),
                    style = androidx.compose.material3.MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Bold,
                    color = if (reached) EmeraldCharging else TextPrimary,
                    fontFamily = FontFamily.Monospace,
                )
                Text(
                    text = strings.getString(R.string.steps_2),
                    style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                    color = TextSecondary,
                    modifier = Modifier.padding(start = 2.dp, end = 8.dp),
                )
                if (reached) {
                    Box(
                        modifier =
                            Modifier.size(18.dp)
                                .clip(CircleShape)
                                .background(EmeraldCharging.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            tint = EmeraldCharging,
                            modifier = Modifier.size(12.dp),
                        )
                    }
                }
            }
        }
    }
}

private fun formatDayLabel(dayKey: String, strings: android.content.res.Resources): String =
    runCatching {
            val date = LocalDate.parse(dayKey)
            val today = LocalDate.now()
            when {
                date == today -> strings.getString(R.string.today, date.monthValue, date.dayOfMonth)
                date == today.minusDays(1) ->
                    strings.getString(R.string.yesterday, date.monthValue, date.dayOfMonth)
                else ->
                    strings.getString(
                        R.string.date_month_day_weekday,
                        date.monthValue,
                        date.dayOfMonth,
                        date.dayOfWeek.getDisplayName(
                            java.time.format.TextStyle.SHORT,
                            strings.configuration.locales[0],
                        ),
                    )
            }
        }
        .getOrDefault(dayKey)
