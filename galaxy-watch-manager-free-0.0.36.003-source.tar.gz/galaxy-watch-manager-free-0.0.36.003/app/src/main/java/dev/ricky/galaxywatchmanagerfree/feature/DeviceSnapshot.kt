package dev.ricky.galaxywatchmanagerfree.feature

import org.json.JSONObject

/** Last confirmed device identity and watch face. Connection / charging state is never restored. */
object DeviceSnapshot {
    fun encode(state: WatchState): String =
        JSONObject()
            .apply {
                put("deviceName", state.deviceName)
                put("watchAlias", state.watchAlias)
                put("modelNumber", state.modelNumber)
                put("modelName", state.modelName)
                put("firmware", state.firmware)
                put("androidVersion", state.androidVersion)
                put("wearOs", state.wearOs)
                put("batteryCapacityMah", state.batteryCapacityMah)
                put("esimSupported", state.esimSupported)
                put("eid", state.eid)
                put("imei", state.imei)
                put("activeWatchfacePkg", state.activeWatchfacePkg)
                put("activeWatchfaceCls", state.activeWatchfaceCls)
                put("activeWatchfaceFavoriteId", state.activeWatchfaceFavoriteId)
                put("activeWatchfacePreviewPath", state.activeWatchfacePreviewPath)
                put("watchfaceOrderType", state.watchfaceOrderType)
                put("watchfaceFavoriteIds", org.json.JSONArray(state.watchfaceFavoriteIds))
                put("watchfaceUpdatedAt", state.watchfaceUpdatedAt)
            }
            .toString()

    fun restore(encoded: String?, state: WatchState): WatchState {
        val json = encoded?.let { runCatching { JSONObject(it) }.getOrNull() } ?: return state
        fun value(key: String) = json.optString(key).takeIf { it.isNotBlank() && it != "null" }
        return state.copy(
            deviceName = value("deviceName") ?: state.deviceName,
            watchAlias = value("watchAlias") ?: state.watchAlias,
            modelNumber = value("modelNumber") ?: state.modelNumber,
            modelName = value("modelName") ?: state.modelName,
            firmware = value("firmware") ?: state.firmware,
            androidVersion = value("androidVersion") ?: state.androidVersion,
            wearOs = value("wearOs") ?: state.wearOs,
            batteryCapacityMah = value("batteryCapacityMah") ?: state.batteryCapacityMah,
            esimSupported = json.optBoolean("esimSupported", state.esimSupported),
            eid = value("eid") ?: state.eid,
            imei = value("imei") ?: state.imei,
            activeWatchfacePkg = value("activeWatchfacePkg"),
            activeWatchfaceCls = value("activeWatchfaceCls"),
            activeWatchfaceFavoriteId = json.optInt("activeWatchfaceFavoriteId", -1),
            activeWatchfacePreviewPath = value("activeWatchfacePreviewPath"),
            watchfaceOrderType = value("watchfaceOrderType"),
            watchfaceFavoriteIds =
                json
                    .optJSONArray("watchfaceFavoriteIds")
                    ?.let { a -> (0 until a.length()).map { a.optInt(it) } }
                    .orEmpty(),
            watchfaceUpdatedAt = json.optLong("watchfaceUpdatedAt", 0),
        )
    }

    /** A set-command ack contains no identity. It must not erase an already known face. */
    fun applyWatchface(state: WatchState, json: JSONObject, now: Long): WatchState {
        if (json.optInt("result", 0) != 0) return state
        val data = json.optJSONObject("data") ?: return state
        val pkg =
            data.optString("packageName").takeIf { it.isNotBlank() && it != "null" } ?: return state
        val cls =
            data.optString("className").takeIf { it.isNotBlank() && it != "null" }
                ?: state.activeWatchfaceCls.takeIf { state.activeWatchfacePkg == pkg }
        val sameFace = pkg == state.activeWatchfacePkg && cls == state.activeWatchfaceCls
        val favoriteId =
            data.optInt("favoriteId", if (sameFace) state.activeWatchfaceFavoriteId else -1)
        return state.copy(
            activeWatchfacePkg = pkg,
            activeWatchfaceCls = cls,
            activeWatchfaceFavoriteId = favoriteId,
            activeWatchfacePreviewPath =
                state.activeWatchfacePreviewPath.takeIf {
                    sameFace && favoriteId == state.activeWatchfaceFavoriteId
                },
            watchfaceUpdatedAt = now,
            lastSyncAt = now,
        )
    }
}
