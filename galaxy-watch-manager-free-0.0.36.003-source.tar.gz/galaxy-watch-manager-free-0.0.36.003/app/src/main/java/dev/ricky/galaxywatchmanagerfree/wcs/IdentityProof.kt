package dev.ricky.galaxywatchmanagerfree.wcs

import org.json.JSONObject

/** Checks raw live responses; cached projections and empty acknowledgements are never proof. */
internal object IdentityProof {
    fun matchesPeer(
        watch: String,
        phone: String,
        source: String?,
        destination: String?,
        pathNode: String?,
    ): Boolean =
        watch.isNotBlank() &&
            phone.isNotBlank() &&
            destination == phone &&
            (source.isNullOrBlank() || source == watch) &&
            (pathNode == null || pathNode == watch)

    fun accepts(path: String, payload: String): Boolean {
        val json = runCatching { JSONObject(payload) }.getOrNull() ?: return false
        if (json.has("result") && json.opt("result") != 0 && json.opt("result") != 0L) return false
        val data = json.optJSONObject("data") ?: return false
        return when {
            path == WcsPaths.INTERNAL_FEATURE &&
                json.optString("msgId") == WcsPaths.MSG_FEATURE_EXCHANGE -> {
                val model = data.opt("modelNumber") as? String ?: ""
                val name = data.opt("modelName") as? String ?: ""
                model.startsWith("SM-R") ||
                    model.startsWith("SM-L") ||
                    name.contains("watch", ignoreCase = true)
            }
            path == WcsPaths.WATCHFACE_SYSUI &&
                json.optString("msgId") == WcsPaths.MSG_CHANGE_ACTIVE_WATCHFACE -> {
                val pkg = data.opt("packageName") as? String ?: ""
                val cls = data.opt("className") as? String ?: ""
                pkg.contains('.') && cls.isNotBlank() && cls != "null"
            }
            else -> false
        }
    }
}
