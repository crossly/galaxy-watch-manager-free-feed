package dev.ricky.galaxywatchmanagerfree.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DragIndicator
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.UnfoldMore
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.feature.BlockPlacement
import dev.ricky.galaxywatchmanagerfree.feature.LayoutPage
import dev.ricky.galaxywatchmanagerfree.feature.PageBlock
import dev.ricky.galaxywatchmanagerfree.ui.PageLayoutController
import dev.ricky.galaxywatchmanagerfree.ui.theme.*
import kotlin.math.abs

/**
 * In-place card editing. Gesture coordinates live on the grid, so reordering cannot reset a drag.
 */
@Composable
fun EditableBlockGrid(
    page: LayoutPage,
    editing: Boolean,
    modifier: Modifier = Modifier,
    unavailableBlocks: Set<PageBlock> = emptySet(),
    content: @Composable (BlockPlacement) -> Unit,
) {
    val layouts by PageLayoutController.layouts.collectAsState()
    val placements = layouts.getValue(page).filter { it.block !in unavailableBlocks }
    val shown = placements.filter { it.visible }
    val hidden = placements.filterNot { it.visible }
    val state = rememberLazyGridState()
    val density = androidx.compose.ui.platform.LocalDensity.current
    val edge = with(density) { 72.dp.toPx() }
    val maxSpeed = with(density) { 700.dp.toPx() }
    var dragged by remember { mutableStateOf<PageBlock?>(null) }
    var pointer by remember { mutableStateOf(Offset.Zero) }
    var grip by remember { mutableStateOf(Offset.Zero) }
    val currentPlacements by rememberUpdatedState(placements)

    fun itemAt(point: Offset) =
        state.layoutInfo.visibleItemsInfo.firstOrNull {
            point.x >= it.offset.x &&
                point.x < it.offset.x + it.size.width &&
                point.y >= it.offset.y &&
                point.y < it.offset.y + it.size.height &&
                currentPlacements.any { placement ->
                    placement.visible && placement.block.name == it.key
                }
        }
    fun reorderAtPointer() {
        val source = dragged ?: return
        val target = itemAt(pointer)?.key as? String ?: return
        if (source.name != target) {
            val block = currentPlacements.firstOrNull { it.block.name == target }?.block ?: return
            PageLayoutController.reorder(page, source, block)
        }
    }
    LaunchedEffect(editing, unavailableBlocks) {
        if (!editing || dragged?.let(unavailableBlocks::contains) == true) dragged = null
    }
    LaunchedEffect(dragged) {
        if (dragged == null) return@LaunchedEffect
        var previous = withFrameNanos { it }
        while (dragged != null) {
            val now = withFrameNanos { it }
            val info = state.layoutInfo
            val speed =
                when {
                    pointer.y < info.viewportStartOffset + edge ->
                        -maxSpeed *
                            ((info.viewportStartOffset + edge - pointer.y) / edge).coerceIn(0f, 1f)
                    pointer.y > info.viewportEndOffset - edge ->
                        maxSpeed *
                            ((pointer.y - info.viewportEndOffset + edge) / edge).coerceIn(0f, 1f)
                    else -> 0f
                }
            if (abs(speed) > 1f) {
                state.scrollBy(speed * ((now - previous) / 1_000_000_000f).coerceAtMost(.05f))
                reorderAtPointer()
            }
            previous = now
        }
    }
    BoxWithConstraints(modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        val width = maxWidth.coerceAtMost(840.dp)
        val columns = if ((width - 44.dp) / 2 / density.fontScale >= 148.dp) 2 else 1
        LazyVerticalGrid(
            columns = GridCells.Fixed(columns),
            state = state,
            userScrollEnabled = dragged == null,
            modifier =
                Modifier.widthIn(max = 840.dp).fillMaxSize().testTag("block_grid").pointerInput(
                    editing,
                    page,
                    columns,
                ) {
                    if (!editing) return@pointerInput
                    detectDragGesturesAfterLongPress(
                        onDragStart = { position ->
                            itemAt(position)?.let { item ->
                                dragged =
                                    currentPlacements
                                        .firstOrNull { it.block.name == item.key }
                                        ?.block
                                pointer = position
                                grip =
                                    position -
                                        Offset(item.offset.x.toFloat(), item.offset.y.toFloat())
                            }
                        },
                        onDragCancel = { dragged = null },
                        onDragEnd = { dragged = null },
                        onDrag = { change, delta ->
                            if (dragged != null) {
                                change.consume()
                                pointer += delta
                                reorderAtPointer()
                            }
                        },
                    )
                },
            contentPadding =
                PaddingValues(
                    start = 16.dp,
                    end = 16.dp,
                    top = 8.dp,
                    bottom = LocalRootPageBottomPadding.current,
                ),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            items(
                shown,
                key = { it.block.name },
                span = { GridItemSpan(if (it.wide) maxLineSpan else 1) },
            ) { placement ->
                val active = dragged == placement.block
                val label = stringResource(placement.block.labelRes)
                val removeLabel = stringResource(R.string.remove_block, label)
                val wideLabel =
                    stringResource(
                        if (placement.wide) R.string.layout_half_width
                        else R.string.layout_full_width
                    )
                val upLabel = stringResource(R.string.move_up)
                val downLabel = stringResource(R.string.move_down)
                val dragLabel = stringResource(R.string.drag_block, label)
                Box(
                    Modifier.fillMaxWidth()
                        .testTag("block_${placement.block.name}")
                        .zIndex(if (active) 1f else 0f)
                        .then(if (active) Modifier else Modifier.animateItem())
                        .graphicsLayer {
                            if (active) {
                                val item =
                                    state.layoutInfo.visibleItemsInfo.firstOrNull {
                                        it.key == placement.block.name
                                    }
                                if (item != null) {
                                    translationX = pointer.x - grip.x - item.offset.x
                                    translationY = pointer.y - grip.y - item.offset.y
                                }
                                scaleX = 1.025f
                                scaleY = 1.025f
                                shadowElevation = 8.dp.toPx()
                            }
                        }
                ) {
                    // A shield above the real content absorbs taps; long presses are handled by the
                    // grid.
                    Box(if (editing) Modifier.clearAndSetSemantics {} else Modifier) {
                        content(placement.copy(wide = placement.wide || columns == 1))
                    }
                    if (editing) {
                        Box(
                            Modifier.matchParentSize()
                                .clearAndSetSemantics {
                                    contentDescription = dragLabel
                                    customActions =
                                        listOf(
                                            CustomAccessibilityAction(upLabel) {
                                                PageLayoutController.change(
                                                    page,
                                                    placement.block,
                                                    move = -1,
                                                )
                                                true
                                            },
                                            CustomAccessibilityAction(downLabel) {
                                                PageLayoutController.change(
                                                    page,
                                                    placement.block,
                                                    move = 1,
                                                )
                                                true
                                            },
                                        )
                                }
                                .pressFeedback(onClick = {})
                        )
                        Row(
                            Modifier.align(Alignment.TopEnd).padding(4.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                        ) {
                            if (placement.block.compact) {
                                FilledIconButton(
                                    onClick = {
                                        PageLayoutController.change(
                                            page,
                                            placement.block,
                                            wide = !placement.wide,
                                        )
                                    },
                                    modifier = Modifier.size(36.dp),
                                ) {
                                    Icon(Icons.Default.UnfoldMore, wideLabel, Modifier.size(20.dp))
                                }
                            }
                            FilledIconButton(
                                onClick = {
                                    if (active) dragged = null
                                    PageLayoutController.change(
                                        page,
                                        placement.block,
                                        visible = false,
                                    )
                                },
                                modifier = Modifier.size(36.dp),
                                colors =
                                    IconButtonDefaults.filledIconButtonColors(
                                        containerColor = MaterialTheme.colorScheme.errorContainer,
                                        contentColor = MaterialTheme.colorScheme.onErrorContainer,
                                    ),
                            ) {
                                Icon(Icons.Default.Remove, removeLabel, Modifier.size(20.dp))
                            }
                        }
                        Icon(
                            Icons.Default.DragIndicator,
                            null,
                            tint = TextSecondary,
                            modifier =
                                Modifier.align(Alignment.TopStart)
                                    .padding(4.dp)
                                    .background(CardSurface, CircleShape)
                                    .padding(4.dp)
                                    .size(20.dp),
                        )
                    }
                }
            }
            if (editing) {
                item(key = "editor_help", span = { GridItemSpan(maxLineSpan) }) {
                    Column {
                        Text(
                            stringResource(R.string.drag_blocks_hint),
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                        )
                        TextButton(
                            onClick = {
                                dragged = null
                                PageLayoutController.reset(page)
                            }
                        ) {
                            Text(stringResource(R.string.restore_layout))
                        }
                    }
                }
                if (hidden.isNotEmpty()) {
                    item(key = "hidden_header", span = { GridItemSpan(maxLineSpan) }) {
                        SectionHeader(stringResource(R.string.add_blocks))
                    }
                    items(
                        hidden,
                        key = { "add_${it.block.name}" },
                        span = { GridItemSpan(maxLineSpan) },
                    ) { placement ->
                        val label = stringResource(placement.block.labelRes)
                        GroupedCard(innerPadding = 0.dp) {
                            GroupedCardRow(
                                title = label,
                                icon = Icons.Default.Add,
                                onClick = { PageLayoutController.show(page, placement.block) },
                            )
                        }
                    }
                }
            }
        }
    }
}
