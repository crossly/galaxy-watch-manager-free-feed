package dev.ricky.galaxywatchmanagerfree.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.feature.HeartRateLog
import dev.ricky.galaxywatchmanagerfree.ui.theme.CardBorder
import dev.ricky.galaxywatchmanagerfree.ui.theme.HealthHeart
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextPrimary
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextSecondary
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextTertiary

/** 指定日期的心率曲线：横轴 0–24 时，纵轴按当日范围自适应。 曲线带渐变面积与点按/拖动读数，和其他健康指标详情保持一致。 */
@Composable
fun HeartRateChart(
    points: List<HeartRateLog.Point>,
    day: java.time.LocalDate,
    modifier: Modifier = Modifier,
    zone: java.time.ZoneId = java.time.ZoneId.systemDefault(),
) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources
    val (dayStart, dayEnd) =
        remember(day, zone) {
            day.atStartOfDay(zone).toInstant().toEpochMilli() to
                day.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()
        }
    val sorted =
        remember(points, dayStart, dayEnd) {
            points.filter { it.ts in dayStart until dayEnd }.sortedBy { it.ts }
        }
    val positions = remember(sorted, zone) { sorted.map { chartDayFraction(it.ts, zone) } }
    val range = HeartRateLog.axisRange(sorted)
    val lineColor = HealthHeart
    val gridColor = CardBorder.copy(alpha = 0.55f)
    val labelColor = TextTertiary
    var selected by remember(sorted, day, zone) { mutableStateOf<HeartRateLog.Point?>(null) }

    Column(modifier = modifier.fillMaxWidth()) {
        selected?.let { point ->
            Box(
                modifier =
                    Modifier.fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(lineColor.copy(alpha = 0.12f))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = formatClock(point.ts, zone),
                        style = androidx.compose.material3.MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = lineColor,
                        fontFamily = FontFamily.Monospace,
                    )
                    Text(
                        text = "${point.bpm} ${strings.getString(R.string.bpm_2)}",
                        style = androidx.compose.material3.MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = lineColor,
                        fontFamily = FontFamily.Monospace,
                    )
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
        }

        Canvas(
            modifier =
                Modifier.fillMaxWidth().height(132.dp).testTag("heart_rate_chart").chartProbe(
                    positions,
                    sorted.indexOf(selected).takeIf { it >= 0 },
                    label = strings.getString(R.string.heart_rate),
                    readings =
                        sorted.map {
                            "${formatClock(it.ts, zone)} · ${it.bpm} ${strings.getString(R.string.bpm_2)}"
                        },
                ) { index ->
                    selected = index?.let(sorted::get)
                }
        ) {
            val low = range.first.toFloat()
            val high = range.last.toFloat()
            val usable = (size.height - 10.dp.toPx()).coerceAtLeast(1f)
            fun yOf(value: Int): Float =
                ((high - value) / (high - low) * usable).coerceIn(0f, usable)

            listOf(low, (low + high) / 2f, high).forEach { value ->
                val y = ((high - value) / (high - low) * usable).coerceIn(0f, usable)
                drawLine(gridColor, Offset(0f, y), Offset(size.width, y), strokeWidth = 1f)
            }
            listOf(0f, 6f, 12f, 18f, 24f).forEach { hour ->
                val x = size.width * hour / 24f
                drawLine(gridColor, Offset(x, 0f), Offset(x, usable), strokeWidth = 1f)
            }
            if (sorted.isEmpty()) return@Canvas

            val offsets =
                sorted.mapIndexed { index, point ->
                    val x = size.width * positions[index]
                    Offset(x, yOf(point.bpm))
                }
            drawReadingCurve(
                offsets,
                lineColor,
                usable,
                sorted.indexOf(selected).takeIf { it >= 0 },
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        ChartTimeAxis()
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = strings.getString(R.string.y_axis_bpm, range.first, range.last),
            style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
            color = labelColor,
            fontFamily = FontFamily.Monospace,
        )
    }
}

/** 近 7 天心率：每根胶囊表示当天真实最低–最高范围，横线表示日均值。 纵轴不强制包含 0，避免正常心率波动被压缩在图表顶部。 */
@Composable
fun HeartRateWeekBars(days: List<HeartRateLog.Stats?>, modifier: Modifier = Modifier) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources
    val values = if (days.size == 7) days else List(7) { null }
    val today = java.time.LocalDate.now()
    val labels =
        (6 downTo 0).map { offset ->
            when (today.minusDays(offset.toLong()).dayOfWeek.value) {
                1 -> strings.getString(R.string.mon)
                2 -> strings.getString(R.string.tue)
                3 -> strings.getString(R.string.wed)
                4 -> strings.getString(R.string.thu)
                5 -> strings.getString(R.string.fri)
                6 -> strings.getString(R.string.sat)
                else -> strings.getString(R.string.sun)
            }
        }
    val known = values.filterNotNull()
    if (known.isEmpty()) {
        Text(
            strings.getString(R.string.no_heart_rate_records_in_the_past_7_days),
            style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
            color = TextTertiary,
        )
        return
    }
    val high = (known.maxOf { it.max } + 6).coerceAtMost(HeartRateLog.MAX_BPM)
    val low = (known.minOf { it.min } - 6).coerceAtLeast(HeartRateLog.MIN_BPM)
    val barColor = HealthHeart
    val trackColor = CardBorder.copy(alpha = 0.4f)
    val labelColor = TextTertiary
    val secondary = TextSecondary
    val averageMarkerColor = TextPrimary
    var selectedIndex by remember(values) { mutableStateOf<Int?>(null) }
    val knownIndices = values.indices.filter { values[it] != null }

    Column(modifier = modifier.fillMaxWidth()) {
        selectedIndex?.let { index ->
            values.getOrNull(index)?.let { stat ->
                Box(
                    modifier =
                        Modifier.fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(barColor.copy(alpha = 0.12f))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text =
                            labels[index] +
                                " · " +
                                strings.getString(
                                    R.string.heart_week_range_value,
                                    stat.min,
                                    stat.avg,
                                    stat.max,
                                ),
                        style = androidx.compose.material3.MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = barColor,
                        fontFamily = FontFamily.Monospace,
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
            }
        }

        Canvas(
            modifier =
                Modifier.fillMaxWidth()
                    .height(92.dp)
                    .testTag("heart_rate_week_bars")
                    .chartReadingNavigation(
                        label = strings.getString(R.string.heart_rate),
                        readings =
                            knownIndices.map { index ->
                                val stat = values[index]!!
                                labels[index] +
                                    " · " +
                                    strings.getString(
                                        R.string.heart_week_range_value,
                                        stat.min,
                                        stat.avg,
                                        stat.max,
                                    )
                            },
                        selectedIndex = knownIndices.indexOf(selectedIndex).takeIf { it >= 0 },
                    ) { index ->
                        selectedIndex = index?.let { knownIndices[it] }
                    }
                    .pointerInput(values) {
                        fun selectAt(x: Float) {
                            val index =
                                ((x / size.width) * values.size)
                                    .toInt()
                                    .coerceIn(0, values.lastIndex)
                            selectedIndex =
                                if (values[index] != null) {
                                    if (selectedIndex == index) null else index
                                } else {
                                    null
                                }
                        }
                        detectTapGestures { offset -> selectAt(offset.x) }
                    }
                    .pointerInput(values) {
                        detectHorizontalDragGestures(
                            onDragStart = { offset ->
                                val index =
                                    ((offset.x / size.width) * values.size)
                                        .toInt()
                                        .coerceIn(0, values.lastIndex)
                                selectedIndex = index.takeIf { values[it] != null }
                            },
                            onHorizontalDrag = { change, _ ->
                                change.consume()
                                val index =
                                    ((change.position.x / size.width) * values.size)
                                        .toInt()
                                        .coerceIn(0, values.lastIndex)
                                selectedIndex = index.takeIf { values[it] != null }
                            },
                        )
                    }
        ) {
            val span = (high - low).coerceAtLeast(1)
            val slot = size.width / 7f
            val capsuleWidth = slot * 0.38f
            val minimumCapsuleHeight = 7.dp.toPx()
            fun yOf(bpm: Int) = size.height * (high - bpm).toFloat() / span

            listOf(low, (low + high) / 2, high).forEach { bpm ->
                val y = yOf(bpm)
                drawLine(trackColor, Offset(0f, y), Offset(size.width, y), strokeWidth = 1f)
            }
            selectedIndex?.let { selected ->
                val left = slot * selected
                drawRoundRect(
                    barColor.copy(alpha = 0.055f),
                    topLeft = Offset(left + 3.dp.toPx(), 0f),
                    size = Size((slot - 6.dp.toPx()).coerceAtLeast(1f), size.height),
                    cornerRadius = CornerRadius(6.dp.toPx()),
                )
            }
            values.forEachIndexed { index, stat ->
                val centerX = slot * index + slot / 2f
                if (stat == null) {
                    drawLine(
                        trackColor,
                        Offset(centerX - 3.dp.toPx(), size.height - 2.dp.toPx()),
                        Offset(centerX + 3.dp.toPx(), size.height - 2.dp.toPx()),
                        strokeWidth = 2.dp.toPx(),
                        cap = StrokeCap.Round,
                    )
                    return@forEachIndexed
                }
                val topY = yOf(stat.max)
                val bottomY = yOf(stat.min)
                val capsuleHeight = (bottomY - topY).coerceAtLeast(minimumCapsuleHeight)
                val capsuleTop =
                    ((topY + bottomY) / 2f - capsuleHeight / 2f).coerceIn(
                        0f,
                        size.height - capsuleHeight,
                    )
                val selected = selectedIndex == index
                val isToday = index == values.lastIndex
                drawRoundRect(
                    color =
                        barColor.copy(
                            alpha =
                                when {
                                    selected -> 0.95f
                                    isToday -> 0.76f
                                    else -> 0.4f
                                }
                        ),
                    topLeft = Offset(centerX - capsuleWidth / 2f, capsuleTop),
                    size = Size(capsuleWidth, capsuleHeight),
                    cornerRadius = CornerRadius(capsuleWidth / 2f),
                )
                val averageY = yOf(stat.avg)
                drawLine(
                    averageMarkerColor.copy(alpha = if (selected || isToday) 0.95f else 0.65f),
                    Offset(centerX - capsuleWidth * 0.28f, averageY),
                    Offset(centerX + capsuleWidth * 0.28f, averageY),
                    strokeWidth = 1.5.dp.toPx(),
                    cap = StrokeCap.Round,
                )
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            labels.forEachIndexed { index, label ->
                Text(
                    text = label,
                    style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                    color = if (index == labels.lastIndex) secondary else labelColor,
                    modifier = Modifier.weight(1f),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                )
            }
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = strings.getString(R.string.y_axis_bpm, low, high),
            style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
            color = labelColor,
            fontFamily = FontFamily.Monospace,
        )
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Canvas(modifier = Modifier.width(8.dp).height(18.dp)) {
                drawRoundRect(
                    color = barColor.copy(alpha = 0.48f),
                    size = size,
                    cornerRadius = CornerRadius(size.width / 2f),
                )
                drawLine(
                    averageMarkerColor.copy(alpha = 0.85f),
                    Offset(size.width * 0.18f, size.height / 2f),
                    Offset(size.width * 0.82f, size.height / 2f),
                    strokeWidth = 1.5.dp.toPx(),
                    cap = StrokeCap.Round,
                )
            }
            Text(
                strings.getString(R.string.daily_minimum_maximum),
                style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                color = labelColor,
            )
            Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(barColor))
            Text(
                strings.getString(R.string.daily_average),
                style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                color = labelColor,
            )
        }
    }
}
