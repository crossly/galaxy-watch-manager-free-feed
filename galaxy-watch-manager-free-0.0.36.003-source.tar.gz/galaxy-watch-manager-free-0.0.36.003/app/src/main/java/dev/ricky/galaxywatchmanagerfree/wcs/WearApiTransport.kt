package dev.ricky.galaxywatchmanagerfree.wcs

import android.content.Context
import com.google.android.gms.tasks.Tasks
import com.google.android.gms.wearable.MessageClient
import com.google.android.gms.wearable.MessageEvent
import com.google.android.gms.wearable.Node
import com.google.android.gms.wearable.Wearable
import dev.ricky.galaxywatchmanagerfree.feature.LogBus
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * 基于 Google Play Services / Wear OS companion [MessageClient] 的传输层。
 *
 * 使用此传输时，由官方 companion 持有底层连接，无需本类维护 BLE 唤醒、RFCOMM 协商与 ACK。 这不代表官方连接管理器能与本 App 的独立 RFCOMM
 * 连接同时使用；真机已观察到连接抢占。 该传输仅作为显式启用的诊断通路，BP 入口通过现有 WCS 会话发送请求。
 *
 * 载荷为三星 WCS JSON；显式诊断调用可复用已有消息解析。
 */
class WearApiTransport(context: Context) : MessageClient.OnMessageReceivedListener {

    private val messageClient: MessageClient = Wearable.getMessageClient(context.applicationContext)
    private val nodeClient = Wearable.getNodeClient(context.applicationContext)
    private val executor =
        Executors.newSingleThreadExecutor { r ->
            Thread(r, "wear-api-tx").apply { isDaemon = true }
        }

    private val running = AtomicBoolean(false)
    @Volatile var targetNodeId: String = ""

    /** 收到业务消息回调：(path, payloadBytes, sourceNode) */
    var onMessageListener: ((path: String, payload: ByteArray, sourceNode: String) -> Unit)? = null

    /** 连接状态变化回调 */
    var onConnectionStateListener:
        ((connected: Boolean, nodeName: String, error: String?) -> Unit)? =
        null

    @Synchronized
    fun start() {
        if (!running.compareAndSet(false, true)) return
        LogBus.log("[WearApi] 启动 WearApiTransport...")
        messageClient.addListener(this)
        refreshNodes()
    }

    @Synchronized
    fun stop() {
        if (!running.compareAndSet(true, false)) return
        LogBus.log("[WearApi] 停止 WearApiTransport")
        messageClient.removeListener(this)
        targetNodeId = ""
        executor.shutdown()
        onMessageListener = null
        onConnectionStateListener = null
    }

    /** 异步刷新已连接节点 */
    @Synchronized
    fun refreshNodes() {
        if (!running.get()) return
        executor.execute {
            if (!running.get()) return@execute
            try {
                val nodes: List<Node> = Tasks.await(nodeClient.connectedNodes, 5, TimeUnit.SECONDS)
                if (!running.get()) return@execute
                LogBus.debug { "[WearApi] 已连接的 Wear 节点: ${nodes.size}" }
                val first = nodes.firstOrNull()
                if (first != null) {
                    targetNodeId = first.id
                    LogBus.log("[WearApi] 绑定主手表节点: id=${first.id} name=${first.displayName}")
                    onConnectionStateListener?.invoke(true, first.displayName, null)
                } else {
                    targetNodeId = ""
                    LogBus.debug { "[WearApi] 暂无已连接的 Wear 节点" }
                    onConnectionStateListener?.invoke(false, "", null)
                }
            } catch (e: Exception) {
                if (!running.get()) return@execute
                targetNodeId = ""
                LogBus.error("[WearApi] 获取 Wear 节点失败: ${e.javaClass.simpleName} - ${e.message}", e)
                onConnectionStateListener?.invoke(
                    false,
                    "",
                    "${e.javaClass.simpleName}: ${e.message}",
                )
            }
        }
    }

    /**
     * 向手表发送一条 WCS 业务消息。
     *
     * @param path WCS 路径，例如 [WcsPaths.SYSUI_STATUS_EXCHANGE]
     * @param payload 明文 JSON 字节数组（或自定义 binary）
     */
    @Synchronized
    fun send(path: String, payload: ByteArray, onResult: ((Boolean) -> Unit)? = null) {
        val node = targetNodeId
        if (!running.get() || node.isEmpty()) {
            LogBus.debug { "[WearApi] 未连接手表节点，丢弃发送: $path" }
            onResult?.invoke(false)
            return
        }
        executor.execute {
            if (!running.get()) {
                onResult?.invoke(false)
                return@execute
            }
            try {
                Tasks.await(messageClient.sendMessage(node, path, payload), 5, TimeUnit.SECONDS)
                LogBus.debug { "[WearApi] TX -> $node $path (${payload.size}B)" }
                onResult?.invoke(true)
            } catch (e: Exception) {
                LogBus.error("[WearApi] TX 失败: $path", e)
                onResult?.invoke(false)
            }
        }
    }

    override fun onMessageReceived(event: MessageEvent) {
        if (!running.get()) return
        val path = event.path
        val data = event.data
        val source = event.sourceNodeId
        LogBus.debug { "[WearApi] RX <- $source $path (${data.size}B)" }
        onMessageListener?.invoke(path, data, source)
    }

    companion object {
        private const val TAG = "WearApiTransport"
    }
}
