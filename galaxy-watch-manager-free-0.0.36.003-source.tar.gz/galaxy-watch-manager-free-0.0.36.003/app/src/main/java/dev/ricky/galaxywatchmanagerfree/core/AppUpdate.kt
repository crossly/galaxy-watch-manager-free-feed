package dev.ricky.galaxywatchmanagerfree.core

import org.json.JSONObject

object AppUpdate {
    enum class Channel(val id: String, val feedFile: String) {
        STABLE("stable", "version.json"),
        NIGHTLY("nightly", "nightly.json");

        companion object {
            fun fromPreference(value: String?): Channel =
                entries.firstOrNull { it.id == value } ?: STABLE
        }
    }

    fun channelForVersion(name: String): Channel =
        if (Regex("0\\.0\\.[1-9][0-9]*\\.[0-9]{3}").matches(name) && !name.endsWith(".000"))
            Channel.NIGHTLY
        else Channel.STABLE

    fun selectRelease(channel: Channel, stable: ReleaseInfo, nightly: ReleaseInfo?): ReleaseInfo =
        if (
            channel == Channel.NIGHTLY &&
                nightly != null &&
                isNewer(stable.versionName, stable.versionCode ?: 0, nightly)
        )
            nightly
        else stable

    data class ReleaseInfo(
        /** 去掉前缀 v 的版本名，例如 0.0.4 */
        val versionName: String,
        /** 版本号；缺失时为 null，退化为按版本名比较 */
        val versionCode: Int?,
        val pageUrl: String?,
        val notes: String?,
        val publishedAt: String?,
        val apkName: String?,
        val sha256: String?,
        /** 公开镜像中的 APK 直链；缺失表示只能走发布页 */
        val apkUrl: String? = null,
        /** APK 字节数，用于显示进度；0 表示未知 */
        val apkSize: Long = 0L,
        val channel: Channel = channelForVersion(versionName),
    )

    /** "v1.2.3-beta.1" → [1, 2, 3]；无法解析的段按 0 处理。 */
    fun versionParts(raw: String?): List<Int> {
        val cleaned = raw?.trim()?.removePrefix("v")?.removePrefix("V") ?: return emptyList()
        val core = cleaned.substringBefore('-').substringBefore('+')
        if (core.isBlank()) return emptyList()
        return core.split('.').map { part -> part.takeWhile { it.isDigit() }.toIntOrNull() ?: 0 }
    }

    /** 仅按数字段比较：>0 表示 remote 更新，0 表示相同，<0 表示 remote 更旧。 */
    fun compareNames(current: String?, remote: String?): Int {
        val a = versionParts(current)
        val b = versionParts(remote)
        if (b.isEmpty()) return 0
        val size = maxOf(a.size, b.size)
        for (i in 0 until size) {
            val left = a.getOrElse(i) { 0 }
            val right = b.getOrElse(i) { 0 }
            if (left != right) return right.compareTo(left)
        }
        return 0
    }

    /** 清单带 version_code 时以它为准（单调、不受命名格式影响）； 缺失时退回按版本名逐段比较。远端信息不完整时一律不提示更新。 */
    fun isNewer(currentName: String, currentCode: Int, remote: ReleaseInfo): Boolean {
        val remoteCode = remote.versionCode
        if (remoteCode != null && remoteCode > 0 && currentCode > 0) {
            return remoteCode > currentCode
        }
        return compareNames(currentName, remote.versionName) > 0
    }

    /** 解析 feed 的 version.json；既没有版本号也没有可解析版本名时返回 null。 */
    fun parseFeed(json: String): ReleaseInfo? {
        val root = runCatching { JSONObject(json) }.getOrNull() ?: return null
        val rawName =
            root.optString("version_name").trim().ifBlank { root.optString("version").trim() }
        val code = root.optInt("version_code", 0).takeIf { it > 0 }
        val versionName = rawName.removePrefix("v").removePrefix("V")
        if (versionName.isEmpty() && code == null) return null
        val channel = channelForVersion(versionName)
        if (root.has("channel") && root.optString("channel") != channel.id) return null
        return ReleaseInfo(
            versionName = versionName,
            versionCode = code,
            pageUrl = root.optString("page_url").ifBlank { null },
            notes = root.optString("notes").trim().ifBlank { null }?.take(4000),
            publishedAt = root.optString("published_at").ifBlank { null },
            apkName = root.optString("apk_name").ifBlank { null },
            sha256 = root.optString("sha256").ifBlank { null }?.lowercase(),
            // 只收 http(s)；发布构建在 ApkUpdater 里进一步强制 https
            apkUrl =
                root.optString("apk_url").trim().takeIf {
                    it.startsWith("https://") || it.startsWith("http://")
                },
            apkSize = root.optLong("apk_size", 0L).coerceAtLeast(0L),
        )
    }
}
