package dev.ricky.galaxywatchmanagerfree.core

import android.content.Context
import android.content.res.Configuration
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat

/** AppCompat persists the selected language; no second locale preference is maintained. */
object AppLanguage {
    val tags = listOf("", "zh-CN", "en")

    fun select(languageTag: String) {
        require(languageTag in tags)
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(languageTag))
    }

    /** Services and application-context Toasts also use the selected app language on API < 33. */
    fun context(context: Context): Context {
        val locales = AppCompatDelegate.getApplicationLocales()
        if (locales.isEmpty) return context
        val configuration = Configuration(context.resources.configuration)
        configuration.setLocales(android.os.LocaleList.forLanguageTags(locales.toLanguageTags()))
        return context.createConfigurationContext(configuration)
    }
}
