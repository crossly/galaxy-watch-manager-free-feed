package dev.ricky.galaxywatchmanagerfree.feature

import java.time.ZoneId
import org.json.JSONObject

/** Collect a specifically requested cold sync; ordinary delta windows cannot replace totals. */
class HealthStepSnapshot {
    private var requested = false
    private var started = false
    private val records = linkedMapOf<String, JSONObject>()

    @Synchronized
    fun begin() {
        requested = true
        started = false
        records.clear()
    }

    @Synchronized
    fun reset() {
        requested = false
        started = false
        records.clear()
    }

    data class Snapshot(val records: List<JSONObject>, val total: Int)

    @Synchronized
    fun accept(
        deviceInfo: JSONObject?,
        incoming: List<JSONObject>?,
        now: Long,
        zone: ZoneId = ZoneId.systemDefault(),
    ): Snapshot? {
        if (!requested || deviceInfo == null) return null
        if (!started) {
            if (!deviceInfo.has("start_time") || deviceInfo.optLong("start_time") != 0L) return null
            started = true
        }
        incoming.orEmpty().forEach { record ->
            if (
                !HealthStepParser.isSameLocalDay(
                    HealthStepParser.recordStartTime(record),
                    now,
                    zone,
                )
            )
                return@forEach
            val id = HealthStepParser.recordIdentity(record)
            val old = records[id]
            if (
                old == null ||
                    HealthStepParser.recordUpdateTime(record) >=
                        HealthStepParser.recordUpdateTime(old)
            ) {
                records[id] = record
            }
        }
        if (!deviceInfo.optBoolean("is_last_chunk", false)) return null
        requested = false
        started = false
        val snapshot = records.values.toList()
        records.clear()
        // An explicitly empty module is a valid zero-step day. Missing module is not evidence of
        // zero.
        if (snapshot.isEmpty() && incoming == null) return null
        return Snapshot(snapshot, snapshot.sumOf(HealthStepParser::recordSteps))
    }
}
