package dev.ricky.galaxywatchmanagerfree.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.ui.theme.CardBorder
import dev.ricky.galaxywatchmanagerfree.ui.theme.EmeraldCharging
import dev.ricky.galaxywatchmanagerfree.ui.theme.HealthSteps
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextSecondary
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextTertiary

/** 最近 7 天步数柱状图，带目标参考线。 */
@Composable
fun WeekStepBars(
    steps: List<Int>,
    goal: Int,
    modifier: Modifier = Modifier,
    barHeight: Dp = 72.dp,
) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources

    val values = if (steps.size == 7) steps else List(7) { 0 }
    val today = java.time.LocalDate.now()
    val labels =
        (6 downTo 0).map { offset ->
            val date = today.minusDays(offset.toLong())
            when (date.dayOfWeek.value) {
                1 -> strings.getString(R.string.mon)
                2 -> strings.getString(R.string.tue)
                3 -> strings.getString(R.string.wed)
                4 -> strings.getString(R.string.thu)
                5 -> strings.getString(R.string.fri)
                6 -> strings.getString(R.string.sat)
                else -> strings.getString(R.string.sun)
            }
        }
    val ceiling = maxOf(values.maxOrNull() ?: 0, goal).coerceAtLeast(1)
    val goalRatio = (goal.toFloat() / ceiling).coerceIn(0f, 1f)
    val goalLineColor = TextTertiary.copy(alpha = 0.35f)

    Box(modifier = modifier.fillMaxWidth()) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth().height(barHeight),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.Bottom,
            ) {
                values.forEachIndexed { index, value ->
                    val ratio = (value.toFloat() / ceiling).coerceIn(0f, 1f)
                    val reached = goal > 0 && value >= goal
                    Box(
                        modifier =
                            Modifier.weight(1f)
                                .height(
                                    (barHeight.value * ratio)
                                        .dp
                                        .coerceAtLeast(if (value <= 0) 2.dp else 4.dp)
                                )
                                .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
                                .background(
                                    when {
                                        index == values.lastIndex && reached -> EmeraldCharging
                                        index == values.lastIndex -> HealthSteps
                                        reached -> EmeraldCharging.copy(alpha = 0.55f)
                                        value <= 0 -> CardBorder.copy(alpha = 0.45f)
                                        else -> HealthSteps.copy(alpha = 0.35f)
                                    }
                                )
                    )
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                labels.forEachIndexed { index, label ->
                    Text(
                        text = label,
                        style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                        color = if (index == labels.lastIndex) TextSecondary else TextTertiary,
                        modifier = Modifier.weight(1f),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    )
                }
            }
        }
        // 目标参考线
        Canvas(modifier = Modifier.fillMaxWidth().height(barHeight)) {
            val y = size.height - size.height * goalRatio
            drawLine(
                color = goalLineColor,
                start = Offset(0f, y),
                end = Offset(size.width, y),
                strokeWidth = 1f,
                pathEffect =
                    androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(6f, 6f)),
            )
        }
    }
}
