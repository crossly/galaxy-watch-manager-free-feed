package dev.ricky.galaxywatchmanagerfree.feature

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import org.json.JSONArray
import org.json.JSONObject

/**
 * 健康数据的时间维度整理（纯逻辑）：24 小时分布、逐日历史、连续达标、里程碑。
 *
 * 数据来源都是手表真实下发的报文：
 * - `pedometer_day_summary.binning_data`：10 分钟一个桶（0–143），带 `steps`；
 * - `pedometer_step_count` 区间明细：带 `start_time`，缺失分桶时按起点小时归位。
 *
 * 里程碑与连续达标的阈值对齐 Samsung Health 的步数奖励：
 * - 单日里程碑 10K / 20K / 30K / 40K 步；
 * - 连续达标奖励 7 / 14 / 21 / 28 天。
 */
object HealthTimeline {

    const val HOURS = 24
    const val BUCKET_MINUTES = 10
    const val BUCKETS_PER_DAY = 144

    val MILESTONES = listOf(10_000, 20_000, 30_000, 40_000)
    val STREAK_BADGES = listOf(7, 14, 21, 28)

    /** 一天的健康汇总，历史里按日期保存 */
    data class Day(val steps: Int, val calories: Int, val distanceMeters: Int)

    data class Milestone(val steps: Int, val achieved: Boolean)

    fun emptyHours(): List<Int> = List(HOURS) { 0 }

    fun dayKey(date: LocalDate): String = date.toString()

    fun todayKey(nowMillis: Long, zone: ZoneId = ZoneId.systemDefault()): String =
        dayKey(Instant.ofEpochMilli(nowMillis).atZone(zone).toLocalDate())

    private fun hourOf(ts: Long, zone: ZoneId): Int? =
        runCatching { Instant.ofEpochMilli(ts).atZone(zone).hour }.getOrNull()

    private fun bucketSteps(o: JSONObject): Int {
        val direct = o.optInt("steps", Int.MIN_VALUE)
        if (direct != Int.MIN_VALUE) return direct.coerceAtLeast(0)
        val run = o.optInt("run_steps", 0)
        val walk = o.optInt("walk_steps", 0)
        if (run + walk > 0) return run + walk
        return o.optInt("count", 0).coerceAtLeast(0)
    }

    /**
     * `binning_data` 转 24 小时分布。 元素可以是列表形式 `[index, steps]`，也可以是对象；两种都兼容。 index 为当天第 N 个 10
     * 分钟桶，超出范围的值忽略。
     */
    fun hoursFromBinning(bins: JSONArray?, zone: ZoneId = ZoneId.systemDefault()): List<Int> {
        val hours = MutableList(HOURS) { 0 }
        if (bins == null) return hours
        for (i in 0 until bins.length()) {
            val entry = bins.optJSONObject(i)
            if (entry != null) {
                val index = entry.optInt("index", -1)
                if (index !in 0 until BUCKETS_PER_DAY) {
                    // 极少数报文带桶起点时间戳，按时间归位。
                    val ts = entry.optLong("start_time", entry.optLong("time", 0L))
                    val hour = if (ts > 0) hourOf(ts, zone) ?: continue else continue
                    hours[hour] += bucketSteps(entry)
                    continue
                }
                hours[(index * BUCKET_MINUTES) / 60] += bucketSteps(entry)
                continue
            }
            // 列表形式：[index, steps] 或 [index, run, walk]
            val pair = bins.optJSONArray(i) ?: continue
            val index = pair.optInt(0, -1)
            if (index !in 0 until BUCKETS_PER_DAY) continue
            val steps =
                if (pair.length() >= 3) pair.optInt(1, 0) + pair.optInt(2, 0) else pair.optInt(1, 0)
            hours[(index * BUCKET_MINUTES) / 60] += steps.coerceAtLeast(0)
        }
        return hours
    }

    /** 区间明细按 `start_time` 归入小时；无时间戳或非 [nowMillis] 当日的记录丢弃。 */
    fun hoursFromIntervals(
        records: List<JSONObject>,
        zone: ZoneId = ZoneId.systemDefault(),
        nowMillis: Long,
    ): List<Int> {
        val hours = MutableList(HOURS) { 0 }
        records.forEach { record ->
            val ts = HealthStepParser.recordStartTime(record)
            val hour = if (ts > 0) hourOf(ts, zone) else null
            if (hour == null) return@forEach
            if (!HealthStepParser.isSameLocalDay(ts, nowMillis, zone)) return@forEach
            hours[hour] += HealthStepParser.recordSteps(record)
        }
        return hours
    }

    /** 两个分布取逐小时最大值：手表重发时不会把已有柱子抹平。 */
    fun mergeHours(existing: List<Int>, incoming: List<Int>): List<Int> {
        if (incoming.isEmpty()) return existing
        if (existing.isEmpty()) return incoming
        return List(HOURS) { i -> maxOf(existing.getOrElse(i) { 0 }, incoming.getOrElse(i) { 0 }) }
    }

    /** 今日累计小时分布：分桶优先，缺失时由区间明细补；[nowMillis] 固定「今日」的时点。 */
    fun resolveTodayHours(
        current: List<Int>,
        bins: JSONArray?,
        intervals: List<JSONObject>,
        zone: ZoneId = ZoneId.systemDefault(),
        nowMillis: Long,
    ): List<Int> {
        val fromBins = if (bins != null) hoursFromBinning(bins, zone) else emptyHours()
        val fromIntervals =
            if (intervals.isEmpty()) emptyHours()
            else hoursFromIntervals(intervals, zone, nowMillis)
        return mergeHours(mergeHours(current, fromBins), fromIntervals)
    }

    /** 写入/更新某一天的历史（步数只增不减，避免迟到报文把当天数字改小） */
    fun upsertDay(
        history: MutableMap<String, Day>,
        day: String,
        steps: Int,
        calories: Int,
        distanceMeters: Int,
        replace: Boolean = false,
    ) {
        val previous = if (replace) null else history[day]
        val merged =
            Day(
                steps = maxOf(previous?.steps ?: 0, steps),
                calories = maxOf(previous?.calories ?: 0, calories),
                distanceMeters = maxOf(previous?.distanceMeters ?: 0, distanceMeters),
            )
        history[day] = merged
    }

    /** 只保留最近 [keep] 天，按日期倒序截断 */
    fun trimHistory(history: MutableMap<String, Day>, keep: Int = 60) {
        if (history.size <= keep) return
        history.keys.sortedDescending().drop(keep).forEach { history.remove(it) }
    }

    /**
     * 连续达标天数。
     *
     * 今天还没达标不算断链（一天还没过完），从昨天往前数； 今天已达标则今天计入。缺数据的日期视为断链。
     */
    fun streak(history: Map<String, Day>, goal: Int, today: LocalDate, todaySteps: Int): Int {
        if (goal <= 0) return 0
        var count = 0
        val todayReached = todaySteps >= goal
        if (todayReached) count = 1
        var cursor = today.minusDays(1)
        while (true) {
            val day = history[dayKey(cursor)] ?: break
            if (day.steps < goal) break
            count++
            cursor = cursor.minusDays(1)
            if (count > 3650) break
        }
        return count
    }

    fun milestones(steps: Int): List<Milestone> = MILESTONES.map { Milestone(it, steps >= it) }

    fun nextMilestone(steps: Int): Int? = MILESTONES.firstOrNull { steps < it }

    fun nextStreakBadge(streak: Int): Int? = STREAK_BADGES.firstOrNull { streak < it }

    /** 最近 7 天（含今天）的柱状数据，按日期升序 */
    fun lastWeek(
        history: Map<String, Day>,
        today: LocalDate,
        todaySteps: Int,
    ): List<Pair<LocalDate, Int>> =
        (6 downTo 0).map { offset ->
            val date = today.minusDays(offset.toLong())
            val steps =
                if (offset == 0) maxOf(todaySteps, history[dayKey(date)]?.steps ?: 0)
                else history[dayKey(date)]?.steps ?: 0
            date to steps
        }

    // Serialization

    fun encodeHistory(history: Map<String, Day>): String {
        val root = JSONObject()
        history.toSortedMap().forEach { (day, value) ->
            root.put(
                day,
                JSONArray().put(value.steps).put(value.calories).put(value.distanceMeters),
            )
        }
        return root.toString()
    }

    fun decodeHistory(raw: String?): MutableMap<String, Day> {
        val result = mutableMapOf<String, Day>()
        if (raw.isNullOrBlank()) return result
        val root = runCatching { JSONObject(raw) }.getOrNull() ?: return result
        root.keys().forEach { day ->
            val arr = root.optJSONArray(day) ?: return@forEach
            result[day] =
                Day(
                    steps = arr.optInt(0, 0),
                    calories = arr.optInt(1, 0),
                    distanceMeters = arr.optInt(2, 0),
                )
        }
        return result
    }

    fun encodeHours(hours: List<Int>): String = hours.joinToString(",")

    fun decodeHours(raw: String?): List<Int> {
        if (raw.isNullOrBlank()) return emptyHours()
        val values = raw.split(',').mapNotNull { it.trim().toIntOrNull() }
        if (values.size != HOURS) return emptyHours()
        return values
    }
}
