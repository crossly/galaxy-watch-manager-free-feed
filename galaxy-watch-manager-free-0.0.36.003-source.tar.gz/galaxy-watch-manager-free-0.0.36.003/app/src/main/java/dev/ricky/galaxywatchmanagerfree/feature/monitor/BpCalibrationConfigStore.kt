package dev.ricky.galaxywatchmanagerfree.feature.monitor

import org.json.JSONArray
import org.json.JSONObject

/**
 * Archives official calibration rows verbatim; the watch owns their algorithm and interpretation.
 */
class BpCalibrationConfigStore(
    private val read: () -> String?,
    private val write: (String) -> Boolean,
) {
    @Synchronized
    fun persist(incoming: List<JSONObject>): Boolean =
        runCatching {
                val rows = linkedMapOf<String, JSONObject>()
                fun merge(row: JSONObject) {
                    val id = row.getString("datauuid")
                    require(id.isNotBlank() && row.getLong("start_time") > 0)
                    val key = row.optString("deviceuuid") + ":" + id
                    val previous = rows[key]
                    fun revision(value: JSONObject) =
                        value.optLong("update_time", value.getLong("start_time"))
                    if (previous == null || revision(row) >= revision(previous)) {
                        rows[key] = JSONObject(row.toString())
                    }
                }
                val saved = JSONArray(read() ?: "[]")
                repeat(saved.length()) { merge(saved.getJSONObject(it)) }
                incoming.forEach(::merge)
                write(JSONArray(rows.values.toList()).toString())
            }
            .getOrDefault(false)
}
