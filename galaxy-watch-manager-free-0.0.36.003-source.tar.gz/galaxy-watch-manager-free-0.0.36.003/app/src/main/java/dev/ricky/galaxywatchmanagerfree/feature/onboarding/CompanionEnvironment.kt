package dev.ricky.galaxywatchmanagerfree.feature.onboarding

import android.content.Context
import android.content.Intent
import android.net.Uri

/**
 * Official companion apps that can take part in pairing / holding the watch's Bluetooth channel.
 */
object CompanionApps {
    const val WEAR_CN = "com.google.android.wearable.app.cn"
    const val WEAR_INTL = "com.google.android.wearable.app"
    const val WATCH_MANAGER = "com.samsung.android.app.watchmanager"
    const val SHIZUKU = "moe.shizuku.privileged.api"

    fun openPackage(context: Context, packageName: String): Boolean {
        val intent =
            context.packageManager
                .getLaunchIntentForPackage(packageName)
                ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) ?: return false
        return runCatching {
                context.startActivity(intent)
                true
            }
            .getOrDefault(false)
    }

    /** Store listing, falling back to the public Play page when no market app exists. */
    fun openStore(context: Context, packageName: String): Boolean {
        val market =
            Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (
            runCatching {
                    context.startActivity(market)
                    true
                }
                .getOrDefault(false)
        )
            return true
        val web =
            Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://play.google.com/store/apps/details?id=$packageName"),
                )
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return runCatching {
                context.startActivity(web)
                true
            }
            .getOrDefault(false)
    }

    fun openAppDetails(context: Context, packageName: String): Boolean =
        runCatching {
                context.startActivity(
                    Intent(
                            android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:$packageName"),
                        )
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                true
            }
            .getOrDefault(false)
}

/** Detected installation / effective enabled state of the official connection stack. */
data class CompanionEnvironment(
    val wearPackage: String?,
    val wearEnabled: Boolean,
    val managerInstalled: Boolean,
) {
    val hasGoogleWear: Boolean
        get() = wearPackage != null
}

fun detectCompanionEnvironment(context: Context): CompanionEnvironment {
    val packageManager = context.packageManager
    val wearPackage =
        listOf(CompanionApps.WEAR_CN, CompanionApps.WEAR_INTL).firstOrNull { packageName ->
            runCatching { packageManager.getApplicationInfo(packageName, 0) }.isSuccess
        }
    // ApplicationInfo.enabled is the manifest default; user or privileged helpers can override it.
    val wearEnabled =
        wearPackage?.let { packageName ->
            runCatching { packageManager.getApplicationEnabledSetting(packageName) }
                .getOrDefault(android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_DEFAULT)
                .let { state ->
                    state == android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_DEFAULT ||
                        state == android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_ENABLED
                }
        } ?: false
    val manager =
        runCatching { packageManager.getApplicationInfo(CompanionApps.WATCH_MANAGER, 0) }.isSuccess
    return CompanionEnvironment(
        wearPackage = wearPackage,
        wearEnabled = wearEnabled,
        managerInstalled = manager,
    )
}
