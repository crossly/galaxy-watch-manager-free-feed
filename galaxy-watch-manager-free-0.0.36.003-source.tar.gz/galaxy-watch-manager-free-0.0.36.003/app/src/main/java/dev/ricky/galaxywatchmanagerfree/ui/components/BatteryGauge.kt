package dev.ricky.galaxywatchmanagerfree.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.feature.WatchState
import dev.ricky.galaxywatchmanagerfree.ui.theme.*

@Composable
fun BatteryGaugeCard(state: WatchState, modifier: Modifier = Modifier) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources

    val charging = state.charging || state.batteryStatus == 2
    val flowing = charging && state.batteryStatus != 5
    val progress by
        animateFloatAsState(
            if (state.batteryLevel < 0) 0f else state.batteryLevel.coerceIn(0, 100) / 100f,
            label = "Battery",
        )
    val color =
        if (state.batteryLevel in 0..20) AlertCrimson
        else if (charging) EmeraldCharging else ElectricBlue
    GroupedCard(
        modifier,
        cornerRadius = 34.dp,
        innerPadding = 16.dp,
        backgroundColor = tonalSurface(color, 0.07f),
        accent = color,
    ) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Icon(
                Icons.Default.BatteryFull,
                null,
                tint = TextSecondary,
                modifier = Modifier.size(18.dp),
            )
            Text(
                strings.getString(R.string.watch_battery),
                modifier = Modifier.weight(1f),
                style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.SemiBold,
                color = TextSecondary,
            )
            Box(
                Modifier.clip(CircleShape)
                    .background(CardSurfaceElevated)
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Text(
                    if (state.batteryStatus == 5) strings.getString(R.string.fully_charged)
                    else if (charging) strings.getString(R.string.charging)
                    else if (state.psmMode) strings.getString(R.string.power_saving)
                    else strings.getString(R.string.standard_mode),
                    style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                    color = TextSecondary,
                )
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                if (state.batteryLevel >= 0) "${state.batteryLevel}" else "—",
                fontSize = 34.sp,
                lineHeight = 38.sp,
                letterSpacing = (-0.6).sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
            )
            Text(
                "%",
                style = androidx.compose.material3.MaterialTheme.typography.bodyLarge,
                color = TextSecondary,
                modifier = Modifier.padding(start = 2.dp, bottom = 4.dp),
            )
            Spacer(Modifier.weight(1f))
            if (charging && state.sessionReady)
                StatusOrb(
                    Icons.Default.Bolt,
                    EmeraldCharging,
                    active = flowing && !state.startupSyncing,
                    modifier = Modifier.size(40.dp),
                )
        }
        Spacer(Modifier.height(10.dp))
        ChargeProgress(
            progress = progress,
            charging = flowing && state.sessionReady && !state.startupSyncing,
            color = color,
            track = CardSurfaceElevated,
            height = 8.dp,
        )
        if (state.startupSyncing) {
            Spacer(Modifier.height(8.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                androidx.compose.material3.CircularProgressIndicator(
                    Modifier.size(14.dp),
                    color = color,
                    strokeWidth = 2.dp,
                )
                Text(
                    if (state.batteryLevel < 0) strings.getString(R.string.reading_battery_status)
                    else strings.getString(R.string.updating_saved_battery_status),
                    style = androidx.compose.material3.MaterialTheme.typography.labelMedium,
                    color = TextSecondary,
                )
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            BatteryEstimate(
                strings.getString(R.string.estimated_remaining),
                when {
                    !state.normalBatteryEstimateReceived ->
                        strings.getString(R.string.battery_estimate_waiting)
                    state.remainingNormalMin < 0 ->
                        strings.getString(R.string.battery_estimate_learning)
                    else -> minutes(state.remainingNormalMin, strings)
                },
                Modifier.weight(1f),
            )
            BatteryEstimate(
                strings.getString(R.string.with_power_saving),
                when {
                    !state.psmBatteryEstimateReceived ->
                        strings.getString(R.string.battery_estimate_waiting)
                    state.remainingPsmMin < 0 ->
                        strings.getString(R.string.battery_estimate_learning)
                    else -> minutes(state.remainingPsmMin, strings)
                },
                Modifier.weight(1f),
            )
        }
    }
}

@Composable
private fun BatteryEstimate(label: String, value: String, modifier: Modifier) {
    Column(
        modifier
            .clip(androidx.compose.foundation.shape.RoundedCornerShape(18.dp))
            .background(CardSurfaceElevated)
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Text(
            label,
            style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
            color = TextSecondary,
        )
        Spacer(Modifier.height(2.dp))
        Text(
            value,
            style = androidx.compose.material3.MaterialTheme.typography.titleSmall,
            color = TextPrimary,
        )
    }
}

private fun minutes(value: Int, strings: android.content.res.Resources): String =
    when {
        value >= 1440 ->
            strings.getString(R.string.duration_days_hours_compact, value / 1440, value % 1440 / 60)
        value >= 60 ->
            strings.getString(R.string.duration_hours_minutes_compact, value / 60, value % 60)
        else -> strings.getQuantityString(R.plurals.duration_minutes, value, value)
    }
