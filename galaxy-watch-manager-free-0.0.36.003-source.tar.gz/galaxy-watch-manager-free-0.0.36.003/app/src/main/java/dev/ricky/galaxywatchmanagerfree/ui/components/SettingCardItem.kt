package dev.ricky.galaxywatchmanagerfree.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.toggleable
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.ui.theme.*

@Composable
fun SettingSectionCard(
    title: String,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit,
) {
    Column(modifier) {
        SectionHeader(title)
        GroupedCard(innerPadding = 16.dp, content = content)
    }
}

@Composable
fun SettingSwitchRow(
    title: String,
    checked: Boolean,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    enabled: Boolean = true,
    onCheckedChange: (Boolean) -> Unit,
) {
    Row(
        modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .toggleable(
                value = checked,
                enabled = enabled,
                role = Role.Switch,
                onValueChange = onCheckedChange,
            )
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                title,
                style = androidx.compose.material3.MaterialTheme.typography.bodyLarge,
                lineHeight = 22.sp,
                color = if (enabled) TextPrimary else TextDisabled,
            )
            if (!subtitle.isNullOrEmpty())
                Text(
                    subtitle,
                    style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                    lineHeight = 18.sp,
                    color = TextSecondary,
                )
        }
        Switch(checked = checked, onCheckedChange = null, enabled = enabled)
    }
}

@Composable
fun SettingSliderRow(
    title: String,
    value: Int?,
    modifier: Modifier = Modifier,
    range: ClosedFloatingPointRange<Float> = 0f..100f,
    unit: String = "",
    enabled: Boolean = true,
    onValueChange: (Int) -> Unit,
) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources
    var local by
        remember(value) { mutableFloatStateOf(value?.toFloat()?.coerceIn(range) ?: range.start) }
    Column(modifier.fillMaxWidth().padding(vertical = 12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                title,
                style = androidx.compose.material3.MaterialTheme.typography.bodyLarge,
                modifier = Modifier.weight(1f),
                color = if (enabled) TextPrimary else TextDisabled,
            )
            Text(
                if (value == null) strings.getString(R.string.not_synced)
                else "${local.toInt()}$unit",
                style = androidx.compose.material3.MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
            )
        }
        Spacer(Modifier.height(12.dp))
        Slider(
            value = local,
            onValueChange = { local = it },
            onValueChangeFinished = { onValueChange(local.toInt()) },
            valueRange = range,
            enabled = enabled && value != null,
        )
    }
}

@Composable
fun SettingChoiceRow(
    title: String,
    options: List<String>,
    selectedIndex: Int,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onSelect: (Int) -> Unit,
) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources

    var choosing by remember { mutableStateOf(false) }
    GroupedCardRow(
        title = title,
        modifier = modifier,
        enabled = enabled,
        showChevron = true,
        onClick = { choosing = true },
        trailing = {
            Text(
                options.getOrNull(selectedIndex) ?: strings.getString(R.string.not_synced),
                style = androidx.compose.material3.MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
            )
        },
    )
    if (choosing)
        AlertDialog(
            onDismissRequest = { choosing = false },
            title = { Text(title) },
            text = {
                Column {
                    options.forEachIndexed { index, label ->
                        Row(
                            Modifier.fillMaxWidth()
                                .pressFeedback {
                                    onSelect(index)
                                    choosing = false
                                }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            RadioButton(selected = index == selectedIndex, onClick = null)
                            Text(
                                label,
                                style =
                                    androidx.compose.material3.MaterialTheme.typography.bodyLarge,
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { choosing = false }) {
                    Text(strings.getString(R.string.cancel))
                }
            },
        )
}
