package dev.ricky.galaxywatchmanagerfree.core

/** Owns a connection request across asynchronous discovery, service starts and callbacks. */
internal class ConnectionRequestGate {
    data class Request(val generation: Long, val mac: String)

    private var generation = 0L
    private var current: Request? = null

    @Synchronized
    fun begin(mac: String): Request =
        Request(++generation, mac.uppercase(java.util.Locale.ROOT)).also { current = it }

    @Synchronized
    fun invalidate() {
        generation++
        current = null
    }

    @Synchronized fun isCurrent(request: Request): Boolean = current == request

    @Synchronized
    fun matches(generation: Long, mac: String): Boolean =
        current?.let { it.generation == generation && it.mac.equals(mac, ignoreCase = true) } ==
            true
}
