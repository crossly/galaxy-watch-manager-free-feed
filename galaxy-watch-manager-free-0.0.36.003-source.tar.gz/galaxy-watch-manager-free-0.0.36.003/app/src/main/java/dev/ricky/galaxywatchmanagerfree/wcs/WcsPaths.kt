package dev.ricky.galaxywatchmanagerfree.wcs

import java.util.UUID

/** Protocol paths and constants for Wear OS and Samsung WCS communication. */
object WcsPaths {

    val DATA_LAYER: UUID = UUID.fromString("5e8945b0-9525-11e3-a5e2-0800200c9a66")
    val DIRECT_PROFILE_SECURE: UUID = UUID.fromString("cee50b63-5f79-4727-8b5d-504eb07e1e22")
    val FLOW: UUID = UUID.fromString("fafbdd20-83f0-4389-addf-917ac9dae5b2")

    const val PKG_WATCH_WCS = "com.samsung.android.wcs.extension"
    const val SIGNATURE_PLUGIN = "9ca5170f381919dfe0446fcdab18b19a143b3163"

    // Handshake
    const val INTERNAL_CONNECTION = "/wcs_extension/internal/connection"
    const val INTERNAL_STATUS = "/wcs_extension/internal/status"
    const val INTERNAL_FEATURE = "/wcs_extension/internal/feature"
    const val INTERNAL_P2P = "/wcs_extension/internal/p2p"
    const val INTERNAL_RESET = "/wcs_extension/internal/reset"
    const val INTERNAL_SIM = "/wcs_extension/internal/sim"
    const val INTERNAL_PACKAGES = "/wcs_extension/internal/packages"
    const val INTERNAL_TEXT_TEMPLATE = "/wcs_extension/internal/text_template"
    const val INTERNAL_BUGRERPORT = "/wcs_extension/internal/bugreport"

    const val MSG_SET_DEVICE_ACTIVATION = "set_device_activation"
    const val MSG_STATUS_EXCHANGE = "status_exchange"
    const val MSG_FEATURE_EXCHANGE = "feature_exchange"
    const val MSG_ACTIVE_INFO = "active_info"
    const val MSG_WIFI_P2P_FEATURE = "wifi_p2p_feature"
    const val MSG_TEXT_TEMPLATE_SYNC = "text_template_sync"
    const val MSG_EMOJI_RESPONSE = "emoji_response"
    const val MSG_CUSTOM_RESPONSE = "custom_response"

    // Notifications
    const val NOTI_BRIDGE = "/wcs_extension/sysui/notification/bridge"
    const val NOTI_SETTINGS = "/wcs_extension/sysui/notification/settings"
    const val NOTI_SWITCH = "/wcs_extension/sysui/notification/switch"
    const val NOTI_SWITCH_COMMON = "/wcs_extension/sysui/notification/switch/common_settings"
    const val NOTI_SWITCH_APP = "/wcs_extension/sysui/notification/switch/app_settings"
    const val NOTI_SWITCH_ALERT = "/wcs_extension/sysui/notification/switch/alert_settings"
    const val NOTI_FOCUSMODE = "/wcs_extension/sysui/notification/focusmode"

    const val MSG_NOTIFICATION_FEATURE_EXCHANGE = "notification_feature_exchange"
    const val MSG_NOTIFICATION_SETTINGS = "notification_settings"
    const val MSG_NOTIFICATION_SETTINGS_FEATURE_EXCHANGE = "notification_settings_feature_exchange"
    const val MSG_NOTIFICATION_ALLOWED_PACKAGES = "notification_allowed_packages"
    const val MSG_PHONE_SETTING_TOP_PRIORITY = "phone_setting_top_priority_features"
    const val MSG_SET_WATCH_BIXBY_ENABLE = "set_watch_bixby_enable_state"

    // Watch faces
    const val WATCHFACE_SYSUI = "/wcs_extension/sysui/watchface"
    const val WATCHFACE_HOME = "/w_watchface_home/watchface"
    const val WATCHFACE_HOME_MSG = "/w_watchface_home/watchface/msg"
    const val WATCHFACE_MODULE_MSG = "/w_module_watchface/msg"
    const val WATCHFACE_MODULE_DEVICE_MSG = "/w_module_watchface/device_msg"
    const val MSG_WATCHFACE_ORDER = "watchface_order"
    const val MSG_CHANGE_ACTIVE_WATCHFACE = "change_active_watchface"
    const val MSG_WATCHFACE_ORDER_TYPE = "watchface_order_type"
    const val MSG_WATCHFACE_LAUNCH = "watchface_launch"
    const val MSG_ADDABLE_WATCHFACE_INFO = "addable_watchface_info"
    const val ORDER_TYPE_CUSTOM = "custom"
    const val ORDER_TYPE_RECENT = "recent"
    const val ORDER_TYPE_ALPHABETIC = "alphabetic"

    // Apps & widgets
    const val SYSUI_APPS = "/wcs_extension/sysui/apps"
    const val MSG_APPS_ORDER = "apps_order"

    const val SYSUI_WIDGET = "/wcs_extension/sysui/widget"
    const val TILES_CAPABILITY = "/tiles/capability/home"
    const val TILES_CONFIGS = "/tiles/data/configs"
    const val COMPLICATION_PROVIDERS = "/complication_providers/data/provider_app"
    const val MSG_ADDABLE_TILE_INFO = "addable_tile_info"

    // Quick actions
    const val QUICKACTION_INFO = "/wcs_extension/quickaction/info"
    const val MSG_QUICK_SETTINGS = "quick_settings"

    // Settings
    private const val SET = "/w_module_sec_watch_setting"
    const val SET_INFO_REQ = "$SET/info/setting_info_req"
    const val SET_INFO = "$SET/info/setting_info"
    const val SET_INFO_SUPPORT_FEATURE = "$SET/info/setting_info_support_feature"
    const val SET_INFO_NAL = "$SET/info/setting_info_nal"
    const val SET_INFO_WATCH_NAME = "$SET/info/setting_info/watch_name"
    const val SET_APP_INFO = "$SET/info/application_info"
    const val SET_BLUETOOTH = "$SET/bluetooth"
    const val SET_BT_INFO_SYNC = "$SET/btinfosync"
    const val SET_WIFI_CONFIG_SYNC = "$SET/wificonfigsync"
    const val SET_PSM = "$SET/psm"
    const val SET_BATTERY_CHANGED = "$SET/battery_changed"
    const val SET_FEATURE = "$SET/feature"
    const val SET_RESET = "$SET/general/reset"
    const val SET_CREATE_DATAITEM_REQ = "$SET/create_dataitem_req"
    const val SET_CREATE_DATAITEM_RES = "$SET/create_dataitem_res"
    const val SET_DATAITEM_VALUE_REQ = "$SET/dataitem_value_req"
    const val SET_SHOW_ON_PHONE = "$SET/show_on_phone"
    const val SET_PHONE_AI_AGENT_SYNC = "$SET/phone_ai_agent_sync"

    // 显示
    const val SET_DISPLAY = "$SET/display"
    const val SET_DISPLAY_BRIGHTNESS = "$SET/display/brightness"
    const val SET_DISPLAY_BRIGHTNESS_MAX = "$SET/display/brightness_max_level"
    const val SET_DISPLAY_AOD = "$SET/display/always_on_display"
    const val SET_DISPLAY_AOD_DISABLED = "$SET/display/always_on_display/disabled"
    const val SET_DISPLAY_FONT_SIZE = "$SET/display/font_size"
    const val SET_DISPLAY_FONT_SIZE_MAX = "$SET/display/font_size_max"
    const val SET_DISPLAY_FONT_STYLE_LIST = "$SET/display/font_style/list"
    const val SET_DISPLAY_FONT_STYLE_SEL = "$SET/display/font_style/selected_item"
    const val SET_DISPLAY_SCREEN_TIMEOUT_LIST = "$SET/display/screen_time_out/list"
    const val SET_DISPLAY_SCREEN_TIMEOUT_SEL = "$SET/display/screen_time_out/selected_item"
    const val SET_DISPLAY_OUTDOOR_MODE = "$SET/display/outdoor_mode"
    const val SET_DISPLAY_TOUCH_SENSITIVITY = "$SET/display/touch_sensitivity"
    const val SET_DISPLAY_WAKE_WRIST = "$SET/display/wake_on_wrist_raised"
    const val SET_DISPLAY_WAKE_TOUCH = "$SET/display/wake_on_touch_screen"
    const val SET_DISPLAY_WAKE_BEZEL = "$SET/display/wake_on_turning_bezel"
    const val SET_DISPLAY_BOLD_FONT = "$SET/display/bold_font"
    const val SET_DISPLAY_AUTO_LOW_BRIGHTNESS = "$SET/display/auto_low_brightness"
    const val SET_DISPLAY_SHOW_CHARGING_INFO = "$SET/display/show_charging_info"

    // 声音
    const val SET_SOUND = "$SET/sound_settings"
    const val SET_SOUND_MODE = "$SET/sound_settings/sound_mode"
    const val SET_SOUND_VOL_RINGTONE = "$SET/sound_settings/volume/ringtone"
    const val SET_SOUND_VOL_MEDIA = "$SET/sound_settings/volume/media"
    const val SET_SOUND_VOL_NOTI = "$SET/sound_settings/volume/notifications"
    const val SET_SOUND_VOL_SYSTEM = "$SET/sound_settings/volume/system"
    const val SET_SOUND_VIB_INTENSITY = "$SET/sound_settings/vibration_intensity"
    const val SET_SOUND_VIB_INTENSITY_LIST = "$SET/sound_settings/vibration_intensity/list"
    const val SET_SOUND_VIB_TYPE = "$SET/sound_settings/vibration_type"
    const val SET_SOUND_VIB_TYPE_LIST = "$SET/sound_settings/vibration_type/list"
    const val SET_SOUND_VIB_WITH_SOUND = "$SET/sound_settings/vibration_with_sound"
    const val SET_SOUND_VIB_FEEDBACK = "$SET/sound_settings/vibration_feedback"
    const val SET_SOUND_RINGTONE_SEL = "$SET/sound_settings/ringtone/selected_item"
    const val SET_SOUND_RINGTONE_NAME = "$SET/sound_settings/ringtone/selected_name"
    const val SET_SOUND_NOTI_SOUND_LIST = "$SET/sound_settings/notification_sound/list"
    const val SET_SOUND_NOTI_SOUND_SEL = "$SET/sound_settings/notification_sound/selected_item"
    const val SET_SOUND_TOUCH = "$SET/sound_settings/system_sounds/touch_sound"
    const val SET_SOUND_CHARGING = "$SET/sound_settings/system_sounds/charging_sound"
    const val SET_SOUND_UNLOCK = "$SET/sound_settings/system_sounds/unlock_sound"

    // 电池/就寝
    const val SET_BEDTIME = "$SET/bedtime"
    const val SET_BEDTIME_ON_OFF = "$SET/bedtime/on_off"
    const val SET_BEDTIME_SCHEDULE = "$SET/bedtime/schedule_info"
    const val SET_BEDTIME_WATCH_SCHEDULE = "$SET/bedtime/watch_schedule_info"
    const val SET_BEDTIME_LIFESTYLE = "$SET/bedtime/lifestyle_info"

    // 高级
    const val SET_ADVANCED = "$SET/advanced"
    const val SET_ADV_ACTION_BUTTON_LIST = "$SET/advanced/action_button/list"
    const val SET_ADV_ACTION_BUTTON_SEL = "$SET/advanced/action_button/selected_item"
    const val SET_ADV_BIXBY = "$SET/advanced/bixby/enabled"
    const val SET_ADV_DOUBLE_PRESS_LIST = "$SET/advanced/double_press/list"
    const val SET_ADV_DOUBLE_PRESS_SEL = "$SET/advanced/double_press/selected_package"
    const val SET_ADV_PRESS_HOLD_LIST = "$SET/advanced/press_and_hold/list"
    const val SET_ADV_PRESS_HOLD_SEL = "$SET/advanced/press_and_hold/selected_item"
    const val SET_ADV_GESTURE_ANSWER = "$SET/advanced/gestures/answer_calls"
    const val SET_ADV_GESTURE_DISMISS = "$SET/advanced/gestures/dismiss_alerts_and_reject_calls"
    const val SET_ADV_THEATER_MODE = "$SET/advanced/theater_mode/enabled"
    const val SET_ADV_STATUS_INDICATOR_LIST = "$SET/advanced/status_indicator/list"
    const val SET_ADV_STATUS_INDICATOR_SEL = "$SET/advanced/status_indicator/selected_item"
    const val SET_ADV_DISCONNECTION_ALERT = "$SET/advanced/disconnection_alert/selected_item"

    // 通用
    const val SET_GENERAL = "$SET/general"
    const val SET_GENERAL_WRIST = "$SET/general/orientation/selected_wrist"
    const val SET_GENERAL_BUTTON_POS = "$SET/general/orientation/selected_button_position"
    const val SET_GENERAL_TOUCH_BEZEL = "$SET/general/touch_bezel"
    const val SET_GENERAL_TOUCH_BEZEL_FB = "$SET/general/touch_bezel_feedback"
    const val SET_GENERAL_QUICK_RESPONSES = "$SET/general/quick_responses/custom_responses"
    const val SET_GENERAL_SMART_REPLY = "$SET/general/quick_responses/smart_reply"
    const val SET_GENERAL_PHONE_SWITCH = "$SET/general/transfer_watch/phone_switching_available"
    const val SET_GENERAL_IS_PATTERN = "$SET/general/is_pattern"

    // 安全
    const val SET_SECURITY = "$SET/securitysetting"
    const val SET_SECURITY_WRIST_DETECTION = "$SET/securitysetting/wrist_detection"

    // Phone DND
    const val SET_PHONE_DND = "$SET/phone/dnd"
    const val SET_PHONE_DND_SYNC = "$SET/phone/dnd/sync_do_not_disturb"
    const val SET_PHONE_DND_TURN_ON = "$SET/phone/dnd/dnd_turn_on_now"
    const val SET_PHONE_DND_DURATION = "$SET/phone/dnd/duration"
    const val SET_PHONE_DND_POLICY = "$SET/phone/dnd/policy"

    // Battery & DeviceCare
    const val BATTERY_STATE_REQUEST = "/batterystate/rpc/batterystate_request"
    const val BATTERY_STATE_DATA = "/batterystate/data/batterystate"
    const val INDICATOR_BATTERY = "/indicator_battery"
    const val INDICATOR_BATTERY_RSP = "/indicator_battery/get_battery_status_data_rsp"
    const val INDICATOR_BATTERY_CHG = "/indicator_battery/battery_chg_ind"
    const val STF = "/w_stf"
    const val MSG_STF_BATTERY_RSP = "stf_battery_rsp"
    const val MSG_STOP_BATTERY_STATUS = "stop_battery_status_data"

    const val DEVICECARE_BATTERY = "/c_devicecare/battery/"
    const val DEVICECARE_BATTERY_BASE = "/c_devicecare/battery/base_info"
    const val DEVICECARE_BATTERY_CHANGE = "/c_devicecare/battery/change"
    const val DEVICECARE_BATTERY_REFRESH = "/c_devicecare/battery/refresh"
    const val DEVICECARE_BATTERY_PSM = "/c_devicecare/battery/psm"
    const val DEVICECARE_BATTERY_SETTING = "/c_devicecare/battery/setting"
    const val DEVICECARE_MEMORY = "/c_devicecare/memory/"
    const val DEVICECARE_MEMORY_CLEAN = "/c_devicecare/memory/clean"
    const val DEVICECARE_MEMORY_INFO = "/c_devicecare/memory/info"
    const val DEVICECARE_MEMORY_USAGE = "/c_devicecare/memory/usage"
    const val DEVICECARE_RAM_INFO = "/c_ram/requestRamInfo"

    const val DC_MAP_BATTERY_CHANGED = 200
    const val DC_MAP_BATTERY_USAGE = 202
    const val DC_MAP_BATTERY_ISSUE = 204
    const val DC_MAP_APP_RESTRICT = 205
    const val DC_MAP_BATTERY_SETTING = 206
    const val DC_MAP_BATTERY_BASE_INFO = 209
    const val DC_MAP_MEMORY_USAGE = 300

    // Find my watch / SOS
    const val FIND_MY_WATCH = "/w_apps_find_my_watch"
    const val FIND_MY_PHONE = "/w_apps_find_my_phone"
    const val SAFETY_ASSISTANCE = "/w_apps_safety_assistance"
    const val MSG_FMW_CURRENT_STATE_REQ = "fmw-currentstate-req"
    const val MSG_FMW_CURRENT_STATE_RSP = "fmw-currentstate-rsp"
    const val MSG_FMW_FIND_REQ = "fmw-find-req"
    const val MSG_FMW_START_ALERT_REQ = "fmw-startalert-req"
    const val MSG_FMW_START_ALERT_RSP = "fmw-startalert-rsp"
    const val MSG_FMW_STOP_ALERT_REQ = "fmw-stopalert-req"
    const val MSG_FMW_STOP_ALERT_RSP = "fmw-stopalert-rsp"
    const val MSG_FMW_FINISH_ALERT_REQ = "fmw-finishalert-req"
    const val MSG_FMW_FINISH_ALERT_RSP = "fmw-finishalert-rsp"
    const val MSG_FMW_FIND_RSP = "fmw-find-rsp"
    const val MSG_SOS_GET_SETTINGS_REQ = "sos-getsossettings-req"

    // Alarm, timer & calendar
    const val ALARM_C = "/c_alarm"
    const val ALARM_W = "/w_alarm"
    const val ALARM_CAPABILITY = "$ALARM_W/capability"
    const val ALARM_W_SET = "$ALARM_W/set"
    const val ALARM_W_DELETE = "$ALARM_W/delete"
    const val ALARM_W_SNOOZE = "$ALARM_W/snooze"
    const val ALARM_W_DISMISS = "$ALARM_W/dismiss"
    const val ALARM_COMMON = "$ALARM_C/item"
    const val TIMER_C = "/c_timer"
    const val TIMER_W = "/w_timer"
    const val CALENDAR_C = "/c_calendar"
    const val CALENDAR_W = "/w_calendar"
    const val WORLDCLOCK_C = "/c_worldclock"
    const val WORLDCLOCK_W = "/w_worldclock"

    // Contacts
    const val CONTACTS_MOBILE = "/contacts_mobile/"
    const val CONTACTS3 = "/contacts3"
    const val CONTACTS3_FULL_SYNC_REQ = "$CONTACTS3/contacts_full_sync_request"
    const val CONTACTS3_INFO = "$CONTACTS3/info"
    const val MSG_PUSH_UPDATE_KEY = "Push_Update_Key"

    // Media
    const val MEDIA_UPDATE = "/adaptive_media_bridging/rpc/media_update"
    const val MEDIA_WATCH_REQUEST = "/adaptive_media_bridging/rpc/watch_request"

    // Samsung Health
    const val HEALTH_MESSAGE = "/samsung_health/wearable_message"
    const val HEALTH_CAPABILITY = "/samsung_health/capability"
    const val HEALTH_REFRESH = "/samsung_health/refresh"
    const val HEALTH_VERIFY = "/samsung_health/verify"

    const val HEALTH_PHONE_SYNC = "com.samsung.android.app.shealth.wearable.syncmanager"
    const val HEALTH_WATCH_SYNC = "com.samsung.android.wear.shealth.wearable.syncmanager"
    const val HEALTH_PHONE_FRAMEWORK = "com.samsung.android.app.shealth.wearableframework"
    const val HEALTH_WATCH_FRAMEWORK = "com.samsung.wear.app.shealth.wearableframework"

    const val HEALTH_ACTION_REQUEST_DATA = "REQUEST_DATA"
    const val HEALTH_ACTION_SYNC_DATA = "SYNC_DATA"
    const val HEALTH_ACTION_LOG_DATA = "LOG_DATA"

    const val HEALTH_TYPE_DATA = "DATA"
    const val HEALTH_TYPE_MESSAGE = "MESSAGE"
    const val HEALTH_MSG_REQUEST = "REQUEST"
    const val HEALTH_MSG_RESPONSE = "RESPONSE"
    const val HEALTH_MSG_ERROR = "ERROR"

    // Firmware & eSIM
    const val FOTA = "/wfota"
    const val FOTA_STATUS_REQ = "/watch_ota_status/rpc/watch_ota_status_request"
    const val FOTA_STATUS_UPDATE = "/watch_ota_status/rpc/watch_ota_status_update"
    const val ESIM = "/watch_esim"
    const val SIM_MANAGER = "/w_simcardmanager"

    // OOBE
    const val SETUPWIZARD_OOBE = "/w_module_sec_setupwizard/oobe_setup"
    const val SYSTEMUI = "/w_module_sec_systemui/systemui"

    // Sender identities
    const val PKG_WEAR = "com.google.android.wearable.app"
    const val PKG_GMS = "com.google.android.gms"
    const val PKG_SHEALTH = "com.sec.android.app.shealth"
    const val SIGNATURE_SHEALTH = "9741a0f330dc2e8619b76a2597f308c37dbe30a2"

    const val FALLBACK_NODE = "00000000"
}
