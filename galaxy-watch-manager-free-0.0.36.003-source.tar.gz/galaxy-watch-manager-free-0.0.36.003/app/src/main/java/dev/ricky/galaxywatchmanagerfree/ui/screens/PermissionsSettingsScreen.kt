package dev.ricky.galaxywatchmanagerfree.ui.screens

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.core.OnboardingController
import dev.ricky.galaxywatchmanagerfree.core.UiNotify
import dev.ricky.galaxywatchmanagerfree.core.WatchController
import dev.ricky.galaxywatchmanagerfree.feature.AppPermission
import dev.ricky.galaxywatchmanagerfree.feature.KeepAliveHelper
import dev.ricky.galaxywatchmanagerfree.feature.LogBus
import dev.ricky.galaxywatchmanagerfree.ui.components.*
import dev.ricky.galaxywatchmanagerfree.ui.theme.*

@Composable
fun PermissionsSettingsScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val activity =
        remember(context) {
            generateSequence(context) { (it as? ContextWrapper)?.baseContext }
                .filterIsInstance<Activity>()
                .firstOrNull()
        }
    val entries = remember { AppPermission.applicable(Build.VERSION.SDK_INT) }
    fun readGrants() = entries.associateWith { it.isGranted(context) }
    var grants by remember { mutableStateOf(readGrants()) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner, context) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) grants = readGrants()
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }
    val request =
        rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            result ->
            grants = readGrants()
            val denied = result.filterValues { !it }.keys
            if (
                activity != null &&
                    denied.any {
                        !ActivityCompat.shouldShowRequestPermissionRationale(activity, it)
                    }
            ) {
                UiNotify.show(R.string.permissions_denied_settings)
                if (!KeepAliveHelper.openAppDetails(context))
                    UiNotify.show(R.string.handover_open_settings_failed)
            }
            if (
                result.keys.any {
                    it in AppPermission.NEARBY_DEVICES.runtimePermissions(Build.VERSION.SDK_INT)
                } &&
                    AppPermission.NEARBY_DEVICES.isGranted(context) &&
                    !OnboardingController.isVisible
            ) {
                WatchController.autoConnect(context, force = true)
            }
        }
    fun openSettings(permission: AppPermission) {
        if (permission == AppPermission.BATTERY_OPTIMIZATION) {
            if (!KeepAliveHelper.requestIgnoreBatteryOptimization(context)) {
                UiNotify.show(R.string.handover_open_settings_failed)
            }
            return
        }
        val intent =
            when (permission) {
                AppPermission.NOTIFICATION_ACCESS ->
                    Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                AppPermission.APP_NOTIFICATIONS ->
                    Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                        .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                AppPermission.INSTALL_PACKAGES ->
                    Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES)
                        .setData(Uri.parse("package:${context.packageName}"))
                else ->
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                        .setData(Uri.parse("package:${context.packageName}"))
            }.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            context.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            LogBus.error("无法打开权限设置", e)
            if (!KeepAliveHelper.openAppDetails(context))
                UiNotify.show(R.string.handover_open_settings_failed)
        } catch (e: SecurityException) {
            LogBus.error("系统拒绝打开权限设置", e)
            if (!KeepAliveHelper.openAppDetails(context))
                UiNotify.show(R.string.handover_open_settings_failed)
        }
    }
    LazyColumn(
        modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item {
            Text(
                stringResource(R.string.permissions_intro),
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
            )
        }
        entries.forEach { permission ->
            item(key = permission.name) {
                val granted = grants[permission] == true
                val (title, description) =
                    when (permission) {
                        AppPermission.NEARBY_DEVICES ->
                            R.string.permissions_nearby to R.string.permissions_nearby_desc
                        AppPermission.NOTIFICATION_ACCESS ->
                            R.string.notification_access to R.string.permissions_listener_desc
                        AppPermission.APP_NOTIFICATIONS ->
                            R.string.permissions_app_notifications to
                                R.string.permissions_app_notifications_desc
                        AppPermission.BATTERY_OPTIMIZATION ->
                            R.string.permissions_battery to R.string.permissions_battery_desc
                        AppPermission.INSTALL_PACKAGES ->
                            R.string.permissions_install to R.string.permissions_install_desc
                        AppPermission.LEGACY_STORAGE ->
                            R.string.permissions_storage to R.string.permissions_storage_desc
                    }
                GroupedCard(innerPadding = 0.dp) {
                    GroupedCardRow(
                        title = stringResource(title),
                        subtitle =
                            stringResource(
                                if (granted) R.string.granted else R.string.permissions_not_granted
                            ) + "\n" + stringResource(description),
                        icon = if (granted) Icons.Default.VerifiedUser else Icons.Default.Lock,
                        iconTint = if (granted) EmeraldCharging else TextSecondary,
                        showChevron = true,
                        onClick = {
                            val missing =
                                permission.runtimePermissions(Build.VERSION.SDK_INT).filter {
                                    ContextCompat.checkSelfPermission(context, it) !=
                                        PackageManager.PERMISSION_GRANTED
                                }
                            if (missing.isNotEmpty()) request.launch(missing.toTypedArray())
                            else openSettings(permission)
                        },
                    )
                }
            }
        }
        item {
            GroupedCard(innerPadding = 0.dp) {
                GroupedCardRow(
                    title = stringResource(R.string.open_autostart_settings),
                    subtitle = stringResource(R.string.permissions_background_hint),
                    showChevron = true,
                    onClick = {
                        if (!KeepAliveHelper.openAutoStartSettings(context))
                            UiNotify.show(R.string.handover_open_settings_failed)
                    },
                )
            }
        }
    }
}
