package dev.ricky.galaxywatchmanagerfree.core

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.annotation.MainThread
import androidx.core.content.FileProvider
import dev.ricky.galaxywatchmanagerfree.BuildConfig
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.feature.LogBus
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 应用内更新：从公开镜像下载 APK，校验摘要与签名后交给系统安装器。
 *
 * 不再只是跳转发布页：下载 → SHA-256 比对 → 签名证书与本机一致 → 调用安装器。 任何一步不通过都不会安装，只会把原因写进状态与诊断日志。
 */
object ApkUpdater {

    enum class Phase {
        IDLE,
        DOWNLOADING,
        VERIFYING,
        READY,
        AWAITING_INSTALL_PERMISSION,
        INSTALLING,
        ERROR,
    }

    data class State(
        val phase: Phase = Phase.IDLE,
        val progress: Float = 0f,
        val downloaded: Long = 0L,
        val total: Long = 0L,
        val versionName: String = "",
        val filePath: String? = null,
        val message: UiText? = null,
    ) {
        val busy: Boolean
            get() = phase == Phase.DOWNLOADING || phase == Phase.VERIFYING

        val installReady: Boolean
            get() =
                phase == Phase.READY ||
                    phase == Phase.AWAITING_INSTALL_PERMISSION ||
                    phase == Phase.INSTALLING

        val sizeText: String
            get() = ApkIntegrity.sizeText(if (total > 0L) total else downloaded)
    }

    private const val TIMEOUT_MS = 20_000
    private const val DIR = "updates"
    private const val MAX_APK_BYTES = 128L * 1024 * 1024

    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var downloadJob: Job? = null
    private var installJob: Job? = null
    private var cacheCleanup: Deferred<Unit>? = null
    private var downloadedRelease: AppUpdate.ReleaseInfo? = null

    @MainThread
    fun cancel() {
        downloadJob?.cancel()
        installJob?.cancel()
        discardReadyFile()
        downloadedRelease = null
        _state.value = State()
    }

    private fun discardReadyFile() {
        _state.value.filePath?.let { path -> scope.launch(Dispatchers.IO) { File(path).delete() } }
    }

    /** 下载并校验；成功后状态变成 [Phase.READY]，[autoInstall] 为真时直接拉起安装器。 */
    @MainThread
    fun download(context: Context, info: AppUpdate.ReleaseInfo, autoInstall: Boolean = true) {
        if (downloadJob?.isActive == true || installJob?.isActive == true) return
        val current = _state.value
        if (
            current.installReady &&
                downloadedRelease == info &&
                current.filePath?.let { File(it).exists() } == true
        ) {
            if (autoInstall) install(context)
            return
        }
        discardReadyFile()
        downloadedRelease = null
        val url = info.apkUrl
        if (url.isNullOrBlank()) {
            _state.value =
                State(
                    phase = Phase.ERROR,
                    versionName = info.versionName,
                    message = uiText(R.string.update_no_url),
                )
            return
        }
        if (!BuildConfig.DEBUG && !url.startsWith("https://")) {
            _state.value =
                State(
                    phase = Phase.ERROR,
                    versionName = info.versionName,
                    message = uiText(R.string.update_https_required),
                )
            return
        }
        if (
            info.apkSize !in 1..MAX_APK_BYTES ||
                ApkIntegrity.normalize(info.sha256) == null ||
                info.versionCode == null
        ) {
            _state.value =
                State(
                    phase = Phase.ERROR,
                    versionName = info.versionName,
                    message = uiText(R.string.update_invalid_metadata),
                )
            return
        }
        val app = context.applicationContext
        val mirror = UpdateChecker.mirror(app)
        val fetchUrl = DownloadMirror.rewrite(url, mirror)
        // Every download awaits the same startup cleanup before creating its own files.
        val cleanup =
            cacheCleanup
                ?: scope
                    .async(Dispatchers.IO) {
                        for (file in File(app.cacheDir, DIR).listFiles().orEmpty()) file.delete()
                    }
                    .also { cacheCleanup = it }
        _state.value =
            State(
                phase = Phase.DOWNLOADING,
                versionName = info.versionName,
                total = info.apkSize,
                message = uiText(R.string.update_downloading_version, info.versionName),
            )
        if (mirror != DownloadMirror.OFF) {
            LogBus.log("[更新] ${info.versionName} 经由镜像 ${mirror.id} 下载")
        }
        downloadJob =
            scope.launch {
                val file = File(File(app.cacheDir, DIR), "update-${UUID.randomUUID()}.apk")
                var verified = false
                try {
                    cleanup.await()
                    fetch(info, fetchUrl, file)
                    _state.value =
                        _state.value.copy(
                            phase = Phase.VERIFYING,
                            message = uiText(R.string.update_verifying),
                        )
                    verify(app, info, file)
                    downloadedRelease = info
                    _state.value =
                        _state.value.copy(
                            phase = Phase.READY,
                            progress = 1f,
                            downloaded = file.length(),
                            total = if (info.apkSize > 0L) info.apkSize else file.length(),
                            filePath = file.absolutePath,
                            message = uiText(R.string.update_ready_version, info.versionName),
                        )
                    LogBus.log(
                        "[更新] ${info.versionName} 下载完成 ${ApkIntegrity.sizeText(file.length())}，校验通过"
                    )
                    verified = true
                    if (autoInstall) install(app)
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (t: Exception) {
                    currentCoroutineContext().ensureActive()
                    LogBus.error("[更新] 下载失败", t)
                    _state.value =
                        _state.value.copy(
                            phase = Phase.ERROR,
                            message =
                                (t as? UserFacingException)?.reason
                                    ?: uiText(R.string.update_download_failed),
                        )
                } finally {
                    if (!verified) withContext(NonCancellable + Dispatchers.IO) { file.delete() }
                }
            }
    }

    private suspend fun fetch(info: AppUpdate.ReleaseInfo, url: String, target: File) =
        withContext(Dispatchers.IO) {
            currentCoroutineContext().ensureActive()
            target.parentFile!!.mkdirs()
            // Each attempt owns its files, including cleanup after a channel switch.
            val partial = File(target.parentFile, target.name + ".part")

            val conn =
                (URL(url).openConnection() as HttpURLConnection).apply {
                    instanceFollowRedirects = true
                    connectTimeout = TIMEOUT_MS
                    readTimeout = TIMEOUT_MS
                    setRequestProperty("Accept", "application/octet-stream")
                    setRequestProperty(
                        "User-Agent",
                        "GalaxyWatchManagerFree/${BuildConfig.VERSION_NAME}",
                    )
                    setRequestProperty("Cache-Control", "no-cache")
                }
            try {
                val code = conn.responseCode
                if (code !in 200..299)
                    throw UserFacingException(uiText(R.string.update_http_error, code))
                val total = conn.contentLengthLong.takeIf { it > 0L } ?: info.apkSize
                var copied = 0L
                var lastPercent = -1
                conn.inputStream.use { input ->
                    partial.outputStream().buffered().use { output ->
                        val buffer = ByteArray(64 * 1024)
                        while (true) {
                            currentCoroutineContext().ensureActive()
                            val read = input.read(buffer)
                            if (read <= 0) break
                            output.write(buffer, 0, read)
                            copied += read
                            requireUser(copied <= info.apkSize, uiText(R.string.update_too_large))
                            val percent = if (total > 0L) ((copied * 100) / total).toInt() else 0
                            if (percent != lastPercent) {
                                lastPercent = percent
                                withContext(Dispatchers.Main.immediate) {
                                    _state.value =
                                        _state.value.copy(
                                            phase = Phase.DOWNLOADING,
                                            downloaded = copied,
                                            total = total,
                                            progress =
                                                if (total > 0L)
                                                    (copied.toFloat() / total).coerceIn(0f, 1f)
                                                else 0f,
                                            message =
                                                uiText(
                                                    R.string.update_downloading_version,
                                                    info.versionName,
                                                ),
                                        )
                                }
                            }
                        }
                    }
                }
                if (copied <= 0L) throw UserFacingException(uiText(R.string.update_empty_download))
                if (info.apkSize > 0L && copied != info.apkSize) {
                    throw UserFacingException(
                        uiText(
                            R.string.update_incomplete,
                            ApkIntegrity.sizeText(copied),
                            ApkIntegrity.sizeText(info.apkSize),
                        )
                    )
                }
                if (!partial.renameTo(target)) {
                    partial.copyTo(target, overwrite = true)
                    partial.delete()
                }
                currentCoroutineContext().ensureActive()
            } finally {
                conn.disconnect()
                partial.delete()
            }
        }

    private suspend fun verify(context: Context, info: AppUpdate.ReleaseInfo, file: File) =
        withContext(Dispatchers.IO) {
            ApkValidation.verify(
                info,
                AndroidApkReader.read(context),
                AndroidApkReader.read(context, file.absolutePath),
                file.length(),
                ApkIntegrity.sha256(file.inputStream()),
            )
        }

    /** 是否已被允许安装未知来源应用。 */
    fun canInstall(context: Context): Boolean =
        runCatching { context.packageManager.canRequestPackageInstalls() }.getOrDefault(false)

    /** 跳到本应用的「安装未知应用」授权页。 */
    fun openInstallPermission(context: Context) {
        val intent =
            Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES)
                .setData(Uri.parse("package:" + context.packageName))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { context.startActivity(intent) }
            .onFailure { LogBus.error("[更新] 无法打开安装权限页", it) }
    }

    /** 调起系统安装器；调用前需已获得安装权限。 */
    @MainThread
    fun install(context: Context) {
        val snapshot = _state.value
        val release = downloadedRelease ?: return
        if (!snapshot.installReady || installJob?.isActive == true) return
        val app = context.applicationContext
        installJob =
            scope.launch {
                try {
                    val file =
                        snapshot.filePath?.let(::File)
                            ?: throw UserFacingException(uiText(R.string.update_missing_apk))
                    requireUser(file.isFile, uiText(R.string.update_missing_apk))
                    verify(app, release, file)
                    withContext(Dispatchers.Main) {
                        if (!canInstall(app)) {
                            _state.value =
                                _state.value.copy(
                                    phase = Phase.AWAITING_INSTALL_PERMISSION,
                                    message = uiText(R.string.update_install_permission),
                                )
                            openInstallPermission(app)
                        } else {
                            _state.value = _state.value.copy(phase = Phase.INSTALLING)
                            val uri =
                                FileProvider.getUriForFile(
                                    app,
                                    app.packageName + ".fileprovider",
                                    file,
                                )
                            val intent =
                                Intent(Intent.ACTION_VIEW).apply {
                                    setDataAndType(uri, "application/vnd.android.package-archive")
                                    addFlags(
                                        Intent.FLAG_GRANT_READ_URI_PERMISSION or
                                            Intent.FLAG_ACTIVITY_NEW_TASK
                                    )
                                }
                            app.startActivity(intent)
                            LogBus.log("[更新] 已调起系统安装器")
                        }
                    }
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (error: Exception) {
                    currentCoroutineContext().ensureActive()
                    _state.value =
                        _state.value.copy(
                            phase = Phase.ERROR,
                            message =
                                (error as? UserFacingException)?.reason
                                    ?: uiText(R.string.update_install_failed),
                        )
                    LogBus.error("[更新] 安装失败", error)
                }
            }
    }
}
