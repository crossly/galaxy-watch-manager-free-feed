package dev.ricky.galaxywatchmanagerfree.feature

import dev.ricky.galaxywatchmanagerfree.wcs.WcsPaths
import org.json.JSONObject

/**
 * Samsung Health 能力协商协议信令工厂与常量定义。
 *
 * 逆向自 Samsung Health Wear OS 客户端 (WearableDeviceCapability / AbstractC6878pY0 / C6614oX2 / A93)。
 * Wear OS 4/5 (Galaxy Watch6/7/Ultra) 在健康同步时强制执行 HealthNode 握手： 手表在收到 REQUEST_DATA 时若未就绪，会向手机下发
 * com.samsung.shealth.REQUEST_CAPABILITY； 手机必须响应 com.samsung.shealth.RESPONSE_CAPABILITY，手表接收后创建
 * HealthNode 并刷新同步队列。
 */
object HealthCapability {
    const val REQUEST_CAPABILITY = "com.samsung.shealth.REQUEST_CAPABILITY"
    const val RESPONSE_CAPABILITY = "com.samsung.shealth.RESPONSE_CAPABILITY"
    const val MESSAGE_TYPE_RESPONSE = "com.samsung.android.app.shealth.RESPONSE_CAPABILITY"
    const val PROTOCOL_VERSION = 4.51
    const val SHEALTH_VERSION = 6270000
    const val DEVICE_TYPE_PHONE = 10002

    fun isRequest(json: JSONObject): Boolean =
        json.optString("capability_type") == REQUEST_CAPABILITY

    fun isResponse(json: JSONObject): Boolean =
        json.optString("capability_type") == RESPONSE_CAPABILITY

    fun vascularLoadSupported(json: JSONObject): Boolean {
        if (json.optInt("category") != 40001) return false
        val feature =
            json.optJSONObject("tracker_feature")?.optJSONObject("vascular_load_feature")
                ?: return false
        return feature.optInt("version") >= 1000 && feature.optBoolean("vascular_load_support")
    }

    fun buildRequest(deviceId: String, modelName: String = "Android"): JSONObject =
        buildResponse(deviceId, modelName)
            .put("capability_type", REQUEST_CAPABILITY)
            .put("message_type", "com.samsung.android.app.shealth.REQUEST_CAPABILITY")

    fun buildResponse(deviceId: String, modelName: String = "Android"): JSONObject =
        JSONObject()
            .put("protocol_version", PROTOCOL_VERSION)
            .put("shealth_version", SHEALTH_VERSION)
            .put("message_type", MESSAGE_TYPE_RESPONSE)
            .put("capability_type", RESPONSE_CAPABILITY)
            .put("sender", "shealth")
            .put("receiver", "wearable")
            .put("model_name", modelName)
            .put("device_id", deviceId)
            .put("connection_id", deviceId)
            .put("device_type", DEVICE_TYPE_PHONE)
            .put(
                "tracker_feature",
                JSONObject()
                    .put(
                        "vascular_load_feature",
                        JSONObject().put("version", 1002).put("vascular_load_support", true),
                    ),
            )
            .put("binning", JSONObject().put("pedometer", 4).put("sleep", 10))
            .put(
                "protocol_feature",
                JSONObject()
                    .put("wearable_messaging", true)
                    .put("compression", true)
                    .put("sync_duration", 30)
                    .put("wm_chunk_size", 10000)
                    .put("blob_compression", true),
            )
            .put("compression", JSONObject().put("format", "gzip"))
            .put("sync_address", JSONObject().put("common_sync", WcsPaths.HEALTH_PHONE_SYNC))
            .put(
                "wearable_message",
                JSONObject()
                    .put("message_version", 5.03)
                    .put("message_support", true)
                    .put("message_compression", true)
                    .put("message_compression_format", "gzip")
                    .put("message_size", 10000),
            )
}
