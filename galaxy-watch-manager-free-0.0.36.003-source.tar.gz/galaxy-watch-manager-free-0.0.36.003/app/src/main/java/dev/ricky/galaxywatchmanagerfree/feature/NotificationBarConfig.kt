package dev.ricky.galaxywatchmanagerfree.feature

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** 用户自定义常驻通知栏展示的设备与健康指标配置。 */
data class NotificationBarConfig(
    val showBattery: Boolean = true,
    val showHeartRate: Boolean = true,
    val showSteps: Boolean = true,
    val showCalories: Boolean = false,
    val showSleep: Boolean = false,
    val showDistance: Boolean = false,
    val showStress: Boolean = false,
)

/** 常驻通知栏个性化设置的持久化控制器。 */
object NotificationBarPreferences {
    private const val PREFS = "watchfree_notification_bar"
    private const val KEY_BATTERY = "show_battery"
    private const val KEY_HEART_RATE = "show_heart_rate"
    private const val KEY_STEPS = "show_steps"
    private const val KEY_CALORIES = "show_calories"
    private const val KEY_SLEEP = "show_sleep"
    private const val KEY_DISTANCE = "show_distance"
    private const val KEY_STRESS = "show_stress"

    private var prefs: SharedPreferences? = null
    private val _config = MutableStateFlow(NotificationBarConfig())
    val config: StateFlow<NotificationBarConfig> = _config.asStateFlow()

    fun current(): NotificationBarConfig = _config.value

    fun init(context: Context) {
        if (prefs == null) {
            prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val p = prefs ?: return
            _config.value =
                NotificationBarConfig(
                    showBattery = p.getBoolean(KEY_BATTERY, true),
                    showHeartRate = p.getBoolean(KEY_HEART_RATE, true),
                    showSteps = p.getBoolean(KEY_STEPS, true),
                    showCalories = p.getBoolean(KEY_CALORIES, false),
                    showSleep = p.getBoolean(KEY_SLEEP, false),
                    showDistance = p.getBoolean(KEY_DISTANCE, false),
                    showStress = p.getBoolean(KEY_STRESS, false),
                )
        }
    }

    fun update(context: Context, newConfig: NotificationBarConfig) {
        init(context)
        prefs
            ?.edit()
            ?.putBoolean(KEY_BATTERY, newConfig.showBattery)
            ?.putBoolean(KEY_HEART_RATE, newConfig.showHeartRate)
            ?.putBoolean(KEY_STEPS, newConfig.showSteps)
            ?.putBoolean(KEY_CALORIES, newConfig.showCalories)
            ?.putBoolean(KEY_SLEEP, newConfig.showSleep)
            ?.putBoolean(KEY_DISTANCE, newConfig.showDistance)
            ?.putBoolean(KEY_STRESS, newConfig.showStress)
            ?.apply()
        _config.value = newConfig
    }
}
