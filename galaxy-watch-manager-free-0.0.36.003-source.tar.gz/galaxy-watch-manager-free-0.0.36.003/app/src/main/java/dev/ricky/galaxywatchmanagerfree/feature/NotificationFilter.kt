package dev.ricky.galaxywatchmanagerfree.feature

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class NotificationFilterMode {
    ALL,
    SELECTED,
}

data class NotificationFilterConfig(
    val mode: NotificationFilterMode = NotificationFilterMode.ALL,
    val packages: Set<String> = emptySet(),
) {
    fun allows(packageName: String): Boolean =
        mode == NotificationFilterMode.ALL || packageName in packages

    companion object {
        fun restore(
            savedMode: String?,
            packages: Set<String>,
            legacyPackages: Set<String> = emptySet(),
        ): NotificationFilterConfig =
            if (savedMode == null) {
                NotificationFilterConfig(
                    if (legacyPackages.isEmpty()) NotificationFilterMode.ALL
                    else NotificationFilterMode.SELECTED,
                    legacyPackages.toSet(),
                )
            } else {
                NotificationFilterConfig(
                    NotificationFilterMode.entries.firstOrNull { it.name == savedMode }
                        ?: NotificationFilterMode.SELECTED,
                    packages.toSet(),
                )
            }
    }
}

object NotificationFilterPreferences {
    private const val PREFS = "watchfree_notification_filter"
    private var prefs: SharedPreferences? = null
    private val _config = MutableStateFlow(NotificationFilterConfig())
    val config = _config.asStateFlow()
    private val _observedPackages = MutableStateFlow<Set<String>>(emptySet())
    val observedPackages = _observedPackages.asStateFlow()

    @Synchronized
    fun init(context: Context) {
        if (prefs != null) return
        val store = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val savedMode = store.getString("mode", null)
        val legacy =
            if (savedMode == null) {
                context
                    .getSharedPreferences("watchfree", Context.MODE_PRIVATE)
                    .getStringSet("allowed_packages", emptySet())
                    .orEmpty()
            } else emptySet()
        val restored =
            NotificationFilterConfig.restore(
                savedMode,
                store.getStringSet("packages", emptySet()).orEmpty(),
                legacy,
            )
        if (savedMode == null) {
            store
                .edit()
                .putString("mode", restored.mode.name)
                .putStringSet("packages", restored.packages)
                .apply()
        }
        _config.value = restored
        _observedPackages.value = store.getStringSet("observed", emptySet()).orEmpty().toSet()
        prefs = store
    }

    @Synchronized
    fun setMode(mode: NotificationFilterMode) {
        save(_config.value.copy(mode = mode))
    }

    @Synchronized
    fun setSelected(packageName: String, selected: Boolean) {
        val current = _config.value
        save(
            current.copy(
                packages =
                    if (selected) current.packages + packageName else current.packages - packageName
            )
        )
    }

    private fun save(config: NotificationFilterConfig) {
        val store = checkNotNull(prefs)
        store
            .edit()
            .putString("mode", config.mode.name)
            .putStringSet("packages", config.packages)
            .apply()
        _config.value = config
    }

    @Synchronized
    fun noteObserved(packageName: String) {
        val current = _observedPackages.value
        if (packageName in current || current.size >= 512) return
        val next = current + packageName
        checkNotNull(prefs).edit().putStringSet("observed", next).apply()
        _observedPackages.value = next
    }
}
