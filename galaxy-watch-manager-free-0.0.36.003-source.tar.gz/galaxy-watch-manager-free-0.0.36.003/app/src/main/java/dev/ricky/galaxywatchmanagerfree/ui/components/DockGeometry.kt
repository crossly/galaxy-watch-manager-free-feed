package dev.ricky.galaxywatchmanagerfree.ui.components

import kotlin.math.roundToInt

/** Coordinates include only the destinations' inner row, without the 4dp dock padding. */
internal data class DockGeometry(val pitch: Float, val count: Int, val rtl: Boolean = false) {
    init {
        require(pitch > 0f && count > 0)
    }

    fun positionAt(x: Float): Float {
        val logical = if (rtl) pitch * count - x else x
        return (logical / pitch - 0.5f).coerceIn(0f, (count - 1).toFloat())
    }

    fun indexAt(position: Float): Int = position.roundToInt().coerceIn(0, count - 1)

    fun releaseIndex(position: Float, velocity: Float, hovered: Int, dragging: Boolean): Int {
        if (!dragging) return hovered
        // FLClash projects a flick by 100ms, at most one destination beyond the finger.
        val lead = velocity / pitch * 0.1f * if (rtl) -1f else 1f
        return indexAt(position + lead)
            .coerceIn((hovered - 1).coerceAtLeast(0), (hovered + 1).coerceAtMost(count - 1))
    }
}
