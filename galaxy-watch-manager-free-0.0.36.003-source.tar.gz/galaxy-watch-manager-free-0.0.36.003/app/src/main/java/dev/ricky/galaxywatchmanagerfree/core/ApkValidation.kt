package dev.ricky.galaxywatchmanagerfree.core

import dev.ricky.galaxywatchmanagerfree.R

/** Installation policy, independent of Android's package/archive readers. */
object ApkValidation {
    data class PackageIdentity(
        val packageName: String,
        val versionCode: Long,
        val signers: Set<String>,
    )

    fun verify(
        release: AppUpdate.ReleaseInfo,
        installed: PackageIdentity,
        archive: PackageIdentity,
        byteCount: Long,
        sha256: String,
    ): PackageIdentity {
        requireUser(
            release.apkSize > 0 && byteCount == release.apkSize,
            uiText(R.string.apk_size_mismatch),
        )
        requireUser(
            ApkIntegrity.normalize(release.sha256) != null,
            uiText(R.string.apk_missing_checksum),
        )
        requireUser(
            ApkIntegrity.matches(release.sha256, sha256),
            uiText(R.string.apk_checksum_mismatch),
        )
        requireUser(
            archive.packageName == installed.packageName,
            uiText(R.string.apk_wrong_package),
        )
        requireUser(
            release.versionCode != null && archive.versionCode == release.versionCode.toLong(),
            uiText(R.string.apk_version_mismatch),
        )
        requireUser(
            archive.versionCode > installed.versionCode,
            uiText(R.string.apk_version_not_newer),
        )
        requireUser(installed.signers.isNotEmpty(), uiText(R.string.apk_installed_signer_missing))
        requireUser(archive.signers.isNotEmpty(), uiText(R.string.apk_archive_signer_missing))
        requireUser(archive.signers == installed.signers, uiText(R.string.apk_signer_mismatch))
        return archive
    }
}
