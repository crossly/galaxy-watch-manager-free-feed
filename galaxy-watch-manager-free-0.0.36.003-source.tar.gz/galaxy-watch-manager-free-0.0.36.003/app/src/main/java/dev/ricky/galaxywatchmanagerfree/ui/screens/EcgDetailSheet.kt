package dev.ricky.galaxywatchmanagerfree.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MonitorHeart
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.core.UiNotify
import dev.ricky.galaxywatchmanagerfree.feature.WatchRepository
import dev.ricky.galaxywatchmanagerfree.feature.WatchState
import dev.ricky.galaxywatchmanagerfree.feature.monitor.EcgRecord
import dev.ricky.galaxywatchmanagerfree.feature.monitor.HealthMonitorProtocol
import dev.ricky.galaxywatchmanagerfree.ui.components.GroupedCard
import dev.ricky.galaxywatchmanagerfree.ui.components.GroupedCardRow
import dev.ricky.galaxywatchmanagerfree.ui.components.GroupedDivider
import dev.ricky.galaxywatchmanagerfree.ui.components.MonitorRecordSheet
import dev.ricky.galaxywatchmanagerfree.ui.components.SectionHeader
import dev.ricky.galaxywatchmanagerfree.ui.components.formatMonitorRecordTime
import dev.ricky.galaxywatchmanagerfree.ui.theme.AlertCrimson
import dev.ricky.galaxywatchmanagerfree.ui.theme.EmeraldCharging
import dev.ricky.galaxywatchmanagerfree.ui.theme.HealthHeart
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextPrimary
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextSecondary
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextTertiary
import dev.ricky.galaxywatchmanagerfree.ui.theme.WarningAmber

@Composable
fun EcgDetailSheet(state: WatchState, repo: WatchRepository, onDismiss: () -> Unit) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources

    val records = state.ecgRecords
    val latest = records.firstOrNull()
    val todayRecords =
        records.filter {
            dev.ricky.galaxywatchmanagerfree.feature.monitor.MonitorDay.contains(
                it.startTime,
                java.time.LocalDate.now(),
                java.time.ZoneId.systemDefault(),
            )
        }
    val visibleRecords = todayRecords.ifEmpty { listOfNotNull(latest) }
    val history = records.filter { row -> visibleRecords.none { it.id == row.id } }
    var selectedId by rememberSaveable { mutableStateOf<String?>(null) }
    var showHelp by rememberSaveable { mutableStateOf(false) }
    val selected = records.firstOrNull { it.id == selectedId }
    val overviewScroll = rememberScrollState()

    fun triggerSync() =
        dev.ricky.galaxywatchmanagerfree.ui.components.requestMonitorSync(
            repo.monitor,
            HealthMonitorProtocol.Channel.ECG,
            state.sessionReady,
        )

    MonitorRecordSheet(
        title =
            if (selected == null) strings.getString(R.string.ecg_2)
            else strings.getString(R.string.ecg_details),
        onDismiss = onDismiss,
        onBack = if (selected != null) ({ selectedId = null }) else null,
        onSync = { triggerSync() },
        canSync = state.sessionReady,
        syncDescription = strings.getString(R.string.sync_ecg_records),
    ) {
        if (selected != null) {
            // Each record owns its scroll positions and waveform drawing cache.
            key(selected.id) {
                Column(
                    Modifier.weight(1f, fill = false)
                        .verticalScroll(rememberScrollState())
                        .padding(bottom = 32.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                ) {
                    EcgResultCard(selected)
                    dev.ricky.galaxywatchmanagerfree.ui.components.EcgWaveformCard(selected)
                }
            }
        } else {
            Column(
                Modifier.weight(1f, fill = false)
                    .verticalScroll(overviewScroll)
                    .padding(bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                if (latest != null) {
                    SectionHeader(
                        strings.getString(
                            if (todayRecords.isEmpty()) R.string.latest_measurement
                            else R.string.today_ecg
                        )
                    )
                    visibleRecords.forEach { record ->
                        key(record.id) {
                            EcgResultCard(record)
                            dev.ricky.galaxywatchmanagerfree.ui.components.EcgWaveformCard(record)
                        }
                    }
                } else {
                    GroupedCard(innerPadding = 18.dp) {
                        Icon(Icons.Default.MonitorHeart, null, tint = HealthHeart)
                        Spacer(Modifier.height(12.dp))
                        Text(
                            strings.getString(R.string.no_ecg_records),
                            style = androidx.compose.material3.MaterialTheme.typography.titleLarge,
                            color = TextPrimary,
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            strings.getString(R.string.ecg_empty_guidance),
                            style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                        )
                    }
                }

                SectionHeader(
                    strings.getQuantityString(
                        R.plurals.monitor_history_count,
                        history.size,
                        history.size,
                    )
                )
                if (history.isNotEmpty()) {
                    GroupedCard(innerPadding = 0.dp) {
                        history.forEachIndexed { index, record ->
                            if (index > 0) GroupedDivider()
                            GroupedCardRow(
                                title = strings.getString(record.classificationRes),
                                subtitle = formatMonitorRecordTime(record.startTime),
                                icon = Icons.Default.MonitorHeart,
                                iconTint = ecgClassificationColor(record),
                                showChevron = true,
                                onClick = { selectedId = record.id },
                                trailing = {
                                    Text(
                                        text = ecgHeartRate(record, strings),
                                        style =
                                            androidx.compose.material3.MaterialTheme.typography
                                                .bodyMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        color = TextPrimary,
                                    )
                                },
                            )
                        }
                    }
                } else {
                    Text(
                        strings.getString(R.string.no_earlier_measurements),
                        style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                        color = TextTertiary,
                    )
                }

                TextButton(onClick = { showHelp = !showHelp }) {
                    Text(
                        if (showHelp) strings.getString(R.string.hide_measurement_guide)
                        else strings.getString(R.string.measurement_guide_and_watch_setup)
                    )
                }
                if (showHelp) {
                    GroupedCard(innerPadding = 0.dp) {
                        GroupedCardRow(
                            title = strings.getString(R.string.how_to_measure),
                            subtitle =
                                strings.getString(
                                    R.string.rest_both_hands_on_a_table_touch_the_upper
                                ),
                            icon = Icons.Default.Info,
                            iconTint = EmeraldCharging,
                        )
                        GroupedDivider()
                        GroupedCardRow(
                            title = strings.getString(R.string.complete_ecg_setup),
                            subtitle =
                                strings.getString(
                                    R.string.use_only_if_the_watch_asks_you_to_complete
                                ),
                            icon = Icons.Default.Bolt,
                            iconTint = EmeraldCharging,
                            enabled = state.sessionReady,
                            onClick = {
                                val sent = repo.monitor.activateEcg()
                                UiNotify.show(
                                    if (sent)
                                        strings.getString(
                                            R.string.ecg_setup_requested_check_your_watch
                                        )
                                    else strings.getString(R.string.monitor_connecting_retry)
                                )
                            },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun EcgResultCard(record: EcgRecord) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources

    GroupedCard(innerPadding = 18.dp) {
        Text(
            strings.getString(R.string.watch_analysis),
            style = androidx.compose.material3.MaterialTheme.typography.labelMedium,
            color = TextTertiary,
        )
        Spacer(Modifier.height(6.dp))
        Text(
            strings.getString(record.classificationRes),
            style = androidx.compose.material3.MaterialTheme.typography.headlineSmall,
            lineHeight = 30.sp,
            fontWeight = FontWeight.Bold,
            color = ecgClassificationColor(record),
        )
        Spacer(Modifier.height(6.dp))
        Text(
            formatMonitorRecordTime(record.startTime),
            style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
            color = TextSecondary,
        )
        Spacer(Modifier.height(20.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Column(Modifier.weight(1f)) {
                Text(
                    strings.getString(R.string.average_heart_rate_2),
                    style = androidx.compose.material3.MaterialTheme.typography.labelMedium,
                    color = TextTertiary,
                )
                Text(
                    ecgHeartRate(record, strings),
                    style = androidx.compose.material3.MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = HealthHeart,
                )
            }
            Column(Modifier.weight(1f)) {
                Text(
                    strings.getString(R.string.recording_duration),
                    style = androidx.compose.material3.MaterialTheme.typography.labelMedium,
                    color = TextTertiary,
                )
                Text(
                    ecgDuration(record, strings),
                    style = androidx.compose.material3.MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimary,
                )
            }
        }
    }
}

@Composable
private fun ecgClassificationColor(record: EcgRecord): Color =
    when (record.classification) {
        1 -> EmeraldCharging
        2,
        12 -> AlertCrimson
        0,
        11 -> WarningAmber
        else -> TextSecondary
    }

private fun ecgHeartRate(record: EcgRecord, strings: android.content.res.Resources): String =
    if (record.heartRate > 0) "${record.heartRate} bpm"
    else strings.getString(R.string.not_received)

private fun ecgDuration(record: EcgRecord, strings: android.content.res.Resources): String =
    if (record.waveform.isNotEmpty() && record.sampleRate.isFinite() && record.sampleRate > 0) {
        strings
            .getString(R.string.duration_seconds_decimal)
            .format(record.waveform.size / record.sampleRate)
    } else strings.getString(R.string.not_received)
