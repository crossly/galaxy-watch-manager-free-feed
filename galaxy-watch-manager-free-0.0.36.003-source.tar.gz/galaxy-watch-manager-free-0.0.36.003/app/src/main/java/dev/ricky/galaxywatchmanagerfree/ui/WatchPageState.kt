package dev.ricky.galaxywatchmanagerfree.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.ricky.galaxywatchmanagerfree.feature.WatchState
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map

/** 根页面各自消费的状态域；页面只观察它实际渲染的字段。 */
enum class WatchPage {
    DASHBOARD,
    HEALTH,
    SETTINGS,
    WATCH_FACE,
}

@Immutable
data class RefreshActionState(
    val canRefresh: Boolean = false,
    val refreshInProgress: Boolean = false,
)

// New fields enter a page only when its projection explicitly includes them.
internal fun WatchPage.projection(state: WatchState): WatchState =
    when (this) {
        WatchPage.DASHBOARD ->
            WatchState(
                connected = state.connected,
                sessionReady = state.sessionReady,
                watchNode = state.watchNode,
                phoneNode = state.phoneNode,
                deviceName = state.deviceName,
                watchAlias = state.watchAlias,
                modelNumber = state.modelNumber,
                modelName = state.modelName,
                firmware = state.firmware,
                androidVersion = state.androidVersion,
                wearOs = state.wearOs,
                batteryLevel = state.batteryLevel,
                batteryCapacityMah = state.batteryCapacityMah,
                psmMode = state.psmMode,
                batteryStatus = state.batteryStatus,
                remainingNormalMin = state.remainingNormalMin,
                remainingPsmMin = state.remainingPsmMin,
                normalBatteryEstimateReceived = state.normalBatteryEstimateReceived,
                psmBatteryEstimateReceived = state.psmBatteryEstimateReceived,
                psmControlRestricted = state.psmControlRestricted,
                ramTotalMb = state.ramTotalMb,
                ramUsedMb = state.ramUsedMb,
                ramAvailableMb = state.ramAvailableMb,
                ramApps = state.ramApps,
                ramCleanableApps = state.ramCleanableApps,
                wearing = state.wearing,
                charging = state.charging,
                esimSupported = state.esimSupported,
                eid = state.eid,
                imei = state.imei,
                featureInfoReceived = state.featureInfoReceived,
                findWatch = state.findWatch,
                wakeOnWrist = state.wakeOnWrist,
                syncDnd = state.syncDnd,
                grayscaleEnabled = state.grayscaleEnabled,
                startupSyncing = state.startupSyncing,
                watchfaceRefreshing = state.watchfaceRefreshing,
                activeWatchfacePkg = state.activeWatchfacePkg,
                activeWatchfaceCls = state.activeWatchfaceCls,
                activeWatchfaceFavoriteId = state.activeWatchfaceFavoriteId,
                activeWatchfacePreviewPath = state.activeWatchfacePreviewPath,
            )
        WatchPage.HEALTH ->
            WatchState(
                connected = state.connected,
                sessionReady = state.sessionReady,
                healthSyncStatus = state.healthSyncStatus,
                lastHealthSyncTime = state.lastHealthSyncTime,
                todaySteps = state.todaySteps,
                stepGoal = state.stepGoal,
                stepGoalSource = state.stepGoalSource,
                todayCalories = state.todayCalories,
                todayDistanceMeters = state.todayDistanceMeters,
                todayHours = state.todayHours,
                streakDays = state.streakDays,
                weekSteps = state.weekSteps,
                dailyHistory = state.dailyHistory,
                todayFloors = state.todayFloors,
                sleep = state.sleep,
                sleepSessions = state.sleepSessions,
                allSleepSessions = state.allSleepSessions,
                sleepDays = state.sleepDays,
                sleepAnalysisRunning = state.sleepAnalysisRunning,
                weekSleep = state.weekSleep,
                lastHeartRate = state.lastHeartRate,
                latestHeartRate = state.latestHeartRate,
                lastHeartRateReportTime = state.lastHeartRateReportTime,
                heartRateHistory = state.heartRateHistory,
                heartRateDays = state.heartRateDays,
                heartRateWeek = state.heartRateWeek,
                lastStressScore = state.lastStressScore,
                latestStress = state.latestStress,
                stressHistory = state.stressHistory,
                stressDays = state.stressDays,
                metricSamples = state.metricSamples,
                exercises = state.exercises,
                ecgRecords = state.ecgRecords,
                bpRecords = state.bpRecords,
                vascularLoadSupported = state.vascularLoadSupported,
                vascularLoad = state.vascularLoad,
                monitorState = state.monitorState,
            )
        WatchPage.SETTINGS ->
            WatchState(
                connected = state.connected,
                sessionReady = state.sessionReady,
                deviceName = state.deviceName,
                watchAlias = state.watchAlias,
                modelNumber = state.modelNumber,
                modelName = state.modelName,
                startupSyncing = state.startupSyncing,
                activeWatchfacePkg = state.activeWatchfacePkg,
                activeWatchfaceCls = state.activeWatchfaceCls,
                activeWatchfacePreviewPath = state.activeWatchfacePreviewPath,
                vascularLoadSupported = state.vascularLoadSupported,
                settingItems = state.settingItems,
                brightness = state.brightness,
                aodEnabled = state.aodEnabled,
                wakeOnWrist = state.wakeOnWrist,
                outdoorMode = state.outdoorMode,
                screenTimeoutItem = state.screenTimeoutItem,
                wakeOnTouch = state.wakeOnTouch,
                wakeOnBezel = state.wakeOnBezel,
                touchSound = state.touchSound,
                chargingSound = state.chargingSound,
                gestureAnswer = state.gestureAnswer,
                gestureDismiss = state.gestureDismiss,
                quickLaunch = state.quickLaunch,
                wristRight = state.wristRight,
                negativeColors = state.negativeColors,
                removeAnimations = state.removeAnimations,
                grayscaleEnabled = state.grayscaleEnabled,
                highContrastFonts = state.highContrastFonts,
                muteAllSounds = state.muteAllSounds,
                syncDnd = state.syncDnd,
                psmMode = state.psmMode,
                psmControlRestricted = state.psmControlRestricted,
                batteryProtection = state.batteryProtection,
                lastSyncAt = maxOf(state.lastSyncAt, state.lastHealthSyncTime),
                autoRefresh = state.autoRefresh,
                autoQueryIntervalSeconds = state.autoQueryIntervalSeconds,
            )
        WatchPage.WATCH_FACE ->
            WatchState(
                sessionReady = state.sessionReady,
                activeWatchfacePkg = state.activeWatchfacePkg,
                activeWatchfaceCls = state.activeWatchfaceCls,
                activeWatchfaceFavoriteId = state.activeWatchfaceFavoriteId,
                activeWatchfacePreviewPath = state.activeWatchfacePreviewPath,
                watchfaceOrderType = state.watchfaceOrderType,
                watchfaceEditRequested = state.watchfaceEditRequested,
            )
    }

internal fun WatchState.refreshActionState(): RefreshActionState =
    RefreshActionState(canRefresh = canRefresh, refreshInProgress = refreshInProgress)

@Composable
fun WatchPageState(
    source: StateFlow<WatchState>,
    page: WatchPage,
    content: @Composable (WatchState) -> Unit,
) {
    key(source, page) {
        val projected =
            remember(source, page) { source.map { page.projection(it) }.distinctUntilChanged() }
        val initial = remember(source, page) { page.projection(source.value) }
        val state by projected.collectAsStateWithLifecycle(initialValue = initial)
        content(state)
    }
}

@Composable
fun RefreshAction(
    source: StateFlow<WatchState>,
    content: @Composable (RefreshActionState) -> Unit,
) {
    key(source) {
        val projected =
            remember(source) { source.map { it.refreshActionState() }.distinctUntilChanged() }
        val initial = remember(source) { source.value.refreshActionState() }
        val refresh by projected.collectAsStateWithLifecycle(initialValue = initial)
        content(refresh)
    }
}
