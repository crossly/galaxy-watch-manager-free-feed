package dev.ricky.galaxywatchmanagerfree.core

import dev.ricky.galaxywatchmanagerfree.wcs.CompanionProfile

/**
 * 从系统已配对设备里挑出手表。
 *
 * 纯逻辑，便于单元测试：名称匹配只是排序启发式，不能证明对端支持 WCS； 连接是否真的可用仍由后续握手决定。用户上次成功使用过的 MAC 始终优先。
 */
object WatchDiscovery {

    data class Candidate(val name: String?, val address: String)

    /** “像手表”评分；0 表示不是候选。 */
    fun score(name: String?): Int {
        val n = name?.trim()?.lowercase() ?: return 0
        return when {
            n.contains("galaxy watch") -> 100
            CompanionProfile.fromDeviceName(n) != null -> 90
            n.startsWith("sm-l") || n.contains(" sm-l") -> 90
            n.contains("watch") -> 70
            n.contains("gear") -> 40
            else -> 0
        }
    }

    /** 优先返回上次使用的设备（只要它仍在配对列表中），否则返回评分最高者。 评分相同的设备按地址排序，保证结果稳定可测。 */
    fun pick(bonded: List<Candidate>, savedMac: String?): Candidate? {
        val saved = savedMac?.trim()?.takeIf { it.isNotEmpty() }
        if (saved != null) {
            bonded
                .firstOrNull { it.address.equals(saved, ignoreCase = true) }
                ?.let {
                    return it
                }
        }
        return bonded
            .map { it to score(it.name) }
            .filter { it.second > 0 }
            .sortedWith(
                compareByDescending<Pair<Candidate, Int>> { it.second }.thenBy { it.first.address }
            )
            .firstOrNull()
            ?.first
    }
}
