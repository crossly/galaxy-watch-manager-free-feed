package dev.ricky.galaxywatchmanagerfree.feature

import android.content.Context
import dev.ricky.galaxywatchmanagerfree.wcs.WcsPaths
import java.io.ByteArrayOutputStream
import java.util.Base64
import java.util.concurrent.atomic.AtomicInteger
import java.util.zip.GZIPOutputStream
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

/**
 * Native Samsung Health measurement settings and explicit remote measurement.
 *
 * Preference writes keep the last received preference row intact and only change its `int_value`
 * and monotonic `update_time`. A write is never treated as confirmed from its outbound ACK: the
 * caller must request a fresh readback and the matching FROM_WATCH row must carry the same
 * identity, the desired value and a revision at or above the sent revision.
 */
class HealthMeasurements
internal constructor(
    private val store: MeasurementPreferenceStore,
    private val scope: CoroutineScope,
    private val watchNode: () -> String,
    private val send: (JSONObject) -> Boolean,
    private val requestReadback: () -> Unit,
    private val clock: () -> Long = System::currentTimeMillis,
    private val deviceModel: () -> String = { android.os.Build.MODEL ?: "Android" },
    private val confirmTimeoutMs: Long = CONFIRM_TIMEOUT_MS,
) {
    constructor(
        context: Context,
        peerAddress: String,
        scope: CoroutineScope,
        watchNode: () -> String,
        send: (JSONObject) -> Boolean,
        requestReadback: () -> Unit,
    ) : this(
        store = AndroidMeasurementPreferenceStore(context, peerAddress),
        scope = scope,
        watchNode = watchNode,
        send = send,
        requestReadback = requestReadback,
    )

    enum class Kind {
        SPO2,
        STRESS,
    }

    enum class ToggleStatus {
        UNKNOWN,
        CONFIRMED,
        PENDING,
        UNCONFIRMED,
        FAILED,
    }

    enum class RemoteStatus {
        QUEUED,
        ACCEPTED,
        SEND_FAILED,
    }

    data class Toggle(
        val enabled: Boolean? = null,
        val desired: Boolean? = null,
        val status: ToggleStatus = ToggleStatus.UNKNOWN,
        val canWrite: Boolean = false,
    )

    data class Remote(val kind: Kind?, val status: RemoteStatus, val atMillis: Long)

    data class State(
        val sleepOxygen: Toggle = Toggle(),
        val stressContinuous: Toggle = Toggle(),
        val vascularLoad: Toggle = Toggle(),
        val remote: Remote? = null,
    )

    private enum class Setting(
        val dataUuid: String,
        val serviceId: String,
        val onValue: Int,
        val offValue: Int,
    ) {
        SLEEP_OXYGEN("10-measure.period", "tracker.spo2", onValue = 0, offValue = 1),
        STRESS_CONTINUOUS("08-measure.period", "tracker.stress", onValue = 0, offValue = 1),
        LAB_VASCULAR_LOAD("72-lab.enable.vascular_load", "app.settings", onValue = 1, offValue = 0);

        fun valueFor(enabled: Boolean): Int = if (enabled) onValue else offValue

        fun enabledFor(value: Int?): Boolean? =
            when (value) {
                onValue -> true
                offValue -> false
                else -> null
            }
    }

    /** 一次写入的生命周期：已发送待 ACK → 已 ACK 待回读确认。 */
    private enum class PendingStage {
        WAITING_ACK,
        WAITING_READBACK,
    }

    private data class PendingWrite(
        val setting: Setting,
        val desired: Boolean,
        val sequence: Int,
        val revision: Long,
        val deviceUuid: String,
        var stage: PendingStage = PendingStage.WAITING_ACK,
        var job: Job? = null,
    )

    private data class RemotePending(val sequence: Int)

    private val sequence = AtomicInteger(SEQUENCE_START)
    private val pending = linkedMapOf<Int, PendingWrite>()
    private val baselines = mutableMapOf<Setting, JSONObject>()
    private val revisionFloor = mutableMapOf<Setting, Long>()
    private val toggles = Setting.entries.associateWith { Toggle() }.toMutableMap()
    private var appSettingsTemplate: JSONObject? = null

    private var remotePending: RemotePending? = null
    private var remoteState: Remote? = null
    private val mutableState = MutableStateFlow(State())

    val state: StateFlow<State> = mutableState.asStateFlow()

    init {
        restore()
    }

    @Synchronized
    fun exportSettings(): JSONObject {
        fun setting(setting: Setting, toggle: Toggle): JSONObject {
            val received = baselines[setting]
            return JSONObject()
                .put("enabled", toggle.enabled ?: JSONObject.NULL)
                .put("desired", toggle.desired ?: JSONObject.NULL)
                .put("status", toggle.status.name)
                .put("can_write", toggle.canWrite)
                .put("last_received_enabled", received?.value(setting) ?: JSONObject.NULL)
                .put(
                    "last_received_revision_epoch_ms",
                    received?.optLong("update_time", 0L) ?: JSONObject.NULL,
                )
                .put("pending_revision_epoch_ms", pendingFor(setting)?.revision ?: JSONObject.NULL)
        }
        val current = state.value
        return JSONObject()
            .put("sleep_oxygen", setting(Setting.SLEEP_OXYGEN, current.sleepOxygen))
            .put("stress_continuous", setting(Setting.STRESS_CONTINUOUS, current.stressContinuous))
            .put("vascular_load", setting(Setting.LAB_VASCULAR_LOAD, current.vascularLoad))
    }

    private fun restore() {
        appSettingsTemplate =
            store.readRow(APP_SETTINGS_TEMPLATE_KEY)?.takeIf { it.isAppSettingsRow() }
        Setting.entries.forEach { setting ->
            val row = store.readRow(setting.dataUuid)
            if (row != null && row.matches(setting)) {
                baselines[setting] = row
                val value = row.value(setting)
                toggles[setting] =
                    Toggle(
                        value,
                        status = if (value == null) ToggleStatus.UNKNOWN else ToggleStatus.CONFIRMED,
                    )
            }
            revisionFloor[setting] =
                maxOf(store.readRevision(setting.dataUuid), row?.optLong("update_time", 0L) ?: 0L)
        }
        publish()
    }

    /**
     * Receives the `com.samsung.shealth.preferences` chunk after a durable FROM_WATCH sync.
     *
     * A matching row updates the confirmed value only when no write is pending. While a write is
     * pending it is retained as the latest readback and can confirm the write only after the
     * matching ACK has been consumed.
     */
    @Synchronized
    fun receivePreferences(rows: List<JSONObject>) {
        var changed = false
        rows
            .filter { it.isAppSettingsRow() }
            .maxByOrNull { it.optLong("update_time", 0L) }
            ?.let { row ->
                if (
                    row.optLong("update_time", 0L) >=
                        (appSettingsTemplate?.optLong("update_time", 0L) ?: 0L)
                ) {
                    val copy = JSONObject(row.toString())
                    appSettingsTemplate = copy
                    store.writeRow(APP_SETTINGS_TEMPLATE_KEY, copy)
                    changed = true
                }
            }
        Setting.entries.forEach { setting ->
            val row = selectRow(setting, rows) ?: return@forEach
            val copy = JSONObject(row.toString())
            baselines[setting] = copy
            store.writeRow(setting.dataUuid, copy)
            revisionFloor[setting] =
                maxOf(revisionFloor[setting] ?: 0L, copy.optLong("update_time", 0L))

            val value = copy.value(setting)
            val current = toggles[setting] ?: Toggle()
            val pendingWrite = pendingFor(setting)
            if (pendingWrite == null) {
                toggles[setting] =
                    Toggle(
                        enabled = value,
                        status = if (value == null) ToggleStatus.UNKNOWN else ToggleStatus.CONFIRMED,
                    )
            } else {
                if (value != null && value != pendingWrite.desired) {
                    toggles[setting] = current.copy(enabled = value)
                }
                if (
                    pendingWrite.stage == PendingStage.WAITING_READBACK &&
                        value == pendingWrite.desired &&
                        copy.matches(pendingWrite)
                ) {
                    completeSuccess(pendingWrite)
                }
            }
            changed = true
        }
        if (changed) publish()
    }

    /** Consumes only RESPONSE envelopes addressed to one of this controller's requests. */
    @Synchronized
    fun handleMessage(json: JSONObject): Boolean {
        if (json.optString("message") != WcsPaths.HEALTH_MSG_RESPONSE) return false
        val receivedSequence = json.optInt("sequence_num", 0)
        if (receivedSequence <= 0) return false
        val sender = json.optString("sender")
        return when (json.optString("type")) {
            WcsPaths.HEALTH_TYPE_DATA -> handleDataResponse(json, receivedSequence, sender)
            WcsPaths.HEALTH_TYPE_MESSAGE -> handleRemoteResponse(json, receivedSequence, sender)
            else -> false
        }
    }

    @Synchronized
    fun setSleepOxygen(enabled: Boolean): Boolean = setValue(Setting.SLEEP_OXYGEN, enabled)

    @Synchronized
    fun setStressContinuous(enabled: Boolean): Boolean =
        setValue(Setting.STRESS_CONTINUOUS, enabled)

    @Synchronized
    fun setVascularLoad(enabled: Boolean): Boolean = setValue(Setting.LAB_VASCULAR_LOAD, enabled)

    @Synchronized
    fun openMeasurement(kind: Kind): Boolean {
        val scId =
            when (kind) {
                Kind.SPO2 -> "tracker.spo2"
                Kind.STRESS -> "tracker.stress"
            }
        val sender =
            when (kind) {
                Kind.SPO2 -> SENDER_SPO2
                Kind.STRESS -> SENDER_STRESS
            }
        val uri =
            "samsunghealth://shealth.samsung.com/wear/deepLink?sc_id=$scId&destination=measure"
        return sendRemote(kind, sender, uri)
    }

    @Synchronized
    fun openSettings(target: Kind? = null) {
        val sender =
            when (target) {
                Kind.SPO2 -> SENDER_SPO2
                Kind.STRESS -> SENDER_STRESS
                null -> SENDER_SHEALTH
            }
        val uri =
            if (target == Kind.STRESS) {
                "$SETTINGS_URI&target=stress"
            } else {
                SETTINGS_URI
            }
        sendRemote(null, sender, uri)
    }

    /** Stops pending confirmation jobs and clears transient status; confirmed rows stay stored. */
    @Synchronized
    fun close() {
        pending.values.forEach { it.job?.cancel() }
        pending.clear()
        remotePending = null
        remoteState = null
        Setting.entries.forEach { setting ->
            val current = toggles[setting] ?: Toggle()
            toggles[setting] =
                current.copy(
                    desired = null,
                    status =
                        if (current.enabled == null) ToggleStatus.UNKNOWN
                        else ToggleStatus.CONFIRMED,
                )
        }
        publish()
    }

    private fun setValue(setting: Setting, enabled: Boolean): Boolean {
        val baseline = baselines[setting] ?: newLabPreference(setting)
        if (baseline == null) {
            val current = toggles[setting] ?: Toggle()
            toggles[setting] = current.copy(desired = null, status = ToggleStatus.FAILED)
            publish()
            return false
        }
        pendingFor(setting)?.let { old ->
            pending.remove(old.sequence)
            old.job?.cancel()
        }

        val revision =
            maxOf(
                clock(),
                (revisionFloor[setting] ?: 0L) + 1,
                baseline.optLong("update_time", 0L) + 1,
            )
        val row =
            JSONObject(baseline.toString())
                .put("int_value", setting.valueFor(enabled))
                .put("update_time", revision)
        val requestSequence = nextSequence()
        val request =
            PendingWrite(
                setting = setting,
                desired = enabled,
                sequence = requestSequence,
                revision = revision,
                deviceUuid = baseline.optString("deviceuuid"),
            )
        pending[requestSequence] = request
        val current = toggles[setting] ?: Toggle()
        toggles[setting] = current.copy(desired = enabled, status = ToggleStatus.PENDING)
        publish()

        val sent =
            runCatching { send(buildPreferencePacket(row, requestSequence)) }.getOrDefault(false)
        if (!sent) {
            pending.remove(requestSequence)
            toggles[setting] =
                (toggles[setting] ?: current).copy(desired = null, status = ToggleStatus.FAILED)
            publish()
            return false
        }

        revisionFloor[setting] = revision
        store.writeRevision(setting.dataUuid, revision)
        request.job = scheduleTimeout(request)
        return true
    }

    private fun handleDataResponse(
        json: JSONObject,
        receivedSequence: Int,
        sender: String,
    ): Boolean {
        val request = pending[receivedSequence] ?: return false
        if (sender != WcsPaths.HEALTH_WATCH_SYNC) return false
        val accepted = resultOf(json).equals("SUCCESS", ignoreCase = true)
        if (!accepted) {
            completeFailure(request, ToggleStatus.UNCONFIRMED)
            return true
        }

        val wasWaitingAck = request.stage == PendingStage.WAITING_ACK
        request.stage = PendingStage.WAITING_READBACK
        request.job?.cancel()
        request.job = scheduleTimeout(request)
        if (wasWaitingAck) {
            runCatching { requestReadback() }
        }
        val latest = baselines[request.setting]
        if (
            latest != null &&
                latest.value(request.setting) == request.desired &&
                latest.matches(request)
        ) {
            completeSuccess(request)
        } else {
            publish()
        }
        return true
    }

    private fun handleRemoteResponse(
        json: JSONObject,
        receivedSequence: Int,
        sender: String,
    ): Boolean {
        val request = remotePending ?: return false
        if (request.sequence != receivedSequence || sender != REMOTE_RECEIVER) return false
        remotePending = null
        remoteState =
            remoteState?.copy(
                status =
                    if (resultOf(json).let { it.isNotEmpty() && !it.equals("SUCCESS", true) }) {
                        RemoteStatus.SEND_FAILED
                    } else {
                        // 回执只证明手表收到请求，不代表已经开始或完成测量。
                        RemoteStatus.ACCEPTED
                    }
            )
        publish()
        return true
    }

    /** 健康响应统一是 `{message_info:[{result}]}`；没有该字段时无法判定失败。 */
    private fun resultOf(json: JSONObject): String =
        runCatching { parseResult(json.optString("body")) }.getOrNull().orEmpty()

    private fun sendRemote(kind: Kind?, sender: String, uri: String): Boolean {
        remotePending = null
        val requestSequence = nextSequence()
        remotePending = RemotePending(requestSequence)
        remoteState = Remote(kind, RemoteStatus.QUEUED, clock())
        publish()
        val sent =
            runCatching { send(buildRemotePacket(sender, uri, requestSequence)) }
                .getOrDefault(false)
        if (!sent) {
            if (remotePending?.sequence == requestSequence) remotePending = null
            remoteState = Remote(kind, RemoteStatus.SEND_FAILED, clock())
            publish()
            return false
        }
        return true
    }

    private fun completeSuccess(request: PendingWrite) {
        pending.remove(request.sequence)
        request.job?.cancel()
        val current = toggles[request.setting] ?: Toggle()
        toggles[request.setting] =
            current.copy(enabled = request.desired, desired = null, status = ToggleStatus.CONFIRMED)
        publish()
    }

    private fun completeFailure(request: PendingWrite, status: ToggleStatus) {
        pending.remove(request.sequence)
        request.job?.cancel()
        val current = toggles[request.setting] ?: Toggle()
        toggles[request.setting] =
            current.copy(
                desired = if (status == ToggleStatus.UNCONFIRMED) request.desired else null,
                status = status,
            )
        publish()
    }

    private fun scheduleTimeout(request: PendingWrite): Job =
        scope.launch {
            delay(confirmTimeoutMs)
            synchronized(this@HealthMeasurements) {
                if (pending[request.sequence] !== request) return@launch
                completeFailure(request, ToggleStatus.UNCONFIRMED)
            }
        }

    private fun pendingFor(setting: Setting): PendingWrite? =
        pending.values.firstOrNull { it.setting == setting }

    private fun selectRow(setting: Setting, rows: List<JSONObject>): JSONObject? {
        val knownDevice = baselines[setting]?.optString("deviceuuid").orEmpty()
        return rows
            .asSequence()
            .filter { it.matches(setting) }
            .maxWithOrNull(
                compareBy<JSONObject> {
                        if (knownDevice.isNotBlank() && it.optString("deviceuuid") == knownDevice) 1
                        else 0
                    }
                    .thenBy { it.optLong("update_time", 0L) }
            )
    }

    private fun buildPreferencePacket(row: JSONObject, requestSequence: Int): JSONObject {
        val messageInfo = JSONObject().put("action", WcsPaths.HEALTH_ACTION_SYNC_DATA)
        val deviceInfo =
            JSONObject()
                .put("device", deviceModel())
                .put("device_type", DEVICE_TYPE)
                .put("version", DEVICE_VERSION)
                .put("last_sync_time", clock())
        val payload =
            JSONArray()
                .put(JSONObject().put("message_info", JSONArray().put(messageInfo)))
                .put(JSONObject().put("device_info", JSONArray().put(deviceInfo)))
                .put(JSONObject().put("com.samsung.shealth.preferences", JSONArray().put(row)))
        return JSONObject()
            .put("message", WcsPaths.HEALTH_MSG_REQUEST)
            .put("type", WcsPaths.HEALTH_TYPE_DATA)
            .put("sender", WcsPaths.HEALTH_PHONE_SYNC)
            .put("receiver", WcsPaths.HEALTH_WATCH_SYNC)
            .put("version", VERSION)
            .put("sequence_num", requestSequence)
            .put("source_node", WcsPaths.PKG_SHEALTH)
            .put("destination_node", watchNode())
            .put("body", encodeHealthBody(payload.toString()))
    }

    private fun buildRemotePacket(sender: String, uri: String, requestSequence: Int): JSONObject {
        val body = JSONObject().put("action", "android.intent.action.VIEW").put("deepLinkUri", uri)
        return JSONObject()
            .put("message", WcsPaths.HEALTH_MSG_REQUEST)
            .put("type", WcsPaths.HEALTH_TYPE_MESSAGE)
            .put("sender", sender)
            .put("receiver", REMOTE_RECEIVER)
            .put("version", VERSION)
            .put("sequence_num", requestSequence)
            .put("source_node", WcsPaths.PKG_SHEALTH)
            .put("destination_node", watchNode())
            .put("body", body.toString())
    }

    private fun parseResult(body: String): String? {
        if (body.isBlank()) return null
        val entries = HealthJson.entries(body)
        for (index in 0 until entries.length()) {
            val entry = entries.optJSONObject(index) ?: continue
            val info = entry.optJSONArray("message_info")?.optJSONObject(0) ?: continue
            return info.optString("result").ifBlank { null }
        }
        return null
    }

    private fun nextSequence(): Int =
        sequence.getAndUpdate { if (it >= SEQUENCE_END) SEQUENCE_START else it + 1 }

    private fun publish() {
        mutableState.value =
            State(
                sleepOxygen =
                    (toggles[Setting.SLEEP_OXYGEN] ?: Toggle()).copy(
                        canWrite = baselines.containsKey(Setting.SLEEP_OXYGEN)
                    ),
                stressContinuous =
                    (toggles[Setting.STRESS_CONTINUOUS] ?: Toggle()).copy(
                        canWrite = baselines.containsKey(Setting.STRESS_CONTINUOUS)
                    ),
                vascularLoad =
                    (toggles[Setting.LAB_VASCULAR_LOAD] ?: Toggle()).copy(
                        canWrite =
                            baselines.containsKey(Setting.LAB_VASCULAR_LOAD) ||
                                appSettingsTemplate != null
                    ),
                remote = remoteState,
            )
    }

    private fun newLabPreference(setting: Setting): JSONObject? {
        if (setting != Setting.LAB_VASCULAR_LOAD) return null
        val template = appSettingsTemplate ?: return null
        return JSONObject()
            .put("datauuid", setting.dataUuid)
            .put("service_id", setting.serviceId)
            .put("pkg_name", template.getString("pkg_name"))
            .put("deviceuuid", template.getString("deviceuuid"))
            .put("create_time", clock())
            .put("update_time", 0L)
    }

    private fun JSONObject.matches(setting: Setting): Boolean =
        optString("datauuid") == setting.dataUuid &&
            optString("service_id") == setting.serviceId &&
            hasPreferenceIdentity()

    private fun JSONObject.isAppSettingsRow(): Boolean =
        optString("service_id") == Setting.LAB_VASCULAR_LOAD.serviceId &&
            optString("datauuid").isNotBlank() &&
            hasPreferenceIdentity()

    private fun JSONObject.hasPreferenceIdentity(): Boolean =
        optString("pkg_name").isNotBlank() &&
            optString("deviceuuid").isNotBlank() &&
            has("create_time") &&
            !isNull("create_time") &&
            has("update_time") &&
            !isNull("update_time")

    private fun JSONObject.matches(request: PendingWrite): Boolean =
        optString("datauuid") == request.setting.dataUuid &&
            optString("service_id") == request.setting.serviceId &&
            optString("deviceuuid") == request.deviceUuid &&
            optLong("update_time", 0L) >= request.revision

    private fun JSONObject.value(setting: Setting): Boolean? {
        if (!has("int_value") || isNull("int_value")) return null
        return setting.enabledFor(optInt("int_value", Int.MIN_VALUE))
    }

    private fun encodeHealthBody(json: String): String {
        val output = ByteArrayOutputStream()
        GZIPOutputStream(output).use { it.write(json.toByteArray(Charsets.UTF_8)) }
        return Base64.getEncoder().encodeToString(output.toByteArray())
    }

    companion object {
        const val CONFIRM_TIMEOUT_MS = 60_000L

        private const val SEQUENCE_START = 1_000_000
        private const val SEQUENCE_END = 99_999_999
        private const val VERSION = 5.03
        private const val DEVICE_TYPE = 10062
        private const val DEVICE_VERSION = 4.51
        private const val APP_SETTINGS_TEMPLATE_KEY = "app.settings-template"
        private const val SENDER_SPO2 = "com.samsung.mobile.app.shealth.tracker.spo2"
        private const val SENDER_STRESS = "com.samsung.mobile.app.shealth.tracker.stress"
        private const val SENDER_SHEALTH = "com.samsung.mobile.app.shealth"
        private const val REMOTE_RECEIVER =
            "com.samsung.android.wear.shealth.message_handler.remote_deep_link"
        private const val SETTINGS_URI =
            "samsunghealth://shealth.samsung.com/wear/deepLink?sc_id=app.settings&destination=main"
    }
}

/** Persists the last complete preference row and the highest sent revision per target row. */
internal interface MeasurementPreferenceStore {
    fun readRow(dataUuid: String): JSONObject?

    fun writeRow(dataUuid: String, row: JSONObject)

    fun readRevision(dataUuid: String): Long

    fun writeRevision(dataUuid: String, revision: Long)
}

private class AndroidMeasurementPreferenceStore(context: Context, peerAddress: String) :
    MeasurementPreferenceStore {
    private val preferences =
        context.getSharedPreferences("health_measurements", Context.MODE_PRIVATE)
    private val prefix = peerAddress.takeIf { it.isNotBlank() }?.plus(":") ?: "unverified-session:"

    override fun readRow(dataUuid: String): JSONObject? =
        preferences.getString(prefix + "row:" + dataUuid, null)?.let {
            runCatching { JSONObject(it) }.getOrNull()
        }

    override fun writeRow(dataUuid: String, row: JSONObject) {
        if (prefix == "unverified-session:") return
        preferences.edit().putString(prefix + "row:" + dataUuid, row.toString()).commit()
    }

    override fun readRevision(dataUuid: String): Long =
        preferences.getLong(prefix + "revision:" + dataUuid, 0L)

    override fun writeRevision(dataUuid: String, revision: Long) {
        if (prefix == "unverified-session:") return
        preferences.edit().putLong(prefix + "revision:" + dataUuid, revision).commit()
    }
}
