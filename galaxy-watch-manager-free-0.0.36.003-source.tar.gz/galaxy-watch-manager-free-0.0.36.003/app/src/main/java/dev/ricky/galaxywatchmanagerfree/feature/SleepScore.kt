package dev.ricky.galaxywatchmanagerfree.feature

import kotlin.math.exp
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt

object SleepScore {
    const val SOURCE = "computed_shealth_1_4_24"

    enum class Factor(val weight: Int) {
        TOTAL_SLEEP_TIME(34),
        RESTFULNESS(6),
        PHYSICAL_RECOVERY(18),
        MENTAL_RECOVERY(26),
        SLEEP_LATENCY(16),
    }

    data class FactorScore(val factor: Factor, val score: Int, val contribution: Int)

    data class Result(
        val total: Int,
        val factors: List<FactorScore>,
        val totalSleepMinutes: Int,
        val deepMinutes: Int,
        val remMinutes: Int,
        val awakeMinutes: Int,
        val inBedMinutes: Int,
        val latencyMinutes: Int,
    )

    fun analyze(session: SleepParser.Session): Result? {
        if (session.segments.isEmpty() || session.endMillis <= session.startMillis) return null
        var cursor = session.startMillis
        var latency = 0f
        var deep = 0f
        var rem = 0f
        var light = 0f
        var awake = 0f
        var wakeRun = 0f
        var longWake = 0f
        var sleepStarted = false
        session.segments.forEach { segment ->
            if (
                segment.startMillis != cursor ||
                    segment.endMillis <= cursor ||
                    segment.endMillis > session.endMillis ||
                    segment.durationMillis % 30_000L != 0L
            )
                return null
            cursor = segment.endMillis
            val minutes = segment.durationMillis / 60_000f
            if (!sleepStarted && segment.stage == SleepParser.Stage.AWAKE) {
                latency += minutes
            } else {
                sleepStarted = true
                if (segment.stage == SleepParser.Stage.AWAKE) {
                    awake += minutes
                    wakeRun += minutes
                } else {
                    if (wakeRun >= 3f) longWake += wakeRun
                    wakeRun = 0f
                    when (segment.stage) {
                        SleepParser.Stage.DEEP -> deep += minutes
                        SleepParser.Stage.REM -> rem += minutes
                        SleepParser.Stage.LIGHT -> light += minutes
                        SleepParser.Stage.AWAKE -> Unit
                    }
                }
            }
        }
        if (cursor != session.endMillis) return null
        val asleep = deep + rem + light
        if (asleep <= 0f) return null
        val afterOnset = deep + awake + rem + light
        val efficiency = asleep / (afterOnset + latency) * 100f
        // The native long-WASO accumulator only flushes on a subsequent non-wake epoch.
        val wakeScore =
            (wakeScore(awake / afterOnset * 100f) + wakeScore(longWake / afterOnset * 100f)) / 2f
        val factors =
            listOf(
                factor(Factor.TOTAL_SLEEP_TIME, totalSleepScore(asleep, efficiency)),
                factor(Factor.RESTFULNESS, wakeScore),
                factor(Factor.PHYSICAL_RECOVERY, deepScore(deep / asleep * 100f, efficiency)),
                factor(Factor.MENTAL_RECOVERY, remScore(rem / asleep * 100f, efficiency)),
                factor(Factor.SLEEP_LATENCY, if (latency == 0f) 100f else latencyScore(latency)),
            )
        return Result(
            factors.sumOf { it.contribution }.coerceIn(1, 99),
            factors,
            asleep.toInt(),
            deep.toInt(),
            rem.toInt(),
            awake.toInt(),
            (afterOnset + latency).toInt(),
            latency.toInt(),
        )
    }

    private fun factor(factor: Factor, score: Float): FactorScore =
        FactorScore(
            factor,
            score.roundToInt().coerceIn(0, 100),
            (score * (factor.weight / 100f)).toInt(),
        )

    private fun sigmoid(value: Float, scale: Float, center: Float): Float =
        1f / (exp((-(value - center) / scale).toDouble()).toFloat() + 1f)

    private fun totalSleepScore(minutes: Float, efficiency: Float): Float {
        val curve =
            when {
                minutes < 420f -> (sigmoid(minutes, 45f, 340f) + 0.06f) / 0.912652f
                minutes <= 540f -> 1f
                else -> {
                    val squared = (minutes - 480f).toDouble().pow(2.0).toFloat()
                    val gaussian =
                        2.71828f.toDouble().pow(((squared / 64800f) * -1f).toDouble()).toFloat()
                    (gaussian * 0.0022163468f) / 0.002093f
                }
            }
        return curve * efficiency
    }

    private fun deepScore(percent: Float, efficiency: Float): Float {
        val curve = min(sigmoid(percent, 1.8f, 5f), (1f - sigmoid(percent, 10f, 34f)) * 0.3f + 0.7f)
        return (min(curve, 0.94f) / 0.94f) * 100f * (efficiency / 100f)
    }

    private fun remScore(percent: Float, efficiency: Float): Float {
        val curve =
            min(sigmoid(percent, 4f, 11.3f), (1f - sigmoid(percent, 15f, 58.5f)) * 0.77f + 0.23f)
        return (min(curve, 0.9f) / 0.9f) * 100f * (efficiency / 100f)
    }

    private fun wakeScore(percent: Float): Float =
        (min(1f - sigmoid(percent, 8f, 20f), 0.7773f) / 0.7773f) * 100f

    private fun latencyScore(minutes: Float): Float {
        val curve = min(sigmoid(minutes, 2f, 0f) - 0.425f, 1f - sigmoid(minutes, 30f, 30f))
        return min(curve, 0.5f) / 0.5f * 100f
    }
}
