package dev.ricky.galaxywatchmanagerfree

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import dev.ricky.galaxywatchmanagerfree.core.OnboardingController
import dev.ricky.galaxywatchmanagerfree.core.UpdateChecker
import dev.ricky.galaxywatchmanagerfree.core.WatchController
import dev.ricky.galaxywatchmanagerfree.ui.HomeScreen
import dev.ricky.galaxywatchmanagerfree.ui.onboarding.ConnectionOnboardingScreen
import dev.ricky.galaxywatchmanagerfree.ui.theme.ThemeController
import dev.ricky.galaxywatchmanagerfree.ui.theme.WatchFreeTheme
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private var updateTick: Job? = null

    private val requestPerms =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            // The visible guide owns the connection sequence, including permission recovery.
            if (!OnboardingController.isVisible) WatchController.autoConnect(this, force = true)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        // 沉浸式：内容延伸到状态栏与导航栏后方，由各页面自行处理 insets
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        ThemeController.init(this)
        dev.ricky.galaxywatchmanagerfree.feature.NotificationBarPreferences.init(this)
        OnboardingController.initialize(this)
        ensurePermissions()
        setContent {
            val appearance by ThemeController.mode.collectAsState()
            val darkTheme =
                when (appearance) {
                    ThemeController.MODE_LIGHT -> false
                    ThemeController.MODE_DARK -> true
                    else -> isSystemInDarkTheme()
                }
            WatchFreeTheme(darkTheme = darkTheme) {
                // 系统栏图标明暗跟随主题，保证状态栏时间/电量与导航手势条清晰可见
                LaunchedEffect(darkTheme) { applySystemBarAppearance(darkTheme) }
                val onboardingVisible by OnboardingController.visible.collectAsState()
                if (onboardingVisible) {
                    // First-run guide is a full-screen flow, not a card inside the settings page.
                    ConnectionOnboardingScreen(onClose = { OnboardingController.close() })
                } else {
                    HomeScreen()
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        // 回到前台时再尝试一次（例如用户手动打开蓝牙后）；引导显示期间不抢跑。
        if (!OnboardingController.isVisible) WatchController.autoConnect(this)
        UpdateChecker.maybeAutoCheck(this)
        // 前台期间定期复查；每次 tick 重新读取间隔偏好，修改后立即生效。
        updateTick?.cancel()
        updateTick =
            lifecycleScope.launch {
                while (isActive) {
                    delay(UPDATE_TICK_MS)
                    UpdateChecker.maybeAutoCheck(this@MainActivity)
                }
            }
    }

    override fun onStop() {
        updateTick?.cancel()
        updateTick = null
        super.onStop()
    }

    /** 让状态栏与导航栏的图标/文字颜色适配当前主题 */
    private fun applySystemBarAppearance(dark: Boolean) {
        runCatching {
            val controller = WindowCompat.getInsetsController(window, window.decorView)
            controller.isAppearanceLightStatusBars = !dark
            controller.isAppearanceLightNavigationBars = !dark
        }
    }

    private fun ensurePermissions() {
        val perms = buildList {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                add(Manifest.permission.BLUETOOTH_CONNECT)
                add(Manifest.permission.BLUETOOTH_SCAN)
            } else {
                add(Manifest.permission.BLUETOOTH)
                add(Manifest.permission.BLUETOOTH_ADMIN)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        val missing =
            perms.filter {
                checkSelfPermission(it) != android.content.pm.PackageManager.PERMISSION_GRANTED
            }
        if (missing.isNotEmpty()) {
            requestPerms.launch(missing.toTypedArray())
        }
    }

    private companion object {
        /** 前台复查节拍；是否真正发起检查仍由用户设定的小时周期决定。 */
        const val UPDATE_TICK_MS = 15 * 60_000L
    }
}
