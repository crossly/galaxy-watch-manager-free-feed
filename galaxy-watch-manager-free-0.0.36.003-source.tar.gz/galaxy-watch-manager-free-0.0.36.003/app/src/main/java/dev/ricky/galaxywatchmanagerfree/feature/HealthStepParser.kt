package dev.ricky.galaxywatchmanagerfree.feature

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import org.json.JSONObject

/** Parses day summary and incremental step intervals. */
object HealthStepParser {

    const val MODULE_DAY_SUMMARY = "com.samsung.shealth.tracker.pedometer_day_summary"
    const val MODULE_STEP_COUNT = "com.samsung.shealth.tracker.pedometer_step_count"

    private val BASIC_ISO_DATE = DateTimeFormatter.BASIC_ISO_DATE
    private const val EPOCH_MIN_MILLIS = 946_684_800_000L

    /** Parse local dates before timestamps so numeric `yyyyMMdd` never becomes epoch millis. */
    fun dateKey(value: String?, zone: ZoneId = ZoneId.systemDefault()): String? {
        val text = value?.trim().orEmpty()
        if (text.isEmpty()) return null
        runCatching { LocalDate.parse(text) }
            .getOrNull()
            ?.let {
                return it.toString()
            }
        runCatching { LocalDate.parse(text, BASIC_ISO_DATE) }
            .getOrNull()
            ?.let {
                return it.toString()
            }
        return text
            .toLongOrNull()
            ?.takeIf { it >= EPOCH_MIN_MILLIS }
            ?.let { Instant.ofEpochMilli(it).atZone(zone).toLocalDate().toString() }
    }

    private fun dateValue(record: JSONObject, name: String): String? {
        if (record.has(name) && !record.isNull(name)) return record.optString(name)
        return record
            .keys()
            .asSequence()
            .filter { it.endsWith(".$name") }
            .sorted()
            .firstOrNull { !record.isNull(it) && record.optString(it).isNotBlank() }
            ?.let(record::optString)
    }

    /** The owning day of a day summary comes from `day_time`, never a revision timestamp. */
    fun daySummaryDate(record: JSONObject, zone: ZoneId = ZoneId.systemDefault()): String? =
        dateKey(dateValue(record, "day_time"), zone)

    /** Latest measured count for each interval; updates are replacements, not new intervals. */
    data class StepContribution(val count: Int, val updatedAt: Long)

    fun encodeContributions(values: Map<String, StepContribution>): String =
        JSONObject()
            .apply {
                values.forEach { (id, value) ->
                    put(
                        id,
                        JSONObject().put("count", value.count).put("updated_at", value.updatedAt),
                    )
                }
            }
            .toString()

    fun decodeContributions(raw: String?): MutableMap<String, StepContribution> {
        val result = linkedMapOf<String, StepContribution>()
        if (raw.isNullOrBlank()) return result
        runCatching {
            val root = JSONObject(raw)
            root.keys().forEach { id ->
                root.optJSONObject(id)?.let { value ->
                    val count = value.optInt("count", -1)
                    if (count >= 0)
                        result[id] = StepContribution(count, value.optLong("updated_at"))
                }
            }
        }
        return result
    }

    data class StepAccumulation(val total: Int, val added: Int, val acceptedRecords: Int)

    /** 时间戳是否与 [nowMillis] 属于同一个本地自然日；0 表示未知，按今日处理 */
    fun isSameLocalDay(ts: Long, nowMillis: Long, zone: ZoneId = ZoneId.systemDefault()): Boolean {
        if (ts <= 0L) return true
        return runCatching {
                val day = Instant.ofEpochMilli(ts).atZone(zone).toLocalDate()
                val today = Instant.ofEpochMilli(nowMillis).atZone(zone).toLocalDate()
                day == today
            }
            .getOrDefault(true)
    }

    /** 兼容短名 / 长名 / create_time 兜底的更新时间 */
    fun recordUpdateTime(o: JSONObject): Long =
        o.optLong(
            "update_time",
            o.optLong(
                "com.samsung.health.step_count.update_time",
                o.optLong("create_time", o.optLong("com.samsung.health.step_count.create_time", 0L)),
            ),
        )

    /** 区间记录去重标识：优先 datauuid，缺失时退回 start/end/update 时间三元组 */
    fun recordIdentity(o: JSONObject): String {
        val uuid =
            o.optString("datauuid").ifBlank {
                o.optString("com.samsung.health.step_count.datauuid")
            }
        if (uuid.isNotBlank()) return uuid
        val start =
            o.optLong("start_time", o.optLong("com.samsung.health.step_count.start_time", 0L))
        val end = o.optLong("end_time", o.optLong("com.samsung.health.step_count.end_time", start))
        return "t_${start}_${end}_${recordUpdateTime(o)}"
    }

    /** 单条区间记录的新增步数 */
    fun recordSteps(o: JSONObject): Int {
        val count = o.optInt("count", o.optInt("com.samsung.health.step_count.count", -1))
        if (count > 0) return count
        val run = o.optInt("run_step", o.optInt("com.samsung.health.step_count.run_step", 0))
        val walk = o.optInt("walk_step", o.optInt("com.samsung.health.step_count.walk_step", 0))
        return (run + walk).coerceAtLeast(0)
    }

    /**
     * 全天汇总记录里的当日总步数。 顺序：step_count → run_step_count + walk_step_count → binning_data 各 10 分钟桶求和。
     * 都取不到时返回 -1。
     */
    fun daySummarySteps(o: JSONObject): Int {
        val direct = o.optInt("step_count", -1)
        if (direct >= 0) return direct
        val run = o.optInt("run_step_count", 0)
        val walk = o.optInt("walk_step_count", 0)
        if (run + walk > 0) return run + walk
        val binning = o.optJSONArray("binning_data")
        if (binning != null) {
            var sum = 0
            for (i in 0 until binning.length()) {
                sum += binning.optJSONObject(i)?.optInt("steps", 0) ?: 0
            }
            if (sum > 0) return sum
        }
        return if (o.has("run_step_count") || o.has("walk_step_count")) 0 else -1
    }

    /** 计步所属日期取测量起点，不能把今天修订的历史记录当作今天的新步数。 */
    fun recordStartTime(o: JSONObject): Long =
        o.optLong(
            "start_time",
            o.optLong("com.samsung.health.step_count.start_time", recordUpdateTime(o)),
        )

    fun recordEndTime(o: JSONObject): Long =
        o.optLong(
            "end_time",
            o.optLong("com.samsung.health.step_count.end_time", recordUpdateTime(o)),
        )

    /** 全天汇总记录里挑出「今天的最新一条」 */
    fun latestDaySummary(
        records: List<JSONObject>,
        nowMillis: Long,
        zone: ZoneId = ZoneId.systemDefault(),
    ): JSONObject? {
        val today = Instant.ofEpochMilli(nowMillis).atZone(zone).toLocalDate().toString()
        return records
            .filter { daySummaryDate(it, zone) == today }
            .maxByOrNull {
                recordUpdateTime(it).takeIf { time -> time > 0 } ?: it.optLong("day_time")
            }
    }

    /**
     * 把一批区间记录累加进当日总量。
     *
     * @param current 当前已累计的当日步数
     * @param seen 已计入的记录身份集合（会被就地更新，调用方负责持久化）
     * @param contributions 每条记录上次计入的 count / update_time，必须跨批保留并持久化； null 仅兼容旧版 UUID 去重调用，不支持记录修订。
     * @param records 本批区间记录
     * @param nowMillis 当前时间，用于过滤「非今日」的历史补发记录
     */
    fun accumulate(
        current: Int,
        seen: MutableSet<String>,
        records: List<JSONObject>,
        nowMillis: Long,
        zone: ZoneId = ZoneId.systemDefault(),
        coveredThroughMillis: Long = 0L,
        contributions: MutableMap<String, StepContribution>? = null,
    ): StepAccumulation {
        var total = current
        var added = 0
        var accepted = 0
        records
            .sortedBy { recordUpdateTime(it) }
            .forEach { rec ->
                if (!isSameLocalDay(recordStartTime(rec), nowMillis, zone)) return@forEach
                val id = recordIdentity(rec)
                val count = recordSteps(rec)
                val updatedAt = recordUpdateTime(rec)
                val previous = contributions?.get(id)
                if (previous != null && updatedAt < previous.updatedAt) return@forEach
                val alreadySeen = !seen.add(id)
                if (contributions == null && alreadySeen) return@forEach
                contributions?.set(id, StepContribution(count, updatedAt))
                // Summary-covered intervals still need revision state, but no additional
                // contribution.
                if (coveredThroughMillis > 0 && recordEndTime(rec) <= coveredThroughMillis)
                    return@forEach
                // Adopt first replay as baseline for uncounted legacy records.
                val delta =
                    when {
                        previous != null -> count - previous.count
                        alreadySeen -> 0
                        else -> count
                    }
                if (!alreadySeen || delta != 0) accepted++
                added += delta
            }
        total += added
        return StepAccumulation(total = total, added = added, acceptedRecords = accepted)
    }

    data class StepBatch(val total: Int, val summaryThroughMillis: Long, val added: Int)

    /** 汇总与明细可以在同一批或不同批到达；用汇总更新时间隔开已覆盖的区间。 */
    fun mergeBatch(
        current: Int,
        seen: MutableSet<String>,
        records: List<JSONObject>,
        summary: JSONObject?,
        summaryThroughMillis: Long,
        nowMillis: Long,
        zone: ZoneId = ZoneId.systemDefault(),
        contributions: MutableMap<String, StepContribution>? = null,
    ): StepBatch {
        val summarySteps = summary?.let(::daySummarySteps) ?: -1
        val through =
            if (summarySteps >= 0) {
                maxOf(summaryThroughMillis, summary!!.optLong("update_time", nowMillis))
            } else summaryThroughMillis
        val result =
            accumulate(
                seedAccumulator(current, summarySteps),
                seen,
                records,
                nowMillis,
                zone,
                through,
                contributions,
            )
        return StepBatch(result.total, through, result.added)
    }

    /**
     * 用全天汇总值校准累加器。
     *
     * 汇总报文（day_summary）不一定每次同步都带，但区间增量一定持续下发。 若只用汇总去覆盖展示值而不校准累加器，那么「汇总到达之后走的步数」会被 展示值上限吞掉（例如汇总 612
     * → 再走 20 步仍显示 612）。 因此收到汇总时把累加器抬到汇总值，后续增量就能在此基础上继续累加。
     */
    fun seedAccumulator(accumulated: Int, daySummary: Int): Int =
        if (daySummary > accumulated) daySummary else accumulated

    /** 最终展示值：全天汇总与增量累计取较大者，且不低于已展示值（保证只增不减）。 全部无效时返回 -1。 */
    fun resolveSteps(daySummary: Int, accumulated: Int, displayed: Int): Int {
        val candidates = buildList {
            if (daySummary >= 0) add(daySummary)
            if (accumulated > 0) add(accumulated)
            if (displayed >= 0) add(displayed)
        }
        return candidates.maxOrNull() ?: -1
    }

    /** 去重集合上限保护，超出后丢弃最早的一批 */
    fun trimSeen(seen: LinkedHashSet<String>, keep: Int = 400, limit: Int = 500) {
        if (seen.size <= limit) return
        val it = seen.iterator()
        while (seen.size > keep && it.hasNext()) {
            it.next()
            it.remove()
        }
    }
}
