package dev.ricky.galaxywatchmanagerfree.feature

import android.content.Context
import com.google.android.gms.tasks.Tasks
import com.google.android.gms.wearable.NodeClient
import com.google.android.gms.wearable.Wearable
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/** Result of retrieving local Wear node identity. */
sealed class LocalNodeResult {
    data class Success(val nodeId: String, val displayName: String) : LocalNodeResult()

    data class Failure(val reason: String, val isTimeout: Boolean = false) : LocalNodeResult()
}

interface LocalNodeProvider {
    fun fetchLocalNode(timeoutMs: Long = 5000L, onResult: (LocalNodeResult) -> Unit)

    fun cancel()
}

/**
 * Retrieves the local phone's Wear OS node identity via Google Play Services Wearable NodeClient.
 *
 * Distinctly resolves:
 * - Local node (`nodeClient.localNode`): represents the host phone.
 * - Connected nodes (`nodeClient.connectedNodes`): represents remote watch devices. Under no
 *   circumstances does this class confuse connected remote nodes with the local phone node.
 */
class GmsLocalNodeProvider(
    private val context: Context,
    private val nodeClientProvider: (Context) -> NodeClient = { Wearable.getNodeClient(it) },
) : LocalNodeProvider {

    private val executor =
        Executors.newSingleThreadExecutor { r ->
            Thread(r, "local-node-provider").apply { isDaemon = true }
        }
    private val cancelled = AtomicBoolean(false)

    override fun fetchLocalNode(timeoutMs: Long, onResult: (LocalNodeResult) -> Unit) {
        cancelled.set(false)
        executor.execute {
            if (cancelled.get()) return@execute
            try {
                val client = nodeClientProvider(context.applicationContext)
                val node = Tasks.await(client.localNode, timeoutMs, TimeUnit.MILLISECONDS)
                if (cancelled.get()) return@execute
                if (node == null || node.id.isBlank()) {
                    onResult(
                        LocalNodeResult.Failure(
                            "Local node returned empty from Google Wear service"
                        )
                    )
                    return@execute
                }
                val rawId = node.id
                val normalized = DeviceIdentityStore.normalizeNode(rawId)
                if (!DeviceIdentityStore.isValidNode(normalized)) {
                    onResult(
                        LocalNodeResult.Failure(
                            "Local node ID '$rawId' normalized to '$normalized' is not 7-8 hex characters"
                        )
                    )
                    return@execute
                }
                onResult(LocalNodeResult.Success(normalized, node.displayName.orEmpty()))
            } catch (timeout: java.util.concurrent.TimeoutException) {
                if (!cancelled.get()) {
                    onResult(LocalNodeResult.Failure("获取本机节点超时（${timeoutMs}ms）", isTimeout = true))
                }
            } catch (e: Exception) {
                if (!cancelled.get()) {
                    onResult(
                        LocalNodeResult.Failure(
                            "${e.javaClass.simpleName}: ${e.message ?: "Unknown error"}"
                        )
                    )
                }
            }
        }
    }

    override fun cancel() {
        cancelled.set(true)
    }

    fun shutdown() {
        cancel()
        executor.shutdownNow()
    }
}
