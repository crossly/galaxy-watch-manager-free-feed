package dev.ricky.galaxywatchmanagerfree.feature

import dev.ricky.galaxywatchmanagerfree.R
import kotlin.math.roundToInt
import org.json.JSONArray
import org.json.JSONObject

/** Parses Samsung Health sleep sessions, stage intervals, and raw records. */
object SleepParser {

    const val MODULE_SLEEP = "com.samsung.shealth.sleep"
    const val MODULE_SLEEP_LEGACY = "com.samsung.health.sleep"
    const val MODULE_SLEEP_RAW = "com.samsung.shealth.sleep_raw_data"
    const val MODULE_SLEEP_COMBINED = "com.samsung.shealth.sleep_combined"
    const val MODULE_SLEEP_DATA = "com.samsung.shealth.sleep_data"
    const val MODULE_SLEEP_STAGE = "com.samsung.shealth.sleep_stage"
    const val MODULE_SLEEP_STAGE_LEGACY = "com.samsung.health.sleep_stage"

    const val CODE_AWAKE = 40001
    const val CODE_LIGHT = 40002
    const val CODE_DEEP = 40003
    const val CODE_REM = 40004
    const val CODE_LATENCY = 40005
    const val CODE_GAP = 40006

    /** 分期类型；顺序即图表自上而下的行序 */
    enum class Stage(@androidx.annotation.StringRes val labelRes: Int) {
        AWAKE(R.string.sleep_awake),
        REM(R.string.sleep_rem),
        LIGHT(R.string.sleep_light),
        DEEP(R.string.sleep_deep),
    }

    data class Segment(val startMillis: Long, val endMillis: Long, val stage: Stage) {
        val durationMillis: Long
            get() = (endMillis - startMillis).coerceAtLeast(0L)
    }

    data class Session(
        val startMillis: Long,
        val endMillis: Long,
        val segments: List<Segment>,
        /** 手表给出的睡眠效率（百分比 0–100），没有则为 null */
        val efficiency: Int?,
        /** 手表给出的睡眠评分（`quality`），没有则为 null */
        val score: Int?,
        /** Reported session duration when the watch has not supplied stage records. */
        val reportedSleepMinutes: Int? = null,
        val id: String = "",
        val analysisSource: String? = null,
        val recordedEndMillis: Long? = null,
    ) {
        val inBedMinutes: Int
            get() = ((endMillis - startMillis).coerceAtLeast(0L) / 60_000L).toInt()

        val stageMinutes: Map<Stage, Int>
            get() =
                segments
                    .groupBy { it.stage }
                    .mapValues { (_, list) -> (list.sumOf { it.durationMillis } / 60_000L).toInt() }

        val hasSleepDuration: Boolean
            get() = segments.isNotEmpty() || reportedSleepMinutes != null

        val displayMinutes: Int
            get() = if (hasSleepDuration) asleepMinutes else inBedMinutes

        val asleepMinutes: Int
            get() =
                if (segments.isEmpty()) reportedSleepMinutes ?: 0
                else
                    (segments.filter { it.stage != Stage.AWAKE }.sumOf { it.durationMillis } /
                            60_000L)
                        .toInt()

        /** 效率：优先用手表值，否则用「睡眠时长 / 卧床时长」推算 */
        val efficiencyPercent: Int?
            get() =
                when {
                    efficiency != null && efficiency in 1..100 -> efficiency
                    hasSleepDuration && inBedMinutes > 0 ->
                        ((asleepMinutes * 100.0) / inBedMinutes).roundToInt().coerceIn(0, 100)
                    else -> null
                }

        /** 本机计算评分（含因子分解）；无分期或整夜无有效睡眠时为 null */
        val computedScore: SleepScore.Result?
            get() = SleepScore.analyze(this)

        /** 展示评分：手表 quality 优先，其次本机计算值 */
        val displayScore: Int?
            get() = score?.takeIf { it > 0 } ?: computedScore?.total

        /** 展示评分来源：watch / 本机算法版本 / null */
        val displayScoreSource: String?
            get() =
                when {
                    score != null && score > 0 -> "watch"
                    computedScore != null -> SleepScore.SOURCE
                    else -> null
                }
    }

    fun stageOf(code: Int): Stage? =
        when (code) {
            CODE_AWAKE -> Stage.AWAKE
            CODE_REM -> Stage.REM
            CODE_LIGHT -> Stage.LIGHT
            CODE_DEEP -> Stage.DEEP
            else -> null
        }

    /** 将同一天多段睡眠（夜间与一个或多个小睡）的真实分期合并统计。 */
    fun combinedStageMinutes(sessions: Iterable<Session>): Map<Stage, Int> =
        sessions
            .flatMap { it.segments }
            .groupBy { it.stage }
            .mapValues { (_, list) -> (list.sumOf { it.durationMillis } / 60_000L).toInt() }

    private fun optLong(o: JSONObject, vararg keys: String): Long {
        keys.forEach { key -> if (o.has(key)) return o.optLong(key, 0L) }
        return 0L
    }

    private fun optIntOrNull(o: JSONObject, vararg keys: String): Int? {
        keys.forEach { key ->
            if (o.has(key)) {
                val value = o.optInt(key, Int.MIN_VALUE)
                if (value != Int.MIN_VALUE) return value
            }
        }
        return null
    }

    /** 把 (起点, 分期码) 样本串成连续区间；同一分期的相邻样本合并。 */
    fun segmentsFromSamples(samples: List<Pair<Long, Int>>): List<Segment> {
        val valid =
            samples
                .filter { it.first > 0L }
                .associate { it.first to it.second }
                .toSortedMap()
                .entries
                .map { it.key to it.value }
        if (valid.isEmpty()) return emptyList()
        val result = mutableListOf<Segment>()
        valid.forEachIndexed { index, (start, code) ->
            val end = valid.getOrNull(index + 1)?.first ?: start
            if (end <= start) return@forEachIndexed
            val stage = stageOf(code) ?: return@forEachIndexed
            val previous = result.lastOrNull()
            if (previous != null && previous.stage == stage && previous.endMillis == start) {
                result[result.lastIndex] = previous.copy(endMillis = end)
            } else {
                result.add(Segment(start, end, stage))
            }
        }
        return result
    }

    /** `sleep_status`：Base64(gzip(JSON 数组))，元素带 `startTime` + `status` */
    fun decodeStatusBlob(base64: String): List<Segment> {
        val json = inflate(base64) ?: return emptyList()
        val array = runCatching { JSONArray(json) }.getOrNull() ?: return emptyList()
        val samples = mutableListOf<Pair<Long, Int>>()
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            val start = item.optLong("startTime", item.optLong("start_time", 0L))
            val status = item.optInt("status", item.optInt("stage", 0))
            if (start > 0L && status > 0) samples.add(start to status)
        }
        return segmentsFromSamples(samples)
    }

    /** 分期明细模块：每条记录自带起止时间 */
    fun parseStageRecords(records: List<JSONObject>): List<Segment> =
        records
            .mapNotNull { record ->
                val start =
                    optLong(record, "start_time", "com.samsung.health.sleep_stage.start_time")
                val rawEnd = optLong(record, "end_time", "com.samsung.health.sleep_stage.end_time")
                val code =
                    optIntOrNull(record, "status", "stage", "sleep_stage") ?: return@mapNotNull null
                val stage = stageOf(code) ?: return@mapNotNull null
                val end = if (rawEnd > start) rawEnd else start
                if (start <= 0L || end <= start) null else Segment(start, end, stage)
            }
            .sortedBy { it.startMillis }

    /** 睡眠会话记录（不含分期） */
    private fun parseSessionRecord(record: JSONObject, segments: List<Segment>): Session? {
        val start = optLong(record, "start_time", "com.samsung.health.sleep.start_time")
        val end = optLong(record, "end_time", "com.samsung.health.sleep.end_time")
        val fromSegments = segments.filter { it.startMillis > 0 }
        val sessionStart =
            if (start > 0L) start else fromSegments.minOfOrNull { it.startMillis } ?: 0L
        val sessionEnd =
            when {
                end > sessionStart -> end
                else -> fromSegments.maxOfOrNull { it.endMillis } ?: 0L
            }
        if (sessionStart <= 0L || sessionEnd <= sessionStart) return null
        val efficiency = optIntOrNull(record, "efficiency")?.let { if (it in 1..100) it else null }
        val score =
            optIntOrNull(record, "quality", "rating", "sleep_score", "sleep_score_value")?.takeIf {
                it in 0..100
            }
        return Session(
            startMillis = sessionStart,
            endMillis = sessionEnd,
            segments =
                fromSegments.filter {
                    it.startMillis >= sessionStart && it.endMillis <= sessionEnd
                },
            efficiency = efficiency,
            score = score,
            reportedSleepMinutes = optIntOrNull(record, "sleep_duration")?.takeIf { it in 0..1440 },
            id = record.optString("datauuid"),
        )
    }

    /**
     * 合并睡眠会话与分期数据。
     *
     * 会话与分期通过 `datauuid` / `sleep_uuid` 关联；缺少 uuid 时按时间包含关系归属。
     */
    fun sessions(
        sleepRecords: List<JSONObject>,
        dataRecords: List<JSONObject> = emptyList(),
        stageRecords: List<JSONObject> = emptyList(),
    ): List<Session> {
        val stagesByUuid = mutableMapOf<String, MutableList<Segment>>()
        val looseSegments = mutableListOf<Segment>()
        stageRecords.forEach { record ->
            val uuid =
                record.optString("sleep_id").ifBlank {
                    record.optString("sleep_uuid").ifBlank { record.optString("datauuid") }
                }
            val segment = parseStageRecords(listOf(record)).firstOrNull() ?: return@forEach
            if (uuid.isBlank()) {
                looseSegments.add(segment)
            } else {
                stagesByUuid.getOrPut(uuid) { mutableListOf() }.add(segment)
            }
        }
        val dataByUuid =
            dataRecords.groupBy {
                it.optString("sleep_id").ifBlank {
                    it.optString("sleep_uuid").ifBlank { it.optString("datauuid") }
                }
            }
        val dataSegments = dataRecords.associateWith { segmentsFromDataRecord(it) }

        val sessions = mutableListOf<Session>()
        sleepRecords.forEach { record ->
            val uuid = record.optString("datauuid", record.optString("sleep_uuid"))
            val start = optLong(record, "start_time", "com.samsung.health.sleep.start_time")
            val end = optLong(record, "end_time", "com.samsung.health.sleep.end_time")
            val linked = buildList {
                if (uuid.isNotBlank()) {
                    stagesByUuid[uuid]?.let { addAll(it) }
                    dataByUuid[uuid]?.forEach { data -> addAll(dataSegments[data].orEmpty()) }
                }
                if (isEmpty()) {
                    // 无 uuid 关联时按时间包含关系兜底
                    dataSegments.values.flatten().forEach { segment ->
                        if (segment.startMillis >= start && (end <= 0L || segment.endMillis <= end))
                            add(segment)
                    }
                    looseSegments.forEach { segment ->
                        if (segment.startMillis >= start && (end <= 0L || segment.endMillis <= end))
                            add(segment)
                    }
                }
            }
            parseSessionRecord(record, (linked).distinct().sortedBy { it.startMillis })?.let {
                sessions.add(it)
            }
        }

        if (sessions.isEmpty()) {
            val orphanSegments =
                (looseSegments + dataSegments.values.flatten()).distinct().sortedBy {
                    it.startMillis
                }
            if (orphanSegments.isNotEmpty()) {
                sessions.add(
                    Session(
                        startMillis = orphanSegments.first().startMillis,
                        endMillis = orphanSegments.last().endMillis,
                        segments = orphanSegments,
                        efficiency = null,
                        score = null,
                    )
                )
            }
        }
        return sessions.sortedBy { it.startMillis }
    }

    private fun segmentsFromDataRecord(record: JSONObject): List<Segment> {
        val blob =
            record.optString(
                "sleep_status",
                record.optString("com.samsung.shealth.sleep_data.sleep_status"),
            )
        if (blob.isNotBlank()) {
            val decoded = decodeStatusBlob(blob)
            if (decoded.isNotEmpty()) return decoded
        }
        return parseStageRecords(listOf(record))
    }

    /** 合并两夜的同一段睡眠：会话记录与分期数据可能在不同报文里到达， 保留分期更完整的一份；同样完整时保留结束时间更晚的。 */
    fun merge(current: Session?, incoming: Session?): Session? {
        if (current == null) return incoming
        if (incoming == null) return current
        val sameNight =
            current.startMillis < incoming.endMillis && incoming.startMillis < current.endMillis
        if (!sameNight) return if (incoming.endMillis >= current.endMillis) incoming else current
        val richer =
            when {
                incoming.segments.size != current.segments.size ->
                    if (incoming.segments.size > current.segments.size) incoming else current
                else -> if (incoming.endMillis >= current.endMillis) incoming else current
            }
        // 补齐对方独有的字段（例如会话记录带评分、分期数据带区间）
        return richer.copy(
            startMillis = minOf(current.startMillis, incoming.startMillis),
            endMillis = maxOf(current.endMillis, incoming.endMillis),
            efficiency = richer.efficiency ?: current.efficiency ?: incoming.efficiency,
            score = richer.score ?: current.score ?: incoming.score,
            reportedSleepMinutes =
                richer.reportedSleepMinutes
                    ?: current.reportedSleepMinutes
                    ?: incoming.reportedSleepMinutes,
        )
    }

    /** 最近 7 天睡眠分钟数（按醒来日期归集，升序，含今天） */
    fun lastWeek(history: Map<String, Int>, today: java.time.LocalDate): List<Int> =
        (6 downTo 0).map { offset -> history[today.minusDays(offset.toLong()).toString()] ?: 0 }

    /** 最近一夜：结束时间最晚且不早于 [notBeforeMillis] */
    fun latestSession(sessions: List<Session>, notBeforeMillis: Long): Session? =
        sessions.filter { it.endMillis >= notBeforeMillis }.maxByOrNull { it.endMillis }

    /**
     * 最近一个睡眠日的全部会话（按醒来日期归集）。
     *
     * 夜间睡眠与同一天的午休共享同一个 [nightKey]，因此两者会一起返回；UI 取其中最长的一段 作为主睡眠，其余显示为小睡，并汇总当天总睡眠时长。
     */
    fun latestDaySessions(
        sessions: List<Session>,
        notBeforeMillis: Long,
        zone: java.time.ZoneId = java.time.ZoneId.systemDefault(),
    ): List<Session> {
        val latest = latestSession(sessions, notBeforeMillis) ?: return emptyList()
        val key = nightKey(latest, zone)
        return sessions.filter { nightKey(it, zone) == key }.sortedBy { it.startMillis }
    }

    /** 用户手动补记的午休；手表未上报午休时由用户显式输入，不参与健康数据推断。 */
    data class ManualNap(val startMillis: Long, val endMillis: Long) {
        val minutes: Int
            get() = ((endMillis - startMillis).coerceAtLeast(0L) / 60_000L).toInt()
    }

    fun manualSession(nap: ManualNap): Session =
        Session(
            startMillis = nap.startMillis,
            endMillis = nap.endMillis,
            segments = emptyList(),
            efficiency = null,
            score = null,
            reportedSleepMinutes = nap.minutes.coerceAtLeast(1),
            id = "manual:${nap.startMillis}:${nap.endMillis}",
            analysisSource = "manual",
        )

    /** 将手动补记并入手表会话；起止时间完全相同的会话只保留一份。 */
    fun mergeSessions(sessions: List<Session>, manual: List<ManualNap>): List<Session> =
        (sessions + manual.map(::manualSession))
            .distinctBy { it.startMillis to it.endMillis }
            .sortedBy { it.startMillis }

    /** 逐日睡眠分钟数，包含手动补记。 */
    fun historyByDay(
        sessions: List<Session>,
        zone: java.time.ZoneId = java.time.ZoneId.systemDefault(),
    ): Map<String, Int> =
        sessions
            .filter { it.hasSleepDuration }
            .groupBy { nightKey(it, zone) }
            .mapValues { (_, day) -> day.sumOf { it.asleepMinutes } }

    /** 是否以「昨夜」的日期归类（结束时间落在今天或昨天凌晨） */
    fun nightKey(
        session: Session,
        zone: java.time.ZoneId = java.time.ZoneId.systemDefault(),
    ): String =
        runCatching {
                java.time.Instant.ofEpochMilli(session.endMillis)
                    .atZone(zone)
                    .toLocalDate()
                    .toString()
            }
            .getOrDefault("")

    // Serialization

    fun encode(session: Session): String {
        val root =
            JSONObject()
                .put("start", session.startMillis)
                .put("end", session.endMillis)
                .put("eff", session.efficiency ?: JSONObject.NULL)
                .put("score", session.score ?: JSONObject.NULL)
                .put("reported_minutes", session.reportedSleepMinutes ?: JSONObject.NULL)
                .put("id", session.id)
                .put("analysis_source", session.analysisSource ?: JSONObject.NULL)
                .put("recorded_end", session.recordedEndMillis ?: JSONObject.NULL)
        val segments = JSONArray()
        session.segments.forEach { segment ->
            segments.put(
                JSONArray().put(segment.startMillis).put(segment.endMillis).put(segment.stage.name)
            )
        }
        root.put("segments", segments)
        return root.toString()
    }

    fun decode(raw: String?): Session? {
        if (raw.isNullOrBlank()) return null
        val root = runCatching { JSONObject(raw) }.getOrNull() ?: return null
        val start = root.optLong("start", 0L)
        val end = root.optLong("end", 0L)
        if (start <= 0L || end <= start) return null
        val segments = mutableListOf<Segment>()
        root.optJSONArray("segments")?.let { array ->
            for (i in 0 until array.length()) {
                val item = array.optJSONArray(i) ?: continue
                val stage = runCatching { Stage.valueOf(item.optString(2)) }.getOrNull() ?: continue
                val segStart = item.optLong(0)
                val segEnd = item.optLong(1)
                if (segEnd > segStart) segments.add(Segment(segStart, segEnd, stage))
            }
        }
        return Session(
            startMillis = start,
            endMillis = end,
            segments = segments,
            efficiency = if (root.isNull("eff")) null else root.optInt("eff"),
            score = if (root.isNull("score")) null else root.optInt("score"),
            reportedSleepMinutes =
                if (!root.has("reported_minutes") || root.isNull("reported_minutes")) null
                else root.optInt("reported_minutes"),
            id = root.optString("id"),
            analysisSource =
                if (root.isNull("analysis_source")) null
                else root.optString("analysis_source").takeIf { it.isNotBlank() },
            recordedEndMillis =
                if (!root.has("recorded_end") || root.isNull("recorded_end")) null
                else root.optLong("recorded_end"),
        )
    }

    /** 同一睡眠日的多段会话（夜间 + 午休）编解码。 */
    fun encodeSessions(sessions: List<Session>): String {
        val array = JSONArray()
        sessions.forEach { array.put(JSONObject(encode(it))) }
        return array.toString()
    }

    fun decodeSessions(raw: String?): List<Session> {
        if (raw.isNullOrBlank()) return emptyList()
        val array = runCatching { JSONArray(raw) }.getOrNull() ?: return emptyList()
        return (0 until array.length()).mapNotNull { index ->
            array.optJSONObject(index)?.let { decode(it.toString()) }
        }
    }

    /** 只用于图表的历史：日期 → 睡眠分钟数 */
    fun encodeHistory(history: Map<String, Int>): String {
        val root = JSONObject()
        history.toSortedMap().forEach { (day, minutes) -> root.put(day, minutes) }
        return root.toString()
    }

    fun decodeHistory(raw: String?): MutableMap<String, Int> {
        val result = mutableMapOf<String, Int>()
        if (raw.isNullOrBlank()) return result
        val root = runCatching { JSONObject(raw) }.getOrNull() ?: return result
        root.keys().forEach { day ->
            val minutes = root.optInt(day, 0)
            if (minutes > 0) result[day] = minutes
        }
        return result
    }

    private fun inflate(base64: String): String? =
        runCatching { HealthJson.inflateJson(base64.trim(), 8 * 1024 * 1024) }.getOrNull()
}
