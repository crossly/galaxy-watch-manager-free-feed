package dev.ricky.galaxywatchmanagerfree.core

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.widget.Toast

/**
 * 全局轻量提示的统一出口。
 *
 * 交互约定：
 * - 一次性反馈（已发送、等待确认、未确认、失败原因）统一用 Toast，不做常驻横幅；
 * - 相同文本在 [DEDUPE_MS] 内合并，避免手表连续回包或用户连点造成刷屏；
 * - 只用 Application Context，排队回到主线程执行，调用方可来自任意线程。
 */
object UiNotify {
    private const val DEDUPE_MS = 1200L

    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var appContext: Context? = null
    private var lastText: String? = null
    private var lastAt = 0L

    fun init(context: Context) {
        appContext = context.applicationContext
    }

    fun show(message: UiText, long: Boolean = false) {
        val context = appContext ?: return
        show(message.resolve(AppLanguage.context(context).resources), long)
    }

    fun show(@androidx.annotation.StringRes resource: Int, long: Boolean = false) =
        show(uiText(resource), long)

    fun show(text: String, long: Boolean = false) {
        val message = text.trim()
        if (message.isEmpty()) return
        val now = SystemClock.elapsedRealtime()
        synchronized(this) {
            if (message == lastText && now - lastAt < DEDUPE_MS) return
            lastText = message
            lastAt = now
        }
        val context = appContext ?: return
        handler.post {
            Toast.makeText(context, message, if (long) Toast.LENGTH_LONG else Toast.LENGTH_SHORT)
                .show()
        }
    }
}
