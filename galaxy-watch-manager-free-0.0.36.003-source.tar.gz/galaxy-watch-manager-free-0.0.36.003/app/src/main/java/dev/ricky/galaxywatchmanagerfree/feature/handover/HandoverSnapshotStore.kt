package dev.ricky.galaxywatchmanagerfree.feature.handover

import android.content.Context

/**
 * Persists the handover restore point.
 *
 * Writes use [android.content.SharedPreferences.Editor.commit] before any package is disabled so a
 * process death cannot leave the user with disabled apps and no restore information.
 */
internal class HandoverSnapshotStore(context: Context) {

    private val preferences =
        context.applicationContext.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE)

    @Synchronized
    fun load(): HandoverJournal =
        HandoverJournal.decode(preferences.getString(KEY_JOURNAL, null).orEmpty())

    @Synchronized
    fun save(journal: HandoverJournal): Boolean {
        val editor = preferences.edit()
        if (journal.isEmpty) editor.remove(KEY_JOURNAL)
        else editor.putString(KEY_JOURNAL, journal.encode())
        return editor.commit()
    }

    private companion object {
        const val PREFERENCES_NAME = "watchfree_official_handover"
        const val KEY_JOURNAL = "restore_journal_v1"
    }
}
