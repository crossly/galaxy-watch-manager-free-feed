package dev.ricky.galaxywatchmanagerfree.feature

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import org.json.JSONObject

/** Derive displayed health values from retained record revisions, independently of transport. */
object HealthDataProjection {
    data class Result(
        val heartRatePoints: List<HeartRateLog.Point>,
        val heartRateHistory: Map<String, List<HeartRateLog.Point>>,
        val heartRateDays: Map<String, HeartRateLog.Stats>,
        val latestHeartRate: HeartRateLog.Point?,
        val latestStress: StressLog.Point?,
        val stressHistory: Map<String, List<StressLog.Point>>,
        val stressDays: Map<String, StressLog.Stats>,
        val sleepSessions: List<SleepParser.Session>,
        val metrics: Map<HealthMetric, List<HealthMetricLog.Sample>>,
        val sleepHistory: Map<String, Int>,
        val exercises: List<ExerciseLog.Session>,
        val floors: Int,
        val stress: Int,
        val watchGoal: Int,
        val recommendedGoal: Int,
        val calories: Float?,
        val distanceMeters: Float?,
        val hours: List<Int>,
        val activityHistory: Map<String, HealthTimeline.Day>,
    )

    fun build(
        store: HealthRecordStore,
        now: Long,
        zone: ZoneId = ZoneId.systemDefault(),
        localSleep: Map<String, SleepParser.Session> = emptyMap(),
    ): Result {
        val today = Instant.ofEpochMilli(now).atZone(zone).toLocalDate()
        val heartData = heart(store, now, zone)
        val metrics =
            HealthMetric.entries.associateWith { metric ->
                HealthMetricLog.merge(
                    emptyList(),
                    HealthMetricLog.samples(metric, store.recordsFor(metric)),
                    now,
                )
            }
        val sleeps =
            SleepParser.sessions(
                    store.records(SleepParser.MODULE_SLEEP, SleepParser.MODULE_SLEEP_LEGACY),
                    store.records(SleepParser.MODULE_SLEEP_DATA),
                    store.records(
                        SleepParser.MODULE_SLEEP_STAGE,
                        SleepParser.MODULE_SLEEP_STAGE_LEGACY,
                    ),
                )
                .map { session ->
                    if (session.segments.isNotEmpty()) session
                    else localSleep[session.id] ?: session
                }
        val sleepHistory =
            sleeps
                .filter { it.hasSleepDuration }
                .groupBy { SleepParser.nightKey(it, zone) }
                .mapValues { (_, sessions) ->
                    sessions
                        .distinctBy { it.startMillis to it.endMillis }
                        .sumOf { it.asleepMinutes }
                }
        val floors =
            FloorsLog.todayTotal(
                store.records(
                    "com.samsung.health.floors_climbed",
                    "com.samsung.shealth.floors_climbed",
                ),
                now,
                zone,
            ) ?: -1
        val stressData = stress(store, now, zone)
        val preferences = store.records("com.samsung.shealth.service_preferences")
        val goal =
            preferences
                .sortedBy { it.optLong("update_time") }
                .mapNotNull {
                    val direct = it.optInt("target_steps", 0)
                    val value =
                        if (direct > 0) direct
                        else if (it.optString("key") == "target_steps") it.optInt("int_value")
                        else 0
                    value.takeIf { n -> n in HealthGoals.MIN_STEP_GOAL..HealthGoals.MAX_STEP_GOAL }
                }
                .lastOrNull() ?: 0
        val recommendation =
            store
                .records("com.samsung.shealth.tracker.pedometer_recommendation")
                .maxByOrNull { it.optLong("update_time") }
                ?.let { it.optInt("value", it.optInt("recommendation")) } ?: 0
        val intervalsByDay =
            store
                .records(HealthStepParser.MODULE_STEP_COUNT)
                .filter { HealthStepParser.recordStartTime(it) in 1..now }
                .groupBy { HealthMetricLog.dayOf(HealthStepParser.recordStartTime(it), zone) }
        val summariesByDay =
            store
                .records(HealthStepParser.MODULE_DAY_SUMMARY)
                .mapNotNull { record ->
                    HealthStepParser.daySummaryDate(record, zone)
                        ?.takeIf { LocalDate.parse(it) <= today }
                        ?.let { it to record }
                }
                .groupBy({ it.first }, { it.second })
                .mapValues { (_, records) ->
                    records.maxBy { HealthStepParser.recordUpdateTime(it) }
                }
        val activity =
            (intervalsByDay.keys + summariesByDay.keys).associateWith { day ->
                val intervals = intervalsByDay[day].orEmpty()
                val summary = summariesByDay[day]
                HealthTimeline.Day(
                    summary?.let(HealthStepParser::daySummarySteps)?.takeIf { it >= 0 }
                        ?: intervals.sumOf(HealthStepParser::recordSteps),
                    dailyAmount(summary, intervals, "calorie")?.toInt() ?: 0,
                    dailyAmount(summary, intervals, "distance")?.toInt() ?: 0,
                )
            }
        val steps = store.todaySteps(now, zone)
        val todaySummary = summariesByDay[today.toString()]
        return Result(
            heartRatePoints = heartData.points24h,
            heartRateHistory = heartData.history,
            heartRateDays = heartData.days,
            latestHeartRate = heartData.latest,
            latestStress = stressData.latest,
            stressHistory = stressData.history,
            stressDays = stressData.days,
            metrics = metrics,
            sleepSessions = sleeps,
            sleepHistory = sleepHistory,
            exercises =
                ExerciseLog.merge(
                    emptyList(),
                    ExerciseLog.parse(
                        store.records(ExerciseLog.MODULE, ExerciseLog.MODULE_ALIAS),
                        store.records(ExerciseLog.MODULE_CUSTOM),
                    ) +
                        ExerciseLog.parseRoutines(
                            store.records(ExerciseLog.MODULE_ROUTINE),
                            store.records(ExerciseLog.MODULE_CUSTOM),
                        ),
                ),
            floors = floors,
            stress = stressData.latest?.let { StressLog.roundedScore(it) } ?: -1,
            watchGoal = goal,
            recommendedGoal = recommendation,
            calories = dailyAmount(todaySummary, steps, "calorie"),
            distanceMeters = dailyAmount(todaySummary, steps, "distance"),
            hours =
                HealthTimeline.resolveTodayHours(
                    HealthTimeline.emptyHours(),
                    todaySummary?.optJSONArray("binning_data"),
                    steps,
                    zone,
                    now,
                ),
            activityHistory = activity,
        )
    }

    /** 心率投影：24 小时点保留导出/旧图表契约，逐日历史供详情按天查看。 */
    fun heart(
        store: HealthRecordStore,
        now: Long,
        zone: ZoneId = ZoneId.systemDefault(),
    ): HeartResult {
        val retained =
            HeartRateLog.normalized(
                HeartRateLog.pointsFromRecords(store.records(HeartRateLog.MODULE)),
                now,
            )
        val history = HeartRateLog.byDay(retained, zone)
        return HeartResult(
            points24h = HeartRateLog.merge(emptyList(), retained, now),
            history = history,
            days =
                history
                    .mapNotNull { (day, points) -> HeartRateLog.stats(points)?.let { day to it } }
                    .toMap(),
            latest = retained.lastOrNull(),
        )
    }

    data class HeartResult(
        val points24h: List<HeartRateLog.Point>,
        val history: Map<String, List<HeartRateLog.Point>>,
        val days: Map<String, HeartRateLog.Stats>,
        val latest: HeartRateLog.Point?,
    )

    /** 压力投影：分箱展开为真实读数，逐日历史供详情按天查看。 */
    fun stress(
        store: HealthRecordStore,
        now: Long,
        zone: ZoneId = ZoneId.systemDefault(),
    ): StressResult {
        val retained =
            StressLog.normalized(StressLog.pointsFromRecords(store.records(StressLog.MODULE)), now)
        val history = StressLog.byDay(retained, zone)
        return StressResult(
            history = history,
            days =
                history
                    .mapNotNull { (day, points) -> StressLog.stats(points)?.let { day to it } }
                    .toMap(),
            latest = retained.lastOrNull(),
        )
    }

    data class StressResult(
        val history: Map<String, List<StressLog.Point>>,
        val days: Map<String, StressLog.Stats>,
        val latest: StressLog.Point?,
    )

    /** Missing measurements stay unknown; a partial record must not turn them into zero. */
    private fun amount(record: JSONObject, key: String): Float? =
        record
            .optDouble(key, record.optDouble("com.samsung.health.step_count.$key", Double.NaN))
            .takeIf { it.isFinite() && it >= 0 }
            ?.toFloat()

    private fun dailyAmount(
        summary: JSONObject?,
        intervals: List<JSONObject>,
        key: String,
    ): Float? {
        summary
            ?.let { amount(it, key) }
            ?.let {
                return it
            }
        if (intervals.isEmpty()) return null
        val values = intervals.map { amount(it, key) ?: return null }
        return values.sum()
    }
}
