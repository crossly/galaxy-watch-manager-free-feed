package dev.ricky.galaxywatchmanagerfree.feature

import android.content.Context
import android.os.Build
import android.util.Log
import dev.ricky.galaxywatchmanagerfree.BuildConfig
import java.io.File
import java.time.OffsetDateTime
import java.time.format.DateTimeFormatter
import java.util.UUID
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

object LogBus {
    private const val TAG = "Galaxy Watch Manager Free"
    private const val PREFS = "watchfree_logging"
    private val _lines = MutableStateFlow<List<String>>(emptyList())
    val lines: StateFlow<List<String>> = _lines.asStateFlow()
    private val _debugLines = MutableStateFlow<List<String>>(emptyList())
    val debugLines: StateFlow<List<String>> = _debugLines.asStateFlow()
    private val _debugEnabled = MutableStateFlow(false)
    val debugEnabled: StateFlow<Boolean> = _debugEnabled.asStateFlow()
    val isDebugEnabled: Boolean
        get() = _debugEnabled.value

    private val _storageError = MutableStateFlow(false)
    val storageError: StateFlow<Boolean> = _storageError.asStateFlow()
    @Volatile private var store: DiagnosticLogStore? = null
    private val dropped = AtomicLong()
    private val storageFailures = AtomicLong()
    private val clearGeneration = AtomicLong()
    private var storedGeneration = 0L
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val writer =
        ThreadPoolExecutor(
                1,
                1,
                0L,
                TimeUnit.MILLISECONDS,
                ArrayBlockingQueue(500),
                { task -> Thread(task, "watchfree-log").apply { isDaemon = true } },
                { _, _ -> dropped.incrementAndGet() },
            )
            .apply { prestartCoreThread() }

    fun init(context: Context) {
        store = DiagnosticLogStore(context.filesDir)
        _debugEnabled.value =
            context
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getBoolean("debug_enabled", false)
        log("[应用] session=${UUID.randomUUID()} ${environment()} debug=$isDebugEnabled")
    }

    fun setDebugEnabled(context: Context, enabled: Boolean) {
        context
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putBoolean("debug_enabled", enabled)
            .apply()
        _debugEnabled.value = enabled
        log(if (enabled) "[日志] 已开启调试日志" else "[日志] 已关闭调试日志")
    }

    fun log(s: String) = emit("INFO", s)

    fun error(message: String, error: Throwable? = null) {
        emit("ERROR", formatError(message, error))
        if (error != null) debug { formatDebugStack(error) }
    }

    internal fun formatError(message: String, error: Throwable?): String =
        DiagnosticValue.error(message, error)

    internal fun formatDebugStack(error: Throwable): String = DiagnosticValue.stackTrace(error)

    fun debug(message: String) {
        if (isDebugEnabled) emit("DEBUG", message)
    }

    fun debug(message: () -> String) {
        if (isDebugEnabled) emit("DEBUG", message())
    }

    fun describe(value: Any?): String = DiagnosticValue.describe(value)

    private fun emit(level: String, message: String) {
        val generation = clearGeneration.get()
        val safe = DiagnosticValue.text(message)
        val stamp = OffsetDateTime.now().format(DateTimeFormatter.ISO_OFFSET_DATE_TIME)
        val entry = "$stamp [$level] [${Thread.currentThread().name}] $safe"
        if (level == "DEBUG") {
            Log.d(TAG, safe)
            _debugLines.update { (it + entry).takeLast(300) }
        } else {
            if (level == "ERROR") Log.e(TAG, safe) else Log.i(TAG, safe)
            _lines.update { (it + entry).takeLast(300) }
        }
        val target = store ?: return
        writer.execute {
            diskOperation {
                if (generation != clearGeneration.get()) return@diskOperation
                prepareStore(target)
                val lost = dropped.getAndSet(0)
                if (lost > 0) target.append("$stamp [WARN] [logger] queue full; dropped=$lost")
                target.append(entry)
            }
        }
    }

    private fun prepareStore(target: DiagnosticLogStore) {
        val generation = clearGeneration.get()
        if (storedGeneration != generation) {
            target.clear()
            storedGeneration = generation
        }
    }

    private fun diskOperation(action: () -> Unit) {
        try {
            action()
            _storageError.value = false
        } catch (error: Exception) {
            storageFailures.incrementAndGet()
            _storageError.value = true
            Log.e(TAG, "Log file I/O failed: ${error.javaClass.simpleName}")
        }
    }

    suspend fun export(context: Context): File =
        withContext(Dispatchers.IO) {
            val target = checkNotNull(store) { "Logger not initialized" }
            val completed = CompletableDeferred<File>()
            // A control job must survive queue saturation and follow all earlier writes.
            writer.queue.put {
                var pending: File? = null
                try {
                    prepareStore(target)
                    val dir = File(context.cacheDir, "log_exports")
                    check(dir.isDirectory || dir.mkdirs())
                    dir.listFiles()
                        ?.filter { System.currentTimeMillis() - it.lastModified() > 86_400_000L }
                        ?.forEach { it.delete() }
                    val file =
                        File(
                            dir,
                            "watchfree-${System.currentTimeMillis()}-${UUID.randomUUID().toString().take(8)}.txt",
                        )
                    pending = file
                    file.outputStream().buffered().use {
                        target.export(
                            it,
                            "Galaxy Watch Manager Free diagnostic log\n${environment()}\nExported=${OffsetDateTime.now()} debug=$isDebugEnabled droppedPending=${dropped.get()} storageFailures=${storageFailures.get()}",
                        )
                    }
                    completed.complete(file)
                } catch (error: Exception) {
                    pending?.delete()
                    completed.completeExceptionally(error)
                }
            }
            completed.await()
        }

    fun clear() {
        clearGeneration.incrementAndGet()
        _lines.value = emptyList()
        _debugLines.value = emptyList()
        val target = store ?: return
        scope.launch { writer.queue.put { diskOperation { prepareStore(target) } } }
    }

    private fun environment(): String =
        "app=${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE}) build=${BuildConfig.BUILD_TYPE} " +
            "Android=${Build.VERSION.RELEASE} SDK=${Build.VERSION.SDK_INT} manufacturer=${Build.MANUFACTURER} model=${Build.MODEL}"
}
