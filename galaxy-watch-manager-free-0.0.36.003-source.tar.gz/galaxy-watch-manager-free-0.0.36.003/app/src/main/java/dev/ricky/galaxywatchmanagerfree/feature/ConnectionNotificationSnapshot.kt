package dev.ricky.galaxywatchmanagerfree.feature

import java.time.Instant
import java.time.ZoneId

enum class ConnectionNotificationState {
    WAITING,
    CONNECTING,
    READY,
}

/** 常驻通知只依赖这组会展示的数据。状态里其他高频字段变化时会保持相等，让收集器直接跳过无意义的通知刷新。 */
data class ConnectionNotificationSnapshot(
    val deviceName: String = "",
    val connection: ConnectionNotificationState = ConnectionNotificationState.WAITING,
    val steps: Int? = null,
    val stepGoal: Int? = null,
    val stepProgressPercent: Int? = null,
    val heartRate: Int? = null,
    val batteryLevel: Int? = null,
    val calories: Float? = null,
    val sleepMinutes: Int? = null,
    val distanceMeters: Float? = null,
    val stressScore: Int? = null,
    val config: NotificationBarConfig = NotificationBarPreferences.current(),
) {
    companion object {
        fun from(
            state: WatchState,
            nowMillis: Long = System.currentTimeMillis(),
            zone: ZoneId = ZoneId.systemDefault(),
            config: NotificationBarConfig = NotificationBarPreferences.current(),
        ): ConnectionNotificationSnapshot {
            val steps = state.todaySteps.takeIf { it >= 0 }
            val goal = state.stepGoal.takeIf { it > 0 }
            val progress =
                if (steps != null && goal != null) {
                    ((steps.toLong() * 100L) / goal).coerceIn(0L, Int.MAX_VALUE.toLong()).toInt()
                } else {
                    null
                }
            val today =
                runCatching {
                        Instant.ofEpochMilli(nowMillis).atZone(zone).toLocalDate().toString()
                    }
                    .getOrDefault("")
            val displayName = state.displayName.trim()
            val sleepMins =
                state.sleep?.displayMinutes
                    ?: state.sleepSessions.maxByOrNull { it.endMillis }?.displayMinutes
                    ?: state.weekSleep.lastOrNull()?.takeIf { it > 0 }
            val stress =
                state.latestStress?.score?.toInt() ?: state.lastStressScore.takeIf { it >= 0 }
            return ConnectionNotificationSnapshot(
                deviceName = displayName,
                connection =
                    when {
                        state.sessionReady -> ConnectionNotificationState.READY
                        state.connected -> ConnectionNotificationState.CONNECTING
                        else -> ConnectionNotificationState.WAITING
                    },
                steps = steps,
                stepGoal = goal,
                stepProgressPercent = progress,
                heartRate = latestHeartRateOn(today, state, zone),
                batteryLevel = state.batteryLevel.takeIf { it in 0..100 },
                calories = state.todayCalories.takeIf { it >= 0f },
                sleepMinutes = sleepMins,
                distanceMeters = state.todayDistanceMeters.takeIf { it >= 0f },
                stressScore = stress,
                config = config,
            )
        }

        private fun latestHeartRateOn(day: String, state: WatchState, zone: ZoneId): Int? {
            if (day.isBlank()) return null
            val candidates =
                listOfNotNull(
                    state.heartRateHistory[day]?.maxByOrNull { it.ts },
                    state.heartRatePoints
                        .asSequence()
                        .filter { HeartRateLog.dayOf(it.ts, zone) == day }
                        .maxByOrNull { it.ts },
                    state.latestHeartRate?.takeIf { HeartRateLog.dayOf(it.ts, zone) == day },
                )
            return candidates.maxByOrNull { it.ts }?.bpm
        }
    }
}
