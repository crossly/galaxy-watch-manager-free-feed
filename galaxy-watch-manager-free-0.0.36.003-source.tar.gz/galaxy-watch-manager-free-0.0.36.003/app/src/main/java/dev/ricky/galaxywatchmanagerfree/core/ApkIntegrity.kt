package dev.ricky.galaxywatchmanagerfree.core

import java.io.InputStream
import java.security.MessageDigest

/**
 * 下载包的完整性校验（纯逻辑，可在 JVM 单元测试中验证）。
 *
 * 两道关卡：
 * 1. [sha256] 与清单里的摘要比对，防止传输截断或被中间人替换；
 * 2. 安装前比对签名证书，只接受与本机已安装版本同一把签名密钥的 APK，
 *    这样即便清单被篡改，也无法让我们装上一个冒充的包。
 */
object ApkIntegrity {

    private const val BUFFER = 64 * 1024

    fun sha256(bytes: ByteArray): String = sha256(bytes.inputStream())

    fun sha256(input: InputStream): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(BUFFER)
        input.use { stream ->
            while (true) {
                val read = stream.read(buffer)
                if (read <= 0) break
                digest.update(buffer, 0, read)
            }
        }
        return digest.digest().joinToString("") { byte -> "%02x".format(byte) }
    }

    /** 摘要比对：忽略大小写与 `sha256:` 前缀；期望值缺失时视为无法校验。 */
    fun matches(expected: String?, actual: String?): Boolean {
        val want = normalize(expected) ?: return false
        val got = normalize(actual) ?: return false
        return want == got
    }

    fun normalize(digest: String?): String? {
        val cleaned = digest?.trim()?.lowercase()?.removePrefix("sha256:")?.replace(":", "")
        return cleaned?.takeIf { it.length == 64 && it.all { ch -> ch in '0'..'9' || ch in 'a'..'f' } }
    }

    /** 从直链推测文件名，去掉查询串并限制字符集；无法推测时用 [fallback]。 */
    fun fileNameFrom(url: String, fallback: String = "update.apk"): String {
        val raw = url.substringBefore('?').substringBefore('#').trimEnd('/').substringAfterLast('/')
        val safe = raw.filter { it.isLetterOrDigit() || it == '.' || it == '-' || it == '_' }
        return safe.takeIf { it.length > 4 && it.endsWith(".apk", ignoreCase = true) } ?: fallback
    }

    /** 人类可读的字节数，例如 "13.51 MB"。 */
    fun sizeText(bytes: Long): String = when {
        bytes <= 0L -> ""
        bytes < 1024L -> "$bytes B"
        bytes < 1024L * 1024L -> "%.1f KB".format(bytes / 1024.0)
        else -> "%.2f MB".format(bytes / (1024.0 * 1024.0))
    }
}
