package dev.ricky.galaxywatchmanagerfree.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.feature.HealthMeasurements
import dev.ricky.galaxywatchmanagerfree.ui.components.GroupedCard
import dev.ricky.galaxywatchmanagerfree.ui.components.GroupedCardRow
import dev.ricky.galaxywatchmanagerfree.ui.components.GroupedDivider
import dev.ricky.galaxywatchmanagerfree.ui.components.LocalRootPageBottomPadding
import dev.ricky.galaxywatchmanagerfree.ui.components.SectionHeader
import dev.ricky.galaxywatchmanagerfree.ui.components.SettingSwitchRow
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextSecondary

/**
 * Native automatic measurement settings plus explicit spot measurement deep links.
 *
 * The content owns its scrolling so it can be embedded in the settings route or an app bottom
 * sheet. It never renders a measurement value; only queued/accepted request state is shown.
 */
@Composable
fun HealthMeasurementSettings(
    state: HealthMeasurements.State,
    connected: Boolean,
    vascularLoadSupported: Boolean,
    onSleepOxygen: (Boolean) -> Unit,
    onStressContinuous: (Boolean) -> Unit,
    onVascularLoad: (Boolean) -> Unit,
    onMeasure: (HealthMeasurements.Kind) -> Unit,
    onOpenWatchSettings: (HealthMeasurements.Kind?) -> Unit,
    onRefresh: () -> Unit,
    modifier: Modifier = Modifier,
    bottomPadding: androidx.compose.ui.unit.Dp? = null,
) {
    val sleepOxygenChecked = state.sleepOxygen.desired ?: state.sleepOxygen.enabled ?: false
    val stressContinuousChecked =
        state.stressContinuous.desired ?: state.stressContinuous.enabled ?: false
    val sleepOxygenSubtitle =
        settingSubtitle(
            state.sleepOxygen,
            stringResource(R.string.health_measurement_sleep_oxygen_desc),
            connected,
        )
    val stressSubtitle =
        settingSubtitle(
            state.stressContinuous,
            stringResource(
                if (stressContinuousChecked) {
                    R.string.health_measurement_stress_continuous_desc
                } else {
                    R.string.health_measurement_stress_manual_desc
                }
            ),
            connected,
        )
    // Labs defaults to on; only a received row confirms the watch's value.
    val vascularLoadChecked = state.vascularLoad.desired ?: state.vascularLoad.enabled ?: true
    val vascularLoadSubtitle =
        if (
            state.vascularLoad.status == HealthMeasurements.ToggleStatus.UNKNOWN &&
                state.vascularLoad.canWrite &&
                connected
        ) {
            stringResource(R.string.health_measurement_vascular_load_unknown)
        } else {
            settingSubtitle(
                state.vascularLoad,
                stringResource(R.string.health_measurement_vascular_load_desc),
                connected,
            )
        }
    val needsSync =
        state.sleepOxygen.status == HealthMeasurements.ToggleStatus.UNKNOWN ||
            state.stressContinuous.status == HealthMeasurements.ToggleStatus.UNKNOWN ||
            (vascularLoadSupported &&
                state.vascularLoad.status == HealthMeasurements.ToggleStatus.UNKNOWN)
    val showRequestHint =
        state.remote?.let {
            it.kind != null && it.status != HealthMeasurements.RemoteStatus.SEND_FAILED
        } == true

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding =
            PaddingValues(
                start = 16.dp,
                end = 16.dp,
                top = 4.dp,
                bottom = bottomPadding ?: (LocalRootPageBottomPadding.current + 16.dp),
            ),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item {
            SectionHeader(stringResource(R.string.health_measurement_auto_section))
            GroupedCard(innerPadding = 16.dp) {
                SettingSwitchRow(
                    title = stringResource(R.string.health_measurement_sleep_oxygen),
                    checked = sleepOxygenChecked,
                    subtitle = sleepOxygenSubtitle,
                    enabled =
                        connected &&
                            state.sleepOxygen.status != HealthMeasurements.ToggleStatus.UNKNOWN,
                    onCheckedChange = onSleepOxygen,
                )
                GroupedDivider(startIndent = 0.dp)
                SettingSwitchRow(
                    title = stringResource(R.string.health_measurement_stress_continuous),
                    checked = stressContinuousChecked,
                    subtitle = stressSubtitle,
                    enabled =
                        connected &&
                            state.stressContinuous.status !=
                                HealthMeasurements.ToggleStatus.UNKNOWN,
                    onCheckedChange = onStressContinuous,
                )
                if (vascularLoadSupported) {
                    GroupedDivider(startIndent = 0.dp)
                    SettingSwitchRow(
                        title = stringResource(R.string.health_measurement_vascular_load),
                        checked = vascularLoadChecked,
                        subtitle = vascularLoadSubtitle,
                        enabled =
                            connected &&
                                state.vascularLoad.canWrite &&
                                state.vascularLoad.status !=
                                    HealthMeasurements.ToggleStatus.PENDING,
                        onCheckedChange = onVascularLoad,
                    )
                }
            }
        }

        if (needsSync) {
            item {
                TextButton(
                    onClick = onRefresh,
                    enabled = connected,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Icon(
                        Icons.Default.Refresh,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp),
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.health_measurement_refresh))
                }
            }
        }

        item {
            SectionHeader(stringResource(R.string.health_measurement_measure_section))
            GroupedCard(innerPadding = 0.dp) {
                GroupedCardRow(
                    title = stringResource(R.string.health_measurement_spo2),
                    subtitle =
                        measurementSubtitle(
                            state.remote,
                            HealthMeasurements.Kind.SPO2,
                            stringResource(R.string.health_measurement_spot_desc),
                        ),
                    icon = Icons.Default.MonitorHeart,
                    trailing = {
                        TextButton(
                            onClick = { onMeasure(HealthMeasurements.Kind.SPO2) },
                            enabled = connected,
                        ) {
                            Text(stringResource(R.string.health_measurement_measure))
                        }
                    },
                )
                GroupedDivider()
                GroupedCardRow(
                    title = stringResource(R.string.health_measurement_stress),
                    subtitle =
                        measurementSubtitle(
                            state.remote,
                            HealthMeasurements.Kind.STRESS,
                            stringResource(R.string.health_measurement_spot_desc),
                        ),
                    icon = Icons.Default.Bolt,
                    trailing = {
                        TextButton(
                            onClick = { onMeasure(HealthMeasurements.Kind.STRESS) },
                            enabled = connected,
                        ) {
                            Text(stringResource(R.string.health_measurement_measure))
                        }
                    },
                )
            }
            if (showRequestHint) {
                Text(
                    stringResource(R.string.health_measurement_request_hint),
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                )
            }
        }

        item {
            SectionHeader(stringResource(R.string.health_measurement_settings_section))
            GroupedCard(innerPadding = 0.dp) {
                GroupedCardRow(
                    title = stringResource(R.string.health_measurement_open_watch_settings),
                    icon = Icons.Default.Settings,
                    enabled = connected,
                    showChevron = true,
                    onClick = { onOpenWatchSettings(null) },
                )
                GroupedDivider()
                GroupedCardRow(
                    title = stringResource(R.string.health_measurement_open_stress_settings),
                    icon = Icons.Default.Bolt,
                    enabled = connected,
                    showChevron = true,
                    onClick = { onOpenWatchSettings(HealthMeasurements.Kind.STRESS) },
                )
            }
        }
    }
}

@Composable
private fun settingSubtitle(
    toggle: HealthMeasurements.Toggle,
    base: String,
    connected: Boolean,
): String =
    when (toggle.status) {
        HealthMeasurements.ToggleStatus.UNKNOWN ->
            stringResource(
                if (connected) {
                    R.string.health_measurement_status_sync_required
                } else {
                    R.string.health_measurement_status_connect
                }
            )
        HealthMeasurements.ToggleStatus.PENDING ->
            stringResource(R.string.health_measurement_status_applying)
        HealthMeasurements.ToggleStatus.UNCONFIRMED ->
            stringResource(R.string.health_measurement_status_unconfirmed)
        HealthMeasurements.ToggleStatus.FAILED ->
            stringResource(R.string.health_measurement_status_failed)
        HealthMeasurements.ToggleStatus.CONFIRMED -> base
    }

@Composable
private fun measurementSubtitle(
    remote: HealthMeasurements.Remote?,
    kind: HealthMeasurements.Kind,
    base: String,
): String {
    if (remote?.kind != kind) return base
    return when (remote.status) {
        HealthMeasurements.RemoteStatus.QUEUED ->
            stringResource(R.string.health_measurement_request_queued)
        HealthMeasurements.RemoteStatus.ACCEPTED ->
            stringResource(R.string.health_measurement_request_accepted)
        HealthMeasurements.RemoteStatus.SEND_FAILED ->
            stringResource(R.string.health_measurement_request_failed)
    }
}
