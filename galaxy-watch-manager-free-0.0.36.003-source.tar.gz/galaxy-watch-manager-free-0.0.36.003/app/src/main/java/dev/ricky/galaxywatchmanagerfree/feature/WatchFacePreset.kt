package dev.ricky.galaxywatchmanagerfree.feature

import androidx.annotation.StringRes
import dev.ricky.galaxywatchmanagerfree.R

/** Package and service identifiers remain protocol values when preview assets are unavailable. */
data class WatchFacePreset(
    val id: String,
    @StringRes val nameRes: Int,
    val enName: String,
    val packageName: String,
    val className: String,
    val category: WatchFaceCategory,
) {
    val isUltraExclusive: Boolean
        get() = category == WatchFaceCategory.ULTRA
}

enum class WatchFaceCategory(@StringRes val labelRes: Int) {
    ULTRA(R.string.watch_face_category_ultra),
    FITNESS(R.string.watch_face_category_fitness),
    INFORMATION(R.string.watch_face_category_information),
    ANALOG(R.string.watch_face_category_analog),
    PERSONAL(R.string.watch_face_category_personal),
}

object WatchFacePresets {
    val ALL: List<WatchFacePreset> =
        listOf(
            WatchFacePreset(
                id = "ultraanalog",
                nameRes = R.string.watch_face_ultraanalog,
                enName = "Ultra Analog",
                packageName = "com.samsung.android.watch.watchface.ultraanalog",
                className =
                    "com.samsung.android.watch.watchface.ultraanalog.UltraAnalogWatchFaceService",
                category = WatchFaceCategory.ULTRA,
            ),
            WatchFacePreset(
                id = "ultrainfoboard",
                nameRes = R.string.watch_face_ultrainfoboard,
                enName = "Ultra Info Board",
                packageName = "com.samsung.android.watch.watchface.ultrainfoboard",
                className =
                    "com.samsung.android.watch.watchface.ultrainfoboard.UltraInfoBoardWatchFaceService",
                category = WatchFaceCategory.ULTRA,
            ),
            WatchFacePreset(
                id = "simpleultra",
                nameRes = R.string.watch_face_simpleultra,
                enName = "Simple Ultra",
                packageName = "com.samsung.android.watch.watchface.simpleultra",
                className =
                    "com.samsung.android.watch.watchface.simpleultra.SimpleUltraWatchFaceService",
                category = WatchFaceCategory.ULTRA,
            ),
            WatchFacePreset(
                id = "activitynumber",
                nameRes = R.string.watch_face_activitynumber,
                enName = "Activity Number",
                packageName = "com.samsung.android.watch.watchface.activitynumber",
                className =
                    "com.samsung.android.watch.watchface.activitynumber.ActivityNumberWatchFaceService",
                category = WatchFaceCategory.FITNESS,
            ),
            WatchFacePreset(
                id = "healthmodular",
                nameRes = R.string.watch_face_healthmodular,
                enName = "Health Modular",
                packageName = "com.samsung.android.watch.watchface.healthmodular",
                className =
                    "com.samsung.android.watch.watchface.healthmodular.HealthModularWatchFaceService",
                category = WatchFaceCategory.FITNESS,
            ),
            WatchFacePreset(
                id = "sleepcoaching",
                nameRes = R.string.watch_face_sleepcoaching,
                enName = "Sleep Coaching",
                packageName = "com.samsung.android.watch.watchface.sleepcoaching",
                className =
                    "com.samsung.android.watch.watchface.sleepcoaching.SleepCoachingWatchFaceService",
                category = WatchFaceCategory.FITNESS,
            ),
            WatchFacePreset(
                id = "infomodular",
                nameRes = R.string.watch_face_infomodular,
                enName = "Info Modular",
                packageName = "com.samsung.android.watch.watchface.infomodular",
                className =
                    "com.samsung.android.watch.watchface.infomodular.InfoModularWatchFaceService",
                category = WatchFaceCategory.INFORMATION,
            ),
            WatchFacePreset(
                id = "basicdashboard",
                nameRes = R.string.watch_face_basicdashboard,
                enName = "Basic Dashboard",
                packageName = "com.samsung.android.watch.watchface.basicdashboard",
                className =
                    "com.samsung.android.watch.watchface.basicdashboard.BasicDashboardWatchFaceService",
                category = WatchFaceCategory.INFORMATION,
            ),
            WatchFacePreset(
                id = "weather",
                nameRes = R.string.watch_face_weather,
                enName = "Weather",
                packageName = "com.samsung.android.watch.watchface.weather",
                className = "com.samsung.android.watch.watchface.weather.WeatherWatchFaceService",
                category = WatchFaceCategory.INFORMATION,
            ),
            WatchFacePreset(
                id = "simplecomplication",
                nameRes = R.string.watch_face_simplecomplication,
                enName = "Simple Complication",
                packageName = "com.samsung.android.watch.watchface.simplecomplication",
                className =
                    "com.samsung.android.watch.watchface.simplecomplication.SimpleComplicationWatchFaceService",
                category = WatchFaceCategory.INFORMATION,
            ),
            WatchFacePreset(
                id = "livewallpaper",
                nameRes = R.string.watch_face_livewallpaper,
                enName = "Live Wallpaper",
                packageName = "com.samsung.android.watch.watchface.livewallpaper",
                className =
                    "com.samsung.android.watch.watchface.livewallpaper.LiveWallpaperWatchFaceService",
                category = WatchFaceCategory.INFORMATION,
            ),
            WatchFacePreset(
                id = "analogmodular",
                nameRes = R.string.watch_face_analogmodular,
                enName = "Analog Modular",
                packageName = "com.samsung.android.watch.watchface.analogmodular",
                className =
                    "com.samsung.android.watch.watchface.analogmodular.AnalogModularWatchFaceService",
                category = WatchFaceCategory.ANALOG,
            ),
            WatchFacePreset(
                id = "premiumanalog",
                nameRes = R.string.watch_face_premiumanalog,
                enName = "Premium Analog",
                packageName = "com.samsung.android.watch.watchface.premiumanalog",
                className =
                    "com.samsung.android.watch.watchface.premiumanalog.PremiumAnalogWatchFaceService",
                category = WatchFaceCategory.ANALOG,
            ),
            WatchFacePreset(
                id = "perpetual",
                nameRes = R.string.watch_face_perpetual,
                enName = "Perpetual",
                packageName = "com.samsung.android.watch.watchface.perpetual",
                className =
                    "com.samsung.android.watch.watchface.perpetual.PerpetualWatchFaceService",
                category = WatchFaceCategory.ANALOG,
            ),
            WatchFacePreset(
                id = "simpleanalogue",
                nameRes = R.string.watch_face_simpleanalogue,
                enName = "Simple Analogue",
                packageName = "com.samsung.android.watch.watchface.simpleanalogue",
                className =
                    "com.samsung.android.watch.watchface.simpleanalogue.SimpleAnalogueWatchFaceService",
                category = WatchFaceCategory.ANALOG,
            ),
            WatchFacePreset(
                id = "simpleclassic",
                nameRes = R.string.watch_face_simpleclassic,
                enName = "Simple Classic",
                packageName = "com.samsung.android.watch.watchface.simpleclassic",
                className =
                    "com.samsung.android.watch.watchface.simpleclassic.SimpleClassicWatchFaceService",
                category = WatchFaceCategory.ANALOG,
            ),
            WatchFacePreset(
                id = "boldindex",
                nameRes = R.string.watch_face_boldindex,
                enName = "Bold Index",
                packageName = "com.samsung.android.watch.watchface.boldindex",
                className =
                    "com.samsung.android.watch.watchface.boldindex.BoldIndexWatchFaceService",
                category = WatchFaceCategory.ANALOG,
            ),
            WatchFacePreset(
                id = "stretchindex",
                nameRes = R.string.watch_face_stretchindex,
                enName = "Stretch Index",
                packageName = "com.samsung.android.watch.watchface.stretchindex",
                className =
                    "com.samsung.android.watch.watchface.stretchindex.StretchIndexWatchFaceService",
                category = WatchFaceCategory.ANALOG,
            ),
            WatchFacePreset(
                id = "dualwatch",
                nameRes = R.string.watch_face_dualwatch,
                enName = "Dual Watch",
                packageName = "com.samsung.android.watch.watchface.dualwatch",
                className =
                    "com.samsung.android.watch.watchface.dualwatch.DualWatchWatchFaceService",
                category = WatchFaceCategory.ANALOG,
            ),
            WatchFacePreset(
                id = "basicclock",
                nameRes = R.string.watch_face_basicclock,
                enName = "Basic Clock",
                packageName = "com.samsung.android.watch.watchface.basicclock",
                className =
                    "com.samsung.android.watch.watchface.basicclock.BasicClockWatchFaceService",
                category = WatchFaceCategory.PERSONAL,
            ),
            WatchFacePreset(
                id = "digitalmodular",
                nameRes = R.string.watch_face_digitalmodular,
                enName = "Digital Modular",
                packageName = "com.samsung.android.watch.watchface.digitalmodular",
                className =
                    "com.samsung.android.watch.watchface.digitalmodular.DigitalModularWatchFaceService",
                category = WatchFaceCategory.PERSONAL,
            ),
            WatchFacePreset(
                id = "digitalfont",
                nameRes = R.string.watch_face_digitalfont,
                enName = "Digital Font",
                packageName = "com.samsung.android.watch.watchface.digitalfont",
                className =
                    "com.samsung.android.watch.watchface.digitalfont.DigitalFontWatchFaceService",
                category = WatchFaceCategory.PERSONAL,
            ),
            WatchFacePreset(
                id = "gradientfont",
                nameRes = R.string.watch_face_gradientfont,
                enName = "Gradient Font",
                packageName = "com.samsung.android.watch.watchface.gradientfont",
                className =
                    "com.samsung.android.watch.watchface.gradientfont.GradientFontWatchFaceService",
                category = WatchFaceCategory.PERSONAL,
            ),
            WatchFacePreset(
                id = "analoguefont",
                nameRes = R.string.watch_face_analoguefont,
                enName = "Analogue Font",
                packageName = "com.samsung.android.watch.watchface.analoguefont",
                className =
                    "com.samsung.android.watch.watchface.analoguefont.AnalogueFontWatchFaceService",
                category = WatchFaceCategory.PERSONAL,
            ),
            WatchFacePreset(
                id = "dynamicfont",
                nameRes = R.string.watch_face_dynamicfont,
                enName = "Dynamic Font",
                packageName = "com.samsung.android.watch.watchface.dynamicfont",
                className =
                    "com.samsung.android.watch.watchface.dynamicfont.DynamicFontWatchFaceService",
                category = WatchFaceCategory.PERSONAL,
            ),
            WatchFacePreset(
                id = "large",
                nameRes = R.string.watch_face_large,
                enName = "Large",
                packageName = "com.samsung.android.watch.watchface.large",
                className = "com.samsung.android.watch.watchface.large.LargeWatchFaceService",
                category = WatchFaceCategory.PERSONAL,
            ),
            WatchFacePreset(
                id = "spatialnumber",
                nameRes = R.string.watch_face_spatialnumber,
                enName = "Spatial Number",
                packageName = "com.samsung.android.watch.watchface.spatialnumber",
                className =
                    "com.samsung.android.watch.watchface.spatialnumber.SpatialNumberWatchFaceService",
                category = WatchFaceCategory.PERSONAL,
            ),
            WatchFacePreset(
                id = "spherenumber",
                nameRes = R.string.watch_face_spherenumber,
                enName = "Sphere Number",
                packageName = "com.samsung.android.watch.watchface.spherenumber",
                className =
                    "com.samsung.android.watch.watchface.spherenumber.SphereNumberWatchFaceService",
                category = WatchFaceCategory.PERSONAL,
            ),
            WatchFacePreset(
                id = "superfiction",
                nameRes = R.string.watch_face_superfiction,
                enName = "Superfiction",
                packageName = "com.samsung.android.watch.watchface.superfiction",
                className =
                    "com.samsung.android.watch.watchface.superfiction.SuperfictionWatchFaceService",
                category = WatchFaceCategory.PERSONAL,
            ),
            WatchFacePreset(
                id = "together",
                nameRes = R.string.watch_face_together,
                enName = "Together",
                packageName = "com.samsung.android.watch.watchface.together",
                className = "com.samsung.android.watch.watchface.together.TogetherWatchFaceService",
                category = WatchFaceCategory.PERSONAL,
            ),
            WatchFacePreset(
                id = "typography",
                nameRes = R.string.watch_face_typography,
                enName = "Typography",
                packageName = "com.samsung.android.watch.watchface.typography",
                className =
                    "com.samsung.android.watch.watchface.typography.TypographyWatchFaceService",
                category = WatchFaceCategory.PERSONAL,
            ),
            WatchFacePreset(
                id = "bespoke",
                nameRes = R.string.watch_face_bespoke,
                enName = "Bespoke",
                packageName = "com.samsung.android.watch.watchface.bespoke",
                className = "com.samsung.android.watch.watchface.bespoke.BespokeWatchFaceService",
                category = WatchFaceCategory.PERSONAL,
            ),
            WatchFacePreset(
                id = "mystyle",
                nameRes = R.string.watch_face_mystyle,
                enName = "My Style",
                packageName = "com.samsung.android.watch.watchface.mystyle",
                className = "com.samsung.android.watch.watchface.mystyle.MyStyleWatchFaceService",
                category = WatchFaceCategory.PERSONAL,
            ),
            WatchFacePreset(
                id = "myphoto",
                nameRes = R.string.watch_face_myphoto,
                enName = "My Photo",
                packageName = "com.samsung.android.watch.watchface.myphoto",
                className = "com.samsung.android.watch.watchface.myphoto.MyPhotoWatchFaceService",
                category = WatchFaceCategory.PERSONAL,
            ),
            WatchFacePreset(
                id = "photosticker",
                nameRes = R.string.watch_face_photosticker,
                enName = "Photo Sticker",
                packageName = "com.samsung.android.watch.watchface.photosticker",
                className =
                    "com.samsung.android.watch.watchface.photosticker.PhotoStickerWatchFaceService",
                category = WatchFaceCategory.PERSONAL,
            ),
            WatchFacePreset(
                id = "aremoji",
                nameRes = R.string.watch_face_aremoji,
                enName = "AR Emoji",
                packageName = "com.samsung.android.watch.watchface.aremoji",
                className = "com.samsung.android.watch.watchface.aremoji.AREmojiWatchFaceService",
                category = WatchFaceCategory.PERSONAL,
            ),
            WatchFacePreset(
                id = "bitmoji",
                nameRes = R.string.watch_face_bitmoji,
                enName = "Bitmoji",
                packageName = "com.samsung.android.watch.watchface.bitmoji",
                className = "com.samsung.android.watch.watchface.bitmoji.BitmojiWatchFaceService",
                category = WatchFaceCategory.PERSONAL,
            ),
            WatchFacePreset(
                id = "face",
                nameRes = R.string.watch_face_face,
                enName = "Face",
                packageName = "com.samsung.android.watch.watchface.face",
                className = "com.samsung.android.watch.watchface.face.FaceWatchFaceService",
                category = WatchFaceCategory.PERSONAL,
            ),
            WatchFacePreset(
                id = "animal",
                nameRes = R.string.watch_face_animal,
                enName = "Animal",
                packageName = "com.samsung.android.watch.watchface.animal",
                className = "com.samsung.android.watch.watchface.animal.AnimalWatchFaceService",
                category = WatchFaceCategory.PERSONAL,
            ),
            WatchFacePreset(
                id = "endangeredanimal",
                nameRes = R.string.watch_face_endangeredanimal,
                enName = "Endangered Animal",
                packageName = "com.samsung.android.watch.watchface.endangeredanimal",
                className =
                    "com.samsung.android.watch.watchface.endangeredanimal.EndangeredAnimalWatchFaceService",
                category = WatchFaceCategory.PERSONAL,
            ),
            WatchFacePreset(
                id = "flowergarden",
                nameRes = R.string.watch_face_flowergarden,
                enName = "Flower Garden",
                packageName = "com.samsung.android.watch.watchface.flowergarden",
                className =
                    "com.samsung.android.watch.watchface.flowergarden.FlowerGardenWatchFaceService",
                category = WatchFaceCategory.PERSONAL,
            ),
            WatchFacePreset(
                id = "mypebble",
                nameRes = R.string.watch_face_mypebble,
                enName = "My Pebble",
                packageName = "com.samsung.android.watch.watchface.mypebble",
                className = "com.samsung.android.watch.watchface.mypebble.MyPebbleWatchFaceService",
                category = WatchFaceCategory.PERSONAL,
            ),
            WatchFacePreset(
                id = "simpledigital",
                nameRes = R.string.watch_face_simpledigital,
                enName = "Simple Digital",
                packageName = "com.samsung.android.watch.watchface.simpledigital",
                className =
                    "com.samsung.android.watch.watchface.simpledigital.SimpleDigitalWatchFaceService",
                category = WatchFaceCategory.PERSONAL,
            ),
        )

    fun byId(id: String): WatchFacePreset? {
        val key = id.lowercase(java.util.Locale.ROOT).replace("_", "")
        return ALL.firstOrNull { it.id == key }
    }

    fun find(packageName: String?, className: String?): WatchFacePreset? =
        ALL.firstOrNull { preset ->
            (packageName != null && preset.packageName == packageName) ||
                (className != null && preset.className == className)
        }
}
