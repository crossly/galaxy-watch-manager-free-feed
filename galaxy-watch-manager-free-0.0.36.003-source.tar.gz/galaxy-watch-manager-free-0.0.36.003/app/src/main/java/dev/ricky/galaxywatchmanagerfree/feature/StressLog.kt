package dev.ricky.galaxywatchmanagerfree.feature

import java.time.Instant
import java.time.ZoneId
import kotlin.math.roundToInt
import org.json.JSONArray
import org.json.JSONObject

/**
 * 压力历史与统计（纯逻辑）。
 *
 * 数据来自 `com.samsung.shealth.stress`：连续测量记录通常带一小时的 `start_time` / `end_time`， 并以
 * `binning_data`（Base64 gzip JSON 数组）保存每次真实采样；单次测量记录没有分箱，外层 `score` 就是真实测量值。
 * 有分箱时展开分箱并丢弃外层小时聚合，避免同一份数据既算一条汇总又算子项。测量时间只取 `start_time` （缺失时才用 `end_time`），绝不回退到 `create_time` /
 * `update_time`——后两者是同步/入库时间。
 *
 * 官方分类阈值来自 watch-shealth `EnumC5133it2`：0–10 Relaxed、11–20 Low、21–80 Moderate、 81–100 High。原始 score
 * 是小数，必须先按原始值分类再考虑显示取整：10.4 属于 Low、80.4 属于 High。 官方显示另有 0–25/26–50/51–75/76–100
 * 的缩放映射，不能拿缩放区间去分类原始记录。0 是合法分数 （Relaxed），缺失或越界必须保持未知而不是补 0。
 */
object StressLog {

    const val MODULE = "com.samsung.shealth.stress"
    const val MIN_SCORE = 0f
    const val MAX_SCORE = 100f

    /** 官方原始 score 分类（不是显示缩放值）；上界仅在等于该值时归入本档。 */
    enum class Level(val min: Float, val max: Float) {
        RELAXED(0f, 10f),
        LOW(10f, 20f),
        MODERATE(20f, 80f),
        HIGH(80f, 100f);

        companion object {
            fun of(score: Float?): Level? =
                when {
                    score == null || !score.isFinite() || score < 0f || score > 100f -> null
                    score <= RELAXED.max -> RELAXED
                    score <= LOW.max -> LOW
                    score <= MODERATE.max -> MODERATE
                    else -> HIGH
                }
        }
    }

    /** 单次压力读数；[score]/[min]/[max] 保留源记录精度，不提前取整。 */
    data class Point(
        val ts: Long,
        val score: Float,
        val min: Float = score,
        val max: Float = score,
    )

    data class Stats(val min: Float, val max: Float, val avg: Float, val count: Int)

    private fun tsOf(record: JSONObject): Long =
        listOf("start_time", "com.samsung.shealth.stress.start_time", "end_time")
            .firstNotNullOfOrNull { key -> record.optLong(key, 0L).takeIf { it > 0L } } ?: 0L

    private fun floatOf(record: JSONObject, vararg keys: String): Float? =
        keys.firstNotNullOfOrNull { key ->
            if (!record.has(key) || record.isNull(key)) null
            else record.optDouble(key, Double.NaN).takeIf { it.isFinite() }?.toFloat()
        }

    private fun pointOf(
        record: JSONObject,
        scoreKeys: Array<String> =
            arrayOf("score", "com.samsung.shealth.stress.score", "stress_score"),
        minKeys: Array<String> = arrayOf("min", "score_min", "com.samsung.shealth.stress.min"),
        maxKeys: Array<String> = arrayOf("max", "score_max", "com.samsung.shealth.stress.max"),
    ): Point? {
        val ts = tsOf(record)
        if (ts <= 0L) return null
        val score =
            floatOf(record, *scoreKeys)?.takeIf { it in MIN_SCORE..MAX_SCORE } ?: return null
        val low = (floatOf(record, *minKeys) ?: score).coerceIn(MIN_SCORE, score)
        val high = (floatOf(record, *maxKeys) ?: score).coerceIn(score, MAX_SCORE)
        return Point(ts, score, low, high)
    }

    /** 报表记录 → 真实读数；有分箱时展开分箱并丢弃外层聚合。 */
    fun pointsFromRecords(records: List<JSONObject>): List<Point> =
        records.flatMap { record ->
            val bins =
                HealthJson.array(record.opt("binning_data"))
                    ?: HealthJson.array(record.opt("binning"))
            val detailed =
                bins
                    ?.let { array ->
                        (0 until array.length()).mapNotNull { index ->
                            val bin = array.optJSONObject(index) ?: return@mapNotNull null
                            pointOf(
                                bin,
                                arrayOf("score", "com.samsung.shealth.stress.score"),
                                arrayOf("score_min", "min"),
                                arrayOf("score_max", "max"),
                            )
                        }
                    }
                    .orEmpty()
            if (detailed.isNotEmpty()) detailed else listOfNotNull(pointOf(record))
        }

    /** 去重、按时间排序并按留存窗口裁剪；同一时间戳保留后到的一条。 */
    fun normalized(
        points: List<Point>,
        nowMillis: Long,
        keepMillis: Long = 30 * 24 * 3_600_000L,
        cap: Int = 20_000,
    ): List<Point> {
        val cutoff = nowMillis - keepMillis
        return points
            .filter {
                it.ts in cutoff..nowMillis &&
                    it.score.isFinite() &&
                    it.score in MIN_SCORE..MAX_SCORE
            }
            .associateBy { it.ts }
            .values
            .sortedBy { it.ts }
            .takeLast(cap)
    }

    fun stats(points: List<Point>): Stats? {
        val valid = points.filter { it.score.isFinite() && it.score in MIN_SCORE..MAX_SCORE }
        if (valid.isEmpty()) return null
        val sum = valid.sumOf { it.score.toDouble() }
        return Stats(
            min = valid.minOf { it.min.coerceIn(MIN_SCORE, it.score) },
            max = valid.maxOf { it.max.coerceIn(it.score, MAX_SCORE) },
            avg = (sum / valid.size).toFloat(),
            count = valid.size,
        )
    }

    /** 仅用于兼容仍以 Int 保存的旧字段；分类必须使用原始 Float score。 */
    fun roundedScore(point: Point): Int = point.score.roundToInt()

    private fun dayOf(ts: Long, zone: ZoneId = ZoneId.systemDefault()): String =
        runCatching { Instant.ofEpochMilli(ts).atZone(zone).toLocalDate().toString() }
            .getOrDefault("")

    /** 按本地日期归组，每天升序排列。 */
    fun byDay(
        points: List<Point>,
        zone: ZoneId = ZoneId.systemDefault(),
    ): Map<String, List<Point>> =
        points
            .groupBy { dayOf(it.ts, zone) }
            .filterKeys { it.isNotEmpty() }
            .mapValues { (_, dayPoints) -> dayPoints.sortedBy { it.ts } }

    // Serialization

    fun encodePoints(points: List<Point>): String {
        val array = JSONArray()
        points.forEach {
            array.put(
                JSONArray()
                    .put(it.ts)
                    .put(it.score.toDouble())
                    .put(it.min.toDouble())
                    .put(it.max.toDouble())
            )
        }
        return array.toString()
    }

    fun decodePoints(raw: String?): List<Point> {
        if (raw.isNullOrBlank()) return emptyList()
        val array = runCatching { JSONArray(raw) }.getOrNull() ?: return emptyList()
        return (0 until array.length()).mapNotNull { index ->
            val item = array.optJSONArray(index) ?: return@mapNotNull null
            val ts = item.optLong(0)
            val score = item.optDouble(1, Double.NaN).toFloat()
            if (ts <= 0L || !score.isFinite() || score !in MIN_SCORE..MAX_SCORE)
                return@mapNotNull null
            val min = item.optDouble(2, score.toDouble()).toFloat().coerceIn(MIN_SCORE, score)
            val max = item.optDouble(3, score.toDouble()).toFloat().coerceIn(score, MAX_SCORE)
            Point(ts, score, min, max)
        }
    }

    fun encodeDays(days: Map<String, Stats>): String {
        val root = JSONObject()
        days.toSortedMap().forEach { (day, stats) ->
            root.put(
                day,
                JSONArray()
                    .put(stats.min.toDouble())
                    .put(stats.avg.toDouble())
                    .put(stats.max.toDouble())
                    .put(stats.count),
            )
        }
        return root.toString()
    }

    fun decodeDays(raw: String?): MutableMap<String, Stats> {
        val result = mutableMapOf<String, Stats>()
        if (raw.isNullOrBlank()) return result
        val root = runCatching { JSONObject(raw) }.getOrNull() ?: return result
        root.keys().forEach { day ->
            val array = root.optJSONArray(day) ?: return@forEach
            val min = array.optDouble(0, Double.NaN).toFloat()
            val avg = array.optDouble(1, Double.NaN).toFloat()
            val max = array.optDouble(2, Double.NaN).toFloat()
            if (
                min.isFinite() &&
                    max.isFinite() &&
                    min in MIN_SCORE..MAX_SCORE &&
                    max in MIN_SCORE..MAX_SCORE
            ) {
                result[day] =
                    Stats(
                        min = min,
                        avg = if (avg.isFinite()) avg.coerceIn(MIN_SCORE, MAX_SCORE) else min,
                        max = max,
                        count = array.optInt(3),
                    )
            }
        }
        return result
    }
}
