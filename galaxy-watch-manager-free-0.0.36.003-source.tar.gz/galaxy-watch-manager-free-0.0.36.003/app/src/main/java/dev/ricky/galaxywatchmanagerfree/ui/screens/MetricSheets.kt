package dev.ricky.galaxywatchmanagerfree.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Air
import androidx.compose.material.icons.filled.Bloodtype
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.MonitorHeart
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SportsScore
import androidx.compose.material.icons.filled.Stairs
import androidx.compose.material.icons.filled.Terrain
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.feature.ExerciseLog
import dev.ricky.galaxywatchmanagerfree.feature.ExerciseTypes
import dev.ricky.galaxywatchmanagerfree.feature.HealthMetric
import dev.ricky.galaxywatchmanagerfree.feature.HealthMetricLog
import dev.ricky.galaxywatchmanagerfree.ui.components.AppBottomSheet
import dev.ricky.galaxywatchmanagerfree.ui.components.GroupedCard
import dev.ricky.galaxywatchmanagerfree.ui.components.MetricLineChart
import dev.ricky.galaxywatchmanagerfree.ui.components.MetricWeekBars
import dev.ricky.galaxywatchmanagerfree.ui.components.pressFeedback
import dev.ricky.galaxywatchmanagerfree.ui.theme.CardSurfaceElevated
import dev.ricky.galaxywatchmanagerfree.ui.theme.HealthHrv
import dev.ricky.galaxywatchmanagerfree.ui.theme.HealthOxygen
import dev.ricky.galaxywatchmanagerfree.ui.theme.HealthRespiratory
import dev.ricky.galaxywatchmanagerfree.ui.theme.HealthSteps
import dev.ricky.galaxywatchmanagerfree.ui.theme.HealthTemperature
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextPrimary
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextSecondary
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextTertiary
import dev.ricky.galaxywatchmanagerfree.ui.theme.tonalSurface

@Composable
fun metricIcon(metric: HealthMetric): ImageVector =
    when (metric) {
        HealthMetric.SPO2 -> Icons.Default.Bloodtype
        HealthMetric.SKIN_TEMP -> Icons.Default.Thermostat
        HealthMetric.RESPIRATORY -> Icons.Default.Air
        HealthMetric.HRV -> Icons.Default.MonitorHeart
    }

@Composable
fun metricColor(metric: HealthMetric): Color =
    when (metric) {
        HealthMetric.SPO2 -> HealthOxygen
        HealthMetric.SKIN_TEMP -> HealthTemperature
        HealthMetric.RESPIRATORY -> HealthRespiratory
        HealthMetric.HRV -> HealthHrv
    }

/** 指标详情：今日采样曲线 + 近 7 天趋势 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MetricSheet(
    metric: HealthMetric,
    samples: List<HealthMetricLog.Sample>,
    onDismiss: () -> Unit,
) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val day = java.time.LocalDate.now()
    val zone = java.time.ZoneId.systemDefault()
    val daily = HealthMetricLog.daily(samples, day, zone)
    val stats = daily.stats
    val latest = HealthMetricLog.latest(samples)
    val accent = metricColor(metric)

    AppBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        LazyColumn(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item {
                dev.ricky.galaxywatchmanagerfree.ui.components.SheetToolbar(
                    strings.getString(metric.labelRes),
                    onDismiss,
                )
            }

            // 核心统计卡片
            item {
                GroupedCard(innerPadding = 16.dp) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom,
                    ) {
                        Column {
                            Text(
                                strings.getString(R.string.latest_record),
                                style =
                                    androidx.compose.material3.MaterialTheme.typography.labelMedium,
                                color = TextTertiary,
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Row(verticalAlignment = Alignment.Bottom) {
                                Text(
                                    text = latest?.let { metric.format(it.value) } ?: "—",
                                    style =
                                        androidx.compose.material3.MaterialTheme.typography
                                            .headlineLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = accent,
                                    fontFamily = FontFamily.Monospace,
                                )
                                Text(
                                    text = " ${strings.getString(metric.unitRes)}",
                                    style =
                                        androidx.compose.material3.MaterialTheme.typography
                                            .labelMedium,
                                    color = TextSecondary,
                                    modifier = Modifier.padding(bottom = 6.dp),
                                )
                            }
                        }

                        if (stats != null) {
                            Box(
                                modifier =
                                    Modifier.clip(RoundedCornerShape(999.dp))
                                        .background(accent.copy(alpha = 0.12f))
                                        .padding(horizontal = 10.dp, vertical = 5.dp)
                            ) {
                                Text(
                                    text =
                                        androidx.compose.ui.res.stringResource(
                                            dev.ricky.galaxywatchmanagerfree.R.string
                                                .metric_today_average,
                                            stats.format(metric, stats.avg),
                                            strings.getString(metric.unitRes),
                                        ),
                                    style =
                                        androidx.compose.material3.MaterialTheme.typography
                                            .labelMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = accent,
                                )
                            }
                        }
                    }

                    latest?.let {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            strings.getString(
                                R.string.metric_measured_at,
                                dev.ricky.galaxywatchmanagerfree.ui.components.formatRecordTime(
                                    it.ts
                                ),
                            ),
                            style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        strings.getString(R.string.metric_sync_explanation),
                        style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                    )

                    if (stats != null) {
                        Spacer(modifier = Modifier.height(14.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            MetricStatCell(
                                strings.getString(R.string.minimum),
                                stats.format(metric, stats.min),
                                strings.getString(metric.unitRes),
                                Modifier.weight(1f),
                            )
                            MetricStatCell(
                                strings.getString(R.string.average),
                                stats.format(metric, stats.avg),
                                strings.getString(metric.unitRes),
                                Modifier.weight(1f),
                            )
                            MetricStatCell(
                                strings.getString(R.string.maximum),
                                stats.format(metric, stats.max),
                                strings.getString(metric.unitRes),
                                Modifier.weight(1f),
                            )
                        }
                    }
                }
            }

            // 今日采样曲线
            if (samples.isNotEmpty()) {
                item {
                    GroupedCard(innerPadding = 16.dp) {
                        Text(
                            androidx.compose.ui.res.stringResource(
                                dev.ricky.galaxywatchmanagerfree.R.string.metric_today_samples
                            ),
                            style = androidx.compose.material3.MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        if (daily.samples.isEmpty()) {
                            Text(
                                androidx.compose.ui.res.stringResource(
                                    dev.ricky.galaxywatchmanagerfree.R.string
                                        .metric_no_samples_today
                                ),
                                style =
                                    androidx.compose.material3.MaterialTheme.typography.bodySmall,
                                color = TextTertiary,
                            )
                        } else
                            MetricLineChart(
                                samples = daily.samples,
                                metric = metric,
                                accent = accent,
                                day = day,
                                zone = zone,
                            )
                    }
                }

                // 近 7 天日均趋势
                item {
                    GroupedCard(innerPadding = 16.dp) {
                        Text(
                            strings.getString(R.string.past_7_days),
                            style = androidx.compose.material3.MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        MetricWeekBars(
                            values = HealthMetricLog.weekly(samples, java.time.LocalDate.now()),
                            metric = metric,
                            accent = accent,
                        )
                    }
                }
            } else {
                item {
                    GroupedCard {
                        Box(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 28.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                strings.getString(R.string.health_trend_empty),
                                style =
                                    androidx.compose.material3.MaterialTheme.typography.bodySmall,
                                color = TextTertiary,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricStatCell(
    label: String,
    value: String,
    unit: String,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier =
            modifier
                .clip(RoundedCornerShape(12.dp))
                .background(CardSurfaceElevated)
                .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    text = value,
                    style = androidx.compose.material3.MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    fontFamily = FontFamily.Monospace,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                )
                Text(
                    text = unit,
                    style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                    color = TextTertiary,
                    modifier = Modifier.padding(start = 2.dp, bottom = 2.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                )
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                label,
                style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                color = TextTertiary,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            )
        }
    }
}

/** Exercise totals use the watch's summary distance in meters, never accumulated live samples. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExerciseSheet(
    sessions: List<ExerciseLog.Session>,
    onDismiss: () -> Unit,
    onRefresh: (() -> Unit)? = null,
    syncing: Boolean = false,
) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources
    var selectedType by
        androidx.compose.runtime.saveable.rememberSaveable { mutableStateOf<Int?>(null) }
    val workouts =
        androidx.compose.runtime.remember(sessions) {
            ExerciseLog.topLevel(sessions).sortedByDescending { it.startMillis }
        }
    val types = workouts.map { it.typeCode }.distinct()
    val selected =
        workouts.filter {
            selectedType == null || selectedType !in types || it.typeCode == selectedType
        }
    val zone = java.time.ZoneId.systemDefault()

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    AppBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        LazyColumn(
            contentPadding =
                androidx.compose.foundation.layout.PaddingValues(
                    start = 20.dp,
                    end = 20.dp,
                    bottom = 32.dp,
                ),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item {
                dev.ricky.galaxywatchmanagerfree.ui.components.SheetToolbar(
                    strings.getString(R.string.workout_history),
                    onDismiss,
                )
            }
            item {
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text(
                        strings.getString(R.string.exercise_history_scope),
                        style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        modifier = Modifier.weight(1f),
                    )
                    if (onRefresh != null)
                        androidx.compose.material3.TextButton(
                            onClick = onRefresh,
                            enabled = !syncing,
                        ) {
                            if (syncing) {
                                androidx.compose.material3.CircularProgressIndicator(
                                    modifier = Modifier.size(14.dp),
                                    strokeWidth = 2.dp,
                                )
                                Spacer(Modifier.width(6.dp))
                            } else {
                                Icon(Icons.Default.Refresh, null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                            }
                            Text(
                                strings.getString(
                                    if (syncing) R.string.syncing
                                    else R.string.exercise_sync_history
                                )
                            )
                        }
                }
                if (types.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Row(
                        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        WorkoutFilterChip(
                            label = strings.getString(R.string.exercise_all_types),
                            icon = Icons.Default.SportsScore,
                            selected = selectedType == null,
                            color = HealthSteps,
                            onClick = { selectedType = null },
                        )
                        types.forEach { type ->
                            WorkoutFilterChip(
                                label = strings.getString(ExerciseLog.typeNameRes(type), type),
                                icon = ExerciseTypes.icon(type),
                                selected = selectedType == type,
                                color = ExerciseTypes.accentColor(type),
                                onClick = {
                                    selectedType = if (selectedType == type) null else type
                                },
                            )
                        }
                    }
                }
            }
            if (selected.isEmpty()) {
                item {
                    GroupedCard {
                        Text(
                            strings.getString(R.string.completed_workouts_sync_from_your_watch),
                            style = androidx.compose.material3.MaterialTheme.typography.bodyMedium,
                            color = TextSecondary,
                        )
                    }
                }
            } else {
                item {
                    GroupedCard(
                        backgroundColor =
                            dev.ricky.galaxywatchmanagerfree.ui.theme.tonalSurface(
                                HealthSteps,
                                0.05f,
                            ),
                        accent = HealthSteps,
                        cornerRadius = 24.dp,
                        innerPadding = 18.dp,
                    ) {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top,
                        ) {
                            Column {
                                Text(
                                    strings.getQuantityString(
                                        R.plurals.workout_count,
                                        selected.size,
                                        selected.size,
                                    ),
                                    style =
                                        androidx.compose.material3.MaterialTheme.typography
                                            .bodyMedium,
                                    color = TextSecondary,
                                )
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    strings.getString(
                                        R.string.workout_duration,
                                        selected.sumOf { it.durationMillis } / 60_000,
                                        selected.sumOf { it.durationMillis } % 60_000 / 1000,
                                    ),
                                    style =
                                        androidx.compose.material3.MaterialTheme.typography
                                            .headlineMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary,
                                )
                            }
                            if (selected.any { it.calories >= 0 }) {
                                Box(
                                    Modifier.clip(RoundedCornerShape(14.dp))
                                        .background(CardSurfaceElevated)
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        strings.getString(
                                            R.string.exercise_energy_value,
                                            selected.sumOf { it.calories.coerceAtLeast(0) },
                                        ),
                                        style =
                                            androidx.compose.material3.MaterialTheme.typography
                                                .titleSmall,
                                        fontWeight = FontWeight.SemiBold,
                                        color = HealthSteps,
                                    )
                                }
                            }
                        }
                        if (selected.any { it.distanceMeters > 0 }) {
                            Spacer(Modifier.height(10.dp))
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                            ) {
                                Icon(
                                    Icons.Default.Terrain,
                                    null,
                                    tint = TextSecondary,
                                    modifier = Modifier.size(16.dp),
                                )
                                Text(
                                    strings
                                        .getString(R.string.distance_kilometers)
                                        .format(
                                            selected.sumOf {
                                                it.distanceMeters.coerceAtLeast(0.0)
                                            } / 1000.0
                                        ),
                                    style =
                                        androidx.compose.material3.MaterialTheme.typography
                                            .bodyMedium,
                                    color = TextSecondary,
                                )
                            }
                        }
                    }
                }
                selected
                    .groupBy {
                        java.time.Instant.ofEpochMilli(it.startMillis).atZone(zone).toLocalDate()
                    }
                    .forEach { (day, records) ->
                        item(key = "day_$day") {
                            Text(
                                day.format(
                                    java.time.format.DateTimeFormatter.ofLocalizedDate(
                                            java.time.format.FormatStyle.MEDIUM
                                        )
                                        .withLocale(strings.configuration.locales[0])
                                ),
                                style =
                                    androidx.compose.material3.MaterialTheme.typography.titleSmall,
                                color = TextSecondary,
                            )
                        }
                        items(records, key = { it.id }) { session ->
                            ExerciseRow(
                                session,
                                activities =
                                    sessions.filter {
                                        it.routineId == session.id && it.id != session.id
                                    },
                            )
                        }
                    }
            }
        }
    }
}

@Composable
private fun WorkoutFilterChip(
    label: String,
    icon: ImageVector,
    selected: Boolean,
    color: Color,
    onClick: () -> Unit,
) {
    val dark = androidx.compose.material3.MaterialTheme.colorScheme.surface.luminance() < 0.5f
    val effectiveColor =
        if (dark || color.luminance() <= 0.45f) color
        else {
            Color(
                red = color.red * 0.65f,
                green = color.green * 0.65f,
                blue = color.blue * 0.65f,
                alpha = color.alpha,
            )
        }
    val background by
        androidx.compose.animation.animateColorAsState(
            if (selected) effectiveColor.copy(alpha = 0.18f) else CardSurfaceElevated,
            label = "chipBg",
        )
    val contentColor = if (selected) effectiveColor else TextSecondary
    Row(
        Modifier.clip(CircleShape)
            .background(background)
            .pressFeedback(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Icon(icon, null, tint = contentColor, modifier = Modifier.size(16.dp))
        Text(
            label,
            style = androidx.compose.material3.MaterialTheme.typography.labelMedium,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            color = contentColor,
        )
    }
}

@Composable
fun ExerciseRow(
    session: ExerciseLog.Session,
    modifier: Modifier = Modifier,
    activities: List<ExerciseLog.Session> = emptyList(),
) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources

    var expanded by
        androidx.compose.runtime.saveable.rememberSaveable(session.id) { mutableStateOf(false) }
    val zone = java.time.ZoneId.systemDefault()
    val start = java.time.Instant.ofEpochMilli(session.startMillis).atZone(zone)
    val end = java.time.Instant.ofEpochMilli(session.endMillis).atZone(zone)
    val date =
        start.format(
            java.time.format.DateTimeFormatter.ofPattern(
                strings.getString(R.string.mmm_d_hh_mm),
                strings.configuration.locales[0],
            )
        )
    val endText =
        end.format(
            java.time.format.DateTimeFormatter.ofPattern(
                if (start.toLocalDate() == end.toLocalDate()) "HH:mm"
                else strings.getString(R.string.mmm_d_hh_mm),
                strings.configuration.locales[0],
            )
        )
    val accent = session.accentColor

    GroupedCard(
        modifier = modifier,
        cornerRadius = 24.dp,
        innerPadding = 18.dp,
        backgroundColor = dev.ricky.galaxywatchmanagerfree.ui.theme.tonalSurface(accent, 0.04f),
        accent = accent,
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Box(
                Modifier.size(42.dp).clip(CircleShape).background(accent.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(session.icon, null, tint = accent, modifier = Modifier.size(22.dp))
            }
            Column(Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Text(
                        session.title.ifBlank {
                            strings.getString(session.typeNameRes, session.typeCode)
                        },
                        modifier = Modifier.weight(1f, fill = false),
                        style = androidx.compose.material3.MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary,
                    )
                    if (session.autoDetected)
                        Box(
                            Modifier.clip(CircleShape)
                                .background(CardSurfaceElevated)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                strings.getString(R.string.auto_detected),
                                style =
                                    androidx.compose.material3.MaterialTheme.typography.labelSmall,
                                color = TextSecondary,
                            )
                        }
                }
                Spacer(Modifier.height(2.dp))
                Text(
                    "$date – $endText",
                    style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                )
            }
        }
        Spacer(Modifier.height(14.dp))
        Text(
            if (session.distanceMeters > 0)
                strings
                    .getString(R.string.distance_kilometers)
                    .format(session.distanceMeters / 1000.0)
            else
                strings.getString(
                    R.string.workout_duration,
                    session.durationMillis / 60_000,
                    session.durationMillis % 60_000 / 1000,
                ),
            style = androidx.compose.material3.MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.SemiBold,
            color = TextPrimary,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            listOfNotNull(
                    if (session.distanceMeters > 0)
                        strings.getString(
                            R.string.workout_duration,
                            session.durationMillis / 60_000,
                            session.durationMillis % 60_000 / 1000,
                        )
                    else null,
                    session.calories
                        .takeIf { it >= 0 }
                        ?.let { strings.getString(R.string.exercise_energy_value, it) },
                )
                .joinToString(" · "),
            style = androidx.compose.material3.MaterialTheme.typography.bodyMedium,
            color = TextSecondary,
        )
        val hasBadges =
            session.stepCount >= 0 ||
                (session.count >= 0 && session.countType in 30002..30004) ||
                session.locationPointCount > 0
        if (hasBadges) {
            Spacer(Modifier.height(10.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (session.stepCount >= 0) {
                    WorkoutBadge(strings.getString(R.string.exercise_step_count, session.stepCount))
                }
                if (session.count >= 0 && session.countType in 30002..30004) {
                    WorkoutBadge(
                        strings.getString(
                            when (session.countType) {
                                30002 -> R.string.exercise_strokes
                                30003 -> R.string.exercise_swings
                                else -> R.string.exercise_repetitions
                            },
                            session.count,
                        )
                    )
                }
                if (session.locationPointCount > 0) {
                    WorkoutBadge(
                        strings.getString(
                            R.string.exercise_location_count,
                            session.locationPointCount,
                        )
                    )
                }
            }
        }
        val routeRelevant =
            session.locationPayloadPresent ||
                session.typeCode in
                    setOf(1001, 1002, 1007, 1008, 11007, 13001, 13002, 13003, 13004, 13005, 9014001)
        Spacer(Modifier.height(10.dp))
        if (routeRelevant)
            Text(
                when {
                    session.locationPointCount > 0 ->
                        strings.getString(
                            R.string.exercise_location_count,
                            session.locationPointCount,
                        )
                    session.locationPayloadPresent ->
                        strings.getString(R.string.workout_route_unsupported)
                    else -> strings.getString(R.string.no_route_received)
                },
                style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                color = TextTertiary,
            )
        Spacer(Modifier.height(4.dp))
        androidx.compose.material3.TextButton(onClick = { expanded = !expanded }) {
            Text(
                if (expanded) strings.getString(R.string.hide_details)
                else strings.getString(R.string.view_details)
            )
            Spacer(Modifier.width(4.dp))
            Icon(
                if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                null,
                modifier = Modifier.size(18.dp),
            )
        }
        if (expanded) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (session.distanceMeters >= 0)
                    Text(
                        strings.getString(R.string.distance_meters).format(session.distanceMeters),
                        style = androidx.compose.material3.MaterialTheme.typography.bodyMedium,
                        color = TextPrimary,
                    )
                if (session.avgHeartRate > 0)
                    Text(
                        strings.getString(R.string.exercise_average_hr, session.avgHeartRate),
                        style = androidx.compose.material3.MaterialTheme.typography.bodyMedium,
                        color = TextPrimary,
                    )
                if (session.maxHeartRate > 0)
                    Text(
                        strings.getString(R.string.exercise_maximum_hr, session.maxHeartRate),
                        style = androidx.compose.material3.MaterialTheme.typography.bodyMedium,
                        color = TextPrimary,
                    )
                if (
                    session.meanSpeed > 0 ||
                        session.durationMillis > 0 && session.distanceMeters > 0
                ) {
                    Text(
                        strings
                            .getString(R.string.average_speed_km_h)
                            .format(
                                if (session.meanSpeed > 0) session.meanSpeed * 3.6
                                else session.distanceMeters * 3600 / session.durationMillis
                            ),
                        style = androidx.compose.material3.MaterialTheme.typography.bodyMedium,
                        color = TextPrimary,
                    )
                }
                Text(
                    strings.getString(R.string.workout_duration_explanation),
                    style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                    lineHeight = 18.sp,
                    color = TextSecondary,
                )
                if (session.minHeartRate > 0)
                    Text(
                        strings.getString(R.string.exercise_minimum_hr, session.minHeartRate),
                        color = TextPrimary,
                    )
                if (session.maxSpeed > 0)
                    Text(
                        strings.getString(R.string.exercise_maximum_speed, session.maxSpeed * 3.6),
                        color = TextPrimary,
                    )
                if (session.altitudeGain >= 0)
                    Text(
                        strings.getString(R.string.exercise_elevation_gain, session.altitudeGain),
                        color = TextPrimary,
                    )
                if (session.altitudeLoss >= 0)
                    Text(
                        strings.getString(R.string.exercise_elevation_loss, session.altitudeLoss),
                        color = TextPrimary,
                    )
                if (activities.isNotEmpty()) {
                    Text(
                        strings.getString(R.string.exercise_routine_activities),
                        fontWeight = FontWeight.SemiBold,
                        color = TextSecondary,
                    )
                    activities
                        .sortedBy { it.startMillis }
                        .forEach { activity ->
                            Text(
                                activity.title.ifBlank {
                                    strings.getString(activity.typeNameRes, activity.typeCode)
                                } +
                                    " · " +
                                    strings.getString(
                                        R.string.workout_duration,
                                        activity.durationMillis / 60_000,
                                        activity.durationMillis % 60_000 / 1000,
                                    ),
                                color = TextPrimary,
                            )
                        }
                }
                if (routeRelevant && !session.locationPayloadPresent)
                    Text(
                        strings.getString(R.string.workout_route_missing),
                        style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                        lineHeight = 18.sp,
                        color = TextSecondary,
                    )
            }
        }
    }
}

@Composable
private fun WorkoutBadge(text: String) {
    Box(
        Modifier.clip(RoundedCornerShape(8.dp))
            .background(CardSurfaceElevated)
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text,
            style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
            color = TextSecondary,
        )
    }
}

@Composable fun stairsIcon(): ImageVector = Icons.Default.Stairs
