package dev.ricky.galaxywatchmanagerfree.core

import android.content.Context
import androidx.annotation.MainThread
import dev.ricky.galaxywatchmanagerfree.BuildConfig
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.feature.LogBus
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

object UpdateChecker {
    private const val FEED_BASE =
        "https://raw.githubusercontent.com/crossly/galaxy-watch-manager-free-feed/main/"
    const val FEED_URL = "${FEED_BASE}version.json"
    const val RELEASES_URL = "https://github.com/crossly/galaxy-watch-manager-free/releases"

    private const val PREFS = "watchfree_update"
    private const val KEY_CHANNEL = "channel"
    private const val KEY_LAST_CHECK = "last_check_at"
    private const val KEY_DEBUG_FEED = "debug_feed_url"
    private const val KEY_AUTO_HOURS = "auto_check_hours"
    private const val KEY_MIRROR = "download_mirror"
    const val DEFAULT_AUTO_HOURS = 12
    const val AUTO_HOURS_DISABLED = 0
    val AUTO_HOURS_OPTIONS = listOf(AUTO_HOURS_DISABLED, 1, 3, 6, 12, 24)
    private const val TIMEOUT_MS = 10_000

    enum class Status {
        IDLE,
        CHECKING,
        UP_TO_DATE,
        UPDATE_AVAILABLE,
        ERROR,
    }

    data class State(
        val status: Status = Status.IDLE,
        val info: AppUpdate.ReleaseInfo? = null,
        val message: UiText? = null,
        val checkedAt: Long = 0L,
        val channel: AppUpdate.Channel = AppUpdate.Channel.STABLE,
    )

    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var checkJob: Job? = null

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun channel(context: Context): AppUpdate.Channel =
        AppUpdate.Channel.fromPreference(prefs(context).getString(KEY_CHANNEL, null))

    @MainThread
    fun restoreChannel(context: Context) {
        val saved = channel(context)
        if (_state.value.channel == saved) return
        checkJob?.cancel()
        ApkUpdater.cancel()
        _state.value = State(channel = saved)
    }

    @MainThread
    fun setChannel(context: Context, channel: AppUpdate.Channel) {
        if (this.channel(context) == channel) return
        checkJob?.cancel()
        ApkUpdater.cancel()
        prefs(context).edit().putString(KEY_CHANNEL, channel.id).apply()
        _state.value = State(channel = channel)
        LogBus.log("[更新] 切换通道 channel=${channel.id}")
        check(context)
    }

    private fun feedUrl(context: Context, channel: AppUpdate.Channel): String {
        val official = FEED_BASE + channel.feedFile
        val source =
            if (BuildConfig.DEBUG) {
                val key =
                    if (channel == AppUpdate.Channel.STABLE) KEY_DEBUG_FEED
                    else "debug_nightly_feed_url"
                prefs(context).getString(key, null)?.trim()?.takeIf {
                    it.startsWith("http://") || it.startsWith("https://")
                } ?: official
            } else official
        return DownloadMirror.rewrite(source, mirror(context))
    }

    fun mirror(context: Context): DownloadMirror =
        DownloadMirror.fromPreference(prefs(context).getString(KEY_MIRROR, null))

    @MainThread
    fun setMirror(context: Context, mirror: DownloadMirror) {
        if (this.mirror(context) == mirror) return
        val wasChecking = checkJob?.isActive == true
        val wasDownloading = ApkUpdater.state.value.busy
        val release = _state.value.info
        prefs(context).edit().putString(KEY_MIRROR, mirror.id).apply()
        LogBus.log("[更新] 下载镜像=${mirror.id}")
        if (wasDownloading) ApkUpdater.cancel()
        if (wasChecking) {
            checkJob?.cancel()
            check(context)
        } else if (wasDownloading && release != null) {
            ApkUpdater.download(context, release, autoInstall = false)
        }
    }

    fun autoCheckHours(context: Context): Int {
        val stored = prefs(context).getInt(KEY_AUTO_HOURS, DEFAULT_AUTO_HOURS)
        return if (stored in AUTO_HOURS_OPTIONS) stored else DEFAULT_AUTO_HOURS
    }

    fun setAutoCheckHours(context: Context, hours: Int) {
        val safe = if (hours in AUTO_HOURS_OPTIONS) hours else DEFAULT_AUTO_HOURS
        prefs(context).edit().putInt(KEY_AUTO_HOURS, safe).apply()
    }

    internal fun shouldAutoCheck(autoHours: Int, lastCheckAt: Long, now: Long): Boolean {
        if (autoHours <= AUTO_HOURS_DISABLED) return false
        return now - lastCheckAt >= autoHours * 3600_000L
    }

    @MainThread
    fun maybeAutoCheck(context: Context) {
        restoreChannel(context)
        val selected = channel(context)
        val last =
            prefs(context)
                .getLong(
                    "${KEY_LAST_CHECK}_${selected.id}",
                    if (selected == AppUpdate.Channel.STABLE)
                        prefs(context).getLong(KEY_LAST_CHECK, 0L)
                    else 0L,
                )
        if (!shouldAutoCheck(autoCheckHours(context), last, System.currentTimeMillis())) return
        check(context, automatic = true)
    }

    @MainThread
    fun check(context: Context, automatic: Boolean = false) {
        val app = context.applicationContext
        restoreChannel(app)
        if (automatic && autoCheckHours(app) <= AUTO_HOURS_DISABLED) return
        if (checkJob?.isActive == true) return
        val selected = channel(app)
        val stableUrl = feedUrl(app, AppUpdate.Channel.STABLE)
        val nightlyUrl = feedUrl(app, AppUpdate.Channel.NIGHTLY)
        _state.value =
            State(
                channel = selected,
                status = Status.CHECKING,
                message =
                    if (automatic) uiText(R.string.update_background_checking)
                    else uiText(R.string.update_checking),
            )
        checkJob =
            scope.launch {
                val activeMirror = mirror(app)
                if (activeMirror != DownloadMirror.OFF) {
                    LogBus.log("[更新] 检查经由镜像 ${activeMirror.id}")
                }
                val result =
                    try {
                        val info =
                            withContext(Dispatchers.IO) {
                                val stable =
                                    fetchRelease(stableUrl, AppUpdate.Channel.STABLE)
                                        ?: throw UserFacingException(
                                            uiText(R.string.update_invalid_feed)
                                        )
                                val nightly =
                                    if (selected == AppUpdate.Channel.NIGHTLY)
                                        fetchRelease(nightlyUrl, AppUpdate.Channel.NIGHTLY)
                                    else null
                                AppUpdate.selectRelease(selected, stable, nightly)
                            }
                        val newer =
                            AppUpdate.isNewer(
                                BuildConfig.VERSION_NAME,
                                BuildConfig.VERSION_CODE,
                                info,
                            )
                        LogBus.log(
                            "[更新] channel=${selected.id} 清单 ${info.versionName}（code=${info.versionCode ?: "-"}），" +
                                "当前 ${BuildConfig.VERSION_NAME}（code=${BuildConfig.VERSION_CODE}），" +
                                if (newer) "有新版本" else "无可升级版本"
                        )
                        State(
                            channel = selected,
                            status = if (newer) Status.UPDATE_AVAILABLE else Status.UP_TO_DATE,
                            info = info,
                            message =
                                when {
                                    newer -> uiText(R.string.update_available, info.versionName)
                                    selected == AppUpdate.Channel.STABLE &&
                                        AppUpdate.channelForVersion(BuildConfig.VERSION_NAME) ==
                                            AppUpdate.Channel.NIGHTLY &&
                                        AppUpdate.compareNames(
                                            BuildConfig.VERSION_NAME,
                                            info.versionName,
                                        ) < 0 -> uiText(R.string.update_waiting_stable)
                                    else -> uiText(R.string.update_current)
                                },
                            checkedAt = System.currentTimeMillis(),
                        )
                    } catch (cancelled: CancellationException) {
                        throw cancelled
                    } catch (error: Exception) {
                        currentCoroutineContext().ensureActive()
                        LogBus.error("[更新] 检查异常 channel=${selected.id}", error)
                        State(
                            channel = selected,
                            status = Status.ERROR,
                            message =
                                (error as? UserFacingException)?.reason
                                    ?: uiText(R.string.update_network_error),
                            checkedAt = System.currentTimeMillis(),
                        )
                    }
                prefs(app)
                    .edit()
                    .putLong("${KEY_LAST_CHECK}_${selected.id}", result.checkedAt)
                    .apply()
                _state.value = result
                if (
                    result.status == Status.UPDATE_AVAILABLE && !result.info?.apkUrl.isNullOrBlank()
                ) {
                    result.info?.let { ApkUpdater.download(app, it, autoInstall = false) }
                } else {
                    ApkUpdater.cancel()
                }
            }
    }

    private suspend fun fetchRelease(
        url: String,
        channel: AppUpdate.Channel,
    ): AppUpdate.ReleaseInfo? {
        currentCoroutineContext().ensureActive()
        val conn =
            (URL(url).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = TIMEOUT_MS
                readTimeout = TIMEOUT_MS
                setRequestProperty("Accept", "application/json")
                setRequestProperty(
                    "User-Agent",
                    "GalaxyWatchManagerFree/${BuildConfig.VERSION_NAME}",
                )
                setRequestProperty("Cache-Control", "max-age=300")
            }
        try {
            val code = conn.responseCode
            if (code == HttpURLConnection.HTTP_NOT_FOUND && channel == AppUpdate.Channel.NIGHTLY)
                return null
            if (code != HttpURLConnection.HTTP_OK)
                throw UserFacingException(uiText(R.string.update_check_http, code))
            val body =
                conn.inputStream.use { input ->
                    val output = java.io.ByteArrayOutputStream()
                    val buffer = ByteArray(8 * 1024)
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        val count = input.read(buffer)
                        if (count < 0) break
                        require(output.size() + count <= 256 * 1024) {
                            "Update feed exceeds size limit"
                        }
                        output.write(buffer, 0, count)
                    }
                    output.toString(Charsets.UTF_8.name())
                }
            val info = AppUpdate.parseFeed(body)
            if (info == null || info.channel != channel)
                throw UserFacingException(uiText(R.string.update_invalid_feed))
            return info
        } finally {
            conn.disconnect()
        }
    }
}
