package dev.ricky.galaxywatchmanagerfree.feature.monitor

import dev.ricky.galaxywatchmanagerfree.R
import org.json.JSONArray
import org.json.JSONObject

data class BpRecord(
    val id: String,
    val startTime: Long,
    val systolic: Int,
    val diastolic: Int,
    val heartRate: Int,
) {
    val classification: Classification
        get() = classify(systolic, diastolic)

    enum class Classification(@androidx.annotation.StringRes val labelRes: Int) {
        NORMAL(R.string.bp_normal),
        ELEVATED(R.string.bp_elevated),
        STAGE1(R.string.bp_stage1),
        STAGE2(R.string.bp_stage2),
        LOW(R.string.bp_low),
    }

    companion object {
        fun classify(systolic: Int, diastolic: Int): Classification =
            when {
                systolic <= 0 || diastolic <= 0 -> Classification.NORMAL
                systolic < 90 || diastolic < 60 -> Classification.LOW
                systolic < 120 && diastolic < 80 -> Classification.NORMAL
                systolic in 120..129 && diastolic < 80 -> Classification.ELEVATED
                systolic >= 140 || diastolic >= 90 -> Classification.STAGE2
                else -> Classification.STAGE1
            }

        fun parse(record: JSONObject): BpRecord? {
            val uuid =
                record.optString("datauuid", record.optString("data_uuid")).ifBlank {
                    return null
                }
            val time = record.optLong("start_time", record.optLong("create_time", 0L))
            if (time <= 0L) return null
            val sys = record.optInt("systolic", -1)
            val dia = record.optInt("diastolic", record.optInt("diastole", -1))
            val hr = record.optInt("heart_rate", record.optInt("hr", record.optInt("pulse", -1)))
            if (sys <= 0 || dia <= 0) return null
            return BpRecord(
                id = uuid,
                startTime = time,
                systolic = sys,
                diastolic = dia,
                heartRate = hr,
            )
        }
    }
}

object BpLog {
    fun encode(records: List<BpRecord>): String {
        val array = JSONArray()
        records.forEach { r ->
            array.put(
                JSONObject()
                    .put("id", r.id)
                    .put("time", r.startTime)
                    .put("sys", r.systolic)
                    .put("dia", r.diastolic)
                    .put("hr", r.heartRate)
            )
        }
        return array.toString()
    }

    fun decode(raw: String?): List<BpRecord> {
        if (raw.isNullOrBlank()) return emptyList()
        val array = runCatching { JSONArray(raw) }.getOrNull() ?: return emptyList()
        val out = ArrayList<BpRecord>(array.length())
        for (i in 0 until array.length()) {
            val obj = array.optJSONObject(i) ?: continue
            val id = obj.optString("id")
            if (id.isBlank()) continue
            val time = obj.optLong("time")
            val sys = obj.optInt("sys", -1)
            val dia = obj.optInt("dia", -1)
            if (time <= 0L || sys <= 0 || dia <= 0) continue
            out.add(BpRecord(id, time, sys, dia, obj.optInt("hr", -1)))
        }
        return out.sortedByDescending { it.startTime }
    }

    fun merge(
        existing: List<BpRecord>,
        incoming: List<BpRecord>,
        maxKeep: Int = 100,
    ): List<BpRecord> {
        val byId = LinkedHashMap<String, BpRecord>()
        (existing + incoming).sortedBy { it.startTime }.forEach { byId[it.id] = it }
        return byId.values.sortedByDescending { it.startTime }.take(maxKeep)
    }
}
