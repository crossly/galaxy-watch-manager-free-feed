package dev.ricky.galaxywatchmanagerfree.wcs

/** Bound active Bluetooth work while the watch is unavailable or repeatedly disconnects. */
class ReconnectPolicy(private val now: () -> Long = { System.nanoTime() / 1_000_000L }) {
    private var failures = 0
    private var connectedAt: Long? = null
    private var lastWakeAt: Long? = null

    @Synchronized
    fun connected() {
        connectedAt = now()
    }

    @Synchronized
    fun disconnected() {
        connectedAt?.let { if (now() - it >= STABLE_CONNECTION_MS) failures = 0 }
        connectedAt = null
    }

    @Synchronized
    fun nextDelayMillis(): Long {
        val delay = (500L shl failures.coerceAtMost(8)).coerceAtMost(MAX_DELAY_MS)
        failures = (failures + 1).coerceAtMost(8)
        return delay
    }

    @Synchronized
    fun mayWake(): Boolean {
        val at = now()
        if (lastWakeAt?.let { at - it < WAKE_COOLDOWN_MS } == true) return false
        lastWakeAt = at
        return true
    }

    companion object {
        const val MAX_DELAY_MS = 60_000L
        const val WAKE_COOLDOWN_MS = 120_000L
        const val STABLE_CONNECTION_MS = 30_000L
    }
}
