package dev.ricky.galaxywatchmanagerfree.feature

import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first

internal suspend fun syncVascularLoadHistory(
    state: StateFlow<WatchState>,
    request: () -> Boolean,
): Boolean {
    while (true) {
        val ready =
            state.first {
                !it.vascularLoadSupported ||
                    it.healthSyncStatus != HealthSyncCoordinator.Status.SYNCING
            }
        if (
            !ready.vascularLoadSupported ||
                ready.healthSyncStatus == HealthSyncCoordinator.Status.DISCONNECTED
        )
            return false
        if (request()) break
        if (state.value.healthSyncStatus != HealthSyncCoordinator.Status.SYNCING) return false
    }
    val finished =
        state.first {
            !it.vascularLoadSupported || it.healthSyncStatus != HealthSyncCoordinator.Status.SYNCING
        }
    return finished.vascularLoadSupported &&
        finished.healthSyncStatus == HealthSyncCoordinator.Status.IDLE
}
