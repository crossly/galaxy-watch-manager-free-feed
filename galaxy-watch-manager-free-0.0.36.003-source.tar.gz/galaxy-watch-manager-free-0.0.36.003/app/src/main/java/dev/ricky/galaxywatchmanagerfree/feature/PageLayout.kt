package dev.ricky.galaxywatchmanagerfree.feature

import androidx.annotation.StringRes
import dev.ricky.galaxywatchmanagerfree.R
import org.json.JSONArray
import org.json.JSONObject

enum class LayoutPage(@StringRes val labelRes: Int) {
    OVERVIEW(R.string.overview),
    HEALTH(R.string.health),
}

enum class PageBlock(
    val page: LayoutPage,
    @StringRes val labelRes: Int,
    val compact: Boolean = false,
) {
    CONNECTION(LayoutPage.OVERVIEW, R.string.device_connection),
    BATTERY(LayoutPage.OVERVIEW, R.string.watch_battery),
    WATCH_FACE(LayoutPage.OVERVIEW, R.string.watch_faces),
    QUICK_CONTROLS(LayoutPage.OVERVIEW, R.string.quick_controls),
    MEMORY(LayoutPage.OVERVIEW, R.string.memory),
    DEVICE_INFO(LayoutPage.OVERVIEW, R.string.device_information),
    HEALTH_SYNC(LayoutPage.HEALTH, R.string.sync),
    STEPS(LayoutPage.HEALTH, R.string.today_s_steps),
    HEART_RATE(LayoutPage.HEALTH, R.string.heart_rate, true),
    STRESS(LayoutPage.HEALTH, R.string.stress, true),
    ECG(LayoutPage.HEALTH, R.string.ecg, true),
    BP(LayoutPage.HEALTH, R.string.blood_pressure, true),
    VASCULAR_LOAD(LayoutPage.HEALTH, R.string.vascular_load, true),
    SLEEP(LayoutPage.HEALTH, R.string.sleep),
    METRICS(LayoutPage.HEALTH, R.string.body_measurements),
    WORKOUTS(LayoutPage.HEALTH, R.string.workouts_2),
}

data class BlockPlacement(
    val block: PageBlock,
    val visible: Boolean = true,
    val wide: Boolean = !block.compact,
)

/** Stable IDs survive locale changes and additions; malformed entries cannot remove new blocks. */
object PageLayout {
    fun defaults(page: LayoutPage): List<BlockPlacement> =
        PageBlock.entries.filter { it.page == page }.map { BlockPlacement(it) }

    fun decode(raw: String?, page: LayoutPage): List<BlockPlacement> {
        val saved = runCatching { JSONArray(raw ?: "[]") }.getOrNull() ?: JSONArray()
        val found = linkedMapOf<PageBlock, BlockPlacement>()
        for (i in 0 until saved.length()) {
            val item = saved.optJSONObject(i) ?: continue
            val block =
                PageBlock.entries.firstOrNull { it.name == item.optString("id") && it.page == page }
                    ?: continue
            found.putIfAbsent(
                block,
                BlockPlacement(
                    block,
                    item.optBoolean("visible", true),
                    !block.compact || item.optBoolean("wide", false),
                ),
            )
        }
        return found.values.toList() + defaults(page).filter { it.block !in found }
    }

    fun encode(placements: List<BlockPlacement>): String =
        JSONArray()
            .apply {
                placements.forEach {
                    put(
                        JSONObject()
                            .put("id", it.block.name)
                            .put("visible", it.visible)
                            .put("wide", it.wide)
                    )
                }
            }
            .toString()

    fun move(items: List<BlockPlacement>, block: PageBlock, offset: Int): List<BlockPlacement> {
        val from = items.indexOfFirst { it.block == block }
        val to = from + offset
        if (from < 0 || to !in items.indices) return items
        return items.toMutableList().apply { add(to, removeAt(from)) }
    }
}
