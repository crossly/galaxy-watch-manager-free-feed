package dev.ricky.galaxywatchmanagerfree.ui.screens.connection

import android.Manifest
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.filled.BatteryAlert
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Circle
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Watch
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.core.OnboardingController
import dev.ricky.galaxywatchmanagerfree.core.UiNotify
import dev.ricky.galaxywatchmanagerfree.core.WatchController
import dev.ricky.galaxywatchmanagerfree.feature.AutoQueryPolicy
import dev.ricky.galaxywatchmanagerfree.feature.DeviceIdentityStore
import dev.ricky.galaxywatchmanagerfree.feature.KeepAliveHelper
import dev.ricky.galaxywatchmanagerfree.feature.OnboardingStatus
import dev.ricky.galaxywatchmanagerfree.feature.WatchFacePresets
import dev.ricky.galaxywatchmanagerfree.feature.WatchRepository
import dev.ricky.galaxywatchmanagerfree.feature.WatchState
import dev.ricky.galaxywatchmanagerfree.ui.components.CompanionHandoverCard
import dev.ricky.galaxywatchmanagerfree.ui.components.GroupedCard
import dev.ricky.galaxywatchmanagerfree.ui.components.SettingChoiceRow
import dev.ricky.galaxywatchmanagerfree.ui.components.SettingSwitchRow
import dev.ricky.galaxywatchmanagerfree.ui.components.WatchDeviceGraphic
import dev.ricky.galaxywatchmanagerfree.ui.theme.CardBorder
import dev.ricky.galaxywatchmanagerfree.ui.theme.ElectricBlue
import dev.ricky.galaxywatchmanagerfree.ui.theme.EmeraldCharging
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextPrimary
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextSecondary
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextTertiary
import dev.ricky.galaxywatchmanagerfree.ui.theme.WarningAmber
import kotlinx.coroutines.launch

/**
 * Device connection page.
 *
 * The page is deliberately a thin shell: all volatile UI state lives in [ConnectionPageModel],
 * session state in [WatchController], and the screen only wires callbacks and renders sections.
 * First-run guidance is a separate full-screen flow
 * ([dev.ricky.galaxywatchmanagerfree.ui.onboarding]).
 */
@Composable
fun DeviceConnectionScreen(
    state: WatchState,
    repo: WatchRepository,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val appContext = context.applicationContext
    val scope = rememberCoroutineScope()
    val lifecycleOwner = LocalLifecycleOwner.current
    val model = remember(appContext) { ConnectionPageModel(appContext) }
    val ui by model.state.collectAsState()
    val progress by WatchController.connectionProgress.collectAsState()
    val status =
        if (progress.mac.equals(ui.selectedMac, true)) progress.status else OnboardingStatus.IDLE

    val permissionLauncher =
        rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
            scope.launch { model.refresh() }
        }

    LaunchedEffect(Unit) { model.refresh() }
    DisposableEffect(lifecycleOwner, model) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) scope.launch { model.refresh() }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    fun resolvePlatformIssue() {
        if (
            ui.issueRes == R.string.conn_permission_needed &&
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
        ) {
            permissionLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            context.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
        }
    }

    fun connect() {
        val mac = ui.selectedMac
        if (mac.isBlank()) {
            UiNotify.show(R.string.connection_status_no_watch)
            return
        }
        val name = ui.selectedWatch?.name ?: mac
        when {
            status == OnboardingStatus.ERROR || status == OnboardingStatus.IDENTITY_MISSING ->
                WatchController.retryConnection(context)
            else -> WatchController.startService(context, mac)
        }
        UiNotify.show(context.getString(R.string.connecting_to, name))
    }

    DeviceConnectionContent(
        ui = ui,
        state = state,
        status = status,
        onRefresh = { scope.launch { model.refresh() } },
        onSelectWatch = model::select,
        onConnect = ::connect,
        onStop = { WatchController.stopConnection(context) },
        onShowOnboarding = OnboardingController::open,
        onAutoConnectChange = model::setAutoConnect,
        onAutoRefreshChange = { repo.autoRefreshEnabled = it },
        onAutoIntervalChange = { repo.setAutoQueryIntervalSeconds(it) },
        onResolvePlatform = ::resolvePlatformIssue,
        onHandoverStateChanged = model::refreshConnectionOwnership,
        modifier = modifier,
    )
}

/** Connection controls use one primary action; selection and diagnostics stay secondary. */
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun DeviceConnectionContent(
    ui: ConnectionPageUiState,
    state: WatchState,
    status: OnboardingStatus,
    onRefresh: () -> Unit,
    onSelectWatch: (String) -> Unit,
    onConnect: () -> Unit,
    onStop: () -> Unit,
    onShowOnboarding: () -> Unit,
    onAutoConnectChange: (Boolean) -> Unit,
    onAutoRefreshChange: (Boolean) -> Unit,
    onAutoIntervalChange: (Int) -> Unit,
    onResolvePlatform: () -> Unit,
    onHandoverStateChanged: () -> Unit = {},
    showHandover: Boolean = true,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val strings = context.resources
    val identityStore =
        remember(context, ui.selectedMac) {
            ui.selectedMac
                .takeIf { it.isNotBlank() }
                ?.let { DeviceIdentityStore(context.applicationContext, it) }
        }
    val confirmedNode = identityStore?.confirmedPhoneNode.orEmpty()
    val pendingNode = identityStore?.pendingHandoverNode.orEmpty()
    val isConnected = status == OnboardingStatus.READY && state.connected && state.sessionReady
    val busy =
        status == OnboardingStatus.ACQUIRING_IDENTITY ||
            status == OnboardingStatus.CONNECTING ||
            status == OnboardingStatus.VERIFYING_IDENTITY
    val waitingHandover =
        status == OnboardingStatus.PREPARING_HANDOVER ||
            (identityStore?.handoverPreparing == true && !busy)
    val ownership = if (waitingHandover) ConnectionOwnership.HANDOVER else ui.ownership
    val isCurrentDevice = ui.selectedMac.isNotBlank() && (isConnected || state.connected)
    val selectedName =
        if (isCurrentDevice && state.displayName.isNotBlank()) state.displayName
        else ui.selectedWatch?.name ?: strings.getString(R.string.connection_selected_watch)
    val scope = rememberCoroutineScope()
    val handoverRequester = remember { BringIntoViewRequester() }
    var handoverExpandRequest by remember { mutableIntStateOf(0) }
    var choosingWatch by
        androidx.compose.runtime.saveable.rememberSaveable {
            androidx.compose.runtime.mutableStateOf(false)
        }

    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        ConnectionStatusCard(
            ui = ui,
            status = status,
            isConnected = isConnected,
            busy = busy,
            waitingHandover = waitingHandover,
            ownership = ownership,
            selectedName = selectedName,
            lastSyncAt = state.lastSyncAt,
            confirmedIdentity = confirmedNode.isNotBlank(),
            pendingIdentity = pendingNode.isNotBlank(),
            onConnect = onConnect,
            onStop = onStop,
            onChooseWatch = { choosingWatch = true },
            onResolvePlatform = onResolvePlatform,
            onManageOwnership = {
                handoverExpandRequest++
                scope.launch { handoverRequester.bringIntoView() }
            },
            watchState = state,
        )
        GroupedCard(innerPadding = 0.dp) {
            dev.ricky.galaxywatchmanagerfree.ui.components.GroupedCardRow(
                title =
                    if (ui.selectedMac.isBlank())
                        strings.getString(R.string.connection_choose_watch)
                    else strings.getString(R.string.connection_change_current_watch),
                titleMaxLines = 2,
                subtitle =
                    if (ui.selectedMac.isBlank())
                        strings.getString(R.string.connection_change_watch)
                    else selectedName,
                icon = Icons.Default.Watch,
                showChevron = true,
                onClick = { choosingWatch = true },
                modifier = Modifier.testTag("tag_choose_watch"),
            )
            dev.ricky.galaxywatchmanagerfree.ui.components.GroupedDivider()
            dev.ricky.galaxywatchmanagerfree.ui.components.GroupedCardRow(
                title = strings.getString(R.string.connection_setup_help),
                subtitle = strings.getString(R.string.connection_setup_help_subtitle),
                icon = Icons.AutoMirrored.Filled.HelpOutline,
                showChevron = true,
                onClick = onShowOnboarding,
                modifier = Modifier.testTag("tag_show_onboarding"),
            )
        }
        if (showHandover && ui.selectedMac.isNotBlank()) {
            CompanionHandoverCard(
                selectedMac = ui.selectedMac,
                selectedDeviceName = selectedName,
                modifier = Modifier.bringIntoViewRequester(handoverRequester),
                expandRequest = handoverExpandRequest,
                expandByDefault = false,
                onConnectionOwnershipChanged = onHandoverStateChanged,
            )
        }
        GroupedCard(innerPadding = 16.dp) {
            SettingSwitchRow(
                title = strings.getString(R.string.auto_connect_at_startup),
                subtitle =
                    strings.getString(
                        when {
                            !ui.autoConnect -> R.string.connection_auto_connect_disabled_description
                            ownership == ConnectionOwnership.OFFICIAL_APPS ->
                                R.string.connection_auto_connect_paused_description
                            ownership == ConnectionOwnership.HANDOVER ->
                                R.string.connection_auto_connect_handover_description
                            else -> R.string.connection_auto_connect_description
                        }
                    ),
                checked = ui.autoConnect,
                onCheckedChange = onAutoConnectChange,
                modifier = Modifier.testTag("tag_auto_connect"),
            )
            HorizontalDivider(color = CardBorder.copy(alpha = 0.45f))
            SettingSwitchRow(
                title = strings.getString(R.string.auto_query),
                subtitle = strings.getString(R.string.auto_query_explanation),
                checked = state.autoRefresh,
                onCheckedChange = onAutoRefreshChange,
            )
            if (state.autoRefresh) {
                val intervals = AutoQueryPolicy.INTERVALS_SECONDS
                SettingChoiceRow(
                    title = strings.getString(R.string.auto_query_interval),
                    options =
                        intervals.map {
                            strings.getString(R.string.auto_query_interval_seconds, it)
                        },
                    selectedIndex = intervals.indexOf(state.autoQueryIntervalSeconds),
                    onSelect = { onAutoIntervalChange(intervals[it]) },
                )
            }
        }
        KeepAliveCard()
    }
    if (choosingWatch) {
        WatchPickerSheet(
            ui = ui,
            connectedMac = if (isConnected) ui.selectedMac else "",
            onRefresh = onRefresh,
            onSelect = {
                onSelectWatch(it)
                choosingWatch = false
            },
            onOpenBluetooth = onResolvePlatform,
            onDismiss = { choosingWatch = false },
            watchState = state,
        )
    }
}

@Composable
private fun ConnectionStatusCard(
    ui: ConnectionPageUiState,
    status: OnboardingStatus,
    isConnected: Boolean,
    busy: Boolean,
    waitingHandover: Boolean,
    ownership: ConnectionOwnership,
    selectedName: String,
    lastSyncAt: Long,
    confirmedIdentity: Boolean,
    pendingIdentity: Boolean,
    onConnect: () -> Unit,
    onStop: () -> Unit,
    onChooseWatch: () -> Unit,
    onResolvePlatform: () -> Unit,
    onManageOwnership: () -> Unit,
    watchState: WatchState? = null,
) {
    val context = LocalContext.current
    val strings = context.resources
    val failed = status == OnboardingStatus.ERROR || status == OnboardingStatus.IDENTITY_MISSING
    val title =
        when {
            ui.issueRes != null -> strings.getString(R.string.connection_platform_unavailable)
            waitingHandover -> strings.getString(R.string.connection_status_preparing)
            ui.selectedMac.isBlank() -> strings.getString(R.string.connection_status_no_watch)
            status == OnboardingStatus.ACQUIRING_IDENTITY ->
                strings.getString(R.string.connection_status_acquiring_identity)
            isConnected -> strings.getString(R.string.connected_2)
            busy -> strings.getString(R.string.connecting)
            failed -> strings.getString(R.string.connection_status_failed)
            ownership == ConnectionOwnership.OFFICIAL_APPS ->
                strings.getString(R.string.connection_status_official_apps)
            else -> strings.getString(R.string.connection_ready_to_connect)
        }
    val description =
        when {
            ui.issueRes != null -> strings.getString(ui.issueRes)
            waitingHandover -> strings.getString(R.string.connection_desc_preparing)
            ui.selectedMac.isBlank() -> strings.getString(R.string.connection_desc_select_watch)
            status == OnboardingStatus.ACQUIRING_IDENTITY ->
                strings.getString(R.string.connection_desc_acquiring)
            isConnected -> strings.getString(R.string.connection_desc_connected)
            busy -> strings.getString(R.string.connection_desc_connecting)
            failed -> strings.getString(R.string.connection_desc_failed)
            ownership == ConnectionOwnership.OFFICIAL_APPS ->
                strings.getString(R.string.connection_desc_official_apps)
            else -> strings.getString(R.string.connection_desc_idle)
        }
    val statusColor =
        when {
            ui.issueRes != null || waitingHandover -> WarningAmber
            failed -> MaterialTheme.colorScheme.error
            isConnected -> EmeraldCharging
            ownership == ConnectionOwnership.OFFICIAL_APPS -> TextSecondary
            else -> ElectricBlue
        }
    val modeLabel =
        strings.getString(
            when {
                ui.selectedMac.isBlank() -> R.string.connection_mode_no_device
                ownership == ConnectionOwnership.HANDOVER -> R.string.connection_mode_handover
                ownership == ConnectionOwnership.OFFICIAL_APPS ->
                    R.string.connection_mode_official_apps
                else -> R.string.connection_mode_direct
            }
        )
    GroupedCard(cornerRadius = 28.dp, innerPadding = 20.dp) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            if (ui.selectedMac.isNotBlank()) {
                val isCurrent =
                    isConnected || (ui.selectedMac.isNotBlank() && watchState?.connected == true)
                val modelName =
                    if (isCurrent && watchState?.modelName.orEmpty().isNotBlank())
                        watchState!!.modelName
                    else selectedName
                val modelNumber = if (isCurrent) watchState?.modelNumber.orEmpty() else ""
                val syncing =
                    isCurrent &&
                        (watchState?.startupSyncing == true ||
                            (watchState?.connected == true && watchState.sessionReady.not()))
                WatchDeviceGraphic(
                    modelName = modelName,
                    modelNumber = modelNumber,
                    active = busy || syncing,
                    preset =
                        if (isCurrent && watchState != null)
                            WatchFacePresets.find(
                                watchState.activeWatchfacePkg,
                                watchState.activeWatchfaceCls,
                            )
                        else null,
                    previewPath = if (isCurrent) watchState?.activeWatchfacePreviewPath else null,
                    modifier = Modifier.size(54.dp),
                )
            } else {
                Box(
                    Modifier.size(48.dp)
                        .clip(CircleShape)
                        .background(statusColor.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center,
                ) {
                    if (busy && !waitingHandover) {
                        CircularProgressIndicator(
                            Modifier.size(24.dp).testTag("tag_connection_progress"),
                            color = statusColor,
                            strokeWidth = 2.dp,
                        )
                    } else {
                        Icon(
                            if (isConnected) Icons.Default.CheckCircle else Icons.Default.Bluetooth,
                            null,
                            tint = statusColor,
                            modifier = Modifier.size(26.dp),
                        )
                    }
                }
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Surface(
                        color = statusColor.copy(alpha = 0.12f),
                        shape = RoundedCornerShape(50),
                    ) {
                        Text(
                            modeLabel,
                            modifier =
                                Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                                    .testTag("tag_connection_ownership"),
                            style = MaterialTheme.typography.labelSmall,
                            color = statusColor,
                        )
                    }
                    if (busy && !waitingHandover) {
                        CircularProgressIndicator(
                            Modifier.size(13.dp).testTag("tag_connection_progress"),
                            color = statusColor,
                            strokeWidth = 1.8.dp,
                        )
                    }
                }
                if (ui.selectedMac.isNotBlank()) {
                    Text(
                        selectedName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary,
                    )
                    if (
                        watchState?.watchAlias?.isNotBlank() == true &&
                            watchState.modelName.isNotBlank() &&
                            selectedName != watchState.modelName
                    ) {
                        Text(
                            watchState.modelName,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                        )
                    }
                }
                Text(
                    title,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                )
                Text(
                    description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                )
            }
        }
        if (ui.selectedMac.isNotBlank() && ui.issueRes == null) {
            Spacer(Modifier.height(14.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                val step1Done = true
                val step2Done = confirmedIdentity || isConnected
                val step3Done = isConnected

                ConnectionStepChip(
                    text = strings.getString(R.string.connection_step_paired),
                    done = step1Done,
                    active = false,
                    modifier = Modifier.weight(1f),
                )
                ConnectionStepChip(
                    text = strings.getString(R.string.connection_step_identity),
                    done = step2Done,
                    active = busy && !step2Done,
                    modifier = Modifier.weight(1f),
                )
                ConnectionStepChip(
                    text = strings.getString(R.string.connection_step_channel),
                    done = step3Done,
                    active = busy && step2Done && !step3Done,
                    modifier = Modifier.weight(1f),
                )
            }
        }
        if (lastSyncAt > 0L && ui.selectedMac.isNotBlank()) {
            Spacer(Modifier.height(14.dp))
            val lastSync =
                remember(lastSyncAt) {
                    android.text.format.DateFormat.getTimeFormat(context)
                        .format(java.util.Date(lastSyncAt))
                }
            Text(
                strings.getString(R.string.connection_last_sync, lastSync),
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
            )
        }
        if (pendingIdentity || (confirmedIdentity && ownership == ConnectionOwnership.HANDOVER)) {
            Spacer(Modifier.height(8.dp))
            Text(
                strings.getString(
                    if (pendingIdentity) R.string.connection_identity_pending
                    else R.string.identity_acquired_success
                ),
                style = MaterialTheme.typography.bodySmall,
                color = if (pendingIdentity) TextSecondary else EmeraldCharging,
            )
        }
        if (ownership == ConnectionOwnership.OFFICIAL_APPS && ui.autoConnect) {
            Spacer(Modifier.height(10.dp))
            Surface(color = WarningAmber.copy(alpha = 0.10f), shape = RoundedCornerShape(12.dp)) {
                Text(
                    strings.getString(R.string.connection_auto_connect_paused_inline),
                    modifier =
                        Modifier.fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp)
                            .testTag("tag_auto_connect_paused"),
                    style = MaterialTheme.typography.bodySmall,
                    color = WarningAmber,
                )
            }
        }
        if (!waitingHandover) {
            Spacer(Modifier.height(16.dp))
            when {
                ui.issueRes != null ->
                    Button(
                        onResolvePlatform,
                        Modifier.fillMaxWidth().testTag("tag_resolve_platform"),
                    ) {
                        Text(
                            strings.getString(
                                if (ui.issueRes == R.string.conn_permission_needed)
                                    R.string.connection_grant_bluetooth
                                else R.string.connection_open_bluetooth
                            )
                        )
                    }
                busy || isConnected ->
                    OutlinedButton(onStop, Modifier.fillMaxWidth().testTag("tag_stop_connection")) {
                        Text(strings.getString(R.string.action_pause_connection))
                    }
                ownership == ConnectionOwnership.OFFICIAL_APPS ->
                    Button(
                        onManageOwnership,
                        Modifier.fillMaxWidth().testTag("tag_take_connection_back"),
                    ) {
                        Text(strings.getString(R.string.connection_take_back))
                    }
                ui.selectedMac.isBlank() ->
                    Button(
                        onClick = if (ui.watches.isEmpty()) onResolvePlatform else onChooseWatch,
                        modifier =
                            Modifier.fillMaxWidth()
                                .testTag(
                                    if (ui.watches.isEmpty()) "tag_open_bluetooth_settings"
                                    else "tag_choose_watch_primary"
                                ),
                    ) {
                        Text(
                            strings.getString(
                                if (ui.watches.isEmpty()) R.string.connection_pair_watch
                                else R.string.connection_choose_watch
                            )
                        )
                    }
                else ->
                    Button(onConnect, Modifier.fillMaxWidth().testTag("tag_connect_button")) {
                        Text(
                            strings.getString(
                                if (failed) R.string.conn_retry else R.string.connect_watch
                            )
                        )
                    }
            }
        }
    }
}

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
internal fun WatchPickerSheet(
    ui: ConnectionPageUiState,
    connectedMac: String,
    onRefresh: () -> Unit,
    onSelect: (String) -> Unit,
    onOpenBluetooth: () -> Unit,
    onDismiss: () -> Unit,
    watchState: WatchState? = null,
) {
    val strings = LocalContext.current.resources
    dev.ricky.galaxywatchmanagerfree.ui.components.AppBottomSheet(
        onDismissRequest = onDismiss,
        sheetState =
            androidx.compose.material3.rememberModalBottomSheetState(skipPartiallyExpanded = true),
    ) {
        Box(Modifier.padding(horizontal = 16.dp)) {
            dev.ricky.galaxywatchmanagerfree.ui.components.SheetToolbar(
                strings.getString(R.string.connection_choose_watch),
                onDismiss,
            )
        }
        androidx.compose.foundation.lazy.LazyColumn(
            modifier = Modifier.fillMaxWidth().weight(1f, fill = false),
            contentPadding =
                androidx.compose.foundation.layout.PaddingValues(
                    start = 16.dp,
                    end = 16.dp,
                    bottom = 24.dp,
                ),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        strings.getString(R.string.connection_paired_devices),
                        style = MaterialTheme.typography.titleSmall,
                        color = TextSecondary,
                        modifier = Modifier.weight(1f),
                    )
                    androidx.compose.material3.IconButton(
                        onClick = onRefresh,
                        enabled = !ui.loading,
                        modifier = Modifier.testTag("tag_refresh_bonded"),
                    ) {
                        if (ui.loading)
                            CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                        else
                            Icon(
                                Icons.Default.Refresh,
                                strings.getString(R.string.refresh_list),
                                tint = ElectricBlue,
                            )
                    }
                }
            }
            if (ui.watches.isEmpty()) {
                item {
                    Text(
                        strings.getString(ui.issueRes ?: R.string.no_paired_devices_found),
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary,
                    )
                }
            } else {
                item {
                    GroupedCard(innerPadding = 0.dp) {
                        ui.watches.forEachIndexed { index, watch ->
                            if (index > 0)
                                dev.ricky.galaxywatchmanagerfree.ui.components.GroupedDivider()
                            val selected = watch.mac.equals(ui.selectedMac, true)
                            Row(
                                Modifier.fillMaxWidth()
                                    .selectable(
                                        selected = selected,
                                        role = androidx.compose.ui.semantics.Role.RadioButton,
                                        onClick = { onSelect(watch.mac) },
                                    )
                                    .heightIn(min = 56.dp)
                                    .padding(16.dp)
                                    .testTag("tag_device_${watch.mac}"),
                                horizontalArrangement = Arrangement.spacedBy(16.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                val isMatchingMac =
                                    watch.mac.equals(connectedMac, true) ||
                                        (watch.mac.equals(ui.selectedMac, true) &&
                                            watchState?.connected == true)
                                val isCurrent = isMatchingMac && watchState?.sessionReady == true
                                val itemDisplayName =
                                    if (
                                        isMatchingMac &&
                                            watchState?.watchAlias?.isNotBlank() == true
                                    )
                                        watchState.displayName
                                    else watch.name
                                val modelName =
                                    if (
                                        isMatchingMac &&
                                            watchState?.modelName.orEmpty().isNotBlank()
                                    )
                                        watchState!!.modelName
                                    else watch.name
                                val modelNumber =
                                    if (isMatchingMac) watchState?.modelNumber.orEmpty() else ""
                                WatchDeviceGraphic(
                                    modelName = modelName,
                                    modelNumber = modelNumber,
                                    active = isCurrent && watchState?.startupSyncing == true,
                                    preset =
                                        if (isMatchingMac && watchState != null)
                                            WatchFacePresets.find(
                                                watchState.activeWatchfacePkg,
                                                watchState.activeWatchfaceCls,
                                            )
                                        else null,
                                    previewPath =
                                        if (isMatchingMac) watchState?.activeWatchfacePreviewPath
                                        else null,
                                    modifier = Modifier.size(44.dp),
                                )
                                Column(
                                    Modifier.weight(1f),
                                    verticalArrangement = Arrangement.spacedBy(4.dp),
                                ) {
                                    Text(
                                        itemDisplayName,
                                        style = MaterialTheme.typography.bodyLarge,
                                        color = TextPrimary,
                                    )
                                    if (
                                        isMatchingMac &&
                                            watchState?.watchAlias?.isNotBlank() == true &&
                                            watchState.modelName.isNotBlank() &&
                                            itemDisplayName != watchState.modelName
                                    ) {
                                        Text(
                                            watchState.modelName,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextSecondary,
                                        )
                                    } else {
                                        Text(
                                            watch.mac,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextSecondary,
                                        )
                                    }
                                    if (selected)
                                        Text(
                                            strings.getString(
                                                if (watch.mac.equals(connectedMac, true))
                                                    R.string.connected_2
                                                else R.string.connection_device_selected
                                            ),
                                            style = MaterialTheme.typography.labelMedium,
                                            color =
                                                if (watch.mac.equals(connectedMac, true))
                                                    EmeraldCharging
                                                else ElectricBlue,
                                        )
                                }
                                if (selected)
                                    Icon(
                                        Icons.Default.CheckCircle,
                                        null,
                                        tint = ElectricBlue,
                                        modifier = Modifier.size(24.dp),
                                    )
                            }
                        }
                    }
                }
            }
            item {
                TextButton(
                    onOpenBluetooth,
                    Modifier.fillMaxWidth().testTag("tag_open_bluetooth_settings"),
                ) {
                    Text(
                        strings.getString(
                            if (ui.issueRes == R.string.conn_permission_needed)
                                R.string.connection_grant_bluetooth
                            else R.string.connection_open_bluetooth
                        )
                    )
                }
            }
        }
    }
}

@Composable
private fun ConnectionStepChip(
    text: String,
    done: Boolean,
    active: Boolean,
    modifier: Modifier = Modifier,
) {
    val bgColor =
        when {
            done -> EmeraldCharging.copy(alpha = 0.12f)
            active -> ElectricBlue.copy(alpha = 0.15f)
            else -> CardBorder.copy(alpha = 0.25f)
        }
    val contentColor =
        when {
            done -> EmeraldCharging
            active -> ElectricBlue
            else -> TextTertiary
        }
    Surface(color = bgColor, shape = RoundedCornerShape(12.dp), modifier = modifier) {
        Row(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
        ) {
            Icon(
                if (done) Icons.Default.CheckCircle else Icons.Default.Circle,
                contentDescription = null,
                tint = contentColor,
                modifier = Modifier.size(11.dp),
            )
            Spacer(Modifier.width(4.dp))
            Text(
                text = text,
                style = MaterialTheme.typography.labelSmall,
                color = contentColor,
                maxLines = 1,
            )
        }
    }
}

@Composable
private fun KeepAliveCard(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val strings = context.resources
    val lifecycleOwner = LocalLifecycleOwner.current

    var isIgnored by
        androidx.compose.runtime.remember {
            androidx.compose.runtime.mutableStateOf(
                KeepAliveHelper.isBatteryOptimizationIgnored(context)
            )
        }
    var expandedGuide by
        androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    val brand = androidx.compose.runtime.remember { KeepAliveHelper.detectRomBrand() }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                isIgnored = KeepAliveHelper.isBatteryOptimizationIgnored(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    GroupedCard(cornerRadius = 28.dp, innerPadding = 18.dp, modifier = modifier) {
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Box(
                    modifier =
                        Modifier.size(44.dp)
                            .clip(CircleShape)
                            .background(
                                if (isIgnored) EmeraldCharging.copy(alpha = 0.14f)
                                else WarningAmber.copy(alpha = 0.14f)
                            ),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        if (isIgnored) Icons.Default.BatteryChargingFull
                        else Icons.Default.BatteryAlert,
                        contentDescription = null,
                        tint = if (isIgnored) EmeraldCharging else WarningAmber,
                        modifier = Modifier.size(24.dp),
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        strings.getString(R.string.keep_alive_and_battery_optimization),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary,
                    )
                    Spacer(Modifier.height(3.dp))
                    Text(
                        if (isIgnored) strings.getString(R.string.battery_optimization_unrestricted)
                        else strings.getString(R.string.battery_optimization_restricted),
                        style = MaterialTheme.typography.bodySmall,
                        color = if (isIgnored) EmeraldCharging else WarningAmber,
                    )
                }
            }

            Text(
                if (isIgnored) strings.getString(R.string.keep_alive_desc)
                else strings.getString(R.string.battery_optimization_restricted_desc),
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                lineHeight = 18.sp,
            )

            // Detected ROM Brand Badge
            Surface(
                color = CardBorder.copy(alpha = 0.25f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        strings.getString(R.string.rom_detected_prefix) +
                            " ${brand.brandName} (${brand.systemName})",
                        style = MaterialTheme.typography.labelMedium,
                        color = TextSecondary,
                    )
                }
            }

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                if (!isIgnored) {
                    Button(
                        onClick = {
                            KeepAliveHelper.requestIgnoreBatteryOptimization(context)
                            isIgnored = KeepAliveHelper.isBatteryOptimizationIgnored(context)
                        },
                        modifier = Modifier.weight(1f),
                    ) {
                        Text(
                            strings.getString(R.string.request_battery_whitelist),
                            maxLines = 1,
                            style = MaterialTheme.typography.labelSmall,
                        )
                    }
                }
                OutlinedButton(
                    onClick = { KeepAliveHelper.openAutoStartSettings(context) },
                    modifier = Modifier.weight(1f),
                ) {
                    Text(
                        strings.getString(R.string.open_autostart_settings),
                        maxLines = 1,
                        style = MaterialTheme.typography.labelSmall,
                    )
                }
            }

            // Collapsible step-by-step ROM guide
            Row(
                modifier =
                    Modifier.fillMaxWidth()
                        .clickable { expandedGuide = !expandedGuide }
                        .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(
                    strings.getString(R.string.keep_alive_guide_title),
                    style = MaterialTheme.typography.labelMedium,
                    color = ElectricBlue,
                )
                Icon(
                    if (expandedGuide) Icons.Default.KeyboardArrowUp
                    else Icons.Default.KeyboardArrowDown,
                    contentDescription = null,
                    tint = ElectricBlue,
                    modifier = Modifier.size(18.dp),
                )
            }

            AnimatedVisibility(expandedGuide) {
                Text(
                    strings.getString(brand.guideRes),
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    lineHeight = 20.sp,
                )
            }
        }
    }
}
