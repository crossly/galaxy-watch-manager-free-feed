package dev.ricky.galaxywatchmanagerfree.feature.handover

/**
 * Durable "restore point" for the companion handover.
 *
 * Each entry remembers the exact application enabled state observed *before* this app changed it.
 * Entries are added only for apps that are actually about to change, and an existing entry is never
 * overwritten: repeated disable attempts keep the first (true original) state.
 *
 * The encoding is intentionally plain and JVM-testable:
 * ```
 * com.google.android.wearable.app.cn|0
 * com.samsung.android.app.watchmanager|1
 * ```
 */
class HandoverJournal private constructor(val originalStates: Map<String, Int>) {

    constructor() : this(emptyMap())

    val isEmpty: Boolean
        get() = originalStates.isEmpty()

    val packages: Set<String>
        get() = originalStates.keys

    /**
     * Adds observed states only for allowlisted, currently-enabled apps that are not already
     * recorded. Existing entries are never replaced, so a repeat run cannot lose the true original
     * state after the user manually re-enabled an app.
     */
    fun snapshot(observedStates: Map<String, Int>): HandoverJournal {
        val additions =
            observedStates.filter { (packageName, state) ->
                OfficialCompanionApp.isAllowed(packageName) &&
                    HandoverPolicy.canDisable(state) &&
                    packageName !in originalStates
            }
        return if (additions.isEmpty()) this else HandoverJournal(originalStates + additions)
    }

    /** Drops entries that were returned to their original state (or were never changed). */
    fun without(packageNames: Set<String>): HandoverJournal {
        if (packageNames.isEmpty()) return this
        val remaining = originalStates.filterKeys { it !in packageNames }
        return if (remaining.size == originalStates.size) this else HandoverJournal(remaining)
    }

    fun encode(): String =
        originalStates.entries
            .sortedBy { it.key }
            .joinToString(separator = "\n") { (packageName, state) -> "$packageName|$state" }

    companion object {
        private const val SEPARATOR = '|'

        /**
         * Parses a persisted journal defensively. Malformed lines, non-allowlisted packages and
         * states that this app never snapshots are ignored. The first entry for a package wins.
         */
        fun decode(raw: String): HandoverJournal {
            if (raw.isBlank()) return HandoverJournal()
            val parsed = LinkedHashMap<String, Int>()
            for (line in raw.lineSequence()) {
                val trimmed = line.trim()
                if (trimmed.isEmpty()) continue
                val separator = trimmed.lastIndexOf(SEPARATOR)
                if (separator <= 0 || separator == trimmed.lastIndex) continue
                val packageName = trimmed.substring(0, separator)
                val state = trimmed.substring(separator + 1).toIntOrNull() ?: continue
                if (!OfficialCompanionApp.isAllowed(packageName)) continue
                if (!HandoverPolicy.canDisable(state)) continue
                if (!parsed.containsKey(packageName)) parsed[packageName] = state
            }
            return if (parsed.isEmpty()) HandoverJournal() else HandoverJournal(parsed)
        }
    }
}
