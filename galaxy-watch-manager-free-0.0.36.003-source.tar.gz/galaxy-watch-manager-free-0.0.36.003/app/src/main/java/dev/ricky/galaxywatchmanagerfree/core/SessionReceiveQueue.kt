package dev.ricky.galaxywatchmanagerfree.core

import java.util.ArrayDeque
import java.util.concurrent.Executor

internal class SessionReceiveQueue(
    private val executor: Executor,
    private val isActive: () -> Boolean,
    private val onClosed: () -> Unit,
    private val onFailure: (Exception) -> Unit,
    private val maxEvents: Int = 64,
    private val maxBytes: Int = 8 * 1024 * 1024,
) {
    private data class Event(
        val bytes: Int,
        val run: () -> Unit,
        val completion: java.util.concurrent.CompletableFuture<Boolean>? = null,
    )

    private val lock = java.lang.Object()
    private val pending = ArrayDeque<Event>()
    private var events = 0
    private var bytes = 0
    private var scheduled = false
    private var closed = false
    private var finished = false

    fun submit(byteCount: Int = 0, run: () -> Unit): Boolean = enqueue(Event(byteCount, run))

    fun await(run: () -> Unit): Boolean {
        val completion = java.util.concurrent.CompletableFuture<Boolean>()
        if (!enqueue(Event(0, run, completion))) return false
        return try {
            completion.get()
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
            false
        }
    }

    private fun enqueue(event: Event): Boolean {
        val byteCount = event.bytes
        require(byteCount >= 0)
        if (byteCount > maxBytes) return false
        val schedule =
            synchronized(lock) {
                while (
                    !closed && isActive() && (events >= maxEvents || bytes + byteCount > maxBytes)
                ) {
                    try {
                        lock.wait()
                    } catch (_: InterruptedException) {
                        Thread.currentThread().interrupt()
                        return false
                    }
                }
                if (closed || !isActive()) return false
                pending.addLast(event)
                events++
                bytes += byteCount
                (!scheduled).also { scheduled = true }
            }
        if (schedule) executor.execute(::drain)
        return true
    }

    fun close() {
        val schedule =
            synchronized(lock) {
                if (closed) return
                closed = true
                pending.forEach {
                    bytes -= it.bytes
                    events--
                    it.completion?.complete(false)
                }
                pending.clear()
                lock.notifyAll()
                (!scheduled).also { scheduled = true }
            }
        if (schedule) executor.execute(::drain)
    }

    private fun drain() {
        while (true) {
            var finish = false
            val event =
                synchronized(lock) {
                    if (closed || pending.isEmpty()) {
                        scheduled = false
                        if (closed && !finished) {
                            finished = true
                            finish = true
                        }
                        null
                    } else pending.removeFirst()
                }
            if (event == null) {
                if (finish) onClosed()
                return
            }
            try {
                if (isActive()) {
                    event.run()
                    event.completion?.complete(true)
                }
            } catch (error: Exception) {
                close()
                onFailure(error)
            } finally {
                event.completion?.complete(false)
                synchronized(lock) {
                    bytes -= event.bytes
                    events--
                    lock.notifyAll()
                }
            }
        }
    }
}
