package dev.ricky.galaxywatchmanagerfree.feature

import java.util.Locale

/** Cache/migration scope is the paired Bluetooth device, not a provisional Wear node ID. */
object DeviceScope {
    fun address(value: String?): String? =
        value?.trim()?.lowercase(Locale.ROOT)?.takeIf {
            it.matches(Regex("(?:[0-9a-f]{2}:){5}[0-9a-f]{2}"))
        }

    fun preferences(base: String, device: String?): String =
        base + "_" + (address(device)?.replace(":", "") ?: "unassigned")

    fun canImportLegacy(device: String?, owner: String?): Boolean =
        address(device)?.let { it == address(owner) } == true
}
