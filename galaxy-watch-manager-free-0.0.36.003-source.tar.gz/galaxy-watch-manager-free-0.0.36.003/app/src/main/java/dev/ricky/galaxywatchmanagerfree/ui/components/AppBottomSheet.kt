package dev.ricky.galaxywatchmanagerfree.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.SheetState
import androidx.compose.material3.Surface
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import dev.ricky.galaxywatchmanagerfree.ui.theme.CardBorder
import dev.ricky.galaxywatchmanagerfree.ui.theme.DeepCanvas
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextPrimary

/** Shared surface and drag handle for detail sheets. Content owns its scrolling and toolbar. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppBottomSheet(
    onDismissRequest: () -> Unit,
    sheetState: SheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
    centerInWideWindow: Boolean = false,
    content: @Composable ColumnScope.() -> Unit,
) {
    val window = LocalConfiguration.current
    val currentContent by rememberUpdatedState(content)
    val body = remember { movableContentOf { Column(content = currentContent) } }
    if (centerInWideWindow && window.screenWidthDp >= 600 && window.screenHeightDp >= 480) {
        Dialog(onDismissRequest, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Surface(
                modifier =
                    Modifier.padding(24.dp)
                        .widthIn(max = 560.dp)
                        .fillMaxWidth()
                        .heightIn(max = (window.screenHeightDp - 48).dp),
                shape = MaterialTheme.shapes.extraLarge,
                color = DeepCanvas,
                contentColor = TextPrimary,
            ) {
                body()
            }
        }
        return
    }
    ModalBottomSheet(
        onDismissRequest = onDismissRequest,
        sheetState = sheetState,
        sheetMaxWidth = 840.dp,
        containerColor = DeepCanvas,
        contentColor = TextPrimary,
        shape =
            MaterialTheme.shapes.extraLarge.copy(
                bottomStart = androidx.compose.foundation.shape.CornerSize(0.dp),
                bottomEnd = androidx.compose.foundation.shape.CornerSize(0.dp),
            ),
        dragHandle = {
            Box(
                Modifier.padding(top = 10.dp, bottom = 4.dp)
                    .width(36.dp)
                    .height(4.5.dp)
                    .clip(RoundedCornerShape(999.dp))
                    .background(CardBorder)
            )
        },
        content = { body() },
    )
}
