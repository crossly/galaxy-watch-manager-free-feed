package dev.ricky.galaxywatchmanagerfree.wcs

import java.io.ByteArrayOutputStream

/** Reassemble Envelope pieces before parsing any inner protobuf message. */
class WcsPieceAssembler(
    private val debug: (() -> String) -> Unit = {},
    private val clock: () -> Long = System::currentTimeMillis,
) {
    private data class Pending(
        val count: Int,
        val created: Long,
        val pieces: MutableMap<Int, ByteArray>,
    )

    private val pending = linkedMapOf<String, Pending>()

    @Synchronized
    fun reset() {
        debug { "[WCS分片] reset streams=${pending.size}" }
        pending.clear()
    }

    private fun reject(reason: String): ByteArray? {
        debug { "[WCS分片] rejected $reason" }
        return null
    }

    @Synchronized
    fun accept(body: ByteArray): ByteArray? {
        val env = Proto.parse(body)
        val count = env.num(4) ?: 1L
        if (count == 1L) return body
        if (count !in 2L..512L) return reject("reason=invalid_count count=$count")
        val digest = env.text(2) ?: return reject("reason=missing_digest")
        val index = env.num(3) ?: return reject("reason=missing_index digest=$digest")
        if (index !in 1..count)
            return reject("reason=invalid_index index=$index count=$count digest=$digest")
        val piece =
            env.raw(1) ?: return reject("reason=missing_payload digest=$digest index=$index")
        if (piece.size > 65536)
            return reject("reason=oversized_piece digest=$digest bytes=${piece.size}")
        val now = clock()
        pending.entries.removeAll {
            val expired = now - it.value.created > 30_000
            if (expired)
                debug {
                    "[WCS分片] expired digest=${it.key} received=${it.value.pieces.size}/${it.value.count}"
                }
            expired
        }
        if (!pending.containsKey(digest) && pending.size >= 8) {
            val evicted = pending.keys.first()
            pending.remove(evicted)
            debug { "[WCS分片] evicted digest=$evicted reason=stream_limit" }
        }
        val item = pending.getOrPut(digest) { Pending(count.toInt(), now, linkedMapOf()) }
        if (item.count != count.toInt()) {
            pending.remove(digest)
            return reject(
                "reason=count_changed digest=$digest expected=${item.count} actual=$count"
            )
        }
        val old = item.pieces[index.toInt()]
        if (old != null && !old.contentEquals(piece)) {
            pending.remove(digest)
            return reject("reason=conflicting_piece digest=$digest index=$index")
        }
        item.pieces[index.toInt()] = piece
        val bytes = item.pieces.values.sumOf { it.size }
        if (bytes > 8 * 1024 * 1024) {
            pending.remove(digest)
            return reject("reason=stream_size digest=$digest bytes=$bytes")
        }
        debug {
            "[WCS分片] digest=$digest index=$index/$count bytes=${piece.size} received=${item.pieces.size} totalBytes=$bytes duplicate=${old != null}"
        }
        if (item.pieces.size != item.count) return null
        pending.remove(digest)
        val combined = ByteArrayOutputStream()
        for (i in 1..item.count) combined.write(
            item.pieces[i] ?: return reject("reason=missing_piece digest=$digest index=$i")
        )
        val inner = combined.toByteArray()
        if (WcsFrame.messageDigest(inner) != digest)
            return reject("reason=digest_mismatch digest=$digest bytes=${inner.size}")
        debug {
            "[WCS分片] complete digest=$digest bytes=${inner.size} count=$count elapsedMs=${now - item.created}"
        }
        return Proto.bytes(1, inner) +
            Proto.string(2, digest) +
            Proto.integer(3, 1) +
            Proto.integer(4, 1) +
            (env.num(5)?.let { Proto.integer(5, it) } ?: byteArrayOf())
    }
}
