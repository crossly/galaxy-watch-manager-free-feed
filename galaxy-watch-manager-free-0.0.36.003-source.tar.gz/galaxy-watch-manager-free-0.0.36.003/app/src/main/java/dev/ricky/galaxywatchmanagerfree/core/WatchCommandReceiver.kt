package dev.ricky.galaxywatchmanagerfree.core

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import dev.ricky.galaxywatchmanagerfree.feature.LogBus

/**
 * 外部指令入口（adb / Tasker / MacroDroid 自动化）。
 *
 * adb shell am broadcast -a dev.ricky.galaxywatchmanagerfree.CMD --es cmd psm --ez on true
 *
 * 支持的 cmd： refresh | battery | battery_details | memory | clean_ram battery_usage | battery_setting
 * | battery_protect (--ez on true) psm (--ez on true/false) | find | notif (--es title --es text)
 * setting_read | setting_write (--es path --es type bool|int|string --es value) | setting_dump
 * health | apps | watchfaces | media | notify_sync
 */
class WatchCommandReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        // 广播回调在主线程，协议处理与状态更新放到工作线程，避免阻塞 UI/通知派发
        val pending = goAsync()
        kotlin.concurrent.thread(name = "wcs-cmd") {
            try {
                handle(intent, context.applicationContext)
            } catch (t: Throwable) {
                LogBus.error("[CMD] 处理失败", t)
            } finally {
                pending.finish()
            }
        }
    }

    private fun handle(intent: Intent, appContext: Context) {
        val cmd = intent.getStringExtra("cmd") ?: return
        val repo = WatchController.repository
        LogBus.debug("[CMD] $cmd -> ready=${repo.state.value.sessionReady}")
        when (cmd) {
            "refresh" -> repo.refreshAll()
            "battery" -> repo.requestBattery()
            "battery_details" -> repo.requestBatteryDetails()
            "battery_usage" -> repo.requestBatteryUsage()
            "battery_setting" -> repo.requestBatterySetting()
            "battery_protect" -> repo.setBatteryProtection(intent.getBooleanExtra("on", true))
            "memory" -> repo.requestMemory()
            "clean_ram" -> repo.cleanRam()
            "psm" -> repo.setPowerSavingMode(intent.getBooleanExtra("on", true))
            "find" -> repo.findMyWatch()
            "notif" ->
                repo.sendTestNotification(
                    title = intent.getStringExtra("title") ?: "Galaxy Watch Manager Free",
                    text = intent.getStringExtra("text") ?: "测试通知",
                )
            "setting_read" -> repo.requestSettingInfo()
            "setting_write" -> {
                val path = intent.getStringExtra("path") ?: return
                val type = intent.getStringExtra("type") ?: "bool"
                val rawObj = intent.extras?.get("value")
                when (type) {
                    "bool" -> {
                        val b =
                            when (rawObj) {
                                is Boolean -> rawObj
                                is String -> rawObj.toBooleanStrictOrNull() ?: true
                                else -> true
                            }
                        repo.updateSetting(path, b)
                    }
                    "int" -> {
                        val n =
                            when (rawObj) {
                                is Number -> rawObj.toInt()
                                is String -> rawObj.toIntOrNull() ?: 0
                                else -> 0
                            }
                        repo.updateSetting(path, n)
                    }
                    else -> repo.updateSetting(path, rawObj?.toString() ?: "")
                }
            }
            "setting_dump" -> {
                repo
                    .settingItems()
                    .values
                    .sortedBy { it.path }
                    .forEach {
                        LogBus.debug {
                            "[DUMP] ${it.path} key=${it.key} type=${it.type} val=${it.display}"
                        }
                    }
            }
            "monitor_probe" -> repo.monitor.connect()
            "monitor_info" ->
                dev.ricky.galaxywatchmanagerfree.feature.monitor.HealthMonitorProtocol.Channel
                    .entries
                    .forEach { repo.monitor.request(it, "information") }
            "monitor_dump" -> {
                val monitor = repo.monitor.state.value
                LogBus.log(
                    "[健康监测器] 状态=${monitor.connection} received=${monitor.receivedCount} error=${monitor.error}"
                )
                monitor.information.forEach { (channel, data) ->
                    val json = org.json.JSONObject(data)
                    LogBus.log(
                        "[健康监测器] $channel version=${json.optInt("app_version_code")} calibration_time=${json.optLong("calibration_time", -1)} need_to_recal=${json.optBoolean("need_to_recal")} keys=${json.keys().asSequence().sorted().joinToString()}"
                    )
                }
            }
            "health_settings_dump" -> LogBus.log("[健康设置] ${repo.healthMeasurements.state.value}")
            "health_settings_set" -> {
                if (!intent.hasExtra("on")) return
                val enabled = intent.getBooleanExtra("on", false)
                val sent =
                    when (intent.getStringExtra("target")) {
                        "spo2" -> repo.healthMeasurements.setSleepOxygen(enabled)
                        "stress" -> repo.healthMeasurements.setStressContinuous(enabled)
                        "vascular" -> {
                            if (!repo.state.value.vascularLoadSupported) return
                            repo.healthMeasurements.setVascularLoad(enabled)
                        }
                        else -> return
                    }
                LogBus.log("[健康设置] 写入请求已发送=$sent")
            }
            "health_measure" -> {
                val kind =
                    when (intent.getStringExtra("target")) {
                        "spo2" ->
                            dev.ricky.galaxywatchmanagerfree.feature.HealthMeasurements.Kind.SPO2
                        "stress" ->
                            dev.ricky.galaxywatchmanagerfree.feature.HealthMeasurements.Kind.STRESS
                        else -> return
                    }
                repo.healthMeasurements.openMeasurement(kind)
            }
            "health_recover" -> repo.requestHealthRecovery()
            "health_dump" -> {
                val packets = org.json.JSONArray()
                repo.health.value.forEach { packet ->
                    packets.put(
                        org.json
                            .JSONObject()
                            .put("sequence", packet.sequenceNum)
                            .put("action", packet.action)
                            .put("decoded", org.json.JSONArray(packet.raw))
                    )
                }
                val file = java.io.File(appContext.filesDir, "health-debug.json")
                file.writeText(packets.toString())
                LogBus.log("[CMD] 导出 ${packets.length()} 个健康报文到 ${file.name}")
            }
            "health" -> repo.requestHealthSync()
            "health_module" -> {
                val module = intent.getStringExtra("module") ?: "PEDOMETER"
                val today = intent.getBooleanExtra("today", true)
                val hours = intent.getIntExtra("hours", 0)
                repo.requestHealthModule(module, today, hours)
            }
            "apps" -> repo.requestApps()
            "watchfaces",
            "watchface_get" -> {
                repo.requestActiveWatchface()
                repo.requestWatchfaceOrder()
            }
            "watchface_set" -> {
                val id = intent.getStringExtra("id")
                if (id != null) {
                    val preset = dev.ricky.galaxywatchmanagerfree.feature.WatchFacePresets.byId(id)
                    if (preset != null) {
                        repo.setActiveWatchface(preset)
                    } else {
                        LogBus.log("[CMD] 未知表盘 id: $id")
                    }
                } else {
                    val pkg = intent.getStringExtra("pkg") ?: return
                    val cls = intent.getStringExtra("cls") ?: return
                    repo.setActiveWatchface(pkg, cls)
                }
            }
            "wearapi_start" -> WatchController.startWearApi(appContext)
            "wearapi_nodes" -> WatchController.wearApiRefresh()
            "wearapi_send" -> {
                val path = intent.getStringExtra("path") ?: return
                val b64 = intent.getStringExtra("b64")
                val payload =
                    if (b64 != null) {
                        android.util.Base64.decode(b64, android.util.Base64.DEFAULT)
                    } else {
                        (intent.getStringExtra("text") ?: "").toByteArray(Charsets.UTF_8)
                    }
                LogBus.debug { "[WearApi→] path=$path payload=${LogBus.describe(payload)}" }
                WatchController.wearApiSend(path, payload)
            }
            "media" -> repo.requestMediaState()
            "notify_sync" -> repo.syncNotificationFeatures()

            // 诊断探针：任意 path/msgId/msgType + JSON data
            "probe" -> {
                val path = intent.getStringExtra("path") ?: return
                val msgId = intent.getStringExtra("msgid") ?: return
                val msgType = intent.getIntExtra("msgType", 4)
                val b64 = intent.getStringExtra("b64")
                val json =
                    if (b64 != null) {
                        val text =
                            String(
                                android.util.Base64.decode(b64, android.util.Base64.DEFAULT),
                                Charsets.UTF_8,
                            )
                        LogBus.debug { "[PROBE] payloadBytes=${text.toByteArray().size}" }
                        runCatching { org.json.JSONObject(text) }
                            .getOrElse {
                                LogBus.error("[PROBE] payload 解析失败", it)
                                null
                            }
                    } else {
                        intent.getStringExtra("json")?.let {
                            runCatching { org.json.JSONObject(it) }.getOrNull()
                        }
                    }
                repo.probe(path, msgId, msgType, json)
            }
            "notif_pkg" ->
                repo.probe(
                    dev.ricky.galaxywatchmanagerfree.wcs.WcsPaths.NOTI_BRIDGE,
                    "mobile_send_intent_notification",
                    4,
                    org.json
                        .JSONObject()
                        .put("package_name", intent.getStringExtra("pkg") ?: "com.tencent.mm")
                        .put("title", intent.getStringExtra("title") ?: "微信")
                        .put("body", intent.getStringExtra("text") ?: "测试消息")
                        .put("tag", "probe_${System.currentTimeMillis()}")
                        .put("time", System.currentTimeMillis()),
                )
            "notif_watch_only" ->
                repo.probe(
                    dev.ricky.galaxywatchmanagerfree.wcs.WcsPaths.NOTI_BRIDGE,
                    "request_only_show_on_watch_notification",
                    4,
                    org.json
                        .JSONObject()
                        .put("title", intent.getStringExtra("title") ?: "仅手表通知")
                        .put("body", intent.getStringExtra("text") ?: "探针测试")
                        .put(
                            "packageName",
                            intent.getStringExtra("pkg") ?: "com.samsung.android.messaging",
                        )
                        .put("actionCount", 0)
                        .put("customPanel", "")
                        .put("actionData", org.json.JSONArray()),
                )
            "notif_bridger" ->
                repo.sendBridgerNotification(
                    packageName = intent.getStringExtra("pkg") ?: "com.tencent.mm",
                    title = intent.getStringExtra("title") ?: "微信",
                    text = intent.getStringExtra("text") ?: "测试通知：你好！",
                    appName = intent.getStringExtra("app") ?: "微信",
                )
        }
    }
}
