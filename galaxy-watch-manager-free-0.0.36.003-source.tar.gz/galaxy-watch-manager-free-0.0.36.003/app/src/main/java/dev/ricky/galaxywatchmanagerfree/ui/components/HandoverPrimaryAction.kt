package dev.ricky.galaxywatchmanagerfree.ui.components

internal enum class HandoverPrimaryAction {
    NONE,
    DISABLE_AND_CONNECT,
    PREPARE_IDENTITY,
    CONTINUE_VERIFICATION,
    MANUAL,
}

internal fun resolveHandoverPrimaryAction(
    isPreparing: Boolean,
    canOneClickDisable: Boolean,
    hasPendingIdentity: Boolean,
    releasedToOfficialApps: Boolean,
    hasEnabledOfficialApp: Boolean,
    hasIdentity: Boolean,
    shizukuAvailable: Boolean,
): HandoverPrimaryAction =
    when {
        isPreparing && canOneClickDisable -> HandoverPrimaryAction.DISABLE_AND_CONNECT
        isPreparing && hasPendingIdentity -> HandoverPrimaryAction.CONTINUE_VERIFICATION
        isPreparing -> HandoverPrimaryAction.NONE
        (releasedToOfficialApps || hasEnabledOfficialApp) && shizukuAvailable && hasIdentity ->
            HandoverPrimaryAction.DISABLE_AND_CONNECT
        !hasIdentity -> HandoverPrimaryAction.PREPARE_IDENTITY
        releasedToOfficialApps || hasEnabledOfficialApp -> HandoverPrimaryAction.MANUAL
        else -> HandoverPrimaryAction.NONE
    }
