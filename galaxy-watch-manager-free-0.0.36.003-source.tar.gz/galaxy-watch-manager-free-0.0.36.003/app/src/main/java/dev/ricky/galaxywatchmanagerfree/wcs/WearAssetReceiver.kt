package dev.ricky.galaxywatchmanagerfree.wcs

import java.io.ByteArrayOutputStream

/** Wear SetAsset / FilePiece / AckAsset, separate from Envelope fragmentation and Channel API. */
class WearAssetReceiver(
    private val persist: (String, ByteArray) -> Boolean,
    private val contains: (String) -> Boolean,
    private val send: (ByteArray) -> Boolean,
    private val log: (String) -> Unit = {},
    private val now: () -> Long = System::currentTimeMillis,
) {
    private data class Transfer(val digest: String, val bytes: ByteArrayOutputStream, var touched: Long)
    private val pending = linkedMapOf<String, Transfer>()

    @Synchronized fun reset() { pending.clear() }

    @Synchronized
    fun receive(innerRaw: ByteArray): Boolean {
        pending.entries.removeAll { now() - it.value.touched > 60_000L }
        val inner = Proto.parse(innerRaw)
        inner.nested(4)?.let { asset ->
            val digest = asset.text(1) ?: return true
            if (!digest.matches(Regex("[A-Za-z0-9_-]{27}"))) return true
            if (inner.num(13) == 1L) {
                val key = WcsFrame.messageDigest(innerRaw)
                if (pending.size >= 16 && key !in pending) pending.remove(pending.keys.first())
                pending[key] = Transfer(digest, ByteArrayOutputStream(), now())
            } else {
                val bytes = asset.raw(2)
                if (bytes != null) complete(digest, bytes, null)
                else if (contains(digest)) acknowledge(digest)
            }
            return true
        }
        inner.nested(12)?.let { piece ->
            val key = piece.text(1) ?: return true
            val transfer = pending[key] ?: return true
            val bytes = piece.raw(3) ?: byteArrayOf()
            val total = pending.values.sumOf { it.bytes.size().toLong() }
            if (transfer.bytes.size().toLong() + bytes.size > 8 * 1024 * 1024L || total + bytes.size > 32 * 1024 * 1024L) {
                pending.remove(key)
                log("[Asset] 传输超出接收上限，未确认")
                return true
            }
            transfer.bytes.write(bytes)
            transfer.touched = now()
            if (piece.num(2) == 1L) {
                pending.remove(key)
                complete(transfer.digest, transfer.bytes.toByteArray(), piece.text(4))
            }
            return true
        }
        return false
    }

    private fun complete(digest: String, bytes: ByteArray, finalDigest: String?) {
        val actual = WcsFrame.messageDigest(bytes)
        if (actual != digest || (finalDigest != null && finalDigest != actual)) {
            log("[Asset] 文件摘要不匹配，未确认")
            return
        }
        if (persist(digest, bytes)) {
            val sent = acknowledge(digest)
            log(if (sent) "[Asset] 保存并确认 ${bytes.size}B $digest" else "[Asset] 文件已保存，确认未能入队")
        } else log("[Asset] 文件未落盘，未确认")
    }

    private fun acknowledge(digest: String): Boolean =
        send(Proto.bytes(5, Proto.string(1, digest)))
}
