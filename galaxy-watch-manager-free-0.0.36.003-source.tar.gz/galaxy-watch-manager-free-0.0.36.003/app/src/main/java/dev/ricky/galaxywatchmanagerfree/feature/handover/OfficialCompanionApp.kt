package dev.ricky.galaxywatchmanagerfree.feature.handover

/**
 * The complete set of official phone apps that may hold the watch's RFCOMM channel.
 *
 * This is an exact allowlist, not a prefix match. Samsung Health/Samsung Health Monitor and every
 * other package are deliberately absent: they are never disabled, cleared or uninstalled.
 */
enum class OfficialCompanionApp(val packageName: String, val fallbackName: String) {
    WEAR_CN("com.google.android.wearable.app.cn", "Wear OS (China)"),
    WEAR("com.google.android.wearable.app", "Wear OS"),
    WATCH4_PLUGIN("com.samsung.android.waterplugin", "Galaxy Watch4 Plugin"),
    WATCH5_PLUGIN("com.samsung.android.heartplugin", "Galaxy Watch5 Plugin"),
    WATCH6_PLUGIN("com.samsung.wearable.watch6plugin", "Galaxy Watch6 Plugin"),
    WATCH7_PLUGIN("com.samsung.wearable.watch7plugin", "Galaxy Watch7 Plugin"),
    GALAXY_WEARABLE("com.samsung.android.app.watchmanager", "Galaxy Wearable");

    companion object {
        private val byPackage: Map<String, OfficialCompanionApp> =
            entries.associateBy { it.packageName }

        val packageNames: List<String> = entries.map { it.packageName }

        fun find(packageName: String): OfficialCompanionApp? = byPackage[packageName]

        fun isAllowed(packageName: String): Boolean = byPackage.containsKey(packageName)
    }
}

/** PackageManager enabled-state values, duplicated to keep handover policy JVM-testable. */
object EnabledState {
    const val DEFAULT = 0
    const val ENABLED = 1
    const val DISABLED = 2
    const val DISABLED_USER = 3
    const val DISABLED_UNTIL_USED = 4
    const val UNKNOWN = -1
}

/** Pure state policy shared by the app and the shell-side user service. */
object HandoverPolicy {
    /** Only these states mean "the app is currently active and may hold Bluetooth". */
    fun isEnabled(state: Int): Boolean =
        state == EnabledState.DEFAULT || state == EnabledState.ENABLED

    /** A known non-enabled state is recoverable even if the durable snapshot was lost. */
    fun needsRestore(state: Int): Boolean = state != EnabledState.UNKNOWN && !isEnabled(state)

    /**
     * Prefer the exact state recorded before handover. With no snapshot, safely fall back to
     * DEFAULT so an app left disabled by an older install can be recovered.
     */
    fun restoreTarget(originalState: Int?, observedState: Int): Int? =
        originalState ?: EnabledState.DEFAULT.takeIf { needsRestore(observedState) }

    /**
     * Shell (UID 2000) may only move whole packages between DEFAULT, ENABLED and DISABLED_USER.
     * Anything else (including DISABLED/DISABLED_UNTIL_USED) is left untouched.
     */
    fun canDisable(state: Int): Boolean = isEnabled(state)

    fun canSet(state: Int): Boolean =
        state == EnabledState.DEFAULT ||
            state == EnabledState.ENABLED ||
            state == EnabledState.DISABLED_USER

    /**
     * pm disable-user uses DISABLED_USER; this also makes an OEM/manual restore distinguishable.
     */
    const val DISABLE_TARGET: Int = EnabledState.DISABLED_USER
}
