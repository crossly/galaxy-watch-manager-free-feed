package dev.ricky.galaxywatchmanagerfree.wcs

import java.util.Locale

/** Official plugin identities, verified against the four 26071051 APKs. */
enum class CompanionProfile(val packageName: String, val versionName: String) {
    WATCH4("com.samsung.android.waterplugin", "2.2.11.26071051"),
    WATCH5("com.samsung.android.heartplugin", "2.2.12.26071051"),
    WATCH6("com.samsung.wearable.watch6plugin", "2.2.13.26071051"),
    WATCH7("com.samsung.wearable.watch7plugin", "2.2.15.26071051");

    companion object {
        private val modelPattern = Regex("""\bSM-([RL]\d{3})[A-Z0-9]*\b""")
        private val namePattern = Regex("""\b(?:GALAXY\s+)?WATCH\s*([4-7])\b""")
        private val fePattern = Regex("""\b(?:GALAXY\s+)?WATCH\s+FE\b""")
        private val ultraPattern = Regex("""\b(?:GALAXY\s+)?WATCH\s+ULTRA\b(?!\s*2)""")

        fun fromPackage(packageName: String?): CompanionProfile? =
            entries.firstOrNull { it.packageName == packageName }

        fun fromDeviceName(name: String?): CompanionProfile? {
            val normalized = name?.uppercase(Locale.ROOT) ?: return null
            modelPattern.find(normalized)?.groupValues?.get(1)?.let { model ->
                when (model) {
                    "R860",
                    "R861",
                    "R865",
                    "R866",
                    "R870",
                    "R875",
                    "R880",
                    "R885",
                    "R890",
                    "R895" -> return WATCH4
                    "R900",
                    "R905",
                    "R910",
                    "R915",
                    "R920",
                    "R925" -> return WATCH5
                    "R930",
                    "R935",
                    "R940",
                    "R945",
                    "R950",
                    "R955",
                    "R960",
                    "R965" -> return WATCH6
                    "L300",
                    "L305",
                    "L310",
                    "L315",
                    "L700",
                    "L705" -> return WATCH7
                }
            }
            namePattern.find(normalized)?.groupValues?.get(1)?.let { generation ->
                return when (generation) {
                    "4" -> WATCH4
                    "5" -> WATCH5
                    "6" -> WATCH6
                    else -> WATCH7
                }
            }
            if (fePattern.containsMatchIn(normalized)) return WATCH4
            if (ultraPattern.containsMatchIn(normalized)) return WATCH7
            return null
        }

        /** Peer identity takes priority over a saved choice or unrelated installed plugins. */
        fun resolve(
            peerName: String?,
            savedPackage: String?,
            installedPackages: Collection<String>,
        ): CompanionProfile =
            fromDeviceName(peerName)
                ?: fromPackage(savedPackage)
                ?: installedPackages.mapNotNull(::fromPackage).distinct().singleOrNull()
                ?: WATCH7
    }
}
