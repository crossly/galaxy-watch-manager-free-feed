package dev.ricky.galaxywatchmanagerfree.ui.components

import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Bottom content padding for scrolling root pages.
 *
 * HomeScreen supplies the space actually occupied by the root navigation: the floating dock's top
 * gap, dock height and system navigation inset plus a content gap, or a plain content gap when the
 * navigation is fixed below the body or hidden. The 110.dp default keeps isolated screen previews
 * and tests outside HomeScreen readable.
 */
val LocalRootPageBottomPadding = compositionLocalOf<Dp> { 110.dp }
