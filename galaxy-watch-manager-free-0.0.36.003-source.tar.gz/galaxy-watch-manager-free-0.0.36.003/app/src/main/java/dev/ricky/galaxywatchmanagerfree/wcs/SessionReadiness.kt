package dev.ricky.galaxywatchmanagerfree.wcs

/**
 * WCS 握手就绪状态机。
 *
 * 旧实现把「是否已发 peers」「是否已就绪」拆成两个 `@Volatile` 布尔，在 NodeInfo 回帧线程、 SyncStart 回帧线程和状态回包线程上分别读取，`if
 * (!ready)` 的检查与赋值之间可被另一个线程插入， 因此理论上会重复初始化业务或重复回调 `onSessionReady()`。这里把两个标志收进同一把锁，
 * 每个事件返回一次[Transition]，调用方只根据返回值决定发什么帧，不再自己判断状态。
 *
 * 纯 Kotlin、无 Android 依赖，可直接单测（见 `SessionReadinessTest`）。
 */
class SessionReadiness {

    /** 一次状态迁移该做什么；[none] 表示本次事件无需任何动作。 */
    data class Transition(
        /** 需要广播 peers（NodeInfo/SyncStart 增量游标） */
        val peers: Boolean = false,
        /** 需要初始化业务通道（p2p feature / handshake / status exchange） */
        val activate: Boolean = false,
        /** 需要回调 `onSessionReady()` */
        val notifyReady: Boolean = false,
    ) {
        val isEmpty: Boolean
            get() = !peers && !activate && !notifyReady

        companion object {
            val none = Transition()
        }
    }

    private val lock = Any()

    @Volatile
    var ready: Boolean = false
        private set

    @Volatile
    var peersSent: Boolean = false
        private set

    /** 新传输连接：两个标志都要清空，否则重连会跳过初始化。 */
    fun reset() =
        synchronized(lock) {
            ready = false
            peersSent = false
        }

    /**
     * 收到对端 NodeInfo。
     * - 身份未配置或 peers 已发过 → 无动作（每个会话只广播一次）；
     * - 首次且尚未就绪 → 广播 peers 并初始化业务；
     * - 首次但已由 SyncStart/状态回包抢先就绪 → 只广播 peers，不重复初始化。
     */
    fun onPeerNodeInfo(hasPhoneNode: Boolean): Transition =
        synchronized(lock) {
            if (!hasPhoneNode || peersSent) return Transition.none
            peersSent = true
            if (ready) Transition(peers = true)
            else {
                ready = true
                Transition(peers = true, activate = true, notifyReady = true)
            }
        }

    /** 收到 SyncStart：仅当尚未就绪时初始化业务。 */
    fun onSyncStart(): Transition =
        synchronized(lock) {
            if (ready) Transition.none
            else {
                ready = true
                Transition(activate = true, notifyReady = true)
            }
        }

    /** 收到状态回包：旧固件的兜底就绪路径，已经就绪则忽略。 */
    fun onStatusReceived(): Transition =
        synchronized(lock) {
            if (ready) Transition.none
            else {
                ready = true
                Transition(notifyReady = true)
            }
        }
}
