package dev.ricky.galaxywatchmanagerfree.feature

import java.security.MessageDigest
import java.time.Instant
import java.time.ZoneId
import org.json.JSONArray
import org.json.JSONObject

internal class HealthExportData(
    private val snapshot: HealthExportSnapshot,
    private val zone: ZoneId,
) {
    private val state = snapshot.state
    private val modules = snapshot.sourceRecords.optJSONObject("modules") ?: JSONObject()

    fun records(vararg names: String): List<Pair<String, JSONObject>> =
        HealthRecordStore.newestRevisions(
            names.flatMap { name ->
                modules
                    .optJSONArray(name)
                    ?.let { array ->
                        (0 until array.length()).mapNotNull {
                            array.optJSONObject(it)?.let { row -> name to row }
                        }
                    }
                    .orEmpty()
            }
        )

    private fun number(row: JSONObject, vararg keys: String): Double? =
        keys.firstNotNullOfOrNull { key ->
            if (row.isNull(key)) null else row.optDouble(key, Double.NaN).takeIf { it.isFinite() }
        }

    private fun start(row: JSONObject): Long? =
        row.keys()
            .asSequence()
            .filter { it == "start_time" || it.endsWith(".start_time") }
            .sorted()
            .firstNotNullOfOrNull { row.optLong(it).takeIf { ts -> ts > 0 } }

    private fun sourceId(row: JSONObject): String =
        row.optString("datauuid").takeIf { it.isNotBlank() }
            ?: digest(HealthRecordStore.identity(row))

    private fun provenance(module: String, row: JSONObject): JSONObject =
        JSONObject()
            .put("source", "watch")
            .put("source_module", module)
            .put("source_record_id", sourceId(row))
            .put(
                "source_revision_epoch_ms",
                number(row, "update_time", "create_time")?.toLong()?.takeIf { it > 0 }
                    ?: JSONObject.NULL,
            )

    private fun quantity(
        type: String,
        unit: String,
        ts: Long,
        value: Number,
        id: String,
        meta: JSONObject,
    ): JSONObject =
        JSONObject(meta.toString())
            .put("record_id", id)
            .put("type", type)
            .put("start_time", time(ts))
            .put("start_time_epoch_ms", ts)
            .put("value", value)
            .put("unit", unit)

    val measurements: JSONArray by lazy {
        val result = mutableListOf<JSONObject>()
        records(HeartRateLog.MODULE).forEach { (module, row) ->
            HeartRateLog.pointsFromRecords(listOf(row)).forEach { point ->
                result +=
                    quantity(
                            "heart_rate",
                            "count/min",
                            point.ts,
                            point.bpm,
                            "heart_rate:${sourceId(row)}:${point.ts}",
                            provenance(module, row),
                        )
                        .put("minimum_value", point.minBpm)
                        .put("maximum_value", point.maxBpm)
            }
        }
        val fallbackHeart =
            (HeartRateLog.decodePoints(snapshot.retainedCache.optString("hr_points")) +
                    state.heartRatePoints +
                    state.heartRateHistory.values.flatten())
                .associateBy { it.ts }
        val rawHeartTimes = result.map { it.getLong("start_time_epoch_ms") }.toSet()
        fallbackHeart.values
            .filter { it.ts !in rawHeartTimes }
            .forEach { point ->
                result +=
                    quantity(
                            "heart_rate",
                            "count/min",
                            point.ts,
                            point.bpm,
                            "heart_rate:${point.ts}",
                            cachedSource(),
                        )
                        .put("minimum_value", point.minBpm)
                        .put("maximum_value", point.maxBpm)
            }
        HealthMetric.entries.forEach { metric ->
            val (type, unit) =
                when (metric) {
                    HealthMetric.SPO2 -> "oxygen_saturation" to "%"
                    HealthMetric.SKIN_TEMP -> "skin_temperature" to "Cel"
                    HealthMetric.RESPIRATORY -> "respiratory_rate" to "count/min"
                    HealthMetric.HRV -> "heart_rate_variability" to "ms"
                }
            val rawTimes = mutableSetOf<Long>()
            records(*metric.moduleKeys.toTypedArray()).forEach { (module, row) ->
                val bins =
                    HealthJson.array(row.opt("binning_data"))
                        ?: HealthJson.array(row.opt("binning"))
                val detail =
                    bins
                        ?.let { array -> (0 until array.length()).mapNotNull(array::optJSONObject) }
                        .orEmpty()
                        .filter { start(it) != null && metric.readings(it).isNotEmpty() }
                (detail.ifEmpty { listOf(row) }).forEach sample@{ sample ->
                    val ts = start(sample) ?: return@sample
                    metric.readings(sample).forEach { (field, value) ->
                        val method =
                            if (metric == HealthMetric.HRV) field.substringAfterLast('.') else null
                        result +=
                            quantity(
                                    type,
                                    unit,
                                    ts,
                                    value,
                                    "$type:${sourceId(row)}:$ts:${method ?: type}",
                                    provenance(module, row),
                                )
                                .put("source_field", field)
                                .put("method", method ?: JSONObject.NULL)
                        rawTimes += ts
                    }
                }
            }
            val cached =
                HealthMetricLog.decode(snapshot.retainedCache.optString("metric_${metric.name}"))
            (cached + state.metricSamples[metric].orEmpty())
                .associateBy { it.ts }
                .values
                .filter { it.ts !in rawTimes }
                .forEach { sample ->
                    result +=
                        quantity(
                                type,
                                unit,
                                sample.ts,
                                sample.value,
                                "$type:${sample.ts}",
                                cachedSource(),
                            )
                            .put("source_field", JSONObject.NULL)
                            .put(
                                "method",
                                if (metric == HealthMetric.HRV) "unknown" else JSONObject.NULL,
                            )
                }
        }
        val rawStressTimes = mutableSetOf<Long>()
        records(StressLog.MODULE).forEach { (module, row) ->
            StressLog.pointsFromRecords(listOf(row)).forEach { point ->
                result +=
                    quantity(
                            "stress",
                            "{score}",
                            point.ts,
                            point.score,
                            "stress:${sourceId(row)}:${point.ts}",
                            provenance(module, row),
                        )
                        .put("minimum_value", point.min)
                        .put("maximum_value", point.max)
                        .put("method", "samsung_raw_score")
                rawStressTimes += point.ts
            }
        }
        (StressLog.decodePoints(snapshot.retainedCache.optString("stress_points")) +
                state.stressHistory.values.flatten())
            .associateBy { it.ts }
            .values
            .filter { it.ts !in rawStressTimes }
            .forEach { point ->
                result +=
                    quantity(
                            "stress",
                            "{score}",
                            point.ts,
                            point.score,
                            "stress:${point.ts}",
                            cachedSource(),
                        )
                        .put("minimum_value", point.min)
                        .put("maximum_value", point.max)
                        .put("method", "samsung_raw_score")
            }
        state.bpRecords.forEach { row ->
            val meta = JSONObject().put("source", "watch_samsung_health_monitor")
            result +=
                quantity(
                    "blood_pressure_systolic",
                    "mm[Hg]",
                    row.startTime,
                    row.systolic,
                    row.id,
                    meta,
                )
            result +=
                quantity(
                    "blood_pressure_diastolic",
                    "mm[Hg]",
                    row.startTime,
                    row.diastolic,
                    row.id,
                    meta,
                )
            if (row.heartRate > 0)
                result += quantity("pulse", "count/min", row.startTime, row.heartRate, row.id, meta)
        }
        val valid =
            result.filter {
                it.getLong("start_time_epoch_ms") > 0 && it.getDouble("value").isFinite()
            }
        val unique = linkedMapOf<Pair<String, String>, JSONObject>()
        valid.forEach { row ->
            val key = row.getString("type") to row.getString("record_id")
            val old = unique[key]
            if (
                old == null ||
                    row.optLong("source_revision_epoch_ms") >=
                        old.optLong("source_revision_epoch_ms")
            )
                unique[key] = row
        }
        JSONArray(unique.values.toList())
    }

    val activityIntervals: JSONArray by lazy {
        JSONArray(
            records(HealthStepParser.MODULE_STEP_COUNT).mapNotNull { (module, row) ->
                val ts = start(row) ?: return@mapNotNull null
                provenance(module, row)
                    .put("record_id", sourceId(row))
                    .put("start_time", time(ts))
                    .put("start_time_epoch_ms", ts)
                    .put(
                        "end_time",
                        number(row, "end_time")?.toLong()?.takeIf { it >= ts }?.let(::time)
                            ?: JSONObject.NULL,
                    )
                    .put("steps", steps(row) ?: JSONObject.NULL)
                    .put("active_energy_kcal", amount(row, "calorie") ?: JSONObject.NULL)
                    .put("distance_m", amount(row, "distance") ?: JSONObject.NULL)
            }
        )
    }

    private fun amount(row: JSONObject, key: String): Double? =
        number(row, key, "com.samsung.health.step_count.$key")?.takeIf { it >= 0 }

    private fun steps(row: JSONObject): Int? {
        number(row, "count", "com.samsung.health.step_count.count")
            ?.takeIf { it >= 0 }
            ?.let {
                return it.toInt()
            }
        val run =
            number(row, "run_step", "com.samsung.health.step_count.run_step")?.takeIf { it >= 0 }
        val walk =
            number(row, "walk_step", "com.samsung.health.step_count.walk_step")?.takeIf { it >= 0 }
        return if (run == null && walk == null) null else ((run ?: 0.0) + (walk ?: 0.0)).toInt()
    }

    val dailyActivity: JSONArray by lazy {
        val legacy =
            HealthTimeline.decodeHistory(snapshot.retainedCache.optString("history")) +
                state.dailyHistory
        val intervals =
            objects(activityIntervals).groupBy { day(it.getLong("start_time_epoch_ms")) }
        val summaries =
            records(HealthStepParser.MODULE_DAY_SUMMARY)
                .mapNotNull { (_, row) -> dateKey(row.optString("day_time"))?.let { it to row } }
                .groupBy({ it.first }, { it.second })
                .mapValues { (_, rows) -> rows.maxBy { it.optLong("update_time") } }
        JSONArray(
            (legacy.keys + intervals.keys + summaries.keys).sorted().map { date ->
                val summary = summaries[date]
                val parts = intervals[date].orEmpty()
                val old = legacy[date]
                fun total(key: String): Double? =
                    parts
                        .takeIf { it.isNotEmpty() && it.all { row -> !row.isNull(key) } }
                        ?.sumOf { it.getDouble(key) }
                val summarySteps =
                    summary?.let(HealthStepParser::daySummarySteps)?.takeIf { it >= 0 }
                JSONObject()
                    .put("local_date", date)
                    .put("source", "app_daily_projection")
                    .put(
                        "steps",
                        summarySteps
                            ?: total("steps")?.toInt()
                            ?: old?.steps?.takeIf { it > 0 }
                            ?: JSONObject.NULL,
                    )
                    .put(
                        "active_energy_kcal",
                        summary?.let { amount(it, "calorie") }
                            ?: total("active_energy_kcal")
                            ?: old?.calories?.takeIf { it > 0 }
                            ?: JSONObject.NULL,
                    )
                    .put(
                        "distance_m",
                        summary?.let { amount(it, "distance") }
                            ?: total("distance_m")
                            ?: old?.distanceMeters?.takeIf { it > 0 }
                            ?: JSONObject.NULL,
                    )
                    .put(
                        "coverage",
                        if (summary != null) "watch_day_summary"
                        else if (parts.isNotEmpty()) "retained_intervals_partial"
                        else "legacy_unknown",
                    )
            }
        )
    }

    val floors: JSONArray by lazy {
        JSONArray(
            records("com.samsung.shealth.floors_climbed", "com.samsung.health.floors_climbed")
                .mapNotNull { (module, row) ->
                    val ts = start(row) ?: return@mapNotNull null
                    val count =
                        number(
                                row,
                                "floor_count",
                                "com.samsung.health.floors_climbed.floor_count",
                                "floor",
                                "count",
                                "floors",
                            )
                            ?.takeIf { it >= 0 }
                    provenance(module, row)
                        .put("record_id", sourceId(row))
                        .put("start_time", time(ts))
                        .put("start_time_epoch_ms", ts)
                        .put(
                            "end_time",
                            number(row, "end_time")?.toLong()?.takeIf { it >= ts }?.let(::time)
                                ?: JSONObject.NULL,
                        )
                        .put("floors", count ?: JSONObject.NULL)
                        .put("unit", "{floor}")
                }
        )
    }

    val vascularLoad: JSONArray by lazy {
        val raw =
            records(VascularLoadLog.MODULE).mapNotNull { (module, row) ->
                VascularLoadLog.parse(row)?.let { Triple(it, module, row) }
            }
        val fallback =
            state.vascularLoad.records.filter { entry -> raw.none { it.first.id == entry.id } }
        JSONArray(
            raw.map { (entry, module, row) -> vascular(entry, provenance(module, row)) } +
                fallback.map { vascular(it, cachedSource()) }
        )
    }

    private fun vascular(entry: VascularLoadLog.Entry, meta: JSONObject): JSONObject =
        meta
            .put("record_id", entry.id)
            .put("start_time", time(entry.startMillis))
            .put("start_time_epoch_ms", entry.startMillis)
            .put("end_time", time(entry.endMillis))
            .put("samsung_type_code", entry.type.code)
            .put("type", entry.type.name.lowercase(java.util.Locale.ROOT))
            .put("measurement", entry.measurement ?: JSONObject.NULL)
            .put("time_offset_ms", entry.timeOffset)
            .put("tracking_local_date", entry.trackingDate.toString())
            .put(
                "band",
                if (entry.type == VascularLoadLog.Type.MEASUREMENT)
                    entry.band.name.lowercase(java.util.Locale.ROOT)
                else JSONObject.NULL,
            )

    val sleepSessions: List<SleepParser.Session> by lazy {
        val raw =
            SleepParser.sessions(
                records(SleepParser.MODULE_SLEEP, SleepParser.MODULE_SLEEP_LEGACY).map {
                    it.second
                },
                records(SleepParser.MODULE_SLEEP_DATA).map { it.second },
                records(SleepParser.MODULE_SLEEP_STAGE, SleepParser.MODULE_SLEEP_STAGE_LEGACY).map {
                    it.second
                },
            )
        val displayed =
            SleepParser.decodeSessions(snapshot.retainedCache.optString("sleep_sessions_json")) +
                listOfNotNull(state.sleep) +
                state.sleepSessions +
                state.allSleepSessions
        val byId = displayed.associateBy { sleepIdentity(it) }.toMutableMap()
        raw.forEach { session ->
            val old = byId[sleepIdentity(session)]
            // Local inference trims bounds inside the same record; keep its stages.
            val keepLocalInference =
                old != null &&
                    session.segments.isEmpty() &&
                    old.segments.isNotEmpty() &&
                    old.startMillis >= session.startMillis &&
                    old.endMillis <= session.endMillis
            if (
                !keepLocalInference &&
                    (session.segments.isNotEmpty() ||
                        old == null ||
                        old.startMillis != session.startMillis ||
                        old.endMillis != session.endMillis)
            )
                byId[sleepIdentity(session)] = session
        }
        SleepParser.mergeSessions(byId.values.toList(), snapshot.manualNaps).sortedBy {
            it.startMillis
        }
    }

    val localSleepAnalysis: JSONArray by lazy {
        JSONArray(
            snapshot.localSleepResults
                .keys()
                .asSequence()
                .sorted()
                .map { key ->
                    val encoded = snapshot.localSleepResults.get(key)
                    val decoded = SleepParser.decode(encoded.toString())
                    JSONObject()
                        .put("cache_key", key)
                        .put("retained_result", encoded)
                        .put("session", decoded?.let(::sleepJson) ?: JSONObject.NULL)
                }
                .toList()
        )
    }

    fun sleepJson(row: SleepParser.Session): JSONObject =
        JSONObject()
            .put("record_id", row.id.ifBlank { "sleep:${row.startMillis}:${row.endMillis}" })
            .put("start_time", time(row.startMillis))
            .put("start_time_epoch_ms", row.startMillis)
            .put("end_time", time(row.endMillis))
            .put("source", row.analysisSource ?: "watch")
            .put("recorded_end_time", row.recordedEndMillis?.let(::time) ?: JSONObject.NULL)
            .put(
                "time_asleep_minutes",
                if (row.hasSleepDuration) row.asleepMinutes else JSONObject.NULL,
            )
            .put("reported_sleep_minutes", row.reportedSleepMinutes ?: JSONObject.NULL)
            .put("efficiency_percent", row.efficiencyPercent ?: JSONObject.NULL)
            .put("reported_efficiency_percent", row.efficiency ?: JSONObject.NULL)
            .put("score", row.score ?: JSONObject.NULL)
            .put("computed_score", row.computedScore?.total ?: JSONObject.NULL)
            .put(
                "computed_score_algorithm",
                if (row.computedScore != null) SleepScore.SOURCE else JSONObject.NULL,
            )
            .put("score_source", row.displayScoreSource ?: JSONObject.NULL)
            .put(
                "stages",
                JSONArray(
                    row.segments.map { segment ->
                        JSONObject()
                            .put("start_time", time(segment.startMillis))
                            .put("end_time", time(segment.endMillis))
                            .put("stage", segment.stage.name.lowercase(java.util.Locale.ROOT))
                    }
                ),
            )

    private fun sleepIdentity(row: SleepParser.Session): String =
        row.id.ifBlank { "${row.startMillis}:${row.endMillis}" }

    private fun cachedSource(): JSONObject =
        JSONObject()
            .put("source", "retained_app_cache")
            .put("source_revision_epoch_ms", JSONObject.NULL)

    private fun day(ts: Long): String =
        Instant.ofEpochMilli(ts).atZone(zone).toLocalDate().toString()

    fun dateKey(value: String?): String? = HealthStepParser.dateKey(value, zone)

    companion object {
        fun time(ts: Long): String = Instant.ofEpochMilli(ts).toString()

        fun objects(array: JSONArray): List<JSONObject> =
            (0 until array.length()).map(array::getJSONObject)

        private fun digest(value: String): String =
            MessageDigest.getInstance("SHA-256")
                .digest(value.toByteArray(Charsets.UTF_8))
                .joinToString("") { "%02x".format(it) }
    }
}
