package dev.ricky.galaxywatchmanagerfree.ui.components

import android.content.Context
import android.content.Intent
import android.content.res.Resources
import android.net.Uri
import android.provider.Settings
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.core.UiNotify
import dev.ricky.galaxywatchmanagerfree.core.WatchController
import dev.ricky.galaxywatchmanagerfree.feature.DeviceIdentityStore
import dev.ricky.galaxywatchmanagerfree.feature.OnboardingStatus
import dev.ricky.galaxywatchmanagerfree.feature.handover.HandoverPolicy
import dev.ricky.galaxywatchmanagerfree.feature.handover.OfficialAppHandover
import dev.ricky.galaxywatchmanagerfree.feature.handover.OfficialCompanionApp
import dev.ricky.galaxywatchmanagerfree.feature.handover.ShizukuAccess
import dev.ricky.galaxywatchmanagerfree.ui.theme.CardSurfaceElevated
import dev.ricky.galaxywatchmanagerfree.ui.theme.EmeraldCharging
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextPrimary
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextSecondary
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextTertiary
import dev.ricky.galaxywatchmanagerfree.ui.theme.WarningAmber
import kotlinx.coroutines.launch

/** Companion handover card for official Wear OS / Galaxy Wearable app coexistence. */
@Composable
fun CompanionHandoverCard(
    selectedMac: String,
    selectedDeviceName: String,
    modifier: Modifier = Modifier,
    expandRequest: Int = 0,
    expandByDefault: Boolean = true,
    onConnectionOwnershipChanged: () -> Unit = {},
) {
    val context = LocalContext.current
    val appContext = context.applicationContext
    val strings = context.resources
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()

    val handover = remember(appContext) { OfficialAppHandover(appContext) }
    val handoverState by handover.state.collectAsState()
    val progress by WatchController.connectionProgress.collectAsState()
    val status =
        if (progress.mac.equals(selectedMac, true)) progress.status else OnboardingStatus.IDLE
    val connectionBusy =
        status == OnboardingStatus.ACQUIRING_IDENTITY ||
            status == OnboardingStatus.CONNECTING ||
            status == OnboardingStatus.VERIFYING_IDENTITY

    var busy by remember { mutableStateOf(false) }
    var refreshToken by remember { mutableIntStateOf(0) }
    // Forces a pending-identity re-read after synchronous prepare calls.
    var identityToken by remember { mutableIntStateOf(0) }

    DisposableEffect(handover) {
        handover.start()
        onDispose { handover.close() }
    }

    LaunchedEffect(handover, refreshToken) { handover.refresh() }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                refreshToken++
                identityToken++
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val store =
        remember(appContext, selectedMac) {
            if (selectedMac.isNotBlank()) DeviceIdentityStore(appContext, selectedMac) else null
        }
    val pendingNode =
        remember(store, identityToken, progress) { store?.pendingHandoverNode.orEmpty() }
    val confirmedNode =
        remember(store, identityToken, progress) { store?.confirmedPhoneNode.orEmpty() }
    val candidateNode =
        remember(store, identityToken, progress) { store?.candidatePhoneNode.orEmpty() }
    val releasedToOfficialApps =
        remember(store, identityToken, progress, handoverState.apps) {
            store?.releasedToOfficialApps == true
        }
    // A staged or in-process candidate is never presented as a verified identity.
    val hasConfirmedIdentity = confirmedNode.isNotBlank()
    val hasCandidateIdentity = pendingNode.isNotBlank() || candidateNode.isNotBlank()
    // Preserves the previous enablement rule for the one-click disable action.
    val hasIdentity = hasConfirmedIdentity || hasCandidateIdentity
    val hasRestorePoint = handoverState.hasRestorePoint
    val hasDisabledOfficialApp =
        handoverState.apps.any { app ->
            app.installed == true && HandoverPolicy.needsRestore(app.enabledState)
        }
    val hasEnabledOfficialApp = handoverState.apps.any { it.installed != false && it.enabled }
    val installedAppCount = handoverState.apps.count { it.installed != false }
    val disabledAppCount = handoverState.apps.count { it.installed == true && !it.enabled }
    val canRestoreOfficialApps = hasRestorePoint || hasDisabledOfficialApp
    val shizuku = handoverState.access
    val working = busy || handoverState.busy
    val isPreparing =
        status == OnboardingStatus.PREPARING_HANDOVER || store?.handoverPreparing == true
    // Connection keeps this optional card collapsed; onboarding opens it by default. Preparation
    // pauses the connection and needs an explicit Continue or Cancel, so it opens on its own.
    var expanded by rememberSaveable(selectedMac) { mutableStateOf(expandByDefault) }
    var appDetailsExpanded by rememberSaveable(selectedMac) { mutableStateOf(false) }
    var manualExpanded by rememberSaveable(selectedMac) { mutableStateOf(false) }
    var confirmRestore by remember { mutableStateOf(false) }
    LaunchedEffect(isPreparing) { if (isPreparing) expanded = true }
    LaunchedEffect(expandRequest) { if (expandRequest > 0) expanded = true }

    // Shizuku can act only after an identity is staged; prepared state must still offer the
    // one-click disable instead of forcing Continue with the official apps still enabled.
    val canOneClickDisable =
        shizuku == ShizukuAccess.AVAILABLE && pendingNode.isNotBlank() && hasEnabledOfficialApp
    val primaryAction =
        resolveHandoverPrimaryAction(
            isPreparing = isPreparing,
            canOneClickDisable = canOneClickDisable,
            hasPendingIdentity = pendingNode.isNotBlank(),
            releasedToOfficialApps = releasedToOfficialApps,
            hasEnabledOfficialApp = hasEnabledOfficialApp,
            hasIdentity = hasIdentity,
            shizukuAvailable = shizuku == ShizukuAccess.AVAILABLE,
        )

    fun refreshAll() {
        refreshToken++
        identityToken++
    }

    fun prepareHandover() {
        if (working) return
        val prepared = WatchController.prepareHandover(context)
        identityToken++
        onConnectionOwnershipChanged()
        if (!prepared) UiNotify.show(R.string.handover_prepare_failed)
    }

    fun disableOfficialApps() {
        if (working) return
        val targetMac = selectedMac
        // Never release official apps before a candidate identity exists.
        if (pendingNode.isBlank()) {
            if (!WatchController.prepareHandover(context)) {
                UiNotify.show(R.string.handover_identity_required)
                return
            }
            identityToken++
            val staged = DeviceIdentityStore(context, selectedMac).pendingHandoverNode.isNotBlank()
            if (!staged) {
                UiNotify.show(R.string.handover_identity_required)
                return
            }
        }
        scope.launch {
            busy = true
            try {
                if (handover.disableOfficialApps()) {
                    // The coroutine outlives the composition that started it; never continue a
                    // different watch that became selected while the apps were being disabled.
                    if (!targetMac.equals(WatchController.savedMac, true)) {
                        UiNotify.show(R.string.handover_target_changed)
                    } else if (WatchController.continueHandover(context)) {
                        UiNotify.show(R.string.handover_disabled_continuing)
                    } else {
                        UiNotify.show(R.string.handover_continue_failed)
                    }
                } else {
                    UiNotify.show(R.string.handover_disable_failed)
                }
                refreshAll()
                onConnectionOwnershipChanged()
            } finally {
                busy = false
            }
        }
    }

    fun restoreOfficialApps() {
        if (working) return
        UiNotify.show(R.string.handover_restoring)
        scope.launch {
            busy = true
            try {
                // Persist the handoff before enabling official apps. A process restart must not
                // bring our foreground service back and fight the restored official stack.
                WatchController.releaseConnectionToOfficialApps(context)
                if (handover.restoreOfficialApps()) UiNotify.show(R.string.handover_restored)
                else UiNotify.show(R.string.handover_restore_failed)
                refreshAll()
                onConnectionOwnershipChanged()
            } finally {
                busy = false
            }
        }
    }

    val summary =
        when {
            isPreparing && pendingNode.isNotBlank() ->
                strings.getString(R.string.handover_waiting_candidate)
            isPreparing -> strings.getString(R.string.handover_waiting_identity)
            releasedToOfficialApps -> strings.getString(R.string.handover_summary_official)
            hasDisabledOfficialApp && installedAppCount > 0 ->
                strings.getString(
                    R.string.handover_summary_direct,
                    disabledAppCount,
                    installedAppCount,
                )
            else -> strings.getString(R.string.handover_summary_optional)
        }
    val chevronRotation by
        animateFloatAsState(targetValue = if (expanded) 180f else 0f, label = "handoverChevron")
    val expandState =
        strings.getString(if (expanded) R.string.action_collapse else R.string.action_expand)

    GroupedCard(modifier = modifier, innerPadding = 0.dp) {
        GroupedCardRow(
            title = strings.getString(R.string.handover_title),
            subtitle = summary,
            icon = Icons.Default.Info,
            iconTint =
                when {
                    isPreparing -> WarningAmber
                    hasDisabledOfficialApp -> EmeraldCharging
                    else -> TextSecondary
                },
            iconBackground =
                when {
                    isPreparing -> WarningAmber.copy(alpha = 0.16f)
                    hasDisabledOfficialApp -> EmeraldCharging.copy(alpha = 0.13f)
                    else -> CardSurfaceElevated
                },
            onClick = { expanded = !expanded },
            modifier =
                Modifier.semantics {
                        role = Role.Button
                        stateDescription = expandState
                    }
                    .testTag("tag_handover_expand"),
            trailing = {
                Icon(
                    imageVector = Icons.Default.ExpandMore,
                    contentDescription = null,
                    tint = TextTertiary,
                    modifier = Modifier.size(20.dp).rotate(chevronRotation),
                )
            },
        )
        AnimatedVisibility(visible = expanded) {
            Column(
                modifier =
                    Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, bottom = 16.dp)
            ) {
                Text(
                    strings.getString(R.string.handover_subtitle),
                    style = MaterialTheme.typography.labelSmall,
                    color = TextTertiary,
                )
                if (selectedDeviceName.isNotBlank()) {
                    Text(
                        strings.getString(R.string.handover_device_scope, selectedDeviceName),
                        style = MaterialTheme.typography.labelSmall,
                        color = TextTertiary,
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))

                // Identity success is implicit. Only surface a pending or missing identity because
                // those states change which action is safe.
                if (pendingNode.isNotBlank()) {
                    HandoverStatusLine(
                        icon = Icons.Default.Info,
                        tint = TextSecondary,
                        text =
                            strings.getString(
                                if (isPreparing) R.string.handover_waiting_candidate
                                else R.string.connection_identity_pending
                            ),
                    )
                } else if (candidateNode.isNotBlank()) {
                    HandoverStatusLine(
                        icon = Icons.Default.Info,
                        tint = TextSecondary,
                        text = strings.getString(R.string.connection_identity_pending),
                    )
                } else if (!hasConfirmedIdentity) {
                    HandoverStatusLine(
                        icon = Icons.Default.Warning,
                        tint = WarningAmber,
                        text = strings.getString(R.string.handover_identity_first),
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Shizuku status: every state gets its own explanation and recovery action.
                val accessText =
                    when (shizuku) {
                        ShizukuAccess.AVAILABLE -> R.string.handover_shizuku_available
                        ShizukuAccess.NOT_INSTALLED -> R.string.handover_shizuku_not_installed
                        ShizukuAccess.NOT_RUNNING -> R.string.handover_shizuku_not_running
                        ShizukuAccess.NEEDS_PERMISSION -> R.string.handover_shizuku_needs_permission
                        ShizukuAccess.DENIED -> R.string.handover_shizuku_denied
                        ShizukuAccess.UNSUPPORTED -> R.string.handover_shizuku_unsupported
                    }
                if (shizuku != ShizukuAccess.AVAILABLE) {
                    Text(
                        strings.getString(accessText),
                        style = MaterialTheme.typography.labelMedium,
                        color = TextSecondary,
                    )
                }
                when (shizuku) {
                    ShizukuAccess.NEEDS_PERMISSION,
                    ShizukuAccess.DENIED -> {
                        OutlinedButton(
                            onClick = { handover.requestAuthorization() },
                            enabled = !working,
                            modifier = Modifier.fillMaxWidth().testTag("tag_handover_grant"),
                        ) {
                            Text(strings.getString(R.string.handover_grant))
                        }
                    }
                    ShizukuAccess.NOT_RUNNING -> {
                        OutlinedButton(
                            onClick = { openShizukuApp(context) },
                            modifier = Modifier.fillMaxWidth().testTag("tag_handover_open_shizuku"),
                        ) {
                            Text(strings.getString(R.string.handover_open_shizuku))
                        }
                    }
                    ShizukuAccess.NOT_INSTALLED -> {
                        OutlinedButton(
                            onClick = { installShizuku(context) },
                            modifier = Modifier.fillMaxWidth().testTag("tag_handover_get_shizuku"),
                        ) {
                            Text(strings.getString(R.string.handover_get_shizuku))
                        }
                    }
                    else -> Unit
                }

                Spacer(modifier = Modifier.height(6.dp))

                TextButton(
                    onClick = { appDetailsExpanded = !appDetailsExpanded },
                    modifier = Modifier.fillMaxWidth().testTag("tag_handover_apps_toggle"),
                ) {
                    Text(
                        strings.getString(
                            if (appDetailsExpanded) R.string.handover_hide_app_states
                            else R.string.handover_show_app_states
                        )
                    )
                }
                AnimatedVisibility(appDetailsExpanded) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (handoverState.apps.isEmpty()) {
                            Text(
                                strings.getString(R.string.handover_apps_empty),
                                style = MaterialTheme.typography.labelSmall,
                                color = TextTertiary,
                            )
                        } else {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                handoverState.apps.forEach { app ->
                                    Column(
                                        modifier =
                                            Modifier.fillMaxWidth()
                                                .clip(RoundedCornerShape(10.dp))
                                                .background(CardSurfaceElevated)
                                                .padding(horizontal = 10.dp, vertical = 8.dp)
                                                .testTag("tag_handover_app_${app.packageName}")
                                    ) {
                                        Text(
                                            localizedAppName(strings, app.packageName)
                                                ?: app.displayName.ifBlank { app.packageName },
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextPrimary,
                                            maxLines = 3,
                                            overflow = TextOverflow.Ellipsis,
                                        )
                                        val installed = app.installed
                                        Text(
                                            strings.getString(
                                                when {
                                                    installed == false ->
                                                        R.string.handover_package_not_installed
                                                    installed == null ->
                                                        R.string.handover_package_unknown
                                                    app.enabled -> R.string.handover_package_enabled
                                                    else -> R.string.handover_package_disabled
                                                }
                                            ),
                                            style = MaterialTheme.typography.labelSmall,
                                            color =
                                                when {
                                                    installed != true -> TextTertiary
                                                    app.enabled -> WarningAmber
                                                    else -> EmeraldCharging
                                                },
                                            fontWeight = FontWeight.SemiBold,
                                        )
                                        SelectionContainer {
                                            Text(
                                                app.packageName,
                                                style = MaterialTheme.typography.labelSmall,
                                                fontFamily = FontFamily.Monospace,
                                                color = TextTertiary,
                                            )
                                        }
                                        if (app.installed != false) {
                                            TextButton(
                                                onClick = {
                                                    // Opening system settings pauses connection to
                                                    // prevent auto-reconnect contention.
                                                    if (!isPreparing) {
                                                        WatchController.prepareHandover(context)
                                                        identityToken++
                                                        onConnectionOwnershipChanged()
                                                    }
                                                    openAppDetails(context, app.packageName)
                                                },
                                                modifier =
                                                    Modifier.align(Alignment.End)
                                                        .testTag(
                                                            "tag_handover_details_${app.packageName}"
                                                        ),
                                            ) {
                                                Text(
                                                    strings.getString(R.string.handover_app_details)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        TextButton(
                            onClick = {
                                if (!working) {
                                    refreshToken++
                                    identityToken++
                                }
                            },
                            enabled = !working,
                            modifier = Modifier.fillMaxWidth().testTag("tag_handover_refresh"),
                        ) {
                            Text(strings.getString(R.string.handover_refresh))
                        }
                    }
                }

                handoverState.message
                    ?.takeIf { it.isNotBlank() }
                    ?.let { message ->
                        Text(
                            message,
                            style = MaterialTheme.typography.labelSmall,
                            color = WarningAmber,
                        )
                    }

                Spacer(modifier = Modifier.height(6.dp))

                if (working) {
                    CircularProgressIndicator(
                        modifier = Modifier.padding(vertical = 4.dp).size(20.dp),
                        strokeWidth = 2.dp,
                    )
                }

                if (isPreparing) {
                    Text(
                        strings.getString(
                            if (pendingNode.isNotBlank()) R.string.handover_waiting_candidate
                            else R.string.handover_waiting_identity
                        ),
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                    )
                    when (primaryAction) {
                        HandoverPrimaryAction.DISABLE_AND_CONNECT -> {
                            Button(
                                onClick = { disableOfficialApps() },
                                enabled = !working,
                                modifier = Modifier.fillMaxWidth().testTag("tag_handover_disable"),
                            ) {
                                Text(strings.getString(R.string.handover_disable_and_connect))
                            }
                        }
                        HandoverPrimaryAction.CONTINUE_VERIFICATION -> {
                            OutlinedButton(
                                onClick = {
                                    if (!working) {
                                        if (!WatchController.continueHandover(context)) {
                                            UiNotify.show(R.string.handover_continue_failed)
                                        }
                                        identityToken++
                                        onConnectionOwnershipChanged()
                                    }
                                },
                                enabled = !working,
                                modifier = Modifier.fillMaxWidth().testTag("tag_handover_continue"),
                            ) {
                                Text(strings.getString(R.string.handover_continue))
                            }
                        }
                        else -> Unit
                    }
                    TextButton(
                        onClick = {
                            if (!working) {
                                WatchController.cancelHandover(context)
                                identityToken++
                                onConnectionOwnershipChanged()
                                UiNotify.show(R.string.connection_stopped)
                            }
                        },
                        enabled = !working,
                        modifier = Modifier.fillMaxWidth().testTag("tag_handover_cancel"),
                    ) {
                        Text(strings.getString(R.string.handover_cancel))
                    }
                } else {
                    when (primaryAction) {
                        HandoverPrimaryAction.DISABLE_AND_CONNECT ->
                            Button(
                                onClick = { disableOfficialApps() },
                                enabled = !working && !connectionBusy,
                                modifier = Modifier.fillMaxWidth().testTag("tag_handover_disable"),
                            ) {
                                Text(strings.getString(R.string.handover_take_connection_back))
                            }
                        HandoverPrimaryAction.PREPARE_IDENTITY ->
                            Button(
                                onClick = { prepareHandover() },
                                enabled = !working && !connectionBusy,
                                modifier = Modifier.fillMaxWidth().testTag("tag_handover_prepare"),
                            ) {
                                Text(strings.getString(R.string.handover_prepare))
                            }
                        HandoverPrimaryAction.MANUAL ->
                            Button(
                                onClick = {
                                    appDetailsExpanded = true
                                    manualExpanded = true
                                },
                                enabled = !working,
                                modifier = Modifier.fillMaxWidth().testTag("tag_handover_manual"),
                            ) {
                                Text(strings.getString(R.string.handover_manual_action))
                            }
                        else -> Unit
                    }
                }

                // Ownership is released before package restoration; failed restores must stay
                // retryable.
                if (canRestoreOfficialApps) {
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = { confirmRestore = true },
                        enabled = !working,
                        modifier = Modifier.fillMaxWidth().testTag("tag_handover_restore"),
                    ) {
                        Text(strings.getString(R.string.handover_restore_and_pause))
                    }
                    Text(
                        strings.getString(
                            if (hasDisabledOfficialApp && !hasRestorePoint)
                                R.string.handover_restore_fallback_hint
                            else R.string.handover_restore_hint
                        ),
                        style = MaterialTheme.typography.labelSmall,
                        color = TextTertiary,
                    )
                    if (hasRestorePoint) {
                        Text(
                            strings.getString(R.string.handover_reversible),
                            style = MaterialTheme.typography.labelSmall,
                            color = TextTertiary,
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                TextButton(
                    onClick = { manualExpanded = !manualExpanded },
                    modifier = Modifier.fillMaxWidth().testTag("tag_handover_manual_toggle"),
                ) {
                    Text(
                        strings.getString(
                            if (manualExpanded) R.string.handover_hide_manual
                            else R.string.handover_show_manual
                        )
                    )
                }
                AnimatedVisibility(manualExpanded) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            strings.getString(R.string.handover_manual_title),
                            style = MaterialTheme.typography.labelMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.SemiBold,
                        )
                        Text(
                            strings.getString(R.string.handover_manual_body),
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary,
                        )
                        Text(
                            strings.getString(R.string.handover_uninstall_warning),
                            style = MaterialTheme.typography.labelSmall,
                            color = WarningAmber,
                        )
                    }
                }
            }
        }
    }
    if (confirmRestore) {
        AlertDialog(
            onDismissRequest = { confirmRestore = false },
            title = { Text(strings.getString(R.string.handover_restore_confirm_title)) },
            text = { Text(strings.getString(R.string.handover_restore_confirm_body)) },
            confirmButton = {
                TextButton(
                    onClick = {
                        confirmRestore = false
                        restoreOfficialApps()
                    },
                    modifier = Modifier.testTag("tag_handover_restore_confirm"),
                ) {
                    Text(strings.getString(R.string.handover_restore_confirm_action))
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmRestore = false }) {
                    Text(strings.getString(R.string.cancel))
                }
            },
        )
    }
}

@Composable
private fun HandoverStatusLine(
    icon: ImageVector,
    tint: Color,
    text: String,
    textColor: Color = TextSecondary,
) {
    Row(verticalAlignment = Alignment.Top) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(15.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(text, style = MaterialTheme.typography.bodySmall, color = textColor)
    }
}

private fun openAppDetails(context: Context, packageName: String) {
    val direct =
        Intent(
            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.fromParts("package", packageName, null),
        )
    val fallback = Intent(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS)
    val opened =
        runCatching { context.startActivity(direct) }.isSuccess ||
            runCatching { context.startActivity(fallback) }.isSuccess
    if (!opened) UiNotify.show(R.string.handover_open_settings_failed)
}

private const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"
private val SHIZUKU_MARKET_URI: Uri = Uri.parse("market://details?id=$SHIZUKU_PACKAGE")

private fun openShizukuApp(context: Context) {
    val launch = context.packageManager.getLaunchIntentForPackage(SHIZUKU_PACKAGE)
    val opened =
        (launch != null && runCatching { context.startActivity(launch) }.isSuccess) ||
            runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, SHIZUKU_MARKET_URI)) }
                .isSuccess
    if (!opened) UiNotify.show(R.string.handover_open_settings_failed)
}

private fun installShizuku(context: Context) {
    val opened =
        runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, SHIZUKU_MARKET_URI)) }
            .isSuccess ||
            runCatching {
                    context.startActivity(
                        Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/"))
                    )
                }
                .isSuccess
    if (!opened) UiNotify.show(R.string.handover_open_settings_failed)
}

private fun localizedAppName(strings: Resources, packageName: String): String? =
    when (OfficialCompanionApp.find(packageName)) {
        OfficialCompanionApp.WEAR_CN -> strings.getString(R.string.handover_app_wear_os_cn)
        OfficialCompanionApp.WEAR -> strings.getString(R.string.handover_app_wear_os)
        OfficialCompanionApp.GALAXY_WEARABLE ->
            strings.getString(R.string.handover_app_galaxy_wearable)
        OfficialCompanionApp.WATCH4_PLUGIN -> strings.getString(R.string.handover_app_watch4_plugin)
        OfficialCompanionApp.WATCH5_PLUGIN -> strings.getString(R.string.handover_app_watch5_plugin)
        OfficialCompanionApp.WATCH6_PLUGIN -> strings.getString(R.string.handover_app_watch6_plugin)
        OfficialCompanionApp.WATCH7_PLUGIN -> strings.getString(R.string.handover_app_watch7_plugin)
        null -> null
    }
