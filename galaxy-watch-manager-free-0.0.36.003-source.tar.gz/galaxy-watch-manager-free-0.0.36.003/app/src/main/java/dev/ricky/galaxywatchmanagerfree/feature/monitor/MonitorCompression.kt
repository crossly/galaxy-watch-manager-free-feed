package dev.ricky.galaxywatchmanagerfree.feature.monitor

import java.io.ByteArrayOutputStream
import java.util.zip.DeflaterOutputStream
import java.util.zip.GZIPInputStream
import java.util.zip.InflaterInputStream

/** Channel/report payloads use zlib; ordinary JSON message envelopes use gzip. Both are bounded. */
object MonitorCompression {
    fun deflate(bytes: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()
        DeflaterOutputStream(out).use { it.write(bytes) }
        return out.toByteArray()
    }

    fun inflate(bytes: ByteArray, limit: Int): ByteArray {
        require(bytes.size <= limit && bytes.size >= 2) {
            "Monitor compressed payload exceeds limit"
        }
        val gzip = bytes[0] == 0x1f.toByte() && bytes[1] == 0x8b.toByte()
        val input =
            if (gzip) GZIPInputStream(bytes.inputStream())
            else InflaterInputStream(bytes.inputStream())
        return input.use {
            val out = ByteArrayOutputStream()
            val buffer = ByteArray(8192)
            while (true) {
                val count = it.read(buffer)
                if (count < 0) break
                require(out.size() + count <= limit) { "Monitor inflated payload exceeds limit" }
                out.write(buffer, 0, count)
            }
            out.toByteArray()
        }
    }
}
