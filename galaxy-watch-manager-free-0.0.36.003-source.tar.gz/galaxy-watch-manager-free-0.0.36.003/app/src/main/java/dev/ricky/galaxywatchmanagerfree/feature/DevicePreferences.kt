package dev.ricky.galaxywatchmanagerfree.feature

import android.content.Context
import android.content.SharedPreferences

/** One-time copy of v0.0.9 caches; the originals remain untouched for recovery. */
object DevicePreferences {
    private const val MIGRATION = "watchfree_device_migration"
    private const val OWNER = "legacy_owner"
    private const val OWNER_CAPTURED = "legacy_owner_captured"
    private const val INITIALIZED = "device_cache_initialized"

    /** Must run at application startup before automatic selection can replace the saved MAC. */
    fun rememberLegacyOwner(context: Context, savedDevice: String?) {
        val state = context.getSharedPreferences(MIGRATION, Context.MODE_PRIVATE)
        if (state.getBoolean(OWNER_CAPTURED, false)) return
        val editor = state.edit().putBoolean(OWNER_CAPTURED, true)
        DeviceScope.address(savedDevice)?.let { address ->
            if (!state.contains(OWNER)) editor.putString(OWNER, address)
        }
        check(editor.commit()) { "Could not retain legacy cache ownership" }
    }

    fun legacyOwner(context: Context): String? =
        context.getSharedPreferences(MIGRATION, Context.MODE_PRIVATE).getString(OWNER, null)

    @Synchronized
    fun open(context: Context, base: String, device: String?): SharedPreferences {
        val scoped =
            context.getSharedPreferences(
                DeviceScope.preferences(base, device),
                Context.MODE_PRIVATE,
            )
        if (scoped.getBoolean(INITIALIZED, false)) return scoped
        val owner =
            context.getSharedPreferences(MIGRATION, Context.MODE_PRIVATE).getString(OWNER, null)
        val editor = scoped.edit()
        if (DeviceScope.canImportLegacy(device, owner) && scoped.all.isEmpty()) {
            val legacy = context.getSharedPreferences(base, Context.MODE_PRIVATE)
            legacy.all.forEach { (key, value) ->
                when (value) {
                    is String -> editor.putString(key, value)
                    is Boolean -> editor.putBoolean(key, value)
                    is Int -> editor.putInt(key, value)
                    is Long -> editor.putLong(key, value)
                    is Float -> editor.putFloat(key, value)
                    is Set<*> -> editor.putStringSet(key, value.filterIsInstance<String>().toSet())
                }
            }
        }
        check(editor.putBoolean(INITIALIZED, true).commit()) { "Could not initialize device cache" }
        return scoped
    }
}
