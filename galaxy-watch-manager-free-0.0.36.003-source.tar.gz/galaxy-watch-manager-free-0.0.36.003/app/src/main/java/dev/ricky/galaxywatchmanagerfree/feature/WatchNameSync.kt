package dev.ricky.galaxywatchmanagerfree.feature

import dev.ricky.galaxywatchmanagerfree.wcs.WcsFrame
import dev.ricky.galaxywatchmanagerfree.wcs.WcsPaths
import kotlinx.coroutines.CoroutineScope

class WatchNameSync(
    scope: CoroutineScope,
    initialAlias: String,
    private val watchNode: () -> String,
    private val requestRead: () -> Boolean,
    private val write: (String, Map<String, Any>) -> Boolean,
    private val onName: (String) -> Unit,
    private val onResult: (Result) -> Unit,
    private val onDebug: (String) -> Unit = {},
) {
    enum class Result {
        PENDING,
        LOCAL_ONLY,
        CONFIRMED,
        SEND_FAILED,
        SOURCE_UNAVAILABLE,
        SUBMITTED,
    }

    private enum class Stage(val label: String) {
        IDLE("idle"),
        READING_TEMPLATE("read_template"),
        CONFIRMING_WRITE("confirm_write"),
    }

    private data class Template(val uri: String, val dataMap: Map<String, Any>)

    private var template: Template? = null
    private var localAlias = initialAlias
    private var connected = false
    private var disconnected = false
    private var stage = Stage.IDLE
    private var sourceUri: String? = null
    private var notifyResult = false
    private val path = WcsPaths.SET_INFO_WATCH_NAME.trimStart('/')
    private val commands =
        SettingCommands(
            scope,
            onDebug = onDebug,
            onError = { failure ->
                if (notifyResult) {
                    onResult(
                        when (failure) {
                            SettingCommands.Failure.SEND_FAILED -> Result.SEND_FAILED
                            SettingCommands.Failure.UNCONFIRMED ->
                                if (stage == Stage.READING_TEMPLATE) Result.SOURCE_UNAVAILABLE
                                else Result.SUBMITTED
                        }
                    )
                }
                onDebug("[手表名称] stage=${stage.label} failure=$failure")
                stage = Stage.IDLE
            },
            onConfirmed = { _, _ -> if (notifyResult) onResult(Result.CONFIRMED) },
        )

    fun rename(name: String) {
        synchronized(commands) {
            val trimmed = name.trim().take(32)
            if (trimmed.isBlank()) return
            localAlias = trimmed
            onName(trimmed)
            if (connected) sync(notify = true) else onResult(Result.LOCAL_ONLY)
        }
    }

    fun connect() {
        synchronized(commands) {
            connected = true
            disconnected = false
            if (localAlias.isNotBlank()) sync(notify = false)
        }
    }

    fun disconnect() {
        synchronized(commands) {
            connected = false
            disconnected = true
            stage = Stage.IDLE
            sourceUri = null
            commands.clear()
            notifyResult = false
        }
    }

    fun receive(uri: String, dataMap: Map<String, Any>) {
        synchronized(commands) {
            if (disconnected) return
            val (owner, itemPath) = WcsFrame.splitWearPath(uri)
            if (owner.isNullOrBlank() || owner != watchNode() || itemPath != "/$path") return
            if ((dataMap["key"] ?: "stringName") != "stringName") return
            val name = dataMap["stringName"] as? String ?: return
            if (name.isBlank()) return
            val received = Template(uri, dataMap.toMap())
            template = received
            val fromPhone = dataMap["from"] == "phone"
            if (!fromPhone && localAlias.isBlank()) onName(name.trim().take(32))
            if (!commands.hasPending(path)) return
            if (stage == Stage.READING_TEMPLATE) {
                writeTemplate(received)
            } else if (!fromPhone && uri == sourceUri) {
                commands.confirm(path, name)
            }
        }
    }

    private fun sync(notify: Boolean) {
        notifyResult = notify
        sourceUri = null
        if (notify) onResult(Result.PENDING)
        val cached = template?.takeIf { WcsFrame.splitWearPath(it.uri).first == watchNode() }
        if (cached != null) {
            onDebug("[手表名称] template=cache")
            writeTemplate(cached)
        } else {
            template = null
            stage = Stage.READING_TEMPLATE
            onDebug("[手表名称] stage=read_template")
            commands.submit(path, localAlias) { requestRead() }
        }
    }

    private fun writeTemplate(source: Template) {
        stage = Stage.CONFIRMING_WRITE
        sourceUri = source.uri
        val updated = source.dataMap + mapOf("stringName" to localAlias, "from" to "phone")
        onDebug("[手表名称] stage=write keys=${updated.keys}")
        commands.submit(path, localAlias, readBack = { requestRead() }) {
            write(source.uri, updated)
        }
    }
}
