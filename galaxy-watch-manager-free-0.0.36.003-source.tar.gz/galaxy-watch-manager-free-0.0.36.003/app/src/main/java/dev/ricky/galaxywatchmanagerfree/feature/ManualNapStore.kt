package dev.ricky.galaxywatchmanagerfree.feature

import android.content.Context
import org.json.JSONArray

/**
 * 本机保存用户显式补记的午休。
 *
 * 手表的睡眠模块没有上报午休时，用户可以在睡眠详情里补记；补记只存在本机，不冒充手表数据，也不参与任何推断。
 */
class ManualNapStore(context: Context, peerAddress: String?) {
    private val prefs =
        context.applicationContext.getSharedPreferences(
            DeviceScope.preferences(PREFS, peerAddress),
            Context.MODE_PRIVATE,
        )

    @Synchronized
    fun load(): List<SleepParser.ManualNap> =
        runCatching {
                val array = JSONArray(prefs.getString(KEY, "[]") ?: "[]")
                (0 until array.length())
                    .mapNotNull { index ->
                        val row = array.optJSONArray(index) ?: return@mapNotNull null
                        val start = row.optLong(0)
                        val end = row.optLong(1)
                        if (end > start) SleepParser.ManualNap(start, end) else null
                    }
                    .distinctBy { it.startMillis to it.endMillis }
                    .sortedBy { it.startMillis }
            }
            .getOrDefault(emptyList())

    @Synchronized
    fun add(nap: SleepParser.ManualNap): Boolean {
        if (nap.endMillis <= nap.startMillis) return false
        val next =
            (load() + nap).distinctBy { it.startMillis to it.endMillis }.sortedBy { it.startMillis }
        return save(next)
    }

    @Synchronized
    fun remove(startMillis: Long, endMillis: Long): Boolean {
        val current = load()
        val next = current.filterNot { it.startMillis == startMillis && it.endMillis == endMillis }
        return if (next.size == current.size) false else save(next)
    }

    @Synchronized
    fun clear(): Boolean {
        prefs.edit().remove(KEY).apply()
        return true
    }

    private fun save(naps: List<SleepParser.ManualNap>): Boolean {
        val array = JSONArray()
        naps.forEach { nap -> array.put(JSONArray().put(nap.startMillis).put(nap.endMillis)) }
        prefs.edit().putString(KEY, array.toString()).apply()
        return true
    }

    private companion object {
        const val PREFS = "watchfree_manual_naps"
        const val KEY = "naps"
    }
}
