package dev.ricky.galaxywatchmanagerfree.wcs

import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.os.Build
import dev.ricky.galaxywatchmanagerfree.feature.LogBus
import java.nio.ByteBuffer
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * BLE GATT wake-lock helper for Samsung Galaxy Watch. Connects to proprietary service, enables CCC
 * notification, and sends popup request TLV to trigger the watch's RFCOMM server listener.
 */
// wake() checks permission before starting; callbacks recheck it after async boundaries.
@android.annotation.SuppressLint("MissingPermission")
object BleWakeLock {

    val SERVICE_UUID: UUID = UUID.fromString("eed6d5cc-c3b2-4d7b-8c6b-7acbf7965bb6")
    val CHAR_UUID: UUID = UUID.fromString("2fb6a5aa-1219-4129-bc97-dd4df70613cd")
    val CCC_DESCRIPTOR_UUID: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")

    private const val POPUP_REQUEST_JSON =
        """{"msgId":"msg_popup_request","sender":"phone","data":{"category":2}}"""

    fun buildWakePayload(): ByteArray {
        val jsonBytes = POPUP_REQUEST_JSON.toByteArray(Charsets.UTF_8)
        val buf = ByteBuffer.allocate(1 + 4 + jsonBytes.size)
        buf.put(12.toByte())
        buf.putInt(jsonBytes.size)
        buf.put(jsonBytes)
        return buf.array()
    }

    fun wake(context: Context, device: BluetoothDevice, timeoutMs: Long = 6000L): Boolean {
        fun permitted() =
            Build.VERSION.SDK_INT < 31 ||
                context.checkSelfPermission(android.Manifest.permission.BLUETOOTH_CONNECT) ==
                    android.content.pm.PackageManager.PERMISSION_GRANTED
        if (!permitted()) return false
        LogBus.log("[BLE] 开始 BLE GATT 唤醒手表 ${device.address}...")
        val latch = CountDownLatch(1)
        var gattInstance: BluetoothGatt? = null
        var writeSuccess = false
        var targetChar: BluetoothGattCharacteristic? = null

        val callback =
            object : BluetoothGattCallback() {
                override fun onConnectionStateChange(
                    gatt: BluetoothGatt,
                    status: Int,
                    newState: Int,
                ) {
                    if (!permitted()) {
                        latch.countDown()
                        return
                    }
                    if (newState == BluetoothProfile.STATE_CONNECTED) {
                        LogBus.debug { "[BLE] GATT 已连接 (status=$status)，发现服务中..." }
                        gatt.discoverServices()
                    } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                        LogBus.debug { "[BLE] GATT 已断开 (status=$status)" }
                        latch.countDown()
                    }
                }

                override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
                    if (!permitted()) {
                        latch.countDown()
                        return
                    }
                    if (status != BluetoothGatt.GATT_SUCCESS) {
                        LogBus.error("[BLE] GATT 服务发现失败: status=$status")
                        latch.countDown()
                        return
                    }

                    val service = gatt.getService(SERVICE_UUID)
                    val characteristic = service?.getCharacteristic(CHAR_UUID)
                    if (characteristic == null) {
                        LogBus.error("[BLE] 未找到三星专属服务/特征: service=${service != null}")
                        latch.countDown()
                        return
                    }
                    targetChar = characteristic

                    LogBus.debug { "[BLE] 找到三星特征，开启 CCC 通知..." }
                    gatt.setCharacteristicNotification(characteristic, true)
                    val ccc = characteristic.getDescriptor(CCC_DESCRIPTOR_UUID)
                    if (ccc != null) {
                        val res =
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                gatt.writeDescriptor(
                                    ccc,
                                    BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE,
                                ) == android.bluetooth.BluetoothStatusCodes.SUCCESS
                            } else {
                                @Suppress("DEPRECATION")
                                ccc.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                                @Suppress("DEPRECATION") gatt.writeDescriptor(ccc)
                            }
                        LogBus.debug { "[BLE] 写入 CCC 描述符调用结果: $res（等待 onDescriptorWrite 回调）" }
                        if (!res) {
                            // 如果写 CCC 失败，直接尝试写特征兜底
                            doWriteCharacteristic(gatt, characteristic)
                        }
                    } else {
                        doWriteCharacteristic(gatt, characteristic)
                    }
                }

                override fun onDescriptorWrite(
                    gatt: BluetoothGatt,
                    descriptor: BluetoothGattDescriptor,
                    status: Int,
                ) {
                    LogBus.debug { "[BLE] CCC 描述符写入完成 (status=$status)，开始写入唤醒 TLV..." }
                    targetChar?.let { doWriteCharacteristic(gatt, it) } ?: latch.countDown()
                }

                private fun doWriteCharacteristic(
                    gatt: BluetoothGatt,
                    characteristic: BluetoothGattCharacteristic,
                ) {
                    if (!permitted()) {
                        latch.countDown()
                        return
                    }
                    val wakePayload = buildWakePayload()
                    LogBus.debug {
                        "[BLE] 向特征写入官方 TLV (12+4B+JSON, 共 ${wakePayload.size}B, WRITE_TYPE_NO_RESPONSE)..."
                    }
                    val writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                    val res =
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            gatt.writeCharacteristic(characteristic, wakePayload, writeType) ==
                                android.bluetooth.BluetoothStatusCodes.SUCCESS
                        } else {
                            @Suppress("DEPRECATION")
                            characteristic.writeType = writeType
                            @Suppress("DEPRECATION")
                            characteristic.value = wakePayload
                            @Suppress("DEPRECATION") gatt.writeCharacteristic(characteristic)
                        }
                    writeSuccess = res
                    LogBus.debug { "[BLE] 写入特征调用结果: $res" }
                    latch.countDown()
                }
            }

        try {
            gattInstance =
                device.connectGatt(context, false, callback, BluetoothDevice.TRANSPORT_LE)

            val ok = latch.await(timeoutMs, TimeUnit.MILLISECONDS)
            LogBus.log("[BLE] 唤醒完成 (ok=$ok, writeSuccess=$writeSuccess)，保持 GATT 1500ms...")
            try {
                Thread.sleep(1500)
            } catch (_: InterruptedException) {}
            return writeSuccess
        } catch (e: Exception) {
            LogBus.error("[BLE] 唤醒异常: ${e.message}", e)
            return false
        } finally {
            try {
                gattInstance?.disconnect()
                gattInstance?.close()
            } catch (_: Exception) {}
        }
    }
}
