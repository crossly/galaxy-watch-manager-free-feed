package dev.ricky.galaxywatchmanagerfree.feature

import java.security.MessageDigest
import java.util.Collections
import java.util.IdentityHashMap
import org.json.JSONArray
import org.json.JSONObject

internal object DiagnosticValue {
    const val MAX_CHARS = 12_000
    private val mac = Regex("(?i)\\b(?:[0-9a-f]{2}:){5}[0-9a-f]{2}\\b")
    private val bearer = Regex("(?i)(\\bBearer\\s+)[A-Za-z0-9._~+/=-]+")
    private val healthKeys =
        listOf(
            "datauuid",
            "deviceuuid",
            "sleepuuid",
            "sleepid",
            "asleep",
            "efficiency",
            "score",
            "segments",
            "stages",
            "heartrate",
            "hr",
            "hrv",
            "rmssd",
            "sdnn",
            "steps",
            "stepcount",
            "calorie",
            "calories",
            "distance",
            "floors",
            "stress",
            "spo2",
            "oxygensaturation",
            "bloodpressure",
            "systolic",
            "diastolic",
            "ecg",
            "measurement",
            "measurements",
            "weight",
            "bodyfat",
            "temperature",
        )
    private val credentialKeys =
        listOf(
            "token",
            "secret",
            "password",
            "authorization",
            "cookie",
            "credential",
            "account",
            "phonenumber",
            "contact",
            "titleraw",
            "textraw",
        )
    private val sensitiveKeys =
        credentialKeys +
            listOf("title", "subtitle", "subtext", "body", "text", "extras") +
            healthKeys
    private val embeddedAssignment = Regex("""(["']?)([A-Za-z0-9_.-]+)\1\s*[:=]\s*""")

    fun text(value: String): String {
        val bounded = value.take(MAX_CHARS)
        val masked = mac.replace(bounded) { "**:**:**:**:" + it.value.takeLast(5) }
        val tokensMasked = bearer.replace(masked) { it.groupValues[1] + "[redacted]" }
        val redacted = buildString {
            var offset = 0
            while (offset < tokensMasked.length) {
                val match = embeddedAssignment.find(tokensMasked, offset) ?: break
                val valueStart = match.range.last + 1
                append(tokensMasked, offset, valueStart)
                offset = valueStart
                if (isSensitiveKey(match.groupValues[2])) {
                    append("[redacted]")
                    offset = valueEnd(tokensMasked, valueStart)
                }
            }
            append(tokensMasked, offset, tokensMasked.length)
        }
        return redacted +
            if (value.length > MAX_CHARS) "… [truncated, chars=${value.length}]" else ""
    }

    private fun valueEnd(value: String, start: Int): Int {
        var quote: Char? = null
        var escaped = false
        var depth = 0
        for (index in start until value.length) {
            val char = value[index]
            if (quote != null) {
                when {
                    escaped -> escaped = false
                    char == '\\' -> escaped = true
                    char == quote -> {
                        quote = null
                        if (depth == 0) return index + 1
                    }
                }
            } else {
                when (char) {
                    '"',
                    '\'' -> quote = char
                    '{',
                    '[' -> depth++
                    '}',
                    ']' -> {
                        if (depth == 0) return index
                        depth--
                        if (depth == 0) return index + 1
                    }
                    ',',
                    ';' -> if (depth == 0) return index
                    else -> if (depth == 0 && char.isWhitespace()) return index
                }
            }
        }
        return value.length
    }

    fun error(message: String, error: Throwable?): String = buildString {
        append(text(message))
        error?.let { append(": ").append(it.javaClass.simpleName) }
    }

    // Parser input can appear in messages throughout the cause and suppressed exception chains.
    fun stackTrace(error: Throwable): String {
        val rendered = buildString {
            val seen = Collections.newSetFromMap(IdentityHashMap<Throwable, Boolean>())
            fun render(throwable: Throwable, prefix: String, depth: Int) {
                if (length >= MAX_CHARS) return
                append(prefix).append(throwable.javaClass.name)
                if (depth > 8) {
                    append(" [depth limit]\n")
                    return
                }
                if (!seen.add(throwable)) {
                    append(" [cyclic]\n")
                    return
                }
                append('\n')
                throwable.stackTrace.take(80).forEach {
                    if (length < MAX_CHARS) append("\tat ").append(it).append('\n')
                }
                throwable.suppressed.take(4).forEach { render(it, "Suppressed: ", depth + 1) }
                throwable.cause?.let { render(it, "Caused by: ", depth + 1) }
            }
            render(error, "", 0)
        }
        return if (rendered.length <= MAX_CHARS) rendered
        else rendered.take(MAX_CHARS) + "… [truncated]"
    }

    fun describe(value: Any?): String = text(buildString { appendValue(value, 0) })

    private fun StringBuilder.appendValue(value: Any?, depth: Int) {
        if (length >= MAX_CHARS) return
        if (depth > 4) {
            append("…")
            return
        }
        when (value) {
            null,
            JSONObject.NULL -> append("null")
            is ByteArray -> {
                val digest = MessageDigest.getInstance("SHA-256").digest(value)
                append("bytes(size=${value.size}, sha256=")
                append(digest.joinToString("") { "%02x".format(it) })
                append(")")
            }
            is JSONObject ->
                appendEntries(value.keys().asSequence().map { it to value.opt(it) }, depth)
            is Map<*, *> ->
                appendEntries(
                    value.entries.asSequence().map { it.key.toString() to it.value },
                    depth,
                )
            is JSONArray ->
                appendItems(
                    (0 until value.length()).asSequence().map { value.opt(it) },
                    value.length(),
                    depth,
                )
            is Collection<*> -> appendItems(value.asSequence(), value.size, depth)
            is String ->
                append(text(value.take(1024)))
                    .append(if (value.length > 1024) "…(${value.length} chars)" else "")
            else -> append(text(value.toString()))
        }
    }

    private fun StringBuilder.appendEntries(entries: Sequence<Pair<String, Any?>>, depth: Int) {
        append("{")
        entries.take(25).forEachIndexed { index, (key, value) ->
            if (length >= MAX_CHARS) return@forEachIndexed
            if (index > 0) append(", ")
            if (index == 24) append("…")
            else {
                append(text(key.take(120))).append("=")
                if (isSensitiveKey(key)) append("[redacted]") else appendValue(value, depth + 1)
            }
        }
        append("}")
    }

    private fun StringBuilder.appendItems(items: Sequence<Any?>, count: Int, depth: Int) {
        append("[")
        items.take(8).forEachIndexed { index, item ->
            if (length >= MAX_CHARS) return@forEachIndexed
            if (index > 0) append(", ")
            appendValue(item, depth + 1)
        }
        if (count > 8) append(", … count=$count")
        append("]")
    }

    private fun isSensitiveKey(raw: String): Boolean {
        val compact = raw.lowercase().replace("_", "").replace("-", "")
        if (credentialKeys.any { compact.contains(it) }) return true
        val words =
            raw.replace(Regex("([a-z0-9])([A-Z])"), "$1_$2")
                .lowercase()
                .split('_', '-', '.')
                .filter { it.isNotEmpty() }
        val candidates = buildSet {
            add(compact)
            for (start in words.indices) {
                var joined = ""
                for (end in start until minOf(words.size, start + 3)) {
                    joined += words[end]
                    add(joined)
                }
            }
        }
        return sensitiveKeys.any { it in candidates }
    }
}
