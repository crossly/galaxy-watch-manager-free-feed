package dev.ricky.galaxywatchmanagerfree.feature

/** App-wide query preferences; transport keepalives and sensor sampling are independent. */
data class AutoQueryPolicy(
    val enabled: Boolean = true,
    val intervalSeconds: Int = DEFAULT_INTERVAL_SECONDS,
) {
    companion object {
        const val DEFAULT_INTERVAL_SECONDS = 900
        val INTERVALS_SECONDS = listOf(30, 60, 120, 300, 600, 900)

        fun fromPreferences(enabled: Boolean, intervalSeconds: Int): AutoQueryPolicy =
            AutoQueryPolicy(
                enabled,
                intervalSeconds.takeIf { it in INTERVALS_SECONDS } ?: DEFAULT_INTERVAL_SECONDS,
            )
    }
}
