package dev.ricky.galaxywatchmanagerfree.feature

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import kotlin.math.roundToInt
import org.json.JSONArray
import org.json.JSONObject

/**
 * 心率历史与统计（纯逻辑）。
 *
 * 数据来自 `com.samsung.shealth.tracker.heart_rate`：每条记录是一次测量（或若干分钟的平均）， 带 `start_time` 与
 * `heart_rate`，少数固件另带 `min` / `max`。带 `binning_data` / `binning`
 * 的记录会展开为逐分钟真实读数，此时不再保留外层聚合记录，避免同一份数据既算母项又算子项。 测量时间只取 `start_time`，不回退到 `create_time` /
 * `update_time`；后两者不是测量或接收时间。
 */
object HeartRateLog {

    const val MODULE = "com.samsung.shealth.tracker.heart_rate"
    const val MIN_BPM = 30
    const val MAX_BPM = 240

    /** 单次采样；[minBpm]/[maxBpm] 保存该次测量（或分箱）的真实范围。 */
    data class Point(val ts: Long, val bpm: Int, val minBpm: Int = bpm, val maxBpm: Int = bpm)

    data class Stats(val min: Int, val max: Int, val avg: Int, val count: Int)

    private fun tsOf(record: JSONObject): Long =
        listOf("start_time", "com.samsung.health.heart_rate.start_time").firstNotNullOfOrNull { key
            ->
            record.optLong(key, 0L).takeIf { it > 0L }
        } ?: 0L

    private fun intOf(record: JSONObject, vararg keys: String): Int? =
        keys.firstNotNullOfOrNull { key ->
            if (!record.has(key) || record.isNull(key)) null
            else record.optDouble(key, Double.NaN).takeIf { it.isFinite() }?.roundToInt()
        }

    private fun bpmOf(record: JSONObject): Int =
        intOf(record, "heart_rate", "com.samsung.health.heart_rate.heart_rate", "bpm")?.takeIf {
            it in MIN_BPM..MAX_BPM
        }
            ?: intOf(record, "heart_rate_min", "min")?.takeIf { it in MIN_BPM..MAX_BPM }
            ?: intOf(record, "heart_rate_max", "max")?.takeIf { it in MIN_BPM..MAX_BPM }
            ?: Int.MIN_VALUE

    private fun pointOf(ts: Long, bpm: Int, min: Int?, max: Int?): Point? {
        if (ts <= 0L || bpm !in MIN_BPM..MAX_BPM) return null
        val low = (min ?: bpm).takeIf { it in MIN_BPM..bpm } ?: bpm
        val high = (max ?: bpm).takeIf { it in bpm..MAX_BPM } ?: bpm
        return Point(ts, bpm, low, high)
    }

    /** 报表记录 → 采样点；有分箱时展开分箱并丢弃外层聚合，缺少测量时间或心率不合法的记录直接丢弃 */
    fun pointsFromRecords(records: List<JSONObject>): List<Point> =
        records.flatMap { record ->
            val bins =
                HealthJson.array(record.opt("binning_data"))
                    ?: HealthJson.array(record.opt("binning"))
            val detailed =
                bins
                    ?.let { array ->
                        (0 until array.length()).mapNotNull { index ->
                            val bin = array.optJSONObject(index) ?: return@mapNotNull null
                            pointOf(
                                tsOf(bin),
                                bpmOf(bin),
                                intOf(
                                    bin,
                                    "heart_rate_min",
                                    "com.samsung.health.heart_rate.heart_rate_min",
                                    "min",
                                ),
                                intOf(
                                    bin,
                                    "heart_rate_max",
                                    "com.samsung.health.heart_rate.heart_rate_max",
                                    "max",
                                ),
                            )
                        }
                    }
                    .orEmpty()
            if (detailed.isNotEmpty()) detailed
            else
                listOfNotNull(
                    pointOf(
                        tsOf(record),
                        bpmOf(record),
                        intOf(record, "min", "heart_rate_min", "com.samsung.health.heart_rate.min"),
                        intOf(record, "max", "heart_rate_max", "com.samsung.health.heart_rate.max"),
                    )
                )
        }

    /** 去重、按时间排序并按留存窗口裁剪；同时间戳保留后到的一条。 */
    fun normalized(
        points: List<Point>,
        nowMillis: Long,
        keepMillis: Long = 30 * 24 * 3_600_000L,
        cap: Int = 20_000,
    ): List<Point> {
        val cutoff = nowMillis - keepMillis
        return points
            .filter { it.ts in cutoff..nowMillis && it.bpm in MIN_BPM..MAX_BPM }
            .associateBy { it.ts }
            .values
            .sortedBy { it.ts }
            .takeLast(cap)
    }

    /** 合并去重并裁剪：只保留最近 [keepMillis] 且最多 [cap] 个点 */
    fun merge(
        existing: List<Point>,
        incoming: List<Point>,
        nowMillis: Long,
        keepMillis: Long = 24 * 3_600_000L,
        cap: Int = 600,
    ): List<Point> = normalized(existing + incoming, nowMillis, keepMillis, cap)

    fun stats(points: List<Point>): Stats? {
        val valid = points.filter { it.bpm in MIN_BPM..MAX_BPM }
        if (valid.isEmpty()) return null
        val sum = valid.sumOf { it.bpm }
        return Stats(
            min = valid.minOf { it.minBpm.coerceIn(MIN_BPM, it.bpm) },
            max = valid.maxOf { it.maxBpm.coerceIn(it.bpm, MAX_BPM) },
            avg = (sum.toDouble() / valid.size).toInt(),
            count = valid.size,
        )
    }

    /** 同一份日期统计增量合并：min/max 取极值，均值按样本数加权 */
    fun mergeStats(existing: Stats?, incoming: Stats?): Stats? {
        if (existing == null) return incoming
        if (incoming == null) return existing
        val count = existing.count + incoming.count
        if (count <= 0) return existing
        val weighted =
            (existing.avg.toLong() * existing.count + incoming.avg.toLong() * incoming.count) /
                count
        return Stats(
            min = minOf(existing.min, incoming.min),
            max = maxOf(existing.max, incoming.max),
            avg = weighted.toInt().coerceIn(MIN_BPM, MAX_BPM),
            count = count,
        )
    }

    fun dayOf(ts: Long, zone: ZoneId = ZoneId.systemDefault()): String =
        runCatching { Instant.ofEpochMilli(ts).atZone(zone).toLocalDate().toString() }
            .getOrDefault("")

    /** 按本地日期归组，每天升序排列；用于详情页按天切换和逐日统计。 */
    fun byDay(
        points: List<Point>,
        zone: ZoneId = ZoneId.systemDefault(),
    ): Map<String, List<Point>> =
        points
            .groupBy { dayOf(it.ts, zone) }
            .mapValues { (_, dayPoints) -> dayPoints.sortedBy { it.ts } }

    fun pointsOnDay(
        points: List<Point>,
        day: LocalDate,
        zone: ZoneId = ZoneId.systemDefault(),
    ): List<Point> = points.filter { dayOf(it.ts, zone) == day.toString() }.sortedBy { it.ts }

    /** 某天的小时均值（24 槽，无数据为 null） */
    fun hourlyAvg(points: List<Point>, zone: ZoneId = ZoneId.systemDefault()): List<Int?> {
        val buckets = Array(24) { mutableListOf<Int>() }
        points.forEach { point ->
            val hour =
                runCatching { Instant.ofEpochMilli(point.ts).atZone(zone).hour }.getOrNull()
                    ?: return@forEach
            buckets[hour].add(point.bpm)
        }
        return buckets.map { list -> if (list.isEmpty()) null else list.sum() / list.size }
    }

    // Serialization

    fun encodePoints(points: List<Point>): String {
        val array = JSONArray()
        points.forEach {
            val item = JSONArray().put(it.ts).put(it.bpm)
            if (it.minBpm != it.bpm || it.maxBpm != it.bpm) {
                item.put(it.minBpm).put(it.maxBpm)
            }
            array.put(item)
        }
        return array.toString()
    }

    fun decodePoints(raw: String?): List<Point> {
        if (raw.isNullOrBlank()) return emptyList()
        val array = runCatching { JSONArray(raw) }.getOrNull() ?: return emptyList()
        return (0 until array.length()).mapNotNull { index ->
            val item = array.optJSONArray(index) ?: return@mapNotNull null
            val ts = item.optLong(0)
            val bpm = item.optInt(1)
            if (ts <= 0L || bpm !in MIN_BPM..MAX_BPM) return@mapNotNull null
            val min = item.optInt(2, bpm).takeIf { it in MIN_BPM..bpm } ?: bpm
            val max = item.optInt(3, bpm).takeIf { it in bpm..MAX_BPM } ?: bpm
            Point(ts, bpm, min, max)
        }
    }

    fun encodeDays(days: Map<String, Stats>): String {
        val root = JSONObject()
        days.toSortedMap().forEach { (day, stats) ->
            root.put(day, JSONArray().put(stats.min).put(stats.avg).put(stats.max).put(stats.count))
        }
        return root.toString()
    }

    fun decodeDays(raw: String?): MutableMap<String, Stats> {
        val result = mutableMapOf<String, Stats>()
        if (raw.isNullOrBlank()) return result
        val root = runCatching { JSONObject(raw) }.getOrNull() ?: return result
        root.keys().forEach { day ->
            val array = root.optJSONArray(day) ?: return@forEach
            val min = array.optInt(0)
            val avg = array.optInt(1)
            val max = array.optInt(2)
            if (min in MIN_BPM..MAX_BPM && max in MIN_BPM..MAX_BPM) {
                result[day] =
                    Stats(
                        min = min,
                        avg = avg.coerceIn(MIN_BPM, MAX_BPM),
                        max = max,
                        count = array.optInt(3),
                    )
            }
        }
        return result
    }

    /** 最近 7 天（含今天），缺数据的位置为 null */
    fun lastWeek(days: Map<String, Stats>, today: LocalDate): List<Stats?> =
        (6 downTo 0).map { offset -> days[today.minusDays(offset.toLong()).toString()] }

    /** 纵轴范围：至少留 20 bpm 的跨度，避免几分钟内的小波动被拉成剧烈锯齿 */
    fun axisRange(points: List<Point>): IntRange {
        val stats = stats(points) ?: return 60..100
        val low = (stats.min - 4).coerceAtLeast(MIN_BPM)
        val high = (stats.max + 4).coerceAtMost(MAX_BPM)
        if (high - low >= 20) return low..high
        val bottom = (low - (20 - (high - low)) / 2).coerceIn(MIN_BPM, MAX_BPM - 20)
        return bottom..maxOf(bottom + 20, high).coerceAtMost(MAX_BPM)
    }
}
