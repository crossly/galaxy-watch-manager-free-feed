package dev.ricky.galaxywatchmanagerfree.feature.handover

/** Availability of the optional Shizuku privileged helper. */
enum class ShizukuAccess {
    NOT_INSTALLED,
    NOT_RUNNING,
    NEEDS_PERMISSION,
    DENIED,
    AVAILABLE,
    UNSUPPORTED,
}

/**
 * One known companion app. [installed] is null until a query succeeded; [enabledState] is the
 * PackageManager state (or -1 when unknown). UI text is owned by the UI layer; [displayName] is
 * only a fallback label supplied by the backend.
 */
data class OfficialAppStatus(
    val packageName: String,
    val displayName: String,
    val enabled: Boolean,
    val installed: Boolean? = null,
    val enabledState: Int = EnabledState.UNKNOWN,
)

data class OfficialHandoverState(
    val access: ShizukuAccess = ShizukuAccess.NOT_INSTALLED,
    val apps: List<OfficialAppStatus> = emptyList(),
    val busy: Boolean = false,
    val message: String? = null,
    val hasRestorePoint: Boolean = false,
)
