package dev.ricky.galaxywatchmanagerfree.ui.components

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Watch
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.feature.WatchFacePreset
import dev.ricky.galaxywatchmanagerfree.feature.WatchFacePresets
import dev.ricky.galaxywatchmanagerfree.feature.WatchFacePreviewResolver
import dev.ricky.galaxywatchmanagerfree.feature.WatchState
import dev.ricky.galaxywatchmanagerfree.ui.theme.CardBorder
import dev.ricky.galaxywatchmanagerfree.ui.theme.CardBorderGlow
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextPrimary
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextSecondary
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextTertiary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * 仪表盘（Dashboard）上的精简入口卡片。
 *
 * 只显示：当前表盘圆形预览 + 表盘名称 + 状态角标 + 切换表盘入口按钮（点击跳转二级页面）， 避免在主页展开 43 款表盘网格占用过多高度。
 */
@Composable
fun WatchFaceSummaryCard(state: WatchState, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources

    val currentPreset = WatchFacePresets.find(state.activeWatchfacePkg, state.activeWatchfaceCls)
    val currentName =
        currentPreset?.let { strings.getString(it.nameRes) }
            ?: state.activeWatchfacePkg?.substringAfterLast('.')
            ?: strings.getString(R.string.unknown_watch_face)

    GroupedCard(
        modifier = modifier.pressFeedback(onClick = onClick),
        cornerRadius = 34.dp,
        innerPadding = 20.dp,
    ) {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            WatchFacePreview(
                preset = currentPreset,
                size = 64.dp,
                previewPath = state.activeWatchfacePreviewPath,
            )

            Spacer(modifier = Modifier.width(14.dp))

            // 表盘名称与状态
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    strings.getString(R.string.watch_faces),
                    style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = currentName,
                    style = androidx.compose.material3.MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text =
                        when {
                            state.watchfaceRefreshing && state.activeWatchfacePkg != null ->
                                strings.getString(R.string.saved_watch_face_refreshing)
                            state.watchfaceRefreshing ->
                                strings.getString(R.string.reading_current_watch_face)
                            else ->
                                strings.getQuantityString(
                                    R.plurals.watch_face_count,
                                    WatchFacePresets.ALL.size,
                                    WatchFacePresets.ALL.size,
                                )
                        },
                    style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                )
            }

            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = strings.getString(R.string.manage_watch_faces),
                tint = TextTertiary,
                modifier = Modifier.size(20.dp),
            )
        }
    }
}

/** Resolves an optional local preview drawable; null means the original illustration is used. */
@Composable
fun rememberWatchFacePreviewRes(preset: WatchFacePreset?): Int? {
    val context = LocalContext.current
    val resources = context.resources
    return remember(preset?.id, resources, context.packageName) {
        preset?.let {
            val selection =
                WatchFacePreviewResolver.select(it.id) { name ->
                    resources.getIdentifier(name, "drawable", context.packageName) != 0
                }
            selection.drawableName?.let { name ->
                resources.getIdentifier(name, "drawable", context.packageName).takeIf { id ->
                    id != 0
                }
            }
        }
    }
}

/** Renders a preset with its optional local preview, or the original generic illustration. */
@Composable
fun WatchFacePresetImage(
    preset: WatchFacePreset,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Crop,
) {
    val context = LocalContext.current
    val localPreview = rememberWatchFacePreviewRes(preset)
    val description =
        if (localPreview != null) {
            context.getString(preset.nameRes)
        } else {
            context.getString(
                R.string.watch_face_illustration_content_description,
                context.getString(preset.nameRes),
            )
        }
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Image(
            painter = painterResource(id = localPreview ?: R.drawable.watch_face_illustration),
            contentDescription = description,
            contentScale = contentScale,
            modifier = Modifier.fillMaxSize(),
        )
        if (localPreview == null) {
            Text(
                context.getString(R.string.watch_face_illustration_badge),
                style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                color = Color.White,
                maxLines = 1,
                modifier =
                    Modifier.align(Alignment.BottomCenter)
                        .padding(bottom = 8.dp)
                        .background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(50))
                        .padding(horizontal = 6.dp, vertical = 1.dp),
            )
        }
    }
}

/** 圆形预览图公共渲染（复用于入口卡片、二级页网格、弹窗） */
@Composable
fun WatchFacePreview(
    preset: WatchFacePreset?,
    size: Dp,
    highlighted: Boolean = false,
    modifier: Modifier = Modifier,
    previewPath: String? = null,
) {
    val preview by
        key(previewPath) {
            produceState<ImageBitmap?>(initialValue = null) {
                value =
                    previewPath?.let { path ->
                        withContext(Dispatchers.IO) {
                            BitmapFactory.decodeFile(path)?.asImageBitmap()
                        }
                    }
            }
        }
    Box(
        modifier =
            modifier
                .size(size)
                .clip(CircleShape)
                .background(Color.Black)
                .border(
                    width = if (highlighted) 1.5.dp else 1.dp,
                    color = if (highlighted) CardBorderGlow else CardBorder,
                    shape = CircleShape,
                ),
        contentAlignment = Alignment.Center,
    ) {
        val image = preview
        if (image != null) {
            Image(
                bitmap = image,
                contentDescription =
                    androidx.compose.ui.res.stringResource(R.string.current_watch_face),
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        } else if (preset != null) {
            WatchFacePresetImage(
                preset = preset,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        } else {
            Icon(
                Icons.Default.Watch,
                contentDescription = null,
                tint = TextSecondary,
                modifier = Modifier.size(size * 0.45f),
            )
        }
    }
}
