package dev.ricky.galaxywatchmanagerfree.ui.screens

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.selection.toggleable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.feature.LogBus
import dev.ricky.galaxywatchmanagerfree.feature.NotificationApp
import dev.ricky.galaxywatchmanagerfree.feature.NotificationAppCatalog
import dev.ricky.galaxywatchmanagerfree.feature.NotificationFilterMode
import dev.ricky.galaxywatchmanagerfree.feature.NotificationFilterPreferences
import dev.ricky.galaxywatchmanagerfree.ui.components.*
import dev.ricky.galaxywatchmanagerfree.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun NotificationAppFilterScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val config by NotificationFilterPreferences.config.collectAsStateWithLifecycle()
    val observed by NotificationFilterPreferences.observedPackages.collectAsStateWithLifecycle()
    var query by rememberSaveable { mutableStateOf("") }
    var apps by remember { mutableStateOf<List<NotificationApp>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var failed by remember { mutableStateOf(false) }
    var refresh by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) refresh++
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }
    LaunchedEffect(refresh, observed) {
        loading = true
        failed = false
        try {
            apps =
                withContext(Dispatchers.IO) {
                    NotificationAppCatalog.load(
                        context,
                        observed + NotificationFilterPreferences.config.value.packages,
                    )
                }
        } catch (e: SecurityException) {
            LogBus.error("无法读取通知应用列表", e)
            failed = true
        } finally {
            loading = false
        }
    }
    val visible =
        remember(apps, query) {
            val term = query.trim()
            apps.filter {
                it.label.contains(term, ignoreCase = true) ||
                    it.packageName.contains(term, ignoreCase = true)
            }
        }
    val selectedOnly = config.mode == NotificationFilterMode.SELECTED
    LazyColumn(
        modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item {
            GroupedCard {
                SettingSwitchRow(
                    title = stringResource(R.string.notification_filter_selected_only),
                    subtitle = stringResource(R.string.notification_filter_mode_hint),
                    checked = selectedOnly,
                    onCheckedChange = {
                        NotificationFilterPreferences.setMode(
                            if (it) NotificationFilterMode.SELECTED else NotificationFilterMode.ALL
                        )
                    },
                )
            }
        }
        item {
            Text(
                when {
                    selectedOnly && config.packages.isEmpty() ->
                        stringResource(R.string.notification_filter_none)
                    selectedOnly ->
                        stringResource(
                            R.string.notification_filter_selected_count,
                            config.packages.size,
                        )
                    else -> stringResource(R.string.notification_filter_all_hint)
                },
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                modifier = Modifier.padding(vertical = 8.dp),
            )
        }
        if (selectedOnly) {
            item {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text(stringResource(R.string.notification_filter_search)) },
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    singleLine = true,
                )
            }
            item {
                Text(
                    stringResource(R.string.notification_filter_catalog_hint),
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    modifier = Modifier.padding(vertical = 8.dp),
                )
            }
            if (loading) {
                item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
            } else if (failed) {
                item {
                    TextButton(onClick = { refresh++ }) {
                        Text(stringResource(R.string.notification_filter_load_retry))
                    }
                }
            } else if (visible.isEmpty()) {
                item {
                    Text(
                        stringResource(R.string.notification_filter_no_apps),
                        color = TextSecondary,
                    )
                }
            } else {
                items(visible, key = { it.packageName }) { app ->
                    val selected = app.packageName in config.packages
                    GroupedCard(innerPadding = 0.dp, cornerRadius = 16.dp) {
                        GroupedCardRow(
                            title = app.label,
                            subtitle = app.packageName,
                            modifier =
                                Modifier.toggleable(
                                    value = selected,
                                    role = Role.Checkbox,
                                    onValueChange = {
                                        NotificationFilterPreferences.setSelected(
                                            app.packageName,
                                            it,
                                        )
                                    },
                                ),
                            leading = { NotificationAppIcon(app.packageName) },
                            trailing = { Checkbox(checked = selected, onCheckedChange = null) },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun NotificationAppIcon(packageName: String) {
    val context = LocalContext.current
    var bitmap by remember(context, packageName) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(context, packageName) {
        bitmap = withContext(Dispatchers.IO) { NotificationAppCatalog.icon(context, packageName) }
    }
    val image = bitmap
    if (image == null) {
        Icon(Icons.Default.Apps, null, Modifier.size(32.dp), tint = TextSecondary)
    } else {
        Image(image.asImageBitmap(), null, Modifier.size(32.dp))
    }
}
