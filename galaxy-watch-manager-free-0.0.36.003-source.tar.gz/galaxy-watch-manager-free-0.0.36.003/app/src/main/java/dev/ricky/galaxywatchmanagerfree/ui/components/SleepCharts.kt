package dev.ricky.galaxywatchmanagerfree.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.feature.SleepParser
import dev.ricky.galaxywatchmanagerfree.ui.theme.CardBorder
import dev.ricky.galaxywatchmanagerfree.ui.theme.HealthSleep
import dev.ricky.galaxywatchmanagerfree.ui.theme.SleepAwake
import dev.ricky.galaxywatchmanagerfree.ui.theme.SleepDeep
import dev.ricky.galaxywatchmanagerfree.ui.theme.SleepLight
import dev.ricky.galaxywatchmanagerfree.ui.theme.SleepRem
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextSecondary
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextTertiary

/** 睡眠分期配色来自当前主题的睡眠色族，保证结构条、时间线和 7 日趋势一致。 */
@Composable
fun stageColor(stage: SleepParser.Stage): Color =
    when (stage) {
        SleepParser.Stage.DEEP -> SleepDeep
        SleepParser.Stage.LIGHT -> SleepLight
        SleepParser.Stage.REM -> SleepRem
        SleepParser.Stage.AWAKE -> SleepAwake
    }

/** 睡眠结构条：按各分期时长占比铺满一行，直观看出深睡/REM 的比例。 */
@Composable
fun SleepStageBar(session: SleepParser.Session, modifier: Modifier = Modifier) =
    SleepStageBar(listOf(session), modifier)

/** 将夜间与全部小睡的真实分期合并为一条结构条。 */
@Composable
fun SleepStageBar(sessions: List<SleepParser.Session>, modifier: Modifier = Modifier) {
    val stages = SleepParser.Stage.entries
    val minutes = SleepParser.combinedStageMinutes(sessions)
    val total = stages.sumOf { minutes[it] ?: 0 }
    val colors = stages.associateWith { stageColor(it) }
    val track = CardBorder

    Row(
        modifier =
            modifier
                .fillMaxWidth()
                .height(10.dp)
                .clip(RoundedCornerShape(5.dp))
                .background(track.copy(alpha = 0.4f)),
        horizontalArrangement = Arrangement.spacedBy(1.dp),
    ) {
        if (total <= 0) return@Row
        stages.forEach { stage ->
            val value = minutes[stage] ?: 0
            if (value > 0) {
                Box(
                    modifier =
                        Modifier.weight(value.toFloat())
                            .height(10.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(colors.getValue(stage))
                )
            }
        }
    }
}

/** 睡眠分期时序图（hypnogram）：四行对应清醒 / REM / 浅睡 / 深睡， 横向按真实时间轴铺开，能看出夜里醒了多少次、深睡集中在哪一段。 */
@Composable
fun SleepHypnogram(session: SleepParser.Session, modifier: Modifier = Modifier) =
    SleepHypnogram(listOf(session), modifier)

/** 将同一睡眠日的夜间睡眠与全部小睡叠加在同一个真实时钟轴上。 每段会话保留自己的窗口，窗口之间不补造分期；空白就是两段睡眠之间的清醒间隔。 */
@Composable
fun SleepHypnogram(sessions: List<SleepParser.Session>, modifier: Modifier = Modifier) {
    val validSessions = sessions.filter { it.endMillis > it.startMillis }
    val segments = validSessions.flatMap { it.segments }.filter { it.durationMillis > 0 }
    if (segments.isEmpty()) return
    val stages = SleepParser.Stage.entries
    val colors = stages.associateWith { stageColor(it) }
    val rowColor = CardBorder.copy(alpha = 0.35f)
    val sessionTint = SleepDeep.copy(alpha = 0.045f)
    val boundaryColor = CardBorder.copy(alpha = 0.85f)
    val t0 = validSessions.minOf { it.startMillis }
    val t1 = validSessions.maxOf { it.endMillis }
    val span = (t1 - t0).coerceAtLeast(1L)
    val strings = androidx.compose.ui.platform.LocalContext.current.resources
    val description = strings.getString(R.string.sleep_hypnogram_description, validSessions.size)

    Column(modifier = modifier.fillMaxWidth()) {
        Canvas(
            modifier =
                Modifier.fillMaxWidth().height(72.dp).testTag("sleep_hypnogram").semantics {
                    contentDescription = description
                }
        ) {
            val rows = stages.size
            val gap = 5.dp.toPx()
            val rowHeight = (size.height - gap * (rows - 1)) / rows
            stages.forEachIndexed { index, stage ->
                val top = index * (rowHeight + gap)
                drawRoundRect(
                    color = rowColor,
                    topLeft = Offset(0f, top),
                    size = Size(size.width, rowHeight),
                    cornerRadius = CornerRadius(2.dp.toPx()),
                )
            }
            validSessions.forEach { session ->
                val left =
                    ((session.startMillis - t0).toFloat() / span * size.width).coerceIn(
                        0f,
                        size.width,
                    )
                val right =
                    ((session.endMillis - t0).toFloat() / span * size.width).coerceIn(
                        left,
                        size.width,
                    )
                drawRoundRect(
                    color = sessionTint,
                    topLeft = Offset(left, 0f),
                    size = Size((right - left).coerceAtLeast(1f), size.height),
                    cornerRadius = CornerRadius(3.dp.toPx()),
                )
            }
            if (validSessions.size > 1) {
                validSessions.forEach { session ->
                    val x =
                        ((session.startMillis - t0).toFloat() / span * size.width).coerceIn(
                            0f,
                            size.width,
                        )
                    drawLine(
                        color = boundaryColor,
                        start = Offset(x, 0f),
                        end = Offset(x, size.height),
                        strokeWidth = 1.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 4f)),
                    )
                }
            }
            segments.forEach { segment ->
                val rowIndex = stages.indexOf(segment.stage)
                if (rowIndex < 0) return@forEach
                val left =
                    ((segment.startMillis - t0).toFloat() / span * size.width).coerceIn(
                        0f,
                        size.width,
                    )
                val right =
                    ((segment.endMillis - t0).toFloat() / span * size.width).coerceIn(
                        left,
                        size.width,
                    )
                val top = rowIndex * (rowHeight + gap)
                drawRoundRect(
                    color = colors.getValue(segment.stage),
                    topLeft = Offset(left, top),
                    size = Size((right - left).coerceAtLeast(1f), rowHeight),
                    cornerRadius = CornerRadius(2.dp.toPx()),
                )
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(
                text = formatClock(t0),
                style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                color = TextTertiary,
                fontFamily = FontFamily.Monospace,
            )
            Text(
                text = formatClock(t1),
                style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                color = TextTertiary,
                fontFamily = FontFamily.Monospace,
            )
        }
    }
}

/** 分期图例：颜色点 + 名称 + 时长 */
@Composable
fun SleepStageLegend(session: SleepParser.Session, modifier: Modifier = Modifier) =
    SleepStageLegend(listOf(session), modifier)

/** 分期图例：颜色点 + 名称 + 当天多段睡眠的合并时长。 */
@Composable
fun SleepStageLegend(sessions: List<SleepParser.Session>, modifier: Modifier = Modifier) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources
    val minutes = SleepParser.combinedStageMinutes(sessions)
    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        SleepParser.Stage.entries.chunked(2).forEach { row ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                row.forEach { stage ->
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(
                            modifier =
                                Modifier.size(7.dp).clip(CircleShape).background(stageColor(stage))
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            strings.getString(stage.labelRes),
                            style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                            color = TextSecondary,
                        )
                        Spacer(modifier = Modifier.weight(1f))
                        Text(
                            text = sleepDurationText(minutes[stage] ?: 0, strings),
                            style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Medium,
                            color = TextSecondary,
                            fontFamily = FontFamily.Monospace,
                        )
                    }
                }
            }
        }
    }
}

/** 圆形睡眠评分环：270° 进度弧 + 中心分数，颜色随分数分档。 */
@Composable
fun SleepScoreRing(score: Int, modifier: Modifier = Modifier, ringSize: Dp = 96.dp) {
    val clamped = score.coerceIn(0, 100)
    val accent =
        when {
            clamped >= 85 -> SleepDeep
            clamped >= 70 -> HealthSleep
            clamped >= 60 -> SleepLight
            else -> SleepAwake
        }
    val track = CardBorder.copy(alpha = 0.5f)
    Box(modifier = modifier.size(ringSize), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val stroke = 7.dp.toPx()
            val inset = stroke / 2f
            val arcSize = Size(this.size.width - stroke, this.size.height - stroke)
            drawArc(
                color = track,
                startAngle = 135f,
                sweepAngle = 270f,
                useCenter = false,
                topLeft = Offset(inset, inset),
                size = arcSize,
                style = Stroke(width = stroke, cap = StrokeCap.Round),
            )
            if (clamped > 0) {
                drawArc(
                    color = accent,
                    startAngle = 135f,
                    sweepAngle = 270f * clamped / 100f,
                    useCenter = false,
                    topLeft = Offset(inset, inset),
                    size = arcSize,
                    style = Stroke(width = stroke, cap = StrokeCap.Round),
                )
            }
        }
        Text(
            text = "$clamped",
            style = androidx.compose.material3.MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = accent,
            fontFamily = FontFamily.Monospace,
        )
    }
}

/** 近 7 天睡眠时长柱状图 */
@Composable
fun SleepWeekBars(minutes: List<Int>, modifier: Modifier = Modifier) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources

    val values = if (minutes.size == 7) minutes else List(7) { 0 }
    val today = java.time.LocalDate.now()
    val labels =
        (6 downTo 0).map { offset ->
            when (today.minusDays(offset.toLong()).dayOfWeek.value) {
                1 -> strings.getString(R.string.mon)
                2 -> strings.getString(R.string.tue)
                3 -> strings.getString(R.string.wed)
                4 -> strings.getString(R.string.thu)
                5 -> strings.getString(R.string.fri)
                6 -> strings.getString(R.string.sat)
                else -> strings.getString(R.string.sun)
            }
        }
    val peak = values.maxOrNull() ?: 0
    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth().height(56.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.Bottom,
        ) {
            values.forEachIndexed { index, value ->
                val ratio = if (peak <= 0) 0f else value.toFloat() / peak
                Box(
                    modifier =
                        Modifier.weight(1f)
                            .height((56 * ratio).dp.coerceAtLeast(if (value <= 0) 2.dp else 4.dp))
                            .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
                            .background(
                                when {
                                    index == values.lastIndex -> SleepDeep
                                    value <= 0 -> CardBorder.copy(alpha = 0.45f)
                                    else -> SleepDeep.copy(alpha = 0.45f)
                                }
                            )
                )
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            labels.forEachIndexed { index, label ->
                Text(
                    text = label,
                    style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                    color = if (index == labels.lastIndex) TextSecondary else TextTertiary,
                    modifier = Modifier.weight(1f),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                )
            }
        }
    }
}

/** 时长文案：80 分钟 → 「1 小时 20 分」 */
fun sleepDurationText(minutes: Int, strings: android.content.res.Resources): String {
    if (minutes <= 0) return "—"
    val hours = minutes / 60
    val rest = minutes % 60
    return when {
        hours <= 0 -> strings.getString(R.string.duration_minutes_short, rest)
        rest == 0 -> strings.getString(R.string.duration_hours_short, hours)
        else -> strings.getString(R.string.duration_hours_minutes_short, hours, rest)
    }
}

fun formatRecordTime(millis: Long): String =
    java.text
        .SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault())
        .format(java.util.Date(millis))

fun formatClock(millis: Long, zone: java.time.ZoneId = java.time.ZoneId.systemDefault()): String =
    java.time.format.DateTimeFormatter.ofPattern("HH:mm", java.util.Locale.getDefault())
        .withZone(zone)
        .format(java.time.Instant.ofEpochMilli(millis))
