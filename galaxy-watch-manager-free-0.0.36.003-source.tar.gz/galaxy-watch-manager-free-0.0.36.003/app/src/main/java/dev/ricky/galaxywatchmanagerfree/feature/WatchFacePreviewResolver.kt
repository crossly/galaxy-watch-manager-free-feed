package dev.ricky.galaxywatchmanagerfree.feature

data class WatchFacePreviewSelection(val drawableName: String?, val isIllustration: Boolean)

object WatchFacePreviewResolver {
    fun resourceName(presetId: String): String = "wf_$presetId"

    fun select(presetId: String, drawableExists: (String) -> Boolean): WatchFacePreviewSelection {
        val name = resourceName(presetId)
        return if (drawableExists(name)) {
            WatchFacePreviewSelection(drawableName = name, isIllustration = false)
        } else {
            WatchFacePreviewSelection(drawableName = null, isIllustration = true)
        }
    }
}
