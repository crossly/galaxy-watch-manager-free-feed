package dev.ricky.galaxywatchmanagerfree.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.currentStateAsState
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.feature.StressLog
import dev.ricky.galaxywatchmanagerfree.feature.WatchState
import dev.ricky.galaxywatchmanagerfree.ui.components.AppBottomSheet
import dev.ricky.galaxywatchmanagerfree.ui.components.DetailDayChip
import dev.ricky.galaxywatchmanagerfree.ui.components.DetailStatCell
import dev.ricky.galaxywatchmanagerfree.ui.components.GroupedCard
import dev.ricky.galaxywatchmanagerfree.ui.components.GroupedCardRow
import dev.ricky.galaxywatchmanagerfree.ui.components.GroupedDivider
import dev.ricky.galaxywatchmanagerfree.ui.components.StressChart
import dev.ricky.galaxywatchmanagerfree.ui.components.formatMonitorRecordTime
import dev.ricky.galaxywatchmanagerfree.ui.components.formatStressValue
import dev.ricky.galaxywatchmanagerfree.ui.theme.AlertCrimson
import dev.ricky.galaxywatchmanagerfree.ui.theme.CardSurfaceElevated
import dev.ricky.galaxywatchmanagerfree.ui.theme.EmeraldCharging
import dev.ricky.galaxywatchmanagerfree.ui.theme.HealthStress
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextPrimary
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextSecondary
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextTertiary
import dev.ricky.galaxywatchmanagerfree.ui.theme.WarningAmber
import java.time.LocalDate
import java.time.ZoneId
import kotlinx.coroutines.delay

/** 压力监测详情：最新真实测量（含测量时间与同步时间区分）、官方原始分类、逐日图表与时间倒序读数。 呼吸训练只是放松引导，不读取压力传感器，也不产生测量值。 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StressDetailSheet(
    state: WatchState,
    onDismiss: () -> Unit,
    onMeasure: () -> Unit,
    onOpenMeasurementSettings: () -> Unit,
) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val zone = remember { ZoneId.systemDefault() }
    val today = LocalDate.now(zone)
    val history = state.stressHistory
    val latest = state.latestStress ?: history.values.asSequence().flatten().maxByOrNull { it.ts }
    val availableDays =
        remember(history, state.stressDays, today) {
            (history.keys + state.stressDays.keys)
                .mapNotNull { runCatching { LocalDate.parse(it) }.getOrNull() }
                .distinct()
                .sortedDescending()
        }
    val dayOptions =
        remember(availableDays, today) {
            (listOf(today) + availableDays).distinct().sortedDescending()
        }
    var selectedDayIso by rememberSaveable { mutableStateOf<String?>(null) }
    val selectedDay =
        selectedDayIso?.let { runCatching { LocalDate.parse(it) }.getOrNull() } ?: today
    val selectedPoints = history[selectedDay.toString()].orEmpty().sortedBy { it.ts }
    val selectedStats = state.stressDays[selectedDay.toString()] ?: StressLog.stats(selectedPoints)
    var showAllReadings by remember(selectedDayIso) { mutableStateOf(false) }
    val newestFirst = selectedPoints.asReversed()
    val previewCount = 20
    val visibleReadings = if (showAllReadings) newestFirst else newestFirst.take(previewCount)
    val readingBatches = visibleReadings.chunked(20)

    val score = latest?.score ?: state.lastStressScore.takeIf { it >= 0 }?.toFloat()
    val level = StressLog.Level.of(score)
    val statusLabel =
        when (level) {
            StressLog.Level.RELAXED -> strings.getString(R.string.relaxed)
            StressLog.Level.LOW -> strings.getString(R.string.low)
            StressLog.Level.MODERATE -> strings.getString(R.string.stress_level_moderate)
            StressLog.Level.HIGH -> strings.getString(R.string.high)
            null -> strings.getString(R.string.no_measurement)
        }
    val statusColor =
        when (level) {
            StressLog.Level.RELAXED -> EmeraldCharging
            StressLog.Level.LOW -> HealthStress
            StressLog.Level.MODERATE -> WarningAmber
            StressLog.Level.HIGH -> AlertCrimson
            null -> TextTertiary
        }
    val canMeasure = state.connected && state.sessionReady

    var breathingActive by remember { mutableStateOf(false) }
    var breathingPhase by remember { mutableStateOf(R.string.breathe_in) }
    val scale = remember { Animatable(1f) }
    val lifecycle by LocalLifecycleOwner.current.lifecycle.currentStateAsState()
    val running = breathingActive && lifecycle.isAtLeast(Lifecycle.State.STARTED)
    LaunchedEffect(running) {
        if (running) {
            while (running) {
                breathingPhase = R.string.breathe_in
                scale.animateTo(1.35f, tween(4000, easing = LinearEasing))
                breathingPhase = R.string.hold
                delay(4000)
                breathingPhase = R.string.breathe_out
                scale.animateTo(1.0f, tween(4000, easing = LinearEasing))
                delay(1000)
            }
        } else {
            scale.snapTo(1f)
        }
    }

    AppBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        LazyColumn(
            modifier =
                Modifier.fillMaxWidth()
                    .testTag("stress_detail_list")
                    .padding(horizontal = 20.dp)
                    .padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item {
                dev.ricky.galaxywatchmanagerfree.ui.components.SheetToolbar(
                    strings.getString(R.string.stress),
                    onDismiss,
                )
            }

            // 最新一次真实测量：分数、官方分类、测量时间与整体同步时间分开显示。
            item {
                GroupedCard(innerPadding = 18.dp) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                strings.getString(R.string.latest_measurement_2),
                                style = MaterialTheme.typography.labelMedium,
                                color = TextTertiary,
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Row(verticalAlignment = Alignment.Bottom) {
                                Text(
                                    text = score?.let(::formatStressValue) ?: "—",
                                    style = MaterialTheme.typography.headlineLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = statusColor,
                                    fontFamily = FontFamily.Monospace,
                                )
                                Text(
                                    text = " / 100",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = TextSecondary,
                                    modifier = Modifier.padding(bottom = 6.dp),
                                )
                            }
                        }

                        Box(
                            modifier =
                                Modifier.clip(RoundedCornerShape(999.dp))
                                    .background(statusColor.copy(alpha = 0.16f))
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = statusLabel,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold,
                                color = statusColor,
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text =
                            when {
                                latest != null ->
                                    strings.getString(
                                        R.string.metric_measured_at,
                                        formatMonitorRecordTime(latest.ts),
                                    )
                                score != null ->
                                    strings.getString(R.string.stress_measurement_time_unknown)
                                else -> strings.getString(R.string.no_measurement)
                            },
                        style = MaterialTheme.typography.bodySmall,
                        color = if (latest != null) TextSecondary else TextTertiary,
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text =
                            strings.getString(
                                R.string.overall_health_sync,
                                if (state.lastHealthSyncTime > 0)
                                    formatMonitorRecordTime(state.lastHealthSyncTime)
                                else strings.getString(R.string.not_synced),
                            ),
                        style = MaterialTheme.typography.bodySmall,
                        color = TextTertiary,
                    )
                    if (
                        latest != null && (latest.min != latest.score || latest.max != latest.score)
                    ) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text =
                                strings.getString(
                                    R.string.stress_raw_range,
                                    formatStressValue(latest.min),
                                    formatStressValue(latest.max),
                                ),
                            style = MaterialTheme.typography.bodySmall,
                            color = TextTertiary,
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // 官方原始分类色带：0–10 / 10–20 / 20–80 / 80–100，不做等宽四段假刻度。
                    Row(
                        modifier =
                            Modifier.fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(CardSurfaceElevated),
                        horizontalArrangement = Arrangement.spacedBy(2.dp),
                    ) {
                        val colors =
                            listOf(EmeraldCharging, HealthStress, WarningAmber, AlertCrimson)
                        val weights = listOf(1f, 1f, 6f, 2f)
                        colors.forEachIndexed { index, color ->
                            Box(
                                modifier =
                                    Modifier.weight(weights[index])
                                        .height(8.dp)
                                        .background(
                                            if (level != null && level.ordinal >= index) color
                                            else color.copy(alpha = 0.3f)
                                        )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(
                            strings.getString(R.string.stress_scale_low),
                            style = MaterialTheme.typography.labelSmall,
                            color = TextTertiary,
                        )
                        Text(
                            strings.getString(R.string.stress_scale_high),
                            style = MaterialTheme.typography.labelSmall,
                            color = TextTertiary,
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        strings.getString(R.string.stress_level_bands),
                        style = MaterialTheme.typography.labelSmall,
                        color = TextTertiary,
                    )
                }
            }

            // 测量与会话状态：按钮只在连接且会话就绪时可用，不伪造测量进度或结果。
            item {
                GroupedCard(innerPadding = 16.dp) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = null,
                            tint = HealthStress,
                            modifier = Modifier.size(18.dp),
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            strings.getString(R.string.stress_measurement_title),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        strings.getString(R.string.stress_measurement_hint),
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Button(
                            onClick = onMeasure,
                            enabled = canMeasure,
                            modifier = Modifier.weight(1f),
                        ) {
                            Text(
                                strings.getString(R.string.stress_measure_now),
                                maxLines = 2,
                                textAlign = TextAlign.Center,
                            )
                        }
                        OutlinedButton(
                            onClick = onOpenMeasurementSettings,
                            enabled = canMeasure,
                            modifier = Modifier.weight(1f),
                        ) {
                            Text(
                                strings.getString(R.string.stress_measurement_settings),
                                maxLines = 2,
                                textAlign = TextAlign.Center,
                            )
                        }
                    }
                    if (!canMeasure) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            strings.getString(R.string.stress_measurement_unavailable),
                            style = MaterialTheme.typography.labelSmall,
                            color = TextTertiary,
                        )
                    }
                }
            }

            if (latest != null || state.stressDays.isNotEmpty() || history.isNotEmpty()) {
                item {
                    GroupedCard(innerPadding = 16.dp) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Bottom,
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    strings.getString(R.string.stress_daily_statistics),
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary,
                                )
                                Text(
                                    if (selectedDay == today)
                                        strings.getString(R.string.heart_today_label)
                                    else selectedDay.toString(),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary,
                                )
                            }
                            if (selectedStats != null) {
                                Text(
                                    strings.getQuantityString(
                                        R.plurals.stress_readings_count,
                                        selectedStats.count,
                                        selectedStats.count,
                                    ),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = TextTertiary,
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(dayOptions, key = { it.toString() }) { day ->
                                DetailDayChip(
                                    day = day.toString(),
                                    selected = day == selectedDay,
                                    accent = HealthStress,
                                    onClick = { selectedDayIso = day.toString() },
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(14.dp))
                        if (selectedStats != null) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                DetailStatCell(
                                    strings.getString(R.string.minimum),
                                    formatStressValue(selectedStats.min),
                                    Modifier.weight(1f),
                                )
                                DetailStatCell(
                                    strings.getString(R.string.average),
                                    formatStressValue(selectedStats.avg),
                                    Modifier.weight(1f),
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                DetailStatCell(
                                    strings.getString(R.string.maximum),
                                    formatStressValue(selectedStats.max),
                                    Modifier.weight(1f),
                                )
                                DetailStatCell(
                                    strings.getString(R.string.stress_readings),
                                    selectedStats.count.toString(),
                                    Modifier.weight(1f),
                                )
                            }
                        } else {
                            Text(
                                if (selectedDay == today)
                                    strings.getString(R.string.stress_no_readings_today)
                                else
                                    strings.getString(
                                        R.string.stress_no_readings_on_day,
                                        selectedDay.toString(),
                                    ),
                                style = MaterialTheme.typography.bodySmall,
                                color = TextTertiary,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                            )
                        }
                    }
                }
            }

            if (selectedPoints.isNotEmpty()) {
                item {
                    GroupedCard(innerPadding = 16.dp) {
                        Text(
                            if (selectedDay == today) strings.getString(R.string.stress_today_chart)
                            else
                                strings.getString(
                                    R.string.stress_day_chart,
                                    selectedDay.toString(),
                                ),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        StressChart(points = selectedPoints, day = selectedDay, zone = zone)
                    }
                }
            }

            if (score == null && history.isEmpty() && state.stressDays.isEmpty()) {
                item {
                    GroupedCard {
                        Box(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 28.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                strings.getString(
                                    R.string.wear_the_watch_and_take_a_measurement_to_view
                                ),
                                style = MaterialTheme.typography.bodySmall,
                                color = TextTertiary,
                                textAlign = TextAlign.Center,
                            )
                        }
                    }
                }
            }

            // 呼吸放松引导：只是放松练习，明确不读取压力传感器。
            item {
                GroupedCard(innerPadding = 20.dp) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(
                                imageVector = Icons.Default.SelfImprovement,
                                contentDescription = null,
                                tint = HealthStress,
                                modifier = Modifier.size(18.dp),
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                strings.getString(R.string.guided_breathing),
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                            )
                        }

                        TextButton(onClick = { breathingActive = !breathingActive }) {
                            Text(
                                text =
                                    if (breathingActive) strings.getString(R.string.stop)
                                    else strings.getString(R.string.start_exercise),
                                style = MaterialTheme.typography.labelLarge,
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Animate only the decoration; translated labels retain their layout.
                    Box(
                        modifier = Modifier.fillMaxWidth().height(180.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Box(
                            modifier =
                                Modifier.size(120.dp)
                                    .graphicsLayer {
                                        scaleX = scale.value
                                        scaleY = scale.value
                                    }
                                    .clip(CircleShape)
                                    .background(HealthStress.copy(alpha = 0.18f))
                                    .border(1.5.dp, HealthStress, CircleShape)
                        )
                        Text(
                            text =
                                strings.getString(
                                    if (breathingActive) breathingPhase else R.string.deep_breathing
                                ),
                            modifier = Modifier.width(180.dp).padding(horizontal = 12.dp),
                            style = MaterialTheme.typography.bodyMedium,
                            textAlign = TextAlign.Center,
                            fontWeight = FontWeight.Bold,
                            color = if (breathingActive) HealthStress else TextSecondary,
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text =
                            strings.getString(R.string.breathe_in_for_4_seconds_hold_for_4_seconds),
                        style = MaterialTheme.typography.labelMedium,
                        color = TextTertiary,
                        lineHeight = 16.sp,
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = strings.getString(R.string.breathing_relaxation_note),
                        style = MaterialTheme.typography.labelMedium,
                        color = TextTertiary,
                        lineHeight = 16.sp,
                    )
                }
            }

            if (selectedPoints.isNotEmpty()) {
                item {
                    Text(
                        strings.getString(R.string.stress_readings),
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        color = TextSecondary,
                        modifier =
                            Modifier.testTag("stress_readings_header").padding(horizontal = 4.dp),
                    )
                }
                items(readingBatches, key = { it.first().ts }) { batch ->
                    GroupedCard(innerPadding = 0.dp) {
                        batch.forEachIndexed { index, point ->
                            if (index > 0) GroupedDivider()
                            GroupedCardRow(
                                title = "${formatStressValue(point.score)} / 100",
                                subtitle =
                                    buildString {
                                        append(formatMonitorRecordTime(point.ts))
                                        if (point.min != point.score || point.max != point.score) {
                                            append(" · ")
                                            append(
                                                strings.getString(
                                                    R.string.stress_raw_range,
                                                    formatStressValue(point.min),
                                                    formatStressValue(point.max),
                                                )
                                            )
                                        }
                                    },
                            )
                        }
                    }
                }
                if (newestFirst.size > previewCount) {
                    item {
                        Box(
                            modifier = Modifier.fillMaxWidth(),
                            contentAlignment = Alignment.Center,
                        ) {
                            TextButton(onClick = { showAllReadings = !showAllReadings }) {
                                Text(
                                    if (showAllReadings)
                                        strings.getString(R.string.stress_show_fewer_readings)
                                    else
                                        strings.getString(
                                            R.string.stress_view_all_readings,
                                            newestFirst.size,
                                        )
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
