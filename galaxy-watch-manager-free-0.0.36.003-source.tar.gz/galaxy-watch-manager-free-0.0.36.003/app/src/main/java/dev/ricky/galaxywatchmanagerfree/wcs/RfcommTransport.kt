package dev.ricky.galaxywatchmanagerfree.wcs

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.Context
import dev.ricky.galaxywatchmanagerfree.feature.LogBus
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

private const val KEEPALIVE_INTERVAL_MS = 10_000L

/**
 * 经典蓝牙 RFCOMM 传输层（双工：Client 主动连接 + Server 被动监听）。
 *
 * 核心机制（完全对齐 Google Wear 官方 hfp.java / MigratingBTServer 架构）：
 * 1. 手机端作为 Server 端常驻监听 "WearableBt" (UUID: 5e8945b0...)，手表任何时刻醒来主动连入均可被 accept() 秒接；
 * 2. 手机端同时作为 Client 端尝试连接手表的 RFCOMM 服务端（SDP Secure → SDP Insecure → Channel 5/8/4/7）；
 * 3. 若 Client 直连被拒（Connect refused），通过 BleWakeLock (GATT TLV) 唤醒手表；
 * 4. 任意一路建立成功后，统一接管流式 Envelope 读写与保活。
 */
class RfcommTransport(private val context: Context, private val device: BluetoothDevice? = null) {

    private val running = AtomicBoolean(false)
    private val connectionLock = java.lang.Object()
    private val reconnectPolicy = ReconnectPolicy()
    // Order lifecycle callbacks without holding the resource lock needed by stop().
    private val lifecycleLock = Any()
    @Volatile
    var isConnected: Boolean = false
        private set

    private var socket: BluetoothSocket? = null
    private var serverSocket: BluetoothServerSocket? = null
    private var input: InputStream? = null
    private var output: OutputStream? = null
    private val sendLock = Any()

    @Volatile private var listener: Listener? = null
    @Volatile private var connectingSocket: BluetoothSocket? = null
    private var connectThread: Thread? = null
    private var heartbeatThread: Thread? = null
    @Volatile var keepaliveFrame: ByteArray? = null

    /**
     * 发送队列。
     *
     * 关键：写套接字可能因手表休眠/缓冲满而阻塞数秒，绝不能在主线程直接 write。 所有调用方（通知监听、广播接收器、UI 点击）只需入队，由 writer 线程实际写出。
     */
    private val sendQueue = java.util.concurrent.LinkedBlockingQueue<ByteArray>(1024)
    private var writerThread: Thread? = null

    @Volatile private var refused: Boolean = false

    interface Listener {
        fun onConnected()

        fun onDisconnected(reason: String)

        fun onEnvelope(body: ByteArray)

        fun onLog(line: String)
    }

    fun setListener(l: Listener?) {
        listener = l
    }

    fun start() {
        if (
            android.os.Build.VERSION.SDK_INT >= 31 &&
                context.checkSelfPermission(android.Manifest.permission.BLUETOOTH_CONNECT) !=
                    android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            listener?.onLog("请先授予蓝牙连接权限")
            LogBus.error("[RFC] 缺少蓝牙连接权限 (BLUETOOTH_CONNECT)")
            return
        }
        if (!running.compareAndSet(false, true)) return
        LogBus.debug { "[RFC] 启动双工传输层（Client 连接线程 + Server 监听线程）" }
        startServer()
        connectThread = thread(name = "wcs-client-connect", isDaemon = true) { connectLoop() }
    }

    fun stop() {
        running.set(false)
        connectThread?.interrupt()
        connectThread = null
        runCatching { connectingSocket?.close() }
        connectingSocket = null
        synchronized(connectionLock) {
            isConnected = false
            closeQuietly()
            connectionLock.notifyAll()
        }
    }

    private fun trace(msg: String) {
        LogBus.debug { "[RFC] $msg" }
    }

    // Server mode (passive inbound listener)

    @android.annotation.SuppressLint("MissingPermission") // Bluetooth calls are inside try/catch.
    private fun startServer() {
        thread(name = "wcs-rfcomm-server", isDaemon = true) {
            val adapter = BluetoothAdapter.getDefaultAdapter()
            if (adapter == null) {
                LogBus.debug { "[RFC] Server: 无法获取 BluetoothAdapter" }
                return@thread
            }
            try {
                // 对齐官方 hfp.java: listenUsingRfcommWithServiceRecord("WearableBt", 5e8945b0...)
                val srv =
                    adapter.listenUsingRfcommWithServiceRecord("WearableBt", WcsPaths.DATA_LAYER)
                serverSocket = srv
                LogBus.debug { "[RFC] Server 监听开启成功: WearableBt on ${WcsPaths.DATA_LAYER}" }

                while (running.get()) {
                    val incoming =
                        try {
                            srv.accept()
                        } catch (e: IOException) {
                            if (running.get())
                                LogBus.error("[RFC] Server accept 异常: ${e.message}", e)
                            break
                        } ?: break

                    val incomingAddr = incoming.remoteDevice?.address.orEmpty()
                    LogBus.debug { "[RFC] Server 收到连入请求: $incomingAddr" }

                    if (device == null || incomingAddr.equals(device.address, ignoreCase = true)) {
                        handleEstablishedSocket(incoming, "Server(Incoming)")
                    } else {
                        LogBus.debug { "[RFC] 非目标手表连入，直接拒绝: $incomingAddr" }
                        runCatching { incoming.close() }
                    }
                }
            } catch (e: Exception) {
                LogBus.debug { "[RFC] Server 线程退出: ${e.message}" }
            } finally {
                runCatching { serverSocket?.close() }
                serverSocket = null
            }
        }
    }

    // Client mode (active outbound connector)

    @android.annotation.SuppressLint("MissingPermission") // SDP refresh handles SecurityException.
    private fun connectLoop() {
        while (running.get()) {
            if (isConnected) {
                try {
                    synchronized(connectionLock) {
                        while (running.get() && isConnected) connectionLock.wait()
                    }
                } catch (_: InterruptedException) {
                    break
                }
                continue
            }

            var ready = tryOpen()

            // 连接失败的原因尚不唯一；尝试 BLE 后重试标准 RFCOMM。
            if (
                ready == null &&
                    refused &&
                    !isConnected &&
                    running.get() &&
                    reconnectPolicy.mayWake()
            ) {
                listener?.onLog("通道被拒 → 尝试 BLE 后重连 RFCOMM")
                LogBus.log("[RFC] 通道被拒 → 尝试 BLE 后重连 RFCOMM")
                if (device != null) BleWakeLock.wake(context, device)
                try {
                    device?.fetchUuidsWithSdp()
                    LogBus.debug { "[RFC] 已请求 fetchUuidsWithSdp" }
                    Thread.sleep(1500)
                } catch (_: InterruptedException) {
                    break
                } catch (e: Exception) {
                    LogBus.error("[RFC] ACL 唤醒异常: ${e.message}", e)
                }
                if (!isConnected) {
                    ready = tryOpen()
                }
            }

            if (ready != null) {
                handleEstablishedSocket(ready, "Client(Outgoing)")
            }

            if (!running.get()) break

            val backoff = reconnectPolicy.nextDelayMillis()
            if (!isConnected) {
                listener?.onLog("${backoff}ms 后重试")
                LogBus.debug { "[RFC] ${backoff}ms 后重试连接" }
            }
            try {
                Thread.sleep(backoff)
            } catch (_: InterruptedException) {
                break
            }
        }
    }

    private fun handleEstablishedSocket(sock: BluetoothSocket, label: String) {
        try {
            val accepted =
                synchronized(lifecycleLock) {
                    val connected =
                        synchronized(connectionLock) {
                            if (!running.get() || isConnected) false
                            else {
                                socket = sock
                                input = sock.inputStream
                                output = sock.outputStream
                                isConnected = true
                                reconnectPolicy.connected()
                                startWriter()
                                startHeartbeat()
                                true
                            }
                        }
                    if (connected) {
                        listener?.onConnected()
                        listener?.onLog("RFCOMM 已接通 [$label]")
                        LogBus.log("[RFC] RFCOMM 已接通 [$label]")
                    }
                    connected
                }
            if (!accepted) {
                runCatching { sock.close() }
                return
            }
            readLoop()
        } catch (t: Throwable) {
            LogBus.error("[RFC] 读循环异常: ${t.javaClass.simpleName}: ${t.message}", t)
        } finally {
            synchronized(lifecycleLock) {
                val disconnected =
                    synchronized(connectionLock) {
                        // An obsolete read loop must not clear a replacement connection.
                        if (socket === sock) {
                            isConnected = false
                            reconnectPolicy.disconnected()
                            closeSocketQuietly()
                            connectionLock.notifyAll()
                            true
                        } else false
                    }
                if (disconnected) {
                    listener?.onDisconnected("连接结束")
                    LogBus.log("[RFC] RFCOMM 连接已断开 [$label]")
                }
            }
        }
    }

    private fun tryOpen(): BluetoothSocket? {
        refused = false
        if (!running.get() || isConnected) return null
        openSdp(secure = true)?.let {
            return it
        }
        if (!running.get() || isConnected) return null
        openSdp(secure = false)?.let {
            return it
        }
        for (ch in CHANNELS) {
            if (!running.get() || isConnected) return null
            openChannel(ch)?.let {
                return it
            }
        }
        return null
    }

    private fun openSdp(secure: Boolean): BluetoothSocket? {
        val dev = device ?: return null
        val label = if (secure) "SDP(Secure)" else "SDP(Insecure)"
        var candidate: BluetoothSocket? = null
        val t0 = System.currentTimeMillis()
        return try {
            val s =
                if (secure) {
                    dev.createRfcommSocketToServiceRecord(WcsPaths.DATA_LAYER)
                } else {
                    dev.createInsecureRfcommSocketToServiceRecord(WcsPaths.DATA_LAYER)
                }
            candidate = s
            connectCandidate(s)
            val elapsed = System.currentTimeMillis() - t0
            LogBus.debug { "[RFC] $label 连接成功 (耗时 ${elapsed}ms)" }
            s
        } catch (e: Exception) {
            val elapsed = System.currentTimeMillis() - t0
            runCatching { candidate?.close() }
            noteFailure(e)
            LogBus.debug {
                "[RFC] $label 失败 (耗时 ${elapsed}ms): ${e.javaClass.simpleName}: ${e.message}"
            }
            null
        }
    }

    private fun openChannel(channel: Int): BluetoothSocket? {
        val dev = device ?: return null
        var candidate: BluetoothSocket? = null
        val t0 = System.currentTimeMillis()
        return try {
            val m = dev.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType)
            val s = m.invoke(dev, channel) as BluetoothSocket
            candidate = s
            connectCandidate(s)
            val elapsed = System.currentTimeMillis() - t0
            LogBus.debug { "[RFC] Channel $channel 连接成功 (耗时 ${elapsed}ms)" }
            s
        } catch (e: Exception) {
            val elapsed = System.currentTimeMillis() - t0
            runCatching { candidate?.close() }
            noteFailure(e)
            LogBus.debug {
                "[RFC] Channel $channel 失败 (耗时 ${elapsed}ms): ${e.javaClass.simpleName}: ${e.message}"
            }
            null
        }
    }

    private fun connectCandidate(candidate: BluetoothSocket) {
        synchronized(connectionLock) {
            if (!running.get() || isConnected) throw IOException("连接已停止或已有活动连接")
            connectingSocket = candidate
        }
        try {
            candidate.connect()
            if (!running.get()) throw IOException("连接已停止")
        } finally {
            connectingSocket = null
        }
    }

    private fun noteFailure(e: Throwable) {
        val m = e.message.orEmpty()
        if (m.contains("refused", ignoreCase = true) || m.contains("rejected", ignoreCase = true)) {
            refused = true
        }
    }

    // Read loop

    private fun readLoop() {
        val inp = input ?: return
        val lenBuf = ByteArray(4)
        while (running.get() && isConnected) {
            try {
                readFully(inp, lenBuf)
                val len = LengthPrefix.readLength(lenBuf)
                if (len <= 0 || len > 4 * 1024 * 1024) {
                    listener?.onLog("非法帧长度 $len，重建连接")
                    LogBus.error("[RFC] 非法帧长度 $len，重建连接")
                    break
                }
                val body = ByteArray(len)
                readFully(inp, body)
                LogBus.debug { "[RFC] 收到帧 ${body.size}B" }
                listener?.onEnvelope(body)
            } catch (e: IOException) {
                if (running.get()) {
                    listener?.onLog("读循环结束: ${e.message}")
                    LogBus.debug { "[RFC] 读循环结束: ${e.message}" }
                }
                break
            }
        }
    }

    private fun readFully(inp: InputStream, buf: ByteArray) {
        var off = 0
        while (off < buf.size) {
            val n = inp.read(buf, off, buf.size - off)
            if (n < 0) throw IOException("EOF")
            off += n
        }
    }

    // Write and keepalive

    /** 入队发送（不阻塞调用方线程，顺序由队列保证） */
    fun send(frame: ByteArray): Boolean {
        if (!isConnected || output == null) {
            LogBus.debug { "[RFC] TX rejected reason=transport_offline bytes=${frame.size}" }
            return false
        }
        val queued = sendQueue.offer(frame)
        if (!queued) {
            listener?.onLog("发送队列已满，丢弃一帧 ${frame.size}B")
            LogBus.error("[RFC] 发送队列已满 (容量1024)，丢弃帧 ${frame.size}B")
        } else {
            LogBus.debug { "[RFC] 帧入队 ${frame.size}B (待发队列数=${sendQueue.size})" }
        }
        return queued
    }

    private fun startWriter() {
        val activeSocket = socket ?: return
        val out = output ?: return
        writerThread?.interrupt()
        writerThread =
            thread(name = "wcs-writer", isDaemon = true) {
                while (running.get() && isConnected) {
                    val frame =
                        try {
                            sendQueue.take()
                        } catch (_: InterruptedException) {
                            break
                        }
                    val t0 = System.currentTimeMillis()
                    val ok =
                        synchronized(sendLock) {
                            try {
                                out.write(frame)
                                out.flush()
                                true
                            } catch (e: IOException) {
                                listener?.onLog("发送失败: ${e.message}")
                                LogBus.error("[RFC] 实际写出套接字失败: ${e.message}", e)
                                false
                            }
                        }
                    val elapsed = System.currentTimeMillis() - t0
                    if (ok) {
                        LogBus.debug {
                            "[RFC] 帧写出成功 ${frame.size}B (耗时 ${elapsed}ms, 剩余待发=${sendQueue.size})"
                        }
                    } else {
                        // 关闭当前 socket 以唤醒阻塞中的 read，交给读循环统一清理与重连。
                        runCatching { activeSocket.close() }
                        break
                    }
                }
            }
    }

    private fun startHeartbeat() {
        heartbeatThread?.interrupt()
        heartbeatThread =
            thread(name = "wcs-heartbeat", isDaemon = true) {
                while (running.get() && isConnected) {
                    try {
                        Thread.sleep(KEEPALIVE_INTERVAL_MS)
                    } catch (_: InterruptedException) {
                        break
                    }
                    if (!isConnected) break
                    keepaliveFrame?.let { send(it) }
                }
            }
    }

    private fun closeSocketQuietly() {
        heartbeatThread?.interrupt()
        heartbeatThread = null
        writerThread?.interrupt()
        writerThread = null
        val cleared = sendQueue.size
        sendQueue.clear()
        if (cleared > 0) {
            LogBus.debug { "[RFC] 连接断开，清空发送队列 $cleared 帧" }
        }
        try {
            input?.close()
        } catch (_: Exception) {}
        try {
            output?.close()
        } catch (_: Exception) {}
        try {
            socket?.close()
        } catch (_: Exception) {}
        input = null
        output = null
        socket = null
    }

    private fun closeQuietly() {
        closeSocketQuietly()
        try {
            serverSocket?.close()
        } catch (_: Exception) {}
        serverSocket = null
    }

    companion object {
        private val CHANNELS = intArrayOf(5, 8, 4, 7)
    }
}
