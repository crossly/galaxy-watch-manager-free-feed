package dev.ricky.galaxywatchmanagerfree.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.feature.StressLog
import dev.ricky.galaxywatchmanagerfree.ui.theme.AlertCrimson
import dev.ricky.galaxywatchmanagerfree.ui.theme.CardBorder
import dev.ricky.galaxywatchmanagerfree.ui.theme.EmeraldCharging
import dev.ricky.galaxywatchmanagerfree.ui.theme.HealthStress
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextTertiary
import dev.ricky.galaxywatchmanagerfree.ui.theme.WarningAmber

/** 指定日期的压力曲线：本地 0–24 时、0–100 原始分数与实际分级色带。 渐变曲线、点按/横向拖动探针及选择指引线与心率图保持一致。 */
@Composable
fun StressChart(
    points: List<StressLog.Point>,
    day: java.time.LocalDate,
    modifier: Modifier = Modifier,
    zone: java.time.ZoneId = java.time.ZoneId.systemDefault(),
) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources
    val gridColor = CardBorder.copy(alpha = 0.55f)
    val labelColor = TextTertiary
    val relaxedColor = EmeraldCharging
    val lowColor = HealthStress
    val moderateColor = WarningAmber
    val highColor = AlertCrimson
    val lineColor = HealthStress
    val thresholdColor = WarningAmber.copy(alpha = 0.35f)
    val (dayStart, dayEnd) =
        remember(day, zone) {
            day.atStartOfDay(zone).toInstant().toEpochMilli() to
                day.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()
        }
    val sorted =
        remember(points, dayStart, dayEnd) {
            points
                .filter {
                    it.ts in dayStart until dayEnd &&
                        it.score in StressLog.MIN_SCORE..StressLog.MAX_SCORE
                }
                .sortedBy { it.ts }
        }
    val positions = remember(sorted, zone) { sorted.map { chartDayFraction(it.ts, zone) } }
    var selected by remember(sorted, day, zone) { mutableStateOf<StressLog.Point?>(null) }

    Column(modifier = modifier.fillMaxWidth()) {
        selected?.let { point ->
            val level = StressLog.Level.of(point.score)
            val levelLabel =
                strings.getString(
                    when (level) {
                        StressLog.Level.RELAXED -> R.string.relaxed
                        StressLog.Level.LOW -> R.string.low
                        StressLog.Level.MODERATE -> R.string.stress_level_moderate
                        StressLog.Level.HIGH -> R.string.high
                        null -> R.string.no_measurement
                    }
                )
            val selectedColor =
                when (level) {
                    StressLog.Level.RELAXED -> relaxedColor
                    StressLog.Level.LOW -> lowColor
                    StressLog.Level.MODERATE -> moderateColor
                    StressLog.Level.HIGH -> highColor
                    null -> lineColor
                }
            Box(
                modifier =
                    Modifier.fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(selectedColor.copy(alpha = 0.12f))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = formatClock(point.ts, zone),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = selectedColor,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.weight(1f),
                    )
                    Text(
                        text =
                            strings.getString(
                                R.string.stress_chart_reading,
                                formatStressValue(point.score),
                                levelLabel,
                            ),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = selectedColor,
                        fontFamily = FontFamily.Monospace,
                        textAlign = TextAlign.End,
                        modifier = Modifier.weight(2f),
                    )
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
        }

        Canvas(
            modifier =
                Modifier.fillMaxWidth()
                    .height(132.dp)
                    .testTag("stress_chart")
                    .semantics {
                        contentDescription =
                            strings.getString(R.string.stress_chart_description, sorted.size)
                    }
                    .chartProbe(
                        positions,
                        sorted.indexOf(selected).takeIf { it >= 0 },
                        label = strings.getString(R.string.stress),
                        readings =
                            sorted.map {
                                "${formatClock(it.ts, zone)} · ${formatStressValue(it.score)} / 100"
                            },
                    ) { index ->
                        selected = index?.let(sorted::get)
                    }
        ) {
            val usable = (size.height - 10.dp.toPx()).coerceAtLeast(1f)
            fun yOf(score: Float) = (usable * (1f - score / 100f)).coerceIn(0f, usable)
            // 官方原始分类色带。
            drawRect(
                relaxedColor.copy(alpha = 0.07f),
                topLeft = Offset(0f, yOf(10f)),
                size = androidx.compose.ui.geometry.Size(size.width, yOf(0f) - yOf(10f)),
            )
            drawRect(
                lowColor.copy(alpha = 0.07f),
                topLeft = Offset(0f, yOf(20f)),
                size = androidx.compose.ui.geometry.Size(size.width, yOf(10f) - yOf(20f)),
            )
            drawRect(
                moderateColor.copy(alpha = 0.07f),
                topLeft = Offset(0f, yOf(80f)),
                size = androidx.compose.ui.geometry.Size(size.width, yOf(20f) - yOf(80f)),
            )
            drawRect(
                highColor.copy(alpha = 0.07f),
                topLeft = Offset(0f, yOf(100f)),
                size = androidx.compose.ui.geometry.Size(size.width, yOf(80f) - yOf(100f)),
            )

            listOf(0, 20, 40, 60, 80, 100).forEach { score ->
                val y = yOf(score.toFloat())
                drawLine(gridColor, Offset(0f, y), Offset(size.width, y), strokeWidth = 1f)
            }
            listOf(10f, 20f, 80f).forEach { score ->
                val y = yOf(score)
                drawLine(
                    thresholdColor,
                    Offset(0f, y),
                    Offset(size.width, y),
                    strokeWidth = 1f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(5f, 5f)),
                )
            }
            listOf(0f, 6f, 12f, 18f, 24f).forEach { hour ->
                val x = size.width * hour / 24f
                drawLine(gridColor, Offset(x, 0f), Offset(x, usable), strokeWidth = 1f)
            }
            if (sorted.isEmpty()) return@Canvas

            val offsets =
                sorted.mapIndexed { index, point ->
                    Offset(size.width * positions[index], yOf(point.score))
                }
            drawReadingCurve(
                offsets,
                lineColor,
                usable,
                sorted.indexOf(selected).takeIf { it >= 0 },
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        ChartTimeAxis()
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = strings.getString(R.string.stress_axis_label),
            style = MaterialTheme.typography.labelSmall,
            color = labelColor,
            fontFamily = FontFamily.Monospace,
        )
    }
}

/** 与页面其他数值一致：整数原样显示，小数保留一位。 */
fun formatStressValue(value: Float): String =
    if (value == value.toInt().toFloat()) value.toInt().toString()
    else java.lang.String.format(java.util.Locale.US, "%.1f", value)
