package dev.ricky.galaxywatchmanagerfree.feature.monitor

import dev.ricky.galaxywatchmanagerfree.feature.HealthJson
import java.io.ByteArrayOutputStream
import java.util.Base64
import java.util.Locale
import java.util.zip.GZIPOutputStream
import org.json.JSONArray
import org.json.JSONObject

/**
 * Samsung Health Monitor 协议编解码与信令工厂。 逆向自 Samsung Health Monitor 1.5.1.022 (Wear OS) 与 1.5.2.002
 * (Phone)。
 */
object HealthMonitorProtocol {
    const val PACKAGE = "com.samsung.android.shealthmonitor"
    const val SIGNATURE = "9741a0f330dc2e8619b76a2597f308c37dbe30a2"
    const val PLAIN_CONNECTION = "/plain_connection"

    /** 手表端 CapabilityClient 监听的能力标识 */
    val CAPABILITIES =
        listOf("capability_ecg", "capability_bp", "capability_ihrn", "capability_sleep")

    fun capabilityPath(capability: String): String = "capabilities/$PACKAGE/$SIGNATURE/$capability"

    enum class Channel(val path: String) {
        BP("/991"),
        ECG("/992"),
        IHRN("/993"),
        APNEA("/994");

        val controlPath: String
            get() = path + "c"

        val dataPath: String
            get() = path + "d"

        val module: String
            get() = if (this == APNEA) "sleep" else name.lowercase(Locale.ROOT)

        companion object {
            fun fromPath(path: String): Channel? =
                entries.firstOrNull {
                    path == it.path || path == it.controlPath || path == it.dataPath
                }
        }
    }

    data class Message(
        val message: String,
        val sequence: Int,
        val type: String,
        val action: String,
        val data: JSONObject,
        val dataArray: JSONArray?,
        val result: String,
        val body: JSONObject,
    )

    fun request(
        channel: Channel,
        action: String,
        sequence: Int,
        data: JSONObject = JSONObject(),
        endpoint: String = "common",
    ): JSONObject =
        envelope(
            message = "REQUEST",
            sender = "com.samsung.mobile.app.health.samd.${channel.module}.$endpoint",
            receiver = "com.samsung.wearable.app.health.samd.${channel.module}.$endpoint",
            sequence = sequence,
            type = "MESSAGE",
            body =
                JSONObject()
                    .put("type", "request")
                    .put("action", action)
                    .put("data", data)
                    .put("result", ""),
        )

    /** 回应手表的 SYNC_DATA 或 REQUEST */
    fun response(
        channel: Channel,
        action: String,
        sequence: Int,
        result: String = "SUCCESS",
        endpoint: String = "syncmanager",
    ): JSONObject =
        envelope(
            message = "RESPONSE",
            sender = "com.samsung.mobile.app.health.samd.${channel.module}.$endpoint",
            receiver = "com.samsung.wearable.app.health.samd.${channel.module}.$endpoint",
            sequence = sequence,
            type = "RESPONSE",
            body =
                JSONObject()
                    .put("type", "response")
                    .put("action", action)
                    .put("data", JSONObject())
                    .put("result", result),
        )

    /** Wear OS asks its sync client to resend retained unsynced records with this DATA request. */
    fun syncRequest(channel: Channel, sequence: Int): JSONObject =
        envelope(
            "REQUEST",
            "com.samsung.mobile.app.health.samd.${channel.module}.syncmanager",
            "com.samsung.wearable.app.health.samd.${channel.module}.syncmanager",
            sequence,
            "DATA",
            JSONObject()
                .put(
                    "message_info",
                    JSONObject()
                        .put("action", "SYNC_DATA")
                        .put("type", "REQUEST")
                        .put("id", sequence)
                        .put("result", ""),
                )
                .put("device_info", JSONObject().put("is_last_chunk", true))
                .put("data", JSONArray()),
        )

    /** Uppercase sync result and message_info.id are required by the watch request tracker. */
    fun syncResponse(channel: Channel, id: Int, success: Boolean): JSONObject =
        envelope(
            "RESPONSE",
            "com.samsung.mobile.app.health.samd.${channel.module}.syncmanager",
            "com.samsung.wearable.app.health.samd.${channel.module}.syncmanager",
            id,
            "DATA",
            JSONObject()
                .put(
                    "message_info",
                    JSONObject()
                        .put("action", "SYNC_DATA")
                        .put("type", "RESPONSE")
                        .put("id", id)
                        .put("result", if (success) "SUCCESS" else "FAIL"),
                )
                .put("device_info", JSONObject().put("is_last_chunk", true))
                .put("data", JSONArray()),
        )

    fun informationResponse(channel: Channel, sequence: Int): JSONObject =
        envelope(
            "RESPONSE",
            "com.samsung.mobile.app.health.samd.${channel.module}.common",
            "com.samsung.wearable.app.health.samd.${channel.module}.common",
            sequence,
            "MESSAGE",
            JSONObject()
                .put("type", "response")
                .put("action", "information")
                .put("data", JSONObject().put("reset", false))
                .put("result", "success"),
        )

    /** ECG Onboarding: 写入手腕位置，激活手表端 ECG 测量界面 */
    fun ecgOnboarding(sequence: Int, wristPosition: String = "left"): JSONObject =
        request(
            channel = Channel.ECG,
            action = "onboarding",
            sequence = sequence,
            data = JSONObject().put("wrist_position", wristPosition),
        )

    /** 同意条款 (Terms & Condition) */
    fun termsAndCondition(channel: Channel, sequence: Int): JSONObject =
        request(
            channel = channel,
            action = "terms_and_condition",
            sequence = sequence,
            data = JSONObject().put("status", "complete"),
        )

    /** 血压校准准备阶段：通知手表打开 BpCalibrationActivity 并展示准备指引 */
    fun prepareCalibration(sequence: Int): JSONObject =
        request(
            channel = Channel.BP,
            action = "prepare_calibration",
            sequence = sequence,
            endpoint = "measuring",
        )

    /** 血压校准测量阶段：通知手表启动 30 秒光学 PPG 采样 */
    fun startCalibration(sequence: Int): JSONObject =
        request(
            channel = Channel.BP,
            action = "start_calibration",
            sequence = sequence,
            endpoint = "measuring",
        )

    /** 血压校准数据更新：向手表提交本轮袖带收缩压与舒张压及采样特征标识 */
    fun updateCalibration(
        sequence: Int,
        refSystolic: Int,
        refDiastolic: Int,
        nth: Int,
        datauuid: String? = null,
    ): JSONObject =
        request(
            channel = Channel.BP,
            action = "update_calibration",
            sequence = sequence,
            data =
                JSONObject()
                    .put("ref_systolic", refSystolic)
                    .put("ref_diastolic", refDiastolic)
                    .put("nth", nth)
                    .apply {
                        if (!datauuid.isNullOrBlank()) {
                            put("datauuid", datauuid)
                        }
                    },
            endpoint = "measuring",
        )

    /** 血压校准完成阶段：通知手表 native 算法合并 3 轮校准特征并保存生效 */
    fun initialCalibration(sequence: Int, isRecalibration: Boolean = false): JSONObject =
        request(
            channel = Channel.BP,
            action = if (isRecalibration) "re_calibration" else "initial_calibration",
            sequence = sequence,
            data = JSONObject().put("status", "complete"),
            endpoint = "measuring",
        )

    /** 取消当前血压校准流程 */
    fun cancelCalibration(sequence: Int, nextAction: String = ""): JSONObject =
        request(
            channel = Channel.BP,
            action = "cancel_calibration",
            sequence = sequence,
            data =
                JSONObject().apply {
                    if (nextAction.isNotBlank()) {
                        put("next_action", nextAction)
                    }
                },
            endpoint = "measuring",
        )

    fun envelope(
        message: String,
        sender: String,
        receiver: String,
        sequence: Int,
        type: String,
        body: JSONObject,
    ): JSONObject {
        val compressed =
            ByteArrayOutputStream()
                .also { output ->
                    GZIPOutputStream(output).use {
                        it.write(body.toString().toByteArray(Charsets.UTF_8))
                    }
                }
                .toByteArray()
        return JSONObject()
            .put("message", message)
            .put("sender", sender)
            .put("receiver", receiver)
            .put("version", 0.1)
            .put("sequence_num", sequence)
            .put("type", type)
            .put("body", Base64.getEncoder().encodeToString(compressed))
    }

    fun decode(packet: JSONObject): Message {
        val body = JSONObject(HealthJson.inflateJson(packet.getString("body"), 8 * 1024 * 1024))
        return Message(
            message = packet.optString("message"),
            sequence = packet.optInt("sequence_num"),
            type = packet.optString("type"),
            action =
                body.optJSONObject("message_info")?.optString("action") ?: body.optString("action"),
            data = body.optJSONObject("data") ?: JSONObject(),
            dataArray = body.optJSONArray("data"),
            result =
                body.optJSONObject("message_info")?.optString("result") ?: body.optString("result"),
            body = body,
        )
    }
}
