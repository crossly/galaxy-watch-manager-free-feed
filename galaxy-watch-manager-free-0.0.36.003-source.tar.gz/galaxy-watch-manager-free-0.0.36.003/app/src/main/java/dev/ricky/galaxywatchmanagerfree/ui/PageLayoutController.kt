package dev.ricky.galaxywatchmanagerfree.ui

import android.content.Context
import dev.ricky.galaxywatchmanagerfree.feature.BlockPlacement
import dev.ricky.galaxywatchmanagerfree.feature.LayoutPage
import dev.ricky.galaxywatchmanagerfree.feature.PageBlock
import dev.ricky.galaxywatchmanagerfree.feature.PageLayout
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

object PageLayoutController {
    private var prefs: android.content.SharedPreferences? = null
    private val mutable = MutableStateFlow(LayoutPage.entries.associateWith(PageLayout::defaults))
    val layouts = mutable.asStateFlow()

    @Synchronized
    fun init(context: Context) {
        if (prefs != null) return
        prefs = context.applicationContext.getSharedPreferences("page_layout", Context.MODE_PRIVATE)
        mutable.value =
            LayoutPage.entries.associateWith {
                PageLayout.decode(prefs?.getString(it.name, null), it)
            }
    }

    @Synchronized
    fun change(
        page: LayoutPage,
        block: PageBlock,
        visible: Boolean? = null,
        wide: Boolean? = null,
        move: Int = 0,
    ) {
        val items =
            PageLayout.move(mutable.value.getValue(page), block, move).map {
                if (it.block == block)
                    it.copy(
                        visible = visible ?: it.visible,
                        wide = if (block.compact) wide ?: it.wide else true,
                    )
                else it
            }
        save(page, items)
    }

    @Synchronized
    fun reorder(page: LayoutPage, source: PageBlock, target: PageBlock) {
        val items = mutable.value.getValue(page)
        val from = items.indexOfFirst { it.block == source }
        val to = items.indexOfFirst { it.block == target }
        if (from < 0 || to < 0 || from == to) return
        save(page, PageLayout.move(items, source, to - from))
    }

    @Synchronized
    fun show(page: LayoutPage, block: PageBlock) {
        val items = mutable.value.getValue(page)
        val item = items.firstOrNull { it.block == block } ?: return
        save(page, items.filterNot { it.block == block } + item.copy(visible = true))
    }

    @Synchronized fun reset(page: LayoutPage) = save(page, PageLayout.defaults(page))

    private fun save(page: LayoutPage, items: List<BlockPlacement>) {
        prefs?.edit()?.putString(page.name, PageLayout.encode(items))?.apply()
        mutable.value = mutable.value + (page to items)
    }
}
