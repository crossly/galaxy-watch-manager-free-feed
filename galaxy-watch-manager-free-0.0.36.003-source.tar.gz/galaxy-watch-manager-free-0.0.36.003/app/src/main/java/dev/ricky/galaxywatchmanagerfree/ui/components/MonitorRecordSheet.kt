package dev.ricky.galaxywatchmanagerfree.ui.components

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextTertiary
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/** Shared navigation and fixed toolbar for locally saved ECG/BP records. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MonitorRecordSheet(
    title: String,
    onDismiss: () -> Unit,
    onBack: (() -> Unit)?,
    onSync: () -> Unit,
    canSync: Boolean,
    syncDescription: String,
    content: @Composable ColumnScope.() -> Unit,
) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources

    AppBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
    ) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (onBack != null) {
                    FilledTonalIconButton(onClick = onBack) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            strings.getString(R.string.back_to_records),
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                }
                Box(Modifier.weight(1f)) {
                    SheetToolbar(
                        title = title,
                        onDismiss = onDismiss,
                        actions = {
                            if (onBack == null) {
                                FilledTonalIconButton(onClick = onSync, enabled = canSync) {
                                    Icon(
                                        Icons.Default.Refresh,
                                        syncDescription,
                                        tint = TextTertiary,
                                    )
                                }
                            }
                        },
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            content()
        }
    }
}

fun formatMonitorRecordTime(millis: Long): String =
    DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
        .withZone(ZoneId.systemDefault())
        .format(Instant.ofEpochMilli(millis))
