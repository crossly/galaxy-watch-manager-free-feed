package dev.ricky.galaxywatchmanagerfree.ui.screens

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.feature.SleepParser
import dev.ricky.galaxywatchmanagerfree.feature.SleepScore
import dev.ricky.galaxywatchmanagerfree.feature.WatchState
import dev.ricky.galaxywatchmanagerfree.ui.components.AppBottomSheet
import dev.ricky.galaxywatchmanagerfree.ui.components.DetailDayChip
import dev.ricky.galaxywatchmanagerfree.ui.components.GroupedCard
import dev.ricky.galaxywatchmanagerfree.ui.components.GroupedDivider
import dev.ricky.galaxywatchmanagerfree.ui.components.SegmentedTabs
import dev.ricky.galaxywatchmanagerfree.ui.components.SleepHypnogram
import dev.ricky.galaxywatchmanagerfree.ui.components.SleepScoreRing
import dev.ricky.galaxywatchmanagerfree.ui.components.SleepStageBar
import dev.ricky.galaxywatchmanagerfree.ui.components.SleepStageLegend
import dev.ricky.galaxywatchmanagerfree.ui.components.SleepWeekBars
import dev.ricky.galaxywatchmanagerfree.ui.components.formatClock
import dev.ricky.galaxywatchmanagerfree.ui.components.sleepDurationText
import dev.ricky.galaxywatchmanagerfree.ui.theme.CardBorder
import dev.ricky.galaxywatchmanagerfree.ui.theme.HealthSleep
import dev.ricky.galaxywatchmanagerfree.ui.theme.SleepAwake
import dev.ricky.galaxywatchmanagerfree.ui.theme.SleepDeep
import dev.ricky.galaxywatchmanagerfree.ui.theme.SleepLight
import dev.ricky.galaxywatchmanagerfree.ui.theme.SleepRem
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextPrimary
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextSecondary
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextTertiary
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import kotlin.math.roundToInt

enum class SleepViewTab(val titleRes: Int) {
    LAST_NIGHT(R.string.last_night_s_sleep),
    WEEK_TREND(R.string.past_7_days_3),
}

/** 睡眠监测详情面板 包含：睡眠时长与评分、四阶段分期比例与时序图 (Hypnogram)、近 7 天趋势。 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SleepDetailSheet(
    state: WatchState,
    onDismiss: () -> Unit,
    onAddNap: ((Long, Long) -> Boolean)? = null,
    onDeleteNap: ((Long, Long) -> Boolean)? = null,
) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var selectedTab by remember { mutableStateOf(SleepViewTab.LAST_NIGHT) }
    var showAddNap by remember { mutableStateOf(false) }
    var pendingDelete by remember { mutableStateOf<SleepParser.Session?>(null) }
    val daysMap =
        state.sleepDays.ifEmpty {
            val all =
                state.allSleepSessions.ifEmpty {
                    state.sleepSessions.ifEmpty { listOfNotNull(state.sleep) }
                }
            if (all.isNotEmpty())
                all.groupBy { SleepParser.nightKey(it) }
                    .mapValues { (_, s) -> s.sortedBy { it.startMillis } }
            else emptyMap()
        }
    val availableDays = daysMap.keys.sortedDescending()
    var selectedDayIso by rememberSaveable { mutableStateOf<String?>(null) }
    val selectedDay = selectedDayIso?.takeIf { it in daysMap } ?: availableDays.firstOrNull()
    val sessions =
        (selectedDay?.let { daysMap[it] } ?: state.sleepSessions).ifEmpty {
            listOfNotNull(state.sleep)
        }
    val sleep = sessions.maxByOrNull { it.displayMinutes } ?: state.sleep
    val totalAsleepMinutes = sessions.sumOf { it.displayMinutes }
    val stagedSessionCount = sessions.count { it.segments.isNotEmpty() }
    val unstagedSessionCount = sessions.size - stagedSessionCount

    AppBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        LazyColumn(
            modifier =
                Modifier.fillMaxWidth()
                    .testTag("sleep_detail_list")
                    .padding(horizontal = 20.dp)
                    .padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item {
                dev.ricky.galaxywatchmanagerfree.ui.components.SheetToolbar(
                    strings.getString(R.string.sleep),
                    onDismiss,
                )
            }
            if (availableDays.size > 1) {
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(availableDays, key = { it }) { day ->
                            DetailDayChip(
                                day = day,
                                selected = day == selectedDay,
                                accent = HealthSleep,
                                onClick = { selectedDayIso = day },
                            )
                        }
                    }
                }
            }

            if (sleep == null) {
                item {
                    GroupedCard {
                        Box(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 32.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Default.Bedtime,
                                    contentDescription = null,
                                    tint = TextTertiary,
                                    modifier = Modifier.size(36.dp),
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text =
                                        strings.getString(R.string.no_sleep_record_for_last_night),
                                    style =
                                        androidx.compose.material3.MaterialTheme.typography
                                            .bodyMedium,
                                    fontWeight = FontWeight.Medium,
                                    color = TextSecondary,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = strings.getString(R.string.sleep_empty_guidance),
                                    style =
                                        androidx.compose.material3.MaterialTheme.typography
                                            .labelMedium,
                                    color = TextTertiary,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                )
                            }
                        }
                    }
                }
            } else {
                // 昨夜核心卡片
                item {
                    GroupedCard(innerPadding = 16.dp) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Bottom,
                        ) {
                            Column {
                                Text(
                                    if (
                                        selectedDay != null &&
                                            selectedDay != availableDays.firstOrNull()
                                    )
                                        "$selectedDay · " +
                                            (if (sleep.hasSleepDuration)
                                                strings.getString(R.string.time_asleep)
                                            else
                                                strings.getString(R.string.recorded_sleep_interval))
                                    else if (sleep.hasSleepDuration)
                                        strings.getString(R.string.time_asleep)
                                    else strings.getString(R.string.recorded_sleep_interval),
                                    style =
                                        androidx.compose.material3.MaterialTheme.typography
                                            .bodySmall,
                                    color = TextTertiary,
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text =
                                        sleepDurationText(
                                            if (sessions.size > 1) totalAsleepMinutes
                                            else sleep.displayMinutes,
                                            strings,
                                        ),
                                    style =
                                        androidx.compose.material3.MaterialTheme.typography
                                            .headlineMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary,
                                    fontFamily = FontFamily.Monospace,
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            dev.ricky.galaxywatchmanagerfree.ui.components.formatRecordTime(
                                sleep.startMillis
                            ) +
                                " – " +
                                dev.ricky.galaxywatchmanagerfree.ui.components.formatRecordTime(
                                    sleep.endMillis
                                ),
                            style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider(color = CardBorder.copy(alpha = 0.6f), thickness = 0.5.dp)
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceAround,
                        ) {
                            Column(
                                Modifier.weight(1f),
                                horizontalAlignment = Alignment.CenterHorizontally,
                            ) {
                                Text(
                                    strings.getString(R.string.fell_asleep),
                                    style =
                                        androidx.compose.material3.MaterialTheme.typography
                                            .labelSmall,
                                    color = TextTertiary,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    formatClock(sleep.startMillis),
                                    style =
                                        androidx.compose.material3.MaterialTheme.typography
                                            .bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary,
                                    fontFamily = FontFamily.Monospace,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                )
                            }
                            Column(
                                Modifier.weight(1f),
                                horizontalAlignment = Alignment.CenterHorizontally,
                            ) {
                                Text(
                                    strings.getString(R.string.woke_up),
                                    style =
                                        androidx.compose.material3.MaterialTheme.typography
                                            .labelSmall,
                                    color = TextTertiary,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    formatClock(sleep.endMillis),
                                    style =
                                        androidx.compose.material3.MaterialTheme.typography
                                            .bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary,
                                    fontFamily = FontFamily.Monospace,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                )
                            }
                            Column(
                                Modifier.weight(1f),
                                horizontalAlignment = Alignment.CenterHorizontally,
                            ) {
                                Text(
                                    strings.getString(R.string.sleep_efficiency),
                                    style =
                                        androidx.compose.material3.MaterialTheme.typography
                                            .labelSmall,
                                    color = TextTertiary,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text =
                                        sleep.efficiencyPercent?.let { "$it%" }
                                            ?: strings.getString(R.string.awaiting_analysis),
                                    style =
                                        androidx.compose.material3.MaterialTheme.typography
                                            .bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary,
                                    fontFamily = FontFamily.Monospace,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                )
                            }
                        }
                        if (sleep.analysisSource != null) {
                            Spacer(Modifier.height(12.dp))
                            Text(
                                strings.getString(R.string.sleep_local_analysis_explanation),
                                style =
                                    androidx.compose.material3.MaterialTheme.typography.bodySmall,
                                lineHeight = 18.sp,
                                color = TextSecondary,
                            )
                            sleep.recordedEndMillis
                                ?.takeIf { it != sleep.endMillis }
                                ?.let { recordedEnd ->
                                    Text(
                                        strings.getString(
                                            R.string.original_wake_time_stage_analysis_ends_at,
                                            formatClock(recordedEnd),
                                            formatClock(sleep.endMillis),
                                        ),
                                        style =
                                            androidx.compose.material3.MaterialTheme.typography
                                                .bodySmall,
                                        lineHeight = 18.sp,
                                        color = TextSecondary,
                                    )
                                }
                        } else if (!sleep.hasSleepDuration) {
                            Spacer(Modifier.height(12.dp))
                            Text(
                                if (state.sleepAnalysisRunning)
                                    strings.getString(R.string.sleep_analysis_pending)
                                else strings.getString(R.string.sleep_interval_explanation),
                                style =
                                    androidx.compose.material3.MaterialTheme.typography.bodySmall,
                                lineHeight = 18.sp,
                                color = TextSecondary,
                            )
                        }
                    }
                }

                // 睡眠评分卡片：手表评分优先；只有本机分析分期时展示因子分解
                item { SleepScoreCard(sleep, strings) }

                // 当天多段睡眠（夜间 + 午休）：分别展示起止与时长，总计已在顶部卡片。
                if (sessions.size > 1) {
                    item {
                        GroupedCard(innerPadding = 16.dp) {
                            Text(
                                strings.getString(R.string.sleep_day_sessions_title),
                                style =
                                    androidx.compose.material3.MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            sessions.forEachIndexed { index, session ->
                                if (index > 0) {
                                    Spacer(modifier = Modifier.height(10.dp))
                                    HorizontalDivider(
                                        color = CardBorder.copy(alpha = 0.6f),
                                        thickness = 0.5.dp,
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            strings.getString(
                                                when {
                                                    session.analysisSource == "manual" ->
                                                        R.string.sleep_manual_session
                                                    session == sleep -> R.string.sleep_main_session
                                                    else -> R.string.sleep_nap_session
                                                }
                                            ),
                                            style =
                                                androidx.compose.material3.MaterialTheme.typography
                                                    .bodySmall,
                                            fontWeight = FontWeight.SemiBold,
                                            color = TextPrimary,
                                        )
                                        Text(
                                            dev.ricky.galaxywatchmanagerfree.ui.components
                                                .formatRecordTime(session.startMillis) +
                                                " – " +
                                                dev.ricky.galaxywatchmanagerfree.ui.components
                                                    .formatRecordTime(session.endMillis),
                                            style =
                                                androidx.compose.material3.MaterialTheme.typography
                                                    .labelSmall,
                                            color = TextTertiary,
                                        )
                                    }
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            sleepDurationText(session.displayMinutes, strings),
                                            style =
                                                androidx.compose.material3.MaterialTheme.typography
                                                    .bodyMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = TextPrimary,
                                            fontFamily = FontFamily.Monospace,
                                        )
                                        if (
                                            session.analysisSource == "manual" &&
                                                onDeleteNap != null
                                        ) {
                                            IconButton(
                                                onClick = { pendingDelete = session },
                                                modifier =
                                                    Modifier.testTag(
                                                        "tag_delete_nap_${session.startMillis}"
                                                    ),
                                            ) {
                                                Icon(
                                                    Icons.Default.Delete,
                                                    contentDescription =
                                                        strings.getString(
                                                            R.string.sleep_nap_delete
                                                        ),
                                                    tint = TextTertiary,
                                                    modifier = Modifier.size(18.dp),
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // 分段选择器
                item {
                    SegmentedTabs(
                        items = SleepViewTab.entries,
                        selectedItem = selectedTab,
                        onItemSelected = { selectedTab = it },
                        labelOf = { strings.getString(it.titleRes) },
                    )
                }

                when (selectedTab) {
                    SleepViewTab.LAST_NIGHT -> {
                        // 分期比例条
                        if (stagedSessionCount > 0) {
                            item {
                                GroupedCard(innerPadding = 16.dp) {
                                    Text(
                                        strings.getString(R.string.sleep_stage_breakdown),
                                        style =
                                            androidx.compose.material3.MaterialTheme.typography
                                                .bodyMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary,
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))
                                    SleepStageBar(sessions = sessions)
                                    Spacer(modifier = Modifier.height(14.dp))
                                    SleepStageLegend(sessions = sessions)
                                }
                            }

                            // 睡眠时序图 (Hypnogram)
                            item {
                                GroupedCard(innerPadding = 16.dp) {
                                    Text(
                                        strings.getString(R.string.sleep_stage_timeline),
                                        style =
                                            androidx.compose.material3.MaterialTheme.typography
                                                .bodyLarge,
                                        fontWeight = FontWeight.SemiBold,
                                        color = TextPrimary,
                                    )
                                    if (stagedSessionCount > 1) {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            strings.getString(
                                                R.string.sleep_stage_timeline_combined_hint,
                                                stagedSessionCount,
                                            ),
                                            style =
                                                androidx.compose.material3.MaterialTheme.typography
                                                    .bodySmall,
                                            color = TextSecondary,
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(12.dp))
                                    SleepHypnogram(sessions = sessions)
                                    if (unstagedSessionCount > 0) {
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(
                                            strings.getString(
                                                R.string.sleep_stage_timeline_unstaged_hint
                                            ),
                                            style =
                                                androidx.compose.material3.MaterialTheme.typography
                                                    .labelSmall,
                                            color = TextTertiary,
                                        )
                                    }
                                }
                            }
                        } else {
                            item {
                                GroupedCard {
                                    Text(
                                        strings.getString(R.string.sleep_stages),
                                        style =
                                            androidx.compose.material3.MaterialTheme.typography
                                                .bodyLarge,
                                        fontWeight = FontWeight.SemiBold,
                                        color = TextPrimary,
                                    )
                                    Spacer(Modifier.height(12.dp))
                                    Text(
                                        if (state.sleepAnalysisRunning)
                                            strings.getString(
                                                R.string.analyzing_deep_light_rem_and_awake_stages
                                            )
                                        else strings.getString(R.string.sleep_stages_empty),
                                        style =
                                            androidx.compose.material3.MaterialTheme.typography
                                                .bodyMedium,
                                        lineHeight = 21.sp,
                                        color = TextSecondary,
                                    )
                                }
                            }
                        }
                        if (onAddNap != null) {
                            item { AddNapCard(strings, onClick = { showAddNap = true }) }
                        }
                    }
                    SleepViewTab.WEEK_TREND -> {
                        item {
                            GroupedCard(innerPadding = 16.dp) {
                                Text(
                                    strings.getString(R.string.sleep_duration_over_7_days),
                                    style =
                                        androidx.compose.material3.MaterialTheme.typography
                                            .bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary,
                                )
                                Spacer(modifier = Modifier.height(14.dp))
                                SleepWeekBars(minutes = state.weekSleep)
                                Spacer(modifier = Modifier.height(14.dp))
                                GroupedDivider(startIndent = 0.dp)
                                Spacer(modifier = Modifier.height(10.dp))

                                val valid = state.weekSleep.filter { it > 0 }
                                val avg = if (valid.isNotEmpty()) valid.sum() / valid.size else 0
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceAround,
                                ) {
                                    Column(
                                        Modifier.weight(1f),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                    ) {
                                        Text(
                                            strings.getString(R.string.label_7_day_daily_average),
                                            style =
                                                androidx.compose.material3.MaterialTheme.typography
                                                    .labelMedium,
                                            color = TextTertiary,
                                            textAlign =
                                                androidx.compose.ui.text.style.TextAlign.Center,
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text =
                                                if (avg > 0) sleepDurationText(avg, strings)
                                                else "—",
                                            style =
                                                androidx.compose.material3.MaterialTheme.typography
                                                    .bodyMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = TextPrimary,
                                            fontFamily = FontFamily.Monospace,
                                            textAlign =
                                                androidx.compose.ui.text.style.TextAlign.Center,
                                        )
                                    }
                                    Column(
                                        Modifier.weight(1f),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                    ) {
                                        Text(
                                            strings.getString(R.string.days_recorded),
                                            style =
                                                androidx.compose.material3.MaterialTheme.typography
                                                    .labelMedium,
                                            color = TextTertiary,
                                            textAlign =
                                                androidx.compose.ui.text.style.TextAlign.Center,
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text =
                                                strings.getString(
                                                    R.string.label_7_days,
                                                    valid.size,
                                                ),
                                            style =
                                                androidx.compose.material3.MaterialTheme.typography
                                                    .bodyMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = TextPrimary,
                                            fontFamily = FontFamily.Monospace,
                                            textAlign =
                                                androidx.compose.ui.text.style.TextAlign.Center,
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    if (showAddNap && onAddNap != null) {
        AddNapDialog(
            seedMillis = sleep?.startMillis ?: System.currentTimeMillis(),
            strings = strings,
            onDismiss = { showAddNap = false },
            onSave = onAddNap,
        )
    }
    pendingDelete?.let { target ->
        if (onDeleteNap != null) {
            AlertDialog(
                onDismissRequest = { pendingDelete = null },
                title = { Text(strings.getString(R.string.sleep_nap_delete_title)) },
                text = { Text(strings.getString(R.string.sleep_nap_delete_body)) },
                confirmButton = {
                    TextButton(
                        onClick = {
                            onDeleteNap(target.startMillis, target.endMillis)
                            pendingDelete = null
                        }
                    ) {
                        Text(strings.getString(R.string.sleep_nap_delete))
                    }
                },
                dismissButton = {
                    TextButton(onClick = { pendingDelete = null }) {
                        Text(strings.getString(R.string.sleep_nap_cancel))
                    }
                },
            )
        }
    }
}

@Composable
private fun AddNapCard(strings: android.content.res.Resources, onClick: () -> Unit) {
    GroupedCard(innerPadding = 16.dp) {
        Text(
            strings.getString(R.string.sleep_add_nap_hint),
            style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
            lineHeight = 18.sp,
            color = TextSecondary,
        )
        Spacer(Modifier.height(10.dp))
        OutlinedButton(
            onClick = onClick,
            modifier = Modifier.fillMaxWidth().testTag("tag_add_nap"),
        ) {
            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.size(6.dp))
            Text(strings.getString(R.string.sleep_add_nap))
        }
    }
}

@Composable
private fun AddNapDialog(
    seedMillis: Long,
    strings: android.content.res.Resources,
    onDismiss: () -> Unit,
    onSave: (Long, Long) -> Boolean,
) {
    val context = LocalContext.current
    val zone = ZoneId.systemDefault()
    var date by remember {
        mutableStateOf(Instant.ofEpochMilli(seedMillis).atZone(zone).toLocalDate())
    }
    var startMinutes by remember { mutableIntStateOf(13 * 60) }
    var endMinutes by remember { mutableIntStateOf(14 * 60) }
    var errorRes by remember { mutableStateOf(0) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(strings.getString(R.string.sleep_add_nap_title)) },
        text = {
            Column {
                Text(
                    strings.getString(R.string.sleep_add_nap_hint),
                    style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                    lineHeight = 18.sp,
                    color = TextSecondary,
                )
                Spacer(Modifier.height(8.dp))
                NapField(strings.getString(R.string.sleep_nap_date), date.toString()) {
                    DatePickerDialog(
                            context,
                            { _, year, month, day -> date = LocalDate.of(year, month + 1, day) },
                            date.year,
                            date.monthValue - 1,
                            date.dayOfMonth,
                        )
                        .show()
                }
                NapField(
                    strings.getString(R.string.sleep_nap_start),
                    formatNapMinutes(startMinutes),
                ) {
                    TimePickerDialog(
                            context,
                            { _, hour, minute -> startMinutes = hour * 60 + minute },
                            startMinutes / 60,
                            startMinutes % 60,
                            true,
                        )
                        .show()
                }
                NapField(strings.getString(R.string.sleep_nap_end), formatNapMinutes(endMinutes)) {
                    TimePickerDialog(
                            context,
                            { _, hour, minute -> endMinutes = hour * 60 + minute },
                            endMinutes / 60,
                            endMinutes % 60,
                            true,
                        )
                        .show()
                }
                if (errorRes != 0) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        strings.getString(errorRes),
                        style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                        color = androidx.compose.material3.MaterialTheme.colorScheme.error,
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                modifier = Modifier.testTag("tag_save_nap"),
                onClick = {
                    val start =
                        date
                            .atTime(startMinutes / 60, startMinutes % 60)
                            .atZone(zone)
                            .toInstant()
                            .toEpochMilli()
                    val end =
                        date
                            .atTime(endMinutes / 60, endMinutes % 60)
                            .atZone(zone)
                            .toInstant()
                            .toEpochMilli()
                    val minutes = (end - start) / 60_000L
                    errorRes =
                        when {
                            end <= start -> R.string.sleep_nap_invalid_range
                            minutes < 5 || minutes > 12 * 60 -> R.string.sleep_nap_invalid_duration
                            !onSave(start, end) -> R.string.sleep_nap_overlap
                            else -> 0
                        }
                    if (errorRes == 0) onDismiss()
                },
            ) {
                Text(strings.getString(R.string.sleep_nap_save))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(strings.getString(R.string.sleep_nap_cancel)) }
        },
    )
}

@Composable
private fun NapField(label: String, value: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            label,
            style = androidx.compose.material3.MaterialTheme.typography.bodyMedium,
            color = TextPrimary,
        )
        TextButton(onClick = onClick) { Text(value, fontFamily = FontFamily.Monospace) }
    }
}

private fun formatNapMinutes(minutes: Int): String = "%02d:%02d".format(minutes / 60, minutes % 60)

@Composable
private fun SleepScoreCard(sleep: SleepParser.Session, strings: android.content.res.Resources) {
    val watchScore = sleep.score?.takeIf { it > 0 }
    val computed = sleep.computedScore
    val headline = watchScore ?: computed?.total ?: return
    val computedOnly = watchScore == null

    GroupedCard(innerPadding = 16.dp) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SleepScoreRing(score = headline, ringSize = 96.dp)
            Spacer(modifier = Modifier.width(20.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    strings.getString(
                        R.string.sleep_score,
                        headline,
                        scoreRating(headline, strings),
                    ),
                    style = androidx.compose.material3.MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimary,
                )
                Spacer(modifier = Modifier.height(6.dp))
                if (computedOnly) {
                    Text(
                        strings.getString(R.string.sleep_score_computed_badge),
                        style = androidx.compose.material3.MaterialTheme.typography.labelMedium,
                        color = TextTertiary,
                    )
                } else {
                    Box(
                        modifier =
                            Modifier.clip(RoundedCornerShape(999.dp))
                                .background(HealthSleep.copy(alpha = 0.16f))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            strings.getString(R.string.sleep_score_watch_badge),
                            style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = HealthSleep,
                        )
                    }
                }
            }
        }

        if (computedOnly && computed != null) {
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                strings.getString(R.string.sleep_score_computed_explanation),
                style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                lineHeight = 18.sp,
                color = TextSecondary,
            )
            Spacer(modifier = Modifier.height(14.dp))
            computed.factors.forEachIndexed { index, factor ->
                if (index > 0) Spacer(modifier = Modifier.height(10.dp))
                SleepFactorRow(
                    label = factorLabel(factor.factor, strings),
                    detail = factorDetail(factor.factor, computed, strings),
                    score = factor.score,
                    color = factorColor(factor.factor),
                )
            }
        }
    }
}

@Composable
private fun SleepFactorRow(label: String, detail: String, score: Int, color: Color) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                label,
                style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                color = TextSecondary,
            )
            Text(
                detail,
                style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                color = TextTertiary,
                fontFamily = FontFamily.Monospace,
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier =
                    Modifier.weight(1f)
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(CardBorder.copy(alpha = 0.4f))
            ) {
                Box(
                    modifier =
                        Modifier.fillMaxHeight()
                            .fillMaxWidth((score / 100f).coerceIn(0f, 1f))
                            .clip(RoundedCornerShape(3.dp))
                            .background(color)
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = "$score",
                style = androidx.compose.material3.MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                fontFamily = FontFamily.Monospace,
                textAlign = androidx.compose.ui.text.style.TextAlign.End,
                modifier = Modifier.width(26.dp),
            )
        }
    }
}

private fun factorLabel(factor: SleepScore.Factor, strings: android.content.res.Resources): String =
    when (factor) {
        SleepScore.Factor.TOTAL_SLEEP_TIME ->
            strings.getString(R.string.sleep_factor_total_sleep_time)
        SleepScore.Factor.RESTFULNESS -> strings.getString(R.string.sleep_factor_restfulness)
        SleepScore.Factor.PHYSICAL_RECOVERY ->
            strings.getString(R.string.sleep_factor_physical_recovery)
        SleepScore.Factor.MENTAL_RECOVERY ->
            strings.getString(R.string.sleep_factor_mental_recovery)
        SleepScore.Factor.SLEEP_LATENCY -> strings.getString(R.string.sleep_factor_sleep_latency)
    }

@Composable
private fun factorColor(factor: SleepScore.Factor): Color =
    when (factor) {
        SleepScore.Factor.TOTAL_SLEEP_TIME -> HealthSleep
        SleepScore.Factor.RESTFULNESS -> SleepAwake
        SleepScore.Factor.PHYSICAL_RECOVERY -> SleepDeep
        SleepScore.Factor.MENTAL_RECOVERY -> SleepRem
        SleepScore.Factor.SLEEP_LATENCY -> SleepLight
    }

private fun factorDetail(
    factor: SleepScore.Factor,
    result: SleepScore.Result,
    strings: android.content.res.Resources,
): String =
    when (factor) {
        SleepScore.Factor.TOTAL_SLEEP_TIME -> sleepDurationText(result.totalSleepMinutes, strings)
        SleepScore.Factor.RESTFULNESS -> {
            val afterOnset = result.inBedMinutes - result.latencyMinutes
            val percent =
                if (afterOnset > 0) ((result.awakeMinutes * 100.0) / afterOnset).roundToInt() else 0
            strings.getString(R.string.sleep_factor_awake_percent, percent)
        }
        SleepScore.Factor.PHYSICAL_RECOVERY -> sleepDurationText(result.deepMinutes, strings)
        SleepScore.Factor.MENTAL_RECOVERY -> sleepDurationText(result.remMinutes, strings)
        SleepScore.Factor.SLEEP_LATENCY -> sleepDurationText(result.latencyMinutes, strings)
    }

private fun scoreRating(score: Int, strings: android.content.res.Resources): String =
    when {
        score >= 85 -> strings.getString(R.string.excellent)
        score >= 70 -> strings.getString(R.string.good)
        score >= 60 -> strings.getString(R.string.fair)
        else -> strings.getString(R.string.low)
    }
