package dev.ricky.galaxywatchmanagerfree.core

import android.content.Context
import dev.ricky.galaxywatchmanagerfree.feature.DeviceIdentityStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * First-run connection onboarding visibility.
 *
 * It is shown once when no verified identity exists yet; existing installations (and users who
 * already completed the guide) go straight to the app. The guide can always be reopened from the
 * device connection page, and completion is remembered independently of connection success.
 */
object OnboardingController {
    private const val PREFS = "watchfree_onboarding"
    private const val KEY_DONE = "done"

    private val _visible = MutableStateFlow(false)
    val visible: StateFlow<Boolean> = _visible.asStateFlow()

    /** Auto-connect must not race the guide while it is on screen. */
    val isVisible: Boolean
        get() = _visible.value

    @Volatile private var initialized = false

    fun initialize(context: Context) {
        if (initialized) return
        initialized = true
        val app = context.applicationContext
        if (prefs(app).getBoolean(KEY_DONE, false)) {
            _visible.value = false
            return
        }
        // Upgrade path: a device with an already verified identity never needs the first-run flow.
        val mac = WatchController.savedMac.orEmpty()
        val hasIdentity =
            mac.isNotBlank() && DeviceIdentityStore(app, mac).confirmedPhoneNode.isNotBlank()
        if (hasIdentity) {
            prefs(app).edit().putBoolean(KEY_DONE, true).apply()
            _visible.value = false
        } else {
            _visible.value = true
        }
    }

    /** Reopen the full-screen guide without changing the completed flag. */
    fun open() {
        _visible.value = true
    }

    /** Close without marking completion (session-only skip). */
    fun close() {
        _visible.value = false
    }

    /** Mark the guide as seen/completed and close it. */
    fun finish(context: Context) {
        prefs(context).edit().putBoolean(KEY_DONE, true).apply()
        _visible.value = false
    }

    fun reset(context: Context) {
        prefs(context).edit().putBoolean(KEY_DONE, false).apply()
    }

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
