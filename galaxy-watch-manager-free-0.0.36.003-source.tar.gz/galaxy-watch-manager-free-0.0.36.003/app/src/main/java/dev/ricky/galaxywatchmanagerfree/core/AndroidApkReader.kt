package dev.ricky.galaxywatchmanagerfree.core

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import dev.ricky.galaxywatchmanagerfree.R

/** Android boundary: a read failure throws instead of manufacturing an unsigned identity. */
object AndroidApkReader {
    @Suppress("DEPRECATION")
    fun read(context: Context, apkPath: String? = null): ApkValidation.PackageIdentity {
        val pm = context.packageManager
        val flags =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                PackageManager.GET_SIGNING_CERTIFICATES
            } else PackageManager.GET_SIGNATURES
        val info =
            if (apkPath == null) pm.getPackageInfo(context.packageName, flags)
            else
                pm.getPackageArchiveInfo(apkPath, flags)
                    ?: throw UserFacingException(uiText(R.string.apk_unreadable))
        val signers =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                info.signingInfo?.apkContentsSigners.orEmpty()
            } else info.signatures.orEmpty()
        val version =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) info.longVersionCode
            else info.versionCode.toLong()
        return ApkValidation.PackageIdentity(
            info.packageName,
            version,
            signers.map { ApkIntegrity.sha256(it.toByteArray()) }.toSet(),
        )
    }
}
