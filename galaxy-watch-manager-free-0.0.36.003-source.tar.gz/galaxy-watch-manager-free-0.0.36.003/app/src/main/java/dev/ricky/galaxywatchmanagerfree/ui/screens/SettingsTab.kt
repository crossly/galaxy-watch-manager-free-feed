package dev.ricky.galaxywatchmanagerfree.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.feature.SettingItem
import dev.ricky.galaxywatchmanagerfree.feature.SettingLabels
import dev.ricky.galaxywatchmanagerfree.feature.WatchRepository
import dev.ricky.galaxywatchmanagerfree.feature.WatchState
import dev.ricky.galaxywatchmanagerfree.ui.components.GroupedCard
import dev.ricky.galaxywatchmanagerfree.ui.components.SettingChoiceRow
import dev.ricky.galaxywatchmanagerfree.ui.components.SettingSectionCard
import dev.ricky.galaxywatchmanagerfree.ui.components.SettingSliderRow
import dev.ricky.galaxywatchmanagerfree.ui.components.SettingSwitchRow
import dev.ricky.galaxywatchmanagerfree.ui.screens.connection.DeviceConnectionScreen
import dev.ricky.galaxywatchmanagerfree.ui.theme.CardBorder
import dev.ricky.galaxywatchmanagerfree.ui.theme.CardSurface
import dev.ricky.galaxywatchmanagerfree.ui.theme.ElectricBlue
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextPrimary
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextSecondary
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextTertiary

enum class SettingCategory(@androidx.annotation.StringRes val titleRes: Int) {
    /** 旧版「常用」合并页：只用于恢复历史保存路由，新导航不再提供入口。 */
    FEATURED(R.string.common),
    DISPLAY(R.string.display),
    SOUND(R.string.sound),
    BATTERY(R.string.battery),
    BUTTONS(R.string.buttons_and_gestures),
    ACCESSIBILITY(R.string.accessibility),
    DEVICE(R.string.device_connection),
    RAW(R.string.all_settings),
}

/** 设置中心 分类设置、手势按键、显示声音、设备连接配对、底层 DataItem 调试与应用内更新。 */
@Composable
fun SettingsCategoryContent(
    state: WatchState,
    repo: WatchRepository,
    selectedCategory: SettingCategory,
    modifier: Modifier = Modifier,
) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources

    val locale = androidx.compose.ui.platform.LocalConfiguration.current.locales[0]
    val labels = remember(locale) { SettingLabels(locale) { strings.getString(it) } }
    var searchQuery by remember { mutableStateOf("") }

    val rawItems = remember(state.settingItems) { state.settingItems.values.toList() }
    val filteredRaw =
        remember(rawItems, searchQuery, labels) {
            rawItems
                .filter { item ->
                    val label = labels.describe(item.path)
                    searchQuery.isBlank() ||
                        label.title.contains(searchQuery, ignoreCase = true) ||
                        label.category.contains(searchQuery, ignoreCase = true) ||
                        item.path.contains(searchQuery, ignoreCase = true) ||
                        item.key.contains(searchQuery, ignoreCase = true) ||
                        item.value.toString().contains(searchQuery, ignoreCase = true)
                }
                .sortedWith(
                    compareBy(
                        { labels.describe(it.path).category },
                        { labels.describe(it.path).title },
                    )
                )
        }

    LazyColumn(
        modifier = modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item { Spacer(modifier = Modifier.height(2.dp)) }

        // Settings are opened from the root list as individual pages.

        // 2. 根据选中的分类渲染内容
        when (selectedCategory) {
            SettingCategory.FEATURED -> {
                item { DisplaySettingsCard(state, repo) }
                item { BatterySettingsCard(state, repo) }
                item { SoundSettingsCard(state, repo) }
                item { ButtonsSettingsCard(state, repo) }
                item { AccessibilitySettingsCard(state, repo) }
            }
            SettingCategory.DISPLAY -> {
                item { DisplaySettingsCard(state, repo) }
            }
            SettingCategory.BATTERY -> {
                item { BatterySettingsCard(state, repo) }
            }
            SettingCategory.SOUND -> {
                item { SoundSettingsCard(state, repo) }
            }
            SettingCategory.BUTTONS -> {
                item { ButtonsSettingsCard(state, repo) }
            }
            SettingCategory.ACCESSIBILITY -> {
                item { AccessibilitySettingsCard(state, repo) }
            }
            SettingCategory.DEVICE -> {
                // Device connection, onboarding guide, identity acquisition and diagnostics
                item { DeviceConnectionScreen(state, repo) }
            }

            SettingCategory.RAW -> {
                // 搜索栏
                item {
                    Box(
                        modifier =
                            Modifier.fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(CardSurface)
                                .border(1.dp, CardBorder, RoundedCornerShape(14.dp))
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = null,
                                tint = TextTertiary,
                                modifier = Modifier.size(18.dp),
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            androidx.compose.foundation.text.BasicTextField(
                                value = searchQuery,
                                onValueChange = { searchQuery = it },
                                textStyle =
                                    androidx.compose.ui.text.TextStyle(
                                        fontSize = 13.sp,
                                        color = TextPrimary,
                                    ),
                                decorationBox = { innerTextField ->
                                    if (searchQuery.isEmpty()) {
                                        Text(
                                            strings.getString(
                                                R.string
                                                    .search_settings_categories_or_protocol_fields
                                            ),
                                            style =
                                                androidx.compose.material3.MaterialTheme.typography
                                                    .bodySmall,
                                            color = TextTertiary,
                                        )
                                    }
                                    innerTextField()
                                },
                                modifier = Modifier.weight(1f),
                            )
                            if (searchQuery.isNotEmpty()) {
                                androidx.compose.material3.IconButton(
                                    onClick = { searchQuery = "" }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Clear,
                                        contentDescription = strings.getString(R.string.clear),
                                        tint = TextSecondary,
                                        modifier = Modifier.size(20.dp),
                                    )
                                }
                            }
                        }
                    }
                }

                // 列表
                items(filteredRaw, key = { it.path }) { item ->
                    RawSettingItemCard(item = item, repo = repo, enabled = state.sessionReady)
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

// Category setting cards

@Composable
private fun DisplaySettingsCard(state: WatchState, repo: WatchRepository) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources

    SettingSectionCard(title = strings.getString(R.string.display_and_screen)) {
        SettingSwitchRow(
            title = strings.getString(R.string.always_on_display),
            subtitle = strings.getString(R.string.aod_explanation),
            checked = state.aodEnabled,
            enabled = state.sessionReady,
            onCheckedChange = { repo.setAod(it) },
        )

        HorizontalDivider(color = CardBorder.copy(alpha = 0.5f), thickness = 0.5.dp)

        SettingSwitchRow(
            title = strings.getString(R.string.raise_to_wake),
            subtitle = strings.getString(R.string.wake_the_screen_when_you_raise_your_wrist),
            checked = state.wakeOnWrist,
            enabled = state.sessionReady,
            onCheckedChange = { repo.setWakeOnWrist(it) },
        )

        HorizontalDivider(color = CardBorder.copy(alpha = 0.5f), thickness = 0.5.dp)

        SettingSwitchRow(
            title = strings.getString(R.string.touch_to_wake),
            subtitle = strings.getString(R.string.touch_the_screen_to_wake_it),
            checked = state.wakeOnTouch,
            enabled = state.sessionReady,
            onCheckedChange = { repo.setWakeOnTouch(it) },
        )

        HorizontalDivider(color = CardBorder.copy(alpha = 0.5f), thickness = 0.5.dp)

        SettingSwitchRow(
            title = strings.getString(R.string.rotate_bezel_to_wake),
            subtitle = strings.getString(R.string.bezel_wake_explanation),
            checked = state.wakeOnBezel,
            enabled = state.sessionReady,
            onCheckedChange = { repo.setWakeOnBezel(it) },
        )

        HorizontalDivider(color = CardBorder.copy(alpha = 0.5f), thickness = 0.5.dp)

        SettingSwitchRow(
            title = strings.getString(R.string.outdoor_brightness),
            subtitle = strings.getString(R.string.adjust_screen_brightness_for_outdoor_use),
            checked = state.outdoorMode,
            enabled = state.sessionReady,
            onCheckedChange = { repo.setOutdoorMode(it) },
        )

        HorizontalDivider(color = CardBorder.copy(alpha = 0.5f), thickness = 0.5.dp)

        SettingChoiceRow(
            title = strings.getString(R.string.screen_timeout),
            options =
                listOf(
                    strings.getString(R.string.label_15_seconds),
                    strings.getString(R.string.label_30_seconds),
                    strings.getString(R.string.label_1_minute),
                    strings.getString(R.string.label_5_minutes),
                ),
            selectedIndex = state.screenTimeoutItem,
            enabled = state.sessionReady,
            onSelect = { repo.setScreenTimeout(it) },
        )

        HorizontalDivider(color = CardBorder.copy(alpha = 0.5f), thickness = 0.5.dp)

        SettingSliderRow(
            title = strings.getString(R.string.screen_brightness),
            value = state.brightness.takeIf { it >= 0 },
            range = 0f..100f,
            unit = "%",
            enabled = state.sessionReady,
            onValueChange = { repo.setBrightness(it) },
        )
    }
}

@Composable
private fun BatterySettingsCard(state: WatchState, repo: WatchRepository) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources

    SettingSectionCard(title = strings.getString(R.string.battery_2)) {
        SettingSwitchRow(
            title = strings.getString(R.string.power_saving),
            subtitle = strings.getString(R.string.reduce_watch_power_use),
            checked = state.psmMode,
            enabled = state.sessionReady && !state.psmControlRestricted,
            onCheckedChange = { repo.setPowerSavingMode(it) },
        )

        HorizontalDivider(color = CardBorder.copy(alpha = 0.5f), thickness = 0.5.dp)

        SettingSwitchRow(
            title = strings.getString(R.string.protect_battery),
            subtitle = strings.getString(R.string.battery_protection_explanation),
            checked = state.batteryProtection == 1,
            enabled = state.sessionReady && state.batteryProtection >= 0,
            onCheckedChange = { repo.setBatteryProtection(it) },
        )
    }
}

@Composable
private fun SoundSettingsCard(state: WatchState, repo: WatchRepository) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources

    SettingSectionCard(title = strings.getString(R.string.sounds_and_vibration)) {
        SettingSwitchRow(
            title = strings.getString(R.string.mute_all_sounds),
            subtitle = strings.getString(R.string.mute_the_watch_speaker),
            checked = state.muteAllSounds,
            enabled = state.sessionReady,
            onCheckedChange = { repo.setMuteAllSounds(it) },
        )

        HorizontalDivider(color = CardBorder.copy(alpha = 0.5f), thickness = 0.5.dp)

        SettingSwitchRow(
            title = strings.getString(R.string.sync_phone_do_not_disturb),
            subtitle = strings.getString(R.string.sync_the_phone_s_do_not_disturb_setting_to),
            checked = state.syncDnd,
            enabled = state.sessionReady,
            onCheckedChange = { repo.setSyncDnd(it) },
        )

        HorizontalDivider(color = CardBorder.copy(alpha = 0.5f), thickness = 0.5.dp)

        SettingSwitchRow(
            title = strings.getString(R.string.touch_sounds),
            subtitle = strings.getString(R.string.play_sounds_when_interacting_with_the_watch),
            checked = state.touchSound,
            enabled = state.sessionReady,
            onCheckedChange = { repo.setTouchSound(it) },
        )

        HorizontalDivider(color = CardBorder.copy(alpha = 0.5f), thickness = 0.5.dp)

        SettingSwitchRow(
            title = strings.getString(R.string.charging_sound),
            subtitle = strings.getString(R.string.play_a_sound_when_charging_starts),
            checked = state.chargingSound,
            enabled = state.sessionReady,
            onCheckedChange = { repo.setChargingSound(it) },
        )
    }
}

@Composable
private fun ButtonsSettingsCard(state: WatchState, repo: WatchRepository) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources

    SettingSectionCard(title = strings.getString(R.string.buttons_and_gestures)) {
        SettingSwitchRow(
            title = strings.getString(R.string.quick_launch_gesture),
            subtitle = strings.getString(R.string.open_an_app_or_feature_using_the_watch_s),
            checked = state.quickLaunch,
            enabled = state.sessionReady,
            onCheckedChange = { repo.setQuickLaunch(it) },
        )

        HorizontalDivider(color = CardBorder.copy(alpha = 0.5f), thickness = 0.5.dp)

        SettingSwitchRow(
            title = strings.getString(R.string.answer_calls_with_gestures),
            subtitle = strings.getString(R.string.gesture_answer_explanation),
            checked = state.gestureAnswer,
            enabled = state.sessionReady,
            onCheckedChange = { repo.setGestureAnswer(it) },
        )

        HorizontalDivider(color = CardBorder.copy(alpha = 0.5f), thickness = 0.5.dp)

        SettingSwitchRow(
            title = strings.getString(R.string.dismiss_calls_and_alerts_with_gestures),
            subtitle = strings.getString(R.string.gesture_dismiss_explanation),
            checked = state.gestureDismiss,
            enabled = state.sessionReady,
            onCheckedChange = { repo.setGestureDismiss(it) },
        )

        HorizontalDivider(color = CardBorder.copy(alpha = 0.5f), thickness = 0.5.dp)

        SettingChoiceRow(
            title = strings.getString(R.string.preferred_wrist),
            options =
                listOf(
                    strings.getString(R.string.left_wrist),
                    strings.getString(R.string.right_wrist),
                ),
            selectedIndex = if (state.wristRight) 1 else 0,
            enabled = state.sessionReady,
            onSelect = { repo.setWristOrientation(it == 1) },
        )
    }
}

@Composable
private fun AccessibilitySettingsCard(state: WatchState, repo: WatchRepository) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources

    SettingSectionCard(title = strings.getString(R.string.vision_and_accessibility)) {
        SettingSwitchRow(
            title = strings.getString(R.string.grayscale_2),
            subtitle = strings.getString(R.string.display_the_screen_in_grayscale),
            checked = state.grayscaleEnabled,
            enabled = state.sessionReady,
            onCheckedChange = { repo.setGrayscale(it) },
        )

        HorizontalDivider(color = CardBorder.copy(alpha = 0.5f), thickness = 0.5.dp)

        SettingSwitchRow(
            title = strings.getString(R.string.high_contrast_text),
            subtitle = strings.getString(R.string.increase_text_edge_contrast),
            checked = state.highContrastFonts,
            enabled = state.sessionReady,
            onCheckedChange = { repo.setHighContrastFonts(it) },
        )

        HorizontalDivider(color = CardBorder.copy(alpha = 0.5f), thickness = 0.5.dp)

        SettingSwitchRow(
            title = strings.getString(R.string.invert_colors),
            subtitle = strings.getString(R.string.invert_screen_colors),
            checked = state.negativeColors,
            enabled = state.sessionReady,
            onCheckedChange = { repo.setNegativeColors(it) },
        )

        HorizontalDivider(color = CardBorder.copy(alpha = 0.5f), thickness = 0.5.dp)

        SettingSwitchRow(
            title = strings.getString(R.string.reduce_animations),
            subtitle = strings.getString(R.string.reduce_interface_animations),
            checked = state.removeAnimations,
            enabled = state.sessionReady,
            onCheckedChange = { repo.setRemoveAnimations(it) },
        )
    }
}

/** 全量底层设置项卡片：自适应渲染不同类型（Switch / 步进 / 文本框） */
@Composable
private fun RawSettingItemCard(item: SettingItem, repo: WatchRepository, enabled: Boolean) {
    val strings = androidx.compose.ui.platform.LocalContext.current.resources

    val locale = androidx.compose.ui.platform.LocalConfiguration.current.locales[0]
    val labels = remember(locale) { SettingLabels(locale) { strings.getString(it) } }
    val label = remember(item.path, labels) { labels.describe(item.path) }
    var showProtocol by remember(item.path) { mutableStateOf(false) }
    GroupedCard(cornerRadius = 20.dp, innerPadding = 16.dp) {
        Text(
            label.category,
            style = androidx.compose.material3.MaterialTheme.typography.labelMedium,
            color = ElectricBlue,
        )
        Spacer(Modifier.height(6.dp))
        if (item.value is Boolean && label.known) {
            SettingSwitchRow(
                label.title,
                checked = item.value,
                subtitle = label.description,
                enabled = enabled,
                onCheckedChange = { repo.updateSetting(item.path, it) },
            )
        } else {
            Text(
                label.title,
                style = androidx.compose.material3.MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.SemiBold,
                color = TextPrimary,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                labels.value(item),
                style = androidx.compose.material3.MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
            )
            if (label.description.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                Text(
                    label.description,
                    style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                    lineHeight = 18.sp,
                    color = TextTertiary,
                )
            }
        }
        androidx.compose.material3.TextButton(onClick = { showProtocol = !showProtocol }) {
            Text(
                if (showProtocol) strings.getString(R.string.hide_raw_fields)
                else strings.getString(R.string.view_raw_fields),
                style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
            )
        }
        if (showProtocol) {
            androidx.compose.foundation.text.selection.SelectionContainer {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        strings.getString(R.string.path) + item.path,
                        style = androidx.compose.material3.MaterialTheme.typography.labelMedium,
                        color = TextSecondary,
                    )
                    Text(
                        strings.getString(R.string.field) + item.key,
                        style = androidx.compose.material3.MaterialTheme.typography.labelMedium,
                        color = TextSecondary,
                    )
                    Text(
                        strings.getString(R.string.raw_value) + item.value.toString(),
                        style = androidx.compose.material3.MaterialTheme.typography.labelMedium,
                        color = TextSecondary,
                    )
                    Text(
                        strings.getString(R.string.data_type) +
                            when {
                                item.isBool -> strings.getString(R.string.setting_switch)
                                item.value is Number -> strings.getString(R.string.number)
                                item.value is List<*> -> strings.getString(R.string.list)
                                else -> strings.getString(R.string.text)
                            },
                        style = androidx.compose.material3.MaterialTheme.typography.labelMedium,
                        color = TextTertiary,
                    )
                }
            }
        }
    }
}
