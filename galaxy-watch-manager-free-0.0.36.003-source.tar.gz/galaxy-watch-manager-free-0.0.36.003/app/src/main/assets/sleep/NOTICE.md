# Offline sleep analysis runtime

This folder contains the **vendor-derived** inference runtime and model used to analyze
Galaxy Watch sleep sensor records. It is not an independently trained model.

Source: the locally retained Samsung Health 7.1.0.053 APK, SHA-256
`88b0359eaaea6061466df4fdb15754ca8408caf68e1eb796ef58b24374efe312`.
The source APK itself is not included in the repository.

Default public builds and corresponding source archives include:

- `engine.jar`: reduced DEX inference bridge, 30-second stage model and quantile table.
  The model `tcn_ibi_t2v_stages_sum_214_l8_db6.tflite` and
  `quantiles_db6_vertical.txt` are embedded under the JAR's `assets/` directory.
- `arm64-v8a/` and `armeabi-v7a/`, each containing:
  - `libmobilesleepjni.so`: Samsung feature preprocessing / inference support.
  - `libtensorflowlite_jni.so`: TensorFlow Lite runtime distributed with that APK.
- `manifest.json`: input provenance and SHA-256 digests verified during the build and
  before runtime extraction.

Samsung's model and feature library retain their original ownership. TensorFlow Lite is
an upstream Google/TensorFlow component under Apache-2.0; the upstream license text is
retained as `TENSORFLOW-LICENSE.txt`. Inclusion does not establish redistribution rights or
the full notice requirements of Samsung's specific bundled binary; see `THIRD-PARTY.md`.
Extraction and repackaging do not change ownership or grant new rights. These vendor
components are not covered by the repository's GPLv3 grant for original code.

Reconstruction source and tooling profile: `scripts/sleep-engine/`. Behavior and validation
scope: `docs/SLEEP-ANALYSIS.md`. The app executes this bundle from its own private code cache;
it does not load code from, launch, or require Samsung Health installed on the phone.

ARM64 inference has been tested on a physical Android phone. ARMv7 files are bundled but
have not been tested on an ARMv7 device. Other CPU architectures keep received session
data and show analysis as unavailable rather than fabricating stages.
