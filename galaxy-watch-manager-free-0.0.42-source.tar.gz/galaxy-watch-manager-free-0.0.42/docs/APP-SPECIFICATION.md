# Galaxy Watch Manager Free 程序架构与功能全景规范

> **状态基线**：v0.0.41.001 Nightly (versionCode: 41001) · 2026-11-24（在 v0.0.41 / 0.0.41.001 健康监测器手表证书投递修复与四端证书身份文档化基础上：加固 Flow 代理目标过滤/帧长校验/异常隔离与 RFCOMM 双工竞争清理及 `BOND_BONDED` 校验；修复天地图共享 32 MiB 磁盘缓存与连接池复用；将原始健康记录迁出 SharedPreferences 至原子文件 `HealthRecordFileStore`、主线程重度写盘异步化、SHM ECG/BP 批量原子入库；将设备快照与 DND 状态统一收敛至 MAC 作用域、为 `wear-assets` 增加容量裁剪并兜底接收队列 `Throwable`；完成 `OfficialAppHandover` 提示全面 `UiText` 双语化、日志 `node=` / `wear://` 脱敏加固并抽出 `WatchfaceController`）
> **维护规则**：本文档为应用实际架构、核心组件与功能实现的真实全景基线。后续有任何新功能接入、协议变动、数据结构修改或界面调整，**必须在同一变更中回补本文档**，保持文档与代码严格一致。

---

## 1. 概述与核心定位

**Galaxy Watch Manager Free** 是一个独立运行于 Android 系统的 Samsung Galaxy Watch 手表管理应用。本应用从 `galaxy-watch-tweaker` 实验模块独立拆分而来，采用标准 Android 蓝牙 API，无需 Root 或手表固件修改。Watch 4 / 5 / 6 / 7 / Ultra 的实测范围见 [协议规范](PROTOCOL-SPEC.md)。Watch8 和 Watch8 Classic 已加入设备识别及官方应用交接，真机验证范围见 §5.6。

### 1.1 核心设计哲学

1. **直接连接与协议突破**：使用原生 Android Bluetooth RFCOMM 套接字与手表内置的 WCS（Wearable Communication Service）直接建立双向通信，无需三星官方 Galaxy Wearable、Watch Plugin 介入或转发。
2. **官方功能与身份兼容**：保留手表全部原生特性，通过逆向突破 GMS `OemCompanionVerifier` 鉴权与 WCS `feature_exchange` 身份协商，支持在非三星手机上使用 Samsung Health Monitor（ECG 心电图与血压记录/校准）。
3. **数据主权与离线优先**：健康记录、睡眠分析、诊断日志均保存在手机本地私有存储中。随包附带本地端侧睡眠推理引擎，无需任何第三方云端依赖；地图底图采用天地图标准服务，轨迹绘制完全在端侧完成。
4. **状态真实与解耦校验**：UI 展示与设备确认严格解耦；支持免打扰与核心设置的即时乐观呈现，同时以手表底层状态回传为最终校准基准；未知值和有效零值严格区分，禁止构造虚假占位数据。
5. **无损交接与共存机制**：通过内置的官方连接交接模块（支持 Shizuku 一键启停或系统手动指引），可随时在「本应用直连」与「官方应用接管」之间无损切换，不损坏官方配对与数据。

---

## 2. 全局分层架构与核心数据流

应用采用清晰的单向数据流与分层驱动模型，各层职责明确，线程与锁边界清晰：

```mermaid
flowchart TD
    subgraph UI ["表现层 (Compose UI)"]
        Activity[MainActivity / HomeScreen]
        Tabs[Dashboard / Health / WatchFace / Settings]
        Sheets[Detail Sheets: Step / Sleep / HR / Stress / ECG / BP / Exercise / Vascular / Energy]
    end

    subgraph ServiceLayer ["服务与生命周期管理层"]
        Service[WatchConnectionService]
        Controller[WatchController]
        Gate[ConnectionRequestGate]
        NotifService[NotificationBridgeService]
    end

    subgraph DomainLayer ["业务领域与仓储门面层"]
        WatchRepo[WatchRepository]
        WatchfaceCtrl[WatchfaceController]
        HealthRepo[HealthRepository]
        EnergyCalc[EnergyScoreCalculator]
        Handover[OfficialAppHandover]
        SyncCoord[HealthSyncCoordinator]
        AutoQuery[AutoQueryCoordinator]
        SettingSchema[WatchSettingSchema / SettingCommands]
    end

    subgraph ProtocolLayer ["协议编排与传输层"]
        Session[WcsSession]
        Assembler[WcsPieceAssembler]
        Transport[RfcommTransport]
        FlowProxy[FlowProxyServer / FlowProxySession]
        TimeSync[PhoneTimeSync]
        BleWake[BleWakeLock]
        Bridger[BridgerNotificationSender]
        MonitorSess[HealthMonitorSession]
        EnergySync[EnergyScoreSync]
    end

    subgraph StorageLayer ["数据存储与导出层"]
        DevPrefs[DevicePreferences / DeviceIdentityStore]
        RecordStore[HealthRecordStore / HealthRecordFileStore]
        SleepStore[LocalSleepAnalyzer / ManualNapStore]
        EnergyLog[EnergyScoreLog]
        LogStore[DiagnosticLogStore]
        Archive[HealthArchive / HealthExportData]
    end

    %% UI to Service & Facade
    Activity --> Controller
    Tabs --> WatchRepo
    Tabs --> HealthRepo
    Sheets --> HealthRepo
    Sheets --> WatchRepo

    %% Lifecycle
    Service --> Controller
    Controller --> Gate
    Controller --> Transport
    Controller --> Session
    Controller --> WatchRepo

    %% Notifications
    NotifService --> Bridger
    Bridger --> Session

    %% Repository dependencies
    WatchRepo --> Session
    WatchRepo --> WatchfaceCtrl
    WatchRepo --> HealthRepo
    WatchRepo --> SettingSchema
    WatchRepo --> AutoQuery
    WatchRepo --> EnergySync
    HealthRepo --> EnergyCalc
    HealthRepo --> EnergyLog
    HealthRepo --> SyncCoord
    HealthRepo --> MonitorSess
    HealthRepo --> RecordStore
    HealthRepo --> SleepStore
    HealthRepo --> Archive
    Handover --> DevPrefs

    %% Protocol connection
    Session --> Transport
    Session --> TimeSync
    Transport --> FlowProxy
    MonitorSess --> Session
    EnergySync --> Session
    EnergySync --> HealthRepo
    Session --> WatchRepo
    Transport --> BleWake

    %% State flow back to UI
    WatchRepo -.->|WatchState Flow| Tabs
    HealthRepo -.->|HealthDataProjection| Tabs
```

### 2.1 关键线程模型与并发控制

- **RFCOMM 传输线程**：`RfcommTransport` 内部由读线程驱动阻塞式 `InputStream.read()`，写操作通过独立锁与缓冲队列入队。连接锁 `connectionLock` 与生命周期锁 `lifecycleLock` 严格分离，生命周期回调绝不持有连接锁，避免死锁。
- **协议路由线程**：`WcsSession` 在读线程解包分片与 Protobuf 信封后，通过观察者回调派发至 `WatchRepository.onMessage` 与 `HealthRepository.handleMessage`。
- **Flow 代理线程**：独立 RFCOMM 监听与单会话读取/写入线程负责 Flow 字节流；NIO Selector 负责非阻塞 IPv4 TCP/UDP 转发，有界队列在拥塞时暂停网络读取。默认拒绝本机回环（`127.0.0.0/8`）、未指定（`0.0.0.0`）、链路本地（`169.254.0.0/16`）、组播（`224.0.0.0/4`）、受限广播（`255.255.255.255`）及 0 端口目标，保留公网与局域网 DNS/私有地址转发；对异常截断帧执行防御性长度校验；监听循环不区分 MAC 大小写校验对端，并隔离单会话异常防止 `flow-server` 监听线程退出。手机默认网络回调只发布类型与计费状态，转发不进入主线程。
- **后台计算协程**：健康记录的聚合计算（`HealthDataProjection`）、端侧睡眠分期推理（`LocalSleepAnalyzer`）以及 ZIP 归档导出（`HealthArchive`）均运行在 `Dispatchers.IO` / `Dispatchers.Default` 协程池中，绝不阻塞主线程。
- **状态快照发布**：`WatchRepository` 维护不可变的 `WatchState` 快照，通过 Kotlin `StateFlow` 对 UI 暴露。更新时发布全新快照，严禁原地修改集合或内部状态。

---

## 3. 核心控制器与生命周期管理

### 3.1 WatchController (`core/WatchController.kt`)
- **职责**：维护全局连接状态机、当前设备 MAC、服务启动与停止、以及官方应用交接过渡。
- **连接代次守卫 (`core/ConnectionRequestGate.kt`)**：每次发起连接或身份读取分配单调递增的代次 ID。异步回调返回时检查代次有效性，杜绝过时的连接尝试或失效回调覆盖当前状态。
- **广播接收器 (`core/WatchCommandReceiver.kt`)**：支持系统或外部意图触发的手表控制命令（如后台定时连接、刷新）。

### 3.2 WatchConnectionService (`service/WatchConnectionService.kt`)
- **前台保活服务**：注册为 Android 前台服务，持有系统通知以防止后台被杀。
- **动态状态栏通知 (`feature/ConnectionNotificationSnapshot.kt`)**：通知栏实时展示当前连接状态（连接中、已连接、维持连接），并在已连接时动态刷新今日步数、心率、目标完成百分比与手表电量；当无关数据变动时不引起通知重绘抖动。

---

## 4. 传输层与 WCS 协议栈实现

### 4.1 RFCOMM 直连传输 (`wcs/RfcommTransport.kt`)
- **双向竞争接入**：同时启动 BluetoothServerSocket 监听（等待手表主动连入）与 BluetoothSocket 发起主动连接，先成功者接管通信信道并立即关闭竞争失败方正在阻塞的 `connectingSocket`，防止对端重复通道闪断；被动监听端校验来访设备与当前选定手表 MAC 一致（不区分大小写）且处于 `BOND_BONDED` 状态，拒绝未配对或非目标设备。
- **重连退避策略 (`wcs/ReconnectPolicy.kt`)**：主动重连实施指数退避限制，并辅以 `BleWakeLock` 控制 BLE 广播唤醒频次，防止手表与手机在低电量下频繁唤醒造成电量损耗。
- **官方按需心跳与低频兜底**：`WcsSession` 在组装出完整消息后，对非心跳消息调用 `RfcommTransport.markInboundNonHeartbeat()`；writer 在发送队列排空时补发一次官方空心跳（`inner=5a00`，摘要由内容计算，不依赖配对凭据），不对心跳回心跳。无任何入站时由 writer 的 60 秒轮询超时发送一次兜底心跳，已移除独立 10 秒心跳线程。

### 4.2 WCS 协议分包与会话管理 (`wcs/WcsFrame.kt`, `wcs/WcsSession.kt`)
- **帧与分片重组**：还原 WCS 底层帧结构，通过 `WcsPieceAssembler` 组装超长分片数据包，校验数据包长度与序列完整性；接收端由 `SessionReceiveQueue` 有界串行消费并对非 `Exception` 的 `Throwable` 执行关闭与唤醒兜底，避免队列永久卡死；8 秒 `readyWatchdog` 线程在会话就绪或关闭时及时中断。
- **有界资产缓存 (`wcs/WearAssetStore.kt`)**：入站 `SetAsset` 附件原子落盘至 `files/wear-assets/<phoneNode>_<watchNode>/`，校验安全摘要并实施 LRU 容量裁剪（默认上限 64 个文件 / 32 MiB）。
- **Generation 重排队列与单调 DataItem `seqId`**：完整还原 Google Wearable RPC 的 `generation` 重排队列机制；队列满丢帧时不提前递增 `messageCounter`，防止手表 `ReorderingQueue` 出现 20 秒空洞等待；DataItem `seqId` 从手表 `SyncStart.cursors[phoneNode]` 与本地持久化单调计数器（`DeviceIdentityStore.localDataItemSeq`）延续，不再用毫秒时间戳污染手表 SQLite `nodeinfo.seqId`，保障交还官方 GMS 后正常同步。节点 ID 校验放宽至官方 1–8 位无前导零十六进制（`[0-9a-f]{1,8}`）；`CompanionProfile` 覆盖 Watch4–Watch8/Ultra2（含 `com.samsung.wearable.watchuniteplugin`）。
- **官方协议路径集 (`wcs/WcsPaths.kt`)**：
  - `/wcs_extension/sysui/watchface`：表盘查询、收藏夹排序与切换。
  - `/samsung_health/wearable_message`：三星健康双向 gzip 游标同步信道。
  - `/991`–`/994`：Samsung Health Monitor (SHM) BP / ECG / IHRN / APNEA 信道。
  - `/bridger/...`：Wear OS 规范的通知桥接 DataItem 路径。
  - `/remote_intent/rpc`：远程意图拉起通道。

### 4.3 关键身份兼容补丁 (不可删除的兼容基准)
- **GMS Companion 鉴权突破 (`wcs/IdentityProof.kt`)**：携带官方三星可穿戴应用包名与官方证书 SHA-256 签名，通过手表底层 GMS `OemCompanionVerifier` 验证。
- **WCS 状态交换兼容身份 (`wcs/PhoneFeature.kt`)**：在 `feature_exchange` 中模拟三星兼容手机身份（`deviceName="Galaxy S25 Ultra"`, `modelNumber="SM-S938U1"`, `vender="samsung"`, `isTablet="false"`, `csc="XAA"`）。**此项是确保非三星手机能够接收健康监测器 ECG/血压以及手表高级设置的基石，严禁清理或改回宿主手机真实 `Build.*`**。
- **健康监测器与三星健康手表原生 AppKey 直投 (`HealthMonitorProtocol.WATCH_SIGNATURE` / `WcsPaths.PKG_WATCH_SHEALTH`)**：手表 WearableService 仅在双端曾通过官方 App 同步 `TrustedPeersService`（`hlq.i`）时才改写跨证书身份；为免除新机安装官方手机 App 的依赖，SHM（含 `/991d`–`/992d` Channel 控制包）与三星健康（含 Channel 控制包）均默认使用手表平台证书 `9ca5170f…` 对应的手表本地 AppKey 直投，同时各自保留握手/能力超时后的单次 `9741a0f3…` 备用回退与按设备记忆。完整路由边界见 [协议 SSOT §7.3](PROTOCOL-SPEC.md#73-证书指纹白名单与三条路由机制2026-11-24-彻底闭环)。
- **GMS 能力 DataItem 发布者身份 (`WcsSession.publishCapabilities`)**：在每次连接收到手表 `SyncStart` 后发送一次；外层 Tag 9 字段 2/9 必须携带 `AppKey[com.google.android.gms, 38918a453d07199354f8b19af05ec6562ced5788]`（`WcsPaths.SIGNATURE_GMS`），路径内使用手表端证书 `9ca5170f…`，同步广播 SHM 四项能力与三星健康 `samsung_health_wearable_interaction_protocol`，确保手表 `CapabilityService` 正确索引。

---

## 5. 核心业务功能与状态机实现全景

### 5.1 设备概览与快速控制 (Dashboard Tab)
- **运行内存管理 (`memory/clean`) 与健康免杀保护**：
  - 手表端当前 RAM 使用量、可用量及活跃后台进程列表查询。
  - **健康应用守护进程过滤**：Wear OS 的 `WearableListenerService`（如手表端 `com.samsung.android.wear.shealth` 和 `com.samsung.android.service.health`）若被一键清理强行杀死，系统不会自动通过蓝牙数据报文唤醒它，导致常驻监听挂起、健康报文被静默丢弃、同步彻底超时。在解析 `ramCleanableApps` 及 `cleanRam` 触发下发时，通过 `isProtectedMemoryCleanPackage` 排除所有包名包含 `shealth` 或 `health` 的应用，保障手表端健康采集与传输后台持续存活。
  - 一键清理（`memory/clean` RPC）：向手表下发清理调度请求，有界等待手表底层进程清理完成后自动回读，呈现真实释放后的 RAM 快照。
- **免打扰 (Do Not Disturb / DND)**：
  - **即时乐观交互**：手机端点击开关后立即在界面更新为目标状态（`dndSubmitted ?: dndOn`），无需等待手表网络回传。
  - **连续反向点击支持**：如果在手表确认前再次点击，立即触发反向切换命令并刷新界面目标，避免界面卡死在「已请求/未确认」状态。
  - **定向节点下发**：请求优先解析手表目标节点 ID 下发；无目标节点时不构造空请求。
  - **回声校验**：手表端回传真实状态时，执行一次性覆盖校对，保证最终一致性。
- **快速控制磁贴 (Quick Controls)**：
  - 省电模式 (PSM)：双向状态同步与超时补发。
  - 睡眠模式 (Bedtime) 与影院模式 (Theater)。
  - 屏幕辅助功能：黑白灰度模式 (Grayscale) 与高对比度文字，通过 Tag 9 DataItem 联动 Dalvik ExclusiveTaskManager 实时生效。
- **官方表盘切换 (`feature/WatchfaceController.kt` / `ui/screens/WatchFaceScreen.kt`)**：
  - 沿 `/wcs_extension/sysui/watchface` 协议边界由独立 `WatchfaceController` 统一负责表盘查询、切换、收藏排序、延时回读确认（新操作自动取消旧确认任务）与断连清理。
  - 接入 43 款官方旗舰预设表盘（包含 Galaxy Watch Ultra 独占表盘）。
  - 本地随包提供 43 张逐款高清效果示意图（概览页设备卡片与表盘图库复用同一矢量资源）。
  - 一键下发切换，手表底层 `WallpaperService` 实时响应，手机卡片双向同步当前活跃表盘。
- **手表改名 (Alias Name)**：
  - 通过手表官方 Alias DataItem URI 修改手表蓝牙显示名称，修改后主动回读并在重连及进程重启后正确持久化。

### 5.2 双源健康数据同步体系 (Health Sync)
系统将健康数据通道正交解耦为两个独立子系统，实现双源独立握手与协同管理：

```mermaid
sequenceDiagram
    participant App as 手机应用 (HealthSyncCoordinator)
    participant WCS as 三星健康信道 (/samsung_health)
    participant SHM as 健康监测器信道 (/991)

    Note over App: 触发同步 (定时/下拉刷新/手动点击)
    par 三星健康同步
        App->>WCS: REQUEST_DATA (发送游标)
        WCS-->>App: SYNC_DATA (分块 gzip 记录上报)
        App->>WCS: LOG_DATA (回写持久化确认游标)
    and 健康监测器同步
        App->>SHM: 握手并拉取 ECG / 血压
        SHM-->>App: 回传采样点与测量记录
        App->>SHM: 确认接收完成
    end
    Note over App: 聚合两路结果，独立更新状态并触发数据投影
```

- **通道 1：三星健康通道 (`/samsung_health/wearable_message`)**：
  - 双向三段式 gzip 游标握手协议：`REQUEST_DATA` → `SYNC_DATA`（含 `is_last_chunk` 3 秒宽限完结）→ `LOG_DATA`；非同步 `type="MESSAGE"` 辅助流量（如 `sound_relay`、`sport`）与调试导出用 `DATA_CLIENT_WITH_ASSET` 均被隔离，不触发全量落盘。
  - `HealthRecordStore` 留存步数、心率、压力（含 `histogram`/`alerted_stress`）、血管负荷、血氧（含 `.raw`）、皮温、呼吸率（标准化视图过滤 `is_outlier` 异常点）、HRV、运动及附属表（`exercise.route/hr_zone/recovery_heart_rate/max_heart_rate/weather/periodization_training_result`）、`movement`、`antioxidant`、`ages`、`activity.day_summary` 与 `preferences`，并接入 `deleted_data` 删除墓碑（60 天 / 8,000 条）防止陈旧重放复活已删记录；`HealthDataProjection` 保留 30 天体征投影；手机外发 `device_info.device_type=0`，远程深链接 body 规范做 gzip+Base64，能力响应补齐 `config` 与扩展 `tracker_feature`。
  - 游标在且仅在数据写入本地 `HealthRecordStore` 持久化成功后才向手表回写，保证不丢数据。
  - **手表原生 AppKey 优先 + 自动回退**：通过 `WcsSession.sendHealthJson` 默认以 `com.samsung.android.wear.shealth` + `9ca5170f…` 直投（免安装官方三星健康），10 秒无应答自动切换一次 `com.sec.android.app.shealth` + `9741a0f3…` 并按配对地址持久化生效模式（`DeviceIdentityStore.healthIdentityMode`）。
- **通道 2：健康监测器通道 (`/991`–`/994` & `HealthMonitorSession`)**：
  - 专用于 ECG 心电波形（含采样点、采样率、手表分类、分类码 4..8 细分原因、症状编码 0..8、`ecg_app_version`、时区偏移与元数据）及血压记录（含 `calibration_datauuid`、时区偏移与元数据）的接收，本地留存上限各 1,000 条（防止手表 ACK 后永久删除导致的不可逆丢失）。
  - **ECG v2 握手与 BP 端点对齐**：`/992` `RESPONSE information` 携带 `"ecg_app_version": "1.3"` 避免手表 ECG 静默降级至 v1；BP `terms_and_condition` 发送至 `bp.measuring`；`activateEcg()`/`activateBp()` 在未就绪时排队等待 `READY` 后再派发；按通道记录 `<path>c` `disable` 状态；`/992d` 批量任务经 `receiveSyncBatch` 与终结包 `RESPONSE DATA (id=0)` 完整收尾，并对旧版 Watch SHM（`< 1.4.5.002` 不支持 `/plain_connection`）给出明确超时提示。
  - **发送证书与双身份记忆**：`/plain_connection`、`/991`–`/994` 与 `/991d`–`/992d` Channel 控制包均动态跟随 `monitorSignature`（默认手表平台证书 `9ca5170f…`）；握手 10 秒无应答时切换 `9741a0f3…` 重试一次，确认后按配对地址写入 `DeviceIdentityStore.monitorSignature` 复用。
  - **批量解析与原子入库**：单次 `SYNC_DATA` 报文先完成整批 ECG / 血压记录解析，再通过 `onEcgBatchReceived` / `onBpBatchReceived` 一次性归并、持久化并在失败时整体回滚，杜绝部分落盘后不回 ACK 的状态分裂。
  - **袖带血压三轮校准编排**：由手机端向导编排三轮袖带测量，录入真实袖带高压/低压读数，合并发送给手表官方算法完成校准；消除了导致手表端闪退的并发 Intent 冲突。
- **双源状态呈现 (`HealthSyncSummary`)**：
  - 两路同步分别维护握手状态与超时保护。
  - UI 精确区分：「全部同步成功」、「仅三星健康已同步」、「仅健康监测器已同步」、「健康数据部分同步」以及错误提示。

### 5.3 运动记录与天地图轨迹地图 (Exercise & Routes)
- **运动类型支持**：完整支持 100+ 种官方运动模式（跑步、健走、户外骑行、徒步、游泳、器械训练等）。
- **轨迹数据还原 (`feature/ExerciseRoute.kt`)**：
  - 自动解算原始运动位置资料中的经纬度序列、时间戳、海拔、分段与距离信息。
  - 无坐标记录如实声明「未收到地图轨迹」，绝不绘制虚假路线。
- **MapLibre 11.8.0 与天地图集成 (`ui/components/ExerciseRouteMap.kt` / `ui/screens/MetricSheets.kt`)**：
  - 地图底图采用天地图标准 WMTS 瓦片服务（`vec_w` 矢量底图 + `cva_w` 矢量中文注记图层）。
  - 瓦片 HTTP 请求通过单例 `MapTileHttp` 共享基础 `OkHttpClient` 连接池与 32 MiB 磁盘缓存（`cache/map_tiles/`）；当上游成功响应未携带 `Cache-Control` 与 `Expires` 时，在 Network Interceptor 中移除 `Pragma` 并注入 `Cache-Control: public, max-age=604800`，使预览卡片与全屏交互地图共享离线命中。全屏地图通过独立 `Dispatcher` 派生客户端，关闭时仅取消并回收本对话框调度器，不影响共享连接池与磁盘缓存。
  - 轨迹在手机端本地离线计算并叠加渲染，绘制起点标记、终点标记与轨迹连线。
  - 支持双指缩放、旋转、全程自适应缩放（Fit Bounds）与全屏交互。
  - 声明网络隐私提示：底图经由天地图加载，轨迹在端侧绘制。

### 5.4 端侧离线睡眠分析与小睡记录 (Sleep Subsystem)
- **端侧睡眠推理引擎 (`feature/LocalSleepAnalyzer.kt`)**：
  - 随包内置 ARM64 与 ARMv7 架构 Native 推理运行时与模型，无网络调用，数据纯本地推理。
  - 解析手表睡眠原始传感器数据，还原清醒、浅睡、深睡、REM 快速眼动期四段分期及睡眠呼吸暂停筛查。
- **多段睡眠合并与去重 (`feature/SleepParser.kt`)**：
  - 自动识别同一自然日内的多段睡眠并进行时间线合并与重叠去重。
- **本机小睡记录 (`feature/ManualNapStore.kt`)**：
  - 当手表漏记白天小睡时，支持用户手动补记起止时间。
  - 小睡记录保存在手机本地，按配对设备 MAC 隔离，与夜间睡眠合并计算当日总时长，不篡改手表端原始数据。

### 5.5 通知桥接与应用图标推送 (Notification Bridge)
- **通知监听与筛选 (`feature/NotificationBridgeService.kt`)**：
  - 继承 Android 原生 `NotificationListenerService`。
  - 支持配置全部应用转发或仅白名单应用转发。
  - 支持配置免打扰时间段过滤，过滤常驻通知与系统摘要。
  - **使用手机时不提醒 (`feature/PhoneStatusDetector.kt` / `NotificationFilterPreferences.muteWhileUsingPhone`)**：
    - 参考三星官方判定逻辑（`PowerManager.isInteractive && !KeyguardManager.isKeyguardLocked`），当手机屏幕点亮且锁屏已解锁时判定手机正处于活跃使用中；
    - 若开启“使用手机时不提醒”（默认开启，符合官方行为），通知到达时直接在手机端拦截跳过，输出明确诊断日志 `[pkg id]: 手机正在使用中 (USING_PHONE)`，避免在用户操作手机时打扰手表；
    - 在通知设置页提供开关切换，并通过 WCS `alerts_on_watch`（0=开/仅未在使用手机时提醒，1=关/即使使用手机也提醒）与手表端双向同步。
  - **手表重连恢复**：WCS 会话就绪、对端 SyncStart 或系统监听连接后，同步桥接特性与通知设置。同一连接合并并发任务，延迟补发一次以覆盖对端初始化，首次补发入队失败时继续有限重试。断线取消旧任务。
  - **手机监听恢复 (`feature/NotificationListenerRecovery.kt`)**：进程启动、主界面回到前台、手表重连或监听断开时，检查已授权且开启转发但监听未连接的情况，并请求 Android 重绑。等待系统回调时有限重试，通知设置页显示实际监听连接状态。
- **Wear OS Bridger DataItem 规范**：
  - 将手机通知格式化为 `wear://<phoneNode>/bridger/stream_item:…` 标准 DataItem 广播至手表。
  - DataMap 字段集对齐官方 GMS `wear_companion` 发送器（Samsung 手机插件内置的 `zzewl`）：`R_c` / `R_c,0`、`when`、`post_time_millis`、`show_when`、`app_name`、`notification_style`（标准样式 = 1）、`title_html` / `title_raw`、`text_html` / `text_raw`、`color`、`notification_flags`、`user_id`、`defaults`、`has_sound`、`has_content_intent`、`only_alert_once`、`is_work_profile`、`is_emergency`、`is_group_summary`、`is_small_icon_vector_drawable`、`from=phone`。缺少 `notification_style` 时手表端无法确定模板，只能回退通用样式。
- **应用高清图标与状态栏小图标双下发**：
  - 在通知后台队列从手机 PackageManager 读取来源应用显示名（`app_name`）与应用图标（最大边 56px），并从 StatusBarNotification 提取状态栏小图标（最大边 40px），统一以 PNG 无损编码。
  - 通过 WCS V1 文件附件下发（`SetAsset` 头 `hjo.f4 = hjw`，分片 `hjo.f12 = hje`）：`hjw.f1` 为内容摘要、`hjw.f2` 留空（流式发送不内联）、**`hjw.f3 = hid` 拥有者列表（`hid.f1` 重复 `hif{f1 包名, f2 签名摘要}`）**。手表端按（包名、签名摘要）做资产访问控制，拥有者缺失时资产虽被 `AckAsset` 确认保存，但 DataItem 中的资产引用不可解析，通知卡片只能显示通用图标。
  - DataItem 资产表 `f8` 的 `him{f1 键, f2 hil{f4 摘要}, f3 4}` 与 DataMap 的整数引用索引按 DataMap 键排序（`app_icon` → 0，`icon` → 1）对应。
  - 处理手表端 `FetchAsset`（`hjo.f6 = hjd{f1 包名, f2 摘要, f3 urgent, f4 签名摘要}`）：用最近下发资产的字节缓存按请求方身份重新下发 `SetAsset` + `FilePiece`。
  - 首次提交时允许回退到纯文字。同一连接内，纯文字已入队的通知再次收到相同正文更新时，可补发带图标的原通知，图标仍不可用时跳过重复文字。
  - 日志记录图标摘要、附件和通知入队状态，可用摘要对应手表 `AckAsset` 回执。ADB 诊断命令 `notif_probe`（`pkg` / `app` / `color` / `mode=app|small|both|none`）可下发纯色图标，用于判定资产渲染链路是否可用。

### 5.6 官方应用连接交接 (Handover Subsystem)
- **无损连接接管与恢复 (`feature/handover/OfficialAppHandover.kt`)**：
  - 解决官方 Wear OS / Galaxy Wearable 与本应用在后台争抢手表 RFCOMM 蓝牙通道的根本冲突。
- **双模操作方案**：
  - **Shizuku 一键操作**：通过 Shizuku 授权，一键停用或恢复 Galaxy Wearable、Watch4/5/6/7 插件、Watch8 和 Watch8 Classic 共用的 Watch Manager 插件（`com.samsung.wearable.watchuniteplugin`），以及 Wear OS / Wear OS 中国版。共享插件的启停按手机当前用户作用于整个包；全部用户可见状态与失败提示通过支持嵌套解析的 `UiText` 接入中英双语资源。
  - **Watch8 适配范围**：已配对设备的自动选择识别 Watch8 / Watch8 Classic 及 `SM-L320`、`SM-L325`、`SM-L330`、`SM-L335`、`SM-L500`、`SM-L505` 型号别名。概览可按型号显示 Classic 外观。已完成手机端静态适配，直连、交接执行和健康同步待两款真机验收。
  - **免 Shizuku 手动方案**：提供系统应用详情页快捷入口与清晰操作向导，支持手动停用与恢复。
- **事务日志保护 (`feature/handover/HandoverJournal.kt`)**：
  - 在改动系统包状态前，将原始启用状态持久化到恢复日志中；交还官方控制权时自动停止本应用自动重连并全量恢复官方应用，杜绝残留竞争。
- **节点身份动态感知与重连防死循环 (`core/WatchController.kt` / `CompanionHandoverCard.kt`)**：
  - 官方应用接管期间手表 Wear OS 拓扑协商可能变更节点关系。当设备曾交还官方（`releasedToOfficialApps == true`）时，`prepareHandover` 与 `startService` 强制向 GMS 探测最新手机节点 ID，禁止复用交还前的旧暂存身份；`continueHandover` 在未获得新鲜暂存身份时拒绝回退陈旧确认节点；`CompanionHandoverCard` 支持协程异步等待最新身份就绪后执行停用与接管，杜绝手表端因节点不匹配瞬间断开套接字导致的死循环。
  - **节点身份容灾与已确认节点回退**：当手机端向 GMS 探测本地节点 ID 出现超时或异常失败（如无 GMS 环境、网络抖动或定制系统限制）时，如果本地已持久化有效的 `confirmedPhoneNode`，自动回退复用该已确认身份，避免因单次探测抖动直接中断连接或卡死在 `IdentityMissing` 状态。
  - **交接等待容差与设备选择保护**：交接准备超时放宽至 6 秒（`CompanionHandoverCard.kt`），彻底消除与 GMS 探测超时之间的临界竞争；连接入口同步校准 `savedMac`，避免多设备切换时的状态漂移。

### 5.7 全量健康数据联动导出 (Health Export v7)
- **导出边界与覆盖范围**：
  - 覆盖当前配对设备在手机中存储的**全部留存历史记录**，不以 UI 当前视图或日历选择窗口为界限；包含独立手动小睡、本机睡眠分析缓存和手机计算的能量得分。
- **归档格式与文件清单 (ZIP)**：
  - `manifest.json`：导出版本（v7，`galaxy-watch-manager-free.health.v7`）、设备信息、时间范围、各文件记录条数、留存上限（ECG/BP 1,000、删除墓碑计数与 60 天窗口）与 SHA-256 校验和。
  - 标准化 JSON：`measurements.json`, `daily_activity.json`, `sleep_sessions.json`, `workouts.json`, `workout_routes.json`, `ecg.json`（含症状、算法版本与元数据）, `blood_pressure.json`（含校准关联 UUID 与元数据）, `vascular_load.json` 等，完整清单见 [HEALTH-EXPORT.md](HEALTH-EXPORT.md)。
  - 能量得分：`energy_scores.json` 保留来源、算法、输入（含活动时长来源与合成日期）、值、身份、修订与应答元数据；`energy_score_rows.json` 是同批记录的 WCS 写回投影，不能重复计数或当作手表原始数据；`energy_profile.json` 保存当前设备用户填写的年龄与算法生理性别（零或一条、`source=user_entered`、`current_value_only`），是当前设置值而非历史记录。
  - 汇总 CSV：便于数据科学工具及电子表格直接分析。
  - 原始记录：`source_records.json` 保留留存的手表上报字段、编码载荷与 `deleted_tombstones`；`retained_cache.json` 保留安全投影后的本机缓存，来源、算法与单位继续随对应数据集导出。
- **ECG 高清图片导出 (`core/EcgImageRenderer.kt`)**：
  - 将心电波形、采样率、心率值与标准 25mm/s、10mm/mV 医学网格渲染为高分辨率 PNG，保存至系统相册。

### 5.8 升级检测与双通道发布体系
- **发布通道严格隔离**：
  - **稳定版通道**：清单由 `crossly/galaxy-watch-manager-free-feed` 仓库的 `version.json` 维护，APK 托管于 `apk` 分支，采用不可变提交 SHA 访问路径。
  - **Nightly 通道**：清单由 `nightly.json` 维护，APK 托管于 `apk-nightly` 分支，版本号形如 `0.0.X.YYY`。
  - 稳定版客户端不接收测试版更新；稳定版发布不会破坏或覆盖已有的 Nightly 发布。
- **更新说明来源**：清单的 `notes` / `published_at` 由发布脚本写入，正文优先取 GitHub Release 正文，取不到时回落到仓库内 `docs/RELEASE-NOTES.md` 的当前版本章节（没有 `GH_TOKEN` 的本地发布同样可用）；`write-update-feed.py --from-feed` 可原地补写已发布清单，只改展示字段、保留产物地址与摘要。客户端把缺失、JSON `null`、空白，以及设备端 `org.json` 对 `null` 产生的字面量 `"null"` 一律视为无说明，不显示为更新日志。
- **本地三重安全防线**：
  - 强制 HTTPS 传输，防范中间人篡改。
  - 下载文件大小上限校验与 SHA-256 完整性哈希校验。
  - 本地解析 APK 确认包名 `dev.ricky.galaxywatchmanagerfree`、版本号与发布签名证书 SHA-256（`86de4a33245393411b43ad0d4fa99233f0ca6f926cef6f60982eac9eba3f1525`）一致。

### 5.9 设置体系与双轨自诊断日志
- **78+ 项手表设置 Schema (`feature/WatchSettingSchema.kt`)**：
  - 声明式覆盖显示、声音与振动、按钮手势、高级辅助功能、通用等手表设置。
  - 写入操作自动生成重试命令，待手表回读确认后同步 UI。
- **双轨循环日志 (`feature/LogBus.kt` / `feature/DiagnosticLogStore.kt`)**：
  - 内存中分轨维护运行日志（`lines`，最近 300 条，记录业务关键结果与异常）与调试日志（`debugLines`，最近 300 条，由 `watchfree_logging.xml` 的 `debug_enabled` 开关控制，记录协议帧细节与异常堆栈）。
  - 磁盘侧由 `DiagnosticLogStore` 单线程顺序落盘至 `files/watchfree.log` 与单份轮转备份 `files/watchfree.previous.log`（每文件上限 2 MiB，超限自动轮转，杜绝无限制膨胀）；开启调试日志时与运行日志按时间序写入同一轮转对；导出时聚合输出至 `cache/log_exports/`（24 小时自动清理）。
  - 敏感字段脱敏 (`feature/DiagnosticValue.kt`)：蓝牙 MAC、`wear://<node>/` 节点 URI、带 `node=` / `imei=` / `eid=` 等键的敏感值（含中文标点定界）、联系人、通知内容与私钥自动替换为掩码。

### 5.10 手机能量得分计算与手表写回
- **入口与操作 (`ui/screens/EnergyScoreSheet.kt` / `ui/WatchPageState.kt`)**：
  - 健康页能量得分卡片与详情面板通过 `WatchPage.HEALTH` 投影订阅 `energyProfile`、`energyScores` 与 `energyScoreSyncStatus`，显示总分、进度条、睡眠/前一日活动/睡眠心率/睡眠 HRV 分项进度及逐日历史（高亮当前选中日期）。当最新结算结果不是今天时，健康页卡片会附带短日期（如 `极佳 · 11月24日`），避免误判为当日分数。
  - 面板把“计算资料”独立成专属卡片，并将“保存资料”和“计算”分开：首次填写支持年龄（18–99）± 步进微调与数字输入、越界即时校验以及带明确标签的生理性别双栏选择卡片；保存成功后自动切回**已保存资料摘要视图**，直接展示已保存的年龄、生理性别与“已保存”标识，并可随时点按“编辑”修改（编辑期间仍展示当前已保存摘要及未保存变更提示）。
  - 资料作为当前设备作用域的独立值持久化（`EnergyScoreProfile`，键 `energy_profile`），不依赖是否成功算出结果；重新打开面板或重启应用后自动恢复并展示已保存资料，无需重复填写。旧版本仅在成功结果 `inputs` 中留下的 `profile_age`/`profile_sex` 会在恢复时迁移并保存。
  - 保存资料、手动计算与历史写回都在后台执行，等待 ACK 时禁止重复操作。同步卡片的应答状态按当前选中记录已持久化的 `acknowledged` 与活跃写回状态联合展示，重启后与顶部卡片及历史列表保持一致；当选中日期不是今天时，明确提示手表主界面仅展示今天的能量得分，历史日期写入手表后用于较昨日变化与 7 天趋势。
- **自动结算**：启动恢复、健康报文成功落盘、本机睡眠分析完成与补记午休变化后会延迟约 5 秒合并触发本机结算；用户显式保存资料后立即触发后台结算（不等待 5 秒防抖），仅当结果变化时落盘。自动结算**不**自动写回手表，写回仍只由用户显式操作。
- **计算边界 (`feature/EnergyScoreCalculator.kt`)**：
  - 算法标识 `phone_vitality_v1`，按已核对官方公式实现分数重映射、总分权重（活动 19%、睡眠心率 31%、睡眠 HRV 13%、睡眠 37%）、睡眠储备积分、小睡加分、活动 EMA 和生理基线。
  - 输入来自留存睡眠及已有有效分期、与非小睡区间重叠的心率与 RMSSD、每日活动时长；不将 SDNN 当 RMSSD，不使用皮温。当手表固件省略日汇总（`pedometer_day_summary` / `activity.day_summary`）时，自动按官方手机端规则由 `pedometer_step_count.duration` + 非重叠 `exercise.duration` 合成每日活动时长（`< 60_000 ms` 归零，无记录日期保持缺失），并在 `inputs.activity_input` / `inputs.activity_synthesized_dates` 中记录来源；小睡识别兼顾 `is_nap`、`nap_score > 0` 及按记录醒来日取最长非手动睡眠。缺少必要输入时跳过该日期，不补造总分；可选缺失指标在本机结果中保持 null。
  - `calculateWithReport` 返回逐日缺失报告：候选日期、近 30 天已结算天数，以及每个未结算日期缺失的原因（无主睡眠、缺分期、缺前日活动、前日活动为零、无睡眠心率、无有效 RMSSD、因子无效）。`HealthRepository` 在数据不全时输出运行 ERROR 日志（类别与计数，不含实际年龄/性别或原始读数），便于调试；数据完整时输出普通日志。
  - 本机适配并未证明与官方完整管线等价：28 日 EMA 窗口内缺日采用算法零负荷，原始缺失仍未改成测量零。输入记录保留这些规则、年龄/性别、引用身份与 `official_equivalence_verified=false`，不能将结果宣传为官方原算值。
- **留存与修订 (`feature/EnergyScoreLog.kt` / `HealthRepository`)**：
  - 结果随当前配对设备健康缓存保存，保留来源 `phone_computed`、算法、输入、值、时区、UUID 与创建/修订时间。同日期同算法更新保留记录身份，值未变不增加修订；落盘失败回滚。全部留存结果纳入 Health Export v7；当前资料另以 `energy_profile.json`（零或一条、`source=user_entered`）随导出。
- **写回状态 (`feature/EnergyScoreSync.kt` / `WatchRepository`)**：
  - 经现有 RFCOMM/WCS `/samsung_health/wearable_message` 下发 `SYNC_DATA` 中的 `com.samsung.shealth.vitality_score`，不依赖 Google Wear app 或诊断 GMS 适配器。字段与投影规则见 [PROTOCOL-SPEC.md §6.6.10](PROTOCOL-SPEC.md)。
  - 点击“写回手表”时通过 `EnergyScoreLog.watchSyncRows` 打包**当前选中记录 + 手表 7 天查询窗口（`today - 6 天 .. today`）内全部含真实 `deviceuuid` 的已有得分**一并下发，匹配手表端 `k(7)` 能力与较昨日差值 / 7 天趋势展示，并由 `LogBus` 记录不含分数与设备标识的安全同步日志（序号、条数、日期列表与应答结果）。
  - 按序号、消息类型与收发方匹配应答；处理发送失败、拒绝、30 秒超时、替换、断线与 ACK 元数据落盘失败。成功应答只确认对应已发送修订，不证明手表显示、实际入库或重启持久化。
- **验收状态**：本地合成回归和构建已通过；真机联调（`HONOR BKQ-AN90` + `Galaxy Watch Ultra SM-L7050`）已确认资料保存/展示/冷重启恢复，且手表 `VitalityActivity` / `VitalityDataProvider` 实际读出手机写回的 `dataVersion=4` 能量得分行（含总分、分项、7 项因子与睡眠心率/HRV 基线）；同时确认手表所有展示入口仅在存在“今天”的 `day_time` 记录时显示主视图，否则进入无数据视图。当日主视图实机展示与手表重启后持久化仍需在产生当日新主睡眠后进一步验收。

---

## 6. 数据存储布局与持久化规范

设备级健康数据、配对身份、设备快照、小睡与免打扰状态均按配对设备 MAC（无冒号小写，见 `DeviceScope`）隔离，防止多手表用户数据交织；`backup_rules.xml` 与 `data_extraction_rules.xml` 仅允许 `watchfree_theme.xml` 参与 Android 云备份与设备迁移，其余配对凭据、健康数据与诊断日志均保留在本地私有存储：

```
/data/data/dev.ricky.galaxywatchmanagerfree/
├── shared_prefs/
│   ├── watchfree.xml                          # WatchController 全局连接偏好（watch_mac、enabled、forward_notifications、auto_connect）
│   ├── watchfree_theme.xml                    # ThemeController 外观主题设置（唯一纳入自动备份）
│   ├── page_layout.xml                        # PageLayoutController 页面布局配置
│   ├── watchfree_logging.xml                  # LogBus 调试日志开关（debug_enabled）
│   ├── watchfree_sync.xml                     # WatchRepository 定时健康同步开关与周期
│   ├── watchfree_update.xml                   # UpdateChecker 更新通道、检查时间与下载镜像
│   ├── watchfree_onboarding.xml               # OnboardingController 引导状态
│   ├── watchfree_notification_bar.xml         # NotificationBarPreferences 状态栏常驻通知配置
│   ├── watchfree_notification_filter.xml      # NotificationFilterPreferences 通知白名单与使用手机静音规则
│   ├── watchfree_aliases.xml                  # WatchRepository 按 MAC 保存的手表昵称
│   ├── watchfree_device_migration.xml         # DevicePreferences v0.0.9 旧缓存归属迁移记录
│   ├── watchfree_official_handover.xml        # HandoverSnapshotStore 官方应用交接前包状态快照与事务记录
│   ├── health_measurements.xml                # HealthMeasurements 手表测量采集开关状态与修订
│   ├── watchfree_pairing_<MAC>.xml            # DeviceIdentityStore 按 MAC 隔离的已确认/候选节点身份与 SHM 证书记忆
│   ├── watchfree_health_<MAC>.xml             # HealthRepository 按 MAC 隔离的健康摘要缓存、目标、ECG/BP、能量得分及独立资料（energy_profile）
│   ├── watchfree_manual_naps_<MAC>.xml        # ManualNapStore 按 MAC 隔离的本机小睡补记
│   ├── watchfree_sleep_analysis_<MAC>.xml     # LocalSleepAnalyzer 按 MAC 隔离的本机睡眠分期缓存
│   ├── watchfree_dnd_<MAC>.xml                # WatchRepository 按 MAC 隔离的免打扰待提交状态（键 submitted，兼容旧 watchNode 键读取）
│   └── watchfree_device_<MAC>.xml             # WatchRepository 按 MAC 隔离的设备状态快照（DeviceSnapshot，兼容旧 watchfree_device_<watchNode>.xml 单向迁移）
├── files/
│   ├── health-records_<MAC>.json              # HealthRecordFileStore 按 MAC 隔离的原始健康记录原子文件（升级自动迁移自 watchfree_health_<MAC>.xml）
│   ├── health-records_<MAC>_recovery.json     # 仅在原始记录损坏时保留的未替换恢复副本（纳入导出 retained_cache.json）
│   ├── watchfree.log                          # DiagnosticLogStore 当前诊断日志（≤2 MiB）
│   ├── watchfree.previous.log                 # DiagnosticLogStore 上一份轮转日志（≤2 MiB）
│   ├── wear-data-<phoneNode>_<watchNode>.json # WcsSession 本地 DataItem 状态与同步游标
│   ├── wear-assets/<phoneNode>_<watchNode>/   # WearAssetStore 有界持久化的 WearAsset 二进制附件（≤64 文件 / 32 MiB）
│   └── health-debug.json                      # 仅由 ADB WatchCommandReceiver health_dump 按需导出
├── code_cache/
│   └── sleep-engine-<sha256_16>/              # LocalSleepAnalyzer 按包内摘要解压的端侧睡眠推理 engine.jar 与 ABI .so
└── cache/
    ├── map_tiles/                             # MapTileHttp 天地图 WMTS 瓦片 OkHttp 磁盘缓存（≤32 MiB）
    ├── updates/                               # ApkUpdater 增量下载与验签 APK 暂存目录（经 FileProvider 唤起安装）
    ├── health_exports/                        # HealthExportSettings 分享用临时 ZIP 归档（24 小时自动清理）
    └── log_exports/                           # LogBus 导出的临时诊断日志文本（24 小时自动清理）
```

---

## 7. 后续功能变动回补要求 (开发者与智能体必须遵循)

为防止文档与代码实现脱节，项目立下如下强制维护规范：

1. **同变更回补要求**：
   - 任何涉及协议增改、核心控制流重构、健康数据模型更新、地图/轨迹能力变动、通知与交接逻辑变动，**必须在同一个 Commit / PR 中同步更新本文档对应的章节**。
2. **健康导出强联动**：
   - 任何健康字段或持久化结构的增删，必须同时同步更新 `docs/HEALTH-EXPORT.md`、`HealthExportSnapshot`、标准化 JSON 以及导出单元测试。
3. **既有兼容常量保护**：
   - 严禁随意清理 `feature_exchange` 中的三星兼容身份参数；清理任何历史硬编码前必须在文档与测试中完整评估其对非三星手机兼容性的影响。
4. **门禁与测试底线**：
   - 代码提交前必须通过：
     - `./gradlew :app:spotlessCheck`
     - `./gradlew :app:testDebugUnitTest` (本次工作区 891 项单元测试全部通过)
     - `./gradlew :app:lintDebug` (0 Errors)
     - `./gradlew :app:assembleRelease`
     - `python3 scripts/check-i18n.py` (本次工作区双语 1552 项资源全量对应)
     - `python3 scripts/check_public_assets.py --apk app/build/outputs/apk/release/app-release-unsigned.apk`
     - `python3 -m unittest discover -s scripts/tests -v`
