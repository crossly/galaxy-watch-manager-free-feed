package dev.ricky.galaxywatchmanagerfree.feature

import dev.ricky.galaxywatchmanagerfree.wcs.WcsPaths
import java.io.ByteArrayOutputStream
import java.util.Base64
import java.util.zip.GZIPOutputStream
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class EnergyScoreSyncTest {
    @Test
    fun `sync preserves row identity nulls and revisions and waits for the matching response`() =
        runTest {
            val sent = mutableListOf<JSONObject>()
            val statuses = mutableListOf<EnergyScoreSync.Status>()
            val accepted = mutableListOf<JSONObject>()
            val sync =
                EnergyScoreSync(
                    this,
                    { "synthetic-watch" },
                    { "synthetic-phone" },
                    {
                        sent.add(it)
                        true
                    },
                    statuses::add,
                    { rows, _ ->
                        accepted.addAll(rows)
                        true
                    },
                    { 42L },
                )
            val row = row().put("shr_value", JSONObject.NULL)
            assertTrue(sync.push(listOf(row)))
            row.put("total_score", 1)
            val packet = sent.single()
            assertEquals(WcsPaths.HEALTH_PHONE_SYNC, packet.getString("sender"))
            assertEquals("synthetic-watch", packet.getString("destination_node"))
            val body = HealthJson.entries(packet.getString("body"))
            val written =
                body.getJSONObject(2).getJSONArray(EnergyScoreSync.MODULE).getJSONObject(0)
            assertEquals(81.5, written.getDouble("total_score"), 0.0)
            assertEquals("synthetic-score", written.getString("datauuid"))
            assertEquals(17L, written.getLong("update_time"))
            assertTrue(written.isNull("shr_value"))
            assertEquals(EnergyScoreSync.Status.WAITING_ACK, statuses.last())
            assertTrue(accepted.isEmpty())
            val sequence = packet.getInt("sequence_num")
            assertFalse(sync.handleMessage(ack(sequence + 1)))
            assertFalse(sync.handleMessage(ack(sequence).put("sender", "other-service")))
            assertFalse(sync.handleMessage(ack(sequence).put("receiver", "other-service")))
            assertTrue(sync.handleMessage(ack(sequence, action = "REQUEST_DATA")))
            assertTrue(accepted.isEmpty())
            assertTrue(sync.handleMessage(ack(sequence)))
            assertEquals(EnergyScoreSync.Status.ACCEPTED, statuses.last())
            assertEquals(81.5, accepted.single().getDouble("total_score"), 0.0)
            assertFalse(sync.handleMessage(ack(sequence)))
        }

    @Test
    fun `replaced request disconnect and timeout cannot accept a late response`() = runTest {
        val sent = mutableListOf<JSONObject>()
        val statuses = mutableListOf<EnergyScoreSync.Status>()
        var accepted = 0
        val sync =
            EnergyScoreSync(
                this,
                { "watch" },
                { "phone" },
                {
                    sent.add(it)
                    true
                },
                statuses::add,
                { _, _ ->
                    accepted++
                    true
                },
                timeoutMillis = 100,
            )
        assertTrue(sync.push(listOf(row())))
        runCurrent()
        val first = sent.last().getInt("sequence_num")
        assertTrue(sync.push(listOf(row().put("update_time", 18))))
        runCurrent()
        assertFalse(sync.handleMessage(ack(first)))
        val second = sent.last().getInt("sequence_num")
        advanceTimeBy(100)
        runCurrent()
        assertEquals(EnergyScoreSync.Status.TIMED_OUT, statuses.last())
        assertFalse(sync.handleMessage(ack(second)))
        assertTrue(sync.push(listOf(row())))
        runCurrent()
        val third = sent.last().getInt("sequence_num")
        sync.disconnect()
        assertFalse(sync.handleMessage(ack(third)))
        advanceTimeBy(100)
        runCurrent()
        assertEquals(EnergyScoreSync.Status.DISCONNECTED, statuses.last())
        assertEquals(0, accepted)
    }

    @Test
    fun `failed send rejection and malformed body never become accepted`() = runTest {
        val sent = mutableListOf<JSONObject>()
        val statuses = mutableListOf<EnergyScoreSync.Status>()
        var canSend = false
        var accepted = 0
        val sync =
            EnergyScoreSync(
                this,
                { "watch" },
                { "phone" },
                {
                    sent.add(it)
                    canSend
                },
                statuses::add,
                { _, _ ->
                    accepted++
                    true
                },
                timeoutMillis = 100,
            )
        assertFalse(sync.push(listOf(row())))
        assertEquals(EnergyScoreSync.Status.SEND_FAILED, statuses.last())
        canSend = true
        assertTrue(sync.push(listOf(row())))
        val sequence = sent.last().getInt("sequence_num")
        assertTrue(sync.handleMessage(ack(sequence).put("body", "malformed")))
        assertEquals(EnergyScoreSync.Status.WAITING_ACK, statuses.last())
        assertTrue(sync.handleMessage(ack(sequence, result = "FAIL")))
        assertEquals(EnergyScoreSync.Status.REJECTED, statuses.last())
        assertEquals(0, accepted)
    }

    @Test
    fun `diagnostic logging reports safe date summaries without leaking scores or device ids`() =
        runTest {
            val sent = mutableListOf<JSONObject>()
            val logs = mutableListOf<String>()
            val errors = mutableListOf<String>()
            val sync =
                EnergyScoreSync(
                    scope = this,
                    watchNode = { "watch" },
                    deviceModel = { "phone" },
                    send = {
                        sent.add(it)
                        true
                    },
                    onStatus = {},
                    onAccepted = { _, _ -> true },
                    timeoutMillis = 100,
                    onLog = logs::add,
                    onError = errors::add,
                )
            val row =
                row()
                    .put("deviceuuid", "secret-watch-uuid-12345")
                    .put("day_time", 1_795_478_400_000L) // 2026-11-24 UTC
            assertTrue(sync.push(listOf(row)))
            assertTrue(logs.last().contains("rows=1"))
            assertTrue(logs.last().contains("2026-11-24"))
            assertFalse(logs.last().contains("secret-watch-uuid"))
            assertFalse(logs.last().contains("81.5"))

            val seq = sent.last().getInt("sequence_num")
            assertTrue(sync.handleMessage(ack(seq)))
            assertTrue(logs.last().contains("手表已应答"))
            assertTrue(logs.last().contains("2026-11-24"))
            assertTrue(errors.isEmpty())

            assertTrue(sync.push(listOf(row)))
            val seq2 = sent.last().getInt("sequence_num")
            assertTrue(sync.handleMessage(ack(seq2, result = "VALIDATION_ERROR")))
            assertTrue(errors.last().contains("VALIDATION_ERROR"))
        }

    private fun row() =
        JSONObject()
            .put("datauuid", "synthetic-score")
            .put("update_time", 17L)
            .put("day_time", 1_700_006_400_000L)
            .put("total_score", 81.5)

    private fun ack(
        sequence: Int,
        result: String = "SUCCESS",
        action: String = "SYNC_DATA",
    ): JSONObject {
        val body =
            JSONArray()
                .put(
                    JSONObject()
                        .put(
                            "message_info",
                            JSONArray()
                                .put(JSONObject().put("action", action).put("result", result)),
                        )
                )
        val output = ByteArrayOutputStream()
        GZIPOutputStream(output).use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        return JSONObject()
            .put("sequence_num", sequence)
            .put("message", WcsPaths.HEALTH_MSG_RESPONSE)
            .put("type", WcsPaths.HEALTH_TYPE_DATA)
            .put("sender", WcsPaths.HEALTH_WATCH_SYNC)
            .put("receiver", WcsPaths.HEALTH_PHONE_SYNC)
            .put("body", Base64.getEncoder().encodeToString(output.toByteArray()))
    }
}
