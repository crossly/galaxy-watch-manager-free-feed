package dev.ricky.galaxywatchmanagerfree.wcs

import dev.ricky.galaxywatchmanagerfree.feature.NotificationIdentity

internal class BridgerNotificationSender(
    private val log: (String) -> Unit = {},
    private val sendFrame: (ByteArray) -> Boolean,
) {
    enum class Result(val queued: Boolean) {
        REJECTED(false),
        TEXT_ONLY(true),
        WITH_ICON(true),
    }

    @Synchronized
    fun send(
        phoneNode: String,
        identity: NotificationIdentity,
        title: String,
        text: String,
        appName: String?,
        whenMillis: Long,
        seqId: Long,
        appIcon: ByteArray?,
        allowTextFallback: Boolean = true,
    ): Result? {
        if (phoneNode.isBlank()) return Result.REJECTED
        val digest =
            when {
                appIcon == null || appIcon.isEmpty() -> null
                appIcon.size > MAX_ICON_BYTES -> {
                    log("[通知图标] package=${identity.packageName} 超出大小上限 bytes=${appIcon.size}")
                    null
                }
                else -> {
                    val assetDigest = WcsFrame.messageDigest(appIcon)
                    val queued = sendIcon(appIcon, assetDigest)
                    log(
                        "[通知图标] package=${identity.packageName} digest=$assetDigest bytes=${appIcon.size} assetQueued=$queued"
                    )
                    assetDigest.takeIf { queued }
                }
            }
        if (digest == null && !allowTextFallback) return null
        val data =
            linkedMapOf<String, Any>(
                "R_c,0" to 1L,
                "R_c" to 1L,
                "title_raw" to title,
                "text_raw" to text,
                "priority" to 1,
                "notification_flags" to 0,
                "user_id" to identity.userId,
                "when" to whenMillis,
                "show_when" to true,
                "defaults" to 2,
                "has_sound" to true,
                "app_name" to (appName ?: identity.packageName),
                "from" to "phone",
            )
        if (digest != null) data["app_icon"] = DataMapEncoder.AssetReference(0)
        val queued =
            sendFrame(
                WcsFrame.wearPathFrame(
                    path = "wear://$phoneNode/${identity.bridgerPath(phoneNode)}",
                    dataItems = listOf(DataMapEncoder.encode(data)),
                    senderPkg = SENDER_PACKAGE,
                    nodeId = phoneNode,
                    seqId = seqId,
                    assets = if (digest == null) emptyMap() else mapOf("0" to digest),
                )
            )
        return when {
            !queued -> Result.REJECTED
            digest == null -> Result.TEXT_ONLY
            else -> Result.WITH_ICON
        }
    }

    private fun sendIcon(bytes: ByteArray, digest: String): Boolean {
        val target = Proto.string(1, SENDER_PACKAGE) + Proto.string(2, WcsPaths.SIGNATURE_PLUGIN)
        val asset = Proto.string(1, digest) + Proto.bytes(2, Proto.bytes(1, target))
        val header = Proto.bytes(4, asset) + Proto.integer(13, 1)
        val messageId = WcsFrame.messageDigest(header)
        val queue = if (bytes.size <= 32768) 5L else 6L
        if (!sendFrame(WcsFrame.envelope(header, messageId, type = queue))) return false
        for (offset in bytes.indices step FILE_PIECE_BYTES) {
            val end = minOf(bytes.size, offset + FILE_PIECE_BYTES)
            val last = end == bytes.size
            val piece =
                Proto.string(1, messageId) +
                    Proto.integer(2, if (last) 1 else 0) +
                    Proto.bytes(3, bytes.copyOfRange(offset, end)) +
                    if (last) Proto.string(4, digest) else byteArrayOf()
            if (!sendFrame(WcsFrame.envelopeNoType(Proto.bytes(12, piece)))) return false
        }
        return true
    }

    companion object {
        const val MAX_ICON_BYTES = 64 * 1024
        private const val FILE_PIECE_BYTES = 12288 - 73
        private const val SENDER_PACKAGE = "com.samsung.android.wcs.extension"
    }
}
