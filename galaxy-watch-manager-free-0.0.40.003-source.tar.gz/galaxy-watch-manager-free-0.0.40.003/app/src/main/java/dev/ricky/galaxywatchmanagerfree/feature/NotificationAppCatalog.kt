package dev.ricky.galaxywatchmanagerfree.feature

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import androidx.core.graphics.drawable.toBitmap
import java.text.Collator

data class NotificationApp(val packageName: String, val label: String)

object NotificationAppCatalog {
    @Suppress("DEPRECATION")
    fun load(context: Context, extraPackages: Set<String>): List<NotificationApp> {
        val pm = context.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val packages =
            pm.queryIntentActivities(launcher, 0).map { it.activityInfo.packageName }.toSet() +
                extraPackages
        val collator = Collator.getInstance(context.resources.configuration.locales[0])
        return packages
            .filter { it != context.packageName }
            .map { packageName ->
                val label =
                    try {
                        pm.getApplicationLabel(pm.getApplicationInfo(packageName, 0)).toString()
                    } catch (_: PackageManager.NameNotFoundException) {
                        packageName
                    }
                NotificationApp(packageName, label)
            }
            .sortedWith(compareBy(collator) { it.label })
    }

    @androidx.annotation.WorkerThread
    fun forwardingIcon(context: Context, packageName: String): ByteArray? =
        try {
            val bitmap = icon(context, packageName)
            if (bitmap == null) {
                LogBus.debug { "[通知图标] 无法读取应用图标 package=$packageName" }
                null
            } else {
                val output = java.io.ByteArrayOutputStream()
                if (bitmap.compress(Bitmap.CompressFormat.PNG, 100, output)) {
                    output.toByteArray()
                } else {
                    LogBus.debug { "[通知图标] PNG 编码失败 package=$packageName" }
                    null
                }
            }
        } catch (e: RuntimeException) {
            LogBus.debug { "[通知图标] 编码失败 package=$packageName type=${e.javaClass.simpleName}" }
            null
        }

    fun icon(context: Context, packageName: String): Bitmap? =
        try {
            context.packageManager.getApplicationIcon(packageName).toBitmap(96, 96)
        } catch (_: PackageManager.NameNotFoundException) {
            null
        }
}
