package dev.ricky.galaxywatchmanagerfree.feature

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import dev.ricky.galaxywatchmanagerfree.core.WatchController
import java.time.LocalTime
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch

/**
 * 抓取手机通知并转发到手表。
 *
 * 通过 Wear OS Bridger 的 wear://<phoneNode>/bridger/stream_item:* DataItem 下发。
 */
class NotificationBridgeService : NotificationListenerService() {

    private val forwarded = NotificationForwardingCache()

    private data class Event(
        val notification: StatusBarNotification,
        val target: Any? = null,
        val removed: Boolean = false,
    )

    private val events = Channel<Event>(64)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        scope.launch {
            for (event in events) {
                try {
                    if (event.removed) forwarded.remove(event.notification.key)
                    else forwardNotification(event.notification, event.target)
                } catch (e: RuntimeException) {
                    LogBus.debug { "[通知] 处理失败 type=${e.javaClass.simpleName}" }
                }
            }
        }
    }

    override fun onDestroy() {
        NotificationListenerRecovery.onListenerDisconnected(this)
        events.cancel()
        scope.cancel()
        super.onDestroy()
    }

    private fun enqueue(event: Event) {
        if (events.trySend(event).isFailure) LogBus.debug { "[通知] 处理队列已满或服务已停止" }
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        NotificationListenerRecovery.onListenerConnected(this)
        LogBus.log("通知监听已连接")
        WatchController.repository.syncNotificationFeatures()
        activeNotifications?.forEach {
            if (it.packageName != packageName) {
                NotificationFilterPreferences.noteObserved(it.packageName)
            }
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn?.let { enqueue(Event(it, target = WatchController.repository.notificationSession)) }
    }

    @androidx.annotation.WorkerThread
    private fun forwardNotification(s: StatusBarNotification, target: Any?) {
        val n = s.notification ?: return
        if (s.packageName != packageName) NotificationFilterPreferences.noteObserved(s.packageName)
        if (!WatchController.forwardNotifications) {
            LogBus.debug { "通知跳过 [${s.packageName} id=${s.id}]: 全局通知转发未开启" }
            return
        }
        if (s.packageName == packageName) {
            LogBus.debug { "通知跳过 [${s.packageName} id=${s.id}]: 自身应用事件" }
            return
        }

        val extras =
            n.extras
                ?: run {
                    LogBus.debug { "通知跳过 [${s.packageName} id=${s.id}]: 缺少 extras" }
                    return
                }
        // 跳过正在进行的（音乐播放器等常驻通知）与分组摘要
        if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) {
            LogBus.debug { "通知跳过 [${s.packageName} id=${s.id}]: 常驻进行中通知 (ONGOING)" }
            return
        }
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) {
            LogBus.debug { "通知跳过 [${s.packageName} id=${s.id}]: 分组摘要通知 (GROUP_SUMMARY)" }
            return
        }
        val isClearable =
            n.flags and Notification.FLAG_AUTO_CANCEL != 0 ||
                n.flags and Notification.FLAG_NO_CLEAR == 0
        if (!isClearable) {
            LogBus.debug { "通知跳过 [${s.packageName} id=${s.id}]: 不可清除通知 (NO_CLEAR)" }
            return
        }

        if (!NotificationFilterPreferences.config.value.allows(s.packageName)) {
            LogBus.debug { "通知跳过 [${s.packageName} id=${s.id}]: 不在允许应用列表" }
            return
        }

        if (!NotificationFilterPreferences.schedule.value.allows(LocalTime.now())) {
            LogBus.debug { "通知跳过 [${s.packageName} id=${s.id}]: 不在启用推送时间段" }
            return
        }

        if (
            NotificationFilterPreferences.muteWhileUsingPhone.value &&
                PhoneStatusDetector.isPhoneActive(this)
        ) {
            LogBus.debug { "通知跳过 [${s.packageName} id=${s.id}]: 手机正在使用中 (USING_PHONE)" }
            return
        }

        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text =
            (extras.getCharSequence(Notification.EXTRA_TEXT)
                    ?: extras.getCharSequence(Notification.EXTRA_BIG_TEXT))
                ?.toString()
                .orEmpty()
        if (title.isBlank() && text.isBlank()) {
            LogBus.debug { "通知跳过 [${s.packageName} id=${s.id}]: 标题与内容均为空" }
            return
        }

        val uid =
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) s.uid
            else
                s.key.substringAfterLast('|').toIntOrNull()
                    ?: run {
                        LogBus.debug { "通知跳过 [${s.packageName} id=${s.id}]: 无法解析 uid" }
                        return
                    }
        val repository = WatchController.repository
        if (target == null || repository.notificationSession !== target) return
        forwarded.forward(target, s.key, "$title\u0000$text") { allowTextFallback ->
            if (repository.notificationSession !== target) return@forward null
            repository.postNotification(
                packageName = s.packageName,
                title = title,
                body = text,
                tag = s.tag ?: "",
                time = n.`when`.takeIf { it > 0 } ?: s.postTime,
                identity = NotificationIdentity(s.packageName, s.id, s.tag, s.userId, uid),
                allowTextFallback = allowTextFallback,
            )
        }
    }

    override fun onListenerDisconnected() {
        NotificationListenerRecovery.onListenerDisconnected(this)
        LogBus.log("通知监听已断开")
        super.onListenerDisconnected()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        val s = sbn ?: return
        enqueue(Event(s, removed = true))
        LogBus.debug { "通知已移除：[${s.packageName}] id=${s.id}" }
    }

    companion object {
        fun shouldSkipDueToPhoneActive(
            muteWhileUsingPhone: Boolean,
            isPhoneActive: Boolean,
        ): Boolean = muteWhileUsingPhone && isPhoneActive
    }
}
