package dev.ricky.galaxywatchmanagerfree.feature

import dev.ricky.galaxywatchmanagerfree.wcs.WcsPaths
import java.util.Locale
import org.json.JSONObject

/**
 * Samsung Health 能力协商协议信令工厂与常量定义。
 *
 * 逆向自 Samsung Health Wear OS 客户端 (WearableDeviceCapability / AbstractC6878pY0 / C6614oX2 / A93)。
 * Wear OS 4/5 (Galaxy Watch6/7/Ultra) 在健康同步时强制执行 HealthNode 握手： 手表在收到 REQUEST_DATA 时若未就绪，会向手机下发
 * com.samsung.shealth.REQUEST_CAPABILITY； 手机必须响应 com.samsung.shealth.RESPONSE_CAPABILITY，手表接收后创建
 * HealthNode 并刷新同步队列。
 */
object HealthCapability {
    const val REQUEST_CAPABILITY = "com.samsung.shealth.REQUEST_CAPABILITY"
    const val RESPONSE_CAPABILITY = "com.samsung.shealth.RESPONSE_CAPABILITY"
    const val MESSAGE_TYPE_RESPONSE = "com.samsung.android.app.shealth.RESPONSE_CAPABILITY"
    const val PROTOCOL_VERSION = 4.51
    const val SHEALTH_VERSION = 7010053
    const val DEVICE_TYPE_PHONE = 50001
    const val CATEGORY_WATCH = 40001
    const val VASCULAR_LOAD_MIN_VERSION = 1000
    const val VASCULAR_LOAD_RESET_V2_VERSION = 1001
    const val VASCULAR_LOAD_PHONE_VERSION = 1002

    /**
     * Official `lta0.a(deviceType)` mapping to Watch category `40001` (Samsung Health 7.1.0.053).
     */
    private val WATCH_DEVICE_TYPES =
        setOf(
            10019,
            10022,
            10024,
            10038,
            10041,
            10045,
            10046,
            10049,
            10050,
            10053,
            10054,
            10055,
            10056,
            10058,
            10059,
            10063,
        )

    fun isRequest(json: JSONObject): Boolean =
        json.optString("capability_type") == REQUEST_CAPABILITY

    fun isResponse(json: JSONObject): Boolean =
        json.optString("capability_type") == RESPONSE_CAPABILITY

    fun isWatchCategory(json: JSONObject): Boolean {
        if (json.has("category")) {
            val raw = json.opt("category")
            return raw is Number && raw.toInt() == CATEGORY_WATCH
        }
        val deviceType = json.opt("device_type")
        return deviceType is Number && deviceType.toInt() in WATCH_DEVICE_TYPES
    }

    fun vascularLoadVersion(json: JSONObject): Int {
        if (!isWatchCategory(json)) return 0
        val feature =
            json.optJSONObject("tracker_feature")?.optJSONObject("vascular_load_feature")
                ?: return 0
        val rawSupport = feature.opt("vascular_load_support")
        if (rawSupport !is Boolean || !rawSupport) return 0
        val rawVersion = feature.opt("version")
        val version = if (rawVersion is Number) rawVersion.toInt() else return 0
        return if (version >= VASCULAR_LOAD_MIN_VERSION) version else 0
    }

    fun vascularLoadSupported(json: JSONObject): Boolean =
        vascularLoadVersion(json) >= VASCULAR_LOAD_MIN_VERSION

    fun buildRequest(deviceId: String, modelName: String = "Android"): JSONObject =
        buildResponse(deviceId, modelName)
            .put("capability_type", REQUEST_CAPABILITY)
            .put("message_type", "com.samsung.android.app.shealth.REQUEST_CAPABILITY")

    fun buildResponse(deviceId: String, modelName: String = "Android"): JSONObject =
        JSONObject()
            .put("protocol_version", PROTOCOL_VERSION)
            .put("shealth_version", SHEALTH_VERSION)
            .put("message_type", MESSAGE_TYPE_RESPONSE)
            .put("capability_type", RESPONSE_CAPABILITY)
            .put("sender", "shealth")
            .put("receiver", "wearable")
            .put("model_name", modelName)
            .put("device_id", deviceId)
            .put("connection_id", deviceId)
            .put("device_type", DEVICE_TYPE_PHONE)
            .put(
                "config",
                JSONObject()
                    .put("os", "android")
                    .put(
                        "os_version",
                        runCatching { android.os.Build.VERSION.SDK_INT }
                            .getOrNull()
                            ?.takeIf { it > 0 }
                            ?.toString() ?: "34",
                    )
                    .put("country_iso", Locale.getDefault().country.ifBlank { "US" })
                    .put("one_ui_version", -1),
            )
            .put(
                "tracker_feature",
                JSONObject()
                    .put(
                        "vascular_load_feature",
                        JSONObject()
                            .put("version", VASCULAR_LOAD_PHONE_VERSION)
                            .put("vascular_load_support", true),
                    )
                    .put("gender_extended", JSONObject().put("support", true))
                    .put("vitality_score", JSONObject().put("support", true))
                    .put(
                        "ages_feature",
                        JSONObject()
                            .put("version", 1000)
                            .put("ages_support", true)
                            .put("ages_score_processing_support", true),
                    )
                    .put("antioxidant", JSONObject().put("version", 1).put("is_supported", true))
                    .put("sleep_sync", JSONObject().put("support", true))
                    .put("pedometer_sync", JSONObject().put("support_wearable_all_step", true))
                    .put(
                        "dashboard_config_sync",
                        JSONObject().put("version", 1000).put("is_support", true),
                    )
                    .put("deep_link", JSONObject().put("is_support", true)),
            )
            .put("binning", JSONObject().put("pedometer", 4).put("sleep", 10))
            .put(
                "protocol_feature",
                JSONObject()
                    .put("wearable_messaging", true)
                    .put("compression", true)
                    .put("sync_duration", 30)
                    .put("wm_chunk_size", 10000)
                    .put("blob_compression", true),
            )
            .put("compression", JSONObject().put("format", "gzip"))
            .put("sync_address", JSONObject().put("common_sync", WcsPaths.HEALTH_PHONE_SYNC))
            .put(
                "wearable_message",
                JSONObject()
                    .put("message_version", 5.03)
                    .put("message_support", true)
                    .put("message_compression", true)
                    .put("message_compression_format", "gzip")
                    .put("message_size", 10000),
            )
}
