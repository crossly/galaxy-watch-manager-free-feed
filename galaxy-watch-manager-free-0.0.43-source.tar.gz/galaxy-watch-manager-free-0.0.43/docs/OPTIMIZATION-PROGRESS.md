# v0.0.9 审查后的优化进度

基线 `9e263c1`，对应审查见 [REVIEW-0.0.9.md](REVIEW-0.0.9.md)。本轮保持版本号 0.0.9，
使用同签名 preview 做回归；没有发布新版本。不是把下表所有项目都宣称完全关闭。

## 0.0.42 正式版发布（2026-11-25）

- **范围与说明**：正式版汇总 `0.0.41.001` Nightly 及后续修复（含 `b70e8fa`、`d731160`、`28b6e93`），覆盖健康监测器（心电图 / 血压）双身份握手与元数据同步、健康能力协商与 `deleted_data` 墓碑同步、WCS/RFCOMM 断连与节点恢复、官方应用交接双语化、存储/缓存优化、健康导出 v7，以及能量得分展示、无日汇总活动合成、资料页重构与近 7 天窗口手表写回。`docs/RELEASE-NOTES.md` 增加精简版 `## 0.0.42` 章节（518 字符 / 1,235 字节，完整落在更新源 1,000 字符上限内，无截断）；`release-notes.py --tag v0.0.42 --check` 与 `--check-nightlies` 通过。
- **发布流程**：代码提交 `28b6e93`、发布说明提交 `8e382cd`；`./scripts/release.sh`（正式版通道）生成发布提交 `d50da86` 并推送附注标签 `v0.0.42`，版本 `0.0.42` / `42000`。GitHub Actions 的 CI 与 Release 仍在作业启动前失败（与既有账户付款/支出上限限制一致），按 Release 工作流相同步骤本地复刻：升版本后重新 `./gradlew :app:spotlessCheck :app:testDebugUnitTest :app:lintDebug :app:assembleRelease`，`scripts/sign-apk.sh` 正式签名、`check_public_assets.py`、`package-source.py`、`gh release create` 与 `publish-update-feed.sh`。
- **门禁**：Spotless、891 项 JVM 单测（0 失败 / 0 错误 / 0 跳过）、Lint（0 Errors / 148 Warnings）、Release 构建、1,552 项双语资源、97 项脚本回归与公开资源检查全部通过。
- **Release 核验**：非草稿正式版（`draft=false`、`prerelease=false`，`releases/latest` 指向 `v0.0.42`，标题「Galaxy Watch Manager Free 0.0.42」），正文与 `release-notes.py --tag v0.0.42` 逐字一致且仅含一个 `##` 标题。APK 35,263,408 字节，SHA-256 `a67b5b2e19efd4bfcd674457a097ea146d8dcfcb8d7a62ec6ee5dd2fb1f00890`；源码归档 5,877,959 字节，SHA-256 `eb8bc8c2c2a9cde7aaf93314f6c100c333e988ee7af69f77b1f688647fdb10c4`。`aapt2` 确认包名 `dev.ricky.galaxywatchmanagerfree`、版本 `0.0.42` / `42000`（minSdk 26、targetSdk 35）；`apksigner` v2/v3 通过，证书 SHA-256 `86de4a33245393411b43ad0d4fa99233f0ca6f926cef6f60982eac9eba3f1525` 与正式证书一致。
- **源码交付与通道隔离**：`version.json` 更新为 `0.0.42` / `42000`，`notes` 完整保留全部 518 字符未截断，`published_at` 为 `2026-11-24T16:39:33Z`；APK 与源码固定到 feed 提交 `fac98c20f8a6e190e09ea3417a3f7bf6ec16813d`，`apk` 分支指向该提交，retained tag 为 `apk-v0.0.42-a67b5b2e…-eb8bc8c2…`；feed `main` 提交 `84b6215` 只修改 `version.json`。Nightly 通道 `nightly.json` 保持 `0.0.41.001` / `41001`（`apk-nightly` 仍指向 `d923a8ed…`）未变。公开 feed 匿名下载 APK 与源码的 SHA-256 与本地产物及 Release 附件逐字节一致。
- **验收边界**：升版本前已在开发机（HONOR 手机 + Watch Ultra）完成能量得分计算展示与近 7 天批量写回手表联调（手表端新增落库并刷新记录列表）；本次发布核验覆盖本地门禁、正式签名打包、GitHub Release 与公开更新源匿名下载逐字节校验，未在手机上安装 `0.0.42` 正式包复测应用内更新卡片及覆盖升级后的全量持久化。

## 0.0.41.001 Nightly 发布（2026-11-23）

- **范围与说明**：修复健康监测器（心电图 / 血压）通道消息被手表 `Mismatched certificate` 拒收。手表 WearableService 按（包名 + 字段 3 证书摘要）投递，手表端 SHM 为平台证书 `9ca5170f…`，此前沿用手机健康证书 `9741a0f3…`，导致 `/plain_connection` 永远到不了监测器；`/plain_connection`、`/991`、`/992`、`/993` 及 ACK 改用 `HealthMonitorProtocol.WATCH_SIGNATURE`，握手 10 秒无应答时切换一次身份并按配对地址记忆生效身份。`docs/RELEASE-NOTES.md` 增加 `## 0.0.41.001 Nightly` 章节，`release-notes.py --check` 通过。
- **发布流程**：`./scripts/release.sh --nightly` 生成发布提交 `652bf6b` 并推送附注标签 `v0.0.41.001`，版本 `0.0.41.001` / `41001`。GitHub Actions 的 CI 与 Release 仍在作业启动前失败（运行日志不可用，与既有账户付款/支出上限限制一致），按 Release 工作流相同步骤本地复刻：升版本后重新 `./gradlew :app:assembleRelease`，`scripts/sign-apk.sh` 正式签名，`check_public_assets.py`、`package-source.py`、`gh release create --prerelease` 与 `publish-update-feed.sh`。
- **门禁**：Spotless、860 项 JVM 单测（0 失败/错误/跳过，新增身份默认值、切换重试与只重试一次三个用例）、Lint（0 Errors / 146 Warnings）、Release 构建、1491 项双语资源、97 项脚本回归与公开资源检查通过。
- **Release 与 feed 核验**：非草稿预发布（`prerelease=true`、`latest=false`），正文与 `release-notes.py --tag v0.0.41.001` 一致。APK 35,173,296 字节，SHA-256 `17cdf8301395cc6e8bdb511e9c58bd1c556bf81db73c292a60d67031740e8a67`；源码归档 5,830,020 字节，SHA-256 `d932c4df509520115f933c200da0005070e54317878cf1184e88fb43f5679386`。`aapt2` 确认包名 `dev.ricky.galaxywatchmanagerfree`、版本 `0.0.41.001` / `41001`；`apksigner` 通过，证书 SHA-256 `86de4a33245393411b43ad0d4fa99233f0ca6f926cef6f60982eac9eba3f1525` 与正式证书一致。`nightly.json` 为 `0.0.41.001` / `41001`，`notes` 非空（1,000 字符上限），`published_at` 为标签提交时间 `2026-11-23T13:47:16+08:00`；APK 与源码固定到 feed 提交 `d923a8e…`，`apk-nightly` 指向该提交，retained tag 为 `apk-v0.0.41.001-17cdf830…-d932c4df…`；feed `main` 提交 `75145e6` 只修改 `nightly.json`。匿名下载的 APK 与本地产物、Release 附件 SHA-256 一致。
- **验收边界**：真机握手与 ECG/BP 同步尚未验证，需在用户设备（vivo + Watch Ultra XBRP）与开发机（HONOR + Ultra 0V4F）分别复测；本次结论只覆盖本地门禁与线上产物核验，不以单测代替真机结果。

## 0.0.41 正式版发布（2026-11-23）

- **范围与说明**：正式版汇总 `0.0.40.001`–`0.0.40.007` 七个 Nightly，并包含本轮新增的「更新源说明为空 / App 内显示 `null`」修复。`docs/RELEASE-NOTES.md` 增加 `## 0.0.41` 章节（5,611 字节），按新增 / 修复整理为发布后的最终行为；`release-notes.py --check` 与 `--check-nightlies` 通过。
- **发布流程**：`./scripts/release.sh`（正式版通道）生成发布提交 `a625e8d` 并推送附注标签 `v0.0.41`，版本 `0.0.41` / `41000`。GitHub Actions 仍因账户支出限制无法启动，按 Release 工作流相同步骤本地复刻：发布脚本先构建后升版本，故升版本后重新 `./gradlew :app:assembleRelease`，再 `scripts/sign-apk.sh` 正式签名、`check_public_assets.py`、`package-source.py` 与 `gh release create`。
- **Release 核验**：非草稿正式版（`prerelease=false`，`releases/latest` 指向 `v0.0.41`），正文与 `release-notes.py --tag v0.0.41` 一致，只含当前版本章节（正文中仅一个 `##` 标题）。APK 35,169,200 字节，SHA-256 `618b0496508d4a44926d5d465c937e52a24300e9c53ce18215a60d4d0f861930`；源码归档 5,824,037 字节，SHA-256 `06f45158885278bcaa9a7414e77e8b42bf43653d0ddd987ab8b958ade9fda661`。`aapt2` 确认包名 `dev.ricky.galaxywatchmanagerfree`、版本 `0.0.41` / `41000`；`apksigner` v2/v3 通过，证书 SHA-256 `86de4a33245393411b43ad0d4fa99233f0ca6f926cef6f60982eac9eba3f1525` 与正式证书一致。
- **源码交付与通道隔离**：`version.json` 更新为 `0.0.41` / `41000`，`notes` 非空（1,000 字符上限），`published_at` 为标签提交时间 `2026-11-23T09:53:36+08:00`；APK 与源码固定到 feed 提交 `618557161f8ad58890eb11bdc0ea50f8ce905a88`，`apk` 分支指向该提交，retained tag 为 `apk-v0.0.41-618b0496…-06f45158…`；feed `main` 提交 `1166c72` 只修改 `version.json`。Nightly 清单 `nightly.json` 保持 `0.0.40.007` / `40007`（SHA-256 `4d8a414c…`）未变。发布时更新源推送遇到一次 `github.com:443` 连接失败，重试后成功，产物未变。
- **验收边界**：已完成线上清单匿名读取与 feed APK / 源码匿名下载逐字节核验（与本地产物 SHA-256 一致）；未在手机安装 `0.0.41`、未重跑界面交互或设备持久化验收。

## 更新源说明为空与显示为 null 的修复（2026-11-23）

- **现象**：公开 feed 的 `nightly.json` 里 `notes` 与 `published_at` 都是 `null`；App 内点“检查更新”后更新卡片把“更新日志”显示成字面量 `null`。
- **根因（两处叠加）**：
  1. `scripts/write-update-feed.py` 只从 GitHub Release 正文取说明，需要 `GH_TOKEN`。GitHub Actions 因账户支出限制无法启动后，`0.0.40.003` 起的 Nightly 全部改为本地发布，没有 token，发布脚本拿到 `None` 就把 `notes` / `published_at` 写成 `null`。
  2. 客户端 `AppUpdate.parseFeed` 用 `org.json` 的 `optString` 取值；设备端实现对 JSON `null` 返回字面量字符串 `"null"`，`ifBlank` 拦不住，于是更新卡片把 `"null"` 当成说明显示。
- **修复**：
  1. 发布脚本在拿不到 Release 正文时，改从仓库内 `docs/RELEASE-NOTES.md` 的当前版本章节取说明（SSOT 本来就在这里），并用标签指向提交的提交时间补 `published_at`；两条路径都不再依赖 token。
  2. 新增 `--from-feed`：对已发布清单只补写 `notes` / `published_at`，保留 APK 与源码地址、摘要和版本字段，用于原地修复。
  3. 客户端统一走 `textOrNull`：缺失、JSON `null`、空白与字面量 `"null"` 一律视为无说明。
- **验证**：`--from-feed` 对线上清单试运行只改动 `notes` 与 `published_at`；脚本回归 97 项、JVM 单元测试 857 项（0 失败）、Spotless 通过；新增用例覆盖无 Release 正文时回落到仓库文档、`--from-feed` 保留产物字段并拒绝版本不匹配、以及字面量 `"null"` 不显示。该客户端修复随 `0.0.40.008` 及后续版本发出，本次未构建新版本的 APK。
- **线上补写**：代码提交 `b899764`；feed `main` 提交 `33fb316` 把 `0.0.40.007` 的 `notes` 补为当前版本章节（1000 字符上限内）并把 `published_at` 补为 `2026-11-23T01:33:25+08:00`，APK/源码地址与 SHA-256 不变。`0.0.40.003`–`0.0.40.006` 的条目已被后续版本覆盖，不再单独补写。
- **验收边界**：已完成线上清单匿名读取核对；未在真机上重装或重新点“检查更新”，卡片显示效果待用户确认。

## 进程重启与手表重连后的通知恢复（2026-11-20，Nightly 0.0.40.003 已发布）

- **恢复断点**：已授权的 Android 通知监听只在少量入口请求一次重绑，服务断开或销毁后没有主动恢复。WCS 在本机就绪时提交桥接特性与通知设置，忽略入队结果。手动打开转发会在后续时点重新提交同组消息。
- **修复**：进程启动、主界面恢复、WCS 就绪与监听断开触发有上限的重绑请求，监听连接后停止。会话就绪、对端 SyncStart 或监听连接触发桥接交换，合并同会话的并发触发，延迟补发并重试入队失败，断开时取消旧会话重试。设置页显示监听实际连接状态。
- **验证**：合成回归先复现首次桥接提交失败后没有第二次提交，修复后覆盖恢复、合并与取消。841 项 JVM 测试、Spotless、Lint（0 错误）、Release 构建、1490 项双语资源及 91 项脚本回归通过。无在线 ADB 设备，未验收进程被杀或蓝牙断线后手表自动收到真实新通知。
- **Nightly 发布核验（0.0.40.003）**：`./scripts/release.sh --nightly` 生成发布提交 `81fde71` 并推送附注标签 `v0.0.40.003`，版本 `0.0.40.003` / `40003`。GitHub Actions 因账户支出限制未能启动，按既定标准本地复刻完整发布流程：`./gradlew :app:assembleRelease`、`scripts/sign-apk.sh` 正式签名、`check_public_assets.py`、`package-source.py` 与 `gh release create` 创建 GitHub 预发布（`prerelease=true`，`latest=false`，名称「Galaxy Watch Manager Free 0.0.40.003」，正文与 `release-notes.py` 一致）。APK 35,161,008 字节，SHA-256 `c880f6718a25beb70553d5ab57e33c888692e759181825d52484d261ab8d56c2`；源码归档 5,799,413 字节，SHA-256 `279d2d7eef99aff8ec0ca6266eee36ea6cf8a3a485c8dd167be408eb3760cce6`。`aapt2` 确认包名 `dev.ricky.galaxywatchmanagerfree`、版本 `0.0.40.003` / `40003`；`apksigner` v2/v3 通过，证书 SHA-256 `86de4a33245393411b43ad0d4fa99233f0ca6f926cef6f60982eac9eba3f1525` 与正式证书一致。
- **源码交付与通道隔离（0.0.40.003）**：`nightly.json` 更新为 `0.0.40.003` / `40003`，APK 与源码固定到 feed 提交 `d1b9a5126614cdd4a0abd7e70494c7e797a25cbf`，`apk-nightly` 分支指向该提交，retained tag 为 `apk-v0.0.40.003-c880f6718a25beb70553d5ab57e33c888692e759181825d52484d261ab8d56c2-279d2d7eef99aff8ec0ca6266eee36ea6cf8a3a485c8dd167be408eb3760cce6`；feed `main` 提交 `5a2b25c` 只修改 `nightly.json`。稳定通道 `version.json` 严格保持 `0.0.40` / `40000` 未变，`releases/latest` 依然指向 `v0.0.40`。公开 feed 匿名下载 APK 与源码摘要与 Release 产物逐字节一致，完整验证记录保存在 `private/release-0.0.40.003-verification`。

## 通知图标回退后的补发修复（2026-11-20）

- **复现与修复**：从 `0.0.38` 到 `0.0.40.002`，来源应用图标提取、V1 附件和通知去重实现均一致。旧逻辑把纯文字入队记为完整成功，同一连接内会丢弃正文未变的后续通知回调。现在缓存区分纯文字和带图标入队，后续回调可沿用原通知身份补发图标，图标仍不可用时省略重复文字。按图标摘要记录附件入队状态，便于关联手表 `AckAsset`。
- **验证**：合成回归先复现附件入队失败后无法补发，再验证队列恢复时使用同一 URI 补发含 `app_icon` 的 DataItem。Spotless、840 项 JVM 回归、Lint（0 错误）、Release 构建、1488 项双语资源与 91 项脚本测试通过。当前无在线 ADB 设备，未确认用户设备上的首条通知缺图原因，也未验收手表实际展示。

## 使用手机时来通知手表不提醒优化（2026-11-20，Nightly 0.0.40.002 已发布）

- **背景与根因**：此前通知转发服务 `NotificationBridgeService` 仅执行全局开关、应用白名单与时间段过滤，未实现官方三星的“手机在使用中时不提醒手表”功能；当用户正在解锁操作手机时，通知依然推送到手表并震动打扰。
- **微创实现**：
  1. `PhoneStatusDetector`：参考官方三星插件 `PhoneStatus.isActive`，基于 `PowerManager.isInteractive && !KeyguardManager.isKeyguardLocked` 判定手机是否正处于点亮且已解锁的活跃使用状态；提供纯逻辑接缝便于单测。
  2. `NotificationFilterPreferences`：新增 `muteWhileUsingPhone` 偏好（默认 `true`，对应官方默认值），持久化在 `watchfree_notification_filter` 中。
  3. `NotificationBridgeService.forwardNotification`：在包名与时间段过滤后接入 `muteWhileUsingPhone && PhoneStatusDetector.isPhoneActive(this)` 判定，活跃使用中直接拦截跳过并输出 `[pkg id]: 手机正在使用中 (USING_PHONE)` 诊断日志。
  4. `WatchRepository`：在 `syncNotificationFeatures` 下发 `notification_settings` 时将 `alerts_on_watch` 与偏好联动（0=开/仅未在使用手机时提醒，1=关/即使使用手机也提醒）；新增 `syncAlertsOnWatch` 单项更新方法；在 `onMessage` 中监听手表反向发回的 `set_settings_alerts_on_watch` 与 `set_settings_alerts_on_watch_while_using_phone` 消息并回写偏好。
  5. 界面与文案：在通知设置页增加“使用手机时不提醒”切换行，补齐中英文双语资源。
- **本地验证**：Spotless、839 项单元测试（0 失败/错误/跳过）、Lint（0 错误）、Release 构建、1488 项双语资源与 91 项脚本回归全部通过；未签名 Release APK 与正式签名 APK 均通过 `check_public_assets.py` 完整资源校验。
- **验收边界**：当前无在线 ADB 设备，真机亮屏/解锁与息屏来通知的手表提醒体验待真机验收。
- **Nightly 发布核验（0.0.40.002）**：`./scripts/release.sh --nightly` 生成发布提交 `37ad5b1` 并推送附注标签 `v0.0.40.002`，版本 `0.0.40.002` / `40002`。GitHub Actions 因账户支出限制未能启动，按既定标准本地复刻完整发布流程：`./gradlew :app:assembleRelease`、`scripts/sign-apk.sh` 正式签名、`check_public_assets.py`、`package-source.py` 与 `gh release create` 创建 GitHub 预发布（`prerelease=true`，`latest=false`，名称「Galaxy Watch Manager Free 0.0.40.002」，正文与 `release-notes.py` 一致）。APK 35,156,912 字节，SHA-256 `643370fc4771251bbe99161a3d3ab2a218df0463b08131b395f487d8db604c38`；源码归档 5,796,065 字节，SHA-256 `e8d795bea6b023f99574556e0f3417585a1152aab6c6fa84ab1065ca59ed66ec`。`aapt2` 确认包名 `dev.ricky.galaxywatchmanagerfree`、版本 `0.0.40.002` / `40002`；`apksigner` v2/v3 通过，证书 SHA-256 `86de4a33245393411b43ad0d4fa99233f0ca6f926cef6f60982eac9eba3f1525` 与正式证书一致。
- **源码交付与通道隔离（0.0.40.002）**：`nightly.json` 更新为 `0.0.40.002` / `40002`，APK 与源码固定到 feed 提交 `71827ff6a7cb69021ab1cebff2739fdc949f44e5`，`apk-nightly` 分支指向该提交，retained tag 为 `apk-v0.0.40.002-643370fc4771251bbe99161a3d3ab2a218df0463b08131b395f487d8db604c38-e8d795bea6b023f99574556e0f3417585a1152aab6c6fa84ab1065ca59ed66ec`；feed `main` 提交 `f8e6698` 只修改 `nightly.json`。稳定通道 `version.json` 严格保持 `0.0.40` / `40000` 未变，`releases/latest` 依然指向 `v0.0.40`。公开 feed 匿名下载 APK 与源码摘要与 Release 产物逐字节一致，完整验证记录保存在 `private/release-0.0.40.002-verification`。

## 官方应用接管后重复断连修复（2026-11-20，Nightly 0.0.40.001 已发布）

- **根因**：用户将手表交还官方 Galaxy Wearable / Wear OS 应用后，手表端 Wear OS 节点协商与拓扑可能变更。当本应用再次尝试接管手表时，`WatchController.prepareHandover` 曾将交还前的旧手机节点 ID 作为暂存种子，导致跳过了从 GMS 重新探测最新节点，向手表发送了失效的旧节点，触发手表端在 20~40ms 内主动重置 RFCOMM 套接字（`Connection reset by peer` / `read return: -1`），进而陷入无限重连循环。
- **微创修复**：
  1. `WatchController.startService`：增加 `hadReleased = store.releasedToOfficialApps` 校验，曾交还官方的设备强制重新调用 `fetchIdentity` 从 GMS 读取最新节点，禁止复用旧缓存。
  2. `WatchController.prepareHandover`：支持异步等待完成回调；在 `releasedToOfficialApps == true` 时将 `seed` 强制设为空串，触发异步向 GMS 请求新身份。
  3. `WatchController.continueHandover`：在 `releasedToOfficialApps == true` 时仅允许消费新鲜抓取的 `pendingHandoverNode`，拒绝回退至陈旧的 `confirmedPhoneNode`。
  4. `CompanionHandoverCard.disableOfficialApps()`：协程化改造，若 `pendingNode.isBlank()` 异步等待最新身份就绪（5 秒超时），就绪后再停用官方应用并继续交接，实现平滑接管。
  5. 补充单测：`HandoverIdentityTest.handoverAfterOfficialReleaseDoesNotReuseStaleConfirmedIdentity()` 覆盖该分支。
- **本地验证**：Spotless、833 项 JVM 回归（0 失败/错误/跳过）、Lint（0 Errors）、Release 构建、1486 项双语资源与 91 项脚本回归全部通过；未签名 Release APK 与正式签名 APK 均通过 `check_public_assets.py` 完整资源校验。
- **验收边界**：当前无在线 ADB 设备，交还官方应用后再接管的真机握手与建连稳定性仍需真机验收。
- **Nightly 发布核验（0.0.40.001）**：`./scripts/release.sh --nightly` 生成发布提交 `19d5f9a` 并推送附注标签 `v0.0.40.001`，版本 `0.0.40.001` / `40001`。GitHub Actions 因账户支出限制未能启动，按既定标准本地复刻完整发布流程：`./gradlew :app:assembleRelease`、`scripts/sign-apk.sh` 正式签名、`check_public_assets.py`、`package-source.py` 与 `gh release create` 创建 GitHub 预发布（`prerelease=true`，`latest=false`，名称「Galaxy Watch Manager Free 0.0.40.001」，正文与 `release-notes.py` 一致）。APK 35,152,816 字节，SHA-256 `bc126abab81c719f5e6e85e9c4831efbd9f3df7e96d5f6d78a7b40ad28b5ffdc`；源码归档 5,790,615 字节，SHA-256 `56bb3c302b02866bed6fe41e89491343ace421d5c9f27e96b8ff72c7478775fd`。`aapt2` 确认包名 `dev.ricky.galaxywatchmanagerfree`、版本 `0.0.40.001` / `40001`；`apksigner` v2/v3 通过，证书 SHA-256 `86de4a33245393411b43ad0d4fa99233f0ca6f926cef6f60982eac9eba3f1525` 与正式证书一致。
- **源码交付与通道隔离（0.0.40.001）**：`nightly.json` 更新为 `0.0.40.001` / `40001`，APK 与源码固定到 feed 提交 `e328adf86fc4ec7971096fb13823058301492153`，`apk-nightly` 分支指向该提交，retained tag 为 `apk-v0.0.40.001-bc126abab81c719f5e6e85e9c4831efbd9f3df7e96d5f6d78a7b40ad28b5ffdc-56bb3c302b02866bed6fe41e89491343ace421d5c9f27e96b8ff72c7478775fd`；feed `main` 提交 `c72577e` 只修改 `nightly.json`。稳定通道 `version.json` 严格保持 `0.0.40` / `40000` 未变，`releases/latest` 依然指向 `v0.0.40`。公开 feed 匿名下载 APK 与源码摘要与 Release 产物逐字节一致，完整验证记录保存在 `private/release-0.0.40.001-verification`。

## 通知转发在升级/覆盖安装后失效修复（2026-11-18，正式版 0.0.40 已发布）

- **根因**：`NotificationBridgeService.onListenerConnected` 是此前唯一发送通知桥接特性交换（`notification_feature_exchange` 与设置）的位置。应用升级或覆盖安装会杀掉进程，系统可能在 WCS 手表会话就绪前就重绑监听服务；此时特性交换落在未就绪的连接上而丢失，且监听服务此后保持连接、不会再次触发 `onListenerConnected`，导致手表不再接收通知。另有系统在升级后不立即重绑监听服务的情况，监听本身未连接时通知也不会被回调。
- **修复**：`WatchRepository.onSessionReady` 在每个新 WCS 会话就绪时重发通知桥接特性交换与设置；`NotificationListenerRecovery` 在进程启动及通知设置页回到前台时，若已授权但监听未连接，节流调用 `NotificationListenerService.requestRebind`；`onListenerDisconnected` 记录状态；通知设置页重新开启转发且会话就绪时立即重发特性。决策逻辑抽为纯函数并有合成单测（授权、连接、节流边界）。
- **本地验证**：Spotless、832 项 JVM 测试（0 失败/错误/跳过）、Lint（0 Errors）及 Release 构建通过；双语 1486 项资源检查、91 项脚本测试通过。合成单测覆盖 `NotificationListenerRecovery` 的授权、连接状态与 2000ms 节流边界。
- **验收边界**：仅完成静态修复与 JVM 单测，尚未在真机上复现升级/覆盖安装后的通知恢复；需在真机确认升级后手表能重新收到通知、监听重绑日志与系统通知回调。
- **正式版发布核验（0.0.40）**：`./scripts/release.sh`（正式版通道）生成发布提交 `65450fb` 并推送附注标签 `v0.0.40`（指向 `65450fb`），版本 `0.0.40` / `40000`。GitHub Actions 仍在作业启动前因账户付款或支出上限失败、未执行任何步骤；按 Release 工作流相同步骤本地复刻：Spotless、832 项 JVM 回归（0 失败/错误/跳过）、Lint、Release 构建通过，`scripts/sign-apk.sh` 用正式证书签名，`check_public_assets.py` 与 `package-source.py` 通过，并手工创建正式版 GitHub Release。发布脚本先构建后升版本，故签名前按 `0.0.40` 重新 `assembleRelease`，避免产物沿用上一版本号。Release 为非草稿正式版（`prerelease=false`，已设为 `releases/latest`），名称「Galaxy Watch Manager Free 0.0.40」，正文与 `scripts/release-notes.py --tag v0.0.40` 一致。APK 35,152,816 字节，SHA-256 `85aa747322f2f59c22f3aec54d0a8f284925193ac9db8d802f211008adfc0762`；源码归档 5,789,086 字节，SHA-256 `b85e18ebe5bb995f32967738f78636fd9b3ec56962cc8865dc6e4a0335e2d677`。`aapt2` 确认包名 `dev.ricky.galaxywatchmanagerfree`、版本 `0.0.40` / `40000`；`apksigner` v2/v3 通过，证书 SHA-256 `86de4a33245393411b43ad0d4fa99233f0ca6f926cef6f60982eac9eba3f1525` 与既有正式证书相同。公开 feed 匿名下载 APK 的 SHA-256 与 `version.json` 一致。
- **源码交付与通道隔离（0.0.40）**：`version.json` 为 `0.0.40` / `40000`、`published_at` `2026-11-18T05:39:50Z`，APK 与源码固定到 feed 提交 `86eb744638d261f41bbf5119fbcef225b2dc987a`，`apk` 分支指向该提交，retained tag 为 `apk-v0.0.40-85aa747322f2f59c22f3aec54d0a8f284925193ac9db8d802f211008adfc0762-b85e18ebe5bb995f32967738f78636fd9b3ec56962cc8865dc6e4a0335e2d677`；feed `main` 提交 `8263d60` 只修改 `version.json`。`releases/latest` 已指向 `v0.0.40`（`prerelease=false`）；Nightly 通道 `nightly.json` 保持 `0.0.38.003` / `38003` 未回退。手机安装、覆盖安装后通知恢复与重绑、Flow 代理/校时、按需心跳耗电、资料保存/编辑与重启恢复、缺失日志、导出保存/分享、写回展示与重启持久化仍未验收，完整证据保存在被忽略的 `private/`。

## 手机能量得分计算、留存与手表写回（2026-11-18，Nightly 0.0.38.002 / 0.0.38.003 与正式版 0.0.39 已发布）

- **实现**：新增 `EnergyScoreCalculator`、`EnergyScoreLog` 与 `EnergyScoreSync`，健康页提供能量得分卡片、分项、历史与手动计算/写回入口。年龄及算法生理性别由用户输入，计算使用当前设备留存的睡眠分期、睡眠区间心率/RMSSD 与活动日汇总；结果按设备保存，保留稳定记录身份、单调修订、输入和算法来源，落盘失败回滚。缺少必要输入时不生成该日总分。
- **公式与适配边界**：`phone_vitality_v1` 实现已核对的重映射、四项总分权重、睡眠储备、小睡加分、活动 EMA 和生理基线。本机主睡眠采用显式小睡标志及按记录本地醒来日期选择最长非手动睡眠，生理输入按区间重叠加权；活动只使用 `active_time`，EMA 窗口缺日按算法零负荷处理且保留缺失来源。未完整复现官方主睡眠筛选与生理预处理，`official_equivalence_verified=false`；结果标明手机计算，不能宣称与官方完整管线等价。
- **写回与应答**：通过现有 RFCOMM/WCS `/samsung_health/wearable_message` 的 `SYNC_DATA` 下发 `com.samsung.shealth.vitality_score`（`data_version=4`），不依赖 Google Wear app。按当前请求序号与收发方匹配应答，支持发送失败、拒绝、超时、替换、断线与 ACK 落盘失败。成功只确认对应修订收到应答，不证明手表实际保存或展示；未知非空字段仅在官方载荷投影中映射为 `-1` 不可用哨兵。
- **健康导出联动**：`HealthExportSnapshot` 纳入全部留存能量得分，Health Export 升为 v5；新增 `energy_scores.json` 与 `energy_score_rows.json`，同步 schema、manifest 计数/日期范围/留存覆盖、嵌入说明与实际 ZIP 回归。两个文件是同批记录的相关表示，保留算法、来源、输入、未知值与 ACK 元数据；独立小睡、本机睡眠分析及既有全量留存导出继续覆盖。同步更新 APP-SPECIFICATION、PROTOCOL-SPEC 与 HEALTH-EXPORT。
- **资料持久化与编辑（随 0.0.38.003 Nightly 发布）**：年龄与算法生理性别改为当前设备作用域的独立 `EnergyScoreProfile`（键 `energy_profile`），不再附属于某次成功结果；保存成功后才结算，可随时重新编辑保存，重开面板或重启后恢复，旧结果 `inputs.profile_age`/`profile_sex` 在恢复时迁移。面板把“保存资料”与“计算”分开。启动恢复、健康报文落盘、本机睡眠分析完成、补记午休变化与资料保存后延迟约 5 秒合并自动结算，仅结果变化才落盘，且**不**自动写回手表。`EnergyScoreCalculator.calculateWithReport` 返回逐日缺失报告，数据不全时输出运行 ERROR 日志说明缺少哪些输入，便于调试。
- **资料导出联动**：`HealthExportSnapshot` 增加 `energyProfile`，`HealthArchive.write` 新增零或一条的 `energy_profile.json`（`age`、`sex`、`source=user_entered`），manifest 增加 `energy_profile_count`（0/1）与 `energy_profile_coverage=current_device_user_entered`，`retention.energy_profile=current_value_only`；导出契约从已发布的 v5 升为 v6，新增 `energy_profile` 定义并限制数组与计数最多一条，其它数据集与留存范围不变。同步更新 APP-SPECIFICATION 与 HEALTH-EXPORT。
- **本地验证（0.0.38.003 资料优化）**：Spotless、829 项 JVM 测试（0 失败/错误/跳过）、Lint 及 Release 构建通过；双语 1486 项资源检查、91 项脚本测试通过。合成回归覆盖资料独立保存/编辑接缝、严格解析与旧输入迁移、逐日多原因诊断、候选日期计数、无得分时资料导出及数量/校验和、v6 schema 的资料数量边界，并保留既有公式、身份/修订/ACK 和全部留存历史导出回归。保存/手动计算异常输出 ERROR 并提示失败，协程取消继续传播；自动诊断去重包含睡眠记录与主睡眠数量，避免状态变化漏报。资料存储接缝测试不替代 Android 磁盘落盘与重启恢复验收。
- **验收边界**：此前临时合成下发实验曾观察手表详情读取更新后的得分；该实验不能代替当前产品入口与真实数据算法验收。功能开发阶段结束时 `adb devices -l` 无在线设备，手机界面、保存/分享、当前入口写回、手表展示和重启持久化未验收，远端执行未进行；资料保存/编辑、重开与重启恢复同样待真机验收。后续发布见本节的 `0.0.38.002` 核验记录。私有实验材料仍仅在被忽略的 `private/`。
- **Nightly 发布核验（0.0.38.002）**：`./scripts/release.sh --nightly` 生成发布提交 `8e68d3b` 并推送附注标签 `v0.0.38.002`。GitHub Actions 的 CI `44192486313` 与 Release `44192485289` 均在作业启动前失败，注解为账户近期付款失败或需提高支出上限（`The job was not started because recent account payments have failed or your spending limit needs to be increased`），未执行任何步骤；因此按 Release 工作流相同步骤本地复刻：Spotless、818 项 JVM 回归、Lint、Release 构建通过，`scripts/sign-apk.sh` 用正式证书签名，`check_public_assets.py` 与 `package-source.py` 通过，并手工创建 GitHub Release。Release 为非草稿预发布（`prerelease=true`、`latest=false`），名称「Galaxy Watch Manager Free 0.0.38.002」，正文与 `scripts/release-notes.py --tag v0.0.38.002` 一致（仅末尾换行差异）。APK 35,136,432 字节，SHA-256 `bffdda9f9fd143fd14e454aa77c88fa89665ef7d3a6b1a9f7b52574d5d8d4c99`；源码归档 5,774,560 字节，SHA-256 `44c66b66a0ecdb850814dfc844af97be047a9221e6d06d0885f9d37fd94e8e15`。`aapt2` 确认包名 `dev.ricky.galaxywatchmanagerfree`、版本 `0.0.38.002` / `38002`；`apksigner` v2/v3 通过，证书 SHA-256 `86de4a33245393411b43ad0d4fa99233f0ca6f926cef6f60982eac9eba3f1525` 与 `0.0.38` / `0.0.38.001` 相同。公开 feed 匿名下载 APK 与源码的 SHA-256 分别与 `nightly.json` 一致。
- **源码交付与通道隔离（0.0.38.002）**：`nightly.json` 为 `0.0.38.002` / `38002`、`published_at` `2026-11-17T22:46:47Z`，APK 与源码固定到 feed 提交 `1c6a6e0af5ded8477714fd6011f547922b02d100`，`apk-nightly` 分支指向该提交，retained tag 为 `apk-v0.0.38.002-bffdda9f9fd143fd14e454aa77c88fa89665ef7d3a6b1a9f7b52574d5d8d4c99-44c66b66a0ecdb850814dfc844af97be047a9221e6d06d0885f9d37fd94e8e15`；feed `main` 提交 `5b9c0a0` 只修改 `nightly.json`。稳定通道 `version.json` 保持 `0.0.38` / `38000`，`apk` 分支与 `releases/latest` 未变。Actions 计费阻塞仅影响云端流水线，不改变本次产物的签名、摘要与通道结果；手机安装、界面、写回展示与重启持久化仍未验收，完整证据保存在被忽略的 `private/`。
- **Nightly 发布核验（0.0.38.003）**：`./scripts/release.sh --nightly` 生成发布提交 `5472ac2` 并推送附注标签 `v0.0.38.003`。GitHub Actions 的 CI 与 Release 仍在作业启动前因账户付款或支出上限失败、未执行任何步骤；按 Release 工作流相同步骤本地复刻：Spotless、829 项 JVM 回归（0 失败/错误/跳过）、Lint、Release 构建通过，`scripts/sign-apk.sh` 用正式证书签名，`check_public_assets.py` 与 `package-source.py` 通过，并手工创建 GitHub Release。发布脚本先构建后升版本，故签名前按 `0.0.38.003` 重新 `assembleRelease`，避免产物仍为 `0.0.38.002`。Release 为非草稿预发布（`prerelease=true`、`latest=false`），名称「Galaxy Watch Manager Free 0.0.38.003」，正文与 `scripts/release-notes.py --tag v0.0.38.003` 一致。APK 35,152,816 字节，SHA-256 `1ea28104e80f90522c0b072cead586a4e57554c621a53c6b1a9acf8e1bcb3165`；源码归档 5,784,665 字节，SHA-256 `2ea97b0664a3983b069ca554e1639fd4621c3f7f2302afe527df947c5fb1e022`。`aapt2` 确认包名 `dev.ricky.galaxywatchmanagerfree`、版本 `0.0.38.003` / `38003`；`apksigner` v2/v3 通过，证书 SHA-256 `86de4a33245393411b43ad0d4fa99233f0ca6f926cef6f60982eac9eba3f1525` 与既有正式证书相同。公开 feed 匿名下载 APK 的 SHA-256 与 `nightly.json` 一致。
- **源码交付与通道隔离（0.0.38.003）**：`nightly.json` 为 `0.0.38.003` / `38003`、`published_at` `2026-11-18T02:12:39Z`，APK 与源码固定到 feed 提交 `943667df6997f8c4698ab40f41a5dd6080e7af07`，`apk-nightly` 分支指向该提交，retained tag 为 `apk-v0.0.38.003-1ea28104e80f90522c0b072cead586a4e57554c621a53c6b1a9acf8e1bcb3165-2ea97b0664a3983b069ca554e1639fd4621c3f7f2302afe527df947c5fb1e022`；feed `main` 提交 `67468d1` 只修改 `nightly.json`。稳定通道 `version.json` 保持 `0.0.38` / `38000`，`apk` 分支与 `releases/latest` 未变。手机安装、资料保存/编辑与重启恢复、缺失日志、导出保存/分享、写回展示与重启持久化仍未验收，完整证据保存在被忽略的 `private/`。
- **正式版发布核验（0.0.39）**：`./scripts/release.sh`（正式版通道）生成发布提交 `b1bed75` 并推送附注标签 `v0.0.39`（指向 `b1bed75`），版本 `0.0.39` / `39000`。GitHub Actions 仍在作业启动前因账户付款或支出上限失败、未执行任何步骤；按 Release 工作流相同步骤本地复刻：Spotless、829 项 JVM 回归（0 失败/错误/跳过）、Lint、Release 构建通过，`scripts/sign-apk.sh` 用正式证书签名，`check_public_assets.py` 与 `package-source.py` 通过，并手工创建正式版 GitHub Release。发布脚本先构建后升版本，故签名前按 `0.0.39` 重新 `assembleRelease`，避免产物沿用上一版本号。Release 为非草稿正式版（`prerelease=false`，已设为 `releases/latest`），名称「Galaxy Watch Manager Free 0.0.39」，正文与 `scripts/release-notes.py --tag v0.0.39` 一致且汇总 `0.0.38.001`～`0.0.38.003`。APK 35,152,816 字节，SHA-256 `92eb5c17465207930407a0a41b08acf72126c6540c8d869ba34cca30f650f8be`；源码归档 5,785,249 字节，SHA-256 `8cd52a3a1d007d5c28afe8bd599fb86922bffa2eeb5215836da248a9d3c9fd62`。`aapt2` 确认包名 `dev.ricky.galaxywatchmanagerfree`、版本 `0.0.39` / `39000`；`apksigner` v2/v3 通过，证书 SHA-256 `86de4a33245393411b43ad0d4fa99233f0ca6f926cef6f60982eac9eba3f1525` 与既有正式证书相同。公开 feed 匿名下载 APK 的 SHA-256 与 `version.json` 一致。
- **源码交付与通道隔离（0.0.39）**：`version.json` 为 `0.0.39` / `39000`、`published_at` `2026-11-18T03:21:45Z`，APK 与源码固定到 feed 提交 `fc2350d0bf5cf22333760af6ecfe1fed03df292a`，`apk` 分支指向该提交，retained tag 为 `apk-v0.0.39-92eb5c17465207930407a0a41b08acf72126c6540c8d869ba34cca30f650f8be-8cd52a3a1d007d5c28afe8bd599fb86922bffa2eeb5215836da248a9d3c9fd62`；feed `main` 提交 `dcd2bea` 只修改 `version.json`。`releases/latest` 已指向 `v0.0.39`（`prerelease=false`）；Nightly 通道 `nightly.json` 保持 `0.0.38.003` / `38003` 未回退。手机安装、Flow 代理/校时、按需心跳耗电、资料保存/编辑与重启恢复、缺失日志、导出保存/分享、写回展示与重启持久化仍未验收，完整证据保存在被忽略的 `private/`。

## Flow 蓝牙联网代理、校时应答与按需心跳（2026-11-17）

- **背景**：耗电诊断基线显示手表 `Device=connected Proxy=disconnected`、`Start attempts=833`、`hadConnectError=true`，根因指向手机端缺少 Flow 蓝牙联网代理与校时应答，手表反复重试。本次补齐两项功能并改为官方按需心跳，不改动健康、设置或更新逻辑。
- **Flow 联网代理**：新增 `FlowProtocol` / `FlowProxySession` / `FlowProxyServer`，随 `RfcommTransport.start/stop` 启停，在独立 `Flow` SDP（UUID `fafbdd20-83f0-4389-addf-917ac9dae5b2`）仅监听当前选定且已绑定的手表。按官方帧表实现 1–18 类型：TCP 双向转发不回 ACK、UDP/UDP_V2 回包保留端点顺序、PING 回显、PULL/PUSH 探测、默认网络类型与计费状态发布，以及可选握手（START→ACK `[17,0,0,0,5,0,0]`→DONE）。NIO Selector 非阻塞转发 IPv4 TCP/UDP，有界队列、建连超时与空闲回收；不提供 IPv6、VPN 或任意手机侧监听端口。帧表与边界见 PROTOCOL-SPEC §2.3。真机验证：关闭手表 Wi-Fi 后天气应用仍通过蓝牙代理联网。
- **校时应答**：新增 `PhoneTimeSync`，在会话初始化完成后及 `ACTION_TIME_CHANGED`/`ACTION_TIMEZONE_CHANGED` 时发送 START；收到手表 `/settings/rpc` COMMAND=1 时逐字节保留请求其余 entry（避免通用 DataMap 往返丢失 null、未知类型或改变数组类型），仅替换 COMMAND=2 与 `COMPANION_TIME` 后回复，并按官方 `zzaj` 语义发送 `/timezone/rpc` 时区映射；关闭会话注销广播接收器。`WcsSession` 增加 closed 守卫，防止重连期间时间接收器泄漏。字段与保留规则见 PROTOCOL-SPEC §6.9。
- **按需心跳替代 10 秒定时**：从官方 `hbp`/`hbk` 确认固定 10 秒心跳并非协议要求——官方在收到非心跳后唤醒 writer，队列排空时补发一次空心跳（`inner=5a00`）。`RfcommTransport` 移除独立心跳线程，改为 `heartbeatPending` 标志 + 空哨兵唤醒 writer，在完整消息层（`WcsSession` 组装后）触发；writer 以 60 秒轮询超时作低频兜底，不对心跳回心跳。动机见 `private/watch-power-20261117.eoKLR5/diagnosis.html`：约 7 小时 2,261 次蓝牙中断唤醒，中位间隔 10.08 秒，与 10 秒心跳强相关。
- **健康导出联动**：本次只新增网络代理与校时路径，未触碰健康数据模型、字段、持久化、派生统计、留存策略、采集设置或 `HealthExportSnapshot`；健康导出 schema、manifest、覆盖说明与回归测试均不受影响，无需变更。
- **本地验证**：`./gradlew :app:spotlessCheck :app:testDebugUnitTest :app:lintDebug :app:assembleRelease` 通过（798 项 JVM 测试，0 失败）；Lint 0 错误、144 警告；`python3 scripts/check-i18n.py` 通过（1444 条双语资源）；`python3 -m unittest discover -s scripts/tests -v` 通过（91 项脚本测试）。`scripts/sign-apk.sh` 以发布证书（SHA-256 `86de4a…f1525`）签名 `artifacts/galaxy-watch-manager-free-0.0.38.apk` 并覆盖安装到手机，WCS 握手（NodeInfo/SyncStart/DataItem 快照恢复）完成、前台连接服务运行、无错误日志。真机帧节奏已按 ADB 实测（开启应用调试日志后 180 秒 logcat，`private/heartbeat-verify-20261117/`）：窗口内 8 次 41B 心跳写入、5 次入站帧，空闲期出现两次精确 60.0 秒间隔的兜底心跳，其余 6 次均紧跟入站非心跳帧（0.0~3.8 秒内补发一次），全程无 10 秒节奏、无断线。
- **验收边界**：未重置电池统计；A/B 对比（10 秒 vs 60 秒 vs 按需）的耗电差异需在保持健康/通知/表盘设置一致、ADB 断开的前提下另行观测。Flow 代理状态与真实网络请求、校时实际生效及耗电/重试变化仍须分别实测，不能以合成回环测试替代；手机保存/分享交互、远端执行与设备重启后持久化未验证。
- **Nightly 发布核验（0.0.38.001）**：`./scripts/release.sh --nightly` 生成发布提交 `38feabd` 并推送附注标签 `v0.0.38.001`；CI `44072924055` 与 Release 工作流 `44072923321` 均成功。Release 为非草稿预发布（`prerelease=true`），名称「Galaxy Watch Manager Free 0.0.38.001」，正文与 `scripts/release-notes.py --tag v0.0.38.001` 提取内容一致（仅末尾换行差异），只含当前版本章节。正式签名 APK 35,070,896 字节（较 `0.0.38` 正式版 35,054,512 增加 16,384 字节），SHA-256 `8f0ec671c30a9423a702491b036275bb8043d130ae8dd08e96a0735f2676f600`，与 `nightly.json`、Release 附件摘要及 `.sha256` 一致；公开 feed 匿名下载与经授权 Release 附件逐字节相同。`aapt2` 确认包名 `dev.ricky.galaxywatchmanagerfree`、版本 `0.0.38.001` / `38001`、minSdk 26、targetSdk 35；`apksigner` v2/v3 校验通过，证书 SHA-256 `86de4a33245393411b43ad0d4fa99233f0ca6f926cef6f60982eac9eba3f1525` 与 `0.0.38` 相同（`CN=Galaxy Watch Tweaker, O=Ricky, C=US`、RSA 4096）。
- **源码交付与通道隔离**：匿名源码归档 5,744,776 字节，SHA-256 `09497a8aa8ff69c2174d8104fa9a39b339e80e783bfea533de60f94a2040b9e6`，与 `nightly.json`、Release 附件及 `.sha256` 一致，由 `python3 scripts/package-source.py --ref v0.0.38.001` 复现后与发布文件逐字节相同。`nightly.json` 为 `0.0.38.001` / `38001`，APK 与源码固定到 feed 提交 `9aa5c383355f38aae46130d4adc70967638f55ed`，`apk-nightly` 分支指向该提交且只含本版两个文件，retained tag 为 `apk-v0.0.38.001-8f0ec671…-09497a8a…`。稳定通道 `version.json` 保持 `0.0.38` / `38000`、`apk` 分支 `35698cbd…` 与 `releases/latest`（`v0.0.38`，`prerelease=false`）均未变。本次远端发布与安装包静态核验不代表手机安装、代理/校时实际效果、耗电 A/B 或重启持久化已验收；完整证据保存在被忽略的 `private/`。

## 睡眠原生库压缩打包（2026-11-14）

- **方案**：设置 `packaging.jniLibs.useLegacyPackaging = true`，将 APK 中的 `.so` 改为 DEFLATE，包含 `assets/sleep/` 的 ARM64/ARMv7 四个 JNI 文件。完整保留 `engine.jar`、模型、分位表及两组 ABI；解压后摘要与源码一致，原有代码缓存提取和加载逻辑保持不变。
- **体积**：本地未签名 Release APK 从 23,209,861 降至 19,514,077 字节，减少 3,695,784 字节（约 3.52 MiB，15.92%）。这是同版本构建的安装包体积对比；常规 `lib/` JNI 同时改为安装时解压（`extractNativeLibs=true`），不代表解压后运行时占用或内存等比例下降，未测首轮解压耗时。
- **防回归**：已有 APK 资源检查同时验证四个睡眠 JNI 的 DEFLATE 方法，沿用发布脚本与 Release 工作流的检查入口；合成 APK 逐个验证任一 JNI 回退为未压缩时会被拒绝，正常压缩包继续通过模型、摘要及预览完整性检查。
- **健康导出联动**：仅调整 ZIP 打包方式，模型/运行时原始字节、健康字段、分析版本、持久化、留存与导出契约均未改变，无需更新 v3 schema。
- **本地验证与边界**：Spotless、673 项 JVM、78 项脚本测试、LintDebug、默认 Release 构建及 1372 项双语资源校验通过；实际 APK 的四个睡眠 JNI 均为 DEFLATE，完整资源检查通过。本次压缩包未在手机上安装，未重新验收本机推理/缓存持久化或系统保存/分享，不能将下节旧包的手机验收视为本次结果。
- **Nightly 发布核验**：通过 `./scripts/release.sh --nightly` 发布 [0.0.36.001](https://github.com/crossly/galaxy-watch-manager-free/releases/tag/v0.0.36.001)，发布提交 `b87c10b` 的 CI `43576600362` 与 Release 工作流 `43576600664` 均成功，Release 为非草稿预发布且正文仅含当前版本章节。正式签名 APK 为 19,572,188 字节，较已发布 `0.0.36` 减少 3,698,688 字节（15.89%）；匿名下载与 Release 附件逐字节一致，SHA-256 `5c3cb939e4a97f7b6d2fbb1405933b23c6c878ebf12259d5ff7b12eeb41f4a4b` 与 `nightly.json`、附件摘要及 `.sha256` 一致。`aapt2` 确认包名及 `0.0.36.001` / `36001`，`apksigner` v2/v3 校验通过，证书集合与重新核验签名及文件摘要的稳定版 APK 相同；发布 APK 的四个睡眠 JNI 均为 DEFLATE，完整资源检查通过。
- **源码交付与通道**：匿名源码归档为 5,623,563 字节，SHA-256 `0ede854715f765d99bdcc61244a3f0c0af18116c310d9fbfe45e7c42d9431544` 与清单、Release 附件及 `.sha256` 一致，和附件逐字节相同；解压后的 TAR 字节与发布提交的 `git archive` 完全一致。公开 APK 与源码地址均固定到 `7dccf156e9c6541c3951e29d1cfcad7240837eac`，与 `apk-nightly` 分支一致；稳定版清单仍为 `0.0.36` / `36000`，`apk` 分支仍为 `fe7ae670b93f27728d56254167ffa10a62231483`，Latest 仍为 `v0.0.36`。本次远端发布与安装包静态核验不代表手机安装、推理、保存/分享或重启持久化已验收。

## 默认公开构建恢复完整睡眠运行时（2026-11-14）

- **根因与恢复**：此前将厂商睡眠运行时移出默认资源，并以 `VENDOR_ASSETS_ENABLED` 禁用公开版的新分期推理和专用回补，造成已同步原始数据的睡眠记录只有区间。按用户要求恢复默认随包的 `engine.jar`（内嵌 TensorFlow 模型和分位表）、ARM64/ARMv7 两组 JNI、摘要清单及来源/许可说明；移除可选注入参数和运行开关，普通公开构建直接保留完整本机分期能力。第三方组件仍保留其来源与权利归属，不重标为原创代码。
- **防回归与交付**：构建及 APK 检查改为验证必需文件、来源摘要、逐文件 SHA-256、JAR 内模型载荷和源码/APK 一致性；继续验证原有 43 张表盘预览。对应源码打包保留睡眠运行时，仍拒绝私有证据、密钥、APK 和本机配置。合成回归覆盖缺文件、错摘要、缺模型、源码与 APK 不一致及源码归档保留组件。
- **健康导出联动**：已核对 `HealthExportSnapshot`、手动小睡/本机分析独立存储、原始与标准化会话、schema、manifest、嵌入说明及完整留存历史；未改变缓存格式、字段、算法来源或留存范围，继续使用 v3。原始数据与全部已留存分析版本照常导出，手表分期优先，不为未知值补零或补造阶段。
- **本地验证**：673 项 JVM、77 项脚本测试及 1372 项双语资源校验通过；Spotless、LintDebug、默认 Release 构建和 Android 测试源码编译通过。未带额外 Gradle 参数构建的 APK、正式证书签名后的 APK 均通过完整资源检查。
- **手机验证**：在 ARM64 手机先备份应用数据，再以同证书覆盖安装默认构建（版本仍为 `0.0.36`）。睡眠详情显示分期来源、时长、效率及本机评分；备份后仅临时移除最新一条派生分析缓存，默认包自行从已留存原始数据重新生成并落盘，结果与原缓存完全一致，另外 18 条历史分析保持不变；重启应用后睡眠详情正常恢复。备份、界面和缓存对照证据仅保存在被忽略的 `private/sleep-restore-20261114.4X8EJo/`。
- **验收边界**：本节记录本地构建与手机验证，远端发布另行核验；未验证 ARMv7 实机、系统保存/分享、手表端写入或整机重启持久化。下方 2026-11-13 记录中「公开版排除睡眠运行时」为当时状态，已由本节恢复方案取代。

## 表盘图片显示回归修复（2026-11-13，0.0.35.005 Nightly）

- 用户反馈 `0.0.35.004` 优化后应用中的手表图片消失；资源核对确认默认构建缺少全部 43 张 `wf_*.webp`，当前表盘卡片、设备图标和表盘列表因共用预览组件而一起退化为通用示意。
- 从回归前的 `a3253f8` 恢复原有 43 张逐款图片，不修改图片内容；移除按睡眠运行时开关显示的全局示意图提示，保留实际设备图片优先的现有加载逻辑。可选睡眠运行时构建不再重复注入 `res/`，避免与已恢复资源冲突。
- 资源检查由一律拒绝表盘 WebP 改为检查每个预设在源码与 APK 中都有图片；对应源码归档保留图片，并继续拒绝私有证据、密钥与厂商睡眠运行时。图片的第三方来源及许可待确认状态保留，不将其重标为原创 GPLv3。
- 回归测试先复现 43 张图片全部缺失，再验证恢复后的资源完整性、APK 缺图报错、AAPT2 缩短资源路径和合成源码归档保留图片；58 项脚本测试、673 项 JVM 测试、1372 项双语资源检查、格式、Lint、Release 构建及 Android 测试源码编译通过。实际 APK 的 43 个 drawable 均指向原图，图片内容与回归前版本逐字节一致。当前无可用 Android 设备，手机界面交互、远端手表执行及设备持久化未实测。
- 已发布 `0.0.35.005` Nightly：远端 Release 工作流成功；Release 资产、`nightly.json`、匿名 APK 与源码下载、SHA-256、versionCode `35005`、同签名证书及公开更新源核验通过，稳定通道保持 `0.0.35`。手机显示效果待用户实测。

## 全仓审查修复（2026-11-13，基线 a3253f8）

本轮按全仓审查的 15 项 P2 和 2 项 P3 处理，编号与审查报告一致：

| 编号 | 修复及回归 |
|---|---|
| 1、2 | 普通错误与调试堆栈只保留安全上下文、异常类别、帧及因果关系；睡眠分析日志不含记录 ID 或健康值。合成 JSON、通知和凭据覆盖真实格式化入口。 |
| 3、4、5 | 应用与导出共用最新整条修订及日期解析；今日楼层区分未知与零，归档入口覆盖旧历史、别名修订和实际日期。 |
| 6、7 | 快照 schema 2 限制 10,000 条、8 MiB 信封、16 MiB 文件读取；有效条目淘汰后省略对应来源游标，旧 schema 1 清空游标保守全同步，损坏恢复原子清空。 |
| 8 | SettingCommands 确认计时从实际发送开始，请求身份和连接代数阻止队列旧写入；回归覆盖超过 4 秒排队、断线、同值替换及发送失败。 |
| 9、10 | 昵称严格按配对地址读取；通知去重按连接会话切换，合成双设备与会话测试覆盖隔离。 |
| 11 | SETTINGS 投影补齐连接页实际消费的名称、型号、表盘与启动状态，保留无关健康数据隔离，并增加 Compose 消费回归。 |
| 12、13、16 | 发布锁保留待执行队列，旧稳定重跑不回退 Latest；已有产物保留标签先核验再复用，本地临时 Git 仓库覆盖跨源提交时间重发。 |
| 14、15 | 发布随附精确 Git 树的完整对应源码、许可和校验和，feed 提供固定源码 URL；未确认授权的厂商资产保留在忽略的 private/vendor-assets，公开构建和归档增加防混入检查，本地可选注入被 CI 拒绝。 |
| 17 | 小时分布显式传递 nowMillis，测试固定日期与时区。 |

健康联动已核对快照、手动小睡、本机分析独立缓存、raw/normalized、schema、manifest、嵌入说明和完整留存范围，未新增导出字段，维持 v3。公开版停止新的厂商 raw 分期推理及其专用回补；已有分期、旧缓存、评分和导出保留。旧 DataItem 快照与被裁剪来源后续重连会增加全量同步流量。

本轮 673 项 JVM、54 项脚本测试及 1372 项双语资源检查通过；格式、Lint、Release 构建和 Android 测试源码编译均通过。没有可用 Android 设备，Compose 用例只编译，手机保存/分享、界面交互、远端手表执行、覆盖升级和重启持久化均未实测；CI 与公开下载结果在发布后单独核验。

## 已实现的正确性修复

| 审查编号 | 本轮处理 | 验证 |
|---|---|---|
| B02 | 握手与手动刷新共用真实手机状态构造器，不再固定地区、时区和固件 | 实机握手重新连接成功 |
| B03 | 全天活动 summary 优先于局部明细；缺字段保持未知，零值有效；小时分桶不被无条件丢弃 | 先复现失败，再通过投影测试 |
| B04 | 详情统计和曲线仅取当天；历史样本仍供周趋势，今日无数据时明确空态 | Daily 公共接口多日/空日回归测试；图表按本地墙上时间落点 |
| B05 | 存储前归一化长字段元数据，身份/修订/裁剪用同一份数据 | 长名双记录、旧修订、encode/restore 测试 |
| B06 | 先确定全部阶段边界，再排除 GAP/LATENCY/未知码 | GAP 导致浅睡翻倍的失败用例已变绿 |
| B07 | 核对并修正骑行、有氧健身、水中有氧、帆船、皮划艇、滑雪、单板及户外游泳编码 | SportTypeConstants 来源 + 表驱动回归 |
| B08 | confirmed 与 pending 分离；排队失败不改确认值；重试跟随请求、断线/关闭取消 | 失败发送、替换命令、错回执、断线取消测试；实机 AOD 未回执时保持原值并提示未确认 |
| B09 | 从原通知保留 package/user/id/tag/uid 与原时间，不按时间取模；路径片段转义 | 身份区分/复用测试；真实通知跨固件投递仍待设备专项验收 |
| B10 | APK 缺摘要/大小/签名拒绝；核对包名与清单版本且禁止降级；安装前 IO 重验 | 纯策略拒绝矩阵；Android 包/签名读取与 FileProvider 实测 |
| B11 | 健康与推理缓存按蓝牙配对地址隔离；旧缓存只迁原设备，保留原文件 | Android 实际 SharedPreferences 迁移测试；手机迁移后健康和 61 段睡眠结果保留 |
| B12 | sleep_status 改用有界解压（8 MiB） | 嵌套大 payload 拒绝测试先红后绿 |
| B13 | APK URL 改为被标签保留的 commit；main/APK/tag 原子 push；跨版本共用锁并禁止回退 | 真实临时裸 Git 仓库测试：首次、重复、重建、旧地址保留、旧版本跳过；未向生产 feed 发布 |
| B14 | 无有效日期的楼层不参与今日累计 | 缺时间输入先红后绿 |

## 已推进但仍有边界

| 审查编号 | 本轮处理 | 剩余事项 |
|---|---|---|
| B01 | 新设备不套用历史身份；旧设备迁移保留原兼容帧；节点按设备隔离。本轮将连接页整理为选择手表、获取本机 Wear 候选身份、验证连接；手动身份与日志保留为高级入口，补充停止与切换连接的处理 | 首次登记协议仍不支持；自动获取的身份需要业务回包验证，跨设备新安装接入及长期稳定性仍需真机验收，不能宣称开箱配对 |
| S01 | 新增 THIRD-PARTY，补随包 TensorFlow 上游许可证文本；明确厂商睡眠模型/二进制与图片不被原创许可覆盖 | 根许可证必须由维护者选择；厂商组件/图片再分发依据、完整 notice 清单及可选提取构建仍未闭合。本轮未删睡眠功能或替维护者授权 |
| S02 | 新增 SettingCommands、DevicePreferences/DeviceScope、NotificationIdentity、AndroidApkReader/ApkValidation，降低跨状态/Android API 耦合 | WatchRepository 与 WcsSession 仍偏大，下一步适合拆出单一 HealthRepository；不在一次行为修复中搬走全部健康逻辑 |
| S03 | 普通日志删除通知正文/健康 JSON；清空日志也删落盘文件；备份仅允许外观设置；回放样本移到 debug | 历史抓包/图片/整个 Git 历史未做完整去标识化审计；显式用户触发的协议探针可记录输入，不能当作普通日志 |
| S04 | 添加 .editorconfig 与 ktfmt/Spotless 增量检查，改动文件统一格式；新增文案资源化 | 旧页面全量 strings/plurals 迁移、共享 token、旧 import/命名清理仍可分批进行 |
| S05 | 健康解码失败有错误类别；RecordStore 恢复失败保留旧状态和磁盘恢复副本；表盘确认任务可取消且有日志；APK 读取失败不放行 | 仍有历史 runCatching/线程代码待按模块整理，不能宣称所有异常已分类 |
| S06 | 221 项 JVM 测试；新增 3 项 Android 系统边界测试和 CI 模拟器 job，新增发布脚本集成测试；格式检查进入 CI/发布检查 | JNI 仍需 ARM 实机回放，RF 双工竞态及跨厂商系统行为未有全面自动化覆盖；本轮云端构建和新增模拟器 job 均已通过 |
| S07 | README、功能矩阵与 SSOT 更新为当前行为；贡献和第三方说明补齐；移除填写更新 token 的旧注释 | 原始研究过程文档作为历史证据保留；整份 SSOT 的历史段落还可进一步整理 |

## 本轮验收证据

- `:app:spotlessCheck :app:testDebugUnitTest :app:lintDebug :app:assembleRelease` 通过。
- JVM 221 项，0 failure / error；脚本 15 项通过。
- `ANDROID_SERIAL=emulator-5554 ./gradlew :app:connectedDebugAndroidTest`：3 项通过。
- 云端 CI `40625490228`（代码提交 `8bb1ab0`）的 build 与 android-boundaries 两个 job 全部成功：[运行记录](https://github.com/crossly/galaxy-watch-manager-free/actions/runs/40625490228)。
- Lint 0 errors / 44 warnings；主要是依赖更新、旧 API/资源及现有 Compose 建议，未通过全局禁用规则消除。
- 通过用户 MacBook 的 loopback SSH 反向隧道连接 USB Honor 手机，未公开 ADB 端口；修改前保存 shared_prefs/files 恢复副本至 Git 忽略的 `private/review-optimization/`。
- 同签名 preview 覆盖安装后，会话就绪、当前 Ultra Analog 表盘恢复、心率历史/8 条运动记录保留；独立设备缓存已生成。
- 手机睡眠详情自动读取到“5小时1分”“95%”，仍解释 07:49 原始醒来和 07:42 分析结束差异；61 段本机分析结果保留，未重新生成假评分。
- 实机 AOD 请求排队后没有收到该设置的有效确认，显示原来的关闭值并报告未确认；测试后目标恢复关闭。不把 DataItem 已排队或收到其他路径的推送称为设置生效。

预览包路径：`artifacts/galaxy-watch-manager-free-review-preview.apk`。版本仍为 0.0.9，**不是新发布**。

## 后续：设备连接引导重构（基于 0.0.11）

- 选择手表、读取候选身份、验证连接成为主路径；手输身份、查询频率和日志放入高级选项。权限缺失、蓝牙关闭与无配对设备分别呈现，提供重新授权和系统设置入口。
- 候选身份只在进程内暂存，按设备隔离；仅当前连接收到匹配已发请求的有效业务响应后保存。读取节点或建立 RFCOMM 本身不算验证成功。
- 获取身份、连接与验证阶段均可停止；重试、换表及服务回调使用请求代次隔离。READY 后断线恢复重连状态，继续提供停止入口。
- 本地验证：294 项 JVM 单测、31 项 Android 模拟器测试、24 项脚本测试通过；格式检查、Lint、Release 构建通过。926 个资源在中英文之间键与格式参数一致；新增页面覆盖 320dp、英文 200% 字体、明暗主题及权限失败恢复。
- 本轮未进行真实手机与手表连接验收。Google Wear 本机节点查询不保证等于手表登记身份；跨手机新安装接管、无 Google 服务手机和恢复出厂后的首次登记仍不能宣称已支持。

## 后续：已启用中国版 Wear 的身份获取实机验证（2026-10-30）

- 历史手机节点 `<phoneNode>` 来自 `research/snoop/ch8_dir.tsv` 第 469 帧的手机→手表 NodeInfo；解码结果见 `research/snoop/messages_PHONE_WATCH.json:10`。它是既有配对身份，不是本应用新分配的 ID。普通应用不能凭蓝牙运行时权限旁听官方连接或读取系统 HCI 日志；现有自动获取走公开 `NodeClient.localNode`。
- Honor 手机原已安装中国版 Google Wear，但与 Galaxy Wearable、Watch7 Plugin、手机 SHM 一起被 shell 停用（`enabled=3`）。本轮恢复这四个包，保留原数据、系统蓝牙配对与手表设置；Samsung Health、运动与 eSIM 组件原本可用，未额外改动。
- 恢复官方组件后，页面显式“自动获取连接身份”仍复现 `ApiException: 17 / API_UNAVAILABLE`。`play-services-wearable:20.0.1` 的 `zzkp.zzb()` 先通过 `PackageManager.getPackageInfo` 与签名校验探测 `com.google.android.wearable.app.cn`；`zzkf.getStartServicePackage()` 据此选择中国版 Wear 或 Play Services。合并 Manifest 缺少中国版 Wear 的包可见性声明，可能使探测按“未找到”处理。
- 最小修复为 Manifest 增加 `<queries><package android:name="com.google.android.wearable.app.cn" /></queries>`，不增加系统日志权限、root 路径或硬编码身份兜底。`lintRelease`、`assembleRelease` 通过；使用原正式证书（SHA-256 `86de4a33245393411b43ad0d4fa99233f0ca6f926cef6f60982eac9eba3f1525`）同包覆盖安装，仍为 0.0.12，未发布或清除应用数据。
- 修复后通过页面停止连接并显式重新获取身份：公开 API 返回的候选 `<phoneNode>` 经手表业务响应验证并固化；概览显示 Galaxy Watch Ultra、已连接、电量 100%。强制结束应用后重新启动，自动连接恢复；四个官方包仍保持 `enabled=1`。截图保留于忽略目录 `private/identity-visibility-20261030/dashboard-reconnected.png`。
- 验收边界：这次显式获取绕过已保存身份的快捷连接路径，但未清空应用数据或恢复出厂；它验证的是同一已配对手机的重新读取、验证与重启恢复，不代表任意新手机首次登记、恢复出厂首次配对或官方组件长期并行稳定性已通过。


## 后续：可选 Shizuku 官方连接接管（2026-10-30）

- 连接页新增「释放官方蓝牙应用」卡片。停用范围固定为 Google Wear（`com.google.android.wearable.app.cn` / `com.google.android.wearable.app`）、`com.samsung.android.app.watchmanager`、`com.samsung.wearable.watch7plugin`；Samsung Health 与 SHM 不在列表内。读取手机身份仍走公开 `NodeClient.localNode`，因此流程要求先取身份、再释放官方连接。
- Shizuku 路径：使用 `dev.rikka.shizuku:api:13.1.5` / `provider:13.1.5`（MIT，许可保留于 `app/src/main/assets/licenses/SHIZUKU-LICENSE.txt`）与用户服务，在 UID 2000 侧通过 `IPackageManager` 读取并修改启用状态；包名在特权进程内再次按白名单校验，不接受任意命令或跨用户操作。修改前把每个将被改变的应用原始启用状态以 `commit()` 落盘，重复执行不覆盖首次记录；任一停用失败会回滚本次已改应用，回滚无法验证的条目保留在恢复记录中；恢复逐项回读确认，取消/页面销毁时先在 `NonCancellable` 中完成回滚再释放 shell 绑定。
- 无 Shizuku / 未运行 / 未授权时，同一卡片列出实际安装状态并为每项提供「应用详情」，指导用户自行强行停止或按系统提供的方式停用；卸载只作为最后手段并明确会删除官方数据，应用不会自动卸载任何东西。
- 实机（Honor BKQ-AN90 + Galaxy Watch Ultra，Shizuku 13.6.0 运行中）验证：点击一次停用后，中国版 Google Wear、Galaxy Wearable、Watch7 Plugin 变为 `enabled=3`，SHM 保持 `enabled=1`；应用随后自动继续 WCS 连接并显示“协议握手就绪”。点击恢复后三项回到原始 `enabled=1`，恢复记录清空（恢复按钮转为不可用），本应用连接重新建立。基线状态与证据保存在忽略目录 `private/shizuku-handover-20261030/`。
- 回归：301 项 JVM 测试通过；41 项 Android 模拟器测试（含新增 `HandoverIdentityTest` 与连接页接管态测试）通过；`spotlessCheck`、`lintRelease`、`assembleRelease`、`check-i18n.py`、24 项脚本测试通过。正式证书重签覆盖安装，版本仍为 0.0.12，未发布标签。
- 验收边界：只覆盖当前手机与当前 Shizuku 版本；不同 ROM 对系统应用停用的限制、Shizuku 重启后的重新绑定、以及官方组件长期并行后的连接稳定性仍未逐项验收。`killBackgroundProcesses()` 在 Android 14+ 只能终止本应用进程，因此没有把它当作接管手段。


## 后续：午休与连接引导（2026-10-30）

- 睡眠按「醒来日期」归集最近睡眠日的全部会话：`WatchState.sleepSessions` 保存夜间 + 午休，卡片显示当天合计并标注「含小睡 X」，详情面板逐段列出「主睡眠 / 小睡」的起止与时长（当时阶段结构仅展开主睡眠；后续已改为合并全部真实分期）。持久化新增 `sleep_sessions_json`（兼容旧 `sleep_json`），导出 ZIP 新增 `latest_sleep_sessions.json`。单元与 Compose 测试覆盖归集、合计与两段展示。
- 10-30 02:00 对当前手表做 48 小时 `SLEEP` 定向回补（`forceRecovery`、`last_sync_time=0`）：仍只返回 10-23 / 10-28 / 10-29 三段夜间会话，`sleep_raw_data` 同样只有三段，没有 10-29 午休记录。因此该次午休未显示属于手表端未上报，而不是界面过滤；本版保证手表一旦上报午休就会与同一天夜间睡眠合并展示，不推断或补造记录。
- 连接页新增「连接引导」：第 1 步检测 Google Wear（中国版/国际版，读取 `getApplicationEnabledSetting` 判断有效启用状态）、Galaxy Wearable 与已配对手表；检测到 Google Wear 时说明复用其已登记的手机身份，并提示官方应用与直连争用同一条蓝牙通道；未检测到时给出安装 Galaxy Wearable + Google Wear 并完成一次官方配对的指引（可跳转商店/官方应用，返回后可「重新检查」）。随后依次是读取身份、释放官方连接（复用 Shizuku 卡片）、验证连接与完成页；完成状态按设备记录，可在高级区域「重新显示连接引导」，未配对新手表时也能进入引导。
- 实机（Honor + Galaxy Watch Ultra）：按 1→3→4→5 步走完引导，`下一步` 自动推进、连接后显示「引导完成」，完成后引导收起且握手保持就绪；截图保存在忽略目录 `private/onboarding-20261030/`。
- 回归：302 项 JVM 测试、模拟器 UI 测试（新增多段睡眠面板用例）、`spotlessCheck`、`lintRelease`、`assembleRelease`、`check-i18n.py`（1029 条资源）全部通过；正式证书重签覆盖安装，版本仍为 0.0.12。
- 验收边界：无 Google Wear 的安装引导分支只在模拟器上检查了界面与跳转，未在真机复现完整「下载并配对」链路；引导未替代官方首次设置，恢复出厂手表仍需先走官方流程。


## 后续：全屏 Onboarding 与连接页重写（2026-10-30）

- 首启改为**全屏连接引导**：`OnboardingController` 根据完成标记与已确认身份决定是否显示；进程启动与回到前台期间的自动连接在引导显示时暂停，避免抢跑。首次进入按 环境检查 →（无 Google Wear 时）安装/配对指引 → 身份读取 → 释放官方连接 → 验证连接 → 完成 展示；跳过或完成都会记录，老用户升级不会看到该流程，且可从连接页「重新显示连接引导」重新打开。
- 检测逻辑集中到 `feature/onboarding/CompanionEnvironment.kt`：Google Wear 中国版/国际版按 `getApplicationEnabledSetting` 判断有效启用状态，Galaxy Wearable 与已配对手表分别展示；安装页可打开官方应用或商店（无 market 时回退到网页），返回后可重新检查。
- 设备连接页重写为 `ui/screens/connection/`：`ConnectionPageModel` 独立维护已配对列表、选择、手动 Node、高级展开与日志筛选（`BondedWatchSource` 可替换），页面只负责布局与回调；状态卡、选表、官方连接接管、高级/诊断拆成独立区块。保留原有测试标签与全部功能（连接/停止/重试、身份读取、手输验证、自动查询、日志复制/清空），去掉旧的连接引导内嵌卡片与重复状态逻辑。
- 实机（Honor + Galaxy Watch Ultra，正式签名覆盖安装）：已有身份用户启动直接进入概览并保持握手；连接页新布局渲染正常，高级区可展开，诊断计数与复制/清空可用；「重新显示连接引导」打开全屏引导并显示完成页。模拟器全新安装验证首启全屏、无 Google Wear 的安装指引、商店回退、跳过/完成持久化（跳过后再启动不再显示）。截图保存在忽略目录 `private/rewrite-20261030/`。
- 回归：302 项 JVM 测试、43 项 Android 模拟器测试（重写的连接页用例与全屏引导冒烟用例）、`spotlessCheck`、`lintRelease`、`assembleRelease`、`check-i18n.py`（1034 条资源）、24 项脚本测试通过；版本仍为 0.0.12，未发布标签。
- 验收边界：无 Google Wear 的真机完整「下载并配对后返回」链路仍未复现；全屏引导以环境检查与官方配对为前提，不替代官方首次设置。已有连接页测试覆盖状态可达性与平台错误，未覆盖真实蓝牙竞争下的重连抖动。

## 后续：独立传感器实验代码清理与官方桥接巩固（2026-10-30）

- **移除废弃实验链路**：用户决定放弃独立心率/血压底层传感器开发，独立实验模块、应用入口及构建引用已清理；历史研究与原始设备证据保留：
  - 移除独立 Wear 采集工程 `:watch-experiment`（含 HealthClient、ServiceProtocol、EcgListenerBinder 等）；
  - 移除私有算法回放工程 `:native-probe` 及相关 ARM32 `.so` 依赖与 JNI 适配代码；
  - 移除应用层实验模型与文件存储 `feature/experiment/ExperimentStore.kt`、`ExperimentRecord.kt`；
  - 移除设置高级组中的「实验室」页面 `ui/screens/experiment/LabScreen.kt`、路由与入口；
  - 移除中英文两套语言资源中的全部 14 项 `lab_*` 字符串；
  - 移除构建配置 `settings.gradle` 中的模块引入与 `.gitignore` 中的废弃规则；
  - 移除废弃的设计规划文档 `docs/INDEPENDENT-SENSOR-EXPERIMENT-PLAN.md`。
- **保留并巩固官方核心功能**：
  - 心率数据来源于手表端 Samsung Health 官方服务双向游标同步（`/samsung_health/wearable_message`），保持本地解析与统计；
  - ECG 与血压（BP）依靠手表端官方 Samsung Health Monitor (SHM) 桥接（`/plain_connection`、`/991`、`/992` 及 Channel 数据流）；
  - 血压测量依托手表端官方袖带校准建立基线，校准有效状态与真实非空 BP 记录同步已由实机验证闭环（三次袖带全过程与 28 天到期切换为单次会话的历史观测边界）；2026-11-04 的 v0.0.29 新增手机三轮袖带向导并移除 BP 并发远程 Intent 启动，已补充协议单元测试，界面、完整校准与崩溃修复效果仍待 Watch6 / Watch7 Ultra 真机验证；
  - 官方数据结构、解析模型、日统计及详情界面（`HealthMonitorSession`、`EcgLog`、`BpLog`、`BpCalibrationStatus`、`BpDetailSheet`、`EcgDetailSheet` 等）与原始反编译研究事实完整保留；应用内不保留任何独立传感器运行链路。
- **验证与边界（版本仍为 0.0.12，未发布标签）**：
  - 303 项 JVM 测试、44 项 Android 集成测试、24 项 Python 脚本测试全部通过（0 failures / 0 errors）；
  - `spotlessCheck`、`lintDebug`、`assembleDebug`、`assembleRelease` 通过；
  - `check-i18n.py` 1036 条资源双语一致性校验通过；
  - 正式发布证书签名 APK 仅在模拟器安装验证；UI 冒烟实测通过：心率详情可正常打开并显示无测量记录空态，血压详情正常展示同步记录、测量与校准入口、检查校准及袖带校准指引，高级设置仅包含全部设置项且无任何实验室入口；冒烟 XML 与截图归档于 `private/measurement-cleanup-20261030/`；
  - 本轮无物理设备在线连接，故未执行新的手表端实机测量；官方 9 个核心受保护源文件哈希与清理前完全一致。


## 后续：FLClash 源码对照与连接 UI 重排（2026-10-30）

- 固定阅读 FLClash Android `7fd417fb9a9a277c6a9339a8ac87f907df7c25f7` 的主题、表面层级、字阶、分组列表、状态卡、选择与折叠实现；整体评估与源码链接见 [UI-FLCLASH-REFERENCE.md](UI-FLCLASH-REFERENCE.md)。
- 连接页使用一个状态主操作、分组选择面板、次级连接指南、默认收起的官方应用切换和高级诊断；恢复自动连接开关并保留偏好持久化。区分真实忙碌与等待用户、已确认与候选身份；技术 ID 和冗长查询说明收进高级区，紧凑设备摘要最多两行。
- 心率详情/图表统一 HeartRose，导航改用中性选中底板与主题色内容，未授权通知使用中性锁图标；外观单选行只保留一个交互目标，分段控件补选中语义，步数目标面板可滚动。移除设置页失效的重复配对列表查询和日志状态。
- 303 项 JVM、最终 46 项 Android instrumentation、24 项脚本测试通过；1054 条双语资源一致，Spotless、Lint、Debug/Release 与 Android 测试 APK 构建通过。因模拟器已有正式签名包，测试 APK 同签后由 instrumentation runner 执行；现有英文定位用例固定应用语言 `en`，中文单独实际验收。
- 正式签名包实测中文连接页、选择面板；320dp/200% 系统字号下标题、关闭/刷新及操作无裁切重叠。明暗受控状态、长设备名、待验证身份与切换继续/取消另用临时视觉探针核对，探针源码已删除。证据位于 `private/flclash-ui-review-20261030/`。
- 保持 0.0.12 与现有正式证书，未发布标签。当前只有模拟器，本轮未重新进行真实手表连接/测量；官方心率、血压与 ECG 的协议、测量校准及记录处理不因展示重排而替换。

## 后续：心率详情、分箱读数与接收时间（2026-10-30）

- 心率记录解析补齐 `binning_data` / `binning`：逐分钟 `heart_rate`、`heart_rate_min` / `heart_rate_max` 展开为真实读数，外层聚合记录不再与分项重复计数；日统计使用分箱真实最低/最高，测量时间只取 `start_time`，不回退 `create_time` / `update_time`。
- `HealthDataProjection` 从留存记录派生逐日 `heartRateHistory` / `heartRateDays` / `latestHeartRate`；`heartRatePoints` 保留最近 24 小时供旧图表使用，当时导出也使用该短窗口，已由 2026-11-09 的导出 v2 全留存序列修正。首页心率卡显示最近一次真实测量及其日期时间，并给出当日最低–最高 / 平均 / 次数摘要；今日无读数时保留更早最新值并明确说明。
- 心率详情按本地日期提供真实最低 / 平均 / 最高 / 次数、当日曲线（横轴固定为该日零点至次日零点）和倒序逐条读数（完整 `yyyy-MM-dd HH:mm:ss`）；支持留存期内日期切换，切换不随后台更新跳回。
- `WatchState.lastHeartRateReportTime` 仅在 `FROM_WATCH` / `SYNC_DATA` 携带非空心率记录且持久化成功后写入 `hr_received_at`；旧缓存保持未知，不从 `create_time` / `update_time` / `lastHealthSyncTime` 补造。详情将测量时间、心率数据接收时间与整体健康同步分开显示。
- 验证完成：306 项 JVM、49 项 Android instrumentation、24 项脚本测试通过；1072 条双语资源一致，Spotless/Lint/Debug/Release 构建通过。另在 320dp、200% 字号、深色模式下验证旧最新值与今日空态、日期切换及懒加载历史读数；恢复模拟器原始密度。
- 正式证书同签覆盖安装到 Honor 手机，原始记录 UUID 无缺失，262 条心率及已有 ECG/BP 记录保留。今日显示 47 条、69–108 bpm、平均 86、最新 95@19:30:40；10 月 29 日展开 485 条，包含 14:45 等分钟分箱，统计 54–106、平均 76。
- 真实蓝牙冷回补 `seq=10452` 经 Channel 完整接收 950581 字节/15 块，262 条心率持久化成功后显示接收时间 22:12:04；后续空增量只推进整体同步时间，保留心率接收时间。证据位于 `private/health-heart-sync-20261030/`。
- 官方 APK 逆向与手表现场页面明确区分历史同步、连续数据 flush 和独立血氧远程测量入口；皮温/呼吸频率由睡眠事件生成，HRV 来自传感器事件分箱。协议与边界详见 [PROTOCOL-SPEC.md](PROTOCOL-SPEC.md)。


## 0.0.14：原生测量设置、压力对齐与健康摘要重整（2026-10-31）

- 新增「设置 → 健康测量」页与健康页/压力详情入口：睡眠血氧开关、压力连续/仅手动模式直接写入手表原生偏好 `10-measure.period` / `08-measure.period`；保留真实回读整行的元数据，仅改 `int_value` 与单调 `update_time`，`SUCCESS` 回执之外必须收到匹配身份、数值与修订的回读才显示已确认。另有远程打开手表测量界面与原生设置页的入口，均只报告已排队或已回执，不伪造测量结果。
- 官方没有任意分钟间隔的定时点测选项，因此不实现绕过官方流程的定时点测：血氧提供睡眠自动测量开关与手动测量，压力提供连续/仅手动两种模式；是否新增其他周期属于产品假设，须先有协议与实机证据。
- 压力数据按官方原始区间 0–10 / 11–20 / 21–80 / 81–100 分类（先按原始小数分类再显示取整），展开 `binning_data` 并丢弃外层小时聚合；详情新增测量时间、逐日统计与曲线、倒序读数；呼吸训练明确标注仅为放松引导。
- 健康首页心率/压力/心电/血压改为紧凑摘要卡：仅保留图标、标题、主数值与单位/必要分类，完整时间与日统计移入详情，修复半宽卡文字溢出；健康同步行设置入口改为带文字的按钮；测量设置弹窗标题补齐内边距，与设置页及既有详情面板一致。
- 「关于与更新」改用设置页同款分组卡片与选择行；新增 1/3/6/12/24 小时自动检查周期（默认 12 小时），前台每 15 分钟重新评估是否到期，手动检查与后台检查共用同一逻辑；失败同样记录检查时间，避免频繁请求。
- 睡眠历史会话与日期切换：解除此前 `latestDaySessions(sessions, now - 36小时)` 对非近期睡眠的一刀切清空。首页若无近 36 小时睡眠，回退展示最近一次睡眠并标注「最新测量」及日期；睡眠详情支持按日期切换浏览留存期内的全部历史睡眠、分期时序图与统计；`scheduleSleepAnalysis` 支持对 30 天内有原始数据的记录进行离线分析。
- 去重与清理：心率/压力详情共用日期胶囊与统计格组件；移除未使用的压力辅助函数与未引用文案；远端回执解析统一为健康响应 `message_info.result`，不再猜测多种错误外形。
- 验证：322 项 JVM、50 项 Android instrumentation、24 项脚本测试通过；1120 条双语资源一致，Spotless、Lint 与 Debug/Release 构建通过；模拟器验证测量设置页开关禁用态、关于页检查更新（实际读取公开清单）与周期选择持久化；真实手机的健康摘要、详情与蓝牙回补在 0.0.13 验证后保持同一代码路径，本轮升级未清空本地数据。原生偏好写入的手表端回读仍待连接手表时复验。

## 后续：多段睡眠、心率图与动态常驻通知（2026-10-31）

- 睡眠详情把同一睡眠日的夜间与全部小睡合并到一条真实时钟轴：`SleepHypnogram` 接收会话列表，按最早开始到晚结束绘制统一时间范围，每段会话只画实际 `Segment`，间隙不补造清醒/入睡阶段；结构条与图例通过 `SleepParser.combinedStageMinutes` 汇总当天所有真实分期。无分期的补记仍只显示记录区间并明确不推断阶段。
- 心率今日曲线补齐与其他健康指标一致的交互：点按/拖动选择最近读数、显示时间与 bpm、选择指引线与高亮点；曲线改为平滑渐变面积，点数过多时不再逐点绘制圆点。近 7 天趋势从“0 起点日均柱”改为当日最低–最高范围胶囊，叠加日均标记，支持点按/拖动查看最低、日均、最高。
- 前台连接服务订阅 `WatchController.repositoryState` 的当前 `WatchRepository.state`，动态构建常驻通知：设备名/连接状态、当天最新心率、步数/目标完成百分比与手表电量。通知仅依赖 `ConnectionNotificationSnapshot` 的展示字段并通过相等性去重，设置、固件、日志等无关状态变化不会反复刷新；今日无心率时显示未知值，不把昨天读数冒充今日。
- 验证：327 项 JVM、54 项 Android instrumentation、24 项 Python 脚本测试通过；1132 条双语资源一致，Spotless、LintDebug 与 Release 构建通过。新增测试覆盖多段睡眠合并统计与 hypnogram 语义、心率两张图的点按探针，以及通知快照的今日心率筛选、零步数与无关状态去抖。

## 后续：压力图表与正念区块顺序（2026-10-31）

- 今日压力沿用心率图的 132dp 绘图区、渐变面积、平滑线、选择信息条、指引线与高亮点；压力保留 0–100 原始分数、0/10/20/80/100 分级色带和有效零分，信息条按原始小数分级。两张图共用 `smoothChartPath`，平滑控制点保持在相邻实测值范围内。
- 压力图只绘制所选本地日期的有效读数，墙上时间决定横坐标和选中时间，切换空日期清除旧探针；横向拖动选点，纵向手势继续滚动页面；窄屏/大字号横轴自动保留 00:00、12:00、24:00，避免时间标签挤压。正念呼吸放松移到逐条压力读数之前，历史读数保留末尾按时间倒序与展开/收起。
- 验证：327 项 JVM、21 项相关 Android instrumentation 测试通过（压力 8、心率 2、健康布局 11），1134 条双语资源匹配，Spotless、LintDebug、Debug/Release 构建通过。覆盖零分、小数分级、点按关闭、横向拖动、跨日/空日、夏令时、320dp/双倍字号、纵向滚动及区块顺序。
- 同一正式签名 `0.0.14` 覆盖安装到 Honor 手机，已验证手机内 APK 与构建产物 SHA-256 一致，既有安装与配置保留，Ultra 会话恢复、常驻通知显示真实心率/步数/电量，安装后无应用崩溃；证据保存在 `private/stress-chart-20261031/`。

## 0.0.15 发布前验收（2026-10-31）

- 汇总本轮多段睡眠时间线、心率与压力图表、动态常驻通知及正念区块顺序；版本按现有发布脚本递增。
- 修正云端小屏 UI 测试对尚未组合的懒加载列表子项直接定位的问题：睡眠与呼吸练习测试先滚动列表查找目标，再检查显示或执行操作。
- CI 的可选产物上传与 Release 保持一致，存储配额不足时保留构建和测试的真实结果，不让上传失败覆盖验证结果。
- 本地发布门禁通过：327 项 JVM、62 项 Android instrumentation（360dp × 640dp 模拟器）及 24 项脚本测试，1134 条双语资源、Spotless、LintDebug 与 Release 构建均通过。

## v0.0.17 后全仓审查与整理（2026-11-01）

- 修复健康报文并发写入缺少同步保护、RFCOMM 断开回调与控制器停止的反向锁路径，以及部分官方应用停用后主操作消失。健康并发测试用慢磁盘提交稳定复现旧实现重启丢记录；恢复修复后通过。
- 心率、压力和通用指标共用本地日期横轴、探针与平滑渐变，心率周图也只消费横向拖动。补充夏令时、空日期、选点与页面纵向滚动回归。
- 删除 18 个无生产调用的旧方法和 51 项双语无引用文案，修正与 Compose 内部资源重名的键；Lint 从 109 降至 56 个警告、保持 0 错误，未关闭规则。
- 重写架构导航与当前技术债；详细发现、改进顺序和验收条件见 [本轮审查](REVIEW-2026-11-01.md)。
- 最终验证：344 项 JVM、76 项完整 Android instrumentation、24 项脚本测试通过；1112 项双语资源匹配，Spotless、Lint、Release 构建和 diff 空白检查通过。本轮仅使用模拟器，未重新验收真实蓝牙断开/整夜同步，未发布。

## 0.0.20：耗电与定时同步复核（2026-11-02）

- 对应 S02 / S06：提取健康请求窗口与连接退避策略；自动全量回补按设备限频 1 小时，显式历史窗口优先，未入队不消耗回补额度。周期查询仍由 `AutoQueryCoordinator` 单独持有，默认间隔和已有用户偏好保持原值。
- 对应 S02 / S05：主动重连指数退避至 60 秒，稳定连接 30 秒才重置，BLE 唤醒至少间隔 120 秒；发送队列和被动连接等待改为可中断阻塞，断线与停止显式释放等待。
- 对应 S02 / S07：控制回包避免重建整份健康档案，落盘失败后的数据仍保留重试；减少重复睡眠投影与相同失败输入的分析调度，根页面使用生命周期感知订阅。同步更新协议、架构导航、双语设置说明与发布说明。
- 发布前本地门禁通过：377 项 JVM、24 项脚本测试，1118 项双语资源一致；Spotless、Lint、Release 构建与 Android 测试 APK 编译通过，Lint 为 0 错误 / 56 警告。
- 本轮未启动模拟器；`adb devices -l` 无在线真机，新增 3 项 Android 设备测试仅编译，未执行。整夜耗电、实际重连时延与旧固件历史窗口仍待真机对照；确定性请求计数不等于实际省电比例。详细证据和只读采集方式见 [耗电审查](POWER-AUDIT-2026-11-02.md)。

## 后续：概览整轮刷新防重入（2026-11-02）

- 概览右上角刷新由 `RefreshCoordinator` 跟踪整轮设备查询和健康同步，不再只依赖健康请求自身的繁忙检查。未完成时直接忽略重复调用，不排队；启动资料读取或健康同步中也不允许发起新的整轮刷新，按钮显示进度并禁用。
- 设备查询等待有效回包，缺失回包 30 秒后结束等待并记录日志，不自动重试；健康分块继续沿用 60 秒续期超时，不能被设备查询超时提前放行。断线、关闭或派发失败释放本轮状态；带本轮代次的设备护理任务失效后不再补发。
- 验证：新增 10 项刷新回归，包括连续点击 100 次、100 个并发调用只发送一轮、发送阶段收到快速回包、健康分块续期、发送失败、超时与断线代次隔离。全量 387 项 JVM、24 项脚本测试通过；1122 项双语资源一致，Spotless、Lint、Debug/Release 构建与 Android 测试 APK 编译通过，Lint 为 0 错误 / 56 警告。
- 本轮未运行模拟器或真机测试；没有将请求次数验证换算成实际续航改善。版本号保持不变。

## 0.0.24：接收队列解耦、页面投影隔离与健康归一化（2026-11-03）

- **接收与连接生命周期解耦**：引入 `SessionReceiveQueue` 为当前 WCS 会话提供有界（64 帧 / 8 MiB）串行消费队列，将 `onEnvelope` 的 Protobuf 封包反序列化与健康数据落盘移出 `WatchController` 全局锁，杜绝大包同步期间阻塞控制器的停止、重连与设备切换。入队和执行均绑定 `ConnectionRequestGate` 请求代次与活动状态；切换或断开时通过 `deactivate()` 立即失效旧会话，防止过期数据覆盖新设备状态。
- **页面状态投影与 Compose 重组隔离**：引入 `WatchPageState` 与 `WatchPage`（`DASHBOARD`、`HEALTH`、`NOTIFICATIONS`、`SETTINGS`、`WATCH_FACE`）领域投影，以及 `RefreshActionState` 刷新派生状态。通过 `distinctUntilChanged` 过滤无关状态更新，使后台步数、心率等健康同步不再触发概览页或根布局重组。
- **健康持久化效率与事务完整性**：`HealthRecordStore` 引入私有 `normalizedIdentity()`，避免在 `merge()` 和 `replaceTodaySteps()` 中对已归一化对象重复调用 `normalized()` 产生冗余 JSON 序列化/反序列化；在数据包解码、投影、写盘与回复确认全链路强制校验 `isActive()`，确保会话失效时不落盘、不确认，维持落盘前置确认（Durable-before-ACK）原则。
- **验证**：417 项 JVM 单元测试、24 项 Python 脚本测试通过；1130 条双语资源一致；Spotless、LintDebug（0 error）与 Release 构建均通过。新增 `SessionReceiveQueueTest`（队列容量有界、串行性、代次失效与生命周期同步）与 `WatchPageStateTest`（跨页面投影隔离与重组独立性）。

## 血管负荷协议与日志复核（2026-11-06，随 0.0.32.001 Nightly 发布）

- **协议范围**：按手表能力声明显示入口，接收 `mean_arterial_pressure` 结果并保留基线/重置；历史回补走现有零游标冷同步及步数快照保护。官方手表样本不能证明 `VASCULAR_LOAD` 会筛选同步表，因此允许其他健康表回传，不将完成闭环解释为完整数据库导出；具体依据见 [PROTOCOL-SPEC.md §6.6.9](PROTOCOL-SPEC.md)。
- **回补生命周期**：修正前序同步超时后无法启动回补、入队失败后仍挂起的情况；请求异常保留类别，取消继续传播，失败不保存首次完成标记。
- **日志（S03/S05）**：补齐能力确认、接收/解析条数与回补排队、完成、失败、取消上下文。普通日志不带血管读数或记录原文；健康 JSON 解码错误只输出类别、序号、长度与耗时，样本和原始异常详情受现有全局调试开关及隐私提示约束。
- **验证边界**：515 项 JVM 测试、Lint、Release 构建与 Android 测试源码编译通过；1327 项双语资源一致。新增普通错误日志隐私用例仅已编译，血管负荷的真实手表同步与界面验收仍待设备连接后执行。

## 血管负荷健康页入口修复（2026-11-06，随 0.0.32.002 Nightly 发布）

- **根因与修复**：`WatchPage.HEALTH` 创建页面快照时遗漏 `vascularLoadSupported` 和 `vascularLoad`，使健康页始终按默认的不支持状态隐藏卡片，且无法接收历史回补结果；补齐两项投影字段，保留其他页面的状态隔离。
- **回归验证**：新增两项 `WatchPageStateTest`，分别覆盖能力标记变化、能力不变时回补结果更新，并确认概览、设置与表盘页面不受影响。修复前两项均失败，修复后通过；523 项 JVM 测试、43 项发布脚本测试、1333 项双语资源检查、Spotless、LintDebug、Release 构建与 Android 测试源码编译通过。云端测试报告确认两项回归均已执行，523 项测试无失败或跳过；云端 Lint 为 0 错误、86 警告。
- **发布核验**：通过 `--nightly` 发布 `0.0.32.002`（code `32002`），CI 与 Release 工作流均成功，GitHub 标记为 prerelease。匿名下载的 APK 与 Release 附件字节一致（23,147,940 字节，SHA-256 `bd1f45458218112e7d0b67a087e7e1b92033dc852a5ec89f5b988bbcc3c7b4bf`），与 `nightly.json` 和 `.sha256` 文件一致；包名与版本通过 `aapt2` 核验，`apksigner` v2、v3 校验通过，证书 SHA-256 为 `86de4a33245393411b43ad0d4fa99233f0ca6f926cef6f60982eac9eba3f1525`，与稳定版相同。APK 不可变地址与保留标签均指向提交 `032c3643a3157620340c18f2d39021b27e29e9f9`；稳定清单、`apk` 分支和 Latest（`0.0.32`）保持不变，源码仓库仍为私有。
- **验收边界**：当前本地与远程 ADB 均无连接设备；真实手表同步、健康页卡片交互和覆盖升级尚未验收。

## 血管负荷可视化优化（2026-11-06，0.0.32.003 Nightly）

- **展示方式**：参考 [Samsung Health 官方介绍](https://www.samsung.com/uk/apps/samsung-health/) 的五档状态与七日记录，沿用应用主题派生的血管负荷色、圆角卡片和详情面板。摘要卡增加五段刻度与当前位置；基线未完成时显示三晚进度，详情突出日期、状态与个人基线的关系。
- **趋势与历史**：七日图加入分区、平稳区和虚线基线，复用平滑渐变曲线与点按/横向拖动探针；每日选择最新记录，空缺、不可评估和基线变更处不连线，基线建立以空心点表示。保留全部原始记录，以分组行分批展示历史，不显示未经解释的原始测量值。
- **验证**：新增四项每日图表投影测试，覆盖同日新旧结果、缺日与范围、重置/无效结果和跨夜追踪日期；527 项 JVM 测试、43 项脚本测试、1337 项双语资源检查、Spotless、LintDebug（0 错误、86 警告）与 Release 构建通过。预设主题及默认系统色的血管负荷标记对明暗图表背景的对比度均大于 5:1。
- **验收边界**：用户已确认 `0.0.32.002` 的入口和数据可见；本次补充窄屏、大字号、明暗主题及每日选点的 Compose 测试，仅完成源码编译。本地与远程 ADB 当前均无设备，新视觉尚未进行实际渲染、真机操作或覆盖安装验收。
- **发布核验**：通过 `--nightly` 发布 `0.0.32.003`（code `32003`），CI 与 Release 工作流均成功，GitHub 标记为 prerelease。匿名下载的 APK 与 Release 附件字节一致（23,152,036 字节，SHA-256 `c1c8d80029ced67ea4afc67a4ffbea5ff14a40ab766431307dcfc106980e6f38`），与 `nightly.json` 和 `.sha256` 文件一致；云端 527 项 JVM 测试无失败或跳过，43 项脚本测试与 1337 项双语资源检查通过，LintDebug 为 0 错误、86 警告。`aapt2` 确认包名与版本，`apksigner` v2、v3 校验通过，证书 SHA-256 为 `86de4a33245393411b43ad0d4fa99233f0ca6f926cef6f60982eac9eba3f1525`，与稳定版相同。APK 不可变地址与保留标签均指向提交 `2566c7f14030a63a076f6f94d33d278f7ffee1d5`；稳定清单、`apk` 分支和 Latest（`0.0.32`）保持不变，源码仓库仍为私有。

## 0.0.33 正式版（2026-11-06）

- **发布范围**：汇总三个 `0.0.32` Nightly 的血管负荷能力、健康页入口修复、可视化和双通道更新，版本为 `0.0.33` / `33000`；应用实现与已测试的 `0.0.32.003` 一致。
- **用户反馈**：用户已自行测试 `0.0.32.003`，决定保留当前实现并发布正式版；该反馈不扩展为所有机型、固件及手机环境的完整验收。
- **发布核验**：通过无参数发布 `0.0.33`（code `33000`），CI 与 Release 工作流均成功，GitHub 标记为 Latest。与 `v0.0.32.003` 相比仅版本号和 `RELEASE-NOTES.md`、`OPTIMIZATION-PROGRESS.md` 变化，应用代码一致。匿名下载的 APK 与 Release 附件字节一致（23,152,036 字节，SHA-256 `aa0859d50110aae22aee37d694be30d8a0cb09045d06877431e1a2bc2af7e1f7`），与 `version.json` 和 `.sha256` 文件一致；云端 527 项 JVM 测试无失败或跳过，43 项脚本测试、1337 项双语资源检查通过，LintDebug 为 0 错误、86 警告。`aapt2` 确认包名与版本，`apksigner` v2、v3 校验通过，证书 SHA-256 为 `86de4a33245393411b43ad0d4fa99233f0ca6f926cef6f60982eac9eba3f1525`，与上一稳定版及 `0.0.32.003` 相同。APK 不可变地址与保留标签均指向提交 `aa83d5963a1d419411f4fb753169058bfe6c346b`；`nightly.json`、`apk-nightly` 分支和 `0.0.32.003` Nightly 未改动，稳定通道读取新 `version.json`，Nightly 通道比较两份清单后升级到 `33000`，源码仓库仍为私有。

## 稳定版与 Nightly 双通道更新（2026-11-06，已随 0.0.32.001 Nightly 发布）

- **应用内更新**：「设置 → 关于与更新」新增持久化通道选择，现有与新用户默认稳定版。稳定通道只读取 `version.json`；Nightly 同时读取稳定与测试清单并选择较新版本，尚无 Nightly 清单时回退稳定版。切回稳定通道不降级，等待后续稳定版。
- **取消与缓存**：切换通道取消旧检查、下载及尚未完成的安装校验；取消后的网络异常不能覆盖新通道状态。各次下载使用独立临时文件，共享一次启动清理屏障，避免旧任务误删新 APK；自动检查时间按通道分别记录。
- **版本与发布**：稳定版使用 `0.0.N`，Nightly 使用 `0.0.N.MMM`（`001`–`999`）；新版本 code 为 `N × 1000 + MMM`，兼容历史稳定版 `code=N`。无参数发布递增稳定版第三段，`--nightly` 递增第四段。Nightly 在 GitHub 标为 prerelease 且不占用 Latest；公开更新源的 `version.json` / `apk` 与 `nightly.json` / `apk-nightly` 独立更新、各自防回滚，继续保留不可变 APK 提交地址。
- **验证**：521 项 JVM 测试、43 项发布脚本测试通过；1333 项双语资源一致，Spotless、LintDebug、Release 构建与 Android 测试源码编译通过。脚本集成测试在临时本地 Git 仓库验证通道隔离、重跑和旧 APK 地址保留，未向生产更新源写入。
- **验收边界**：新增 8 项 Android 设备测试覆盖通道偏好、取消竞态、自动检查隔离、清单选择及中英文窄屏大字号布局，仅已编译；本轮没有可用设备，界面操作、系统安装器与实际覆盖升级尚未验收。
- **首个 Nightly 发布（0.0.32.001）**：修正两项发布集成测试固定读取稳定清单与 APK 分支的问题，使其按当前版本选择通道；43 项脚本测试通过后以 `--current` 发布。Release 标记为 prerelease，Latest 仍为 `0.0.32`；`nightly.json` 与 `apk-nightly` 更新，`version.json` 与 `apk` 保持不变。
- **发布核验**：CI 与 Release 工作流均成功。匿名下载的 APK 与 Release 附件字节一致（23,147,940 字节，SHA-256 `ff8bd3b40f4a7c3e45b5d8b898424b513ff8ace311a13c66afb014dfa5984dac`），与更新清单及 `.sha256` 文件相符；包名 `dev.ricky.galaxywatchmanagerfree`，版本 `0.0.32.001` / `32001`；`apksigner` v2、v3 校验通过，证书 SHA-256 与稳定版同为正证书。APK 地址固定在提交 `3f376c0231d3f8b01075683ade251f2529855516`，由保留标签指向同一提交。通道切换与实际覆盖升级仍待真机验收。

## 手表自定义名称同步修复（2026-11-06，待真机验收）

- **原因与协议**：旧实现重建仅含名称、来源和新时间的 DataMap，未保留官方读改写流程的元数据；下发后立即提示成功，重连回包又无条件覆盖本机昵称及偏好。依据已逆向的 Watch7 Plugin `WatchStatusMessageSender.sendWatchName`，首轮修复改为读取已有条目，仅修改 `stringName`、`from=phone`，保留 `key`、`type`、`time` 和其他字段，再写入并回读。该轮仍将 DataItem URI 重建在手机节点下；`0.0.33.001` 实机反馈为手表未确认、系统名称未改变，URI 修正见下节。
- **状态与交互**：只有写入后匹配的非手机自回声才提示重命名成功；首次读取、排队成功和手机回声均不能确认。离线明确提示只保存本机，发送失败与超时分别反馈；本机昵称优先于蓝牙旧缓存，旧回包不覆盖昵称或其偏好，未设置本机昵称时仍可跟随手表名称。
- **生命周期与竞态**：连接就绪后重新同步本机昵称；断线和仓库关闭取消未完成任务。名称转换与命令超时共用同一把锁，避免超时后的迟到条目重新启动写入、旧超时误报新改名失败。连续改名仅确认最新目标。
- **本地验证**：旧名称覆盖和超时并发测试均先复现失败再通过；新增 16 项 JVM 测试，完整 543 项单测无失败或跳过，43 项脚本测试与 1339 项双语资源校验通过。Spotless、LintDebug 和 Release 构建通过，Lint 为 0 错误、85 警告。
- **验收边界**：`adb -H 127.0.0.1 -P 15037 devices -l` 没有连接设备，本轮未验证真机界面、手表端名称持久化或实际断线重连；已发布 `0.0.33.001 Nightly`（versionCode `33001`），供真机测试。
- **Nightly 发布核验**：通过 `./scripts/release.sh --nightly` 发布，云端 CI 与 Release 均成功；543 项 JVM 测试、43 项脚本测试与 1339 项双语资源检查通过，Lint 为 0 错误、85 警告。匿名下载的 APK 与 Release 附件字节一致（23,152,036 字节，SHA-256 `41760f534786eba6a1af4cfc1b70fe7e956f609d5a55136c74f0e0f8e5648d05`），与公开清单及 `.sha256` 文件相符；包名与 `0.0.33.001` / `33001` 正确，`apksigner` v2、v3 校验通过，证书 SHA-256 与稳定版相同。Release 为 prerelease，Latest 仍是 `0.0.33`；`nightly.json` 与 `apk-nightly` 已更新，APK 固定到由保留标签指向的提交 `98b3c82c8ff8207fd1c3e0f8f638f82445815fa5`，稳定版清单与 `apk` 分支保持不变。源码仓库保持私有，公开 feed 仅含说明、更新清单和签名 APK。

## 手表名称 DataItem URI 修正（2026-11-06，0.0.33.002 Nightly 实机反馈未改名）

- **静态依据**：官方 `sendWatchName` 以手表 `peerId` 查询 DataItem，`F.c(v.a(item))` 保留返回条目的完整 URI；Wear 服务 `hnf.a` 保留显式 host，`gyg.e` 按 host 和 path 查找或创建条目。首轮只保留 DataMap，接收路由丢弃 URI 节点且发包统一重建为手机节点，可能修改另一条同路径记录；该差异已修正，是否足以解决手表端问题仍待真机验证。
- **该版实现**：`WatchRepository`、`WatchNameSync` 和 `WcsSession.writeSettingItem` 完整传递并写回原始 URI，帧的 sourceNode 仍使用手机身份；常规设置继续在手机节点下创建。确认同时匹配原始 URI 和目标名称，忽略其他节点同路径回包；缺失 authority 或路径不符的条目不能作为模板。每次改名和断线重连重新读取，清除上次 URI，不改变旧回包、手机自回声和超时保护；其中“每次必须等网络新回传”的问题见下节。
- **本地验证**：新增 4 项 URI 回归测试，先通过接口传递暴露 URI 丢失和误确认，4 项均失败；修复后名称同步 17 项测试通过，完整 547 项 JVM 测试无失败、错误或跳过。43 项脚本测试、1339 项双语资源检查、Spotless、LintDebug（0 错误、85 警告）、Release 构建与 Android 测试源码编译通过。
- **验收边界**：本轮未操作真机；本版供测试手表系统名称是否改变、断线重连及重启后的名称是否持久化，不能以单元测试或排队成功代替设备确认。后续收到用户仍未改名的反馈，URI 修正不足以解决整条链路。

## 手表名称本地模板与改名发送断点（2026-11-06，0.0.33.003 Nightly 真机改名成功，持久化待验收）

- **已复现断点**：官方 `WatchStatusMessageSender.sendWatchName` 的 `getDataItem` 查询手机端本地数据库。客户端却丢弃就绪前及无待处理命令时收到的名称条目，改名时必须等 `dataitem_value_req` 再产生新 DataItem 才写。`WcsSession` 本来已恢复配对快照并上报增量游标，`WatchNameSync` 却未保留它。用合成快照回放及空闲名称后连续改名先复现零写入，两项测试均失败；同一 WCS 实例自动重连只恢复一次快照，另加一项回归先复现重连未写入。
- **官方核对**：`dataitem_value_req` 路径及目标路径的 UTF-8 原始字节与插件一致，未发现强制刷新参数。手机 Wear 服务 `gyi.e` 对 payload 与 assets 相同的更新去重，不能依赖相同名称必定重新推送。`hjx` protobuf descriptor 的实际字段为 1 包名、2 URI、4 数据、5 序号、6 删除标记、7 来源节点、8 assets、9 签名、10 修改时间，当前帧编码与之相符；Java 成员声明顺序不是 protobuf 字段编号。手机蓝牙 `setAlias` 仅证明本地 alias 更新；`btinfosync` 的设备筛选与用途不足以证明是手表自身改名的替代通道。
- **修正**：保留当前手表的原始名称 URI/DataMap，包括就绪前恢复及空闲时收到的条目；改名直接读改写，缺模板才请求网络读取。模板严格匹配当前手表节点，其他 owner 不可提供模板或确认。复核还发现 `WcsSession` 在分发前曾以 DataItem URI owner 改写 `watchNode`，使该校验可能失效，已移除这条身份更新路径，仅由 NodeInfo 更新会话对端。断线取消命令及待确认 URI，但保留按节点验证的本地条目供同设备自动重连使用；换节点拒绝旧模板。连续改名立即发送最新值，仍只确认写入后原 URI 上匹配的手表回报。
- **阶段反馈**：无模板超时返回 `SOURCE_UNAVAILABLE`，双语提示尚未发送改名；实际写入后无确认才返回 `UNCONFIRMED`。诊断区分 `read_template`、`write` 与 `confirm_write`，不新增名称内容或设备标识日志。仅有模板、名称已相同或发送已排队都不能提示手表已改名。
- **本地验证**：4 项新增 JVM 回归覆盖恢复快照后无重复回传、空闲条目与连续改名、其他 owner 模板、同设备自动重连；名称同步共 21 项，完整 551 项 JVM 测试无失败、错误或跳过。43 项脚本测试、1340 项双语资源校验、Spotless、LintDebug（0 错误、85 警告）、Release 构建及 Android 测试源码编译通过。新增 `ConnectionIdentityTest.dataItemOwnerCannotReplacePairedWatchNode` 从真实 `WcsSession.onEnvelopeReceived` 入口验证其他 owner 不得改写已配对节点；该设备测试已编译，因无设备尚未运行。
- **证据与验收边界**：REA 证据保存在被忽略的 `private/`。现有 Wear APK 是手机服务，缺少手表名称接收组件 APK，尚未验证最终系统改名 API。ADB 15037 无连接设备；本轮证明并修正了“不发写入帧”的客户端断点，不能据此断言用户设备上的所有失败原因已排除，系统名称变化、重连及重启持久化仍待真机验收。修正纳入 `0.0.33.003 Nightly`，供用户覆盖升级后测试。
- **Nightly 发布核验**：通过 `./scripts/release.sh --nightly` 发布，Release `42208438038` 与发布提交 CI `42208437292` 均成功。匿名下载的 APK 与 Release 附件及 `.sha256` 字节一致（23,168,420 字节，SHA-256 `a1e1e2508dc49afbebb1f36f3b954cb4f3ebe9ee9e6a765d0899780493a74a2f`）；`aapt2` 显示包名与 `0.0.33.003` / `33003` 正确，`apksigner` v2、v3 校验通过，证书 SHA-256 与稳定版相同。Release 为 prerelease，Latest 仍是 `0.0.33`；`nightly.json` 与 `apk-nightly` 已更新并固定到提交 `3cdc1ce1c002ee1311a2639d5ffe515513dce9bc`，稳定版清单与 `apk` 分支保持不变。源码仓库保持私有，公开 feed 仅含说明、更新清单和签名 APK。

## 改名已生效后的确认提示（2026-11-06，0.0.33.004 Nightly 真机反馈未发送，后续修正见下节）

- **真机反馈**：用户覆盖安装 `0.0.33.003 Nightly` 后确认改名成功，手表系统名称也已变化；Toast 仍提示“手表尚未确认设置，请重试”。这证明实际写入已生效，但不能据此确认断线重连或手表重启后的持久化。
- **已复现的反馈问题**：名称写入成功进入队列后，4 秒没有匹配回读就返回 `UNCONFIRMED`，仓库直接使用通用设置的“请重试”文案。新增回归通过真实 `WatchNameSync` 写入与定时器，验证“已提交、无回读”不能提示重试或伪造成功；先运行 22 项名称测试得到 1 项失败，修正后通过。该测试只复现反馈分支，不声称回放了本次真机回包。
- **修正**：写入已提交但没有匹配回读返回独立的 `SUBMITTED`，中英文提示“改名请求已提交，请在手表上查看名称”；取不到模板仍提示尚未发送，写入失败仍提示发送失败，只有匹配回读才提示手表已重命名。原始 URI、目标名称和手机自回声过滤保持原有确认约束，移除已无引用的通用“尚未确认，请重试”资源。
- **本地验证**：名称同步 22 项，完整 552 项 JVM 测试无失败、错误或跳过；1340 项双语资源检查、Spotless、LintDebug、Release 构建与 Android 测试源码编译通过。
- **验收边界**：本机及 15037 ADB 均无连接设备，没有取得本次回包；无法判断确认超时究竟源于无独立回读、回包被过滤或回报较晚。本轮修正反馈语义，真机 Toast 尚未重新验收；修正纳入 `0.0.33.004 Nightly`，供用户覆盖升级后验收提示及重连、重启持久化。
- **Nightly 发布核验**：修正提交与发布提交的 CI 均成功，Release 工作流 `42216228681` 完成签名、发布与镜像。匿名下载的镜像 APK 与 Release 附件及 `.sha256` 字节一致（23,168,420 字节，SHA-256 `48f6ea36a9059f7f01deae1d752fc3872118255a126bf072571013a7e60bcd3e`）；`aapt2` 显示 `0.0.33.004` / `33004`，包内包含「改名请求已提交，请在手表上查看名称」且不再包含旧的「尚未确认，请重试」，`apksigner` v2、v3 校验通过，证书 SHA-256 与稳定版相同。Release 为 prerelease，Latest 仍是 `0.0.33`；`nightly.json` 与 `apk-nightly` 已更新并固定到提交 `789ff1c313bb6298282105ed4469049142da6330`，稳定版清单与 `apk` 分支保持不变。真机提示与持久化仍待用户验收。

## 名称模板与设备确认的来源过滤（2026-11-06，0.0.33.005 Nightly 用户确认改名问题解决）

- **用户反馈与版本差异**：用户反馈 `.003` 能改名、`.004` 又无法改名，实际 Toast 为“未取得手表原始名称数据”，对应 `SOURCE_UNAVAILABLE`，尚未进入写入。`git diff v0.0.33.003 v0.0.33.004` 及两版实际 APK 的方法核验均表明名称接收、分发、读取和写入逻辑未变，仅确认超时结果与 Toast 资源变化；这是共同既有缺陷的排查依据，不能否定真机失败反馈。静态证据保存在被忽略的 `private/rename-003-004-apk-diff-20261106.evidence.json`。
- **本地复现**：假设手机最近写入的名称条目经对端回传并进入接收快照，`WearDataSnapshot` 按包名和完整 URI 用它替换旧条目；重启恢复时 `WatchRepository.applyWatchSetting` 和 `WatchNameSync.receive` 均通过通用 `WatchSettingSchema.decode` 拒收 `from=phone`，导致零写入、最终报模板不可用。生产代码仅缓存接收帧，本地写入不会自动进入快照；测试用合成回声模拟该前提，没有取得用户这次的实际回包。新增回放先复现 `SOURCE_UNAVAILABLE`；扩大针对性测试后 38 项中 3 项失败。
- **修正**：名称条目先交给专用同步器，验证当前手表 URI 与有效 `stringName` 后保留完整 DataMap。`from=phone` 可作为读改写模板，但不能导入已确认的手表名称、确认改名或因重复回声再次发送；通用设置继续过滤手机自回声，非当前手表或畸形名称继续拒绝。没有模板时仍如实反馈尚未发送，进入队列后无匹配回读仍只返回 `SUBMITTED`。
- **验证与测试缺口**：修正后 555 项 JVM 测试（名称同步 25 项）、43 项脚本测试、1340 项双语资源检查、Spotless、LintDebug（0 错误、85 警告）、Release 构建及 Android 测试源码编译通过。新增 `ConnectionIdentityTest.restoredPhoneOriginNameReachesWriteWithoutBecomingConfirmedState` 覆盖真实文件恢复、WCS、仓库及名称同步入口，离线传输只断言到达写入调用，不将队列失败当作发送成功；本机及 15037 无设备，该集成测试仅编译、尚未运行。此前浅层测试把“手机自回声不能确认”误扩展为“不能提供模板”，现已分开验证。
- **用户验收反馈**：修正纳入 `0.0.33.005 Nightly` 后，用户反馈“终于解决，发布正式版”，确认本次改名问题解决。尚未采集此次真机回包，无法进一步确认触发前提；用户也未单独报告断线重连与手表重启后的持久化。
- **Nightly 发布核验**：Release `42237201826`、修正提交 CI `42237144357` 与发布提交 CI `42237200510` 均成功。匿名下载的 APK 与 Release 附件字节一致（23,168,420 字节，SHA-256 `eadd690167b27a20b257390bc58bb800183dd09bd6b4f9a1b15bd3195b433167`）；`aapt2` 确认 `0.0.33.005` / `33005`，`apksigner` v2、v3 校验通过，证书 SHA-256 与稳定版相同。Nightly 清单与 `apk-nightly` 固定到提交 `750ab04df1078e0ad96d0f010a3b01ae4415c987`；稳定清单、`apk` 分支和 Latest `v0.0.33` 未变，源码仓库保持私有。

## 0.0.34 正式版（2026-11-06）

- **发布范围**：汇总 `0.0.33.001` 至 `0.0.33.005` 的名称读改写、模板恢复、节点校验和提示修正，沿用用户确认解决问题的 `0.0.33.005` 应用实现；版本为 `0.0.34` / `34000`，继续使用原正式签名。
- **验收范围**：用户确认本次改名问题解决并要求发布正式版；未将该反馈扩展为断线重连、手表重启持久化或所有机型、固件均已验收。名称快照恢复的 Android 集成测试仅编译，尚未运行真机。
- **发布核验**：通过无参数发布 `0.0.34`（code `34000`），Release `42240818326` 与发布提交 CI `42240815892` 均成功，GitHub 标记为 Latest。与 `v0.0.33.005` 相比仅版本号与文档变化，`app/src`、Gradle、脚本和工作流无差异，应用实现即用户确认可用的版本。匿名下载的 APK 与 Release 附件字节一致（23,168,420 字节，SHA-256 `33d5537cf10990b093c468ea8086fd8e1f3e979aa3cf9e18351304bedc6a3dea`），与 `version.json` 及 `.sha256` 文件一致；云端 555 项 JVM 测试无失败或跳过，43 项脚本测试、1340 项双语资源检查通过。`aapt2` 确认 `0.0.34` / `34000`，`apksigner` v2、v3 校验通过，证书 SHA-256 为 `86de4a33245393411b43ad0d4fa99233f0ca6f926cef6f60982eac9eba3f1525`，与上一稳定版相同。APK 不可变地址固定到提交 `ad9543a5d956bf80e3aec37fb82c96beee321fb0`；`nightly.json`、`apk-nightly` 分支及 `v0.0.33.005` Nightly 附件均未改动，源码仓库仍为私有。

## 血管负荷采集开关（2026-11-07 开发，0.0.34.001 Nightly 2026-11-08 发布）

- **入口与官方逻辑**：在健康页与设置页共用的「健康测量 → 自动测量」增加血管负荷采集，仅在手表声明支持时显示。使用官方 Labs 偏好 `72-lab.enable.vascular_load` / `app.settings`，值为 `1=开、0=关`；不写 `45-vascular.load.onboarding`，不重置基线。静态核对手机 `wwi/vwi` 与手表 `Zi1/TT0/V11/Gm2` 的设置读取及睡眠采集准入，仍遵守支持、引导和省电条件，不承诺切换后立即启停传感器。
- **写入与确认**：沿用健康偏好同步及 ACK 后冷同步回读；已有目标行保留公共字段。缺行时仅借当前配对设备已同步的 `app.settings` 行中包名与设备来源标识新建，不复制其他设置的值。手表同步接收保留来源元数据，按设置键读取。原版缺行默认开，但增量分包缺行不能当作当前值已确认，界面明确显示未确认；成功回执、目标值、身份和修订均匹配后才确认。断线或等待确认时禁止界面重复发送。
- **本地验证**：新增 7 项 JVM 测试覆盖值方向、缺行建行、身份保留、缓存恢复、回执与回读顺序、旧修订和引导标志隔离；完整 562 项 JVM 与 43 项脚本测试通过。1343 项双语资源匹配，Spotless、LintDebug（0 错误、85 警告）、Release 构建与 Android 测试源码编译通过。新增 3 项 Compose 用例覆盖能力门槛、未确认默认文案、断线/等待确认及 320dp、英文双倍字号与明暗主题；仅已编译，尚未执行。
- **验收边界**：本机和远程 ADB 15037 均无连接设备，未安装或运行本次界面，未验证手表持久化及后续睡眠结果；不能据此断言仅有 10 月数据的问题已经解决。REA 证据仅保存在被忽略的 `private/`。本地已构建并签名 `0.0.34.001` / `34001`，按用户指令发布同版本 Nightly，真实设备验收仍未完成。
- **Nightly 发布核验**：`feat` 提交 `fa8d0e0` 先推送私有 main，再用 `./scripts/release.sh --current` 复用已预设版本发布，未再次递增。发布提交 CI `42443263639` 与 Release `42443322428` 均成功，Release 标记为 prerelease，Latest 仍为 `v0.0.34`。发布附件 23,172,516 字节，SHA-256 `8213f4790cd9e9aca71f069430c30bf3f6ff4406d6ec229b9eaf965940a427be`；公开镜像 `nightly.json` 指向 `0.0.34.001` / `34001` 并固定到提交 `ff2b1a8d4a7d944214eb029d7e695f6e11b1b0ce`，由不可变标签 `apk-v0.0.34.001-8213f479…` 保留。因源码仓库私有，Release 附件需授权下载，改用公开镜像匿名下载核验：与 Release 附件逐字节一致，`aapt2` 确认 `0.0.34.001` / `34001` 且包含血管负荷资源，`apksigner` v2、v3 校验通过，证书 SHA-256 `86de4a33245393411b43ad0d4fa99233f0ca6f926cef6f60982eac9eba3f1525` 与稳定版相同。稳定清单 `version.json`（`d07fdd8e…`）与 `apk` 分支（`ad9543a5…`）未改动，源码仓库仍为私有；手表端行为仍待真机验证。

## 两个健康测量入口的能力透传一致性（2026-11-08，0.0.34.002 Nightly 已发布）

- **用户反馈与断点**：`0.0.34.001` 中设置页的健康测量缺少血管负荷采集，但健康页设置面板可见。两处均复用 `HealthMeasurementSettings` 并订阅同一健康偏好状态；`HomeScreen` 分别通过 `WatchPage.SETTINGS` 与 `WatchPage.HEALTH` 裁剪全局状态，前者漏传 `vascularLoadSupported`，导致设置页恒取默认 `false` 并隐藏开关。原能力测试仍将 SETTINGS 列为不受该能力变化影响的页面，未覆盖新增入口的需求。
- **复现与修正**：先更新实际生产 `WatchPage.projection` 的回归测试，运行 `WatchPageStateTest` 得到 13 项中 1 项失败：`SETTINGS expected:<true> but was:<false>`。只在 SETTINGS 投影补齐该支持标记后，同一命令 13 项全部通过；测试覆盖两入口支持状态的 `false → true → false` 取值、投影可变更，以及概览和表盘页不受影响。原有血管负荷结果数据仍仅投影到健康页。
- **本地验证**：完整 562 项 JVM 测试无失败或跳过，1343 项双语资源检查、Spotless、LintDebug 和 Release 构建通过。
- **验收边界**：本机及远程 ADB 15037 均无连接设备，尚未运行手机界面或验证手表采集；本次仅修复页面显示所需的状态传递，手机界面及手表采集行为仍待真机验收。
- **Nightly 发布核验**：`fix` 提交 `7300115` 先推送私有 main，再由 `./scripts/release.sh --nightly` 递增并提交 `c2d196e`、创建 `v0.0.34.002` 标签。发布运行 `42471635934` 前两次在 Spotless 下载 `kotlin-compiler-embeddable-2.0.0.jar` 时收到 Maven Central 重定向的 GitHub 504，第三次通过，耗时 11m40s；提交 `7300115` 与 `c2d196e` 的 CI 均成功。Release 标记为 prerelease，Latest 仍为 `v0.0.34`。发布附件 23,172,516 字节，SHA-256 `39f1a38561e2d988d59e7542e9ae9dbbcd7acb6217dc79eeed15b5b498a79163`，与附件内 `.sha256` 一致；公开镜像 `nightly.json` 指向 `0.0.34.002` / `34002` 并固定到提交 `45e1b85a9140e2e7fb205c3c40e182787f0a8675`，由不可变标签 `apk-v0.0.34.002-39f1a385…` 与 `apk-nightly` 分支共同保留。匿名下载的镜像 APK 与 Release 附件逐字节一致，`aapt2` 确认 `0.0.34.002` / `34002`，`apksigner` v2、v3 校验通过，证书 SHA-256 `86de4a33245393411b43ad0d4fa99233f0ca6f926cef6f60982eac9eba3f1525` 与稳定版相同。稳定清单 `version.json`（`d07fdd8e…`）与 `apk` 分支（`ad9543a5…`）未改动，源码仓库仍为私有；手表端行为仍待真机验证。

## 设备连接引导的交接与恢复（2026-11-08，待真机验收）

- **交接顺序**：身份获取先调用交接准备，将候选身份保存为待验证身份，停止在释放官方连接步骤；只有用户完成释放检查并发起连接后才进入连接验证。引导可见时权限回调不自动连接，避免绕过交接顺序；重新获取身份会在准备阶段重新读取。
- **恢复与选表**：按当前设备的已确认身份、待交接身份与实时连接状态恢复引导；复用连接页选表面板，允许显式选择已改名手表，并纠正不再配对的历史目标。权限或蓝牙读取失败时保留当前选表，不将平台问题误报成未配对。
- **异常交互**：区分权限、蓝牙关闭或不可用、缺少官方应用和未配对，分别提供授权、设置、配对与重试入口；无配对设备时安装指引不再被路由立即弹回。等待交接显示可操作提示，只有实际获取身份或连接验证时显示进度；失败允许重试或重新获取身份。
- **本地验证**：583 项 JVM 测试（含 21 项引导路由回归）无失败、错误或跳过，43 项脚本测试、1348 项双语资源检查、Spotless、LintDebug、Debug/Release 构建及 Android 测试 APK 编译通过。13 项引导 UI 用例覆盖平台错误、配对指引、换表、恢复、交接顺序、失败与完成状态，均仅已编译。
- **验收边界**：当前 ADB 无连接设备，未运行界面或实际交接，未验证手表远端行为及重启后持久化；本地验证不能代替真机结果。本轮按用户指令准备 `0.0.34.003 Nightly` / `34003`，通过既有发布脚本递增版本并发布。

## 健康导出完整性与开发联动约束（2026-11-09，未发布）

- **问题范围**：原归档依赖界面短窗口，未完整覆盖历史手动小睡、独立本机睡眠分析缓存和可标准化留存历史；运动缺少部分字段与父子关系，未知距离/能量写为负值；旧周数组按导出日期重新赋日，可能在离线跨日后把旧数据标作今天。
- **修复范围**：导出格式升级为 `galaxy-watch-manager-free.health.v2`，补充完整睡眠会话、手动补记、所有本机分析缓存版本、活动区间、楼层、血管负荷、压力日统计与安全投影后的采集设置。标准化序列按留存来源展开，不再受首页窗口限制；保留 HRV 算法、来源与修订，运动保留明细及父子关系，未知值与真实零值分开，日期按实际记录或快照所持日期输出。
- **格式与文档**：同步扩展 schema、manifest 的数据集数量/时间范围/留存和同步边界及嵌入说明；[HEALTH-EXPORT.md](HEALTH-EXPORT.md) 记录解析关系和 HealthKit、Health Connect、华为/荣耀独立授权限制。新增根目录 [AGENTS.md](../AGENTS.md) 并更新 [CONTRIBUTING.md](../CONTRIBUTING.md)，要求今后健康模块、字段、持久化、派生、留存和采集设置变动在同一变更中同步检查导出、schema、manifest、文档与回归测试。
- **本地验证**：599 项 JVM 测试无失败、错误或跳过，43 项脚本测试与 1348 项双语资源检查通过；Spotless、LintDebug（0 错误、85 警告）和 Release 构建通过。实际归档回归覆盖历史窗口、独立存储、HRV 双算法与长字段、整条别名修订替换、运动父子关系、未知值/真实零值及跨日日期；另以合成数据生成包含 21 个非空 JSON 数据集的 ZIP，用完整 Draft 2020-12 验证器逐文件校验 schema、格式、数量与 SHA-256。探针及归档保存在被忽略的 `private/`。
- **验证边界**：当前无在线 ADB 设备，尚未验证手机系统文件保存/分享、真实平台写入、手表远端执行或重启持久化；未实现外部健康平台写入器，未提交或发布本轮改动。

## 健康导出独立复核修正（2026-11-09，未发布）

- **复核发现的缺陷**：① 本机分析缓存导出把作用域偏好中的布尔初始化标记按 `String` 强转，`exportResults()` 在所有设备抛 `ClassCastException`，整个导出失败；② 活动区间或楼层缺少 `end_time` 时归档写入显式 JSON null，而 Android `JSONObject.optString` 会把该 null 渲染成文本 `"null"`，清单统计执行 `Instant.parse("null")` 失败；JVM 版 org.json 返回空串，因此本地测试未暴露；③ 合并睡眠会话时，本机推理裁剪过起止时间的会话被同一记录的无分期原会话覆盖，`sleep_sessions.json` 丢失分期与推理来源。
- **修正**：缓存导出只接受可解析为 JSON 对象的字符串值，跳过初始化标记与无法解析的旧值；清单统计先判断 `isNull` 再读取文本；睡眠合并保留起止时间落在原记录内的本机推理分期，超出原记录范围时仍以当前原始修订为准。
- **回归与验证**：新增 4 项回归。临时回退缓存导出与睡眠合并两处逻辑时，对应 2 项测试分别失败，恢复后通过。603 项 JVM 测试无失败、错误或跳过；43 项脚本测试与 1348 项双语资源检查通过；Spotless、LintDebug（0 错误、85 警告）、Release 构建通过；合成归档的 21 个非空 JSON 数据集继续通过 Draft 2020-12 schema、格式、数量与 SHA-256 校验。
- **验证边界**：Android `optString` 对显式 null 的行为按 AOSP 源码核对，本地 JVM 无法复现该差异；当前仍无在线 ADB 设备，手机系统保存/分享与手表远端行为未执行，本地结果不能代替真机验收。

## 隐式状态机逐项核对与收敛（2026-11-09，未发布）

- **核对范围**：逐条核对 [TECH-DEBT.md](TECH-DEBT.md) 的 13 项代码落点，按实际封闭类型、枚举或状态聚合更新收敛说明；保留连接代次、交接恢复、协议回读和各项超时约束。
- **身份写入**：`DeviceIdentityStore.transition(IdentityEvent)` 成为唯一公开写入口，11 个原写方法私有化；控制器、WCS 和四组 Android 回归用例统一迁移。沿用设备作用域、原有返回值、commit/apply 顺序和跨键清理；阶段断言覆盖候选、交接待定、确认与交还官方应用后的恢复。
- **健康报文**：以 `HealthMessagePipeline.process` 替换仅判定布尔值的 ACK 屏障，集中解码、待重试门控及归并/投影、落盘的执行顺序，通过回调接入仓库的既有实现；完成结果显式返回 `persisted` 与可空 `ackCursor`。数据保存失败或会话失效时不返回 ACK 游标；待重试数据使后续控制包继续先落盘，保存成功后才恢复控制包免写盘路径。仓库只消费管线结果发送回复。
- **健康导出检查**：已核对快照、手动小睡和本机分析独立存储、原始/标准化归档、schema、manifest 及嵌入说明，本次未改变字段、缓存键、投影算法、留存或导出契约，仍为 v2；实际归档回归随全量 JVM 测试通过。
- **本地验证**：617 项 JVM 测试无失败、错误或跳过，其中 14 项健康管线测试覆盖真实压缩报文解码、记录归并/投影、失败重试、重复修订、控制包及取消；43 项脚本测试、1348 项双语资源检查、Spotless、LintDebug（0 错误、86 警告）、Release 构建及 Android 测试 Kotlin 编译通过。
- **验收边界**：ADB 设备清单为空，Android 用例仅编译，尚未执行界面操作、官方应用交接、手机实际落盘恢复或手表游标固化验收；本地结果不能代替上述真机结果。本轮未提交、推送或发布。

## 健康导出 v2 与状态机收敛（2026-11-09，0.0.34.004 Nightly 已发布）

- **发布范围**：汇总「健康导出完整性与开发联动约束」「健康导出独立复核修正」「隐式状态机逐项核对与收敛」三节改动，将健康归档升级为 `galaxy-watch-manager-free.health.v2`（完整睡眠会话、手动小睡、本机分析缓存、活动区间、楼层、血管负荷、压力统计、采集设置、HRV 算法区分、运动父子关系与未知值/真实零值区分），并集中连接/身份/交接/健康同步/设置回读/刷新/健康面板/安装更新等状态迁移。`feat` 提交 `3f2eeea` 先推送私有 main，再由 `./scripts/release.sh --nightly` 递增并提交 `ea2716e`、创建 `v0.0.34.004` 标签，版本 `0.0.34.004` / `34004`。
- **Nightly 发布核验**：发布提交 CI `42563294316`、`42563348094` 与 Release `42563348427` 均成功，Release 标记为 prerelease，Latest 仍为 `v0.0.34`。发布附件 23,221,668 字节，SHA-256 `12adb2befd2cf4721723886d78b3936998bad1439e49c140d9ab0306ac6f869e`，与附件内 `.sha256` 一致；公开镜像 `nightly.json` 指向 `0.0.34.004` / `34004` 并固定到提交 `a6cc38ebd5e8ed3d07b74c86c6cb77b6eb8c1bc1`，由不可变标签 `apk-v0.0.34.004-12adb2befd…` 与 `apk-nightly` 分支共同保留。因源码仓库私有，Release 附件需授权下载，改用公开镜像匿名下载核验：与 Release 附件逐字节一致，`aapt2` 确认 `0.0.34.004` / `34004`，`apksigner` v2、v3 校验通过，证书 SHA-256 `86de4a33245393411b43ad0d4fa99233f0ca6f926cef6f60982eac9eba3f1525` 与稳定版相同。稳定清单 `version.json`（`d07fdd8e…`）与 `apk` 分支（`ad9543a5…`）未改动，Latest 稳定版仍为 `v0.0.34`，源码仓库仍为私有。
- **本地验证**：617 项 JVM 测试无失败、错误或跳过，其中 14 项健康管线测试覆盖真实压缩报文解码、记录归并/投影、失败重试、重复修订、控制包及取消；43 项脚本测试、1348 项双语资源检查、Spotless、LintDebug（0 错误、86 警告）、Release 构建及 Android 测试 Kotlin 编译通过。
- **验收边界**：当前无在线 ADB 设备，未运行界面或执行官方应用交接、手机系统保存/分享、真实平台写入、手表远端行为及重启持久化；本地与云端核验不能代替真机结果。证据保存在被忽略的 `private/release-0.0.34.004.verify/`。

## 自动查询与最近同步显示复核（2026-11-09，已随 0.0.34.005 Nightly 发布）

- **调度核对**：会话就绪后 3 秒首次读取健康数据，后续按全局间隔（默认 900 秒）调度；前台同时查询电量，后台只保留健康同步。内存、设备护理详情、佩戴状态与表盘等不在周期查询范围内，完整设备信息通过显式整轮刷新获取。
- **并发语义**：自动、手动与整轮刷新共用健康同步防重入入口；同步未结束时跳过重复请求，`SYNC_DATA` 分块续期 60 秒，`LOG_DATA` 应答入队后释放，超时与断线同样释放。相关调度与握手测试通过，尚无手机运行日志证明用户现场是否存在停发请求。
- **已复现并修正**：连接页原先只观察设备设置/表盘的 `lastSyncAt`，周期电量回包也未推进该字段；健康正常接收时，「最近同步」仍可能停在旧值。先用页面投影用例复现 `expected 9000 / actual 1000`，再将显示时间改为设备回包与健康接收时间的较晚值；STF/Indicator 电量分支仅在数值有效时更新时间，即使电量不变也计为接收，缺失/越界不计。该时间表示最近收到数据，不表示同步闭环完成或手表游标已固化。
- **健康导出检查**：本次仅修正显示投影和电量接收时间，核对 `HealthExportSnapshot`、归档与 manifest 后确认仍直接使用原始 `lastHealthSyncTime`；健康缓存、请求游标、历史留存、独立小睡/分析存储及 schema v2 均无变化，实际归档回归随全量 JVM 测试通过。
- **本地验证**：新增投影回归先红后绿，覆盖双方时间未知、单方未知和先后次序；健康读数与同步状态仍不传播到无关页面。618 项 JVM 测试、43 项脚本测试、1348 项双语资源校验、Spotless、LintDebug（0 错误、86 警告）与 Release 构建通过。
- **验收边界**：本轮 ADB 设备清单为空，未安装/运行修复后的手机界面，也未观察真实定时发包、手表响应、锁屏调度或设备重启后持久化；不能将显示修正认定为用户现场自动查询问题已全部解决。发布核验见下节。

## 自动查询默认间隔调整为 15 分钟（2026-11-09，已随 0.0.34.005 Nightly 发布）

- **变更**：`AutoQueryPolicy.DEFAULT_INTERVAL_SECONDS` 由 300 改为 900，新安装、缺少偏好或历史无效值的用户默认每 15 分钟查询一次；已显式保存 30 / 60 / 120 / 300 / 600 / 900 秒的用户偏好不变，选项集合、开关、首次 3 秒读取与手动刷新也不变。
- **依据与边界**：自动查询不改变手表传感器采样频率，缩短或延长间隔只影响手机发起的通信与后续数据处理，不能换算成具体续航小时数；本轮未做真机耗电对照。
- **同步更新**：连接页说明文案（中英文）、README、自动查询说明、协议 SSOT 的默认值描述、项目地图与技术债；历史审查报告和旧版发布说明保留当时的 300 秒记录。
- **本地验证**：无效值回退与合法值保留的 JVM 回归断言改为 900；Android 设备测试的新仓库默认值断言同步改为 900（仅编译，未运行）。

## 0.0.34.005 Nightly 发布核验（2026-11-09）

- **发布范围与流程**：包含最近同步显示修正与自动查询默认 15 分钟两项变更；通过 `./scripts/release.sh --nightly` 递增为 `0.0.34.005` / `34005`，发布提交 `0a4de6c` 与标签 `v0.0.34.005` 一致。CI `42610266355`、`42610298393` 和 Release `42610297696` 均成功，Release 标记为 prerelease，源码仓库仍为私有。
- **附件与匿名下载**：Release APK 为 23,221,668 字节，SHA-256 `c1ed4231d50a6b79940ab834bdbc03c3b505db466ac76ed786c9172ff63a7b4f`，与 GitHub 附件摘要、`.sha256` 附件及 `nightly.json` 一致。公开清单匿名读取返回 HTTP 200，公开 APK 匿名下载后与 Release 附件逐字节一致；`aapt2` 确认包名 `dev.ricky.galaxywatchmanagerfree`、版本 `0.0.34.005` / `34005`，`apksigner` v2/v3 校验通过，证书 SHA-256 `86de4a33245393411b43ad0d4fa99233f0ca6f926cef6f60982eac9eba3f1525` 与稳定版相同。
- **通道隔离与不可变地址**：`nightly.json` 指向 APK 提交 `5ceb09904c73aa519b4b5e401db3383fb86e0746`，`apk-nightly` 分支和 `apk-v0.0.34.005-c1ed4231d50a6b79940ab834bdbc03c3b505db466ac76ed786c9172ff63a7b4f` 标签共同保留该提交。稳定清单 `version.json`（`d07fdd8ef5e91311c675d2e3dc349ae269d7edee`）与 `apk` 分支（`ad9543a5d956bf80e3aec37fb82c96beee321fb0`）均与发布前基线一致，Latest 仍为 `v0.0.34`。
- **验收边界**：本次完成本地构建、云端发布、公开下载与安装包静态核验；未安装到手机、运行界面或验收真实定时通信、锁屏调度、手表远端执行及重启持久化，也未测量续航改善。完整记录保存在被忽略的 `private/release-0.0.34.005.verify/`，汇总为 `verification-summary.json`。

## 更新下载镜像（2026-11-09，已随 0.0.34.006 Nightly 发布）

- **入口与偏好**：「设置 → 关于与更新 → 下载镜像」复用选择行，可选不使用（默认直连）、`gh-proxy.com`、`ghproxy.net` 和 `ghfast.top`，选择保存在本机更新偏好；未知或已移除的镜像标识回退直连。中英文文案同步。
- **传输范围**：统一镜像策略只对 `github.com` 与 `raw.githubusercontent.com` 的 HTTP(S) 地址增加前缀，同时覆盖稳定版/Nightly 清单及 APK 下载；非 GitHub、无效及已代理地址不二次改写。切换时取消并重启正在进行的检查或下载，旧任务迟到的结果不能覆盖新状态；已校验的安装包保留。
- **安装校验**：保持既有包名、版本、字节数、SHA-256 与同签名证书集合校验，安装前仍重验；镜像仅改变传输地址。界面说明所选服务属于第三方，可用性与隐私处理由服务决定，不承诺中国各网络环境均可访问。
- **网络验证**：开发机通过镜像读取公开清单并核对内容，随后经三个镜像分别下载完整的 `0.0.34.005` APK；均返回 HTTP 200、23,221,668 字节，SHA-256 均为 `c1ed4231d50a6b79940ab834bdbc03c3b505db466ac76ed786c9172ff63a7b4f`，与发布清单一致。`ghproxy.net` 首次 TLS 连接超时，curl 重试后成功，作为备选；不把这次 curl 重试视为应用具备自动重试或故障转移。证据在被忽略的 `private/download-mirror-JvduDd/`。这些是开发机网络结果，不代表 Android 更新流程或中国网络验收。
- **本地验证**：623 项 JVM 测试无失败、错误或跳过（含 5 项镜像地址策略用例），43 项脚本测试、1352 项双语资源检查、Spotless、LintDebug（0 错误、86 警告）、Release 构建和 Android 测试 Kotlin 编译通过。Android 用例覆盖偏好重读、检查/下载中切换与旧失败隔离，并扩展中英文窄屏大字号明暗主题选择测试；这些设备用例尚未执行。
- **验收边界**：ADB 当前无在线手机，尚未安装运行此界面、执行手机上的镜像完整更新或验收重启后的偏好持久化；Android 用例不以编译代替执行。功能已提交为 `81d819c`，按用户指令发布 `0.0.34.006` Nightly，远端与安装包核验见下节。

## 0.0.34.006 Nightly 发布核验（2026-11-09）

- **发布范围与流程**：本次 Nightly 包含更新下载镜像选择；通过 `./scripts/release.sh --nightly` 递增为 `0.0.34.006` / `34006`，发布提交 `2a3055c` 与附注标签 `v0.0.34.006` 一致，源码仓库仍为私有。CI `42628316604`（`756d6d2`）、CI `42628433796` 与 Release `42628433439`（均为 `2a3055c`）全部成功，Release 标记为 prerelease。
- **附件与匿名下载**：Release APK 为 23,225,764 字节，SHA-256 `2a6aa60a9bd942973cf3f6dd29fa73848e84a9eca77fe16d23fd92f5c720a07c`，与 GitHub 附件摘要及 `.sha256` 附件一致。公开 `nightly.json` 匿名读取返回 HTTP 200，公开 APK 匿名下载后与 Release 附件逐字节一致；`aapt2` 确认包名 `dev.ricky.galaxywatchmanagerfree`、版本 `0.0.34.006` / `34006`，`apksigner` v2/v3 校验通过，证书 SHA-256 `86de4a33245393411b43ad0d4fa99233f0ca6f926cef6f60982eac9eba3f1525` 与稳定版相同。
- **通道隔离与不可变地址**：`nightly.json` 指向 APK 提交 `2be59e9d9fccf16a5550f4069bd807c8c78a636b`，`apk-nightly` 分支和 `apk-v0.0.34.006-2a6aa60a9bd942973cf3f6dd29fa73848e84a9eca77fe16d23fd92f5c720a07c` 标签共同保留该提交；更新源提交 `54c191c` 只修改 `nightly.json`。稳定清单 `version.json`（blob `d07fdd8ef5e91311c675d2e3dc349ae269d7edee`）与 `apk` 分支（`ad9543a5d956bf80e3aec37fb82c96beee321fb0`）均与发布前基线一致，稳定清单仍为 `0.0.34` / `34000`，Latest 仍为 `v0.0.34`。
- **验收边界**：本次完成本地构建、云端发布、公开清单与匿名下载、安装包静态核验及稳定通道隔离检查；未安装到手机、运行镜像选择界面、执行手机上的镜像完整更新或验收重启后的偏好持久化，也未验证中国网络的可用性和速度。完整记录保存在被忽略的 `private/release-0.0.34.006.verify-dCJrhm/`，汇总为 `verification-summary.json`。

## 0.0.35 正式版准备（2026-11-10）

- **发布依据**：用户反馈「测试了」，明确要求提交所有修改并发布正式版；该反馈未逐项说明设备型号、完整流程或重启持久化结果，历史本地/云端证据与真机专项验收仍分别保留。
- **汇总范围**：相对 `0.0.34` 汇总六个 Nightly 的血管负荷采集开关及入口一致性、连接引导与恢复、健康导出 v2、连接/同步等状态迁移、最近同步时间显示、默认 15 分钟自动查询和下载镜像。更新正式版发布说明，并将协议 SSOT 中遗留的健康导出 v1 描述同步为现行 v2；未修改健康数据、导出结构、留存或协议执行逻辑。
- **发布流程**：提交全部非忽略改动后通过 `./scripts/release.sh` 递增为 `0.0.35` / `35000`，沿用正式签名；发布前记录 Nightly 清单与 APK 分支基线，发布后分别核验 Release、公开稳定清单、匿名 APK、版本、签名及 Nightly 通道隔离，结果见下节。

## 0.0.35 正式版发布核验（2026-11-10）

- **发布范围与流程**：汇总 `0.0.34.001`–`0.0.34.006` 六个 Nightly；发布提交 `f2b585f` 与附注标签 `v0.0.35` 一致，源码仓库仍为私有。CI `42652431549` 与 Release `42652432457` 均成功，Release 为正式版并成为 Latest。
- **附件与匿名下载**：Release APK 为 23,225,764 字节，SHA-256 `7aef3574f6a48d632b4acc52279026d6531ac2b033505c316561955ac0c85e04`，与 GitHub 附件摘要、`.sha256` 附件及公开 `version.json` 一致。公开清单匿名读取返回 HTTP 200，公开 APK 匿名下载后与 Release 附件逐字节一致；`aapt2` 确认包名 `dev.ricky.galaxywatchmanagerfree`、版本 `0.0.35` / `35000`，`apksigner` v2/v3 校验通过，证书 SHA-256 `86de4a33245393411b43ad0d4fa99233f0ca6f926cef6f60982eac9eba3f1525` 与此前版本相同。
- **通道隔离与不可变地址**：`version.json` 指向 APK 提交 `77a59a649bad9568746429bb99cfe11e5fe8e666`，`apk` 分支和 `apk-v0.0.35-7aef3574f6a48d632b4acc52279026d6531ac2b033505c316561955ac0c85e04` 标签共同保留该提交；更新源提交 `12ac022` 只修改 `version.json`。`nightly.json`（blob `d609e882375890a8fe1373eeb8f82b657c0fa392`）与 `apk-nightly` 分支（`2be59e9d9fccf16a5550f4069bd807c8c78a636b`）保持发布前状态，Nightly 仍为 `0.0.34.006` / `34006`。
- **验收边界**：完成本地构建门禁、云端发布、公开清单与匿名下载及安装包静态核验；用户测试反馈未逐项说明机型、完整流程和重启持久化范围，未在本次发布中重新安装到手机，也未实现或验收外部健康平台导入、中国网络下镜像可用性。完整记录保存在被忽略的 `private/release-0.0.35.verify-4uXED1/`，汇总为 `verification-summary.json`。

## 0.0.35 正式版发布复核（2026-11-10，2026-11-11 补记）

- **远端状态**：复核时 `v0.0.35` 仍为 Latest 正式版，非 draft、非 prerelease，线上发布说明与仓库 `RELEASE-NOTES.md` 一致。发布提交 `f2b585f` 的 CI `42652431549` 与 Release `42652432457` 均成功，测试、Lint、构建、签名、Release 和更新源发布步骤通过；文档提交 `638ed89` 的 CI `42654976925` 也成功，代码测试矩阵及脚本任务按仅文档变更规则跳过，不计作重新执行测试。
- **重新下载与本地安装包核验**：稳定版及 Nightly 公开清单匿名读取均返回 HTTP 200；重新匿名下载的正式 APK 与重新获取的 Release 附件逐字节一致，均为 23,225,764 字节，SHA-256 `7aef3574f6a48d632b4acc52279026d6531ac2b033505c316561955ac0c85e04` 与清单、GitHub 附件摘要及 `.sha256` 附件一致。`aapt2` 再次确认包名 `dev.ricky.galaxywatchmanagerfree`、版本 `0.0.35` / `35000`；`apksigner` v2/v3 密码学签名验证通过，单一签名证书摘要与上节记录相同。
- **通道隔离与保留标签**：稳定版 APK 固定提交、`apk` 分支及版本摘要保留标签仍指向 `77a59a649bad9568746429bb99cfe11e5fe8e666`，更新源提交仍为只修改 `version.json` 的 `12ac022`。Nightly 清单 blob 与 `apk-nightly` 分支均与发布前基线一致，版本仍为 `0.0.34.006` / `34006`，低于正式版 `35000`。
- **三家镜像实测**：开发机分别通过 `gh-proxy.com`、`ghproxy.net`、`ghfast.top` 获取本次正式版清单和完整 APK，六项请求均返回 HTTP 200；清单的通道、版本、文件名、大小、摘要及 APK 地址与直连清单一致，三份 APK 的大小与 SHA-256 均匹配正式版。每个镜像仅进行一次清单与完整 APK 请求，结果只表示本次开发机网络下可用，不作为速度排名、长期可用性或中国网络验收依据。
- **验收边界与证据**：本轮重新读取远端执行结果、下载并核验文件，未重跑本地单元测试或构建；ADB 设备清单为空，未重新安装到手机、运行更新交互或验证设备重启后的持久化。完整记录与下载、签名、工作流证据保存在被忽略的 `private/release-0.0.35-recheck.9NgsV6/`，汇总为 `verification-summary.json`；真实设备证据未进入 Git。

## 睡眠评分与 0.0.35.001 Nightly（2026-11-12）

- **当时的算法核查范围（已由后续原生核查修正）**：当时仅检查 Java 层，看到官方总分由原生库 `libsleepscore.so`（`com.samsung.sleepscore.SleepScoreAlgorithm` JNI 桥接）计算，未核查原生权重。因子分类来自 `SleepScoreContributorUtil$Type`：总睡眠时长、睡眠周期（含首周期）、清醒（觉醒/体动）、身体恢复（深睡）、精神恢复（REM）、安稳度（清醒占比）；Java 层只验证了安稳度阈值（清醒占比 ≤10% 为好，对应安稳度 ≥90 为良）。该发布所用公式为本项目近似，不代表原库算法；后续 1.4.24 核查见下节。反编译证据与目标样本见被忽略的 `private/sleep-investigation/`。
- **实现**：新增 `SleepScore` 纯计算模块，按官方因子分类做透明评分，只用真实持有的分期数据：总睡眠时长 25 / 安稳度 20 / 身体恢复 20 / 精神恢复 20 / 睡眠周期 15，公式见 `docs/SLEEP-ANALYSIS.md`。`Session.computedScore` / `displayScore` / `displayScoreSource` 为派生字段，手表 `quality` 始终优先，本机评分只在无手表评分且存在有效分期时作为补充。
- **UI**：详情面板把原评分徽章替换为睡眠评分卡片：`SleepScoreRing` 圆形进度环按分数分档着色；无手表评分时展示五个因子条形分解与「本机计算」说明，有手表评分时展示「手表评分」徽章且不混入本机因子。中英文文案同步。
- **导出联动**：`sleep_sessions.json` 增加 `computed_score`（0–100 或 null）与 `score_source`（`watch` / `computed_v1`），schema 同步并将 `score` 收紧为 0–100；`docs/HEALTH-EXPORT.md` 与协议 SSOT 同步评分语义。
- **验证边界**：新增 `SleepScoreTest` 与导出/schema 用例；本地 `:app:spotlessCheck`、`:app:testDebugUnitTest`、`:app:lintDebug`、`:app:assembleDebug`、`:app:assembleRelease` 均通过，632 项 JVM 测试无失败或跳过，中英文本地化校验通过（1362 项资源），脚本回归 43 项通过。ADB 无在线设备，真机安装、界面、手机保存/分享与重启持久化未验收；远端执行单独记录于发布核验。
- **发布流程**：功能提交 `2545ef0` 推送后，通过 `./scripts/release.sh --nightly` 递增为 `0.0.35.001` / `35001`，发布提交为 `180103f`；标签与 main 原子推送，远端标签指向该发布提交。
- **云端发布核验**：[Release `v0.0.35.001`](https://github.com/crossly/galaxy-watch-manager-free/releases/tag/v0.0.35.001) 为非草稿预发布，线上说明与仓库 `RELEASE-NOTES.md` 一致；发布提交的 [CI `43248541794`](https://github.com/crossly/galaxy-watch-manager-free/actions/runs/43248541794) 与 [Release `43248540466`](https://github.com/crossly/galaxy-watch-manager-free/actions/runs/43248540466) 均成功。云端单元测试、格式检查、Lint、Debug 构建、Android 测试代码编译、43 项脚本测试及 1362 项双语资源检查通过，发布工作流完成 Release 构建、签名和更新源发布；Android 设备测试未执行。
- **公开下载与安装包**：重新匿名读取 Nightly、稳定版清单及下载 Nightly APK 均返回 HTTP 200；公开 APK 与重新获取的 Release 附件逐字节一致，均为 23,246,244 字节，SHA-256 `c23d319cb22ee8b18bf243cd83a17aac5bad41daebe12d7b66b8292d43ba54cb` 与清单、GitHub 附件摘要及 `.sha256` 附件一致。`aapt2` 确认包名 `dev.ricky.galaxywatchmanagerfree`、版本 `0.0.35.001` / `35001`；`apksigner` v2/v3 密码学签名验证通过，单一签名证书集合与已校验文件摘要并重新验证签名的稳定版 APK 相同。
- **通道隔离与保留标签**：公开 Nightly 清单指向 APK 提交 `fb810760be77dc9bb618d521de7beef958f478cb`，`apk-nightly` 分支与 `apk-v0.0.35.001-c23d319cb22ee8b18bf243cd83a17aac5bad41daebe12d7b66b8292d43ba54cb` 标签共同保留该提交；更新源提交 `802f5c8` 只修改 `nightly.json`。稳定版 `version.json` 的内容与 blob、`apk` 分支均与发布前基线一致，稳定版及 Latest 仍为 `0.0.35` / `35000`。
- **本轮核验边界与证据**：本轮读取远端结果、重新下载并静态核验安装包，未重跑本地单元测试或构建；ADB 无在线设备，未执行手机安装或完整更新交互，睡眠评分界面、手机保存/分享及设备重启持久化仍待真机验收，也未测试第三方代理或中国网络可用性。完整下载、工作流与签名证据保存在被忽略的 `private/release-0.0.35.001-recheck.nlDMZu/`，汇总为 `verification-summary.json`；核验记录未另行提交或推送。

## 原生睡眠评分 1.4.24 核查与对齐（2026-11-13）

- **证据与纠正**：使用 REA / Ghidra 12.1.4 追踪 ARM64 `libsleepscore.so` 的 JNI、`__calcSleepScore`、阶段汇总及五个 kernel；目标 SHA-256 为 `6ced549ad82deb57e8e933d4c05158b2fbea9c06ec3a5dba34aa3dbaf2ac2b36`，库版本 1.4.24。先前基于 Java 层作出的“权重不可见”结论已修正，旧 `computed_v1` 仅为本项目近似。
- **评分与 UI**：替换为夜间路径的权重 34/6/18/26/16、sigmoid/高斯曲线、未舍入效率、入睡耗时、连续清醒统计、逐项截断及总分 1–99；周期近似项改为入睡耗时。保留手表评分优先，不对缺测或不连续分期补造评分，中英文因子说明同步；完整公式及原库末尾清醒处理见 `docs/SLEEP-ANALYSIS.md`。
- **导出联动**：归档显式升级为 `galaxy-watch-manager-free.health.v3`，更新 manifest、schema ID/字段与嵌入 README。`computed_score_algorithm=computed_shealth_1_4_24` 与手表 `score`、展示 `score_source`、分期 `source` 分开保存；本机分数及算法可同时为空。已核对 `HealthExportSnapshot`、原始记录、独立手动小睡/本机分析缓存及全部留存历史，快照/留存/计数范围没有缩小，原始负载和缓存原文不回写；实际 ZIP 回归覆盖历史会话、latest 与本机缓存的标准化评分版本及 manifest 数量。
- **原指令对照**：Unicorn ARM64 模拟执行核心原指令，数学函数使用宿主 float32 libm，按已核查的 JNI 规则限幅；346 组合成输入的总分和五项整数贡献与最终 Kotlin 编译产物全部一致。覆盖随机分期、半分钟/整分钟窗、420/540 分钟边界、短/长睡眠与前导/末尾清醒；原库小睡路径和其他官方版本未接入本次对齐。
- **本地门禁**：`:app:spotlessCheck :app:testDebugUnitTest :app:lintDebug :app:assembleRelease` 全部通过，632 项 JVM 测试无失败、错误或跳过；双语资源校验通过（1361 项资源），脚本回归 43 项通过。第一次完整门禁因任务时限中止，延长时限后的完整执行成功，不将中止当作通过。
- **验收边界与留存**：本次为开发机静态逆向、模拟执行及本地测试/构建；无在线 ADB 设备或可用模拟器，未执行手机界面、系统保存/分享或设备重启持久化验收，也未触发远端 CI、提交、推送或发布。目标库、合成向量、探针、REA Evidence 与分析快照保存在被忽略的 `private/sleepscore-re-20261112/`，REA 会话已关闭；宿主/Android 数学库的极端浮点边界仍待设备核查。

## UI 自适应与图表无障碍（2026-11-13）

- **实施范围**：依据 [UI 设计调研](UI-DESIGN-RESEARCH.md) 的 A–E 本轮方案，统一主题形状和分组卡片表面，网格最大宽度 840dp 并按字号折算空间切换单/双列；用户保存的顺序、隐藏和宽度偏好不因重排改变。健康摘要根据实际空间切换横向/纵向布局。
- **图表与面板**：心率、压力、通用指标、血管负荷及心率周图共用读屏与键盘选点语义，缺测不补占位读数；步数目标试用宽窗口居中对话框，保留 Material 小窗口底部面板，草稿支持窗口切换和状态恢复。历史双栏、自定义预测返回进度、共享转场和 Expressive 依赖升级没有纳入本次实现。
- **导出联动检查**：健康字段、派生统计、已保存目标、采集设置、记录身份/修订及历史留存均未改变。已检查 `HealthExportSnapshot`、手动小睡与本机分析独立快照、原始/标准化归档、Schema v3、manifest 数量与覆盖和导出文档，无需数据结构变更；实际归档入口的既有回归测试随全量 JVM 测试通过。
- **本地验证**：632 项 JVM 测试无失败、错误或跳过；43 项脚本测试、1369 项中英文资源检查、Spotless、Lint（0 错误、90 警告）与 Release 构建通过。Android UI 测试代码编译通过，新增用例涵盖网格重排不改偏好、读屏选点边界/空态/周图缺测跳过、键盘选择与草稿恢复。debug Preview 仅使用合成数据、固定日期和 UTC。
- **设备验收边界**：无可用 Android 设备，未执行 instrumentation 测试、实际渲染 Preview 或建立像素基线；界面、长英文/大字号、TalkBack、键盘、预测返回、拖动及窗口切换仍待真机验证。没有进行手机保存/分享、手表端执行或重启持久化验收；远端 CI/Release 结果在发布完成后单独核验。

## 通知应用筛选与权限检查（2026-11-14）

- **通知筛选**：「设置 → 应用 → 通知与下发 → 转发哪些应用」增加全部应用/仅所选应用，按名称或包名搜索、图标与整行勾选；所选模式空列表不转发任何通知，切回全部应用保留选择。模式与包名单独持久化，首次从旧非空 `allowed_packages` 迁移，已保存的空选择不会被旧值覆盖。通知状态卡显示未选应用状态，子页返回通知设置。
- **应用发现与协议边界**：通过 MAIN/LAUNCHER 的 `<queries>` 声明支持 Android 11+ 可见性，后台枚举桌面入口并合并已选及观察到通知的包名；观察集合最多 512 项，无法读取名称时显示包名。筛选在手机端调用 Bridger 之前生效，继续跳过常驻/摘要等通知，不撤回手表已有通知；没有把本地偏好当作手表确认。核对并修正 SSOT 6.4 的当前负载说明：实际为 `title_raw`/`text_raw`/`when` 等，包名及通知身份来自 URI，本轮未改变发送负载。
- **权限页面**：「设置 → 应用 → 权限检查」按系统版本展示附近设备、通知使用权、本应用通知、电池优化豁免、安装应用更新及 Android 8–9 相册写入，点击请求运行时权限或打开相应系统设置，从系统返回时刷新。永久拒绝引导应用详情，附近设备授权后沿用既有自动连接入口；复用厂商后台设置入口，并明确无法可靠检测厂商自启动授权。
- **本地验证**：Spotless、687 项 JVM 测试（无失败、错误或跳过）、Lint（0 错误、139 警告）、Release 构建及 Android UI 测试编译通过；1401 项双语资源检查与 78 项脚本回归通过。新增 JVM 用例覆盖筛选精确匹配、空选择、模式切换、旧值迁移、防共享可变集合及各 Android 版本权限清单；新增四项 Compose 用例覆盖中英/明暗主题、320dp/双倍字号、搜索和状态恢复、空选择持久化与设置 Intent。本轮首轮 Lint 在图标的 `produceState` 用法处失败，改为 `remember` 状态与 `LaunchedEffect` 后完整门禁通过，没有关闭检查规则。
- **验收边界**：本轮无可用 Android 设备，Compose 用例只完成编译，未执行手机界面或真实系统授权/拒绝/返回交互；应用列表、长英文/大字号、嵌套返回、筛选后的手表实际接收及手机重启持久化仍待真机验收。未进行手机保存/分享、远端执行、提交、推送、打标签或发布；本轮不涉及健康字段、统计、留存或导出结构变更。

## 0.0.36.002 Nightly 发布核验（2026-11-14）

- **发布流程**：功能提交 `837f8c4` 先推送私有 main，再由 `./scripts/release.sh --nightly` 递增为 `0.0.36.002` / `36002`，发布提交 `50e00cb` 与附注标签 `v0.0.36.002` 一致。功能提交 CI `43602926465`、发布提交 CI `43602954949` 与 Release `43602954819` 均成功；Release 为非草稿预发布（`prerelease=true`），正文只含当前版本章节，Latest 仍为 `v0.0.36`。
- **附件与匿名下载**：发布 APK 为 19,613,148 字节，SHA-256 `eeab8388c7780ac5b7c816d1372fe391b71bd08d6fdbc55ef1a86345996b01c2`；源码归档 5,637,028 字节，SHA-256 `52625d0c3a4d7295912cd6db80cd05c561b90ed60f4ffe293087401238777494`，均与附件内 `.sha256` 及公开 `nightly.json` 一致。因源码仓库私有，Release 附件经授权下载，再与公开 feed 匿名下载逐字节比对：APK 与源码均一致。`aapt2` 确认包名 `dev.ricky.galaxywatchmanagerfree`、版本 `0.0.36.002` / `36002`；`apksigner` v2/v3 校验通过，证书 SHA-256 `86de4a33245393411b43ad0d4fa99233f0ca6f926cef6f60982eac9eba3f1525` 与稳定版相同。源码归档用 `git archive` 从 `v0.0.36.002` 复现后与发布文件逐字节一致。
- **通道隔离与不可变地址**：`nightly.json` 指向 `0.0.36.002` / `36002` 并固定到提交 `061bde8220c0eb91f76a13ad2056345b7a8d35ca`，`apk-nightly` 分支与保留标签共同指向该提交；更新源提交 `05a3746de4f33064d2445ca4af07a58b4a6c80cb` 只修改 `nightly.json`。稳定清单 `version.json`（blob `9f9b7893ca9934307438786afdef1c668f1e702d`）与 `apk` 分支（`fe7ae670b93f27728d56254167ffa10a62231483`）均与发布前基线一致，稳定版及 Latest 仍为 `0.0.36` / `36000`。
- **验收边界与证据**：本次完成云端发布、公开清单与匿名下载、安装包与源码归档静态核验及稳定通道隔离检查；未安装到手机、运行界面或验收真实授权/拒绝交互与重启持久化，真机验收由用户执行。完整记录保存在被忽略的 `private/release-0.0.36.002.verify/`。Release 工作流的上传步骤因 GitHub Actions 存储配额命中告警，但签名、发布与更新源步骤全部成功且产物已逐字节核验，不影响本次发布结果。

## 0.0.36.003 Nightly 发布核验（2026-11-14）

- **修复内容**：健康页血管负荷面板改用普通健康同步请求，手动刷新仍走专用同步；导出 `band` 仅用于测量行，基线与重置为 null，并同步 schema 与文档；manifest 的 `local_date` 回退到 `tracking_local_date`；血管负荷历史回填失败后每 30 分钟重试、最多 3 次；移除未使用的 `trackingMillis`。本地 Spotless、687 项 JVM 测试（无失败、错误或跳过）、Lint、Release 构建与 78 项脚本回归通过。
- **发布流程**：修复提交 `bb11264`、发布说明 `527b890`、发布提交 `64a4fde` 与附注标签 `v0.0.36.003` 一致。修复提交 CI `43606293175`、说明提交 CI `43606364395`、发布提交 CI `43606377429` 与 Release `43606377269` 均成功；Release 为非草稿预发布（`prerelease=true`），正文只含当前版本章节，Latest 仍为 `v0.0.36`。
- **附件与匿名下载**：发布 APK 为 19,613,148 字节，SHA-256 `2dc57430b35284f704ec16df150f51ec06d0eaf23798a24d95a82c2d2b9dd5bc`；源码归档 5,638,411 字节，SHA-256 `b35165b33d3631cbc06464e4c6b8ae2816fe90ee34f45d64b19f6acaa11470ac`，均与附件内 `.sha256` 及公开 `nightly.json` 一致。因源码仓库私有，Release 附件经授权下载，再与公开 feed 匿名下载逐字节比对：APK 与源码均一致。`aapt2` 确认包名 `dev.ricky.galaxywatchmanagerfree`、版本 `0.0.36.003` / `36003`；`apksigner` v2/v3 校验通过，证书 SHA-256 `86de4a33245393411b43ad0d4fa99233f0ca6f926cef6f60982eac9eba3f1525` 与稳定版相同。源码归档用 `git archive` 从 `v0.0.36.003` 复现后与发布文件逐字节一致。
- **通道隔离与不可变地址**：`nightly.json` 指向 `0.0.36.003` / `36003` 并固定到提交 `0a1549c88032cde5788239858e000a14094f9ab4`，`apk-nightly` 分支与保留标签 `apk-v0.0.36.003-2dc57430b35284f704ec16df150f51ec06d0eaf23798a24d95a82c2d2b9dd5bc-b35165b33d3631cbc06464e4c6b8ae2816fe90ee34f45d64b19f6acaa11470ac` 共同指向该提交；更新源提交 `70a4f0e049f0dfe5ca3ca902e079ae406db5d2bb` 只修改 `nightly.json`。稳定清单 `version.json` 与 `apk` 分支（`fe7ae670b93f27728d56254167ffa10a62231483`）均与发布前基线一致，稳定版及 Latest 仍为 `0.0.36` / `36000`。
- **验收边界与证据**：本次完成云端发布、公开清单与匿名下载、安装包与源码归档静态核验及稳定通道隔离检查；未安装到手机、运行界面，血管负荷面板同步、回填重试与导出差异仍待真机验收。完整记录保存在被忽略的 `private/release-0.0.36.003.verify/`。

## 通知转发时间段（2026-11-14）

- **实施范围**：「设置 → 应用 → 通知与下发」新增「转发时间段」开关（默认关闭）与开始/结束时间选择，默认 8:00–22:00，24 小时制。开始含、结束不含；开始晚于结束视为跨午夜，相同视为全天。时间段外只跳过新通知，不撤回手表上已有通知，也不改变通知负载或 Bridger 协议。
- **持久化与判定**：`NotificationSchedule` 提供纯函数 `allows(LocalTime)`；`NotificationFilterPreferences` 在同一 `watchfree_notification_filter` 偏好中保存 `schedule_enabled` / `schedule_start_minute` / `schedule_end_minute`，恢复时把分钟数限制在 0–1439 并暴露 `schedule` StateFlow。`NotificationBridgeService` 在应用筛选后、读取标题内容前用设备本地时间判定，跳过原因写入现有调试日志。
- **本地验证**：Spotless、692 项 JVM 测试（无失败、错误或跳过）、Lint（0 错误、139 警告）、Release 构建及 Android UI 测试编译通过；1410 项双语资源检查与 78 项脚本回归通过。新增 5 个 JVM 用例覆盖默认关闭、半开区间边界、跨午夜、起止相同即全天与越界恢复。
- **验收边界**：本轮无可用 Android 设备，未执行手机界面、TimePicker 实际交互、系统时间跨过边界或重启后持久化验收；未进行手机保存/分享、手表实际接收或远端执行。本轮不涉及健康字段、统计、留存或导出结构变更，导出无需联动修改。

## 0.0.36.004 Nightly 发布核验（2026-11-14）

- **发布流程**：功能提交 `b07b957`、发布说明 `55cfafb`、发布提交 `428c2c9` 与附注标签 `v0.0.36.004`（指向 `428c2c9`）一致。功能与说明一次推送的 CI `43610044597`、发布提交 CI `43610058135` 与 Release `43610057914` 均成功；Release 为非草稿预发布（`prerelease=true`），正文只含当前版本章节，Latest 仍为 `v0.0.36`。
- **附件与匿名下载**：发布 APK 为 19,621,340 字节，SHA-256 `1ec7e3dd2f14f0d9ea43ca60b5f9df66b64f0e22ecac6d282e62695c105ff5b8`；源码归档 5,642,484 字节，SHA-256 `17c968b0ce41d9df0bfde9ccb09814e55863374ec6c2705c2d50f1f85569a240`，均与附件内 `.sha256` 及公开 `nightly.json` 一致。因源码仓库私有，Release 附件经授权下载，再与公开 feed 匿名下载逐字节比对：APK 与源码均一致。`aapt2` 确认包名 `dev.ricky.galaxywatchmanagerfree`、版本 `0.0.36.004` / `36004`、targetSdk 35、compileSdk 36；`apksigner` v2/v3 校验通过，证书 SHA-256 `86de4a33245393411b43ad0d4fa99233f0ca6f926cef6f60982eac9eba3f1525` 与稳定版相同。源码归档由 `python3 scripts/package-source.py --ref v0.0.36.004` 复现后与发布文件逐字节一致。
- **通道隔离与不可变地址**：`nightly.json` 指向 `0.0.36.004` / `36004` 并固定到提交 `f803e039375c8baf7bbb956cc8b3323ac5c2eece`，`apk-nightly` 分支与保留标签 `apk-v0.0.36.004-1ec7e3dd2f14f0d9ea43ca60b5f9df66b64f0e22ecac6d282e62695c105ff5b8-17c968b0ce41d9df0bfde9ccb09814e55863374ec6c2705c2d50f1f85569a240` 共同指向该提交；更新源提交 `62fff97a64ce81a21c90d23f0f47efb9e6ffe6c3` 只修改 `nightly.json`。稳定清单 `version.json` 与 `apk` 分支（`fe7ae670b93f27728d56254167ffa10a62231483`）均与发布前基线一致，稳定版及 Latest 仍为 `0.0.36` / `36000`。
- **验收边界与证据**：本次完成云端发布、公开清单与匿名下载、安装包与源码归档静态核验及稳定通道隔离检查；未安装到手机、运行界面，时间段选择器交互、跨零点/系统改时、重启后持久化与手表真实接收仍待真机验收。完整记录保存在被忽略的 `private/release-0.0.36.004.verify/`。

## 0.0.37 正式版发布核验（2026-11-15）

- **发布范围与流程**：汇总 `0.0.36.001`–`0.0.36.004` 四个 Nightly（安装包压缩、通知按应用筛选与权限检查、血管负荷与导出修正、通知转发时间段）。发布说明 `f357185`、发布提交 `3448d4c` 与附注标签 `v0.0.37`（tag 对象 `84884d8`，指向 `3448d4c`）一致。发布说明提交 CI `43613635963`、发布提交 CI `43613701586` 与 Release `43613701263` 均成功；Release 为正式版（draft=false、prerelease=false），正文只含 `0.0.37` 章节且与 `docs/RELEASE-NOTES.md` 提取结果逐字节一致，成为 Latest。
- **附件与匿名下载**：Release APK 为 19,621,340 字节，SHA-256 `c5f5337e583edeb7fc79fb846851af0437b40bc456989fef567e26f57f8f6e4d`；源码归档 5,643,246 字节，SHA-256 `2ccd07f9e666bf8323821abd6d68aa8d40326d6b58cd31c75cc637b82838fc7d`，均与附件内 `.sha256` 及公开 `version.json` 一致。因源码仓库私有，Release 附件经授权下载，再与公开 feed 匿名下载逐字节比对：APK 与源码均一致。`aapt2` 确认包名 `dev.ricky.galaxywatchmanagerfree`、版本 `0.0.37` / `37000`、targetSdk 35、compileSdk 36；`apksigner` v2/v3 校验通过，证书 SHA-256 `86de4a33245393411b43ad0d4fa99233f0ca6f926cef6f60982eac9eba3f1525` 与 `0.0.36` 稳定版 APK 相同。源码归档由 `python3 scripts/package-source.py --ref v0.0.37` 复现后与发布文件逐字节一致。
- **通道隔离与不可变地址**：`version.json` 指向 `0.0.37` / `37000`，APK 提交 `eceb7677a0bed3ab2af2efee93cd9cd66e401723`，`apk` 分支与保留标签 `apk-v0.0.37-c5f5337e583edeb7fc79fb846851af0437b40bc456989fef567e26f57f8f6e4d-2ccd07f9e666bf8323821abd6d68aa8d40326d6b58cd31c75cc637b82838fc7d` 共同指向该提交；`apk` 分支提交只新增 APK 与源码归档，更新源提交 `ab02550b125fccb943f3e0afa4600858e9e92865` 只修改 `version.json`。`nightly.json` 与 `apk-nightly` 分支（`f803e039375c8baf7bbb956cc8b3323ac5c2eece`）保持发布前状态，Nightly 仍为 `0.0.36.004` / `36004`，低于正式版 `37000`。
- **验收边界**：完成本地构建门禁、云端发布、公开清单与匿名下载、安装包与源码归档静态核验及通道隔离检查；未安装到手机、未运行界面，通知应用筛选、系统权限授权/拒绝返回、转发时间段 TimePicker 交互、跨零点/系统改时、重启持久化与手表真实接收待真机验收。完整记录保存在被忽略的 `private/release-0.0.37.verify/`。

## 通知应用图标同步（2026-11-15）

- **协议与负载**：核对官方 `eip.f`、DataMap Asset 分支及 `hjx` / `him` / `hil` 描述，为来源 App 图标增加 `app_icon`（type 13，值字段 13 的资产索引）与 DataItem f8 引用表，修复解码器误读字段 14。图片先以 SetAsset 内联发送，按 1024 字节分为带完整摘要和顺序号的 Envelope，随后下发通知 DataItem；来源应用图标缩放为 96×96 PNG，单图上限 64 KiB。
- **转发与失败处理**：通知监听按容量 64 的后台串行队列处理，PackageManager 图标读取与 PNG 编码移出主线程；队列满时记录原因并跳过，服务销毁取消待处理任务，连接代次变化后旧任务失效。测试按钮和诊断通知沿用统一入口。缺图、空图、超限或图片入队失败时尝试文字通知，不携带悬空 Asset 引用；每次重新发送图片，不把入队当作手表已缓存或已展示。
- **本地验证**：Spotless、701 项 JVM 测试（无失败、错误或跳过）、Lint 和 Release 构建通过；1410 项双语资源检查与 78 项脚本回归通过。新增 9 项合成回归覆盖不同应用/更新图标、真实 wire 字段和摘要、分片组装/模拟保存/确认、缺图/超限/入队失败回退、重连重发与非零资产索引解析。
- **导出与验收边界**：本轮不改变健康字段、统计、采集设置、留存、`HealthExportSnapshot`、独立手动小睡/本机睡眠缓存、原始/标准化归档、Schema v3 或 manifest 覆盖，无需导出结构变更。无可用 Android 设备，未执行手机测试按钮交互、手表实际图标显示、断线重连或设备重启后持久化验收；测试中的保存/确认是内存接收端合成结果，不代表设备落盘。远端发布与更新源结果在发布后单独记录。

## 全仓审查修复与通知资产回执（2026-11-16）

- **健康正确性**：睡眠/分期、楼层与运动模块别名先选最新整条修订；重叠手动小睡不再重复累计，原始补记仍完整导出。血压/ECG 记录保存修订时间并优先保留新修订；睡眠本机分析在每轮完成后重新规划，避免分析期间新数据无人处理。
- **协议与状态**：识别通知图标 AckAsset（inner field 5）；修正 DataMap Float/Double 位编码、Ready 后超时守卫、PSM 发送失败回滚与交接存储 commit 结果传播。该轮还将手机兼容身份误改为真实身份，导致非三星手机的 SHM 厂商门槛回归，修复见下节「健康检测器三星兼容身份恢复」。根据已核查的官方常量和既有设备证据修正电量 SSOT 路径为 `/c_devicecare/battery/base_info`，状态沿用 Android BatteryManager 语义。
- **隐私与交付**：扩充诊断设备标识脱敏，更新页转到公开 feed，签名产物强制核对正式证书；CI 不跳过随包 Markdown 资产。同步修复页面状态恢复、校准关闭按钮读屏描述及步数距离单位本地化。
- **导出联动**：检查快照、独立手动小睡/本机分析缓存、raw/normalized、schema、manifest 与嵌入说明；血压/ECG `update_time` 随既有原始记录和 retained_cache 完整保留，标准化字段及 schema v3 无变化。实际 ZIP 回归覆盖旧修订拒绝、修订落盘后的缓存导出、重叠补记原文保留及数据集数量；不缩小历史范围或补造未知值。
- **验收边界**：本地格式、完整 JVM 回归、Lint、Debug/Release 构建、Android 测试源码编译、1411 项双语资源与 78 项脚本测试已验证。未进行手机保存/分享、UI 或覆盖安装，手表图标实际显示、断线重连和设备重启持久化仍待真机验收；AckAsset 不代表通知已展示。

## 健康检测器三星兼容身份恢复（2026-11-16）

- **根因与修复**：`642829c` 将既有三星兼容手机身份改为真实 `Build.*`，用户在 `0.0.37.004` 报告手表 SHM 弹出「需要三星手机」。静态复核 Wear SHM `ra2.invokeSuspend` 的 companion vendor 判断和 `ml` 的 `ErrorActivity(type=3)` 路径后，恢复此前有效的 `Galaxy S25 Ultra` / `SM-S938U1` / `samsung` / `isTablet="false"` / `csc="XAA"`。兼容字段由 `PhoneFeature` 统一构造，实际蓝牙名、屏幕像素、语言、时区、时间和默认短信包仍由会话采集；协议 SSOT 和调查记录明确兼容身份不可作为无用硬编码移除。
- **防回归与本地检查**：从原实现抽出同一发送 JSON 构造路径，以合成非三星环境先复现 3 项失败；恢复兼容字段后 3 项通过。覆盖 WCS 帧编解码后的 `vender` 拼写与值、整组兼容身份、运行字段的值与 wire 类型及后续交换不复用被修改的 JSON。Spotless、718 项 JVM 测试（0 失败/错误/跳过）、Lint（0 错误、138 警告）、Release 构建与 APK 随包资产检查通过；1411 项双语资源和 83 项脚本回归通过。
- **导出与验收边界**：核对 `HealthExportSnapshot`、手动小睡/本机睡眠独立快照、raw/normalized、Schema v3、manifest 与留存覆盖；本轮只修复 WCS 手机兼容特性，不改变健康模型、采集设置、存储、算法或导出结构，现有导出回归随完整 JVM 测试通过。未执行手机安装、保存/分享、手表入口与 ECG/BP 测量同步、重连/重启持久化或远端发布；修复仍为本地未提交变更。静态 Evidence 和失败测试保存在被忽略的 `private/shm-phone-identity-regression-20261116-*`。
- **兼容清理回查**：核对现存历史 `1a8230e..HEAD`、两轮集中审查修复及当前调用方。除本次手机身份回归外，`fc01db2` 曾移除的表盘预览与睡眠运行时已分别由 `3a8e2b5`、`a375796` 恢复。官方协议常量、插件包名/版本与手机侧 ROM 判断仍有实际用途；健康采集开关常量改为按设置声明后，原睡眠血氧与压力的开关取值保持不变。AGENTS 新增保护规则：既有厂商兼容身份不得作为无用硬编码清理，其他常量先核对读取方与判定条件，不确定影响时明确列出。
- **未证实影响：状态交换**：`buildPhoneStatus()` 的 `mcc/mnc` 空串、`simCountry` 仅取 Locale、`oneUiVersion=0`、`roamingStatus=false`、`fbeMode=true` 在最早保留快照中已存在，近期未修改，不能归因于本轮清理。官方实现按 SIM/网络/Locale 顺序确定国家，并读取运营商、漫游和加密状态；Android 版本在含小数点时仅发送主版本。Watch SHM 定义了 companion 运营商/国家等查询项，Samsung Health 能力配置包含地区与 One UI 版本，但这些差异是否触发用户当前设备上的功能分支尚未证实，未据此更改或补造兼容值。
- **未证实影响：旧身份迁移**：最早保留快照已将固定真机 NodeInfo 帧清空，并将默认节点替换为合成占位值，无法从当前历史复原清理前的完整行为。已保存真实手机节点时走动态生成 NodeInfo；仅剩旧配对归属而没有已保存手机节点时，`confirmedPhoneNode` 仍可能返回占位节点，不能保证手表接受。新安装缺少已登记身份时仍明确阻止连接。未做旧安装升级、身份丢失恢复或重启持久化实测，不能声明这些迁移场景无影响；不把真实设备标识或抓包帧恢复到源码。

## Nightly 签名校验修复（2026-11-16）

- **失败原因**：`v0.0.37.002` Release 工作流 `43783024266` 的测试、Lint 与构建成功，APK 的 v2/v3 签名验证成功，但脚本将 `public key SHA-256 digest` 也提取为证书摘要，误拒绝正式签名，未创建 Release 或更新 feed。
- **修复与回归**：仅提取 `Signer #N certificate SHA-256 digest`，继续逐个检查所有签名证书，并保留缺少证书摘要及 apksigner 失败时拒绝的行为。通过实际脚本入口的合成回归先复现正确证书被公钥误拒绝、缺证书摘要却放行两类错误，修复后 5 项签名用例通过。
- **发布与边界**：保留失败的 `v0.0.37.002` 标签，由 `./scripts/release.sh --nightly` 递增到 `0.0.37.003`，不覆盖旧标签。本次仅修复发布校验，不改变应用代码、健康数据或导出 v3；公开产物、签名与稳定通道隔离在发布后单独核验。

## 通知图标 V1 附件修正（2026-11-16）

- **根因与修复**：`0.0.37.001`–`0.0.37.003` 的 SetAsset 将 f2/f3 颠倒，且握手声明 V1 却未发送 V1 文件附件。按官方 `hjw` / `hid` / `hif` 修正访问元数据位置，按 `hav` / `hbt` 发送带 f13 标记的头消息和 `hje` FilePiece；文件块通过头消息摘要关联，仅末块携带完整文件摘要。上限仍为 64 KiB，头队列按 ≤32 KiB / >32 KiB 选择 5/6；每块上限 12215 字节。接收端内联内容同步改读官方 f3。
- **防回归**：发送测试先在旧实现复现 2 项失败，接收字段测试先复现 1 项失败，修正后通过；覆盖块长边界、队列分界、64 KiB、每个发送阶段失败后文字回退、重连重发和引用摘要。独立 Java 探针调用已编译的真实发送类，Python 按官方 V1 接收路径及原始 SQLite `assetsReadyStatus` 视图验证 9 组纯合成情景，所有图标引用均可就绪，文字字段与 `v0.0.36` 对照一致；没有执行官方 Android 运行时。
- **本地检查**：Spotless、715 项 JVM 测试（0 失败/错误/跳过）、Lint、Release 构建及 APK 随包资源校验通过；1411 项双语资源和 83 项脚本回归通过。协议 SSOT 已修正旧的内联字段和发送流程描述。
- **导出与验收边界**：本轮不改变健康模型、统计、采集设置、留存、快照及独立存储、raw/normalized、Schema v3 或 manifest，无需导出结构变更。手机测试按钮、手表真实通知/图标展示、重连和重启持久化仍待真机验收；本地合成资产就绪不代表设备保存。证据在被忽略的 `private/notification-regression-20261116/`；`0.0.37.004` 的远端发布与公开下载结果另行核验。

## 0.0.37.003 Nightly 发布核验（2026-11-16）

- **发布流程**：修复提交 `b128427` 的 CI `43784640206`、发布提交 `83e00ad` 的 CI `43784733557` 与 Release `43784734046` 均成功；Release 为非草稿预发布（`prerelease=true`），正文只含当前版本章节，Latest 仍为 `v0.0.37`。
- **附件与匿名下载**：发布 APK 为 19,629,532 字节，SHA-256 `835f8d25ace251de576ece388b7110381ee63626d3eb6a7007c5d87ccd8c9177`；源码归档 5,655,858 字节，SHA-256 `ac993196e9c77fcb382902251e70c8ed2fc201334725083dbbc119b4e7d574fd`，均与附件内 `.sha256` 及公开 `nightly.json` 一致。公开 APK 与源码匿名下载后与 Release 附件逐字节一致；`aapt2` 确认包名 `dev.ricky.galaxywatchmanagerfree`、版本 `0.0.37.003` / `37003`、targetSdk 35，`apksigner` v2/v3 校验通过，签名证书 SHA-256 `86de4a33245393411b43ad0d4fa99233f0ca6f926cef6f60982eac9eba3f1525`。源码归档由 `python3 scripts/package-source.py --ref v0.0.37.003 --apk …` 复现后与发布文件逐字节一致。
- **通道隔离与不可变地址**：`nightly.json` 指向 `0.0.37.003` / `37003`，更新源提交 `0f82ecf` 只修改 `nightly.json`；APK 固定到提交 `1f1fed4700ca2759dfe0513cf97d02ddc535021b`，由保留标签 `apk-v0.0.37.003-835f8d25…-ac993196…` 与 `apk-nightly` 分支共同指向。稳定清单 `version.json`（blob `b5e2cb7d885ac5a19c9250c1a587d3b22be1b8f1`）、`apk` 分支（`eceb7677a0bed3ab2af2efee93cd9cd66e401723`）及 Latest `v0.0.37` 均与发布前基线一致。
- **验收边界与证据**：本次完成云端发布、公开清单与匿名下载、安装包与源码归档静态核验及稳定通道隔离检查；当前无可用 Android 设备，未安装到手机或运行界面，通知图标手表显示、测试按钮、断线重连与重启持久化仍待真机验收。完整证据保存在被忽略的 `private/release-0.0.37.003.verify/`；失败版本证据在 `private/release-0.0.37.002.verify/`。

## 0.0.37.001 Nightly 发布核验（2026-11-15）

- **发布流程**：功能提交 `78510c0`、发布提交 `1765d32` 与附注标签 `v0.0.37.001`（tag 对象 `a79df83`，指向 `1765d32`）一致。功能提交 CI `43726292411`、发布提交 CI `43726307920` 与 Release `43726307903` 均成功；Release 为非草稿预发布（`prerelease=true`），正文只含当前版本章节，Latest 仍为 `v0.0.37`。
- **附件与匿名下载**：发布 APK 为 19,629,532 字节，SHA-256 `1c3755bb3cf7fa8be2cc8f4901bf9bc4cad01dbe5711b78fc78ae23630d74791`；源码归档 5,649,608 字节，SHA-256 `49ef04ca35ec3bf372f7b712692e91ad60910a8d70d085c981e5dc1240b962e1`，均与附件内 `.sha256` 及公开 `nightly.json` 一致。因源码仓库私有，Release 附件经授权下载，再与公开 feed 匿名下载逐字节比对：APK 与源码均一致。`aapt2` 确认包名 `dev.ricky.galaxywatchmanagerfree`、版本 `0.0.37.001` / `37001`；`apksigner` v2/v3 校验通过，证书 SHA-256 `86de4a33245393411b43ad0d4fa99233f0ca6f926cef6f60982eac9eba3f1525` 与稳定版相同。源码归档由 `python3 scripts/package-source.py --ref v0.0.37.001 --apk …` 复现后与发布文件逐字节一致。
- **通道隔离与不可变地址**：`nightly.json` 指向 `0.0.37.001` / `37001` 并固定到 APK 提交 `068667104a3692fc3a243c97c11b6e82327e43f6`，`apk-nightly` 分支与保留标签 `apk-v0.0.37.001-1c3755bb3cf7fa8be2cc8f4901bf9bc4cad01dbe5711b78fc78ae23630d74791-49ef04ca35ec3bf372f7b712692e91ad60910a8d70d085c981e5dc1240b962e1` 共同指向该提交；更新源提交 `d8d5a521b4bd1b51c43bbb87f3e406155279c550` 只修改 `nightly.json`。稳定清单 `version.json`（blob `b5e2cb7d885ac5a19c9250c1a587d3b22be1b8f1`）与 `apk` 分支（`eceb7677a0bed3ab2af2efee93cd9cd66e401723`）均与发布前基线一致，稳定版及 Latest 仍为 `0.0.37` / `37000`。
- **验收边界与证据**：本次完成云端发布、公开清单与匿名下载、安装包与源码归档静态核验及稳定通道隔离检查；当前无可用 Android 设备，未安装到手机、未运行界面，通知图标在手表上的实际显示、测试按钮交互、断线重连与重启持久化仍待真机验收。完整记录保存在被忽略的 `private/release-0.0.37.001.verify/`。

## 状态交换地区与系统信息核对及一致性补齐（2026-11-16）

- **官方来源核对**：反编译 Watch7 插件 `StatusExchangeMessage` 确认手机→手表 `status_exchange` 的 `locale*`、`fbeMode`、`pluginVersion`、`mcc/mnc`、`devicePlatform/devicePlatformVersion`、`oneUiVersion`、`swVersion`、`SDKVersion`、`timezone/time`、`simCountry`、`roamingStatus` 来源；`devicePlatformVersion` 仅发送 `Build.VERSION.RELEASE` 的首个点分段，`simCountry` 按 SIM→网络→Locale→`"us"` 回退。手表端 Wear OS 的地区判断读取手表自身 `TelephonyManager`，手机侧状态无法改变。
- **手表端消费边界**：`com.samsung.android.wcs.extension.provider.companion` 在已解包树中仅见于 Wear SHM 的 16 项 URI 定义，唯一读取点为 `hp0.z` 的 `vendor`（ECG/BP 三星手机门槛，`ml` 在判断失败时打开 `ErrorActivity(type=3)`）；`mcc/mnc/sim_iso_country/one_ui_version` 等无已证实消费者。手表侧 WCS extension 本体未解包，其存储/校验行为仍未知，不能据此宣称地区资格或医学功能已获验证。
- **一致性补齐**：`buildPhoneStatus()` 迁到 `PhoneStatus` 纯构造器，`mcc="310"`、`mnc="410"`、`simCountry="us"` 与 `SM-S938U1`/`XAA` 兼容身份一致；`devicePlatformVersion` 改为首个点分段。`oneUiVersion=0`、`roamingStatus=false`、`fbeMode=true` 保持既有占位。本改动不改变 ECG/BP 门槛（仍只依赖 `vendor`），属身份自洽而非功能解锁。
- **本地验证与边界**：新增 3 项合成回归（美国运营商档案、点分段、运行时 locale/time 保持真实）。Spotless 通过；JVM 测试 721 项（0 失败/错误/跳过）；Lint 0 错误、138 警告；Release 构建通过（88 任务）；i18n 1411 项资源、2 语言；脚本回归 83 项通过。未在真机验证手表接收、显示或功能解锁，不宣称地区资格或医学功能已获验证。

## 正式版 Release ChangeLog 汇总规则（2026-11-16）

- **流程规则**：Nightly 章节按当次预发布记录；正式版 `0.0.N` 必须汇总上一稳定版本线 `0.0.(N-1).MMM` 的全部 Nightly，检查新增与修复并合并为最终行为，按「新增」「修复」归类写入，末尾注明汇总范围、测试结果与验收边界。
- **工具与门禁**：`scripts/release-notes.py` 新增 `--collect-nightlies`（按时间顺序提取上一稳定线全部 Nightly 原文）与 `--check-nightlies`（校验上一稳定线每个 Nightly 标签都有对应章节）；`scripts/release.sh` 在正式版发布前执行覆盖检查。GitHub Release 仍只发布当前版本章节。
- **验证**：脚本回归 91 项通过（新增 8 项覆盖采集顺序、缺失章节、CLI 与发布门禁）；以 `v0.0.38` 实测 `0.0.37.x` 覆盖完整。不影响应用代码、健康数据或导出结构。

## 0.0.37.005 Nightly 发布核验（2026-11-16）

- **发布流程**：功能提交 `201576b`、发布说明 `94d26b5` 与发布提交 `e615a7c`（附注标签 `v0.0.37.005` 指向 `e615a7c`）一致；功能与说明同一次推送的 CI `43814604981`、发布提交 CI `43814629192` 与 Release `43814629907` 均成功。Release 为非草稿预发布（`prerelease=true`），正文只含当前版本章节，Latest 仍为 `v0.0.37`。
- **附件与匿名下载**：Release APK 为 19,629,532 字节，SHA-256 `82c2db2750359d4826fcd9eb11012be752004e0bd6aa8ca5c976c5311ebd6d00`；源码归档 5,668,053 字节，SHA-256 `a4aedf79277801329f17f31f42ad267c24fe67d0a2d8dfd23f9005ac16774faf`，均与附件内 `.sha256` 及公开 `nightly.json` 一致。公开 feed 匿名下载与经授权的 Release 附件逐字节比对：APK 与源码均一致。`aapt2` 确认包名 `dev.ricky.galaxywatchmanagerfree`、版本 `0.0.37.005` / `37005`、targetSdk 35、compileSdk 36；`apksigner` v2/v3 校验通过，证书 SHA-256 `86de4a33245393411b43ad0d4fa99233f0ca6f926cef6f60982eac9eba3f1525` 与稳定版相同。源码归档由 `python3 scripts/package-source.py --ref v0.0.37.005 --apk …` 复现后与发布文件逐字节一致。
- **通道隔离与不可变地址**：`nightly.json` 指向 `0.0.37.005` / `37005` 并固定到 APK 提交 `1f0a837d739e3582e90aeb6ae464bd2b1de1d529`，`apk-nightly` 分支与保留标签 `apk-v0.0.37.005-82c2db27…-a4aedf79…` 共同指向该提交；更新源提交 `8e62fd5e9569ebbdcbbcbd3ddb15c94b1fa14e96` 只修改 `nightly.json`。稳定清单 `version.json`（blob `b5e2cb7d885ac5a19c9250c1a587d3b22be1b8f1`）与 `apk` 分支（`eceb7677a0bed3ab2af2efee93cd9cd66e401723`）均与发布前基线一致，稳定版及 Latest 仍为 `0.0.37` / `37000`。
- **验收边界与证据**：本次完成云端发布、公开清单与匿名下载、安装包与源码归档静态核验及稳定通道隔离检查；当前无可用 Android 设备，未安装到手机或运行界面，概览免打扰立即开关实际切换手表免打扰、手表 SHM 恢复可用、状态交换显示、重连与重启持久化仍待真机验收。完整证据保存在被忽略的 `private/release-0.0.37.005.verify/`。

## 0.0.37.006 Nightly 发布核验（2026-11-16）

- **发布流程**：功能提交 `f4837c8` 与发布提交 `700b63a`（附注标签 `v0.0.37.006` 指向 `700b63a`）的 CI `43827629468`、`43827648787` 及 Release `43827648333` 均成功。Release 为非草稿预发布（`prerelease=true`），正文与 `scripts/release-notes.py --tag v0.0.37.006` 提取内容一致（仅末尾换行差异），只含当前版本章节；Latest 仍为 `v0.0.37`。Actions 临时 artifact 上传因账户存储配额已满被跳过（该步允许 `continue-on-error`），Release 附件与公开 feed 由后续步骤直接发布，未受影响。
- **附件与匿名下载**：Release APK 为 35,034,032 字节（较 `0.0.37.005` 的 19,629,532 增加 MapLibre 四组 ABI 原生库），SHA-256 `93bfd13e67405e93dd0c27357937ee9a7ccb8610e28638d971830199514c48fe`；源码归档 5,696,622 字节，SHA-256 `68fc16af2cc4b6339c8a66da777f9bf6d63d250d6f04b57236c9cccfbe962fae`，均与附件内 `.sha256` 及公开 `nightly.json` 一致。公开 feed 清单与 APK、源码匿名下载均返回 HTTP 200，下载内容与经授权的 Release 附件逐字节一致。`aapt2` 确认包名 `dev.ricky.galaxywatchmanagerfree`、版本 `0.0.37.006` / `37006`、targetSdk 35、compileSdk 36；`apksigner` v2/v3 校验通过，证书 SHA-256 `86de4a33245393411b43ad0d4fa99233f0ca6f926cef6f60982eac9eba3f1525` 与稳定版 `0.0.37` / `37000` 相同。源码归档由 `python3 scripts/package-source.py --ref v0.0.37.006 --apk …` 复现后与发布文件逐字节一致。
- **通道隔离与不可变地址**：`nightly.json` 从 `0.0.37.005` / `37005` 更新为 `0.0.37.006` / `37006`，APK 固定到提交 `96f7de8e0a2316129ac5fcfdc71f7944d1ce5f28`，`apk-nightly` 分支与保留标签 `apk-v0.0.37.006-93bfd13e…-68fc16af…` 共同指向该提交；更新源提交 `8e469db9ef0990525ab673a6a112a4822ee18e58` 只修改 `nightly.json`。稳定清单 `version.json`（blob `b5e2cb7d885ac5a19c9250c1a587d3b22be1b8f1`）、`apk` 分支（`eceb7677a0bed3ab2af2efee93cd9cd66e401723`）及 Latest `v0.0.37` 均与发布前基线一致。
- **验收边界与证据**：本次完成云端发布、公开清单、匿名下载、安装包/源码静态核验及稳定通道隔离检查；当前无可用 Android 设备，未安装到手机或运行界面。运动轨迹地图实际渲染、拖动缩放、断网重试、原始轨迹道路对齐、明暗主题/大字号、保存/分享及重启持久化，和勿扰开关实际执行、重连与重启持久化仍待真机验收。完整证据保存在被忽略的 `private/maplibre-sdk-20261116/release-006-xeTBow/`。

## 0.0.37.007 Nightly 发布核验（2026-11-16）

- **发布流程**：功能提交 `f28a6f8` 与发布提交 `36a2eac`（附注标签 `v0.0.37.007` 指向 `36a2eac`）的 CI `43836954203`、`43837036063` 及 Release `43837036251`（09:08:15→09:19:34）均成功。Release 为非草稿预发布（`prerelease=true`），正文与 `scripts/release-notes.py --tag v0.0.37.007` 提取内容一致（1,998 字节，仅末尾换行差异），只含当前版本章节；Latest 仍为 `v0.0.37`。
- **附件与匿名下载**：Release APK 为 35,038,128 字节（较 `0.0.37.006` 的 35,034,032 增加 4,096 字节），SHA-256 `466021429966cdd728b7cc823eb06edef183e56c9a0a808bc9829cc2147b2295`；源码归档 5,703,820 字节，SHA-256 `edbbb902a243e6db1deb796239d5604f7b08910009390a6751e06816475c691f`，均与附件内 `.sha256` 及公开 `nightly.json` 一致。公开 feed 匿名下载与经授权的 Release 附件逐字节比对：APK 与源码均一致。`aapt2` 确认包名 `dev.ricky.galaxywatchmanagerfree`、版本 `0.0.37.007` / `37007`、targetSdk 35、compileSdk 36；`apksigner` v2/v3 校验通过，证书 SHA-256 `86de4a33245393411b43ad0d4fa99233f0ca6f926cef6f60982eac9eba3f1525` 与稳定版 `0.0.37` / `37000` 相同。源码归档由 `python3 scripts/package-source.py --ref v0.0.37.007 --apk …` 复现后与发布文件逐字节一致。
- **通道隔离与不可变地址**：`nightly.json` 从 `0.0.37.006` / `37006` 更新为 `0.0.37.007` / `37007`，APK 固定到提交 `013d4d74b0e7835d3321825e7be043b67464a826`，`apk-nightly` 分支与保留标签 `apk-v0.0.37.007-46602142…-edbbb902…` 共同指向该提交；更新源提交 `91bc1c6223ec05c5f177c015888a3448c647fe73` 只修改 `nightly.json`。稳定清单 `version.json`（blob `b5e2cb7d885ac5a19c9250c1a587d3b22be1b8f1`）、`apk` 分支（`eceb7677a0bed3ab2af2efee93cd9cd66e401723`）及 Latest `v0.0.37` 均与发布前基线一致。
- **验收边界与证据**：本次完成云端发布、公开清单、匿名下载、安装包/源码静态核验及稳定通道隔离检查；当前无可用 Android 设备，未安装到手机或运行界面。运动轨迹预览底图实际加载与拼合、全屏地图关闭后的进程存活、拖动缩放、断网重试、原始轨迹道路对齐、明暗主题/大字号、保存/分享及重启持久化，和勿扰开关实际执行、重连与重启持久化仍待真机验收。完整证据保存在被忽略的 `private/release-007-verify/`。

## 勿扰条目归属与确认修正（2026-11-16）

- **用户反馈与官方链路**：`0.0.37.005` 点击免打扰后手机有反应，手表未开启。已从官方 Watch7 Plugin APK 复核 `SettingsCompanion.putDoNotDisturb`：读取 `DataOwner.WATCH` 所属原条目，克隆完整 URI 与 DataMap 后写回，线缆来源为 `from="phone"`；原实现却在手机节点新建精简条目，与官方链路不符。`From.GW` 仅为内部枚举，不能代替线缆来源。协议事实与证据边界见 `docs/PROTOCOL-SPEC.md` §6.5。
- **实现与反馈**：新增 `WatchDndControl`，按当前手表节点缓存并读改写原条目，保留策略及其他字段，更新目标、来源、时间及直到手动关闭的时长。缺模板先读取，手机自回声仅可提供模板；`dndPending` 与确认状态分离，等待期间禁用磁贴，缺模板与已提交未确认分别提示，断线取消任务并拒绝其他手表模板。概览及诊断写入统一入口。
- **本地验证**：Spotless、734 项 JVM 测试（0 失败/错误/跳过）、Lint（0 错误、138 警告）、Release 构建、Android 设备测试代码编译、i18n 1412 项资源（2 语言）、91 项脚本回归通过。合成回归覆盖实际 WCS 帧中的 URI、sourceNode、字段保留、手机自回声、模板读取、失败与超时、命令替换、断线及换节点。
- **验收边界**：当前无可用 Android 设备，未安装或运行手机界面，未验证手表实际执行与重连、重启后持久化；尚无手表接收组件 APK 或本次回包，独立命令是否要求同步偏好开启仍待确认。此次仅完成本地修正与构建，未提交、推送或发布。官方 APK 证据与检查日志保存在被忽略的 `private/`，不影响健康采集、数据、留存或导出结构。

## 运动轨迹地图与详情排版（2026-11-16，0.0.37.006 Nightly）

- **轨迹链路**：统一 `ExerciseRoute` 解析数组及 Base64/gzip 定位载体；保留原始顺序、可选值与分段，按无效点缺口、来源分段和时间回退断线。当前设备后台按需加载最新运动修订，记录更新及设备切换丢弃旧显示状态；每仓库缓存最多 4 条、50,000 点，不新增独立持久化。
- **地图与排版**：接入 MapLibre Native Android 11.8.0 与 OpenStreetMap Standard；展开详情显示带 OSM 底图的轨迹预览（瓦片失败回退本地轮廓），点击进入可拖动缩放的全屏地图，保留起终点、查看全程、加载/重试及本地轮廓降级。地图下方按距离与速度、心率、海拔变化分组，窄屏及大字号用单列；原有有效时长、计数和例程子项保留。
- **坐标与网络边界**：不推断 WGS84/GCJ-02 或进行地区偏移，明确提示坐标系未知；跨日期变更线和极区处理仅改变绘制副本。轨迹本机绘制，在线瓦片可暴露浏览区域；随页提供 OSM 署名、版本化 User-Agent、缓存头和关闭预取，许可证随包保留。
- **健康导出联动**：归档升级 v4，新增覆盖全部留存原始运动历史的 `workout_routes.json`，保留父记录、模块、修订、载体、原始点字段、分段算法与未知坐标系；同步 schema、manifest 数量/覆盖、逐文件校验和、内嵌 README 和健康导出说明。快照、手动小睡及本机睡眠分析独立存储均已核对，留存策略不变。
- **本地验证**：Spotless、747 项 JVM（0 失败/错误/跳过）、Lint（0 错误、143 警告）、Release 构建及 Android 测试源码编译通过；i18n 1433 项资源（2 语言）、91 项脚本回归通过。最终未签名 APK 通过完整资源检查，MapLibre 四组 ABI 及两份新增许可证已核对；Compose 新用例只完成编译。
- **验收边界**：当前无可用 Android 设备，未验证实际地图渲染、拖动缩放、断网重试、明暗主题/大字号、原始轨迹道路对齐、手机保存/分享及设备重启持久化；中国大陆底图性能留待用户实测后调优。本轮未提交、推送或发布，详细说明见 [运动距离与健走地图核查](EXERCISE-DISTANCE-AND-ROUTES.md)。

## 免打扰二次修正与轨迹预览底图（2026-11-16，0.0.37.007 Nightly）

- **免打扰执行链**：`0.0.37.006` 点击免打扰后手表仍无反应。复核官方 `putDoNotDisturb` 写入条件：`longZenDurationEndtime` 仅在定时结束时写入，`0L` 是纪元零点、会让免打扰窗口立即过期。现写 `booleanIsChecked`、`from="phone"`、`time` 与 `intZenDuration=0`（直到手动关闭），并删除克隆模板中残留的 `longZenDurationEndtime`。手机通知策略依赖 `ACCESS_NOTIFICATION_POLICY`，本应用未声明，不写并保留手表原值。证据边界见 `docs/PROTOCOL-SPEC.md` §6.5。
- **轨迹预览底图**：`PreviewTilePlan` 按轨迹范围选择缩放级并计算最多 2×2 的 OSM 栅格瓦片；预览在后台下载、解码并拼合底图后叠加轨迹，任一瓦片失败回退本地轮廓。几何坐标（x ∈ [-0.5, 1.5)、y ∈ [-0.5, 0.5]）平移 0.5 映射到 OSM [0,1) 瓦片空间；跨日期变更线的列号按世界宽度回绕。
- **全屏地图关闭的历史修正**：当时依据 MapLibre 源码把 `onDestroy()` 延后到主线程下一消息，先完成视图脱离与 surface 释放；取消瓦片请求与连接池清理仍在主线程执行。后续真机异常栈确认本次退出崩溃来自连接池关闭的 TLS 网络写入，不能将此前 EGL 竞态分析视为已验证根因，见下方修正记录。
- **本地验证**：Spotless、752 项 JVM（0 失败/错误/跳过）、Lint（0 错误、143 警告）、Release 构建、Android 设备测试代码编译、1433 项双语资源与 91 项脚本回归通过；新增 `PreviewTilePlanTest` 5 项覆盖瓦片覆盖与边距、单点、跨日期变更线与极区。
- **验收边界**：当前无可用 Android 设备，未验证预览底图实际加载/拼合、关闭全屏地图后的进程存活及免打扰手表端执行；不改变健康数据、采集设置、留存或导出结构。

## 免打扰立即生效与天地图底图（2026-11-16）

- **免打扰交互**：用户反馈手机已可切换手表免打扰，但手机长期显示「已请求开启/关闭 · 未确认」。核实该固件在 `setZenMode` 前更新 `mDndState`、观察器不回传独立状态后，将等待改为乐观更新：目标成功进入发送队列即清除 `dndPending`，磁贴按 `dndEffectiveOn = dndSubmitted ?: dndOn` 立即显示「开启/关闭」并允许反向点击；收到当前手表原 URI 上的非手机自回声时仍以手表状态覆盖一次。移除 `dnd_submitted` 等四条「未确认」提示资源。
- **天地图底图**：轨迹预览与全屏地图的底图从 OSM Standard 切换为天地图 Web Mercator WMTS（`t0.tianditu.gov.cn` 的 `vec_w` 矢量底图与 `cva_w` 中文注记，级别 1～18，使用用户提供的应用 Key）。预览每个瓦片位置依次合成两幅后拼合；MapLibre 样式按背景 → 底图 → 注记 → 轨迹排序。署名链接指向天地图官网，网络说明改为天地图在线加载，`THIRD-PARTY.md` 替换对应条目。
- **本地验证**：Spotless、774 项 JVM 测试（0 失败/错误/跳过）、Lint（0 错误、143 警告）、Release 构建及 Android 测试源码编译通过；i18n 1444 项资源（2 语言）、91 项脚本回归通过。回归改判：发送成功立即清空 pending 并报告 SUBMITTED、手表回执覆盖已发送目标、瓦片 URL 校验天地图主机路径与 LAYER/TILEMATRIX/TILEROW/TILECOL、底图与注记图层顺序。
- **手机与手表实测**：同签名预览覆盖安装并保留数据。免打扰连续开启 → 关闭 → 开启 → 关闭，每次手机约 0.5 秒内显示目标状态，独立读取手表 `Settings.Global.zen_mode` 为 1 → 0 → 1 → 0；应用进程重启后恢复「免打扰，已关闭」。运动详情天地图预览和全屏地图均显示底图、中文注记与本地轨迹；全屏放大、缩小、查看全程、关闭均正常，退出后进程 ID 不变，该进程 crash buffer 无致命异常（本次安装前同一 crash buffer 中为上一版本遗留的 `NetworkOnMainThreadException`，属 0.0.37.007 已修复问题）。
- **验收边界与证据**：未执行云端构建或发布，未验收完整断网重试、浅色主题/大字号、手机保存/分享及手机或手表系统重启后的持久化；坐标系仍按未知处理。APK、截图、交互与手表状态证据保存在被忽略的 `private/dnd-map-validation-4fnj7gks/`。此次不改变健康数据、模型、采集设置、留存及导出结构，无需调整健康导出格式；未提交、推送、打标签或发布。

## 免打扰同步门控与地图退出崩溃修正（2026-11-16）

- **免打扰根因与修正**：从手表接收组件 `StDataLayerDndSyncManager.handleSyncData` 确认，`setting_dnd_sync_with_phone` 未开启时会忽略立即开启、关闭命令。现在每次先向当前手表节点的 `sync_do_not_disturb/enabled` 写 `booleanIsChecked=true`，再经同一队列写原始勿扰 URI；门控发送失败时取消目标发送及等待。此操作会开启手表的勿扰同步偏好，应用未增加手机勿扰观察器，保留原条目的策略与既有时长语义。
- **免打扰反馈与反向点击**：所测固件在调用 `setZenMode` 前更新 `mDndState`，因此观察器可能不发送独立状态回报，且 `handleResendSyncData` 仅记录日志，未实现单项回读。新增独立 `dndSubmitted`，不把手机自回声或排队成功当作手表确认；超时后显示「已请求开启/关闭 · 未确认」，下一次点击按已请求目标反向切换。手表在线反馈清除该目标，替换命令发送失败则保留上次已发送目标。进一步真机复现断开重连后目标丢失、下一次错误重发开启，以及手机进程重启后恢复旧 DataItem 的情况：现在断线仅清除界面等待状态，重连恢复同一手表的请求；最新成功排队目标按配对设备与手表节点独立保存，原始快照回放后再载入，不自动重发，也不作为设备确认。协议与限制同步到 SSOT §6.5。
- **地图根因与修正**：真机异常栈为 `NetworkOnMainThreadException`，链路是 Dialog 退出 → `connectionPool.evictAll()` → Conscrypt TLS socket close/write。将请求取消与连接池清理移到由进程持有的 IO 协程作用域，避免随地图离开组合而取消清理；保留视图脱离后的主线程 `MapView.onDestroy()`。此前 EGL 竞态只是分析假设，不能代替这次异常栈证据。
- **本地验证**：Spotless、762 项 JVM 测试（0 失败/错误/跳过）、Lint（0 错误、143 警告）、Release 构建及 Android 设备测试 Kotlin 编译通过；i18n 1435 项资源（2 语言）、91 项脚本回归通过。合成回归覆盖门控帧字段和顺序、门控失败取消旧命令、超时后反向目标、替换失败与手表反馈清理、概览未确认目标投影，并补齐断开重连、延迟手机自回声、进程重建时旧快照覆盖及请求按节点持久化。地图网络清理的 Android TLS 退出路径由下述真机交互核验，JVM 测试不代替此项。
- **手机与手表实测**：已用与已安装版本相同的证书签署本地预览并覆盖安装，保留手机数据。手机连续请求关闭 → 开启 → 关闭，独立读取手表 `Settings.Global.zen_mode` 为 0 → 1 → 0，两种未确认文案和反向点击正常；同步偏好为 1。进一步在开启状态断开重连，恢复「已请求开启 · 未确认」后点击关闭，手表值从 1 → 0；最终预览又验证手机应用进程重启后恢复最新开启请求、随后断开重连并反向关闭，手表值同样从 1 → 0，接收日志明确记录 `booleanIsChecked=false`、`syncDnd=true` 及 `currState0,mDndState:0`。关闭后再次重启手机应用，仍保留最新的「已请求关闭 · 未确认」，最终手表处于关闭状态。协议日志确认先门控后目标，手机自回声不冒充确认。运动详情中预览入口可用，全屏 OSM 底图与轨迹实际渲染；点击关闭、重新打开后系统返回、放大和查看全程后返回，共三次退出均回到运动详情，进程 ID 保持一致，所测进程 crash buffer 无致命异常。
- **验收边界与证据**：未执行云端构建或发布，未验收手机或手表系统重启后的持久化、跨代固件、明暗主题/大字号、完整断网重试及手机保存/分享；手机应用进程重启与连接恢复已按上述链路验收，不能代替这些结果。真机 APK、异常栈、日志及进程对照保存在被忽略的 `private/dnd-map-validation-4fnj7gks/`，官方手表组件提取证据保存在 `private/dnd-watch-settings-apk/`。此次不改变健康数据、模型、采集设置、留存及导出结构，无需调整健康导出格式；未提交、推送、打标签或发布。

## 0.0.37.008 Nightly 发布核验（2026-11-16）

- **发布流程**：功能提交 `3231583`（三星健康与健康监测器独立同步）、`a4ab61d`（免打扰立即生效与天地图底图）及发布说明提交 `6d69ccf`、发布提交 `0d8a1cf`（附注标签 `v0.0.37.008` 指向 `0d8a1cf`）的 CI `43871655164` 与 Release `43871654365`（08:59:48→09:08:37）均成功。Release 为非草稿预发布（`prerelease=true`），正文与 `scripts/release-notes.py --tag v0.0.37.008` 提取内容一致（仅末尾换行差异），只含当前版本章节；Latest 仍为 `v0.0.37`。
- **附件与匿名下载**：Release APK 为 35,054,512 字节（较 `0.0.37.007` 的 35,038,128 增加 16,384 字节），SHA-256 `11ca1d1c7f54140430b8b542736598ec3adcfd51a65df2e60796e3b2f66d2442`；源码归档 5,715,439 字节，SHA-256 `0c25b8332fad2f1665197c5e6daeffe8e18548cf1a7eb5e09a4688aa5e5cbc8d`，均与附件内 `.sha256` 及公开 `nightly.json` 一致。公开 feed 匿名下载与经授权的 Release 附件逐字节比对：APK 与源码均一致。`aapt2` 确认包名 `dev.ricky.galaxywatchmanagerfree`、版本 `0.0.37.008` / `37008`、minSdk 26、targetSdk 35；`apksigner` v2/v3 校验通过，证书 SHA-256 `86de4a33245393411b43ad0d4fa99233f0ca6f926cef6f60982eac9eba3f1525` 与稳定版 `0.0.37` / `37000` 相同。源码归档由 `python3 scripts/package-source.py --ref v0.0.37.008 --apk …` 复现后与发布文件逐字节一致。
- **通道隔离与不可变地址**：`nightly.json` 从 `0.0.37.007` / `37007` 更新为 `0.0.37.008` / `37008`，APK 与源码固定到 feed 提交 `47f910d961b2bb0e0094dd5e1ae860168483f71c`，`apk-nightly` 分支与保留标签 `apk-v0.0.37.008-11ca1d1c…-0c25b833…` 共同指向该提交；更新源提交 `32bf5971664753dc7eaba6ae2ee21a7d49c2b464` 只修改 `nightly.json`。稳定清单 `version.json`（blob `b5e2cb7d885ac5a19c9250c1a587d3b22be1b8f1`）、`apk` 分支（`eceb7677a0bed3ab2af2efee93cd9cd66e401723`）及 Latest `v0.0.37` 均与发布前基线一致。
- **验收边界与证据**：本次完成云端发布、公开清单、匿名下载、安装包/源码静态核验及稳定通道隔离检查；当前无可用 Android 设备，未安装到手机或运行界面。免打扰与天地图改动已在同签名预览上完成手机与手表实测（见上一节）；三星健康/健康监测器双源同步的握手隔离、按通道完成与失败提示仅有 JVM 回归（`HealthSyncSummaryTest`、`HealthSyncCoordinatorTest`、`HealthMonitorSessionTest` 等），未做真机验证。本轮不改变健康数据模型、采集设置、留存或导出结构，健康导出沿用 v4。完整证据保存在被忽略的 `private/`。

## 0.0.38 正式版发布核验（2026-11-16）

- **发布流程**：发布说明提交 `fa3ae66`（汇总 `0.0.37.001`～`0.0.37.008` 为正式版章节）与 `c7773e7`（记录 `0.0.37.008` 核验）后，`./scripts/release.sh` 生成发布提交 `b1df810` 并推送附注标签 `v0.0.38`（指向 `b1df810`）。CI `43875647849` 与 Release `43875649148`（13:25:42Z 创建）均成功，Release 于 13:34:54Z 发布。Release 为非草稿正式版（`prerelease=false`），名称为「Galaxy Watch Manager Free 0.0.38」，正文与 `scripts/release-notes.py --tag v0.0.38` 提取内容一致（仅末尾换行差异），只含当前版本章节；`releases/latest` 已指向 `v0.0.38`（`prerelease=false`）。
- **附件与匿名下载**：Release APK 为 35,054,512 字节（与 `0.0.37.008` 同为 35,054,512，仅版本号/版本码变化），SHA-256 `299227afc609e4680e96f3f1d2b06f2665ea6fb50cd67511a8a66e2b9e79eea3`；源码归档 5,716,814 字节，SHA-256 `1a9959379edca7e15f9938480e4f578419e3716cd929bbf4e1f639c06ed5afd5`，均与附件内 `.sha256` 及公开 `version.json` 一致。公开 feed 匿名下载（`raw.githubusercontent.com`，无鉴权）与经授权的 Release 附件 SHA-256 一致。`aapt2` 确认包名 `dev.ricky.galaxywatchmanagerfree`、版本 `0.0.38` / `38000`、minSdk 26、targetSdk 35；`apksigner` 验证通过，证书 SHA-256 `86de4a33245393411b43ad0d4fa99233f0ca6f926cef6f60982eac9eba3f1525` 与 `0.0.37` / `0.0.37.008` 相同（`CN=Galaxy Watch Tweaker, O=Ricky, C=US`）。源码归档由 `python3 scripts/package-source.py --ref v0.0.38` 复现后与发布文件逐字节一致。
- **通道隔离与不可变地址**：`version.json` 从 `0.0.37` / `37000`（blob `b5e2cb7d…`，`apk` 分支 `eceb7677…`）更新为 `0.0.38` / `38000`，blob `b149d8089b011af7b17339cecb455c83e560aae9`，APK 与源码固定到 feed 提交 `35698cbd3a1d788d9b956780c4a1a3a8d7cd4f09`，`apk` 分支指向该提交；更新源提交 `2cd9f3cf706c`（chore: update feed for v0.0.38）只修改 `version.json`。Nightly 清单 `nightly.json`（blob `2f78a8684da30c189832c286b804b0237120c340`，仍为 `0.0.37.008` / `37008`）与 `apk-nightly` 分支（`47f910d961b2bb0e0094dd5e1ae860168483f71c`）均与发布前基线一致，Nightly 最新预发布 `v0.0.37.008` 不受正式版影响。
- **验收边界与证据**：本次完成云端发布、公开清单、匿名下载、安装包/源码静态核验及双通道隔离检查；未将发布 APK 安装到手机或运行界面。免打扰与天地图改动已在同签名预览上完成手机与手表实测，手机与手表系统重启后的持久化、跨代固件、完整断网重试、浅色主题/大字号及手机保存/分享仍为未完成边界；三星健康/健康监测器双源同步仅有 JVM 回归，未做真机验证。健康导出为 v4，较 `0.0.37` 的 v3 新增 `workout_routes.json`，数据模型、采集设置与留存策略未变。完整证据保存在被忽略的 `private/release-0.0.38-verification/`。

## 文案校对与程序全景规范建立（2026-11-16）

- **文案校对与术语归一**：校对全仓双语资源（`values/strings.xml` 与 `values-zh-rCN/strings.xml`，1444 项资源、2 种语言）。将历史混用的「勿扰模式/勿扰规则/同步勿扰模式/立即开启勿扰/未取得手表原始勿扰数据」统一归一为 One UI Watch 与 Android 系统标准术语「免打扰/免打扰规则/同步免打扰/立即开启免打扰/未取得手表原始免打扰数据」，消除概览磁贴（`do_not_disturb`，免打扰）与设置页之间的术语撕裂；英文资源同步规范大写 `Do Not Disturb`。全仓 1402 个字符串 key 经静态分析全部有实际引用，无孤儿资源；标点、占位符、复数规则均严格匹配。
- **程序全景规范文档建立**：根据当前代码最新实现与架构，撰写并建立 [`docs/APP-SPECIFICATION.md`](APP-SPECIFICATION.md)，系统整理 7 大核心体系：系统定位与设计哲学、全局分层拓扑与线程模型、核心生命周期与前台服务、WCS 协议栈与关键身份兼容补丁、8 项核心业务功能实现细节（免打扰即时切换、双源健康同步、天地图运动轨迹、端侧睡眠推理、通知桥接与图标、官方交接、健康导出 v4、双通道发布与校验）、数据存储与设备隔离规范、以及后续功能变动强联动回补要求。并在 `AGENTS.md`、`CONTRIBUTING.md`、`README.md` 与 `docs/PROJECT-MAP.md` 中建立索引与维护规则。
- **本地验证**：`python3 scripts/check-i18n.py` 验证 1444 项资源格式与键匹配通过；Spotless、JVM 单元测试、Lint 与脚本测试全量通过。

## 通知图标双资产映射与应用名解析修复（2026-11-20，Nightly 0.0.40.004 已发布）

- **缺陷复盘与原因分析**：
  - 用户反馈 QQ 等第三方通知下发到手表后显示为系统 fallback 普通图标，而非 QQ 自身图标；而微信图标正常。
  - 逆向官方三星 Watch7 插件（`zzewl.java` / `C1426er.java`）与 Wear OS Clockwork（`eip.java`）证实：Wear OS 原生通知卡片头部优先读取 DataMap 中的 `"icon"`（状态栏小图标），而应用徽标读取 `"app_icon"`（应用启动图标）；同时下发 `"app_name"`（应用显示名，如“QQ”）。
  - 此前实现中：`BridgerNotificationSender` 仅写入了 `app_icon`，未填充 `icon`；且 `NotificationBridgeService` 未解析应用显示名，直接将包名（`com.tencent.mobileqq`）作为 `app_name` 下发。
  - 微信之所以显示正常，是因为手表端具备 3pmessaging 与本地微信手表应用/系统包名映射缓存，能本地回退解析；而对于未在手表端安装独立应用的第三方应用（如 QQ），手表端无法本地解析，且因 DataMap 缺失 `icon` 字段而直接退化为默认铃铛 fallback 图标。
- **链路修复与双资产下发**：
  - `NotificationAppCatalog`：新增 `appName(context, packageName)` 读取应用标签；新增 `forwardingSmallIcon(context, sbn)` 提取并压缩 48×48 PNG 通知小图标；新增 `isSmallIconVector(context, sbn)` 判定矢量图标类型。
  - `BridgerNotificationSender`：重构 `send` 方法支持 `appIcon` 与 `smallIcon` 双资产。若两者独立存在，分别作为 Asset 0 与 Asset 1 写入，映射 `app_icon` 与 `icon`，并携带 `is_small_icon_vector_drawable` 标识；若仅有一方或内容一致，则二者安全复用 Asset 0 引用；同时确保 `app_name` 优先使用实际应用显示名。
  - `WcsSession` & `WatchRepository` & `NotificationBridgeService`：补齐双图标参数透传链路，自动在通知转发时提取真实应用名与小图标下发。
- **本地验证**：
  - `BridgerNotificationSenderTest` 扩展覆盖双资产独立映射、小图标复用 Asset 0、矢量标志透传、应用名显式与空白回退测试；
  - Spotless 代码格式检查通过、Lint 检查通过、845 项 JVM 单元测试全部通过（0 失败/错误/跳过）。
- **Nightly 发布核验（0.0.40.004）**：`./scripts/release.sh --nightly` 生成发布提交 `9a88e53` 并推送附注标签 `v0.0.40.004`，版本 `0.0.40.004` / `40004`。GitHub Actions 因账户支出限制未能启动，按既定标准本地复刻完整发布流程：`./gradlew :app:assembleRelease`、`scripts/sign-apk.sh` 正式签名、`check_public_assets.py`、`package-source.py` 与 `gh release create` 创建 GitHub 预发布（`prerelease=true`，`latest=false`，名称「Galaxy Watch Manager Free 0.0.40.004」，正文与 `release-notes.py` 一致）。APK 35,161,008 字节，SHA-256 `7959c33f03f572e9c260363de70e57f72ec76f95954bf019d08fff430f825508`；源码归档 5,802,652 字节，SHA-256 `2ba985282cf84c14a328d5fbd2624716e2dd00fd8f88c4c83a8ff19633537e99`。`aapt2` 确认包名 `dev.ricky.galaxywatchmanagerfree`、版本 `0.0.40.004` / `40004`；`apksigner` v2/v3 通过，证书 SHA-256 `86de4a33245393411b43ad0d4fa99233f0ca6f926cef6f60982eac9eba3f1525` 与正式证书一致。
- **源码交付与通道隔离（0.0.40.004）**：`nightly.json` 更新为 `0.0.40.004` / `40004`，APK 与源码固定到 feed 提交 `88597adf50e9411dbb50082c064bce2c9c55e59b`，`apk-nightly` 分支指向该提交，retained tag 为 `apk-v0.0.40.004-7959c33f03f572e9c260363de70e57f72ec76f95954bf019d08fff430f825508-2ba985282cf84c14a328d5fbd2624716e2dd00fd8f88c4c83a8ff19633537e99`；feed `main` 提交 `7fa18a0` 只修改 `nightly.json`。稳定通道 `version.json` 严格保持 `0.0.40` / `40000` 未变，`releases/latest` 依然指向 `v0.0.40`。公开 feed 匿名下载 APK 与源码摘要与 Release 产物逐字节一致，完整验证记录保存在 `private/release-0.0.40.004-verification`。

## 内存清理健康应用免杀与连接交接容灾优化（2026-11-21，Nightly 0.0.40.005 已发布）

- **问题复盘与日志分析**：
  - 用户反馈健康面板数据无法同步，健康报文同步彻底超时。分析手表端诊断日志发现：手机端执行“一键内存清理”时，将手表端常驻守护进程 `com.samsung.android.wear.shealth` 与 `com.samsung.android.service.health` 杀死；而 Wear OS 系统在后台进程被杀后，不会自动通过蓝牙 RFCOMM 数据报文唤醒 `WearableListenerService`，导致手表端监听挂起、健康报文静默丢弃。
  - 用户同时反馈连接与交接存在偶发不稳定：在 GMS RPC 响应抖动或无 GMS 手机上，获取本机节点偶发超时失败直接导致连接中断置为 `IdentityMissing`；交接卡片等待暂存身份超时与 GMS 存在临界竞争；多设备切换时目标 MAC 状态可能出现短暂漂移。
- **链路修复与保护机制**：
  - `WatchRepository`：在设备维护内存管理中新增 `isProtectedMemoryCleanPackage`，严格排除包含 `shealth` 与 `health` 的包名；在手表上报内存数据解析及手机下发 `cleanRam` 目标应用列表时实施双层白名单过滤，确保手表端核心健康守护服务免受一键清理误杀。
  - `WatchController`：在获取 GMS 本机节点失败（`LocalNodeResult.Failure`）时，新增回退复用 `DeviceIdentityStore.confirmedPhoneNode` 容灾逻辑；在交接准备与常规连接中均可安全复用已确认有效身份，杜绝因临时 RPC 失败中断建连。
  - `CompanionHandoverCard` & `DeviceConnectionScreen`：将交接卡片等待暂存身份超时从 5,000ms 放宽至 6,000ms，消除低端机或多应用切换时的竞争断流；在连接主入口处显式同步校准 `savedMac`，避免多设备环境下的状态漂移。
- **本地验证**：
  - `DeviceCareBatteryPayloadTest` 新增 3 项单测，全面覆盖健康与系统服务白名单免杀及解析过滤；
  - Spotless 代码格式检查通过、Lint 检查通过、848 项 JVM 单元测试全部通过（0 失败/错误/跳过）。
- **Nightly 发布核验（0.0.40.005）**：`./scripts/release.sh --nightly` 生成发布提交 `85dd456` 并推送附注标签 `v0.0.40.005`，版本 `0.0.40.005` / `40005`。GitHub Actions 因账户支出限制未能启动，按既定标准本地复刻完整发布流程：`./gradlew :app:assembleRelease`、`scripts/sign-apk.sh` 正式签名、`check_public_assets.py`、`package-source.py` 与 `gh release create` 创建 GitHub 预发布（`prerelease=true`，`latest=false`，名称「Galaxy Watch Manager Free 0.0.40.005」，正文与 `release-notes.py` 一致）。APK 35,165,104 字节，SHA-256 `e9226185051633e9e6b0b992990e42b8246ea13cf143b0a6e5e020c98fbcccd1`；源码归档 5,806,356 字节，SHA-256 `bac7c141e7504b5900a93f53f98f259a19ef0552f460dec812802879fcdae69c`。`aapt2` 确认包名 `dev.ricky.galaxywatchmanagerfree`、版本 `0.0.40.005` / `40005`；`apksigner` v2/v3 通过，证书 SHA-256 `86de4a33245393411b43ad0d4fa99233f0ca6f926cef6f60982eac9eba3f1525` 与正式证书一致。
- **源码交付与通道隔离（0.0.40.005）**：`nightly.json` 更新为 `0.0.40.005` / `40005`，APK 与源码固定到 feed 提交 `64f1589edf27968f70c9982cf86495bd00e8ea6a`，`apk-nightly` 分支指向该提交，retained tag 为 `apk-v0.0.40.005-e9226185051633e9e6b0b992990e42b8246ea13cf143b0a6e5e020c98fbcccd1-bac7c141e7504b5900a93f53f98f259a19ef0552f460dec812802879fcdae69c`；feed `main` 提交 `46d2049` 只修改 `nightly.json`。稳定通道 `version.json` 严格保持 `0.0.40` / `40000` 未变，`releases/latest` 依然指向 `v0.0.40`。公开 feed 匿名下载 APK 与源码摘要与 Release 产物逐字节一致，完整验证记录保存在 `private/release-0.0.40.005-verification`。

## Galaxy Watch8 与 Watch8 Classic 适配（2026-11-21，Nightly 0.0.40.006 已发布）

- 三星管理器的机型表将两款手表映射到共用 Watch Manager。REA 核对了插件的 APK 清单与 companion service 声明，`apksigner` 验证了官方签名。样本和证据编号见 [Watch8 兼容性调查](WATCH4-6-COMPATIBILITY.md#watch8--watch8-classic)。
- 已配对设备识别支持标准版和 Classic 的蓝牙与 LTE 型号，Classic 可按型号显示外观。交接页、Shizuku 授权操作及测试恢复脚本识别插件的准确包名，应用交接记录保留原启用状态。
- 本地通过 Spotless、850 项 JVM 单测、91 项脚本测试、双语资源校验、Lint（0 错误）以及 Debug / Release 构建。APK 清单已核对包可见性。当前没有在线 ADB 设备，真机交接、重连、通知和健康数据同步待验收。
- **Nightly 发布核验（0.0.40.006）**：`./scripts/release.sh --nightly` 生成发布提交 `334cab6` 并推送附注标签 `v0.0.40.006`，版本 `0.0.40.006` / `40006`。按既定标准本地复刻完整发布流程：`./gradlew :app:assembleRelease`、`scripts/sign-apk.sh` 正式签名、`check_public_assets.py`、`package-source.py` 与 `gh release create` 创建 GitHub 预发布（`prerelease=true`，`latest=false`，名称「Galaxy Watch Manager Free 0.0.40.006」，正文与 `release-notes.py` 一致）。APK 35,165,104 字节，SHA-256 `c8e684666de590ef61a72a7796e3b14264728447c09c3efff13488458395b6e0`；源码归档 5,809,551 字节，SHA-256 `a3d9b09e2f1ac6068d7322fb9b0f13a753887a40308fbf741d388c4826a1d6c1`。`aapt2` 确认包名 `dev.ricky.galaxywatchmanagerfree`、版本 `0.0.40.006` / `40006`；`apksigner` v2/v3 通过，证书 SHA-256 `86de4a33245393411b43ad0d4fa99233f0ca6f926cef6f60982eac9eba3f1525` 与正式证书一致。
- **源码交付与通道隔离（0.0.40.006）**：`nightly.json` 更新为 `0.0.40.006` / `40006`，APK 与源码固定到 feed 提交 `56a0499b990a63f0a7412de7f32aad693cff1486`，`apk-nightly` 分支指向该提交，retained tag 为 `apk-v0.0.40.006-c8e684666de590ef61a72a7796e3b14264728447c09c3efff13488458395b6e0-a3d9b09e2f1ac6068d7322fb9b0f13a753887a40308fbf741d388c4826a1d6c1`；feed `main` 提交 `da1c0a9` 只修改 `nightly.json`。稳定通道 `version.json` 严格保持 `0.0.40` / `40000` 未变，`releases/latest` 依然指向 `v0.0.40`。公开 feed 匿名下载 APK 与源码摘要与 Release 产物逐字节一致，完整验证记录保存在 `private/release-0.0.40.006-verification`。

## 第三方通知应用图标失败根因定位与真机修复（2026-11-22 ~ 11-23）

- **现象**：微信、QQ、Telegram 通知在 Galaxy Watch 7 Ultra 上全部显示通用图标（`0.0.40.006` 之前反复表现为系统短信气泡 / 管理应用图标），微信与 Telegram 的降级表现说明手表端始终没有拿到可用图标。
- **排查过程中的两类误判（已排除）**：
  1. 图片格式与尺寸：曾按 Samsung 手机插件内部图片管线把图标改成 `WEBP_LOSSLESS` 56/40，真机仍然全部回退；官方 Wear 手机端 `dxf.bb` 实际对资产一律用 **PNG**。格式不是根因。
  2. DataMap 字段与单/双图标映射：曾尝试只发 `app_icon`、只发 `icon`、双资产三种组合，并用 `notification_style` 等官方字段补齐，均不改变结果。
- **决定性定位方法**：新增 ADB 诊断命令 `notif_probe`（`pkg` / `app` / `color` / `mode=app|small|both|none`），下发纯色图标并走与真实图标完全相同的资产链路。真机上四条探针（品红 / 青 / 绿 / 无图标）全部显示同一个通用图标，证明**下发的资产根本没有被手表端解析**，而不是图标内容或模板选错。
- **真正根因**：Wear V1 资产下发的 `SetAsset`（`hjo.f4 = hjw`）里，**拥有者列表被写错了字段**。按 `hjw` / `hid` / `hif` 的 proto 定义：f1 为内容摘要、f2 为内联数据、**f3 才是 `hid` 拥有者列表**（`hid.f1` 重复 `hif{f1 包名, f2 签名摘要}`）。原实现把 `hid` 塞进了 f2（内联数据）位置，导致手表端即使 `AckAsset` 保存了字节，也没有建立（包名, 签名摘要）的访问控制记录，DataItem 中的资产引用不可解析，通知卡片只能回退通用图标。
- **修复**：
  1. 新增 `wcs/WearAssetSender.kt` 统一负责 `SetAsset` + `FilePiece`：`hjw = f1 摘要 + f3 hid{f1: hif{包名, 签名摘要}}`，分片仍按 `12288-73` 字节与 queueId 5/6 规则发送。
  2. `BridgerNotificationSender` 改用该发送器，并在成功后把摘要与字节交给会话缓存。
  3. `WcsSession` 新增对官方 **FetchAsset**（`hjo.f6 = hjd{f1 包名, f2 摘要, f3 urgent, f4 签名摘要}`）的应答：用最近 8 个资产的内存缓存按请求方身份重新下发，覆盖资产未被缓存或被清理的情况。
  4. `NotificationAppCatalog` 图标编码回到 PNG 无损；继续按最大边 56px / 40px 缩放。
  5. DataMap 补齐官方 `zzewl` 字段集：`notification_style=1`、`title_html` / `text_html`、`post_time_millis`、`color`、`has_content_intent`、`only_alert_once`、`is_work_profile`、`is_emergency`、`is_group_summary`，并始终下发 `is_small_icon_vector_drawable`。
- **验证**：
  1. 本地门禁：Spotless 通过，JVM 单元测试全部通过（含 `BridgerNotificationSenderTest` 对 `hjw.f3` 拥有者与 `f2` 留空的断言、`WearAssetSenderTest` 对 SetAsset/FilePiece/FetchAsset 解析的断言），Lint 通过，Release 构建与正式签名通过（证书 SHA-256 `86de4a33…f1525`）。
  2. 真机（Galaxy Watch 7 Ultra + 非三星手机）：`notif_probe` 橙色与品红纯色探针在手表通知卡片上正常显示；随后依次下发微信（`com.tencent.mm`）、QQ（`com.tencent.mobileqq`）与 Telegram（`org.telegram.messenger`），**三条均显示各自应用图标**，用户现场确认通过。
  3. **真实通知路径补验**：由用户在微信「文件传输助手」发出真实消息，日志确认走双资产分支（`app_icon` 3271B + 小图标 `icon` 1750B，`result=WITH_ICON`，`is_small_icon_vector_drawable=true`），手表卡片显示微信图标，用户确认通过。此前所有测试都是 ADB 注入的单资产分支，这条组合现已覆盖。
  4. **FetchAsset 补验**：新增诊断模式 `notif_probe --es mode fetch`，只登记资产引用与内存缓存、不主动上传，用来观察手表是否回拉。真机上手表**没有**发出 FetchAsset，而是直接忽略无法解析的资产并回退通用图标，因此应答逻辑目前不会在正常下发路径上触发；其报文解析（`hjd{f1 包名, f2 摘要, f3 urgent, f4 签名摘要}`）与按请求方身份重发已由本地单测覆盖，作为资产被清理或缓存失效时的安全网保留。
- **Nightly 发布核验（0.0.40.007）**：`./scripts/release.sh --nightly` 生成发布提交 `2407ace` 并推送附注标签 `v0.0.40.007`，版本 `0.0.40.007` / `40007`；功能提交为 `915f98e`。按既定标准本地复刻完整发布流程：`./gradlew :app:assembleRelease`、`scripts/sign-apk.sh` 正式签名、`check_public_assets.py`、`package-source.py` 与 `gh release create` 创建 GitHub 预发布（`prerelease=true`，`latest=false`，名称「Galaxy Watch Manager Free 0.0.40.007」，正文与 `release-notes.py` 一致且只含当前版本章节）。APK 35,169,200 字节，SHA-256 `4d8a414c2b96989af3d00b5009dc215887b85d7d940d5af4fdebdef801a2e9f2`；源码归档 5,819,280 字节，SHA-256 `f11b80aa663ee02728a432b384726c980b15e489a2827f61fe9c71548a51c803`。`aapt2` 确认包名 `dev.ricky.galaxywatchmanagerfree`、版本 `0.0.40.007` / `40007`；`apksigner` v2/v3 通过，证书 SHA-256 `86de4a33245393411b43ad0d4fa99233f0ca6f926cef6f60982eac9eba3f1525` 与正式证书一致。
- **源码交付与通道隔离（0.0.40.007）**：`nightly.json` 更新为 `0.0.40.007` / `40007`，APK 与源码固定到 feed 提交 `434d5dd21fb5c91ddddae6caa5a93954eb6ee895`，`apk-nightly` 分支指向该提交，retained tag 为 `apk-v0.0.40.007-4d8a414c…-f11b80aa…`；feed `main` 提交 `9495bed` 只修改 `nightly.json`。稳定通道 `version.json` 保持 `0.0.40` / `40000` 未变，`releases/latest` 仍指向 `v0.0.40`。

