package dev.ricky.galaxywatchmanagerfree.feature

import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.Period
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.temporal.ChronoUnit
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.sqrt
import org.json.JSONArray
import org.json.JSONObject

object EnergyScoreCalculator {
    const val ALGORITHM = "phone_vitality_v1"

    data class Result(
        val date: LocalDate,
        val deviceUuid: String,
        val values: JSONObject,
        val inputs: JSONObject,
    )

    data class Interval(val start: Long, val end: Long, val value: Float)

    data class Sleep(
        val id: String,
        val date: LocalDate,
        val start: Long,
        val end: Long,
        val localStart: LocalDateTime,
        val localEnd: LocalDateTime,
        val stages: List<Pair<LocalDateTime, LocalDateTime>>,
        val deviceUuid: String,
        val isNap: Boolean = false,
    )

    data class SleepFactors(
        val score: Float,
        val duration: Long,
        val durationScale: Float,
        val balance: Float,
        val balanceScale: Float,
        val timing: Float,
        val timingScale: Float,
        val regularity: Float,
        val regularityScale: Float,
        val napDeltas: List<Float>,
    )

    data class HrvFactors(
        val score: Float,
        val value: Float,
        val ratio: Float,
        val balanceScale: Float,
        val baseline: Float,
        val penalty: Boolean,
    )

    data class ActivityFactors(
        val score: Float,
        val previousDayScore: Float,
        val activeMillis: Long,
        val shortTerm: Float,
        val longTerm: Float,
        val balance: Float,
        val balanceScale: Float,
    )

    private fun field(row: JSONObject, name: String): Any? {
        if (row.has(name) && !row.isNull(name)) return row.opt(name)
        return row.keys()
            .asSequence()
            .filter { it.endsWith(".$name") }
            .sorted()
            .firstOrNull { !row.isNull(it) }
            ?.let(row::opt)
    }

    private fun number(row: JSONObject, name: String): Double? =
        field(row, name)?.toString()?.toDoubleOrNull()?.takeIf { it.isFinite() }

    private fun localTime(row: JSONObject, ts: Long, zone: ZoneId): LocalDateTime {
        val offset = field(row, "time_offset")?.toString()
        val milliseconds = offset?.toLongOrNull()
        return if (milliseconds != null && milliseconds in -64_800_000L..64_800_000L)
            LocalDateTime.ofInstant(Instant.ofEpochMilli(ts + milliseconds), ZoneOffset.UTC)
        else if (offset != null && offset.startsWith("UTC"))
            runCatching { LocalDateTime.ofInstant(Instant.ofEpochMilli(ts), ZoneId.of(offset)) }
                .getOrElse { LocalDateTime.ofInstant(Instant.ofEpochMilli(ts), zone) }
        else LocalDateTime.ofInstant(Instant.ofEpochMilli(ts), zone)
    }

    private fun napFlag(row: JSONObject): Boolean? =
        field(row, "is_nap")?.let { it == true || it.toString() == "1" }

    fun sleeps(
        store: HealthRecordStore,
        zone: ZoneId,
        sessions: List<SleepParser.Session>? = null,
    ): List<Sleep> {
        val rows =
            store
                .recordsNewest(SleepParser.MODULE_SLEEP, SleepParser.MODULE_SLEEP_LEGACY)
                .associateBy { field(it, "datauuid")?.toString().orEmpty() }
        val projected =
            SleepParser.mergeSessions(
                sessions
                    ?: SleepParser.sessions(
                        rows.values.toList(),
                        store.records(SleepParser.MODULE_SLEEP_DATA),
                        store.recordsNewest(
                            SleepParser.MODULE_SLEEP_STAGE,
                            SleepParser.MODULE_SLEEP_STAGE_LEGACY,
                        ),
                    ),
                emptyList(),
            )
        val mainIds =
            projected
                .filterNot { it.id.startsWith("manual:") || rows[it.id]?.let(::napFlag) == true }
                .groupBy {
                    localTime(rows[it.id] ?: JSONObject(), it.endMillis, zone).toLocalDate()
                }
                .mapValues { (_, day) -> day.maxBy { it.endMillis - it.startMillis }.id }
        return projected
            .mapNotNull { session ->
                val start = session.startMillis
                val end = session.endMillis
                if (start <= 0 || end <= start || end - start > 24 * 3_600_000L)
                    return@mapNotNull null
                val row = rows[session.id] ?: JSONObject()
                val localStart = localTime(row, start, zone)
                val localEnd = localTime(row, end, zone)
                val nap =
                    session.id.startsWith("manual:") ||
                        (napFlag(row) ?: (mainIds[localEnd.toLocalDate()] != session.id))
                Sleep(
                    session.id,
                    localEnd.toLocalDate(),
                    start,
                    end,
                    localStart,
                    localEnd,
                    session.segments
                        .filter {
                            it.endMillis > it.startMillis &&
                                it.startMillis >= start &&
                                it.endMillis <= end
                        }
                        .map {
                            localTime(row, it.startMillis, zone) to
                                localTime(row, it.endMillis, zone)
                        },
                    field(row, "deviceuuid")?.toString().orEmpty(),
                    nap,
                )
            }
            .sortedBy { it.start }
    }

    private fun intervals(rows: List<JSONObject>, key: String): List<Interval> =
        rows
            .flatMap { row ->
                val bins =
                    HealthJson.array(field(row, "binning_data"))
                        ?: HealthJson.array(field(row, "binning"))
                val source =
                    if (bins == null) listOf(row)
                    else (0 until bins.length()).mapNotNull(bins::optJSONObject)
                source.mapNotNull { item ->
                    val value =
                        number(item, key)?.toFloat()?.takeIf { it > 0f } ?: return@mapNotNull null
                    val start = number(item, "start_time")?.toLong() ?: return@mapNotNull null
                    val end = number(item, "end_time")?.toLong() ?: start + 1
                    if (start <= 0 || end <= start) null else Interval(start, end, value)
                }
            }
            .associateBy { it.start to it.end }
            .values
            .sortedBy { it.start }

    private fun average(samples: List<Interval>, sleeps: List<Sleep>): Float? {
        var sum = 0.0
        var duration = 0L
        for (sample in samples) for (sleep in sleeps) {
            val overlap = minOf(sample.end, sleep.end) - maxOf(sample.start, sleep.start)
            if (overlap > 0) {
                sum += overlap * sample.value.toDouble()
                duration += overlap
            }
        }
        return if (duration > 0) (sum / duration).toFloat() else null
    }

    fun calculate(
        store: HealthRecordStore,
        age: Int,
        female: Boolean,
        today: LocalDate,
        zone: ZoneId,
        sessions: List<SleepParser.Session>? = null,
    ): List<Result> {
        require(age in 18..99)
        val sleep = sleeps(store, zone, sessions).filter { it.date <= today }
        val days = sleep.filterNot { it.isNap }.groupBy { it.date }.toSortedMap()
        val heartRate =
            intervals(store.recordsNewest(HeartRateLog.MODULE), "heart_rate").filter {
                it.value in 25f..240f
            }
        val rmssd =
            intervals(store.recordsNewest(*HealthMetric.HRV.moduleKeys.toTypedArray()), "rmssd")
                .filter { it.value in 1f..300f }
        val shr =
            days.mapNotNull { (date, day) -> average(heartRate, day)?.let { date to it } }.toMap()
        val shrv =
            days.mapNotNull { (date, day) -> average(rmssd, day)?.let { date to it } }.toMap()
        val activity =
            store
                .recordsNewest(HealthStepParser.MODULE_DAY_SUMMARY)
                .mapNotNull { row ->
                    val date =
                        HealthStepParser.daySummaryDate(row, zone)?.let(LocalDate::parse)
                            ?: return@mapNotNull null
                    val time =
                        number(row, "active_time")?.takeIf { it in 0.0..86_400_000.0 }
                            ?: return@mapNotNull null
                    date to time.toLong()
                }
                .groupBy({ it.first }, { it.second })
                .mapValues { it.value.max() }
        return days.mapNotNull { (date, mainSleep) ->
            val recent = sleep.filter { it.date in date.minusDays(6)..date }
            val factors = sleepFactors(recent, date) ?: return@mapNotNull null
            val active = activityFactors(activity, date, female) ?: return@mapNotNull null
            val hrValue = shr[date] ?: return@mapNotNull null
            val hrvValue = shrv[date] ?: return@mapNotNull null
            val hrHistory = shr.filterKeys { it in date.minusDays(6)..date }
            val hrvHistory = shrv.filterKeys { it in date.minusDays(6)..date }
            val hrBaseline =
                if (hrHistory.size == 1) (hrPrior(age, female) * .75f + hrValue) / 2f
                else hrHistory.values.average().toFloat()
            val hrScore = heartRateScore(hrValue / hrBaseline)
            val hrv = hrvFactors(hrvValue, hrvHistory.values.toList(), age, female)
            var total =
                total(active.score, hrScore, hrv.score, factors.score) ?: return@mapNotNull null
            for (delta in factors.napDeltas) total = minOf(100f, total + napBonus(total, delta))
            val stableRate = stableHeartRateTime(heartRate, mainSleep)
            val main = mainSleep.maxBy { it.end }
            val values =
                JSONObject()
                    .put("total_score", total)
                    .put("sleep_score", factors.score)
                    .put("activity_score", active.previousDayScore)
                    .put("shr_score", hrScore)
                    .put("shrv_score", hrv.score)
                    .put("sleep_duration", factors.duration)
                    .put("sleep_balance", available(factors.balance))
                    .put("sleep_regularity", available(factors.regularity))
                    .put("sleep_timing", factors.timing)
                    .put("sleep_duration_scale", available(factors.durationScale))
                    .put("sleep_balance_scale", available(factors.balanceScale))
                    .put("sleep_regularity_scale", available(factors.regularityScale))
                    .put("sleep_timing_scale", available(factors.timingScale))
                    .put("active_time", active.activeMillis)
                    .put("active_time_scale", active.previousDayScore)
                    .put("mvpa_time", JSONObject.NULL)
                    .put("mvpa_impulse", JSONObject.NULL)
                    .put("mvpa_time_scale", JSONObject.NULL)
                    .put("mvpa_impulse_scale", JSONObject.NULL)
                    .put("shrv_penalty", if (hrv.penalty) 20f else 0f)
                    .put("stable_hr_time_rate", available(stableRate))
                    .put("avg_mid_sleep_time", JSONObject.NULL)
                    .put("prev_shr_avg", hrBaseline)
                    .put("prev_shrv_avg", hrv.baseline)
                    .put("shr_balance_scale", hrScore)
                    .put("shrv_balance_scale", hrv.balanceScale)
                    .put("shr_value", hrValue)
                    .put("shrv_value", hrvValue)
                    .put("shr_baseline_min", .9f * hrBaseline)
                    .put("shr_baseline_max", .975f * hrBaseline)
                    .put("shrv_baseline_min", exp(.975f * ln(hrv.baseline)))
                    .put("shrv_baseline_max", exp(1.0666667f * ln(hrv.baseline)))
                    .put("shr_calculation_index", -1)
                    .put("shrv_calculation_index", -1)
                    .put("main_sleep_wake_up_time", main.end)
                    .put("activity_balance_short_term_activity", active.shortTerm)
                    .put("activity_balance_long_term_activity", active.longTerm)
                    .put("activity_balance_scale", active.balanceScale)
                    .put("activity_balance", active.balance)
            val inputs =
                JSONObject()
                    .put("profile_age", age)
                    .put("profile_sex", if (female) "F" else "M")
                    .put("sleep_ids", JSONArray(recent.map { it.id }))
                    .put("nap_ids", JSONArray(recent.filter { it.isNap }.map { it.id }))
                    .put(
                        "staged_sleep_ids",
                        JSONArray(recent.filter { it.stages.isNotEmpty() }.map { it.id }),
                    )
                    .put("nap_recovery_deltas", JSONArray(factors.napDeltas))
                    .put("activity_total_factor", active.score)
                    .put("sleep_hr_bpm", hrValue)
                    .put("sleep_rmssd_ms", hrvValue)
                    .put("sleep_hr_baseline_bpm", hrBaseline)
                    .put("sleep_rmssd_baseline_ms", hrv.baseline)
                    .put(
                        "sleep_hr_daily_means",
                        JSONObject(hrHistory.mapKeys { it.key.toString() }),
                    )
                    .put(
                        "sleep_rmssd_daily_means",
                        JSONObject(hrvHistory.mapKeys { it.key.toString() }),
                    )
                    .put(
                        "active_time_ms",
                        JSONObject(
                            activity
                                .filterKeys { it in date.minusDays(28)..date.minusDays(1) }
                                .mapKeys { it.key.toString() }
                        ),
                    )
                    .put("sleep_selection", "explicit_is_nap_else_longest_non_manual_per_wake_date")
                    .put("activity_input", "day_summary_active_time_only")
                    .put("activity_missing_days", "algorithm_zero_load")
                    .put("physiology_input", "retained_intervals_overlapping_non_nap_sleep")
                    .put("physiology_baseline_days", 7)
                    .put("skin_temperature_used", false)
                    .put("official_equivalence_verified", false)
            Result(date, main.deviceUuid, values, inputs)
        }
    }

    private fun available(value: Float): Any =
        if (value.isFinite() && value != -1f) value else JSONObject.NULL

    fun grade(value: Float): Float =
        map(value, floatArrayOf(1f, 70f, 80f, 90f, 100f), floatArrayOf(1f, 60f, 75f, 85f, 100f))

    fun ungrade(value: Float): Float =
        map(value, floatArrayOf(1f, 60f, 75f, 85f, 100f), floatArrayOf(1f, 70f, 80f, 90f, 100f))

    private fun map(value: Float, from: FloatArray, to: FloatArray): Float {
        if (!value.isFinite() || value == -1f) return -1f
        if (value < 1) return 1f
        for (i in 0 until from.lastIndex) if (value in from[i]..from[i + 1])
            return to[i] + (to[i + 1] - to[i]) * ((value - from[i]) / (from[i + 1] - from[i]))
        return -1f
    }

    fun total(activity: Float, hr: Float, hrv: Float, sleep: Float): Float? {
        val factors = listOf(activity, hr, hrv, sleep)
        if (factors.any { !it.isFinite() || it !in 1f..100f }) return null
        return grade(
                ungrade(activity) * .19f +
                    ungrade(hr) * .31f +
                    ungrade(hrv) * .13f +
                    ungrade(sleep) * .37f
            )
            .takeIf { it in 1f..100f }
    }

    fun napBonus(score: Float, recovery: Float): Float =
        ((1f - exp(recovery.coerceIn(0f, 10f) * -.5f)) * 10f * log10(101f - score) * .5f).coerceIn(
            0f,
            10f,
        )

    fun ema(values: List<Float>, days: Int, female: Boolean): Float {
        val alpha = 2f / (days + 1f)
        return values.fold(if (female) 8.95f else 10.45f) { acc, value ->
            value * alpha + (1f - alpha) * acc
        }
    }

    private fun ratioScore(ratio: Float): Float =
        grade(if (ratio in (-2f / 3f)..(8f / 3f)) 100f - 60f * abs(ratio - 1f) else 0f)

    fun activityFactors(
        activeMillis: Map<LocalDate, Long>,
        date: LocalDate,
        female: Boolean,
    ): ActivityFactors? {
        val yesterday = activeMillis[date.minusDays(1)]?.takeIf { it > 0L } ?: return null
        val loads =
            (28L downTo 1L).map { days ->
                ((activeMillis[date.minusDays(days)] ?: 0L) / 60_000L) * .083333336f
            }
        val baseline = ema(loads, 28, female)
        val shortTerm = ema(loads, 7, female)
        val previousScore = ratioScore(loads.last() / baseline)
        val balance = shortTerm / baseline
        val balanceScore = ratioScore(balance)
        return ActivityFactors(
            (previousScore + balanceScore) / 2f,
            previousScore,
            yesterday,
            shortTerm,
            baseline,
            balance,
            balanceScore,
        )
    }

    fun activityScore(
        activeMillis: Map<LocalDate, Long>,
        date: LocalDate,
        female: Boolean,
    ): Float? = activityFactors(activeMillis, date, female)?.score

    private fun hrPrior(age: Int, female: Boolean): Float =
        when {
            female && age < 40 -> 77.5f
            female && age < 60 -> 74.5f
            female -> 73.5f
            age < 60 -> 72f
            else -> 70.5f
        }

    fun heartRateScore(ratio: Float): Float =
        grade(
            when {
                ratio >= .1f && ratio < .9f -> ratio * 100f - 10f
                ratio >= .9f && ratio < .95f -> ratio * -100f + 190f
                ratio >= .95f && ratio < 1.1f -> ratio * -200f + 285f
                ratio >= 1.1f && ratio < 1.75f -> ratio * -100f + 175f
                else -> 0f
            }
        )

    fun hrvFactors(value: Float, history: List<Float>, age: Int, female: Boolean): HrvFactors {
        require(value > 0f && value.isFinite())
        val prior =
            when {
                female && age < 35 -> 3.76f
                female && age < 45 -> 3.57f
                female && age < 55 -> 3.27f
                female && age < 65 -> 3.06f
                female -> 2.95f
                age < 35 -> 3.68f
                age < 45 -> 3.47f
                age < 55 -> 3.14f
                age < 65 -> 2.99f
                else -> 2.95f
            }
        val valid = history.filter { it > 0f && it.isFinite() }
        val baselineLog =
            if (valid.size <= 1) (prior + ln(value)) / 2f
            else valid.map { ln(it) }.average().toFloat()
        val baseline = exp(baselineLog)
        val ratio = ln(value) / baselineLog
        val penalty = valid.size > 1 && baseline < 19f
        fun score(floor: Float): Float {
            val raw =
                when {
                    ratio !in .75f..1.6666666f -> 0f
                    ratio < 1f -> 400f * ratio - 300f
                    else -> -150f * ratio + 250f
                }
            return grade(maxOf(raw - floor, 1f))
        }
        return HrvFactors(
            score(if (penalty) 20f else 0f),
            value,
            ratio,
            score(0f),
            baseline,
            penalty,
        )
    }

    private fun stableHeartRateTime(samples: List<Interval>, sleeps: List<Sleep>): Float {
        var duration = 0L
        var minimum = Float.POSITIVE_INFINITY
        var offset = -1L
        for (sleep in sleeps.sortedBy { it.start }) {
            val point =
                samples
                    .filter { it.start >= sleep.start && it.start < sleep.end }
                    .minByOrNull { it.value }
            if (point != null && point.value < minimum) {
                minimum = point.value
                offset = duration + point.start - sleep.start
            }
            duration += sleep.end - sleep.start
        }
        return if (offset >= 0 && duration > 0) offset.toFloat() / duration else -1f
    }

    private fun bucket(value: Float, ranges: List<Triple<Float, Float, Int>>): Float {
        if (!value.isFinite() || value == -1f) return -1f
        val range =
            ranges.firstOrNull { value in minOf(it.first, it.second)..maxOf(it.first, it.second) }
                ?: return -1f
        val (lower, upper) =
            when (range.third) {
                1 -> 90f to 100f
                2 -> 80f to 90f
                3 -> 70f to 80f
                else -> 0f to 70f
            }
        return grade(
            lower + (upper - lower) * ((value - range.first) / (range.second - range.first))
        )
    }

    fun sleepFactors(sleeps: List<Sleep>, date: LocalDate): SleepFactors? {
        val staged =
            sleeps
                .filter { it.date in date.minusDays(6)..date && it.stages.isNotEmpty() }
                .sortedBy { it.localStart }
        val main = staged.filter { it.date == date && !it.isNap }
        if (main.isEmpty()) return null
        val mainDates = staged.filterNot { it.isNap }.map { it.date }.toSet()
        val selected = staged.filter { it.date in mainDates }
        val base = selected.filter { it.date != date } + main
        val baseScore = sleepReserveScore(base)
        var withNaps = base
        var previous = baseScore
        val deltas =
            selected
                .filter { it.date == date && it.isNap }
                .map { nap ->
                    withNaps = withNaps + nap
                    val next = sleepReserveScore(withNaps)
                    (next - previous).also { previous = next }
                }
        val durations =
            selected
                .groupBy { it.date }
                .mapValues { (_, day) ->
                    day.sumOf { Duration.between(it.localStart, it.localEnd).toMillis() }
                }
        val mean = durations.values.average().toLong()
        val hours = durations.values.map { it / 3_600_000f }
        val meanHours = hours.average()
        val sd =
            if (durations.keys.any { it != date })
                sqrt(hours.sumOf { (it - meanHours) * (it - meanHours) } / hours.size).toFloat()
            else -1f
        val timing = main.minOf { it.localStart }.let { it.hour + it.minute / 60f }
        val mainHours =
            main.sumOf { Duration.between(it.localStart, it.localEnd).toMillis() } / 3_600_000f
        val penalty =
            when {
                mainHours > 11 -> 30f
                mainHours > 10 -> 20f
                mainHours > 9 -> 10f
                else -> 0f
            }
        val regularity = sleepRegularity(staged.filterNot { it.isNap })
        return SleepFactors(
            grade(maxOf(baseScore - penalty, 1f)),
            mean,
            bucket(
                mean / 60_000f,
                listOf(
                    Triple(420f, 480f, 1),
                    Triple(540f, 480f, 1),
                    Triple(360f, 420f, 2),
                    Triple(600f, 540f, 2),
                    Triple(300f, 360f, 3),
                    Triple(660f, 600f, 3),
                    Triple(0f, 300f, 4),
                    Triple(1440f, 660f, 4),
                ),
            ),
            sd,
            if (sd == -1f) -1f
            else
                bucket(
                    sd.coerceIn(0f, 12f),
                    listOf(
                        Triple(1.07f, 0f, 1),
                        Triple(2.67f, 1.07f, 2),
                        Triple(4.81f, 2.67f, 3),
                        Triple(12f, 4.81f, 4),
                    ),
                ),
            timing,
            bucket(
                timing,
                listOf(
                    Triple(23f, 24.5f, 1),
                    Triple(.5f, -1f, 1),
                    Triple(2f, .5f, 1),
                    Triple(21f, 23f, 2),
                    Triple(4f, 2f, 2),
                    Triple(20f, 21f, 3),
                    Triple(7f, 4f, 3),
                    Triple(13.5f, 7f, 4),
                    Triple(13.5f, 20f, 4),
                ),
            ),
            regularity,
            if (regularity == -1f) -1f
            else
                bucket(
                    regularity.coerceIn(0f, 100f),
                    listOf(
                        Triple(74.91f, 100f, 1),
                        Triple(60.68f, 74.91f, 2),
                        Triple(43.22f, 60.68f, 3),
                        Triple(0f, 43.22f, 4),
                    ),
                ),
            deltas,
        )
    }

    fun sleepRegularity(sleeps: List<Sleep>): Float {
        if (sleeps.isEmpty()) return -1f
        val dates = sleeps.map { it.date }.distinct().sorted()
        if (dates.size < 2) return -1f
        val first = dates.first()
        val last = dates.last()
        val dayCount = ChronoUnit.DAYS.between(first, last).toInt() + 1
        val flags = List(dayCount) { BooleanArray(1440) }
        for (sleep in sleeps) {
            var minute = sleep.localStart
            val count = Duration.between(sleep.localStart, sleep.localEnd).toMinutes()
            repeat(count.toInt() + 1) {
                val index = ChronoUnit.DAYS.between(first, minute.toLocalDate()).toInt()
                if (index in flags.indices) flags[index][minute.hour * 60 + minute.minute] = true
                minute = minute.plusMinutes(1)
            }
        }
        var equal = 0L
        for ((a, b) in dates.zipWithNext()) {
            val previous = flags[ChronoUnit.DAYS.between(first, a).toInt()]
            val next = flags[ChronoUnit.DAYS.between(first, b).toInt()]
            for (minute in 0 until 1440) if (previous[minute] == next[minute]) equal++
        }
        return (200f / ((dates.size - 1) * 1440f)) * equal - 100f
    }

    fun sleepScore(sleeps: List<Sleep>): Float =
        sleeps.maxOfOrNull { it.date }?.let { sleepFactors(sleeps, it)?.score } ?: -1f

    private fun sleepReserveScore(sleeps: List<Sleep>): Float {
        if (sleeps.isEmpty()) return -1f
        var reserve = 2654f
        var stamp = sleeps.first().date.minusDays(1).atTime(9, 15)
        sleeps.forEachIndexed { index, session ->
            if (index > 0) {
                val gap = abs(Period.between(session.date, sleeps[index - 1].date).days)
                if (gap > 4) {
                    stamp = session.date.minusDays(1).atTime(9, 15)
                    reserve = 2654f
                } else if (gap > 1) stamp = stamp.plusDays((gap - 1).toLong())
            }
            if (!session.isNap)
                reserve -= Duration.between(stamp, session.localStart).toMillis() / 60_000f * .5f
            session.stages.forEach { (start, end) ->
                val a = start.hour + start.minute / 60f
                val z =
                    end.hour +
                        end.minute / 60f +
                        if (start.dayOfMonth != end.dayOfMonth) 24f else 0f
                val step = (z - a) / 29f
                for (k in 1..29) {
                    val t = a + (k - 1) * step - 18f
                    val circadian =
                        (.5 * cos((t - 3f).toDouble() * 4 * PI / 24) +
                                cos(t.toDouble() * 2 * PI / 24))
                            .toFloat()
                    val rate = minOf((2880f - reserve) * .0026564f - .55f * circadian, 4.4f)
                    val delta = (a + k * step) - (a + (k - 1) * step)
                    reserve = minOf(2880f, reserve + delta * rate * 60f)
                }
            }
            if (!session.isNap) stamp = session.localEnd
        }
        return maxOf(100f - (2880f - reserve) / 7.2f, 0f)
    }
}
