# 健康数据导出与平台迁移

## 范围与格式

设置 → 导出健康数据，可通过系统文件选择器保存 ZIP，也可打开系统分享面板。整个过程在本机执行，不上传服务器。导出覆盖当前设备在手机中已经留存的数据，包括独立保存的手动小睡和本机睡眠分析结果；不能提取尚未同步的手表记录，也不能恢复已由留存策略删除的记录。

当前格式标识为 `galaxy-watch-manager-free.health.v3`。数据包采用固定英文机器字段，界面语言不影响 schema。v2 补齐历史范围、来源与算法、运动关联、独立存储和覆盖信息；v3 将本机睡眠评分改为经原库对照的 1.4.24 夜间算法，增加 `computed_score_algorithm`、更新 `score_source` 枚举并将 `computed_score` 范围收紧为 1–99。读取者必须按 manifest 的 schema 版本选择解析器，旧 v2 的 `computed_v1` 分数与新分数不能混作同一算法序列。

| 文件 | 内容 |
|---|---|
| `schema.json` | JSON 文件的机器可读结构与文件对应关系；CSV 的列与对应 JSON 字段同名 |
| `manifest.json` | schema 版本、导出 UTC 时间、导出时区、设备型号、逐文件 SHA-256、各数据集数量与时间范围、留存和同步边界 |
| `measurements.json` / `.csv` | 全部可解析留存读数：心率、血氧、皮温、呼吸率、HRV、压力、血压和脉搏；保留单位、来源、原记录/修订及可确定的算法 |
| `blood_pressure.json` | 同一记录的收缩压/舒张压，单位 mmHg，脉搏缺失为 null |
| `ecg.json` | ECG 原始记录 ID、UTC 时间、心率、三星分类编码、采样率、样本数和波形文件路径 |
| `ecg/record-N.csv` | 完整波形，每行一个采样点：序号、相对秒数、电压 mV |
| `activity_intervals.json` | 已留存的计步区间及可用的距离/能量，不与逐日汇总重复相加 |
| `daily_activity.json` / `.csv` | 按实际日期的活动汇总；保留来源与覆盖限制，未知值为 null |
| `floors.json` | 已留存的楼层区间与计数，缺失计数不补零 |
| `vascular_load.json` | 血管负荷的测量、基线及重置记录，保留三星类型和原值语义 |
| `workouts.json` | 完整已解析运动字段、起止/有效时长、距离/能量/心率/速度/海拔/次数/来源类型及位置数据可用性；`routine_id` 和 `is_top_level` 保留父子关系 |
| `sleep_sessions.json` | 全部留存的标准化睡眠会话与已有分期，区分手表、手动和本机推理来源；`score` 为手表评分，`computed_score` 为本机计算评分，`computed_score_algorithm` 为评分算法版本，`score_source` 为展示所用来源 |
| `manual_naps.json` | 独立保存的全部手动补记小睡，保留区间与稳定身份 |
| `local_sleep_analysis.json` | 独立保存的全部本机睡眠分析缓存版本，以 `cache_key`、`retained_result` 和可解析的 `session` 保留原结果及来源；不为导出重跑推理 |
| `latest_sleep.json` / `latest_sleep_sessions.json` | 最近展示的主睡眠及该睡眠日全部会话，是完整睡眠历史的相关视图 |
| `sleep_history.json` | 已留存的逐日睡眠分钟数 |
| `heart_rate_daily.json` / `stress_daily.json` | 以已保存实际日期为键的日统计，不按导出日期推算旧周数组的日期 |
| `snapshot.json` | 最近同步时间、目标及带数据日期的摘要；同步状态见 `manifest.sync`，跨日旧数据不冒充今天 |
| `collection_settings.json` | 当前设备采集设置的安全字段，区分已确认值、待确认目标和状态；不包含带设备地址的偏好键 |
| `source_records.json` | 已留存原始模块字段、记录身份及修订信息；包含传感器负载和无法标准化的字段 |
| `retained_cache.json` | 当前设备健康缓存，包括较早汇总、压缩 ECG 和恢复副本 |
| `README.md` | 单位、结构、原始负载、重复统计与平台迁移限制说明 |

JSON 使用 UTF-8；缺失值是 null 或缺少记录，不补出测量值。CSV 使用引号与 CRLF，数值小数点固定为点。ISO 8601 时间为 UTC，epoch 字段为毫秒。`manifest.time_zone` 是导出时的日期解释上下文，不能假定是每次历史测量的原始时区；已有日期键保留其实际日期，不随导出时钟平移。计步日汇总的 `day_time` 支持 `yyyyMMdd`（数值或字符串）、ISO 本地日期和 epoch 毫秒，应用与导出共用日期解析；`update_time` 只表示修订，不作为缺失日期的归属日。

## 解析、关联与覆盖

1. 读取 manifest，按其 schema 版本选择解析器，验证每个列出文件未压缩内容的 SHA-256。manifest 本身不列入自己的摘要。
2. 优先读取标准化文件；原始字段和无法解析的负载保留在 `source_records.json`、缓存文件和独立分析结果中。标准化结果完整覆盖其可解析留存来源，不受首页心率 24 小时或通用指标 7 天显示窗口限制。
3. 测量保留 `source_module`、`source_record_id`、`source_revision_epoch_ms` 和 `source_field` 等来源信息。未知修订或原字段保持 null；稳定 `record_id` 用于归档内关联，未来平台导入仍须按目标 API 实现版本与去重策略。应用指标投影与导出共用修订选择规则：同一模块族的别名记录先按记录身份选择最新整条修订，再展开标准化结果；旧分箱不会混入新修订，原始模块文件仍保留全部留存来源。
4. HRV 的 `method` 明确区分 `rmssd`、`sdnn` 与未知。原记录同时含两种算法时分别保留，不能只取其中一个，更不能把算法未知的旧缓存改称 SDNN 或 RMSSD。
5. 运动父会话与子会话都保留。统计顶层运动时按 `is_top_level` 和 `routine_id` 处理，不能把父会话总量与子项再次相加；未知距离/能量/心率/次数等为 null，真实零值保留。位置可用性不代表已生成可迁移路线，原始位置负载仍在来源文件中。
6. 原始区间、标准化测量、日汇总与最新日视图来自相关数据，不能当成独立事件重复累加。`local_sleep_analysis.json` 保留缓存版本，也不能将每个版本再算作一次睡眠；手动小睡与其 `sleep_sessions.json` 表示同样不能重复累计。
7. ECG 采样时间为 `start_time + time_offset_seconds`；采样率由记录提供，不将所有设备写死为 500 Hz。血压双值共享记录 ID，与 `blood_pressure.json` 是同一读数的表示。
8. `snapshot.json` 的 `data_local_date` 标识步数的数据日期，`data_day_steps` 和 `data_day_floors` 保留数据日数值，楼层日期单独由 `floors_local_date` 标识。`today_local_date` 是导出日；数据日期未知或与导出日不一致时，相应 `today_steps` / `today_floors` 为 null，不能把旧步数或楼层标作今天的测量。
9. 睡眠评分按来源与算法区分：`score` 是手表 `quality`（0–100 或 null），`computed_score` 是本机按 1.4.24 夜间路径计算的总分（1–99 或 null），`computed_score_algorithm` 为 `computed_shealth_1_4_24` 或 null；`score_source` 标识展示来源（`watch` / `computed_shealth_1_4_24` / null）。即使展示手表评分，也保留可计算的本机分数及算法；无完整连续分期时，本机分数和算法均为 null。新算法按导出时所持分期计算，不回写手表，不更改原始 `quality` 或模型缓存原文；`source` 仍标识会话/分期来源，不能与评分算法混淆。以上字段也用于 latest、手动小睡与本机分析的标准化会话表示；快照覆盖和 manifest 的数量/时间范围没有因此缩小。公式与原库验证边界见 [睡眠分析说明](SLEEP-ANALYSIS.md)。

manifest 的 `datasets` 以 JSON 文件名为键，包含 `record_count`、`first_start_time`、`last_end_time`、`first_local_date`、`last_local_date` 和 `coverage=retained_only`；没有可确定的时间或日期范围时为 null。`source_modules` 按原始模块说明 `record_count`、`first_time`、`last_time`、`retention_days`、`record_limit` 和 `previously_truncated=unknown`；`retention_days=null` 表示该模块不按天数裁剪。

`manifest.retention` 包含 `raw_default_days`、`ecg_record_limit`、`bp_record_limit`、`export_applies_additional_trimming=false` 和 `previously_deleted_data=unavailable`，并用 `manual_naps=all_retained`、`local_sleep_analysis=all_retained_versions` 说明独立存储范围。`manifest.sync` 包含 `status`、`last_health_sync_epoch_ms` 和 `historical_completeness=unknown`；`snapshot.json` 只重复最近同步时间，不包含同步状态。

这些数量与范围只描述本包留存内容，不代表手表或健康平台的完整数据库；空数据集不证明手表没有数据。同步状态和最近同步时间也不能证明所有历史都已同步，无法确认的历史裁剪和同步完整性必须保持 unknown。

原始模块通常保留 30 天：心率最多 20,000 条，其他模块最多 8,000 条。运动及血管负荷模块不受上述 30 天时间裁剪，但仍受条数上限约束；ECG/BP 各最多 100 条。导出不再次按界面窗口裁剪。ZIP 是可移植分析数据集，尚未实现恢复进本应用的导入器。

## 隐私与验收

归档不读取配对凭据、通知正文或应用签名私钥；采集设置按明确字段投影，不直接导出包含设备地址的整份偏好文件。健康原始记录及运动负载本身可能含敏感来源或位置信息，不能把归档当成匿名数据集。分享由用户通过系统面板选择，缓存分享文件在下一次分享时清理超过 24 小时的旧文件。

测试和仓库示例只使用合成数据，真实设备标识、通知、联系人、健康截图和真机帧回放不得进入 Git，必要证据放在被忽略的 `private/`。本地测试与构建、系统文件保存/分享、平台写入、远端执行和设备重启后持久化分别验收。2026-11-09 本轮未有在线 ADB 设备，不能据本地验证宣称手机保存/分享或手表持久化已通过。

## Apple HealthKit

Android 不能直接调用 iOS HealthKit。可行路线是保存 ZIP → 传到 iPhone → 由获得用户授权的 iOS 应用解析并写入支持的数据类型；本项目尚未实现或实机验收该 iOS 导入器，本包不能直接导入 Apple Health。

| 数据 | 迁移判断 |
|---|---|
| 血压 | `bloodPressure` correlation 将收缩压和舒张压组合成一条记录；归档保留共同记录 ID |
| 步数、心率、运动、睡眠等 | 导入器须逐项核对类型、单位、权限、来源、录制方式和去重规则 |
| ECG 原始波形 | `HKElectrocardiogramType` 为只读，第三方不能把三星波形保存为 Apple ECG 样本；归档保留 CSV，应用另支持导出 PNG 供查看 |
| HRV | HealthKit 使用 SDNN；不能将 RMSSD 或算法未知的读数写成 SDNN |
| 皮温 | 不能改称核心体温；Apple 的 `appleSleepingWristTemperature` 同样只读，不能直接写入 |
| 压力、血管负荷等厂商指标 | 未建立等价类型映射时保留在归档，迁移时明确跳过 |

未核实到 Health app 可直接导入本项目 ZIP/任意 CSV 的官方入口。Apple 的“导出全部健康数据”描述的是导出，不能反推同结构 XML 可以导回。未来导入器应保留来源、设备、记录身份及修订，并使用目标平台的同步标识与版本实现重复导入和更新。

## Health Connect、华为与荣耀

Android 可按设备与服务条件提供 Health Connect 适配器：它要求 Android 9 或更高版本及 Google Play 服务；Android 14 起为系统组件，较早支持版本通过 Google Play 分发的应用提供。读写仍需要用户授权及可用类型/功能检查。

Health Connect 的 HRV 使用 RMSSD，与 HealthKit 的 SDNN 分开映射；皮温采用其受功能可用性限制的序列/基线模型，不能把任意绝对皮温直接改名写入。缺失值不能写成零，来源、设备、录制方式、`clientRecordId` 和 `clientRecordVersion` 需由适配器正确构造，避免重复导入及把读回的数据循环写入。

Health Connect 可用不等于华为运动健康或荣耀运动健康一定读取它。华为 Health Kit 与荣耀 Health Kit 是独立平台，需要分别申请平台能力/范围并取得用户授权；支持的数据类型和读写方向需逐项验证。写入 API 成功也不能证明厂商应用已展示，或数据已回填到新手表。本项目当前未实现这些平台的写入器，也未进行真实平台写入验收。

## 官方参考

- [Apple：Health 数据分享与导出](https://support.apple.com/guide/iphone/share-your-health-data-iph5ede58c3d/ios)
- [Apple：HealthKit bloodPressure](https://developer.apple.com/documentation/healthkit/hkcorrelationtypeidentifier/bloodpressure)
- [Apple：HKElectrocardiogramType](https://developer.apple.com/documentation/healthkit/hkelectrocardiogramtype)
- [Apple：appleSleepingWristTemperature](https://developer.apple.com/documentation/healthkit/hkquantitytypeidentifier/applesleepingwristtemperature)
- [Apple WWDC19：Exploring New Data Representations in HealthKit](https://developer.apple.com/videos/play/wwdc2019/218/)
- [Apple：HealthKit metadata keys](https://developer.apple.com/documentation/healthkit/metadata-keys)
- [Android：Health Connect 数据类型](https://developer.android.com/health-and-fitness/health-connect/data-types)
- [Android：Health Connect 可用性](https://developer.android.com/health-and-fitness/health-connect/availability)
- [Android：Health Connect 写入数据](https://developer.android.com/health-and-fitness/health-connect/write-data)
- [华为：Health Kit](https://developer.huawei.com/consumer/cn/hms/huaweihealth/)
- [华为：应用接入流程](https://developer.huawei.com/consumer/cn/doc/hmscore-guides/application-access-process-0000001611092953/)
- [荣耀：Health Kit 介绍](https://developer.honor.com/cn/docs/11005/guides/introduction)
- [荣耀：Health Kit 授权范围](https://developer.honor.com/cn/docs/11005/guides/scope)
- [荣耀：Android 健康采样数据写入](https://developer.honor.com/cn/docs/11005/guides/code-guide/android/healthsampling)
- [Android：共享媒体存储](https://developer.android.com/training/data-storage/shared/media)

## ECG 图片

以原始采样率绘制完整记录，每行 5 秒，包含时间、记录 ID、手表分类与数值网格说明。相册导出与屏幕滚动位置无关。网格按数值标定，不能把手机图片显示尺寸当作实际毫米。生成过程限定最大图像像素数，异常或保存失败会删除未完成的 MediaStore 条目。

公开构建默认携带睡眠 DEX、模型与 ARM64/ARMv7 JNI，从已收到的 version=2 原始传感器数据生成本机分期，缺失原始数据时保留现有回补入口。已经收到的分期优先；手动小睡、全部已留存原始记录与所有本机分析缓存版本均纳入快照和导出，推理结果保留 `local_sensor_v1` 来源，不冒充手表记录。此次恢复没有改变 `HealthExportSnapshot`、独立缓存格式、原始/标准化字段、JSON Schema、manifest 数量口径或留存范围，沿用 v3 导出契约；导出仍不触发推理，也不受首页或图表窗口限制。

## 开发联动约束

健康模块、数据模型、字段、持久化、派生统计、留存或采集设置变更，必须在同一变更中检查并同步快照、原始与标准化导出、schema、manifest、嵌入说明、本文档及回归测试。具体规则见根目录 [AGENTS.md](../AGENTS.md) 和 [CONTRIBUTING.md](../CONTRIBUTING.md)。

2026-11-09 的健康报文管线重构已核对 `HealthExportSnapshot`、手动小睡/本机分析独立存储、原始/标准化归档、schema 与 manifest：本次仅集中报文处理顺序与 ACK 决策，沿用全部缓存键、记录投影、留存与导出字段，格式仍为 v2；导出回归随完整 JVM 测试执行。

2026-11-13 的健康投影修复统一应用与导出的整条修订选择和实际日期解析，区分今日楼层未知与有效零值，并显式传递小时分布的时钟。已核对 `HealthExportSnapshot`、手动小睡/本机分析独立存储、原始与标准化归档、schema、manifest 和嵌入 README：未新增字段或存储、未改变留存范围，格式保持 v3；楼层缺失为 null、来源与修订信息、全部留存历史的既有导出契约保持不变。新增合成回归从 `HealthRecordStore` 到 `HealthArchive.write` 的实际入口覆盖别名修订、日期、未知/零值和较早历史。
