#!/usr/bin/env python3
"""Generate a validated policy.json for remote force-update or app discontinuation.

Upload the generated policy.json to the root of `crossly/galaxy-watch-manager-free-feed`
(`main` branch). Clients check `policy.json` asynchronously and strictly fail-open on
timeouts, network failures, 404, or malformed payloads.

Examples:
    # Normal (no block):
    python3 scripts/write-update-policy.py policy.json --mode none

    # Force-update all versions older than 0.0.44 (version_code 44000):
    python3 scripts/write-update-policy.py policy.json \\
        --mode force_update --min-version-code 44000 --target-version-name 0.0.44 \\
        --message-zh "修复了重要问题，请更新后继续使用。"

    # Emergency app discontinuation / kill-switch for all versions:
    python3 scripts/write-update-policy.py policy.json \\
        --mode block \\
        --title-zh "应用已下架" --message-zh "因故暂停服务，感谢支持。" \\
        --action-url "https://github.com/crossly/galaxy-watch-manager-free-feed"
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
from urllib.parse import urlparse

SCHEMA_VERSION = 1
EXPECTED_PACKAGE = "dev.ricky.galaxywatchmanagerfree"
VALID_MODES = ("none", "force_update", "block")
TRUSTED_HOSTS = {"github.com", "raw.githubusercontent.com"}


def validate_action_url(url: str | None) -> str | None:
    if url is None:
        return None
    cleaned = url.strip()
    if not cleaned:
        return None
    parsed = urlparse(cleaned)
    if parsed.scheme.lower() != "https" or (parsed.hostname or "").lower() not in TRUSTED_HOSTS:
        raise SystemExit(
            f"Unsupported --action-url {cleaned!r}: must use https:// on {sorted(TRUSTED_HOSTS)}"
        )
    return cleaned


def build_policy(
    mode: str,
    *,
    min_version_code: int = 0,
    blocked_version_codes: list[int] | None = None,
    target_version_name: str | None = None,
    target_version_code: int | None = None,
    title: str | None = None,
    title_zh: str | None = None,
    message: str | None = None,
    message_zh: str | None = None,
    action_url: str | None = None,
    updated_at: str | None = None,
) -> dict:
    if mode not in VALID_MODES:
        raise SystemExit(f"Invalid mode {mode!r}; expected one of {VALID_MODES}")
    if min_version_code < 0:
        raise SystemExit("--min-version-code must be >= 0")
    codes = sorted({c for c in (blocked_version_codes or []) if c > 0})
    if any(c <= 0 for c in (blocked_version_codes or [])):
        raise SystemExit("--block-version-code values must be positive integers")
    if mode == "force_update" and min_version_code <= 0 and not codes:
        raise SystemExit(
            "mode=force_update requires --min-version-code > 0 or at least one --block-version-code"
        )
    if target_version_code is not None and target_version_code <= 0:
        raise SystemExit("--target-version-code must be > 0")
    clean_target_name = (
        target_version_name.strip().lstrip("vV") if target_version_name and target_version_name.strip() else None
    )
    return {
        "schema_version": SCHEMA_VERSION,
        "package": EXPECTED_PACKAGE,
        "mode": mode,
        "min_supported_version_code": min_version_code,
        "blocked_version_codes": codes,
        "target_version_name": clean_target_name,
        "target_version_code": target_version_code,
        "title": title.strip()[:200] if title and title.strip() else None,
        "title_zh": title_zh.strip()[:200] if title_zh and title_zh.strip() else None,
        "message": message.strip()[:2000] if message and message.strip() else None,
        "message_zh": message_zh.strip()[:2000] if message_zh and message_zh.strip() else None,
        "action_url": validate_action_url(action_url),
        "updated_at": updated_at or datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    parser.add_argument("--mode", required=True, choices=VALID_MODES)
    parser.add_argument("--min-version-code", type=int, default=0)
    parser.add_argument("--block-version-code", type=int, action="append", default=[])
    parser.add_argument("--target-version-name", default=None)
    parser.add_argument("--target-version-code", type=int, default=None)
    parser.add_argument("--title", default=None)
    parser.add_argument("--title-zh", default=None)
    parser.add_argument("--message", default=None)
    parser.add_argument("--message-zh", default=None)
    parser.add_argument("--action-url", default=None)
    args = parser.parse_args()

    payload = build_policy(
        args.mode,
        min_version_code=args.min_version_code,
        blocked_version_codes=args.block_version_code,
        target_version_name=args.target_version_name,
        target_version_code=args.target_version_code,
        title=args.title,
        title_zh=args.title_zh,
        message=args.message,
        message_zh=args.message_zh,
        action_url=args.action_url,
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"wrote {args.output} (mode={payload['mode']})")


if __name__ == "__main__":
    main()
