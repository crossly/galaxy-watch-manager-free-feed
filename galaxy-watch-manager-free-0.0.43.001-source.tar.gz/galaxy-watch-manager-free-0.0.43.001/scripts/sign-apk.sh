#!/usr/bin/env bash
# The same script signs locally and in Actions. Secrets are passed via the environment.
set -euo pipefail
cd "$(dirname "$0")/.."
: "${RELEASE_KEYSTORE:?Set RELEASE_KEYSTORE to the keystore path}"
: "${RELEASE_KEYSTORE_PASSWORD:?Missing store password}"
: "${RELEASE_KEY_ALIAS:?Missing key alias}"
: "${RELEASE_KEY_PASSWORD:?Missing key password}"
version="$(python3 scripts/version.py show)"
# 发布者证书的 SHA-256 指纹；换错密钥或他人签名的 APK 必须在此失败。
expected_fingerprint="86de4a33245393411b43ad0d4fa99233f0ca6f926cef6f60982eac9eba3f1525"
sdk_path="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
if [[ -z "$sdk_path" && -f local.properties ]]; then
  sdk_path="$(python3 -c 'from pathlib import Path; print(next((line.split("=",1)[1] for line in Path("local.properties").read_text().splitlines() if line.startswith("sdk.dir=")), ""))')"
fi
sdk_path="${sdk_path:-$HOME/Library/Android/sdk}"
build_tools="$sdk_path/build-tools/35.0.0"
unsigned="app/build/outputs/apk/release/app-release-unsigned.apk"
mkdir -p artifacts
aligned="artifacts/aligned.apk"
output="artifacts/galaxy-watch-manager-free-${version}.apk"
"$build_tools/zipalign" -f -p 4 "$unsigned" "$aligned"
"$build_tools/apksigner" sign \
  --ks "$RELEASE_KEYSTORE" \
  --ks-pass env:RELEASE_KEYSTORE_PASSWORD \
  --ks-key-alias "$RELEASE_KEY_ALIAS" \
  --key-pass env:RELEASE_KEY_PASSWORD \
  --out "$output" "$aligned"
cert_output="$("$build_tools/apksigner" verify --verbose --print-certs "$output")"
printf '%s\n' "$cert_output"
cert_digests="$(printf '%s\n' "$cert_output" | sed -n 's/^Signer #[0-9][0-9]* certificate SHA-256 digest: //p')"
[[ -n "$cert_digests" ]] || {
  echo "apksigner printed no certificate SHA-256 digest." >&2
  exit 1
}
while read -r digest; do
  if [[ "$digest" != "$expected_fingerprint" ]]; then
    echo "Unexpected certificate SHA-256 digest: $digest (expected $expected_fingerprint)." >&2
    exit 1
  fi
done <<<"$cert_digests"
rm -f "$aligned"
python3 - "$output" <<'PY'
from pathlib import Path
import hashlib, sys
p = Path(sys.argv[1])
p.with_suffix('.apk.sha256').write_text(hashlib.sha256(p.read_bytes()).hexdigest() + '  ' + p.name + '\n')
PY
printf 'Signed APK: %s\n' "$output"
