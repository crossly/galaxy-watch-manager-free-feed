import importlib.util
import json
from pathlib import Path
import unittest

spec = importlib.util.spec_from_file_location(
    "write_update_policy", Path(__file__).resolve().parents[1] / "write-update-policy.py"
)
policy_mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(policy_mod)


class WriteUpdatePolicyTests(unittest.TestCase):
    def test_none_policy_shape(self):
        entry = policy_mod.build_policy("none", updated_at="2026-11-25T12:00:00+00:00")
        self.assertEqual(1, entry["schema_version"])
        self.assertEqual("dev.ricky.galaxywatchmanagerfree", entry["package"])
        self.assertEqual("none", entry["mode"])
        self.assertEqual(0, entry["min_supported_version_code"])
        self.assertEqual([], entry["blocked_version_codes"])
        self.assertIsNone(entry["action_url"])

    def test_force_update_requires_threshold_or_blocked_codes(self):
        with self.assertRaises(SystemExit):
            policy_mod.build_policy("force_update")

        by_min = policy_mod.build_policy(
            "force_update",
            min_version_code=44000,
            target_version_name="v0.0.44",
            target_version_code=44000,
            message_zh="修复重要问题",
        )
        self.assertEqual("force_update", by_min["mode"])
        self.assertEqual(44000, by_min["min_supported_version_code"])
        self.assertEqual("0.0.44", by_min["target_version_name"])
        self.assertEqual("修复重要问题", by_min["message_zh"])

        by_list = policy_mod.build_policy(
            "force_update",
            blocked_version_codes=[43000, 42000, 43000],
        )
        self.assertEqual([42000, 43000], by_list["blocked_version_codes"])

    def test_block_allows_full_kill_switch_without_version_filters(self):
        entry = policy_mod.build_policy(
            "block",
            title_zh="应用已下架",
            message_zh="暂停服务",
            action_url="https://github.com/crossly/galaxy-watch-manager-free-feed",
        )
        self.assertEqual("block", entry["mode"])
        self.assertEqual(0, entry["min_supported_version_code"])
        self.assertEqual([], entry["blocked_version_codes"])
        self.assertEqual(
            "https://github.com/crossly/galaxy-watch-manager-free-feed", entry["action_url"]
        )
        self.assertIn("应用已下架", json.dumps(entry, ensure_ascii=False))

    def test_rejects_untrusted_action_urls(self):
        for bad in [
            "http://github.com/crossly/galaxy-watch-manager-free-feed",
            "https://evil.example/phish",
            "https://github.com.evil.example/feed",
            "javascript:alert(1)",
        ]:
            with self.assertRaises(SystemExit):
                policy_mod.build_policy("block", action_url=bad)


if __name__ == "__main__":
    unittest.main()
