#!/usr/bin/env python3
"""Extract release notes and audit Nightly coverage for stable releases."""
from __future__ import annotations

import argparse
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
NOTES = ROOT / "docs/RELEASE-NOTES.md"
HEADING = re.compile(r"^##\s+(0\.0\.\d+(?:\.\d{3})?)(?:\s+Nightly)?\s*$")
STABLE = re.compile(r"^0\.0\.(\d+)$")
NIGHTLY = re.compile(r"^0\.0\.(\d+)\.(\d{3})$")


def parse_sections(text: str) -> list[tuple[str, str, str]]:
    lines = text.splitlines()
    headings: list[tuple[int, str, str]] = []
    for index, line in enumerate(lines):
        match = HEADING.match(line)
        if match is not None:
            headings.append((index, match.group(1), line.strip()))
    sections: list[tuple[str, str, str]] = []
    for position, (start, name, heading) in enumerate(headings):
        end = headings[position + 1][0] if position + 1 < len(headings) else len(lines)
        sections.append((name, heading, "\n".join(lines[start + 1 : end]).strip("\n")))
    return sections


def extract(text: str, version: str) -> str:
    matches = [(heading, body) for name, heading, body in parse_sections(text) if name == version]
    if len(matches) != 1:
        raise SystemExit(
            f"Expected exactly one release-notes section for {version}, found {len(matches)}"
        )
    heading, body = matches[0]
    if not body:
        raise SystemExit(f"Release-notes section for {version} is empty")
    return f"{heading}\n\n{body}\n"


def previous_stable_prefix(stable_version: str) -> str:
    match = STABLE.fullmatch(stable_version)
    if match is None:
        raise SystemExit(f"Expected a stable version 0.0.N, got {stable_version!r}")
    previous = int(match.group(1)) - 1
    if previous < 1:
        raise SystemExit(f"{stable_version} has no previous stable line")
    return f"0.0.{previous}."


def collect_nightlies(text: str, stable_version: str) -> str:
    prefix = previous_stable_prefix(stable_version)
    sections = [
        (name, heading, body)
        for name, heading, body in parse_sections(text)
        if NIGHTLY.fullmatch(name) and name.startswith(prefix) and body
    ]
    if not sections:
        raise SystemExit(f"No Nightly sections found under {prefix}x for {stable_version}")
    sections.sort(key=lambda item: int(item[0].rsplit(".", 1)[1]))
    return "\n\n".join(f"{heading}\n\n{body}" for _, heading, body in sections) + "\n"


def missing_nightly_sections(text: str, stable_version: str, tags: list[str]) -> list[str]:
    prefix = previous_stable_prefix(stable_version)
    pattern = re.compile(rf"^v{re.escape(prefix)}\d{{3}}$")
    expected = sorted(tag[1:] for tag in tags if pattern.fullmatch(tag))
    documented = {name for name, _, _ in parse_sections(text) if NIGHTLY.fullmatch(name)}
    return [version for version in expected if version not in documented]


def git_tags() -> list[str]:
    result = subprocess.run(
        ["git", "-C", str(ROOT), "tag", "--list"], check=True, capture_output=True, text=True
    )
    return result.stdout.splitlines()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tag", default=os.environ.get("RELEASE_TAG", ""), help="release tag, e.g. v0.0.35.005")
    parser.add_argument("--notes", type=Path, default=NOTES, help="release-notes Markdown file")
    parser.add_argument("--output", type=Path, help="write the extracted section here instead of stdout")
    parser.add_argument("--check", action="store_true", help="only verify that the section exists")
    parser.add_argument(
        "--collect-nightlies",
        action="store_true",
        help="print all Nightly sections from the previous stable line of a stable tag",
    )
    parser.add_argument(
        "--check-nightlies",
        action="store_true",
        help="verify every Nightly tag under the previous stable line has a release-notes section",
    )
    parser.add_argument(
        "--tags",
        help="newline-separated tag list for --check-nightlies (default: git tag --list)",
    )
    args = parser.parse_args()

    if re.fullmatch(r"v0\.0\.\d+(?:\.\d{3})?", args.tag) is None:
        raise SystemExit(f"Invalid release tag: {args.tag!r}")
    text = args.notes.read_text()
    version = args.tag[1:]
    if args.collect_nightlies:
        sys.stdout.write(collect_nightlies(text, version))
        return
    if args.check_nightlies:
        tags = args.tags.splitlines() if args.tags is not None else git_tags()
        missing = missing_nightly_sections(text, version, tags)
        if missing:
            raise SystemExit(
                "Missing release-notes sections for Nightly tags: " + ", ".join(missing)
            )
        print(f"{args.tag} Nightly coverage OK for {previous_stable_prefix(version)}x")
        return

    section = extract(text, version)
    if args.check:
        print(f"{args.tag} release notes found ({len(section.encode('utf-8'))} bytes)")
    elif args.output is not None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(section)
        print(f"wrote {args.output} for {args.tag}")
    else:
        sys.stdout.write(section)


if __name__ == "__main__":
    main()
