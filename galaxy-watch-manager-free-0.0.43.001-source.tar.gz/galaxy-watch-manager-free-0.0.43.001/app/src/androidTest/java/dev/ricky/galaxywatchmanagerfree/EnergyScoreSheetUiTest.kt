package dev.ricky.galaxywatchmanagerfree

import android.content.Context
import android.content.res.Configuration
import android.os.LocaleList
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsEnabled
import androidx.compose.ui.test.assertIsNotEnabled
import androidx.compose.ui.test.assertTextEquals
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performTextClearance
import androidx.compose.ui.test.performTextInput
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.test.core.app.ApplicationProvider
import dev.ricky.galaxywatchmanagerfree.feature.EnergyScoreCalculation
import dev.ricky.galaxywatchmanagerfree.feature.EnergyScoreLog
import dev.ricky.galaxywatchmanagerfree.feature.EnergyScoreProfile
import dev.ricky.galaxywatchmanagerfree.feature.WatchState
import dev.ricky.galaxywatchmanagerfree.ui.screens.EnergyScoreSheet
import dev.ricky.galaxywatchmanagerfree.ui.theme.WatchFreeTheme
import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test

/** Synthetic fixtures render only inside this test; no readings are saved or sent. */
class EnergyScoreSheetUiTest {
    @get:Rule val compose = createComposeRule()

    @Composable
    private fun TestLayout(tag: String = "zh-CN", content: @Composable () -> Unit) {
        val app = ApplicationProvider.getApplicationContext<Context>()
        val configuration =
            Configuration(app.resources.configuration).apply {
                setLocales(LocaleList.forLanguageTags(tag))
            }
        val localized = app.createConfigurationContext(configuration)
        val density = LocalDensity.current.density
        CompositionLocalProvider(
            LocalContext provides localized,
            LocalConfiguration provides configuration,
            LocalDensity provides Density(density, 1f),
        ) {
            WatchFreeTheme(darkTheme = false) { Box(Modifier.width(360.dp)) { content() } }
        }
    }

    @Test
    fun savingProfileSwitchesToSavedSummaryAndDisplaysSavedValues() {
        var state by mutableStateOf(WatchState())
        var savedInput: Pair<Int, Boolean>? = null
        compose.setContent {
            TestLayout("zh-CN") {
                EnergyScoreSheet(
                    state = state,
                    onDismiss = {},
                    onSaveProfile = { age, female ->
                        savedInput = age to female
                        state = state.copy(energyProfile = EnergyScoreProfile(age, female))
                        true
                    },
                    onCalculate = { _, _ -> EnergyScoreCalculation(0, 0) },
                    onWrite = { false },
                )
            }
        }

        compose.onNodeWithTag("energy_score_profile_editor").assertIsDisplayed()
        compose.onNodeWithTag("energy_score_age").performTextInput("15")
        compose.onNodeWithText("请输入 18 至 99 之间的整数。").assertIsDisplayed()
        compose.onNodeWithTag("energy_score_profile_save").assertIsNotEnabled()

        compose.onNodeWithTag("energy_score_age").performTextClearance()
        compose.onNodeWithTag("energy_score_age").performTextInput("32")
        compose.onNodeWithTag("energy_score_sex_male").performClick()
        compose.onNodeWithTag("energy_score_profile_save").assertIsEnabled().performClick()

        compose.waitForIdle()
        assertEquals(32 to false, savedInput)
        compose.onNodeWithTag("energy_score_profile_summary").assertIsDisplayed()
        compose.onNodeWithTag("energy_score_saved_age").assertTextEquals("32 岁")
        compose.onNodeWithTag("energy_score_saved_sex").assertTextEquals("男性")
    }

    @Test
    fun savedProfileDisplaysScoreAndSupportsEditingAndCancel() {
        val record =
            EnergyScoreLog.Record(
                id = "rec-1",
                date = "2026-11-24",
                zoneId = "UTC",
                algorithm = "phone_vitality_v1",
                createdAt = 1_000L,
                updatedAt = 2_000L,
                deviceUuid = "synthetic-watch",
                values =
                    """{"total_score":86.4,"sleep_score":88.0,"activity_score":82.0,"shr_score":85.0,"shrv_score":84.0}""",
                inputs = """{"profile_age":29,"profile_sex":"F"}""",
            )
        val state =
            WatchState(energyProfile = EnergyScoreProfile(29, true), energyScores = listOf(record))
        compose.setContent {
            TestLayout("zh-CN") {
                EnergyScoreSheet(
                    state = state,
                    onDismiss = {},
                    onSaveProfile = { _, _ -> true },
                    onCalculate = { _, _ -> EnergyScoreCalculation(1, 0) },
                    onWrite = { false },
                    today = LocalDate.of(2026, 11, 24),
                )
            }
        }

        compose.onNodeWithTag("energy_score_value").assertTextEquals("86")
        compose.onNodeWithTag("energy_score_profile_summary").assertIsDisplayed()
        compose.onNodeWithTag("energy_score_saved_age").assertTextEquals("29 岁")
        compose.onNodeWithTag("energy_score_saved_sex").assertTextEquals("女性")

        compose.onNodeWithTag("energy_score_profile_edit").performClick()
        compose.onNodeWithTag("energy_score_profile_editor").assertIsDisplayed()
        compose.onNodeWithTag("energy_score_profile_current").assertTextEquals("当前已保存：29 岁 · 女性")
        compose.onNodeWithText("取消").performClick()
        compose.onNodeWithTag("energy_score_profile_summary").assertIsDisplayed()
    }

    @Test
    fun pastDateShowsWatchTodayNoticeAndPersistedAckStatus() {
        val record =
            EnergyScoreLog.Record(
                id = "rec-yesterday",
                date = "2026-11-24",
                zoneId = "UTC",
                algorithm = "phone_vitality_v1",
                createdAt = 1_000L,
                updatedAt = 2_000L,
                deviceUuid = "synthetic-watch",
                values =
                    """{"total_score":92.0,"sleep_score":95.2,"activity_score":78.6,"shr_score":91.5,"shrv_score":91.7}""",
                inputs = """{"profile_age":33,"profile_sex":"M"}""",
                acceptedRevision = 2_000L,
                acceptedAt = 3_000L,
            )
        val state =
            WatchState(energyProfile = EnergyScoreProfile(33, false), energyScores = listOf(record))
        compose.setContent {
            TestLayout("zh-CN") {
                EnergyScoreSheet(
                    state = state,
                    onDismiss = {},
                    onSaveProfile = { _, _ -> true },
                    onCalculate = { _, _ -> EnergyScoreCalculation(1, 0) },
                    onWrite = { false },
                    today = LocalDate.of(2026, 11, 25),
                )
            }
        }

        compose.onNodeWithTag("energy_score_sync_status").assertTextEquals("手表已应答")
        compose.onNodeWithTag("energy_score_watch_today_notice").assertIsDisplayed()
    }
}
