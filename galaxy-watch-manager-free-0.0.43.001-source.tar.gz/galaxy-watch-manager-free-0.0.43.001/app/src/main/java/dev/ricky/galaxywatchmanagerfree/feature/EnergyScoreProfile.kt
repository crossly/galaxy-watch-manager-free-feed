package dev.ricky.galaxywatchmanagerfree.feature

import org.json.JSONObject

/** 手动维护的能量得分资料，独立于计算结果持久化。 */
data class EnergyScoreProfile(val age: Int, val female: Boolean) {
    fun json(): JSONObject = JSONObject().put("age", age).put("sex", if (female) "F" else "M")

    fun encode(): String = json().toString()

    companion object {
        const val PREF_KEY = "energy_profile"

        fun decode(raw: String?): EnergyScoreProfile? {
            val text = raw?.takeIf { it.isNotBlank() } ?: return null
            return try {
                val row = JSONObject(text)
                profile(row.opt("age"), row.optString("sex"))
            } catch (_: Exception) {
                null
            }
        }

        fun fromResultInputs(inputs: String): EnergyScoreProfile? {
            return try {
                val row = JSONObject(inputs)
                profile(row.opt("profile_age"), row.optString("profile_sex"))
            } catch (_: Exception) {
                null
            }
        }

        private fun profile(age: Any?, sex: String): EnergyScoreProfile? {
            val number = age as? Number ?: return null
            val value = number.toInt()
            if (value.toDouble() != number.toDouble() || value !in 18..99) return null
            val female =
                when (sex) {
                    "F" -> true
                    "M" -> false
                    else -> return null
                }
            return EnergyScoreProfile(value, female)
        }
    }
}

class EnergyScoreProfileStore(
    private val read: () -> String?,
    private val write: (String) -> Boolean,
) {
    fun load(): EnergyScoreProfile? = EnergyScoreProfile.decode(read())

    fun save(profile: EnergyScoreProfile): Boolean = write(profile.encode())
}

data class EnergyScoreCalculation(val calculated: Int, val missing: Int)
