package dev.ricky.galaxywatchmanagerfree.feature

import android.app.KeyguardManager
import android.content.Context
import android.os.PowerManager
import androidx.annotation.VisibleForTesting

/**
 * 手机使用状态检测。
 *
 * 参考官方三星实现（PhoneStatus.isActive）： 当屏幕亮起 (PowerManager.isInteractive) 且锁屏已解锁
 * (!KeyguardManager.isKeyguardLocked) 时，判定手机正处于使用中。
 */
object PhoneStatusDetector {

    @Volatile private var testOverride: ((Context?) -> Boolean)? = null

    fun isPhoneActive(context: Context?): Boolean {
        testOverride?.let {
            return it(context)
        }
        if (context == null) return false
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val keyguardManager = context.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        val isScreenOn = powerManager?.isInteractive ?: false
        val isKeyLocked = keyguardManager?.isKeyguardLocked ?: false
        return isPhoneActive(isInteractive = isScreenOn, isKeyguardLocked = isKeyLocked)
    }

    /** 纯逻辑判断接缝，便于单测 */
    fun isPhoneActive(isInteractive: Boolean, isKeyguardLocked: Boolean): Boolean =
        isInteractive && !isKeyguardLocked

    @VisibleForTesting
    internal fun setOverrideForTest(override: ((Context?) -> Boolean)?) {
        testOverride = override
    }
}
