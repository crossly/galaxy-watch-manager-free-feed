package dev.ricky.galaxywatchmanagerfree.feature

import dev.ricky.galaxywatchmanagerfree.wcs.WcsPaths
import org.json.JSONObject

/**
 * Find My Watch (`/w_apps_find_my_watch`) protocol state machine aligned with Samsung's
 * `FMWManager` / `FMWMessageSender` / `FMWMessageReceiver`.
 */
class WatchFindControl(
    private val send: (JSONObject) -> Boolean,
    private val onStatus: (FindWatchStatus) -> Unit,
    private val onResult: (Result) -> Unit = {},
    private val onLog: (String) -> Unit = {},
) {
    enum class Result {
        STARTED,
        STOPPED,
        SEND_FAILED,
        START_REJECTED,
        START_REJECTED_DURING_CALL,
        STOP_REJECTED,
        FINISHED_BY_WATCH,
    }

    private var connected = false
    private var status = FindWatchStatus.IDLE

    @Synchronized
    fun connect() {
        connected = true
        val payload =
            JSONObject()
                .put("msg_id", WcsPaths.MSG_FMW_CURRENT_STATE_REQ)
                .put("connection_type", CONNECTION_TYPE_BLUETOOTH)
        val sent = send(payload)
        onLog("[找手表] 同步当前状态 sent=$sent")
    }

    @Synchronized
    fun disconnect() {
        connected = false
        if (status != FindWatchStatus.IDLE) {
            updateStatus(FindWatchStatus.IDLE)
        }
    }

    @Synchronized fun toggle(): Boolean = if (status == FindWatchStatus.RINGING) stop() else start()

    @Synchronized
    fun start(): Boolean {
        if (!connected) {
            onResult(Result.SEND_FAILED)
            return false
        }
        updateStatus(FindWatchStatus.RINGING)
        val sent = send(JSONObject().put("msg_id", WcsPaths.MSG_FMW_START_ALERT_REQ))
        if (!sent) {
            updateStatus(FindWatchStatus.IDLE)
            onLog("[找手表] 下发响铃指令失败")
            onResult(Result.SEND_FAILED)
            return false
        }
        onLog("[找手表] 已下发响铃指令")
        onResult(Result.STARTED)
        return true
    }

    @Synchronized
    fun stop(): Boolean {
        if (!connected) {
            onResult(Result.SEND_FAILED)
            return false
        }
        updateStatus(FindWatchStatus.IDLE)
        val sent = send(JSONObject().put("msg_id", WcsPaths.MSG_FMW_STOP_ALERT_REQ))
        if (!sent) {
            updateStatus(FindWatchStatus.RINGING)
            onLog("[找手表] 下发停止响铃指令失败")
            onResult(Result.SEND_FAILED)
            return false
        }
        onLog("[找手表] 已下发停止响铃指令")
        onResult(Result.STOPPED)
        return true
    }

    @Synchronized
    fun handleMessage(json: JSONObject) {
        val msgId = json.optString("msg_id").ifEmpty { json.optString("msgId") }
        when (msgId) {
            WcsPaths.MSG_FMW_START_ALERT_RSP -> {
                val ok = json.optBoolean("result", true)
                val reason = json.optString("reason")
                if (!ok) {
                    updateStatus(FindWatchStatus.IDLE)
                    onLog("[找手表] 手表启动响铃失败 reason=$reason")
                    onResult(
                        if (reason == REASON_DURING_CALL) Result.START_REJECTED_DURING_CALL
                        else Result.START_REJECTED
                    )
                } else {
                    onLog("[找手表] 手表已确认开始响铃")
                }
            }
            WcsPaths.MSG_FMW_STOP_ALERT_RSP -> {
                val ok = json.optBoolean("result", true)
                if (ok) {
                    updateStatus(FindWatchStatus.IDLE)
                    onLog("[找手表] 手表已确认停止响铃")
                } else {
                    updateStatus(FindWatchStatus.RINGING)
                    onLog("[找手表] 手表停止响铃失败")
                    onResult(Result.STOP_REJECTED)
                }
            }
            WcsPaths.MSG_FMW_FINISH_ALERT_REQ -> {
                val wasRinging = status == FindWatchStatus.RINGING
                val finishType = json.optString("type")
                updateStatus(FindWatchStatus.IDLE)
                send(
                    JSONObject()
                        .put("msg_id", WcsPaths.MSG_FMW_FINISH_ALERT_RSP)
                        .put("result", wasRinging)
                )
                onLog("[找手表] 手表端结束响铃 type=$finishType wasRinging=$wasRinging")
                if (wasRinging) {
                    onResult(Result.FINISHED_BY_WATCH)
                }
            }
            WcsPaths.MSG_FMW_CURRENT_STATE_RSP -> {
                onLog("[找手表] 收到手表状态回执 lock=${json.optBoolean("lock_state", false)}")
            }
        }
    }

    private fun updateStatus(next: FindWatchStatus) {
        if (status != next) {
            status = next
            onStatus(next)
        }
    }

    companion object {
        const val CONNECTION_TYPE_BLUETOOTH = 0
        const val REASON_DURING_CALL = "during_call"
    }
}
