package dev.ricky.galaxywatchmanagerfree.feature

import android.content.ComponentName
import android.content.Context
import android.service.notification.NotificationListenerService
import dev.ricky.galaxywatchmanagerfree.core.WatchController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

internal class NotificationRecoveryAttempts(private val scope: CoroutineScope) {
    private var job: Job? = null

    @Synchronized
    fun start(attempt: (Int) -> Boolean) {
        if (job?.isActive == true) return
        job =
            scope.launch {
                for ((index, waitMillis) in listOf(0L, 2_000L, 4_000L, 8_000L).withIndex()) {
                    delay(waitMillis)
                    if (attempt(index)) break
                }
            }
    }

    @Synchronized
    fun cancel() {
        job?.cancel()
        job = null
    }
}

object NotificationListenerRecovery {
    private val attempts =
        NotificationRecoveryAttempts(CoroutineScope(SupervisorJob() + Dispatchers.Main))
    private val _connected = MutableStateFlow(false)
    val connected = _connected.asStateFlow()
    private var listener: NotificationBridgeService? = null

    internal fun onListenerConnected(service: NotificationBridgeService) {
        listener = service
        _connected.value = true
        attempts.cancel()
    }

    internal fun onListenerDisconnected(service: NotificationBridgeService) {
        if (listener !== service) return
        listener = null
        _connected.value = false
        requestRebindIfNeeded(service)
    }

    fun requestRebindIfNeeded(context: Context) {
        val app = context.applicationContext
        attempts.start { index ->
            if (
                _connected.value ||
                    !WatchController.forwardNotifications ||
                    !AppPermission.NOTIFICATION_ACCESS.isGranted(app)
            )
                return@start true

            val component = ComponentName(app, NotificationBridgeService::class.java)
            runCatching { NotificationListenerService.requestRebind(component) }
                .onSuccess { LogBus.log("[通知] 已请求系统重绑通知监听服务 attempt=${index + 1}") }
                .onFailure {
                    LogBus.error(
                        "[通知] 请求重绑通知监听服务失败 attempt=${index + 1} type=${it.javaClass.simpleName}"
                    )
                }
            false
        }
    }
}
