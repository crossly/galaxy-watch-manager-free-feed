package dev.ricky.galaxywatchmanagerfree.wcs

import java.util.Locale
import java.util.TimeZone
import org.json.JSONObject

internal object PhoneStatus {
    // Keep the carrier profile consistent with the SM-S938U1/XAA compatibility identity.
    const val MCC = "310"
    const val MNC = "410"
    const val SIM_COUNTRY = "us"

    fun build(
        locale: Locale,
        timeZone: TimeZone,
        timeMillis: Long,
        release: String,
        sdkInt: Int,
        display: String,
        pluginVersion: String,
    ): JSONObject =
        JSONObject()
            .put("localeLanguage", locale.language)
            .put("localeRegion", locale.country)
            .put("localeVariant", locale.variant ?: "")
            .put("localeUnicodeExtension", "")
            .put("localeScript", locale.script)
            .put("fbeMode", true)
            .put("pluginVersion", pluginVersion)
            .put("mcc", MCC)
            .put("mnc", MNC)
            .put("devicePlatform", "android")
            .put("devicePlatformVersion", release.substringBefore('.'))
            .put("oneUiVersion", 0)
            .put("swVersion", display)
            .put("SDKVersion", sdkInt.toString())
            .put("timezone", timeZone.id)
            .put("time", timeMillis)
            .put("simCountry", SIM_COUNTRY)
            .put("roamingStatus", false)
}
