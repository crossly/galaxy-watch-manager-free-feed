package dev.ricky.galaxywatchmanagerfree.wcs

import java.io.ByteArrayOutputStream
import java.time.DateTimeException
import java.time.Instant
import java.time.ZoneId
import java.util.TimeZone
import java.util.concurrent.TimeUnit

/** 手机侧 Wear OS 校时：保留请求字段并应答手机时间与时区。 */
class PhoneTimeSync(
    private val send: (String, ByteArray) -> Boolean,
    private val clock: () -> Long = { System.currentTimeMillis() },
    private val timeZone: () -> TimeZone = { TimeZone.getDefault() },
    private val log: (String) -> Unit = {},
) {

    /** 发送 START（`settings.COMMAND=0`）请求手表校时。 */
    fun start(): Boolean =
        send(PATH_SETTINGS_RPC, DataMapEncoder.encode(mapOf(KEY_COMMAND to COMMAND_START)))

    /** 仅消费 `/settings/rpc`；COMMAND=1 回复，其他命令静默，畸形/超长返回 false。 */
    fun receive(path: String, payload: ByteArray): Boolean {
        if (path != PATH_SETTINGS_RPC) return false
        if (payload.size > MAX_PAYLOAD_BYTES) {
            log("timesync: reject oversized /settings/rpc payload (${payload.size}B)")
            return false
        }
        val entries =
            Proto.parse(payload).fields[1].orEmpty().map { raw ->
                val entry = raw as? ByteArray ?: return false
                val key = Proto.parse(entry).text(1) ?: return false
                key to entry
            }
        val commandEntry = entries.lastOrNull { it.first == KEY_COMMAND }?.second ?: return false
        val commandValue = Proto.parse(commandEntry).nested(2) ?: return false
        if (commandValue.num(1) != DataMapEncoder.TYPE_INT32) return false
        val command = (commandValue.nested(2)?.num(6) ?: 0L).toInt()
        if (command == COMMAND_REQUEST) {
            val now = clock()
            val reply = ByteArrayOutputStream()
            // 未识别的 DataMap 类型也必须逐字节回传，不能经通用解码器往返。
            for ((key, entry) in entries) {
                if (key != KEY_COMMAND && key != KEY_COMPANION_TIME)
                    reply.write(Proto.bytes(1, entry))
            }
            reply.write(Proto.bytes(1, DataMapEncoder.entry(KEY_COMMAND, COMMAND_RESPONSE)))
            reply.write(Proto.bytes(1, DataMapEncoder.entry(KEY_COMPANION_TIME, now)))
            send(PATH_SETTINGS_RPC, reply.toByteArray())
            send(PATH_TIMEZONE_RPC, DataMapEncoder.encode(timeZoneMap(timeZone(), now)))
        }
        return true
    }

    private fun timeZoneMap(tz: TimeZone, now: Long): Map<String, Any> {
        val end = now + TEN_DAYS_MILLIS
        return linkedMapOf(
            KEY_TIME_ZONE to tz.id,
            KEY_CURRENT_UTC_OFFSET to tz.getOffset(now),
            KEY_RAW_UTC_OFFSET to tz.rawOffset,
            KEY_OFFSET_CALC_DATE to now,
            KEY_TIME_CHANGE_DATE to nextTransition(tz, now, end),
            KEY_OFFSET_AFTER_TIME_CHANGE to tz.getOffset(end),
        )
    }

    /** 官方 zzaj：下一时区 transition（毫秒），无则 Long.MAX_VALUE。 */
    private fun nextTransition(tz: TimeZone, now: Long, end: Long): Long =
        try {
            val rules = ZoneId.of(tz.id, ZoneId.SHORT_IDS).rules
            val transition = rules.nextTransition(Instant.ofEpochMilli(now))
            transition?.let { TimeUnit.SECONDS.toMillis(it.toEpochSecond()) } ?: Long.MAX_VALUE
        } catch (_: DateTimeException) {
            transitionFallback(tz, now, end)
        }

    /** 非标准时区 ID 的二分回退，保证不抛异常。 */
    private fun transitionFallback(tz: TimeZone, now: Long, end: Long): Long {
        val startOffset = tz.getOffset(now)
        if (startOffset == tz.getOffset(end)) return Long.MAX_VALUE
        var lo = now
        var hi = end
        while (hi - lo > TRANSITION_SEARCH_STEP_MILLIS) {
            val mid = (lo + hi) / 2
            if (tz.getOffset(mid) == startOffset) lo = mid else hi = mid
        }
        return (lo / TRANSITION_SEARCH_STEP_MILLIS) * TRANSITION_SEARCH_STEP_MILLIS
    }

    companion object {
        const val PATH_SETTINGS_RPC = "/settings/rpc"
        const val PATH_TIMEZONE_RPC = "/timezone/rpc"

        const val KEY_COMMAND = "settings.COMMAND"
        const val KEY_COMPANION_TIME = "settings.COMPANION_TIME"
        const val KEY_TIME_ZONE = "settings.TIME_ZONE"
        const val KEY_CURRENT_UTC_OFFSET = "settings.CURRENT_UTC_OFFSET"
        const val KEY_RAW_UTC_OFFSET = "settings.RAW_UTC_OFFSET"
        const val KEY_OFFSET_CALC_DATE = "settings.OFFSET_CALC_DATE"
        const val KEY_TIME_CHANGE_DATE = "settings.TIME_CHANGE_DATE"
        const val KEY_OFFSET_AFTER_TIME_CHANGE = "settings.OFFSET_AFTER_TIME_CHANGE"

        const val COMMAND_START = 0
        const val COMMAND_REQUEST = 1
        const val COMMAND_RESPONSE = 2

        /** `/settings/rpc` payload 上限。 */
        const val MAX_PAYLOAD_BYTES = 16 * 1024

        private val TEN_DAYS_MILLIS = TimeUnit.DAYS.toMillis(10)
        private const val TRANSITION_SEARCH_STEP_MILLIS = 1_000L
    }
}
