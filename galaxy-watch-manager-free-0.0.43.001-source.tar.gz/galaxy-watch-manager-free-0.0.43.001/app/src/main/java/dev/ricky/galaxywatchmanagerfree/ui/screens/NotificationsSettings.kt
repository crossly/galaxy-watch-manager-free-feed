package dev.ricky.galaxywatchmanagerfree.ui.screens

import android.app.TimePickerDialog
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.core.UiNotify
import dev.ricky.galaxywatchmanagerfree.core.WatchController
import dev.ricky.galaxywatchmanagerfree.feature.AppPermission
import dev.ricky.galaxywatchmanagerfree.feature.NotificationFilterMode
import dev.ricky.galaxywatchmanagerfree.feature.NotificationFilterPreferences
import dev.ricky.galaxywatchmanagerfree.feature.NotificationListenerRecovery
import dev.ricky.galaxywatchmanagerfree.feature.WatchRepository
import dev.ricky.galaxywatchmanagerfree.feature.WatchState
import dev.ricky.galaxywatchmanagerfree.ui.components.*
import dev.ricky.galaxywatchmanagerfree.ui.theme.*
import java.time.LocalTime
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun NotificationsSettings(
    state: WatchState,
    repo: WatchRepository,
    onAppFilter: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val strings = context.resources

    fun checkPermission(): Boolean = AppPermission.NOTIFICATION_ACCESS.isGranted(context)

    var permission by remember { mutableStateOf(checkPermission()) }
    val listenerConnected by NotificationListenerRecovery.connected.collectAsState()
    var forwarding by remember { mutableStateOf(WatchController.forwardNotifications) }
    val filter by NotificationFilterPreferences.config.collectAsState()
    val schedule by NotificationFilterPreferences.schedule.collectAsState()
    val muteWhileUsingPhone by NotificationFilterPreferences.muteWhileUsingPhone.collectAsState()
    var now by remember { mutableStateOf(LocalTime.now()) }
    val noApps = filter.mode == NotificationFilterMode.SELECTED && filter.packages.isEmpty()
    val withinSchedule = schedule.allows(now)
    val owner = LocalLifecycleOwner.current

    fun minuteText(minute: Int): String = LocalTime.of(minute / 60, minute % 60).toString()

    LaunchedEffect(Unit) {
        while (true) {
            delay(30_000)
            now = LocalTime.now()
        }
    }

    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                permission = checkPermission()
                // 从系统设置授权返回时，主动请求重绑，避免服务仍处于未连接状态。
                NotificationListenerRecovery.requestRebindIfNeeded(context)
            }
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        // Status overview card
        item {
            val active =
                permission &&
                    listenerConnected &&
                    forwarding &&
                    state.connected &&
                    state.sessionReady &&
                    !noApps &&
                    withinSchedule
            GroupedCard(cornerRadius = 24.dp, innerPadding = 18.dp) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    StatusOrb(
                        icon = Icons.Default.Notifications,
                        color = if (active) ElectricBlue else TextSecondary,
                        active = active,
                    )
                    Spacer(Modifier.width(16.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text =
                                when {
                                    !forwarding ->
                                        strings.getString(R.string.notification_forwarding_paused)
                                    noApps ->
                                        strings.getString(R.string.notification_filter_none_title)
                                    !permission -> strings.getString(R.string.permission_required)
                                    !listenerConnected ->
                                        strings.getString(
                                            R.string.notification_listener_disconnected
                                        )
                                    active ->
                                        strings.getString(R.string.notification_forwarding_ready)
                                    !withinSchedule ->
                                        strings.getString(
                                            R.string.notification_schedule_paused_title
                                        )
                                    else ->
                                        strings.getString(
                                            R.string.receive_notifications_on_your_watch
                                        )
                                },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary,
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text =
                                when {
                                    !forwarding ->
                                        strings.getString(
                                            R.string.notification_forwarding_explanation
                                        )
                                    noApps -> strings.getString(R.string.notification_filter_none)
                                    !permission ->
                                        strings.getString(R.string.notification_permission_guidance)
                                    !listenerConnected ->
                                        strings.getString(
                                            R.string.notification_listener_disconnected_detail
                                        )
                                    !state.connected || !state.sessionReady ->
                                        strings.getString(R.string.notification_connection_guidance)
                                    !withinSchedule ->
                                        strings.getString(
                                            R.string.notification_schedule_paused_explanation
                                        )
                                    else ->
                                        strings.getString(
                                            R.string.notification_connection_explanation
                                        )
                                },
                            style = MaterialTheme.typography.bodySmall,
                            lineHeight = 18.sp,
                            color = TextSecondary,
                        )
                    }
                }
            }
        }

        // Notification forwarding toggle
        item {
            SectionHeader(strings.getString(R.string.notification_settings))
            GroupedCard(innerPadding = 0.dp) {
                SettingSwitchRow(
                    title = strings.getString(R.string.forward_phone_notifications),
                    checked = forwarding,
                    modifier = Modifier.padding(horizontal = 16.dp),
                    subtitle =
                        strings.getString(R.string.send_new_phone_notifications_to_the_watch),
                    onCheckedChange = {
                        forwarding = it
                        WatchController.forwardNotifications = it
                        if (it) {
                            NotificationListenerRecovery.requestRebindIfNeeded(context)
                            repo.syncNotificationFeatures()
                        }
                    },
                )
                GroupedDivider(startIndent = 16.dp)
                SettingSwitchRow(
                    title = strings.getString(R.string.mute_notifications_while_using_phone),
                    checked = muteWhileUsingPhone,
                    enabled = forwarding,
                    modifier = Modifier.padding(horizontal = 16.dp),
                    subtitle =
                        strings.getString(R.string.mute_notifications_while_using_phone_desc),
                    onCheckedChange = {
                        NotificationFilterPreferences.setMuteWhileUsingPhone(it)
                        if (state.sessionReady) {
                            WatchController.repository.syncAlertsOnWatch(it)
                        }
                    },
                )
            }
        }

        // Forwarding time window
        item {
            SectionHeader(strings.getString(R.string.notification_schedule_section))
            GroupedCard(innerPadding = 0.dp) {
                SettingSwitchRow(
                    title = strings.getString(R.string.notification_schedule_switch),
                    checked = schedule.enabled,
                    modifier = Modifier.padding(horizontal = 16.dp),
                    subtitle =
                        when {
                            !schedule.enabled ->
                                strings.getString(R.string.notification_schedule_disabled)
                            schedule.startMinute == schedule.endMinute ->
                                strings.getString(R.string.notification_schedule_all_day)
                            else ->
                                strings.getString(
                                    R.string.notification_schedule_summary,
                                    minuteText(schedule.startMinute),
                                    minuteText(schedule.endMinute),
                                )
                        },
                    onCheckedChange = { NotificationFilterPreferences.setScheduleEnabled(it) },
                )
                if (schedule.enabled) {
                    GroupedDivider(startIndent = 64.dp)
                    GroupedCardRow(
                        title = strings.getString(R.string.notification_schedule_start),
                        subtitle = minuteText(schedule.startMinute),
                        showChevron = true,
                        onClick = {
                            TimePickerDialog(
                                    context,
                                    { _, hour, minute ->
                                        NotificationFilterPreferences.setScheduleStart(
                                            hour * 60 + minute
                                        )
                                    },
                                    schedule.startMinute / 60,
                                    schedule.startMinute % 60,
                                    true,
                                )
                                .show()
                        },
                    )
                    GroupedDivider(startIndent = 64.dp)
                    GroupedCardRow(
                        title = strings.getString(R.string.notification_schedule_end),
                        subtitle = minuteText(schedule.endMinute),
                        showChevron = true,
                        onClick = {
                            TimePickerDialog(
                                    context,
                                    { _, hour, minute ->
                                        NotificationFilterPreferences.setScheduleEnd(
                                            hour * 60 + minute
                                        )
                                    },
                                    schedule.endMinute / 60,
                                    schedule.endMinute % 60,
                                    true,
                                )
                                .show()
                        },
                    )
                }
            }
        }

        item {
            GroupedCard(innerPadding = 0.dp) {
                GroupedCardRow(
                    title = strings.getString(R.string.notification_filter_title),
                    subtitle =
                        if (filter.mode == NotificationFilterMode.ALL)
                            strings.getString(R.string.notification_filter_all)
                        else
                            strings.getString(
                                R.string.notification_filter_selected_count,
                                filter.packages.size,
                            ),
                    icon = Icons.Default.Apps,
                    showChevron = true,
                    onClick = onAppFilter,
                )
            }
        }

        // Permissions section
        item {
            SectionHeader(strings.getString(R.string.permissions))
            GroupedCard(innerPadding = 0.dp) {
                GroupedCardRow(
                    title = strings.getString(R.string.notification_access),
                    subtitle =
                        if (permission) strings.getString(R.string.granted)
                        else strings.getString(R.string.permission_required),
                    icon = if (permission) Icons.Default.VerifiedUser else Icons.Default.Lock,
                    iconTint = if (permission) EmeraldCharging else TextSecondary,
                    showChevron = true,
                    onClick = {
                        runCatching {
                            context.startActivity(
                                Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        }
                    },
                )
            }
        }

        // Test push & diagnostics section
        item {
            SectionHeader(strings.getString(R.string.advanced))
            GroupedCard(innerPadding = 0.dp) {
                GroupedCardRow(
                    title = strings.getString(R.string.test_notification),
                    subtitle =
                        if (state.sessionReady) {
                            strings.getString(R.string.send_a_notification_to_the_watch)
                        } else {
                            strings.getString(R.string.watch_disconnected)
                        },
                    icon = Icons.Default.NotificationsActive,
                    enabled = state.sessionReady,
                    onClick = {
                        scope.launch {
                            val sent = withContext(Dispatchers.IO) { repo.sendTestNotification() }
                            UiNotify.show(
                                if (sent) R.string.test_notification_sent
                                else R.string.request_send_failed
                            )
                        }
                    },
                )
            }
        }
    }
}
