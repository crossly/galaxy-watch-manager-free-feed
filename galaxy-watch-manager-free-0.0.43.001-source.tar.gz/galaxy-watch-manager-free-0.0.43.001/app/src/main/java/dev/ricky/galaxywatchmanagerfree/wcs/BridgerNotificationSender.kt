package dev.ricky.galaxywatchmanagerfree.wcs

import dev.ricky.galaxywatchmanagerfree.feature.NotificationIdentity

internal class BridgerNotificationSender(
    private val log: (String) -> Unit = {},
    private val onAssetSent: (digest: String, bytes: ByteArray) -> Unit = { _, _ -> },
    private val sendFrame: (ByteArray) -> Boolean,
) {
    enum class Result(val queued: Boolean) {
        REJECTED(false),
        TEXT_ONLY(true),
        WITH_ICON(true),
    }

    @Synchronized
    fun send(
        phoneNode: String,
        identity: NotificationIdentity,
        title: String,
        text: String,
        appName: String?,
        whenMillis: Long,
        seqId: Long,
        appIcon: ByteArray?,
        smallIcon: ByteArray? = null,
        isSmallIconVector: Boolean = false,
        allowTextFallback: Boolean = true,
        /** 诊断用：为 false 时只登记引用与缓存、不真正上传，用来逼出手表的 FetchAsset。 */
        uploadAssets: Boolean = true,
    ): Result? {
        if (phoneNode.isBlank()) return Result.REJECTED

        val validAppIcon = appIcon?.takeIf { it.isNotEmpty() && it.size <= MAX_ICON_BYTES }
        if (appIcon != null && appIcon.size > MAX_ICON_BYTES) {
            log("[通知图标] package=${identity.packageName} appIcon 超出大小上限 bytes=${appIcon.size}")
        }
        val validSmallIcon = smallIcon?.takeIf { it.isNotEmpty() && it.size <= MAX_ICON_BYTES }
        if (smallIcon != null && smallIcon.size > MAX_ICON_BYTES) {
            log("[通知图标] package=${identity.packageName} smallIcon 超出大小上限 bytes=${smallIcon.size}")
        }

        val assets = mutableMapOf<String, String>()
        var appIconRef: DataMapEncoder.AssetReference? = null
        var smallIconRef: DataMapEncoder.AssetReference? = null

        if (validAppIcon != null && validSmallIcon != null) {
            val appDigest = WcsFrame.messageDigest(validAppIcon)
            val smallDigest = WcsFrame.messageDigest(validSmallIcon)
            val queuedApp = sendIcon(validAppIcon, appDigest, uploadAssets)
            log(
                "[通知图标] package=${identity.packageName} (app_icon) digest=$appDigest bytes=${validAppIcon.size} assetQueued=$queuedApp"
            )
            val queuedSmall = sendIcon(validSmallIcon, smallDigest, uploadAssets)
            log(
                "[通知图标] package=${identity.packageName} (icon) digest=$smallDigest bytes=${validSmallIcon.size} assetQueued=$queuedSmall"
            )
            if (queuedApp && queuedSmall) {
                assets["0"] = appDigest
                assets["1"] = smallDigest
                appIconRef = DataMapEncoder.AssetReference(0)
                smallIconRef = DataMapEncoder.AssetReference(1)
            } else if (queuedApp) {
                assets["0"] = appDigest
                appIconRef = DataMapEncoder.AssetReference(0)
            } else if (queuedSmall) {
                assets["0"] = smallDigest
                smallIconRef = DataMapEncoder.AssetReference(0)
            }
        } else if (validAppIcon != null) {
            val digest = WcsFrame.messageDigest(validAppIcon)
            val queued = sendIcon(validAppIcon, digest, uploadAssets)
            log(
                "[通知图标] package=${identity.packageName} (app_icon) digest=$digest bytes=${validAppIcon.size} assetQueued=$queued"
            )
            if (queued) {
                assets["0"] = digest
                appIconRef = DataMapEncoder.AssetReference(0)
                smallIconRef = DataMapEncoder.AssetReference(0)
            }
        } else if (validSmallIcon != null) {
            val digest = WcsFrame.messageDigest(validSmallIcon)
            val queued = sendIcon(validSmallIcon, digest, uploadAssets)
            log(
                "[通知图标] package=${identity.packageName} (icon) digest=$digest bytes=${validSmallIcon.size} assetQueued=$queued"
            )
            if (queued) {
                assets["0"] = digest
                smallIconRef = DataMapEncoder.AssetReference(0)
            }
        }

        val hasIcon = appIconRef != null || smallIconRef != null
        if (!hasIcon && !allowTextFallback) return null

        // 字段集对齐官方 GMS wear_companion 发送器（Samsung 手机插件内置的 zzewl）：
        // 官方每次都会下发 R_c/R_c,0、when、post_time_millis、show_when、app_name、
        // notification_style、title_html/title_raw、text_html/text_raw、color、
        // notification_flags、user_id、is_small_icon_vector_drawable 等字段。
        // notification_style 缺失时手表端无法确定通知模板，会退回通用样式并显示占位图标。
        val data =
            linkedMapOf<String, Any>(
                "R_c,0" to 1L,
                "R_c" to 1L,
                "when" to whenMillis,
                "post_time_millis" to whenMillis,
                "show_when" to true,
                "app_name" to (appName?.takeIf { it.isNotBlank() } ?: identity.packageName),
                "notification_style" to STYLE_STANDARD,
                "priority" to 1,
                "title_html" to html(title),
                "title_raw" to title,
                "text_html" to html(text),
                "text_raw" to text,
                "color" to 0,
                "notification_flags" to 0,
                "user_id" to identity.userId,
                "defaults" to 2,
                "has_sound" to true,
                "has_content_intent" to false,
                "only_alert_once" to false,
                "is_work_profile" to false,
                "is_emergency" to false,
                "is_group_summary" to false,
                "is_small_icon_vector_drawable" to isSmallIconVector,
                "from" to "phone",
            )
        if (appIconRef != null) data["app_icon"] = appIconRef
        if (smallIconRef != null) data["icon"] = smallIconRef

        val queued =
            sendFrame(
                WcsFrame.wearPathFrame(
                    path = "wear://$phoneNode/${identity.bridgerPath(phoneNode)}",
                    dataItems = listOf(DataMapEncoder.encode(data)),
                    senderPkg = SENDER_PACKAGE,
                    nodeId = phoneNode,
                    seqId = seqId,
                    assets = assets,
                )
            )
        return when {
            !queued -> Result.REJECTED
            !hasIcon -> Result.TEXT_ONLY
            else -> Result.WITH_ICON
        }
    }

    private fun sendIcon(bytes: ByteArray, digest: String, upload: Boolean): Boolean {
        if (!upload) {
            onAssetSent(digest, bytes)
            return true
        }
        val queued =
            WearAssetSender.send(
                sendFrame = sendFrame,
                bytes = bytes,
                digest = digest,
                owners = listOf(SENDER_PACKAGE to WcsPaths.SIGNATURE_PLUGIN),
            )
        if (queued) onAssetSent(digest, bytes)
        return queued
    }

    companion object {
        const val MAX_ICON_BYTES = WearAssetSender.MAX_BYTES
        private const val SENDER_PACKAGE = "com.samsung.android.wcs.extension"

        /** 官方 `C1769ko.f(2)` → `notification_style = 1`（StandardStyle）。 */
        private const val STYLE_STANDARD = 1

        /** 与官方 `BG.r()` 一致：HTML 转义并把换行转成 `<br>`。 */
        internal fun html(text: String): String =
            text
                .replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("\n", "<br>")
    }
}
