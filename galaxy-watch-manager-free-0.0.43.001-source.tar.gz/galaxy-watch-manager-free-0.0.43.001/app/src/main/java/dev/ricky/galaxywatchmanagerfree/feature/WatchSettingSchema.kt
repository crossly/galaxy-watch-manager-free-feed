package dev.ricky.galaxywatchmanagerfree.feature

import dev.ricky.galaxywatchmanagerfree.wcs.WcsFrame
import dev.ricky.galaxywatchmanagerfree.wcs.WcsPaths

/** Official Wear DataItem URI authority owner (`DataOwner.WATCH` vs `DataOwner.GW`). */
enum class SettingOwner {
    WATCH,
    PHONE,
}

data class SettingTemplate(val uri: String, val dataMap: Map<String, Any>)

data class SettingWriteRequest(val uri: String, val dataMap: Map<String, Any>)

/** 固件设置值类型；[firmwareType] 对应回包里的 `type` 字段。 */
enum class SettingKind(val firmwareType: Long) {
    BOOL(0L),
    INT(1L),
    STRING(3L),
    LIST(5L),
    MAP(9L);

    fun accepts(value: Any): Boolean =
        when (this) {
            BOOL -> value is Boolean
            INT -> value is Number
            STRING -> value is String
            LIST -> value is List<*>
            MAP -> value is Map<*, *>
        }

    /**
     * 把回包值归一成下发时的类型。
     *
     * 手表偶尔用另一种类型回显同一个设置（PSM 下发 `Boolean`、回包是 `0/1`），归一后 [SettingCommands.confirm]
     * 才能把「已下发」和「已确认」对上，避免误报未确认。
     */
    fun canonicalize(value: Any): Any? =
        when (this) {
            BOOL ->
                when (value) {
                    is Boolean -> value
                    is Number -> value.toInt() != 0
                    is String -> value.equals("true", ignoreCase = true) || value == "1"
                    else -> null
                }
            INT ->
                when (value) {
                    is Number -> value.toInt()
                    is Boolean -> if (value) 1 else 0
                    is String -> value.toIntOrNull()
                    else -> null
                }
            STRING -> if (value is String) value else null
            LIST,
            MAP -> null
        }
}

/**
 * 一个设置项的完整下发规格。
 *
 * @param path 下发时写进 DataMap 的完整路径
 * @param key 回包里承载取值的 key 名（`booleanIsChecked` / `intLevel` / `intSelectedItem` / `stringName` / …）
 * @param kind 取值类型
 * @param match 回包路径的匹配后缀，默认与 [path] 相同；固件对不同机型会用不同前缀，因此匹配按后缀
 * @param apply 回包值落到 [WatchState] 顶层字段的映射；null 表示只进 `settingItems`
 */
data class SettingSpec(
    val path: String,
    val key: String,
    val kind: SettingKind,
    val match: String = path,
    val owner: SettingOwner = SettingOwner.WATCH,
    val supportsReadBack: Boolean = false,
    val apply: ((WatchState, Any) -> WatchState)? = null,
)

/**
 * 手表系统设置的规格表。
 *
 * 取代 `WatchRepository` 里 30 多个手写 `setXxx` 里的硬编码 key 猜测，以及 `applyWatchSetting` 中那条「路径 endsWith …
 * 则更新某个字段」的长 if-else 链。集中在一处的好处：
 * 1. 写入与回包共用同一份 key/type 知识，不再靠 `guessKey()` 猜；
 * 2. 新增设置项只改表，不碰仓库逻辑；
 * 3. 纯 Kotlin，可以直接单测（见 `WatchSettingSchemaTest`）。
 */
object WatchSettingSchema {

    private const val SET = "/w_module_sec_watch_setting"

    /** 省电模式：下发 Boolean，回包是 `0/1`，且仓库要额外记录 `psmKnown`。 */
    val PSM =
        SettingSpec(
            path = WcsPaths.SET_PSM,
            key = "key_psm_status",
            kind = SettingKind.BOOL,
            match = "watch_setting/psm",
            apply = { state, value -> state.copy(psmMode = value.asBool()) },
        )

    private val specs: List<SettingSpec> =
        listOf(
            PSM,
            SettingSpec(WcsPaths.SET_DISPLAY_BRIGHTNESS, "intLevel", SettingKind.INT) { state, value
                ->
                state.copy(brightness = value.asInt())
            },
            SettingSpec(WcsPaths.SET_DISPLAY_AOD, "booleanIsChecked", SettingKind.BOOL) {
                state,
                value ->
                state.copy(aodEnabled = value.asBool())
            },
            SettingSpec(WcsPaths.SET_DISPLAY_WAKE_WRIST, "booleanIsChecked", SettingKind.BOOL) {
                state,
                value ->
                state.copy(wakeOnWrist = value.asBool())
            },
            SettingSpec(WcsPaths.SET_DISPLAY_OUTDOOR_MODE, "booleanIsChecked", SettingKind.BOOL) {
                state,
                value ->
                state.copy(outdoorMode = value.asBool())
            },
            SettingSpec(
                WcsPaths.SET_DISPLAY_SCREEN_TIMEOUT_SEL,
                "intSelectedItem",
                SettingKind.INT,
            ) { state, value ->
                state.copy(screenTimeoutItem = value.asInt())
            },
            SettingSpec(WcsPaths.SET_DISPLAY_WAKE_TOUCH, "booleanIsChecked", SettingKind.BOOL) {
                state,
                value ->
                state.copy(wakeOnTouch = value.asBool())
            },
            SettingSpec(WcsPaths.SET_DISPLAY_WAKE_BEZEL, "booleanIsChecked", SettingKind.BOOL) {
                state,
                value ->
                state.copy(wakeOnBezel = value.asBool())
            },
            SettingSpec(
                WcsPaths.SET_SOUND_TOUCH,
                "booleanIsChecked",
                SettingKind.BOOL,
                supportsReadBack = true,
            ) { state, value ->
                state.copy(touchSound = value.asBool())
            },
            SettingSpec(
                WcsPaths.SET_SOUND_CHARGING,
                "booleanIsChecked",
                SettingKind.BOOL,
                supportsReadBack = true,
            ) { state, value ->
                state.copy(chargingSound = value.asBool())
            },
            SettingSpec(WcsPaths.SET_ADV_GESTURE_ANSWER, "booleanIsChecked", SettingKind.BOOL) {
                state,
                value ->
                state.copy(gestureAnswer = value.asBool())
            },
            SettingSpec(WcsPaths.SET_ADV_GESTURE_DISMISS, "booleanIsChecked", SettingKind.BOOL) {
                state,
                value ->
                state.copy(gestureDismiss = value.asBool())
            },
            SettingSpec(
                "$SET/advanced/labs/quicklaunch/support",
                "booleanIsChecked",
                SettingKind.BOOL,
                match = "advanced/labs/quicklaunch/support",
            ) { state, value ->
                state.copy(quickLaunch = value.asBool())
            },
            SettingSpec(WcsPaths.SET_GENERAL_WRIST, "intLevel", SettingKind.INT) { state, value ->
                state.copy(wristRight = value.asInt() == 1)
            },
            // 无障碍设置的固件前缀是 `w_module_sec_watch_setting_accessibility`（无斜杠），
            // 与其它页不同，因此匹配按后缀走，兼容两种回包前缀。
            SettingSpec(
                "w_module_sec_watch_setting_accessibility/grayscale",
                "booleanIsChecked",
                SettingKind.BOOL,
                match = "accessibility/grayscale",
            ) { state, value ->
                state.copy(grayscaleEnabled = value.asBool())
            },
            SettingSpec(
                "w_module_sec_watch_setting_accessibility/high_contrast_fonts",
                "booleanIsChecked",
                SettingKind.BOOL,
                match = "accessibility/high_contrast_fonts",
            ) { state, value ->
                state.copy(highContrastFonts = value.asBool())
            },
            SettingSpec(
                "w_module_sec_watch_setting_accessibility/mute_all_sound",
                "booleanIsChecked",
                SettingKind.BOOL,
                match = "accessibility/mute_all_sound",
            ) { state, value ->
                state.copy(muteAllSounds = value.asBool())
            },
            SettingSpec(
                "w_module_sec_watch_setting_accessibility/negative_colors",
                "booleanIsChecked",
                SettingKind.BOOL,
                match = "accessibility/negative_colors",
            ) { state, value ->
                state.copy(negativeColors = value.asBool())
            },
            SettingSpec(
                "w_module_sec_watch_setting_accessibility/remove_animations",
                "booleanIsChecked",
                SettingKind.BOOL,
                match = "accessibility/remove_animations",
            ) { state, value ->
                state.copy(removeAnimations = value.asBool())
            },
            SettingSpec(
                WcsPaths.SET_PHONE_DND_TURN_ON,
                "booleanIsChecked",
                SettingKind.BOOL,
                match = "dnd_turn_on_now",
            ) { state, value ->
                state.copy(dndOn = value.asBool())
            },
            SettingSpec(
                WcsPaths.SET_INFO_WATCH_NAME,
                "stringName",
                SettingKind.STRING,
                match = "setting_info/watch_name",
            ),
        )

    /** 匹配用的表：统一去掉前导斜杠，长后缀优先（避免短后缀抢先命中）。 */
    private val bySuffix: List<Pair<String, SettingSpec>> =
        specs.map { it.match.trimStart('/') to it }.sortedByDescending { it.first.length }

    /** 按回包/写入路径找规格；找不到说明该路径还没登记进表。 */
    fun spec(path: String): SettingSpec? {
        val clean = path.trimStart('/')
        return bySuffix.firstOrNull { clean.endsWith(it.first) }?.second
    }

    fun decode(
        path: String,
        dataMap: Map<String, Any>,
        allowPhoneOrigin: Boolean = false,
    ): SettingItem? {
        if (!allowPhoneOrigin && dataMap["from"] == "phone") return null
        val clean = path.trimStart('/')
        val spec = spec(clean)
        val valueKey =
            (dataMap["key"] as? String)
                ?: spec?.key?.takeIf { dataMap.containsKey(it) }
                ?: dataMap.keys.firstOrNull { it !in metadataKeys }
                ?: return null
        val value = dataMap[valueKey] ?: return null
        val type =
            (dataMap["type"] as? Number)?.toLong()
                ?: when (value) {
                    is Boolean -> 0L
                    is Number -> 1L
                    is String -> 3L
                    is List<*> -> 5L
                    is Map<*, *> -> 9L
                    else -> 3L
                }
        return SettingItem(clean, valueKey, type, value)
    }

    /**
     * Projects a decoded setting value into [WatchState], normalizing watch payloads whose runtime
     * wire type differs from the spec (e.g. `w_module_sec_watch_setting/psm` carries `Int` `0/1`
     * while [PSM] is declared as [SettingKind.BOOL]).
     */
    fun project(spec: SettingSpec?, state: WatchState, rawValue: Any): WatchState {
        val apply = spec?.apply ?: return state
        val projected =
            when {
                spec.kind.accepts(rawValue) -> rawValue
                else -> spec.kind.canonicalize(rawValue)
            } ?: return state
        return apply(state, projected)
    }

    /**
     * Builds the Wear DataItem URI and DataMap payload for a setting write, matching Samsung's
     * `SettingsCompanion.putWatchDataItem` / `putPhoneDataItem`.
     *
     * Watch-owned items (`DataOwner.WATCH`) write to `wear://<watchNode>/<cleanPath>` and clone any
     * cached watch template so existing metadata (`key`, `type`, sibling fields) is preserved.
     */
    fun buildWrite(
        cleanPath: String,
        key: String,
        type: Long,
        value: Any,
        watchNode: String,
        phoneNode: String,
        template: SettingTemplate? = null,
        now: Long = System.currentTimeMillis(),
    ): SettingWriteRequest? {
        val clean = cleanPath.trimStart('/')
        val owner =
            spec(clean)?.owner
                ?: if (clean.startsWith("w_module_sec_watch_setting")) SettingOwner.WATCH
                else SettingOwner.PHONE
        return when (owner) {
            SettingOwner.WATCH -> {
                if (watchNode.isBlank()) return null
                val matchingTemplate =
                    template?.takeIf {
                        val (host, path) = WcsFrame.splitWearPath(it.uri)
                        host == watchNode && path == "/$clean"
                    }
                val uri = matchingTemplate?.uri ?: "wear://$watchNode/$clean"
                val dataMap =
                    if (matchingTemplate != null) {
                        LinkedHashMap<String, Any>(matchingTemplate.dataMap).apply {
                            put(key, value)
                            put("from", "phone")
                            put("time", now)
                        }
                    } else if (clean.startsWith("w_module_sec_watch_setting_accessibility/")) {
                        linkedMapOf(key to value, "from" to "phone", "time" to now)
                    } else {
                        linkedMapOf(
                            "key" to key,
                            "type" to type,
                            key to value,
                            "from" to "phone",
                            "time" to now,
                        )
                    }
                SettingWriteRequest(uri, dataMap)
            }
            SettingOwner.PHONE -> {
                if (phoneNode.isBlank()) return null
                SettingWriteRequest(
                    uri = "wear://$phoneNode/$clean",
                    dataMap = linkedMapOf(key to value, "from" to "phone", "time" to now),
                )
            }
        }
    }

    private val metadataKeys =
        setOf("from", "time", "type", "key", "KEY_DATA_ITEM_TIME", "dataMapId", "time_stamp")

    /** 表里登记的全部规格（测试与文档用）。 */
    fun all(): List<SettingSpec> = specs
}

private fun Any.asBool(): Boolean =
    when (this) {
        is Boolean -> this
        is Number -> toInt() != 0
        is String -> equals("true", ignoreCase = true) || this == "1"
        else -> false
    }

private fun Any.asInt(): Int =
    when (this) {
        is Number -> toInt()
        is Boolean -> if (this) 1 else 0
        is String -> toIntOrNull() ?: 0
        else -> 0
    }
