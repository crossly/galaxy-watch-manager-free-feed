package dev.ricky.galaxywatchmanagerfree.feature

import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.nio.charset.StandardCharsets
import java.nio.file.AtomicMoveNotSupportedException
import java.nio.file.Files
import java.nio.file.StandardCopyOption

/**
 * Atomic, device-scoped file store for the raw [HealthRecordStore] JSON archive.
 *
 * Keeps multi-megabyte raw health records out of `SharedPreferences` XML so lightweight summary
 * updates do not re-serialize the entire archive, while preserving durable-before-ACK semantics.
 */
internal class HealthRecordFileStore(private val directory: File, peerAddress: String?) {
    private val prefix = DeviceScope.preferences(FILE_BASE, peerAddress)
    val recordFile: File = File(directory, "$prefix.json")
    val recoveryFile: File = File(directory, "${prefix}_recovery.json")

    fun exists(): Boolean = recordFile.isFile

    fun read(): String? = readUtf8(recordFile)

    fun readRecovery(): String? = readUtf8(recoveryFile)

    fun write(encoded: String, durable: Boolean): Boolean =
        writeAtomic(recordFile, encoded, durable)

    fun writeRecovery(raw: String): Boolean = writeAtomic(recoveryFile, raw, durable = true)

    private fun readUtf8(file: File): String? =
        if (!file.isFile) null
        else runCatching { file.readText(StandardCharsets.UTF_8) }.getOrNull()

    private fun writeAtomic(target: File, content: String, durable: Boolean): Boolean {
        val temp = File(directory, "${target.name}.tmp")
        return try {
            if (!directory.isDirectory && !directory.mkdirs()) return false
            val bytes = content.toByteArray(StandardCharsets.UTF_8)
            FileOutputStream(temp).use { out ->
                out.write(bytes)
                out.flush()
                if (durable) out.fd.sync()
            }
            try {
                Files.move(
                    temp.toPath(),
                    target.toPath(),
                    StandardCopyOption.REPLACE_EXISTING,
                    StandardCopyOption.ATOMIC_MOVE,
                )
            } catch (_: AtomicMoveNotSupportedException) {
                Files.move(temp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING)
            }
            true
        } catch (_: IOException) {
            runCatching { temp.delete() }
            false
        } catch (_: SecurityException) {
            runCatching { temp.delete() }
            false
        }
    }

    companion object {
        const val FILE_BASE = "health-records"
    }
}
