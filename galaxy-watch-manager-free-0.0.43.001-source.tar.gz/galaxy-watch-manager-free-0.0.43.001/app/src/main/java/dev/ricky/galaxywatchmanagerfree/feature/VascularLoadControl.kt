package dev.ricky.galaxywatchmanagerfree.feature

import dev.ricky.galaxywatchmanagerfree.wcs.WcsPaths
import java.io.ByteArrayOutputStream
import java.time.Instant
import java.time.ZoneId
import java.util.Base64
import java.util.concurrent.atomic.AtomicInteger
import java.util.zip.GZIPOutputStream
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject

/**
 * Pure policy deciding whether an uninitialized watch should automatically receive a baseline
 * initialization (`RESET_EVENT_USER_INITIATED` / v1 `RESET_EVENT`) without requiring a manual tap.
 *
 * Safety invariant: NEVER activates until watch history has been verified in the current session,
 * NEVER activates when the current watch already has an active/in-progress baseline
 * (`needsWatchActivation == false`), and NEVER overrides an explicit user-disabled Labs setting.
 */
object VascularLoadAutoActivatePolicy {
    const val DEFAULT_RETRY_COOLDOWN_MS = 5 * 60_000L

    sealed interface Decision {
        data class Activate(val watchDeviceUuid: String) : Decision

        data object SkipUnsupported : Decision

        data object SkipDisconnected : Decision

        data object SkipSyncing : Decision

        data object SkipControlInFlight : Decision

        data object SkipDisabledByUser : Decision

        data object SkipHistoryUnverified : Decision

        data object SkipAlreadyActive : Decision

        data object SkipCooldown : Decision
    }

    fun decide(
        supported: Boolean,
        sessionReady: Boolean,
        healthSyncIdle: Boolean,
        controlInFlight: Boolean,
        labSettingEnabled: Boolean?,
        historyVerified: Boolean,
        snapshot: VascularLoadLog.Snapshot,
        lastAttemptAt: Long,
        now: Long,
        retryCooldownMs: Long = DEFAULT_RETRY_COOLDOWN_MS,
    ): Decision {
        if (!supported) return Decision.SkipUnsupported
        if (!sessionReady) return Decision.SkipDisconnected
        if (!healthSyncIdle) return Decision.SkipSyncing
        if (controlInFlight) return Decision.SkipControlInFlight
        if (labSettingEnabled == false) return Decision.SkipDisabledByUser
        if (!historyVerified) return Decision.SkipHistoryUnverified
        val watchDevice = snapshot.activeDeviceUuid?.takeIf { it.isNotBlank() }
        if (!snapshot.needsWatchActivation || watchDevice == null) {
            return Decision.SkipAlreadyActive
        }
        if (lastAttemptAt > 0L && now - lastAttemptAt in 0L until retryCooldownMs) {
            return Decision.SkipCooldown
        }
        return Decision.Activate(watchDevice)
    }
}

/**
 * Vascular Load watch activation and baseline reset protocol controller.
 *
 * Watch Samsung Health (6.30.7.008 `V11.c` / `Hc3.x` / `TP2` / `C3723dU2` / `HK1` / `C7105qP1`)
 * only enables overnight Vascular Load tracking when the latest `type=1 (RESET)` row in
 * `com.samsung.shealth.mean_arterial_pressure` carries the watch's own current local `deviceuuid`.
 * Sending `VlPushMessageV2(RESET_EVENT_USER_INITIATED)` (or v1 `VlPushMessage(RESET_EVENT)` for
 * watch capability version 1000) to `com.samsung.android.wear.shealth.vascularload` instructs the
 * watch to insert a fresh `type=1 (RESET)` row stamped with its current `deviceuuid` and sync it
 * back, activating a new or re-paired watch or resetting an existing baseline.
 */
class VascularLoadControl(
    private val scope: CoroutineScope,
    private val watchNode: () -> String,
    private val watchVersion: () -> Int,
    private val send: (JSONObject) -> Boolean,
    private val onStatus: (Status) -> Unit,
    private val onResetCreated: () -> Unit,
    private val clock: () -> Long = System::currentTimeMillis,
    private val zone: () -> ZoneId = ZoneId::systemDefault,
    private val timeoutMillis: Long = 30_000L,
    private val onLog: (String) -> Unit = {},
    private val onError: (String) -> Unit = {},
) {
    enum class Status {
        IDLE,
        SENDING,
        CREATED,
        NOT_CREATED,
        SEND_FAILED,
        TIMED_OUT,
        DISCONNECTED,
    }

    private data class Pending(val sequence: Int, val useV2: Boolean, var job: Job? = null)

    private val sequence = AtomicInteger(kotlin.random.Random.nextInt(200_000_000, 300_000_000))
    private var pending: Pending? = null

    val isPending: Boolean
        @Synchronized get() = pending != null

    @Synchronized
    fun activateOrReset(userInitiated: Boolean = true, automatic: Boolean = false): Boolean {
        pending?.job?.cancel()
        val version = watchVersion()
        val useV2 = version >= HealthCapability.VASCULAR_LOAD_RESET_V2_VERSION
        val request = Pending(sequence.getAndIncrement(), useV2)
        pending = request
        onStatus(Status.SENDING)
        val protocolTag = if (useV2) "v2" else "v1"
        val actionLabel = if (automatic) "自动初始化手表基线" else "发送手表初始化/重置基线指令"
        onLog(
            "[血管负荷→] $actionLabel seq=${request.sequence} protocol=$protocolTag userInitiated=$userInitiated"
        )
        val sent = send(buildPacket(request, userInitiated))
        if (!sent) {
            if (pending === request) {
                pending = null
                onStatus(Status.SEND_FAILED)
                onError("[血管负荷] ${actionLabel}发送失败 seq=${request.sequence}")
            }
            return false
        }
        if (pending === request) {
            request.job =
                scope.launch {
                    delay(timeoutMillis)
                    synchronized(this@VascularLoadControl) {
                        if (pending === request) {
                            pending = null
                            onStatus(Status.TIMED_OUT)
                            onError("[血管负荷] ${actionLabel}等待手表应答超时 seq=${request.sequence}")
                        }
                    }
                }
        }
        return true
    }

    @Synchronized
    fun handleMessage(json: JSONObject): Boolean {
        val request = pending ?: return false
        if (
            json.optString("message") != WcsPaths.HEALTH_MSG_RESPONSE ||
                json.optString("type") != WcsPaths.HEALTH_TYPE_MESSAGE ||
                json.optString("sender") != WcsPaths.HEALTH_WATCH_VASCULAR_LOAD ||
                json.optString("receiver") != WcsPaths.HEALTH_PHONE_VASCULAR_LOAD ||
                json.optInt("sequence_num") != request.sequence
        )
            return false

        val payload =
            runCatching { HealthJson.entries(json.optString("body")).optJSONObject(0) }.getOrNull()
                ?: return true
        val command = payload.optString("command")
        if (command.isBlank()) return true

        pending = null
        request.job?.cancel()
        return when (command) {
            CMD_V2_CREATED_ACK,
            CMD_V1_RESET_ACK -> {
                onStatus(Status.CREATED)
                onLog("[血管负荷←] 手表已确认初始化/重置基线 seq=${request.sequence} cmd=$command")
                onResetCreated()
                true
            }
            CMD_V2_NOT_CREATED_ACK -> {
                onStatus(Status.NOT_CREATED)
                onLog("[血管负荷←] 手表未创建新基线重置记录 seq=${request.sequence} cmd=$command")
                true
            }
            else -> {
                onStatus(Status.NOT_CREATED)
                onError("[血管负荷] 收到未识别的重置应答 seq=${request.sequence} cmd=$command")
                true
            }
        }
    }

    @Synchronized
    fun onRowsSynced() {
        if (pending == null) {
            onStatus(Status.IDLE)
        }
    }

    @Synchronized
    fun disconnect() {
        val previous = pending
        previous?.job?.cancel()
        pending = null
        if (previous != null) {
            onStatus(Status.DISCONNECTED)
            onError("[血管负荷] 初始化/重置基线因断线中止 seq=${previous.sequence}")
        } else {
            onStatus(Status.IDLE)
        }
    }

    private fun buildPacket(request: Pending, userInitiated: Boolean): JSONObject {
        val now = clock()
        val offsetMillis = zone().rules.getOffset(Instant.ofEpochMilli(now)).totalSeconds * 1_000L
        val body =
            if (request.useV2) {
                JSONObject()
                    .put("command", if (userInitiated) CMD_V2_USER_INITIATED else CMD_V2_AUTOMATIC)
                    .put("utcTimestamp", now)
                    .put("timeOffset", offsetMillis)
            } else {
                JSONObject()
                    .put("version", 0)
                    .put("command", CMD_V1_RESET_EVENT)
                    .put("timestamp", now)
                    .put("testMode", false)
            }
        val output = ByteArrayOutputStream()
        GZIPOutputStream(output).use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        return JSONObject()
            .put("message", WcsPaths.HEALTH_MSG_REQUEST)
            .put("type", WcsPaths.HEALTH_TYPE_MESSAGE)
            .put("sender", WcsPaths.HEALTH_PHONE_VASCULAR_LOAD)
            .put("receiver", WcsPaths.HEALTH_WATCH_VASCULAR_LOAD)
            .put("version", 5.03)
            .put("sequence_num", request.sequence)
            .put("source_node", WcsPaths.PKG_SHEALTH)
            .put("destination_node", watchNode())
            .put("body", Base64.getEncoder().encodeToString(output.toByteArray()))
    }

    companion object {
        const val CMD_V2_USER_INITIATED = "RESET_EVENT_USER_INITIATED"
        const val CMD_V2_AUTOMATIC = "RESET_EVENT_AUTOMATIC"
        const val CMD_V2_CREATED_ACK = "RESET_EVENT_CREATED_ACK"
        const val CMD_V2_NOT_CREATED_ACK = "RESET_EVENT_NOT_CREATED_ACK"
        const val CMD_V1_RESET_EVENT = "RESET_EVENT"
        const val CMD_V1_RESET_ACK = "RESET_EVENT_ACK"
    }
}
