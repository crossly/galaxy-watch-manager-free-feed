package dev.ricky.galaxywatchmanagerfree.wcs

import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.nio.file.AtomicMoveNotSupportedException
import java.nio.file.Files
import java.nio.file.StandardCopyOption

/**
 * Bounded on-disk store for incoming Wear OS assets (`files/wear-assets/<phone>_<watch>/`).
 *
 * Evicts the least-recently-used assets when either file count or total byte budget is exceeded so
 * long-running sessions cannot grow private app storage without bound.
 */
internal class WearAssetStore(
    private val directory: File,
    private val maxFiles: Int = DEFAULT_MAX_FILES,
    private val maxTotalBytes: Long = DEFAULT_MAX_TOTAL_BYTES,
    private val nowMillis: () -> Long = System::currentTimeMillis,
) {
    @Synchronized
    fun persist(digest: String, bytes: ByteArray): Boolean {
        if (!isSafeDigest(digest)) return false
        if (bytes.size.toLong() > maxTotalBytes) return false
        val target = File(directory, digest)
        val temp = File(directory, "$digest.tmp")
        return try {
            if (!directory.isDirectory && !directory.mkdirs()) return false
            FileOutputStream(temp).use { out ->
                out.write(bytes)
                out.flush()
            }
            try {
                Files.move(
                    temp.toPath(),
                    target.toPath(),
                    StandardCopyOption.REPLACE_EXISTING,
                    StandardCopyOption.ATOMIC_MOVE,
                )
            } catch (_: AtomicMoveNotSupportedException) {
                Files.move(temp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING)
            }
            target.setLastModified(nowMillis())
            prune(keep = target)
            true
        } catch (_: IOException) {
            runCatching { temp.delete() }
            false
        } catch (_: SecurityException) {
            runCatching { temp.delete() }
            false
        }
    }

    @Synchronized
    fun contains(digest: String): Boolean {
        if (!isSafeDigest(digest)) return false
        val target = File(directory, digest)
        if (!target.isFile) return false
        val matched =
            runCatching { WcsFrame.messageDigest(target.readBytes()) == digest }.getOrDefault(false)
        if (matched) target.setLastModified(nowMillis())
        return matched
    }

    private fun prune(keep: File) {
        val files =
            directory.listFiles()?.filter { it.isFile && !it.name.endsWith(".tmp") } ?: return
        var totalBytes = files.sumOf { it.length() }
        var remainingCount = files.size
        if (remainingCount <= maxFiles && totalBytes <= maxTotalBytes) return
        val candidates =
            files
                .filter { it.name != keep.name }
                .sortedWith(compareBy<File> { it.lastModified() }.thenBy { it.name })
        for (candidate in candidates) {
            if (remainingCount <= maxFiles && totalBytes <= maxTotalBytes) break
            val size = candidate.length()
            if (candidate.delete()) {
                remainingCount--
                totalBytes -= size
            }
        }
    }

    companion object {
        const val DEFAULT_MAX_FILES = 64
        const val DEFAULT_MAX_TOTAL_BYTES = 32L * 1024L * 1024L
        private val SAFE_DIGEST = Regex("^[A-Za-z0-9._-]{1,128}$")

        internal fun isSafeDigest(digest: String): Boolean =
            digest != "." && digest != ".." && SAFE_DIGEST.matches(digest)
    }
}
