package dev.ricky.galaxywatchmanagerfree.feature

import dev.ricky.galaxywatchmanagerfree.wcs.WcsFrame
import dev.ricky.galaxywatchmanagerfree.wcs.WcsPaths
import kotlinx.coroutines.CoroutineScope

class WatchDndControl(
    scope: CoroutineScope,
    private val watchNode: () -> String,
    private val write: (String, Map<String, Any>) -> Boolean,
    private val onValue: (Boolean) -> Unit,
    onPending: (Boolean?) -> Unit,
    private val onResult: (Result) -> Unit,
    private val now: () -> Long = System::currentTimeMillis,
    onDebug: (String) -> Unit = {},
    private val onSubmitted: (Boolean?) -> Unit = {},
    private val loadSubmitted: () -> Boolean? = { null },
    private val saveSubmitted: (Boolean?) -> Unit = {},
) {
    enum class Result {
        PENDING,
        CONFIRMED,
        SEND_FAILED,
        SOURCE_UNAVAILABLE,
        SUBMITTED,
    }

    private enum class Stage {
        IDLE,
        WRITING,
    }

    private data class Template(val uri: String, val dataMap: Map<String, Any>)

    private var connected = false
    private var disconnected = false
    private var template: Template? = null
    private var submitted: Boolean? = null
    private var stage = Stage.IDLE
    private var sourceUri: String? = null
    private var target = false
    private val path = WcsPaths.SET_PHONE_DND_TURN_ON.trimStart('/')
    private val commands =
        SettingCommands(
            scope,
            onPending = { onPending(it[path] as? Boolean) },
            onError = { failure ->
                val result =
                    when {
                        failure == SettingCommands.Failure.SEND_FAILED -> Result.SEND_FAILED
                        else -> Result.SUBMITTED
                    }
                stage = Stage.IDLE
                sourceUri = null
                onResult(result)
            },
            onConfirmed = { _, _ ->
                stage = Stage.IDLE
                sourceUri = null
                onResult(Result.CONFIRMED)
            },
            onDebug = onDebug,
        )

    fun connect() =
        synchronized(commands) {
            connected = true
            disconnected = false
            if (template?.let { WcsFrame.splitWearPath(it.uri).first == watchNode() } != true) {
                template = null
                submitted = null
            }
            submitted = loadSubmitted() ?: submitted
            onSubmitted(submitted)
        }

    fun disconnect() =
        synchronized(commands) {
            connected = false
            disconnected = true
            stage = Stage.IDLE
            sourceUri = null
            commands.clear()
            onSubmitted(null)
        }

    fun setEnabled(enabled: Boolean): Unit =
        synchronized(commands) {
            if (!connected) {
                onResult(Result.SEND_FAILED)
                return
            }
            val currentWatch = watchNode()
            if (currentWatch.isBlank()) {
                onResult(Result.SOURCE_UNAVAILABLE)
                return
            }
            target = enabled
            onResult(Result.PENDING)
            val source =
                template?.takeIf { WcsFrame.splitWearPath(it.uri).first == currentWatch }
                    ?: Template(
                        uri = "wear://$currentWatch${WcsPaths.SET_PHONE_DND_TURN_ON}",
                        dataMap = mapOf("key" to "booleanIsChecked", "type" to 0L),
                    )
            writeTemplate(source)
        }

    fun receive(uri: String, dataMap: Map<String, Any>) =
        synchronized(commands) {
            if (disconnected) return
            val (owner, itemPath) = WcsFrame.splitWearPath(uri)
            if (owner.isNullOrBlank() || owner != watchNode() || itemPath != "/$path") return
            if ((dataMap["key"] ?: "booleanIsChecked") != "booleanIsChecked") return
            val value = dataMap["booleanIsChecked"] as? Boolean ?: return
            val received = Template(uri, dataMap.toMap())
            val firstItemForWatch = template?.uri != uri
            template = received
            val fromPhone = dataMap["from"] == "phone"
            if (!fromPhone) {
                onValue(value)
                publishSubmitted(null)
            } else if (firstItemForWatch) {
                publishSubmitted(value)
            }
            if (!commands.hasPending(path)) return
            if (!fromPhone && uri == sourceUri) {
                commands.confirm(path, value)
            }
        }

    private fun writeTemplate(source: Template) {
        stage = Stage.WRITING
        sourceUri = source.uri
        // Official putDoNotDisturb writes longZenDurationEndtime only when a timed
        // end exists; "until turned off" omits it so a stale watch-side end time
        // cannot expire the command instantly.
        val updated =
            source.dataMap
                .minus("longZenDurationEndtime")
                .plus(
                    mapOf(
                        "booleanIsChecked" to target,
                        "from" to "phone",
                        "time" to now(),
                        "intZenDuration" to 0,
                    )
                )
        val sent =
            commands.submit(path, target) {
                (writeSyncGate() && write(source.uri, updated)).also { sent ->
                    if (sent) {
                        template = Template(source.uri, updated)
                        publishSubmitted(target)
                    }
                }
            }
        if (sent && commands.hasPending(path)) {
            commands.clear()
            stage = Stage.IDLE
            sourceUri = null
            onResult(Result.SUBMITTED)
        }
    }

    private fun publishSubmitted(value: Boolean?) {
        submitted = value
        // Snapshot replay precedes connect and must not erase the latest local request.
        if (connected) saveSubmitted(value)
        onSubmitted(value)
    }

    // The watch ignores dnd_turn_on_now while setting_dnd_sync_with_phone is disabled.
    private fun writeSyncGate(): Boolean =
        write(
            "wear://${watchNode()}${WcsPaths.SET_PHONE_DND_SYNC_ENABLED}",
            mapOf("booleanIsChecked" to true, "from" to "phone", "time" to now()),
        )
}
