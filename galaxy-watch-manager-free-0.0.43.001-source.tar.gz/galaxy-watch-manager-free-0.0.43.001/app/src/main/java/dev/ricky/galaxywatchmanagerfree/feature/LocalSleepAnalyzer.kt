package dev.ricky.galaxywatchmanagerfree.feature

import android.content.Context
import android.content.res.AssetManager
import android.os.Build
import dalvik.system.DexClassLoader
import java.io.File
import java.lang.reflect.Method
import java.security.MessageDigest
import kotlin.math.roundToInt
import org.json.JSONArray
import org.json.JSONObject

internal fun sleepAnalysisLog(
    status: String,
    elapsedMs: Long,
    error: Throwable? = null,
    sensorVersion: Int? = null,
): String =
    "[睡眠分析] 状态=$status" +
        (sensorVersion?.let { " ver=$it" } ?: "") +
        (error?.let { " 类别=${it.javaClass.simpleName}" } ?: "") +
        " 耗时=${elapsedMs}ms"

/**
 * Offline inference runs on the repository's IO scope. No account, network, root or external app.
 */
class LocalSleepAnalyzer(private val context: Context, peerAddress: String? = null) {
    private val prefs = DevicePreferences.open(context, "watchfree_sleep_analysis", peerAddress)
    private val tried = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()

    private fun key(record: JSONObject, raw: JSONObject): String =
        sha256((record.toString() + raw.toString() + SleepAnalysisResult.SOURCE).toByteArray())

    fun cached(record: JSONObject, raw: JSONObject): SleepParser.Session? =
        SleepParser.decode(prefs.getString(key(record, raw), null))

    fun exportResults(): JSONObject = synchronized(INFERENCE_LOCK) { retainedResults(prefs.all) }

    fun needsAnalysis(record: JSONObject, raw: JSONObject): Boolean {
        val cacheKey = key(record, raw)
        return cacheKey !in tried && SleepParser.decode(prefs.getString(cacheKey, null)) == null
    }

    fun analyze(record: JSONObject, raw: JSONObject): SleepParser.Session? =
        synchronized(INFERENCE_LOCK) {
            val cacheKey = key(record, raw)
            SleepParser.decode(prefs.getString(cacheKey, null))?.let {
                return it
            }
            if (!tried.add(cacheKey)) return null
            val began = System.nanoTime()
            var sensorVersion: Int? = null
            runCatching {
                    val source = SleepParser.sessions(listOf(record)).single()
                    val body = decodeRawPayload(raw)
                    val rawJson = JSONObject(body)
                    val version = rawJson.optInt("version", raw.optInt("version", 0))
                    sensorVersion = version.takeIf { it > 0 }
                    val engine = loadEngine()
                    val resultJson =
                        when (version) {
                            VERSION_8ACC ->
                                JSONObject(
                                    engine.analyzeV2.invoke(
                                        null,
                                        engine.context,
                                        record.toString(),
                                        body,
                                    ) as String
                                )
                            VERSION_7ACC -> analyze7Acc(record, rawJson, engine.sleep7Acc)
                            else ->
                                throw IllegalArgumentException("Unsupported sleep sensor version")
                        }
                    val session = SleepAnalysisResult.apply(source, resultJson)
                    check(prefs.edit().putString(cacheKey, SleepParser.encode(session)).commit()) {
                        "Sleep analysis cache write failed"
                    }
                    LogBus.log(
                        sleepAnalysisLog(
                            "完成",
                            (System.nanoTime() - began) / 1_000_000,
                            sensorVersion = sensorVersion,
                        )
                    )
                    session
                }
                .onFailure {
                    val reason =
                        (it as? java.lang.reflect.InvocationTargetException)?.targetException ?: it
                    LogBus.log(
                        sleepAnalysisLog(
                            "暂不可用",
                            (System.nanoTime() - began) / 1_000_000,
                            reason,
                            sensorVersion = sensorVersion,
                        )
                    )
                }
                .getOrNull()
        }

    internal interface Sleep7AccNative {
        fun init()

        fun feedEpoch(acc: DoubleArray, rri: DoubleArray)

        fun predictStages(): IntArray

        fun efficiency(stages: IntArray): Int
    }

    private data class LoadedEngine(
        val context: Context,
        val analyzeV2: Method,
        val sleep7Acc: Sleep7AccNative,
    )

    private fun loadEngine(): LoadedEngine =
        synchronized(ENGINE_LOCK) {
            sharedEngine?.let {
                return it
            }
            val manifest =
                JSONObject(
                    context.assets.open("sleep/manifest.json").bufferedReader().use {
                        it.readText()
                    }
                )
            val files = manifest.getJSONObject("files")
            val abi =
                Build.SUPPORTED_ABIS.firstOrNull { files.has("$it/libmobilesleepjni.so") }
                    ?: error("This CPU has no sleep inference runtime")
            val root =
                File(context.codeCacheDir, "sleep-engine-${files.getString("engine.jar").take(16)}")
                    .apply { mkdirs() }
            fun extract(name: String): File {
                val target = File(root, name.substringAfterLast('/'))
                if (target.isFile && sha256(target.readBytes()) == files.getString(name))
                    return target
                val bytes = context.assets.open("sleep/$name").use { it.readBytes() }
                check(sha256(bytes) == files.getString(name)) { "Sleep engine integrity mismatch" }
                val temporary = File(root, target.name + ".tmp")
                temporary.delete()
                temporary.outputStream().use { out ->
                    check(temporary.setReadOnly())
                    out.write(bytes)
                    out.fd.sync()
                }
                check(temporary.renameTo(target))
                return target
            }
            val jar = extract("engine.jar")
            extract("$abi/libmobilesleepjni.so")
            extract("$abi/libtensorflowlite_jni.so")
            val loader = DexClassLoader(jar.path, root.path, root.path, context.classLoader)
            val type = loader.loadClass("GalaxySleepEngine")
            val sleepInterfaceType =
                loader.loadClass("com.samsung.msleepstagelib.stages.SleepInterface")
            val assets = AssetManager::class.java.getDeclaredConstructor().newInstance()
            val cookie =
                AssetManager::class
                    .java
                    .getMethod("addAssetPath", String::class.java)
                    .invoke(assets, jar.path) as Int
            check(cookie != 0) { "Sleep model assets could not be opened" }
            val engineContext =
                object : android.content.ContextWrapper(context) {
                    override fun getAssets(): AssetManager = assets
                }
            val analyzeV2 =
                type.getMethod(
                    "analyze",
                    Context::class.java,
                    String::class.java,
                    String::class.java,
                )
            val initMethod = sleepInterfaceType.getMethod("i")
            val feedMethod =
                sleepInterfaceType.getMethod("c", DoubleArray::class.java, DoubleArray::class.java)
            val predictMethod = sleepInterfaceType.getMethod("h")
            val efficiencyMethod = sleepInterfaceType.getMethod("a", IntArray::class.java)
            val sleep7Acc =
                object : Sleep7AccNative {
                    override fun init() {
                        initMethod.invoke(null)
                    }

                    override fun feedEpoch(acc: DoubleArray, rri: DoubleArray) {
                        feedMethod.invoke(null, acc, rri)
                    }

                    override fun predictStages(): IntArray =
                        (predictMethod.invoke(null) as? IntArray)
                            ?: throw IllegalStateException("Sleep 7-ACC native stage array is null")

                    override fun efficiency(stages: IntArray): Int =
                        efficiencyMethod.invoke(null, stages) as Int
                }
            LoadedEngine(engineContext, analyzeV2, sleep7Acc).also { sharedEngine = it }
        }

    companion object {
        const val VERSION_7ACC = 1
        const val VERSION_8ACC = 2
        private const val MAX_RAW_JSON_BYTES = 8 * 1024 * 1024
        private const val MAX_EPOCHS_7ACC = 1440
        private const val ACC_FEATURES_7ACC = 7
        private const val MAX_RRI_PER_EPOCH_7ACC = 177
        private const val RRI_INVALID_SENTINEL = 65535
        private const val TRAILING_WAKE_THRESHOLD_7ACC = 5
        private const val TRAILING_WAKE_KEEP = 2

        private val ENGINE_LOCK = Any()
        private val INFERENCE_LOCK = Any()
        @Volatile private var sharedEngine: LoadedEngine? = null

        /**
         * Decodes `com.samsung.shealth.sleep_raw_data.data` supporting both Base64(gzip(JSON))
         * (`blob_compression=true`) and plain UTF-8 JSON (`blob_compression=false`).
         */
        internal fun decodeRawPayload(raw: JSONObject): String {
            val field = raw.opt("data")
            if (field is JSONObject) {
                val text = field.toString()
                require(text.toByteArray(Charsets.UTF_8).size <= MAX_RAW_JSON_BYTES) {
                    "Sleep raw payload exceeds $MAX_RAW_JSON_BYTES bytes"
                }
                return text
            }
            val encoded = (field as? String)?.trim().orEmpty()
            require(encoded.isNotBlank()) { "Sleep raw payload is missing" }
            if (encoded.startsWith("{")) {
                require(encoded.toByteArray(Charsets.UTF_8).size <= MAX_RAW_JSON_BYTES) {
                    "Sleep raw payload exceeds $MAX_RAW_JSON_BYTES bytes"
                }
                return encoded
            }
            return HealthJson.inflateJson(encoded, MAX_RAW_JSON_BYTES)
        }

        /**
         * Executes Samsung Health's `modelVersion = 0` (`tn70` / 7-ACC / 60s epoch) pipeline using
         * the bundled `SleepInterface` (`libmobilesleepjni.so`). Rescues `version = 1` sleep raw
         * records captured by Watch Samsung Health 7.1.x before `sleep_message` negotiation.
         */
        internal fun analyze7Acc(
            session: JSONObject,
            raw: JSONObject,
            native: Sleep7AccNative,
        ): JSONObject {
            require(raw.optInt("version") == VERSION_7ACC) {
                "Unsupported sleep sensor version for 7-ACC"
            }
            val data = raw.getJSONArray("data")
            val epochCount = data.length()
            require(epochCount in 1 until MAX_EPOCHS_7ACC) { "Invalid 7-ACC sleep epoch count" }

            val start =
                positiveLong(session, "original_bed_time")
                    ?: positiveLong(session, "start_time")
                    ?: positiveLong(session, "com.samsung.health.sleep.start_time")
                    ?: throw IllegalArgumentException("Missing sleep start time")
            val end =
                positiveLong(session, "original_wake_up_time")?.takeIf { it > start }
                    ?: positiveLong(session, "end_time")
                    ?: positiveLong(session, "com.samsung.health.sleep.end_time")
                    ?: throw IllegalArgumentException("Missing sleep end time")
            val durationMs = end - start
            require(durationMs > 0L) { "Wake up time must be after bed time" }

            val epochMs = SleepAnalysisResult.EPOCH_MS_7ACC
            val targetEpochs = (durationMs / epochMs).toInt()
            require(targetEpochs in 1 until MAX_EPOCHS_7ACC) { "7-ACC sleep data is too long" }

            val bedDelay = session.optLong("bedtime_detection_delay", 0L)
            val wakeupDelay = session.optLong("wakeup_time_detection_delay", 0L)

            native.init()
            var totalRriCount = 0
            var invalidMinusOneCount = 0
            var zeroRriCount = 0

            for (i in 0 until epochCount) {
                val point = data.getJSONObject(i)
                val accArray = point.getJSONArray("acc")
                require(accArray.length() >= ACC_FEATURES_7ACC) { "Invalid 7-ACC feature length" }
                val acc = DoubleArray(ACC_FEATURES_7ACC) { idx -> accArray.getDouble(idx) }

                val rriArray = point.getJSONArray("rri_info")
                val rriLen = rriArray.length()
                require(rriLen <= MAX_RRI_PER_EPOCH_7ACC) { "RRI in a 7-ACC epoch is too long" }
                totalRriCount += rriLen

                val packedRri = DoubleArray(rriLen * 2 + 1)
                packedRri[0] = (rriLen * 2).toDouble()
                for (k in 0 until rriLen) {
                    val triple = rriArray.getJSONArray(k)
                    val dt = triple.getInt(1)
                    val rawRri = triple.getInt(2)
                    val rri = if (rawRri == RRI_INVALID_SENTINEL) -1 else rawRri
                    packedRri[1 + k * 2] = dt.toDouble()
                    packedRri[2 + k * 2] = rri.toDouble()
                    if (rri == -1) invalidMinusOneCount++
                    if (rri == 0) zeroRriCount++
                }
                native.feedEpoch(acc, packedRri)
            }

            val rawStages = native.predictStages()
            require(rawStages.isNotEmpty()) { "Sleep 7-ACC native output is empty" }

            val resampledLen = ((durationMs + wakeupDelay - bedDelay) / epochMs).toInt()
            val resampled =
                if (resampledLen <= 0) {
                    rawStages.copyOf()
                } else {
                    val ratio = epochCount.toFloat() / resampledLen.toFloat()
                    IntArray(resampledLen) { idx ->
                        val mapped = (idx * ratio).roundToInt().coerceIn(0, rawStages.lastIndex)
                        rawStages[mapped]
                    }
                }

            var leadCount = (bedDelay / epochMs).toInt().coerceAtLeast(0)
            if (targetEpochs > resampled.size + leadCount) {
                leadCount += targetEpochs - (resampled.size + leadCount)
            }
            val aligned =
                IntArray(targetEpochs) { idx ->
                    if (idx < leadCount) 1
                    else resampled[(idx - leadCount).coerceIn(0, resampled.lastIndex)]
                }

            var trailingWake = 0
            for (idx in targetEpochs - 1 downTo 0) {
                if (aligned[idx] == 2) trailingWake++ else break
            }
            val finalStages =
                if (trailingWake > TRAILING_WAKE_THRESHOLD_7ACC) {
                    val trimmedLen =
                        (targetEpochs - (trailingWake - TRAILING_WAKE_KEEP)).coerceAtLeast(1)
                    aligned.copyOf(trimmedLen)
                } else {
                    aligned
                }

            val validRriCount = totalRriCount - invalidMinusOneCount
            val isFourStage = zeroRriCount.toDouble() <= validRriCount.toDouble() * 0.7
            check(isFourStage && finalStages.isNotEmpty()) {
                "Sleep 7-ACC inference returned no four-stage result"
            }

            val nativeEfficiency = native.efficiency(finalStages)
            val stages = JSONArray()
            for (idx in finalStages.indices) {
                stages.put(JSONArray().put(start + idx * epochMs).put(finalStages[idx]))
            }
            return JSONObject()
                .put("native_efficiency", nativeEfficiency)
                .put("epoch_ms", epochMs)
                .put("source", SleepAnalysisResult.SOURCE_7ACC)
                .put("stages", stages)
        }

        private fun positiveLong(obj: JSONObject, key: String): Long? =
            if (obj.has(key) && !obj.isNull(key)) obj.optLong(key, 0L).takeIf { it > 0L } else null

        internal fun retainedResults(values: Map<String, *>): JSONObject =
            JSONObject().apply {
                values.toSortedMap().forEach { (key, value) ->
                    val encoded = value as? String ?: return@forEach
                    val parsed = runCatching { JSONObject(encoded) }.getOrNull() ?: return@forEach
                    put(key, parsed)
                }
            }

        private fun sha256(bytes: ByteArray): String =
            MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") {
                "%02x".format(it.toInt() and 255)
            }
    }
}
