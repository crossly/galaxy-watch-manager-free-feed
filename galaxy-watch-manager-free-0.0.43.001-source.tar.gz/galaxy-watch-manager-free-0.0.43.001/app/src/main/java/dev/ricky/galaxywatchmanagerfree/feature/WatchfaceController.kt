package dev.ricky.galaxywatchmanagerfree.feature

import dev.ricky.galaxywatchmanagerfree.wcs.WcsPaths
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONObject

/**
 * Owns `/wcs_extension/sysui/watchface` queries, commands, delayed readback confirmation, and state
 * transitions along the stable watchface protocol boundary.
 */
internal class WatchfaceController(
    private val scope: CoroutineScope,
    private val state: MutableStateFlow<WatchState>,
    private val sendJson: (path: String, msgId: String, msgType: Int, data: JSONObject) -> Boolean,
    private val onWatchfaceConfirmed: () -> Unit,
    private val onOrderConfirmed: () -> Unit,
    private val onPersistSnapshot: () -> Unit,
    private val onLog: (String) -> Unit = {},
    private val onDebug: (() -> String) -> Unit = {},
    private val onError: (String, Throwable) -> Unit = { _, _ -> },
    private val nowMillis: () -> Long = System::currentTimeMillis,
    private val activateConfirmDelayMs: Long = 800L,
    private val orderConfirmDelayMs: Long = 700L,
) {
    private val _order = MutableStateFlow<List<Int>>(emptyList())
    val order: StateFlow<List<Int>> = _order.asStateFlow()

    @Volatile private var activeConfirmJob: Job? = null
    @Volatile private var orderConfirmJob: Job? = null

    fun syncRestoredOrder(ids: List<Int>) {
        _order.value = ids
    }

    fun requestOrder() {
        onDebug { "[表盘→] 查询表盘收藏列表" }
        sendJson(WcsPaths.WATCHFACE_SYSUI, WcsPaths.MSG_WATCHFACE_ORDER, 0, JSONObject())
    }

    fun requestActive() {
        onDebug { "[表盘→] 查询当前活跃表盘" }
        sendJson(WcsPaths.WATCHFACE_SYSUI, WcsPaths.MSG_CHANGE_ACTIVE_WATCHFACE, 0, JSONObject())
    }

    fun setActive(pkg: String, cls: String): Boolean {
        if (!state.value.sessionReady) return false
        val name = WatchFacePresets.find(pkg, cls)?.enName ?: pkg
        onLog("[表盘→] 切换表盘为 $name ($pkg)")
        val payload = JSONObject().put("packageName", pkg).put("className", cls)
        val queued =
            sendJson(WcsPaths.WATCHFACE_SYSUI, WcsPaths.MSG_CHANGE_ACTIVE_WATCHFACE, 1, payload)
        onDebug { "[表盘] activate package=$pkg class=$cls queued=$queued" }
        if (!queued) return false

        // Keep the last confirmed face visible until a valid query/state response arrives.
        // 800ms 后向手表查询确认实际生效状态
        activeConfirmJob?.cancel()
        activeConfirmJob =
            scope.launch {
                delay(activateConfirmDelayMs)
                runCatching { requestActive() }.onFailure { onError("[表盘] 查询确认失败", it) }
            }
        return true
    }

    /**
     * 设置表盘排序方式。
     *
     * 手表端 `WatchfaceApiStub.setWatchfaceOrderTypeWithSync(type)` 的映射： 0 →
     * {"isWatchSortByRecentsEnabled":false,"WatchFaceOrderType":"custom"} 1 →
     * {"isWatchSortByRecentsEnabled":true ,"WatchFaceOrderType":"recent"} 2 →
     * {"isWatchSortByRecentsEnabled":false,"WatchFaceOrderType":"alphabetic"} msgType=1 为写请求；手表处理后回
     * msgType=3 + result。
     */
    fun setOrderType(mode: String): Boolean {
        val type =
            when (mode) {
                WcsPaths.ORDER_TYPE_RECENT -> 1
                WcsPaths.ORDER_TYPE_ALPHABETIC -> 2
                else -> 0
            }
        val payload =
            JSONObject()
                .put("isWatchSortByRecentsEnabled", type == 1)
                .put("WatchFaceOrderType", mode)
        onLog("[表盘→] 设置排序方式：$mode (type=$type)")
        sendJson(WcsPaths.WATCHFACE_SYSUI, WcsPaths.MSG_WATCHFACE_ORDER_TYPE, 1, payload)
        orderConfirmJob?.cancel()
        orderConfirmJob =
            scope.launch {
                delay(orderConfirmDelayMs)
                runCatching { requestOrder() }.onFailure { onError("[表盘] 排序确认失败", it) }
            }
        return true
    }

    fun clearEditRequest() {
        state.update { it.copy(watchfaceEditRequested = false) }
    }

    fun handleMessage(json: JSONObject) {
        val msgId = json.optString("msgId")
        val msgType = json.optInt("msgType", -1)
        val data = json.optJSONObject("data") ?: JSONObject()
        when (msgId) {
            WcsPaths.MSG_CHANGE_ACTIVE_WATCHFACE,
            "change_active_watchface" -> {
                val now = nowMillis()
                val before = state.value
                state.update { DeviceSnapshot.applyWatchface(it, json, now) }
                val updated = state.value
                if (updated.watchfaceUpdatedAt != before.watchfaceUpdatedAt) {
                    onWatchfaceConfirmed()
                    onPersistSnapshot()
                    onLog("[表盘] 当前活跃表盘：${updated.activeWatchfacePkg}")
                }
            }
            WcsPaths.MSG_WATCHFACE_ORDER,
            "watchface_order" -> {
                val arr = data.optJSONArray("favoriteIdOrderList")
                val orderType = data.optString("WatchFaceOrderType").ifBlank { null }
                val list =
                    if (arr != null) (0 until arr.length()).map { arr.optInt(it) } else emptyList()
                _order.value = list
                state.update {
                    it.copy(watchfaceOrderType = orderType, watchfaceFavoriteIds = list)
                }
                if (arr != null || orderType != null) {
                    onOrderConfirmed()
                    onPersistSnapshot()
                }
                onDebug { "[表盘] 收藏表盘列表：$list, orderType=$orderType" }
            }
            WcsPaths.MSG_WATCHFACE_ORDER_TYPE -> {
                val orderType = data.optString("WatchFaceOrderType").ifBlank { null }
                val result = json.optInt("result", 0)
                if (msgType == 3) {
                    onLog("[表盘] 排序方式写入回执 result=$result orderType=${orderType ?: "-"}")
                }
            }
            WcsPaths.MSG_WATCHFACE_LAUNCH -> {
                if (msgType == 3) {
                    val result = json.optInt("result", 0)
                    val reason = json.optInt("reason", 0)
                    onLog("[表盘] 编辑请求回执 result=$result reason=$reason")
                } else {
                    // 手表请求手机侧打开表盘编辑器：我们无法远程编辑，改为提示用户在手表上操作
                    onLog("[表盘] 手表请求「在手机上编辑表盘」(msgType=$msgType)")
                    state.update { it.copy(watchfaceEditRequested = true) }
                }
            }
            WcsPaths.MSG_ADDABLE_WATCHFACE_INFO -> {
                val badges = data.optString("watchfaceBadgeList").ifBlank { null }
                onLog("[表盘] 可添加表盘信息：badges=${badges ?: "-"}")
            }
        }
    }

    fun cancelPending() {
        activeConfirmJob?.cancel()
        activeConfirmJob = null
        orderConfirmJob?.cancel()
        orderConfirmJob = null
    }
}
