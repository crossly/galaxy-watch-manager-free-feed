package dev.ricky.galaxywatchmanagerfree.ui.screens

import android.text.format.DateFormat
import androidx.annotation.StringRes
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Watch
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.core.UiNotify
import dev.ricky.galaxywatchmanagerfree.feature.EnergyScoreCalculation
import dev.ricky.galaxywatchmanagerfree.feature.EnergyScoreLog
import dev.ricky.galaxywatchmanagerfree.feature.EnergyScoreProfile
import dev.ricky.galaxywatchmanagerfree.feature.EnergyScoreSync
import dev.ricky.galaxywatchmanagerfree.feature.LogBus
import dev.ricky.galaxywatchmanagerfree.feature.WatchState
import dev.ricky.galaxywatchmanagerfree.ui.components.AppBottomSheet
import dev.ricky.galaxywatchmanagerfree.ui.components.GroupedCard
import dev.ricky.galaxywatchmanagerfree.ui.components.GroupedCardRow
import dev.ricky.galaxywatchmanagerfree.ui.components.SectionHeader
import dev.ricky.galaxywatchmanagerfree.ui.components.SheetToolbar
import dev.ricky.galaxywatchmanagerfree.ui.theme.CardBorder
import dev.ricky.galaxywatchmanagerfree.ui.theme.CardSurface
import dev.ricky.galaxywatchmanagerfree.ui.theme.CardSurfaceElevated
import dev.ricky.galaxywatchmanagerfree.ui.theme.EmeraldCharging
import dev.ricky.galaxywatchmanagerfree.ui.theme.HealthHeart
import dev.ricky.galaxywatchmanagerfree.ui.theme.HealthHrv
import dev.ricky.galaxywatchmanagerfree.ui.theme.HealthSleep
import dev.ricky.galaxywatchmanagerfree.ui.theme.HealthSteps
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextPrimary
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextSecondary
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextTertiary
import dev.ricky.galaxywatchmanagerfree.ui.theme.WarningAmber
import dev.ricky.galaxywatchmanagerfree.ui.theme.tonalSurface
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import kotlin.math.roundToInt
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

@StringRes
private fun energyBand(score: Double): Int =
    when {
        score >= 85 -> R.string.energy_score_excellent
        score >= 75 -> R.string.energy_score_good
        score >= 60 -> R.string.energy_score_fair
        else -> R.string.energy_score_attention
    }

@StringRes
private fun energySyncLabel(status: EnergyScoreSync.Status): Int =
    when (status) {
        EnergyScoreSync.Status.IDLE -> R.string.energy_score_unconfirmed
        EnergyScoreSync.Status.WAITING_ACK -> R.string.energy_score_waiting
        EnergyScoreSync.Status.ACCEPTED -> R.string.energy_score_accepted
        EnergyScoreSync.Status.SEND_FAILED -> R.string.energy_score_send_failed
        EnergyScoreSync.Status.SAVE_FAILED -> R.string.energy_score_ack_save_failed
        EnergyScoreSync.Status.REJECTED -> R.string.energy_score_rejected
        EnergyScoreSync.Status.TIMED_OUT -> R.string.energy_score_timeout
        EnergyScoreSync.Status.DISCONNECTED -> R.string.energy_score_disconnected
    }

@Composable
fun EnergyScoreCard(
    record: EnergyScoreLog.Record?,
    wide: Boolean = false,
    today: LocalDate = LocalDate.now(),
    onClick: () -> Unit,
) {
    val locale = LocalConfiguration.current.locales[0]
    val shortDateFormat =
        remember(locale) {
            DateTimeFormatter.ofPattern(DateFormat.getBestDateTimePattern(locale, "MMMd"), locale)
        }
    val unit =
        if (record == null) {
            stringResource(R.string.energy_score_local)
        } else {
            val band = stringResource(energyBand(record.totalScore))
            val recordDate = runCatching { LocalDate.parse(record.date) }.getOrNull()
            if (recordDate != null && recordDate != today) {
                stringResource(
                    R.string.energy_score_card_dated,
                    band,
                    recordDate.format(shortDateFormat),
                )
            } else {
                band
            }
        }
    HealthSummary(
        title = stringResource(R.string.energy_score),
        value = record?.totalScore?.roundToInt()?.toString() ?: "—",
        unit = unit,
        icon = Icons.Default.Bolt,
        accent = HealthSteps,
        modifier = Modifier.fillMaxWidth().testTag("energy_score_card"),
        wide = wide,
        onClick = onClick,
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EnergyScoreSheet(
    state: WatchState,
    onDismiss: () -> Unit,
    onSaveProfile: (Int, Boolean) -> Boolean,
    onCalculate: (Int, Boolean) -> EnergyScoreCalculation?,
    onWrite: (String) -> Boolean,
    today: LocalDate = LocalDate.now(),
) {
    val scope = rememberCoroutineScope()
    val resources = LocalContext.current.resources
    val locale = LocalConfiguration.current.locales[0]
    val dateFormat =
        remember(locale) {
            DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM).withLocale(locale)
        }
    var selectedId by rememberSaveable { mutableStateOf<String?>(null) }
    var calculating by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }
    val savedProfile = state.energyProfile
    var editingProfile by
        rememberSaveable(savedProfile == null) { mutableStateOf(savedProfile == null) }
    var ageText by
        rememberSaveable(savedProfile) { mutableStateOf(savedProfile?.age?.toString().orEmpty()) }
    var female by rememberSaveable(savedProfile) { mutableStateOf(savedProfile?.female) }
    val age = ageText.toIntOrNull()?.takeIf { it in 18..99 }
    val ageError = ageText.isNotEmpty() && age == null
    val dirty =
        savedProfile != null &&
            (age != savedProfile.age || female == null || female != savedProfile.female)
    val busy =
        calculating || saving || state.energyScoreSyncStatus == EnergyScoreSync.Status.WAITING_ACK
    val records = remember(state.energyScores) { state.energyScores.sortedByDescending { it.date } }
    val selected = records.firstOrNull { it.id == selectedId } ?: records.firstOrNull()
    val hasTodayScore =
        remember(records, today) {
            records.any { runCatching { LocalDate.parse(it.date) }.getOrNull() == today }
        }

    fun runSaveProfile(targetAge: Int, targetFemale: Boolean) {
        saving = true
        scope.launch {
            try {
                val saved = withContext(Dispatchers.IO) { onSaveProfile(targetAge, targetFemale) }
                if (saved) editingProfile = false
                UiNotify.show(
                    resources.getString(
                        if (saved) R.string.energy_score_profile_saved_toast
                        else R.string.energy_score_profile_save_failed
                    )
                )
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                LogBus.error("[能量] 资料保存异常", error)
                UiNotify.show(resources.getString(R.string.energy_score_profile_save_failed))
            } finally {
                saving = false
            }
        }
    }

    fun runCalculate(targetAge: Int, targetFemale: Boolean) {
        calculating = true
        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) { onCalculate(targetAge, targetFemale) }
                if (result != null) editingProfile = false
                val message =
                    when {
                        result == null ->
                            resources.getString(R.string.energy_score_calculate_failed)
                        result.calculated == 0 ->
                            resources.getString(R.string.energy_score_profile_saved_no_data)
                        result.missing > 0 ->
                            resources.getQuantityString(
                                R.plurals.energy_score_calculated_partial,
                                result.calculated,
                                result.calculated,
                                result.missing,
                            )
                        else ->
                            resources.getQuantityString(
                                R.plurals.energy_score_calculated,
                                result.calculated,
                                result.calculated,
                            )
                    }
                UiNotify.show(message)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                LogBus.error("[能量] 手动计算异常", error)
                UiNotify.show(resources.getString(R.string.energy_score_calculate_failed))
            } finally {
                calculating = false
            }
        }
    }

    AppBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
    ) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
            SheetToolbar(stringResource(R.string.energy_score), onDismiss)
            LazyColumn(
                Modifier.fillMaxWidth().testTag("energy_score_detail"),
                contentPadding = PaddingValues(top = 8.dp, bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                item {
                    EnergyScoreHeroCard(
                        record = selected,
                        hasSavedProfile = savedProfile != null,
                        dateFormat = dateFormat,
                    )
                }
                item {
                    if (savedProfile != null && !editingProfile) {
                        SavedProfileSummaryCard(
                            profile = savedProfile,
                            busy = busy,
                            onEdit = {
                                ageText = savedProfile.age.toString()
                                female = savedProfile.female
                                editingProfile = true
                            },
                        )
                    } else {
                        ProfileEditorCard(
                            savedProfile = savedProfile,
                            ageText = ageText,
                            age = age,
                            ageError = ageError,
                            female = female,
                            dirty = dirty,
                            busy = busy,
                            saving = saving,
                            calculating = calculating,
                            onAgeTextChange = {
                                if (it.length <= 2 && it.all(Char::isDigit)) ageText = it
                            },
                            onStepAge = { delta ->
                                val base = age ?: savedProfile?.age ?: 30
                                ageText = (base + delta).coerceIn(18, 99).toString()
                            },
                            onFemaleChange = { female = it },
                            onCancel =
                                savedProfile?.let { current ->
                                    {
                                        ageText = current.age.toString()
                                        female = current.female
                                        editingProfile = false
                                    }
                                },
                            onSave = {
                                runSaveProfile(requireNotNull(age), requireNotNull(female))
                            },
                            onCalculate = {
                                runCalculate(requireNotNull(age), requireNotNull(female))
                            },
                        )
                    }
                }
                selected?.let { record ->
                    item { EnergyScoreFactorsSection(record = record, locale = locale) }
                }
                item {
                    EnergyScoreSyncCard(
                        savedProfile = savedProfile,
                        editingProfile = editingProfile,
                        selected = selected,
                        today = today,
                        hasTodayScore = hasTodayScore,
                        dateFormat = dateFormat,
                        sessionReady = state.sessionReady,
                        syncStatus = state.energyScoreSyncStatus,
                        busy = busy,
                        calculating = calculating,
                        onRecalculate = { profile -> runCalculate(profile.age, profile.female) },
                        onWrite = { id ->
                            scope.launch {
                                if (!withContext(Dispatchers.IO) { onWrite(id) }) {
                                    UiNotify.show(
                                        resources.getString(R.string.energy_score_send_failed)
                                    )
                                }
                            }
                        },
                    )
                }
                if (records.isNotEmpty()) {
                    item { SectionHeader(stringResource(R.string.history_2)) }
                    items(records, key = { it.id }) { record ->
                        val isSelected = record.id == selected?.id
                        GroupedCard(
                            cornerRadius = 18.dp,
                            innerPadding = 0.dp,
                            backgroundColor =
                                if (isSelected) tonalSurface(HealthSteps, 0.12f) else CardSurface,
                            borderColor =
                                if (isSelected) HealthSteps.copy(alpha = 0.45f)
                                else Color.Transparent,
                        ) {
                            val bandLabel = stringResource(energyBand(record.totalScore))
                            val ackSuffix =
                                if (record.acknowledged)
                                    " · " + stringResource(R.string.energy_score_accepted)
                                else ""
                            GroupedCardRow(
                                title = LocalDate.parse(record.date).format(dateFormat),
                                subtitle = bandLabel + ackSuffix,
                                onClick = { selectedId = record.id },
                                trailing = {
                                    Text(
                                        record.totalScore.roundToInt().toString(),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) HealthSteps else TextPrimary,
                                    )
                                },
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EnergyScoreHeroCard(
    record: EnergyScoreLog.Record?,
    hasSavedProfile: Boolean,
    dateFormat: DateTimeFormatter,
) {
    GroupedCard(
        cornerRadius = 24.dp,
        innerPadding = 18.dp,
        backgroundColor = tonalSurface(HealthSteps),
        accent = HealthSteps,
    ) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(
                stringResource(R.string.energy_score_local),
                color = TextSecondary,
                style = MaterialTheme.typography.labelMedium,
                modifier = Modifier.weight(1f),
            )
            if (record != null) {
                Text(
                    LocalDate.parse(record.date).format(dateFormat),
                    color = TextSecondary,
                    style = MaterialTheme.typography.labelMedium,
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        if (record != null) {
            Row(
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Text(
                    record.totalScore.roundToInt().toString(),
                    color = TextPrimary,
                    style = MaterialTheme.typography.displayMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.testTag("energy_score_value"),
                )
                Text(
                    "/ 100",
                    color = TextSecondary,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(bottom = 6.dp),
                )
                Spacer(Modifier.weight(1f))
                StatusPill(
                    text = stringResource(energyBand(record.totalScore)),
                    tint = HealthSteps,
                    modifier = Modifier.padding(bottom = 6.dp),
                )
            }
            Spacer(Modifier.height(12.dp))
            LinearProgressIndicator(
                progress = { (record.totalScore / 100.0).toFloat().coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape),
                color = HealthSteps,
                trackColor = CardSurfaceElevated,
                gapSize = 0.dp,
                drawStopIndicator = {},
            )
            Spacer(Modifier.height(10.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Icon(
                    imageVector =
                        if (record.acknowledged) Icons.Default.CheckCircle else Icons.Default.Watch,
                    contentDescription = null,
                    tint = if (record.acknowledged) EmeraldCharging else TextSecondary,
                    modifier = Modifier.size(16.dp),
                )
                Text(
                    stringResource(
                        if (record.acknowledged) R.string.energy_score_accepted
                        else R.string.energy_score_unconfirmed
                    ),
                    color = if (record.acknowledged) EmeraldCharging else TextSecondary,
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        } else {
            Text(
                stringResource(
                    if (hasSavedProfile) R.string.energy_score_empty
                    else R.string.energy_score_empty_need_profile
                ),
                color = TextSecondary,
                style = MaterialTheme.typography.bodyMedium,
            )
        }
    }
}

@Composable
private fun SavedProfileSummaryCard(
    profile: EnergyScoreProfile,
    busy: Boolean,
    onEdit: () -> Unit,
) {
    GroupedCard(
        cornerRadius = 24.dp,
        innerPadding = 16.dp,
        modifier = Modifier.testTag("energy_score_profile_summary"),
    ) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Box(
                Modifier.size(36.dp).clip(CircleShape).background(HealthSteps.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    Icons.Default.Person,
                    contentDescription = null,
                    tint = HealthSteps,
                    modifier = Modifier.size(20.dp),
                )
            }
            Column(Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text(
                        stringResource(R.string.energy_score_profile_title),
                        style = MaterialTheme.typography.titleSmall,
                        color = TextPrimary,
                    )
                    StatusPill(
                        text = stringResource(R.string.energy_score_profile_saved_badge),
                        tint = EmeraldCharging,
                    )
                }
                Spacer(Modifier.height(2.dp))
                Text(
                    stringResource(R.string.energy_score_profile_saved_summary_subtitle),
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                )
            }
            TextButton(
                onClick = onEdit,
                enabled = !busy,
                modifier = Modifier.testTag("energy_score_profile_edit"),
            ) {
                Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text(stringResource(R.string.energy_score_profile_edit))
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ProfileValueTile(
                label = stringResource(R.string.energy_score_age),
                value = stringResource(R.string.energy_score_age_value, profile.age),
                valueTag = "energy_score_saved_age",
                modifier = Modifier.weight(1f),
            )
            ProfileValueTile(
                label = stringResource(R.string.energy_score_sex_label),
                value =
                    stringResource(
                        if (profile.female) R.string.energy_score_female
                        else R.string.energy_score_male
                    ),
                valueTag = "energy_score_saved_sex",
                modifier = Modifier.weight(1f),
            )
        }
    }
}

@Composable
private fun ProfileValueTile(
    label: String,
    value: String,
    valueTag: String,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(CardSurfaceElevated)
            .padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        Spacer(Modifier.height(4.dp))
        Text(
            value,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            color = TextPrimary,
            modifier = Modifier.testTag(valueTag),
        )
    }
}

@Composable
private fun ProfileEditorCard(
    savedProfile: EnergyScoreProfile?,
    ageText: String,
    age: Int?,
    ageError: Boolean,
    female: Boolean?,
    dirty: Boolean,
    busy: Boolean,
    saving: Boolean,
    calculating: Boolean,
    onAgeTextChange: (String) -> Unit,
    onStepAge: (Int) -> Unit,
    onFemaleChange: (Boolean) -> Unit,
    onCancel: (() -> Unit)?,
    onSave: () -> Unit,
    onCalculate: () -> Unit,
) {
    GroupedCard(
        cornerRadius = 24.dp,
        innerPadding = 16.dp,
        modifier = Modifier.testTag("energy_score_profile_editor"),
    ) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Box(
                Modifier.size(36.dp).clip(CircleShape).background(HealthSteps.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    Icons.Default.Person,
                    contentDescription = null,
                    tint = HealthSteps,
                    modifier = Modifier.size(20.dp),
                )
            }
            Column(Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text(
                        stringResource(R.string.energy_score_profile_title),
                        style = MaterialTheme.typography.titleSmall,
                        color = TextPrimary,
                    )
                    StatusPill(
                        text =
                            stringResource(
                                if (savedProfile == null)
                                    R.string.energy_score_profile_not_set_badge
                                else R.string.energy_score_profile_saved_badge
                            ),
                        tint = if (savedProfile == null) TextSecondary else EmeraldCharging,
                    )
                }
                Spacer(Modifier.height(2.dp))
                Text(
                    stringResource(
                        when {
                            savedProfile == null -> R.string.energy_score_profile_not_saved
                            dirty -> R.string.energy_score_profile_unsaved_changes
                            else -> R.string.energy_score_profile_saved
                        }
                    ),
                    color = if (dirty) WarningAmber else TextSecondary,
                    style = MaterialTheme.typography.bodySmall,
                )
            }
            if (onCancel != null) {
                TextButton(onClick = onCancel, enabled = !busy) {
                    Text(stringResource(R.string.cancel))
                }
            }
        }
        if (savedProfile != null) {
            Spacer(Modifier.height(10.dp))
            Box(
                Modifier.fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(CardSurfaceElevated)
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Text(
                    stringResource(
                        R.string.energy_score_profile_current_summary,
                        savedProfile.age,
                        stringResource(
                            if (savedProfile.female) R.string.energy_score_female
                            else R.string.energy_score_male
                        ),
                    ),
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    modifier = Modifier.testTag("energy_score_profile_current"),
                )
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(
                stringResource(R.string.energy_score_age),
                style = MaterialTheme.typography.labelLarge,
                color = TextPrimary,
            )
            Text(
                stringResource(R.string.energy_score_age_range),
                style = MaterialTheme.typography.labelMedium,
                color = TextSecondary,
            )
        }
        Spacer(Modifier.height(8.dp))
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            FilledTonalIconButton(
                onClick = { onStepAge(-1) },
                enabled = !busy && (age == null || age > 18),
            ) {
                Icon(
                    Icons.Default.Remove,
                    contentDescription = stringResource(R.string.energy_score_age_decrease),
                )
            }
            OutlinedTextField(
                value = ageText,
                onValueChange = onAgeTextChange,
                placeholder = { Text("18–99") },
                suffix = { Text(stringResource(R.string.energy_score_age_unit)) },
                isError = ageError,
                keyboardOptions =
                    KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
                singleLine = true,
                enabled = !busy,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.weight(1f).testTag("energy_score_age"),
            )
            FilledTonalIconButton(
                onClick = { onStepAge(1) },
                enabled = !busy && (age == null || age < 99),
            ) {
                Icon(
                    Icons.Default.Add,
                    contentDescription = stringResource(R.string.energy_score_age_increase),
                )
            }
        }
        if (ageError) {
            Spacer(Modifier.height(4.dp))
            Text(
                stringResource(R.string.energy_score_age_range_error),
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall,
            )
        }
        Spacer(Modifier.height(16.dp))
        Text(
            stringResource(R.string.energy_score_sex_label),
            style = MaterialTheme.typography.labelLarge,
            color = TextPrimary,
        )
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf(true to R.string.energy_score_female, false to R.string.energy_score_male)
                .forEach { (value, label) ->
                    val isSelected = female == value
                    SexOptionCard(
                        label = stringResource(label),
                        selected = isSelected,
                        enabled = !busy,
                        onClick = { onFemaleChange(value) },
                        modifier =
                            Modifier.weight(1f)
                                .testTag(
                                    if (value) "energy_score_sex_female"
                                    else "energy_score_sex_male"
                                ),
                    )
                }
        }
        Spacer(Modifier.height(12.dp))
        Text(
            stringResource(R.string.energy_score_profile_help),
            color = TextSecondary,
            style = MaterialTheme.typography.bodySmall,
        )
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(
                onClick = onSave,
                enabled = age != null && female != null && !busy,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                modifier = Modifier.weight(1f).testTag("energy_score_profile_save"),
            ) {
                Text(
                    stringResource(
                        if (saving) R.string.energy_score_profile_saving
                        else R.string.energy_score_profile_save
                    )
                )
            }
            Button(
                onClick = onCalculate,
                enabled = age != null && female != null && !busy,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                modifier = Modifier.weight(1f).testTag("energy_score_calculate"),
            ) {
                Text(
                    stringResource(
                        if (calculating) R.string.energy_score_calculating
                        else R.string.energy_score_calculate
                    )
                )
            }
        }
    }
}

@Composable
private fun SexOptionCard(
    label: String,
    selected: Boolean,
    enabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(16.dp)
    Box(
        modifier
            .heightIn(min = 48.dp)
            .clip(shape)
            .background(if (selected) HealthSteps.copy(alpha = 0.16f) else CardSurfaceElevated)
            .border(
                width = if (selected) 1.5.dp else 0.5.dp,
                color = if (selected) HealthSteps else CardBorder.copy(alpha = 0.6f),
                shape = shape,
            )
            .clickable(enabled = enabled, onClick = onClick)
            .semantics(mergeDescendants = true) {
                this.selected = selected
                role = Role.RadioButton
            }
            .padding(horizontal = 12.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center,
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            if (selected) {
                Icon(
                    Icons.Default.Check,
                    contentDescription = null,
                    tint = HealthSteps,
                    modifier = Modifier.size(18.dp),
                )
            }
            Text(
                label,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                color = if (selected) TextPrimary else TextSecondary,
            )
        }
    }
}

@Composable
private fun EnergyScoreFactorsSection(record: EnergyScoreLog.Record, locale: java.util.Locale) {
    val values = remember(record.values) { JSONObject(record.values) }
    val factors =
        listOf(
            Triple("sleep_score", R.string.energy_score_sleep_factor, HealthSleep),
            Triple("activity_score", R.string.energy_score_activity_factor, HealthSteps),
            Triple("shr_score", R.string.energy_score_hr_factor, HealthHeart),
            Triple("shrv_score", R.string.energy_score_hrv_factor, HealthHrv),
        )
    Column(Modifier.fillMaxWidth()) {
        SectionHeader(stringResource(R.string.energy_score_factors))
        GroupedCard(cornerRadius = 24.dp, innerPadding = 16.dp) {
            factors.forEachIndexed { index, (key, labelRes, accent) ->
                if (index > 0) Spacer(Modifier.height(14.dp))
                val score = values.optDouble(key, Double.NaN).takeIf { it.isFinite() }
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text(
                        stringResource(labelRes),
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextPrimary,
                        modifier = Modifier.weight(1f),
                    )
                    Text(
                        score?.let { "%.1f".format(locale, it) }
                            ?: stringResource(R.string.energy_score_unavailable),
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = if (score != null) TextPrimary else TextSecondary,
                    )
                }
                Spacer(Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { ((score ?: 0.0) / 100.0).toFloat().coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
                    color = if (score != null) accent else CardBorder,
                    trackColor = CardSurfaceElevated,
                    gapSize = 0.dp,
                    drawStopIndicator = {},
                )
            }
        }
    }
}

@Composable
private fun EnergyScoreSyncCard(
    savedProfile: EnergyScoreProfile?,
    editingProfile: Boolean,
    selected: EnergyScoreLog.Record?,
    today: LocalDate,
    hasTodayScore: Boolean,
    dateFormat: DateTimeFormatter,
    sessionReady: Boolean,
    syncStatus: EnergyScoreSync.Status,
    busy: Boolean,
    calculating: Boolean,
    onRecalculate: (EnergyScoreProfile) -> Unit,
    onWrite: (String) -> Unit,
) {
    val selectedDate = selected?.let { runCatching { LocalDate.parse(it.date) }.getOrNull() }
    val showNonTodayWatchNotice = selectedDate != null && selectedDate != today
    val displayedSyncStatus =
        when {
            syncStatus == EnergyScoreSync.Status.WAITING_ACK -> syncStatus
            syncStatus != EnergyScoreSync.Status.IDLE &&
                syncStatus != EnergyScoreSync.Status.ACCEPTED -> syncStatus
            selected?.acknowledged == true -> EnergyScoreSync.Status.ACCEPTED
            else -> EnergyScoreSync.Status.IDLE
        }
    Column(Modifier.fillMaxWidth()) {
        SectionHeader(stringResource(R.string.energy_score_sync_section))
        GroupedCard(cornerRadius = 24.dp, innerPadding = 16.dp) {
            if (savedProfile != null && !editingProfile) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    FilledTonalButton(
                        onClick = { onRecalculate(savedProfile) },
                        enabled = !busy,
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                        modifier = Modifier.weight(1f).testTag("energy_score_calculate"),
                    ) {
                        Icon(
                            Icons.Default.Refresh,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            stringResource(
                                if (calculating) R.string.energy_score_calculating
                                else R.string.energy_score_recalculate
                            )
                        )
                    }
                    Button(
                        onClick = { selected?.id?.let(onWrite) },
                        enabled =
                            sessionReady && selected?.deviceUuid?.isNotBlank() == true && !busy,
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                        modifier = Modifier.weight(1f).testTag("energy_score_write"),
                    ) {
                        Icon(
                            Icons.Default.Watch,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(stringResource(R.string.energy_score_write))
                    }
                }
            } else {
                OutlinedButton(
                    onClick = { selected?.id?.let(onWrite) },
                    enabled = sessionReady && selected?.deviceUuid?.isNotBlank() == true && !busy,
                    modifier = Modifier.fillMaxWidth().testTag("energy_score_write"),
                ) {
                    Icon(
                        Icons.Default.Watch,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp),
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(stringResource(R.string.energy_score_write))
                }
            }
            Spacer(Modifier.height(10.dp))
            Text(
                stringResource(energySyncLabel(displayedSyncStatus)),
                color =
                    if (displayedSyncStatus == EnergyScoreSync.Status.ACCEPTED) EmeraldCharging
                    else TextPrimary,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.testTag("energy_score_sync_status"),
            )
            if (showNonTodayWatchNotice && selectedDate != null) {
                Spacer(Modifier.height(8.dp))
                Row(
                    Modifier.fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(WarningAmber.copy(alpha = 0.12f))
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                        .testTag("energy_score_watch_today_notice"),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.Top,
                ) {
                    Icon(
                        Icons.Default.Info,
                        contentDescription = null,
                        tint = WarningAmber,
                        modifier = Modifier.padding(top = 2.dp).size(16.dp),
                    )
                    Text(
                        stringResource(
                            if (hasTodayScore) R.string.energy_score_watch_past_date_notice
                            else R.string.energy_score_watch_today_missing_notice,
                            selectedDate.format(dateFormat),
                        ),
                        color = TextPrimary,
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                stringResource(R.string.energy_score_ack_help),
                color = TextSecondary,
                style = MaterialTheme.typography.bodySmall,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                stringResource(R.string.energy_score_about),
                color = TextTertiary,
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }
}

@Composable
private fun StatusPill(text: String, tint: Color, modifier: Modifier = Modifier) {
    Box(
        modifier
            .clip(CircleShape)
            .background(tint.copy(alpha = 0.14f))
            .padding(horizontal = 10.dp, vertical = 3.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.SemiBold,
            color = tint,
        )
    }
}
