package dev.ricky.galaxywatchmanagerfree.core

import android.content.Context
import androidx.annotation.MainThread
import dev.ricky.galaxywatchmanagerfree.BuildConfig
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.feature.LogBus
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Fetches and enforces remote force-update / emergency discontinuation policy (`policy.json`).
 *
 * Designed for high resilience under poor GitHub connectivity:
 * - Never blocks app startup; checks asynchronously on IO.
 * - Tries direct GitHub and built-in mirrors with short per-endpoint timeouts.
 * - Strict fail-open: timeouts, DNS/TLS errors, 404, 5xx, or invalid payloads silently allow normal
 *   usage; only an explicitly verified matching policy blocks the app.
 */
object AppPolicyChecker {
    private const val FEED_BASE =
        "https://raw.githubusercontent.com/crossly/galaxy-watch-manager-free-feed/main/"
    const val POLICY_URL = "${FEED_BASE}${AppUpdatePolicy.POLICY_FILE}"

    private const val PREFS = "watchfree_update"
    private const val KEY_POLICY_JSON = "policy_cached_json"
    private const val KEY_POLICY_VERSION_CODE = "policy_cached_version_code"
    private const val KEY_POLICY_FETCHED_AT = "policy_cached_fetched_at"
    private const val KEY_POLICY_RELEASE_JSON = "policy_cached_release_json"
    private const val KEY_POLICY_MIRROR = "policy_cached_mirror"
    private const val KEY_DEBUG_POLICY_URL = "debug_policy_url"
    private const val KEY_DEBUG_FEED_URL = "debug_feed_url"

    private const val CONNECT_TIMEOUT_MS = 4_500
    private const val READ_TIMEOUT_MS = 4_500
    private const val MAX_POLICY_BYTES = 64 * 1024
    private const val CHECK_THROTTLE_MS = 15 * 60_000L

    data class Gate(
        val decision: AppUpdatePolicy.Decision,
        val release: AppUpdate.ReleaseInfo? = null,
        val suggestedMirror: DownloadMirror = DownloadMirror.OFF,
        val fetchedAt: Long = 0L,
    ) {
        val policy: AppUpdatePolicy.Policy
            get() =
                when (decision) {
                    is AppUpdatePolicy.Decision.ForceUpdate -> decision.policy
                    is AppUpdatePolicy.Decision.Block -> decision.policy
                    AppUpdatePolicy.Decision.Allow ->
                        error("Gate cannot be constructed for Allow decision")
                }

        val isForceUpdate: Boolean
            get() = decision is AppUpdatePolicy.Decision.ForceUpdate

        val isHardBlock: Boolean
            get() = decision is AppUpdatePolicy.Decision.Block
    }

    private sealed interface FetchOutcome {
        data class Parsed(
            val rawJson: String,
            val policy: AppUpdatePolicy.Policy,
            val mirror: DownloadMirror,
        ) : FetchOutcome

        data object NotFound : FetchOutcome

        data object Unavailable : FetchOutcome
    }

    private val _gate = MutableStateFlow<Gate?>(null)
    val gate: StateFlow<Gate?> = _gate.asStateFlow()

    private val _checking = MutableStateFlow(false)
    val checking: StateFlow<Boolean> = _checking.asStateFlow()

    val isBlocked: Boolean
        get() = _gate.value != null

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var checkJob: Job? = null
    private var restored = false
    private var lastAttemptAt = 0L

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @MainThread
    fun restore(context: Context) {
        val app = context.applicationContext
        val p = prefs(app)
        val raw = p.getString(KEY_POLICY_JSON, null)
        val cachedCode = p.getInt(KEY_POLICY_VERSION_CODE, 0)
        val fetchedAt = p.getLong(KEY_POLICY_FETCHED_AT, 0L)
        val now = System.currentTimeMillis()
        restored = true
        if (
            raw.isNullOrBlank() ||
                !AppUpdatePolicy.isCachedPolicyValid(
                    cachedForVersionCode = cachedCode,
                    currentVersionCode = BuildConfig.VERSION_CODE,
                    fetchedAt = fetchedAt,
                    now = now,
                )
        ) {
            clearCache(app)
            _gate.value = null
            return
        }
        val policy = AppUpdatePolicy.parsePolicy(raw)
        val decision = AppUpdatePolicy.evaluate(policy, BuildConfig.VERSION_CODE)
        if (decision == AppUpdatePolicy.Decision.Allow) {
            clearCache(app)
            _gate.value = null
            return
        }
        val cachedRelease =
            if (decision is AppUpdatePolicy.Decision.ForceUpdate) {
                p.getString(KEY_POLICY_RELEASE_JSON, null)
                    ?.let { AppUpdate.parseFeed(it) }
                    ?.takeIf {
                        AppUpdatePolicy.isReleaseEligibleForForceUpdate(
                            policy = decision.policy,
                            currentVersionName = BuildConfig.VERSION_NAME,
                            currentVersionCode = BuildConfig.VERSION_CODE,
                            candidate = it,
                        )
                    }
            } else {
                null
            }
        val suggestedMirror = DownloadMirror.fromPreference(p.getString(KEY_POLICY_MIRROR, null))
        _gate.value =
            Gate(
                decision = decision,
                release = cachedRelease,
                suggestedMirror = suggestedMirror,
                fetchedAt = fetchedAt,
            )
    }

    @MainThread
    fun maybeCheck(context: Context, force: Boolean = false, userInitiated: Boolean = false) {
        val app = context.applicationContext
        if (!restored) restore(app)
        if (checkJob?.isActive == true) return
        val now = System.currentTimeMillis()
        if (!force && !userInitiated && !isBlocked && now - lastAttemptAt < CHECK_THROTTLE_MS) {
            return
        }
        lastAttemptAt = now
        _checking.value = true
        val preferredMirror = UpdateChecker.mirror(app)
        val bypassCache = userInitiated || isBlocked
        checkJob =
            scope.launch {
                try {
                    val outcome =
                        withContext(Dispatchers.IO) {
                            fetchPolicy(app, preferredMirror, bypassCache = bypassCache)
                        }
                    when (outcome) {
                        is FetchOutcome.Parsed -> {
                            handleParsedPolicy(app, outcome, userInitiated)
                        }
                        FetchOutcome.NotFound -> {
                            val wasBlocked = isBlocked
                            clearCache(app)
                            _gate.value = null
                            LogBus.debug { "[策略] 远端未配置拦截策略（404），保持正常使用" }
                            if (userInitiated && wasBlocked) {
                                UiNotify.show(R.string.policy_status_cleared)
                            }
                        }
                        FetchOutcome.Unavailable -> {
                            // Re-validate cached TTL; if expired or absent, silently fail open.
                            restore(app)
                            LogBus.debug { "[策略] 远程策略读取超时或不可达，静默放行" }
                            if (userInitiated) {
                                UiNotify.show(R.string.policy_recheck_failed)
                            }
                        }
                    }
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (error: Exception) {
                    currentCoroutineContext().ensureActive()
                    restore(app)
                    LogBus.debug { "[策略] 远程策略检查异常（${error.javaClass.simpleName}），静默放行" }
                    if (userInitiated) {
                        UiNotify.show(R.string.policy_recheck_failed)
                    }
                } finally {
                    _checking.value = false
                }
            }
    }

    private suspend fun handleParsedPolicy(
        app: Context,
        outcome: FetchOutcome.Parsed,
        userInitiated: Boolean,
    ) {
        val now = System.currentTimeMillis()
        val decision = AppUpdatePolicy.evaluate(outcome.policy, BuildConfig.VERSION_CODE)
        when (decision) {
            AppUpdatePolicy.Decision.Allow -> {
                val wasBlocked = isBlocked
                clearCache(app)
                _gate.value = null
                LogBus.log(
                    "[策略] 远程策略校验通过 mode=${outcome.policy.mode.id} mirror=${outcome.mirror.id}"
                )
                if (userInitiated && wasBlocked) {
                    UiNotify.show(R.string.policy_status_cleared)
                }
            }
            is AppUpdatePolicy.Decision.ForceUpdate -> {
                val releaseResult =
                    withContext(Dispatchers.IO) {
                        fetchInstallableRelease(app, decision.policy, outcome.mirror)
                    }
                val release = releaseResult?.first
                val releaseJson = releaseResult?.second
                val effectiveMirror = releaseResult?.third ?: outcome.mirror
                if (release != null) {
                    UpdateChecker.adoptDiscoveredRelease(app, release)
                }
                persistCache(
                    context = app,
                    policyJson = outcome.rawJson,
                    releaseJson = releaseJson,
                    mirror = effectiveMirror,
                    fetchedAt = now,
                )
                _gate.value =
                    Gate(
                        decision = decision,
                        release = release,
                        suggestedMirror = effectiveMirror,
                        fetchedAt = now,
                    )
                WatchController.stopService(app)
                LogBus.log(
                    "[策略] 触发强制更新 minCode=${outcome.policy.minSupportedVersionCode} current=${BuildConfig.VERSION_CODE} mirror=${effectiveMirror.id} hasRelease=${release != null}"
                )
            }
            is AppUpdatePolicy.Decision.Block -> {
                persistCache(
                    context = app,
                    policyJson = outcome.rawJson,
                    releaseJson = null,
                    mirror = outcome.mirror,
                    fetchedAt = now,
                )
                ApkUpdater.cancel()
                _gate.value =
                    Gate(
                        decision = decision,
                        release = null,
                        suggestedMirror = outcome.mirror,
                        fetchedAt = now,
                    )
                WatchController.stopService(app)
                LogBus.log(
                    "[策略] 触发应用停用拦截 current=${BuildConfig.VERSION_CODE} mirror=${outcome.mirror.id}"
                )
            }
        }
    }

    private suspend fun fetchPolicy(
        app: Context,
        preferredMirror: DownloadMirror,
        bypassCache: Boolean = false,
    ): FetchOutcome {
        val debugUrl =
            if (BuildConfig.DEBUG) {
                prefs(app).getString(KEY_DEBUG_POLICY_URL, null)?.trim()?.takeIf {
                    it.startsWith("http://") || it.startsWith("https://")
                }
            } else null

        val rawPolicyUrl =
            if (bypassCache) {
                "$POLICY_URL?_t=${System.currentTimeMillis() / 1000L}"
            } else {
                POLICY_URL
            }

        val endpoints =
            if (debugUrl != null) {
                listOf(DownloadMirror.OFF to debugUrl)
            } else {
                AppUpdatePolicy.candidateMirrors(preferredMirror).map { mirror ->
                    mirror to DownloadMirror.rewrite(rawPolicyUrl, mirror)
                }
            }

        val notFoundMirrors = mutableSetOf<DownloadMirror>()
        for ((mirror, url) in endpoints) {
            currentCoroutineContext().ensureActive()
            val response = httpGet(url) ?: continue
            if (response.first == HttpURLConnection.HTTP_NOT_FOUND) {
                if (mirror == DownloadMirror.OFF) {
                    return FetchOutcome.NotFound
                }
                notFoundMirrors += mirror
                continue
            }
            if (response.first != HttpURLConnection.HTTP_OK) continue
            val body = response.second ?: continue
            val parsed = AppUpdatePolicy.parsePolicy(body)
            if (parsed != null) {
                return FetchOutcome.Parsed(rawJson = body, policy = parsed, mirror = mirror)
            }
        }
        return if (
            AppUpdatePolicy.shouldTreatNotFoundAsCleared(
                directNotFound = false,
                distinctMirrorNotFoundCount = notFoundMirrors.size,
            )
        ) {
            FetchOutcome.NotFound
        } else {
            FetchOutcome.Unavailable
        }
    }

    private suspend fun fetchInstallableRelease(
        app: Context,
        policy: AppUpdatePolicy.Policy,
        preferredMirror: DownloadMirror,
    ): Triple<AppUpdate.ReleaseInfo, String, DownloadMirror>? {
        val debugFeedUrl =
            if (BuildConfig.DEBUG) {
                prefs(app).getString(KEY_DEBUG_FEED_URL, null)?.trim()?.takeIf {
                    it.startsWith("http://") || it.startsWith("https://")
                }
            } else null
        val selectedChannel = UpdateChecker.channel(app)
        val candidates =
            if (debugFeedUrl != null) listOf(DownloadMirror.OFF)
            else AppUpdatePolicy.candidateMirrors(preferredMirror)
        val cacheBuster = System.currentTimeMillis() / 1000L
        for (mirror in candidates) {
            currentCoroutineContext().ensureActive()
            val stableUrl =
                debugFeedUrl
                    ?: DownloadMirror.rewrite("${UpdateChecker.FEED_URL}?_t=$cacheBuster", mirror)
            val stableRaw =
                httpGet(stableUrl)?.takeIf { it.first == HttpURLConnection.HTTP_OK }?.second
            val stable =
                stableRaw
                    ?.let { AppUpdate.parseFeed(it) }
                    ?.takeIf { it.channel == AppUpdate.Channel.STABLE } ?: continue

            var chosen = stable
            var chosenRaw = stableRaw
            if (selectedChannel == AppUpdate.Channel.NIGHTLY) {
                val nightlyUrl =
                    DownloadMirror.rewrite(
                        "${FEED_BASE}${AppUpdate.Channel.NIGHTLY.feedFile}?_t=$cacheBuster",
                        mirror,
                    )
                val nightlyRaw =
                    httpGet(nightlyUrl)?.takeIf { it.first == HttpURLConnection.HTTP_OK }?.second
                val nightly =
                    nightlyRaw
                        ?.let { AppUpdate.parseFeed(it) }
                        ?.takeIf { it.channel == AppUpdate.Channel.NIGHTLY }
                val picked = AppUpdate.selectRelease(selectedChannel, stable, nightly)
                if (nightly != null && picked == nightly && !nightlyRaw.isNullOrBlank()) {
                    chosen = nightly
                    chosenRaw = nightlyRaw
                }
            }
            return if (
                AppUpdatePolicy.isReleaseEligibleForForceUpdate(
                    policy = policy,
                    currentVersionName = BuildConfig.VERSION_NAME,
                    currentVersionCode = BuildConfig.VERSION_CODE,
                    candidate = chosen,
                )
            ) {
                Triple(chosen, chosenRaw, mirror)
            } else {
                null
            }
        }
        return null
    }

    private suspend fun httpGet(url: String): Pair<Int, String?>? {
        currentCoroutineContext().ensureActive()
        val conn =
            runCatching { URL(url).openConnection() as HttpURLConnection }.getOrNull()
                ?: return null
        return try {
            conn.requestMethod = "GET"
            conn.instanceFollowRedirects = true
            conn.connectTimeout = CONNECT_TIMEOUT_MS
            conn.readTimeout = READ_TIMEOUT_MS
            conn.setRequestProperty("Accept", "application/json")
            conn.setRequestProperty(
                "User-Agent",
                "GalaxyWatchManagerFree/${BuildConfig.VERSION_NAME}",
            )
            conn.setRequestProperty("Cache-Control", "no-cache")
            val code = conn.responseCode
            if (code != HttpURLConnection.HTTP_OK) {
                code to null
            } else {
                val body =
                    conn.inputStream.use { input ->
                        val output = ByteArrayOutputStream()
                        val buffer = ByteArray(8 * 1024)
                        while (true) {
                            currentCoroutineContext().ensureActive()
                            val read = input.read(buffer)
                            if (read < 0) break
                            if (output.size() + read > MAX_POLICY_BYTES) {
                                return null
                            }
                            output.write(buffer, 0, read)
                        }
                        output.toString(Charsets.UTF_8.name())
                    }
                code to body
            }
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            null
        } finally {
            conn.disconnect()
        }
    }

    private fun persistCache(
        context: Context,
        policyJson: String,
        releaseJson: String?,
        mirror: DownloadMirror,
        fetchedAt: Long,
    ) {
        prefs(context)
            .edit()
            .putString(KEY_POLICY_JSON, policyJson)
            .putInt(KEY_POLICY_VERSION_CODE, BuildConfig.VERSION_CODE)
            .putLong(KEY_POLICY_FETCHED_AT, fetchedAt)
            .putString(KEY_POLICY_MIRROR, mirror.id)
            .apply {
                if (releaseJson != null) putString(KEY_POLICY_RELEASE_JSON, releaseJson)
                else remove(KEY_POLICY_RELEASE_JSON)
            }
            .apply()
    }

    private fun clearCache(context: Context) {
        prefs(context)
            .edit()
            .remove(KEY_POLICY_JSON)
            .remove(KEY_POLICY_VERSION_CODE)
            .remove(KEY_POLICY_FETCHED_AT)
            .remove(KEY_POLICY_RELEASE_JSON)
            .remove(KEY_POLICY_MIRROR)
            .apply()
    }
}
