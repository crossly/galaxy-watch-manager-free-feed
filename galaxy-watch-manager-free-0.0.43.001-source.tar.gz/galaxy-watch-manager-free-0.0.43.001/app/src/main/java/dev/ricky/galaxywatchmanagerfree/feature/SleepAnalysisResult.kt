package dev.ricky.galaxywatchmanagerfree.feature

import org.json.JSONObject

/**
 * Converts verified offline inference epochs (30-second 8-ACC `version = 2` or 60-second 7-ACC
 * `version = 1`) into the same model as received sleep stages.
 */
object SleepAnalysisResult {
    const val SOURCE = "local_sensor_v1"
    const val SOURCE_7ACC = "local_sensor_7acc_v1"
    const val EPOCH_MS_8ACC = 30_000L
    const val EPOCH_MS_7ACC = 60_000L

    fun apply(session: SleepParser.Session, result: JSONObject): SleepParser.Session {
        val epochMs = result.optLong("epoch_ms", EPOCH_MS_8ACC)
        require(epochMs == EPOCH_MS_8ACC || epochMs == EPOCH_MS_7ACC) {
            "Unsupported sleep epoch duration"
        }
        val maxPoints = if (epochMs == EPOCH_MS_7ACC) 1440 else 2880
        val points = result.getJSONArray("stages")
        require(points.length() in 1..maxPoints)
        val source =
            result.optString("source").takeIf { it == SOURCE || it == SOURCE_7ACC }
                ?: if (epochMs == EPOCH_MS_7ACC) SOURCE_7ACC else SOURCE
        val segments = ArrayList<SleepParser.Segment>()
        var previousEnd = 0L
        for (i in 0 until points.length()) {
            val point = points.getJSONArray(i)
            val start = point.getLong(0)
            val end = start + epochMs
            require(start > 0 && start >= session.startMillis && end <= session.endMillis)
            require(previousEnd == 0L || start == previousEnd)
            val stage =
                when (point.getInt(1)) {
                    0 -> SleepParser.Stage.DEEP
                    1 -> SleepParser.Stage.LIGHT
                    2 -> SleepParser.Stage.AWAKE
                    3 -> SleepParser.Stage.REM
                    else -> error("Unsupported inferred sleep stage")
                }
            val last = segments.lastOrNull()
            if (last?.stage == stage) segments[segments.lastIndex] = last.copy(endMillis = end)
            else segments.add(SleepParser.Segment(start, end, stage))
            previousEnd = end
        }
        return session.copy(
            startMillis = segments.first().startMillis,
            endMillis = segments.last().endMillis,
            segments = segments,
            efficiency = null,
            reportedSleepMinutes = null,
            analysisSource = source,
            recordedEndMillis = session.endMillis,
        )
    }
}
