package dev.ricky.galaxywatchmanagerfree.ui.components

import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.log2
import kotlin.math.max

internal class PreviewTilePlan
private constructor(
    val zoom: Int,
    val tileXRange: IntRange,
    val tileYRange: IntRange,
    private val leftWorldX: Double,
    private val topWorldY: Double,
    private val worldUnitsPerPixelX: Double,
    private val worldUnitsPerPixelY: Double,
    private val worldTiles: Int,
) {
    val columns = tileXRange.last - tileXRange.first + 1
    val rows = tileYRange.last - tileYRange.first + 1
    val widthPixels = columns * TILE_SIZE
    val heightPixels = rows * TILE_SIZE

    fun bitmapX(worldX: Double) = (worldX + WORLD_SHIFT - leftWorldX) / worldUnitsPerPixelX

    fun bitmapY(worldY: Double) = (worldY + WORLD_SHIFT - topWorldY) / worldUnitsPerPixelY

    fun tileUrl(column: Int, row: Int, layer: String): String {
        val wrapped = ((column % worldTiles) + worldTiles) % worldTiles
        return TiandituTiles.template(layer)
            .replace("{z}", zoom.toString())
            .replace("{x}", wrapped.toString())
            .replace("{y}", row.toString())
    }

    companion object {
        const val TILE_SIZE = 256
        private const val MAX_ZOOM = 16
        private const val PADDING = 1.6
        private const val MAX_COLUMNS = 2
        private const val MAX_ROWS = 2
        private const val MIN_HALF_SPAN = 0.0008
        private const val WORLD_SHIFT = 0.5

        fun of(geometry: ExerciseRouteGeometry): PreviewTilePlan {
            val centerX = (geometry.minX + geometry.maxX) / 2
            val centerY = (geometry.minY + geometry.maxY) / 2
            val halfSpanX = max((geometry.maxX - geometry.minX) / 2 * PADDING, MIN_HALF_SPAN)
            val halfSpanY = max((geometry.maxY - geometry.minY) / 2 * PADDING, MIN_HALF_SPAN)
            val zoom =
                minOf(
                        floor(log2(MAX_COLUMNS / (halfSpanX * 2))),
                        floor(log2(MAX_ROWS / (halfSpanY * 2))),
                    )
                    .toInt()
                    .coerceIn(1, MAX_ZOOM)
            val worldTiles = 1 shl zoom
            // Longitudes unwrap into [-0.5, 1.5) and latitudes into [-0.5, 0.5];
            // shifting by half a world maps them onto Web Mercator [0, 1) tile space.
            // Columns may wrap past the seam for routes crossing the antimeridian,
            // so tileUrl wraps them back while the bitmap stays contiguous.
            val left = centerX - halfSpanX + WORLD_SHIFT
            val right = centerX + halfSpanX + WORLD_SHIFT
            val top = (centerY - halfSpanY + WORLD_SHIFT).coerceIn(0.0, 1.0)
            val bottom = (centerY + halfSpanY + WORLD_SHIFT).coerceIn(0.0, 1.0)
            val firstColumn = floor(left * worldTiles).toInt()
            val lastColumn = ceil(right * worldTiles).toInt() - 1
            val firstRow = floor(top * worldTiles).toInt().coerceIn(0, worldTiles - 1)
            val lastRow = (ceil(bottom * worldTiles).toInt() - 1).coerceIn(0, worldTiles - 1)
            return PreviewTilePlan(
                zoom = zoom,
                tileXRange = firstColumn..lastColumn,
                tileYRange = firstRow..lastRow,
                leftWorldX = firstColumn.toDouble() / worldTiles,
                topWorldY = firstRow.toDouble() / worldTiles,
                worldUnitsPerPixelX = 1.0 / (TILE_SIZE.toDouble() * worldTiles),
                worldUnitsPerPixelY = 1.0 / (TILE_SIZE.toDouble() * worldTiles),
                worldTiles = worldTiles,
            )
        }
    }
}

internal object TiandituTiles {
    val layers = listOf("vec", "cva")
    private const val KEY = "aeaea39febbaec7501342261789594a9"
    const val ATTRIBUTION_URL = "https://www.tianditu.gov.cn/"

    fun template(layer: String): String =
        "https://t0.tianditu.gov.cn/${layer}_w/wmts?SERVICE=WMTS&REQUEST=GetTile" +
            "&VERSION=1.0.0&LAYER=$layer&STYLE=default&TILEMATRIXSET=w&FORMAT=tiles" +
            "&TILEMATRIX={z}&TILEROW={y}&TILECOL={x}&tk=$KEY"
}
