package dev.ricky.galaxywatchmanagerfree.wcs

import java.io.DataInputStream
import java.io.EOFException
import java.io.IOException
import java.io.InputStream
import java.nio.ByteBuffer

internal object FlowProtocol {
    const val TCP_OPEN = 1
    const val TCP_CLOSE = 2
    const val TCP_WRITE = 3
    const val UDP_DATAGRAM = 4
    const val PING = 5
    const val ACK = 6
    const val UDP_FAILURE = 7
    const val PULL_REQUEST = 8
    const val PULL_DATA = 9
    const val PACKAGE_NAME = 10
    const val NETWORK_STATE = 11
    const val PUSH_REQUEST = 12
    const val PUSH_DATA = 13
    const val UDP_V2_DATAGRAM = 14
    const val UDP_V2_FAILURE = 15
    const val HANDSHAKE_START = 16
    const val HANDSHAKE_ACK = 17
    const val HANDSHAKE_DONE = 18
    const val MAX_PAYLOAD = 65535

    fun read(input: InputStream): ByteArray? {
        val type = input.read()
        if (type < 0) return null
        val headerSize =
            when (type) {
                TCP_OPEN -> 13
                TCP_CLOSE,
                PING,
                ACK -> 5
                TCP_WRITE,
                PULL_DATA,
                PUSH_DATA,
                HANDSHAKE_START,
                HANDSHAKE_ACK,
                HANDSHAKE_DONE -> 7
                UDP_DATAGRAM,
                UDP_FAILURE,
                PULL_REQUEST,
                PUSH_REQUEST -> 9
                PACKAGE_NAME -> 5
                NETWORK_STATE -> 6
                UDP_V2_DATAGRAM,
                UDP_V2_FAILURE -> 17
                else -> throw IOException("Unsupported Flow type $type")
            }
        val header = ByteArray(headerSize)
        header[0] = type.toByte()
        val data = DataInputStream(input)
        data.readFully(header, 1, headerSize - 1)
        val payloadSize =
            when (type) {
                TCP_WRITE,
                UDP_DATAGRAM,
                UDP_FAILURE,
                PULL_DATA,
                PUSH_DATA,
                PACKAGE_NAME,
                UDP_V2_DATAGRAM,
                UDP_V2_FAILURE,
                HANDSHAKE_START,
                HANDSHAKE_ACK,
                HANDSHAKE_DONE ->
                    ByteBuffer.wrap(header).getShort(headerSize - 2).toInt() and 0xffff
                else -> 0
            }
        if (payloadSize == 0) return header
        val frame = header.copyOf(headerSize + payloadSize)
        try {
            data.readFully(frame, headerSize, payloadSize)
        } catch (error: EOFException) {
            throw EOFException("Truncated Flow payload")
        }
        return frame
    }

    fun channel(type: Int, id: Int): ByteArray =
        ByteBuffer.allocate(5).put(type.toByte()).putInt(id).array()

    fun data(type: Int, id: Int, payload: ByteArray): ByteArray {
        require(payload.size <= MAX_PAYLOAD)
        return ByteBuffer.allocate(7 + payload.size)
            .put(type.toByte())
            .putInt(id)
            .putShort(payload.size.toShort())
            .put(payload)
            .array()
    }

    fun networkState(type: Int, metered: Boolean): ByteArray =
        ByteBuffer.allocate(6)
            .put(NETWORK_STATE.toByte())
            .putInt(type)
            .put(if (metered) 1.toByte() else 0.toByte())
            .array()

    fun datagram(address: ByteArray, port: Int, payload: ByteArray): ByteArray {
        require(address.size == 4 && port in 0..65535 && payload.size <= MAX_PAYLOAD)
        return ByteBuffer.allocate(9 + payload.size)
            .put(UDP_DATAGRAM.toByte())
            .put(address)
            .putShort(port.toShort())
            .putShort(payload.size.toShort())
            .put(payload)
            .array()
    }

    fun datagramV2(
        source: ByteArray,
        sourcePort: Int,
        destination: ByteArray,
        destinationPort: Int,
        uid: Int,
        payload: ByteArray,
    ): ByteArray {
        require(source.size == 4 && destination.size == 4 && payload.size <= MAX_PAYLOAD)
        return ByteBuffer.allocate(17 + payload.size)
            .put(UDP_V2_DATAGRAM.toByte())
            .put(source)
            .putShort(sourcePort.toShort())
            .put(destination)
            .putShort(destinationPort.toShort())
            .putShort(uid.toShort())
            .putShort(payload.size.toShort())
            .put(payload)
            .array()
    }
}
