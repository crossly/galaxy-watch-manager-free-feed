package dev.ricky.galaxywatchmanagerfree.feature.monitor

import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.feature.HealthJson
import java.util.Base64
import org.json.JSONArray
import org.json.JSONObject

data class EcgRecord(
    val id: String,
    val startTime: Long,
    val heartRate: Int,
    val classification: Int,
    val sampleRate: Double = 500.0,
    val waveform: FloatArray = FloatArray(0),
    val updateTime: Long = 0,
    val symptoms: List<Int> = emptyList(),
    val rawSymptoms: String? = null,
    val ecgAppVersion: String? = null,
    val timeOffsetMs: Long? = null,
    val createTime: Long? = null,
    val deviceUuid: String? = null,
    val pkgName: String? = null,
    val comment: String? = null,
) {
    val classificationRes: Int
        get() = classificationLabelRes(classification)

    val classificationDetailRes: Int?
        get() = classificationSubReasonRes(classification)

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is EcgRecord) return false
        return id == other.id &&
            startTime == other.startTime &&
            heartRate == other.heartRate &&
            classification == other.classification &&
            sampleRate == other.sampleRate &&
            updateTime == other.updateTime &&
            symptoms == other.symptoms &&
            rawSymptoms == other.rawSymptoms &&
            ecgAppVersion == other.ecgAppVersion &&
            timeOffsetMs == other.timeOffsetMs &&
            createTime == other.createTime &&
            deviceUuid == other.deviceUuid &&
            pkgName == other.pkgName &&
            comment == other.comment &&
            waveform.contentEquals(other.waveform)
    }

    override fun hashCode(): Int {
        var result = id.hashCode()
        result = 31 * result + startTime.hashCode()
        result = 31 * result + heartRate
        result = 31 * result + classification
        result = 31 * result + sampleRate.hashCode()
        result = 31 * result + updateTime.hashCode()
        result = 31 * result + symptoms.hashCode()
        result = 31 * result + (rawSymptoms?.hashCode() ?: 0)
        result = 31 * result + (ecgAppVersion?.hashCode() ?: 0)
        result = 31 * result + (timeOffsetMs?.hashCode() ?: 0)
        result = 31 * result + (createTime?.hashCode() ?: 0)
        result = 31 * result + (deviceUuid?.hashCode() ?: 0)
        result = 31 * result + (pkgName?.hashCode() ?: 0)
        result = 31 * result + (comment?.hashCode() ?: 0)
        result = 31 * result + waveform.contentHashCode()
        return result
    }

    companion object {
        fun classificationLabelRes(type: Int): Int =
            when (type) {
                1 -> R.string.ecg_sinus
                2 -> R.string.ecg_afib
                0 -> R.string.ecg_poor_signal
                3 -> R.string.ecg_inconclusive
                11 -> R.string.ecg_sinus_fast
                12 -> R.string.ecg_afib_fast
                in 4..10 -> R.string.ecg_inconclusive
                else -> R.string.ecg_unrecognized
            }

        /** 官方手机 SHM 对分类码 4..8 的细分原因，仅用于详情副标题展示，不改主分类标签。 */
        fun classificationSubReasonRes(type: Int): Int? =
            when (type) {
                4 -> R.string.ecg_inconclusive_ectopic
                5 -> R.string.ecg_inconclusive_ectopic_hr
                6 -> R.string.ecg_inconclusive_other_rhythm
                7 -> R.string.ecg_inconclusive_low_hr
                8 -> R.string.ecg_inconclusive_high_hr
                else -> null
            }

        /** 官方手表 SHM `symptoms` 整数编码（0..8）对应的可读标签。 */
        fun symptomLabelRes(code: Int): Int? =
            when (code) {
                0 -> R.string.ecg_symptom_none
                1 -> R.string.ecg_symptom_palpitations
                2 -> R.string.ecg_symptom_skipped_beat
                3 -> R.string.ecg_symptom_fatigue
                4 -> R.string.ecg_symptom_shortness_of_breath
                5 -> R.string.ecg_symptom_chest_pain
                6 -> R.string.ecg_symptom_fainting
                7 -> R.string.ecg_symptom_dizziness
                8 -> R.string.ecg_symptom_other
                else -> null
            }

        internal fun parseSymptoms(raw: Any?): Pair<List<Int>, String?> {
            if (raw == null || raw == JSONObject.NULL) return emptyList<Int>() to null
            val rawText =
                when (raw) {
                    is JSONArray -> raw.toString()
                    is String ->
                        raw.trim().ifBlank {
                            return emptyList<Int>() to null
                        }
                    else ->
                        raw.toString().trim().ifBlank {
                            return emptyList<Int>() to null
                        }
                }
            val parsed = linkedSetOf<Int>()
            val array =
                when (raw) {
                    is JSONArray -> raw
                    is String -> runCatching { JSONArray(rawText) }.getOrNull()
                    else -> null
                }
            if (array != null) {
                for (i in 0 until array.length()) {
                    val value = array.opt(i)?.toString()?.trim()?.toIntOrNull()
                    if (value != null && value in 0..8) parsed += value
                }
            } else {
                rawText.trim('[', ']').split(',').forEach { token ->
                    val value = token.trim().toIntOrNull()
                    if (value != null && value in 0..8) parsed += value
                }
            }
            return parsed.toList() to rawText
        }

        internal fun parseTimeOffsetMs(record: JSONObject): Long? {
            if (!record.has("time_offset") || record.isNull("time_offset")) return null
            val raw = record.opt("time_offset") ?: return null
            when (raw) {
                is Number -> {
                    val ms = raw.toLong()
                    return ms.takeIf { it in -64_800_000L..64_800_000L }
                }
                is String -> {
                    val trimmed = raw.trim()
                    trimmed.toLongOrNull()?.let {
                        return it.takeIf { ms -> ms in -64_800_000L..64_800_000L }
                    }
                    val offsetText = trimmed.removePrefix("UTC").trim()
                    if (offsetText.isNotEmpty()) {
                        val normalized =
                            if (Regex("^[+-]\\d{4}$").matches(offsetText)) {
                                offsetText.substring(0, 3) + ":" + offsetText.substring(3)
                            } else offsetText
                        return runCatching {
                                java.time.ZoneOffset.of(normalized).totalSeconds * 1_000L
                            }
                            .getOrNull()
                            ?.takeIf { it in -64_800_000L..64_800_000L }
                    }
                }
            }
            return null
        }

        internal fun optNonBlank(record: JSONObject, vararg keys: String): String? =
            keys.firstNotNullOfOrNull { key ->
                if (!record.has(key) || record.isNull(key)) null
                else record.optString(key).trim().ifBlank { null }
            }

        internal fun optPositiveLong(record: JSONObject, key: String): Long? =
            if (!record.has(key) || record.isNull(key)) null
            else record.optLong(key, 0L).takeIf { it > 0L }

        fun parse(
            record: JSONObject,
            chartRecords: Map<String, JSONObject> = emptyMap(),
        ): EcgRecord? {
            val uuid =
                record.optString("datauuid", record.optString("data_uuid")).ifBlank {
                    return null
                }
            val startTime = record.optLong("start_time", record.optLong("create_time", 0L))
            if (startTime <= 0L) return null
            val hr = record.optInt("avg_hr", record.optInt("heart_rate", -1))
            val classification =
                record.optInt("classification", record.optInt("classifications", 3))
            val sampleRate = record.optDouble("sample_rate", 500.0)

            // 波形数据可内嵌在 record 中，或在随附的 chartRecords 中
            val chartObj = chartRecords[uuid] ?: record
            val rawWaveform = chartObj.optString("value", chartObj.optString("data"))
            val points =
                if (record.has("report")) decodeReport(record.getString("report"))
                else decodeWaveform(rawWaveform)
            val (symptoms, rawSymptoms) = parseSymptoms(record.opt("symptoms"))

            return EcgRecord(
                id = uuid,
                startTime = startTime,
                heartRate = hr,
                classification = classification,
                sampleRate = if (sampleRate > 0) sampleRate else 500.0,
                waveform = points,
                updateTime = record.optLong("update_time", record.optLong("create_time", 0L)),
                symptoms = symptoms,
                rawSymptoms = rawSymptoms,
                ecgAppVersion = optNonBlank(record, "ecg_app_version"),
                timeOffsetMs = parseTimeOffsetMs(record),
                createTime = optPositiveLong(record, "create_time"),
                deviceUuid = optNonBlank(record, "deviceuuid", "device_uuid"),
                pkgName = optNonBlank(record, "pkg_name"),
                comment = optNonBlank(record, "comment"),
            )
        }

        /** Watch x90.getJsonObject: Base64(zlib(big-endian float64[])), not JSON text. */
        fun decodeReport(encoded: String): FloatArray {
            require(encoded.length <= 4 * 1024 * 1024) { "ECG report exceeds input limit" }
            val decoded = Base64.getDecoder().decode(encoded)
            val bytes = MonitorCompression.inflate(decoded, 8 * 120_000)
            require(bytes.isNotEmpty() && bytes.size % 8 == 0) { "Invalid ECG report length" }
            val values = java.nio.ByteBuffer.wrap(bytes).order(java.nio.ByteOrder.BIG_ENDIAN)
            return FloatArray(bytes.size / 8) {
                val value = values.double
                require(value.isFinite() && value.toFloat().isFinite()) { "Invalid ECG sample" }
                value.toFloat()
            }
        }

        /**
         * 解码 ECG 点阵。
         *
         * 格式两种：
         * 1. gzip Base64 编码的字符串；
         * 2. 解码后为 `"[0.012, 0.015, -0.003, ...]"` 或逗号分隔纯数值。
         */
        fun decodeWaveform(encoded: String): FloatArray {
            if (encoded.isBlank()) return FloatArray(0)
            val text = runCatching { HealthJson.inflateJson(encoded) }.getOrDefault(encoded).trim()
            val clean =
                if (text.startsWith("[") && text.endsWith("]")) {
                    text.substring(1, text.length - 1)
                } else text
            if (clean.isBlank()) return FloatArray(0)
            val parts = clean.split(',')
            val result = FloatArray(parts.size)
            var count = 0
            for (p in parts) {
                val f = p.trim().toFloatOrNull()
                if (f != null && f.isFinite()) {
                    result[count++] = f
                }
            }
            return if (count == result.size) result else result.copyOf(count)
        }
    }
}

object EcgLog {
    const val DEFAULT_MAX_KEEP = 1_000

    fun encodeWaveform(waveform: FloatArray): String {
        if (waveform.isEmpty()) return ""
        val buffer =
            java.nio.ByteBuffer.allocate(waveform.size * 4).order(java.nio.ByteOrder.BIG_ENDIAN)
        for (f in waveform) buffer.putFloat(f)
        val compressed = MonitorCompression.deflate(buffer.array())
        return Base64.getEncoder().encodeToString(compressed)
    }

    fun decodeCompressedWaveform(b64: String): FloatArray {
        if (b64.isBlank()) return FloatArray(0)
        val compressed =
            runCatching { Base64.getDecoder().decode(b64) }.getOrNull() ?: return FloatArray(0)
        val bytes =
            runCatching { MonitorCompression.inflate(compressed, 4 * 120_000) }.getOrNull()
                ?: return FloatArray(0)
        if (bytes.size % 4 != 0) return FloatArray(0)
        val buffer = java.nio.ByteBuffer.wrap(bytes).order(java.nio.ByteOrder.BIG_ENDIAN)
        return FloatArray(bytes.size / 4) { buffer.float }
    }

    fun encode(records: List<EcgRecord>): String {
        val array = JSONArray()
        records.forEach { r ->
            val obj =
                JSONObject()
                    .put("id", r.id)
                    .put("start_time", r.startTime)
                    .put("avg_hr", r.heartRate)
                    .put("classification", r.classification)
                    .put("sample_rate", r.sampleRate)
                    .put("update_time", r.updateTime)
            if (r.waveform.isNotEmpty()) {
                obj.put("waveform_b64", encodeWaveform(r.waveform))
            }
            if (r.symptoms.isNotEmpty()) obj.put("symptoms", JSONArray(r.symptoms))
            r.rawSymptoms?.let { obj.put("raw_symptoms", it) }
            r.ecgAppVersion?.let { obj.put("ecg_app_version", it) }
            r.timeOffsetMs?.let { obj.put("time_offset", it) }
            r.createTime?.let { obj.put("create_time", it) }
            r.deviceUuid?.let { obj.put("deviceuuid", it) }
            r.pkgName?.let { obj.put("pkg_name", it) }
            r.comment?.let { obj.put("comment", it) }
            array.put(obj)
        }
        return array.toString()
    }

    fun decode(raw: String?): List<EcgRecord> {
        if (raw.isNullOrBlank()) return emptyList()
        val array = runCatching { JSONArray(raw) }.getOrNull() ?: return emptyList()
        val out = ArrayList<EcgRecord>(array.length())
        for (i in 0 until array.length()) {
            val obj = array.optJSONObject(i) ?: continue
            val id = obj.optString("id")
            if (id.isBlank()) continue
            val time = obj.optLong("start_time")
            if (time <= 0L) continue
            val wave =
                if (obj.has("waveform_b64")) {
                    decodeCompressedWaveform(obj.getString("waveform_b64"))
                } else {
                    val waveArr = obj.optJSONArray("waveform")
                    if (waveArr != null) {
                        FloatArray(waveArr.length()) { waveArr.optDouble(it).toFloat() }
                    } else FloatArray(0)
                }
            val (parsedSymptoms, fallbackRawSymptoms) = EcgRecord.parseSymptoms(obj.opt("symptoms"))
            val rawSymptoms =
                EcgRecord.optNonBlank(obj, "raw_symptoms")
                    ?: if (obj.has("symptoms") && !obj.isNull("symptoms")) fallbackRawSymptoms
                    else null
            out.add(
                EcgRecord(
                    id = id,
                    startTime = time,
                    heartRate = obj.optInt("avg_hr", -1),
                    classification = obj.optInt("classification", 3),
                    sampleRate = obj.optDouble("sample_rate", 500.0),
                    waveform = wave,
                    updateTime = obj.optLong("update_time"),
                    symptoms = parsedSymptoms,
                    rawSymptoms = rawSymptoms,
                    ecgAppVersion = EcgRecord.optNonBlank(obj, "ecg_app_version"),
                    timeOffsetMs = EcgRecord.parseTimeOffsetMs(obj),
                    createTime = EcgRecord.optPositiveLong(obj, "create_time"),
                    deviceUuid = EcgRecord.optNonBlank(obj, "deviceuuid", "device_uuid"),
                    pkgName = EcgRecord.optNonBlank(obj, "pkg_name"),
                    comment = EcgRecord.optNonBlank(obj, "comment"),
                )
            )
        }
        return out.sortedByDescending { it.startTime }
    }

    fun merge(
        existing: List<EcgRecord>,
        incoming: List<EcgRecord>,
        maxKeep: Int = DEFAULT_MAX_KEEP,
    ): List<EcgRecord> {
        val byId = LinkedHashMap<String, EcgRecord>()
        (existing + incoming).sortedWith(compareBy({ it.updateTime }, { it.startTime })).forEach {
            byId[it.id] = it
        }
        return byId.values.sortedByDescending { it.startTime }.take(maxKeep)
    }
}
