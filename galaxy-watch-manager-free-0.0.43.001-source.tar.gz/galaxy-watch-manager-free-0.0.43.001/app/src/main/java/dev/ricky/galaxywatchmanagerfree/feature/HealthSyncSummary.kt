package dev.ricky.galaxywatchmanagerfree.feature

import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.feature.monitor.HealthMonitorSession

internal enum class HealthSyncSummary(val message: Int) {
    DISCONNECTED(R.string.connect_your_watch_to_sync),
    WAITING(R.string.waiting_for_watch_sync),
    SYNCING(R.string.syncing_health_data),
    SYNCED(R.string.health_data_synced),
    SAMSUNG_HEALTH_ONLY(R.string.health_sync_samsung_only),
    MONITOR_ONLY(R.string.health_sync_monitor_only),
    PARTIAL(R.string.health_sync_partial),
    FAILED(R.string.health_sync_failed);

    companion object {
        fun from(state: WatchState): HealthSyncSummary {
            if (!state.sessionReady) return DISCONNECTED
            val health = state.healthSyncStatus
            val monitor = state.monitorState.syncStatus
            if (
                health == HealthSyncCoordinator.Status.SYNCING ||
                    monitor == HealthMonitorSession.SyncStatus.SYNCING
            )
                return SYNCING
            if (
                health == HealthSyncCoordinator.Status.WAITING ||
                    monitor == HealthMonitorSession.SyncStatus.WAITING
            )
                return WAITING
            val healthSynced = health == HealthSyncCoordinator.Status.IDLE
            return when {
                healthSynced && monitor == HealthMonitorSession.SyncStatus.SYNCED -> SYNCED
                healthSynced && monitor == HealthMonitorSession.SyncStatus.PARTIAL -> PARTIAL
                healthSynced -> SAMSUNG_HEALTH_ONLY
                monitor == HealthMonitorSession.SyncStatus.SYNCED ||
                    monitor == HealthMonitorSession.SyncStatus.PARTIAL -> MONITOR_ONLY
                else -> FAILED
            }
        }
    }
}
