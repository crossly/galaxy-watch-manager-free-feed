package dev.ricky.galaxywatchmanagerfree.feature

import android.content.Context
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.core.UiNotify
import dev.ricky.galaxywatchmanagerfree.core.WatchController
import dev.ricky.galaxywatchmanagerfree.feature.monitor.HealthMonitorProtocol
import dev.ricky.galaxywatchmanagerfree.feature.monitor.HealthMonitorSession
import dev.ricky.galaxywatchmanagerfree.wcs.BridgerNotificationSender
import dev.ricky.galaxywatchmanagerfree.wcs.WcsFrame
import dev.ricky.galaxywatchmanagerfree.wcs.WcsPaths
import dev.ricky.galaxywatchmanagerfree.wcs.WcsSession
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

class WatchRepository(
    private val context: Context,
    private val session: WcsSession,
    private val isCurrent: () -> Boolean = { true },
) : WcsSession.Observer {

    private val queryPrefs = context.getSharedPreferences("watchfree_sync", Context.MODE_PRIVATE)
    private var queryPolicy =
        AutoQueryPolicy.fromPreferences(
            queryPrefs.getBoolean("enabled", true),
            queryPrefs.getInt("interval_seconds", AutoQueryPolicy.DEFAULT_INTERVAL_SECONDS),
        )
    private val _state =
        MutableStateFlow(
            WatchState(
                watchNode = session.watchNode,
                phoneNode = session.phoneNode,
                autoRefresh = queryPolicy.enabled,
                autoQueryIntervalSeconds = queryPolicy.intervalSeconds,
            )
        )
    val state: StateFlow<WatchState> = _state.asStateFlow()

    private val _apps = MutableStateFlow<List<String>>(emptyList())
    val apps: StateFlow<List<String>> = _apps.asStateFlow()

    val watchfaceOrder: StateFlow<List<Int>>
        get() = watchfaceController.order

    private val closed = java.util.concurrent.atomic.AtomicBoolean(false)
    private val resourcesClosed = java.util.concurrent.atomic.AtomicBoolean(false)

    private fun isActive(): Boolean = !closed.get() && isCurrent()

    @Volatile private var connectionGeneration = Any()

    val notificationSession: Any?
        get() =
            connectionGeneration.takeIf {
                isActive() && _state.value.let { it.connected && it.sessionReady }
            }

    private val backgroundScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val notificationRecovery = NotificationRecoveryAttempts(backgroundScope)
    private val refresh =
        RefreshCoordinator(
            scope = backgroundScope,
            onRunning = { running -> _state.update { it.copy(refreshing = running) } },
            onLog = LogBus::log,
        )

    val healthMeasurements: HealthMeasurements =
        HealthMeasurements(
            context = context,
            peerAddress = session.peerAddress.orEmpty(),
            scope = backgroundScope,
            watchNode = { session.watchNode },
            send = { packet ->
                isActive() &&
                    _state.value.sessionReady &&
                    session.sendHealthJson(WcsPaths.HEALTH_MESSAGE, packet)
            },
            requestReadback = { healthRepo.requestRecovery() },
        )

    /** 健康数据管线（采样解析、本地档案、投影、持久化、同步握手）。 */
    private val healthRepo: HealthRepository =
        HealthRepository(
            context = context,
            session = session,
            scope = backgroundScope,
            state = _state,
            isActive = ::isActive,
            onMeasurementPreferences = healthMeasurements::receivePreferences,
            onSyncStatus = { status ->
                if (
                    status == HealthSyncCoordinator.Status.IDLE ||
                        status == HealthSyncCoordinator.Status.TIMED_OUT ||
                        status == HealthSyncCoordinator.Status.DISCONNECTED
                ) {
                    refresh.confirm(RefreshCoordinator.Target.HEALTH)
                }
                if (status == HealthSyncCoordinator.Status.IDLE) {
                    backgroundScope.launch {
                        maybeAutoWriteEnergyScores("同步完成")
                        maybeAutoActivateVascularLoad("同步完成")
                    }
                }
            },
            onEnergyScoresReady = { trigger ->
                backgroundScope.launch { maybeAutoWriteEnergyScores(trigger) }
            },
            onVascularLoadRowsSynced = {
                backgroundScope.launch { vascularLoadControl.onRowsSynced() }
            },
            onVascularLoadBackfillCompleted = {
                backgroundScope.launch { maybeAutoActivateVascularLoad("历史回补完成") }
            },
        )

    @Volatile private var lastEnergyAutoWriteAttemptAt = 0L
    @Volatile private var lastVascularAutoActivateAttemptAt = 0L

    private val energyScoreSync =
        EnergyScoreSync(
            scope = backgroundScope,
            watchNode = { session.watchNode },
            deviceModel = { android.os.Build.MODEL.orEmpty() },
            send = { packet ->
                isActive() &&
                    _state.value.sessionReady &&
                    session.sendHealthJson(WcsPaths.HEALTH_MESSAGE, packet)
            },
            onStatus = { status -> _state.update { it.copy(energyScoreSyncStatus = status) } },
            onAccepted = healthRepo::acceptEnergyScores,
            onLog = LogBus::log,
            onError = LogBus::error,
        )

    private val vascularLoadControl =
        VascularLoadControl(
            scope = backgroundScope,
            watchNode = { session.watchNode },
            watchVersion = healthRepo::vascularLoadWatchVersion,
            send = { packet ->
                isActive() &&
                    _state.value.sessionReady &&
                    session.sendHealthJson(WcsPaths.HEALTH_MESSAGE, packet)
            },
            onStatus = { status -> _state.update { it.copy(vascularLoadControlStatus = status) } },
            onResetCreated = {
                backgroundScope.launch {
                    delay(1_500)
                    if (
                        isActive() &&
                            _state.value.sessionReady &&
                            _state.value.vascularLoadControlStatus ==
                                VascularLoadControl.Status.CREATED
                    ) {
                        healthRepo.requestSync()
                    }
                }
            },
            onLog = LogBus::log,
            onError = LogBus::error,
        )

    private val autoQueries =
        AutoQueryCoordinator(
            scope = backgroundScope,
            queryBattery = {
                runCatching { requestBattery() }.onFailure { LogBus.error("[自动查询] 电量请求失败", it) }
            },
            queryHealth = { healthRepo.requestSync() },
            initialPolicy = queryPolicy,
        )
    private val queryPreferenceListener =
        android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key == "enabled" || key == "interval_seconds") {
                applyQueryPolicy(
                    AutoQueryPolicy.fromPreferences(
                        queryPrefs.getBoolean("enabled", true),
                        queryPrefs.getInt(
                            "interval_seconds",
                            AutoQueryPolicy.DEFAULT_INTERVAL_SECONDS,
                        ),
                    )
                )
            }
        }

    /** 最近 25 个健康数据包（诊断用）。 */
    val health: StateFlow<List<HealthPacket>> = healthRepo.packets

    private val settingTemplates = java.util.concurrent.ConcurrentHashMap<String, SettingTemplate>()
    private val lastPhoneWriteAt = java.util.concurrent.ConcurrentHashMap<String, Long>()

    private val settingCommands =
        SettingCommands(
            backgroundScope,
            onPending = { pending ->
                _state.update { it.copy(psmPending = pending[PSM_COMMAND_KEY] as? Boolean) }
            },
            onDebug = LogBus::debug,
            onError = { failure ->
                when (failure) {
                    SettingCommands.Failure.SEND_FAILED -> {
                        UiNotify.show(R.string.settings_send_failed)
                    }
                    SettingCommands.Failure.UNCONFIRMED -> {
                        // Wear OS 默认抑制发自手机端的 DataItem 回声，仅记日志，不弹失败 Toast
                    }
                }
                if (failure == SettingCommands.Failure.UNCONFIRMED) LogBus.debug("[设置] $failure")
                else LogBus.error("[设置] $failure")
            },
        )
    private val watchFindControl =
        WatchFindControl(
            send = { payload -> session.sendRawJson(WcsPaths.FIND_MY_WATCH, payload) },
            onStatus = { next -> _state.update { it.copy(findWatch = next) } },
            onResult = { result ->
                val message =
                    when (result) {
                        WatchFindControl.Result.SEND_FAILED -> R.string.request_send_failed
                        WatchFindControl.Result.START_REJECTED_DURING_CALL ->
                            R.string.find_watch_failed_during_call
                        WatchFindControl.Result.START_REJECTED -> R.string.find_watch_failed
                        WatchFindControl.Result.STOP_REJECTED -> R.string.find_watch_stop_failed
                        WatchFindControl.Result.FINISHED_BY_WATCH ->
                            R.string.find_watch_stopped_on_watch
                        WatchFindControl.Result.STARTED,
                        WatchFindControl.Result.STOPPED -> null
                    }
                message?.let { UiNotify.show(it) }
            },
            onLog = LogBus::log,
        )
    private val watchNameSync =
        WatchNameSync(
            scope = backgroundScope,
            initialAlias = getStoredAlias(),
            watchNode = { session.watchNode },
            requestRead = { session.requestSettingValue(WcsPaths.SET_INFO_WATCH_NAME) },
            write = session::writeSettingItem,
            onName = { name ->
                _state.update { it.copy(watchAlias = name) }
                persistDeviceSnapshot()
            },
            onResult = { result ->
                UiNotify.show(
                    when (result) {
                        WatchNameSync.Result.PENDING -> R.string.rename_pending
                        WatchNameSync.Result.LOCAL_ONLY -> R.string.rename_local_only
                        WatchNameSync.Result.CONFIRMED -> R.string.rename_success
                        WatchNameSync.Result.SEND_FAILED -> R.string.settings_send_failed
                        WatchNameSync.Result.SOURCE_UNAVAILABLE ->
                            R.string.rename_source_unavailable
                        WatchNameSync.Result.SUBMITTED -> R.string.rename_submitted
                    }
                )
            },
            onDebug = LogBus::debug,
        )

    private val dndPrefs =
        context.getSharedPreferences(
            DeviceScope.preferences("watchfree_dnd", session.peerAddress),
            Context.MODE_PRIVATE,
        )
    private val watchDndControl =
        WatchDndControl(
            scope = backgroundScope,
            watchNode = { session.watchNode },
            write = session::writeSettingItem,
            onValue = { enabled ->
                val item =
                    SettingItem(
                        WcsPaths.SET_PHONE_DND_TURN_ON.trimStart('/'),
                        "booleanIsChecked",
                        0L,
                        enabled,
                    )
                _state.update {
                    it.copy(dndOn = enabled, settingItems = it.settingItems + (item.path to item))
                }
                markSynced()
            },
            onPending = { target -> _state.update { it.copy(dndPending = target) } },
            onSubmitted = { target ->
                _state.update { current ->
                    val nextItems =
                        if (target != null) {
                            val clean = WcsPaths.SET_PHONE_DND_TURN_ON.trimStart('/')
                            current.settingItems +
                                (clean to SettingItem(clean, "booleanIsChecked", 0L, target))
                        } else {
                            current.settingItems
                        }
                    current.copy(dndSubmitted = target, settingItems = nextItems)
                }
            },
            loadSubmitted = {
                when {
                    dndPrefs.contains(DND_SUBMITTED_KEY) ->
                        dndPrefs.getBoolean(DND_SUBMITTED_KEY, false)
                    session.watchNode.isNotBlank() && dndPrefs.contains(session.watchNode) ->
                        dndPrefs.getBoolean(session.watchNode, false)
                    else -> null
                }
            },
            saveSubmitted = { target ->
                val editor = dndPrefs.edit()
                if (target == null) editor.remove(DND_SUBMITTED_KEY)
                else editor.putBoolean(DND_SUBMITTED_KEY, target)
                if (session.watchNode.isNotBlank()) editor.remove(session.watchNode)
                editor.apply()
            },
            onResult = { result ->
                val message =
                    when (result) {
                        WatchDndControl.Result.SEND_FAILED -> R.string.settings_send_failed
                        WatchDndControl.Result.SOURCE_UNAVAILABLE -> R.string.dnd_source_unavailable
                        WatchDndControl.Result.SUBMITTED ->
                            if (_state.value.dndSubmitted == true) R.string.dnd_sent_on
                            else R.string.dnd_sent_off
                        WatchDndControl.Result.PENDING,
                        WatchDndControl.Result.CONFIRMED -> null
                    }
                message?.let { UiNotify.show(it) }
            },
            onDebug = LogBus::debug,
        )

    /**
     * 健康监测器通道的发送身份。手表 WearableService 只投递 AppKey（包名+证书）与手表已安装 SHM 一致的消息，
     * 所以默认使用手表端证书；探测过其他可用身份的旧固件按配对地址记住结果，握手无应答时再切换一次。
     */
    @Volatile
    private var monitorSignature =
        session.identityStore.monitorSignature.ifBlank { HealthMonitorProtocol.WATCH_SIGNATURE }

    init {
        session.monitorSignatureProvider = { monitorSignature }
    }

    val monitor =
        HealthMonitorSession(
            backgroundScope,
            send = { path, packet ->
                session.sendRawJson(
                    path,
                    packet,
                    senderPkg = HealthMonitorProtocol.PACKAGE,
                    senderNode = monitorSignature,
                )
            },
            onHandshakeTimeout = {
                val alternate = HealthMonitorProtocol.alternateMessageSignature(monitorSignature)
                if (alternate == monitorSignature) {
                    false
                } else {
                    monitorSignature = alternate
                    LogBus.log(
                        "[健康监测器] 改用" +
                            (if (alternate == HealthMonitorProtocol.WATCH_SIGNATURE) "手表端"
                            else "手机健康") +
                            "证书重试握手"
                    )
                    true
                }
            },
            onHandshakeReady = { retried ->
                if (session.identityStore.rememberMonitorSignature(monitorSignature)) {
                    val suffix = if (retried) "（备用身份生效）" else ""
                    LogBus.debug { "[健康监测器] 通道证书已记录 ${monitorSignature.take(8)}…$suffix" }
                }
            },
            launchRemoteActivity = { pkg, action, cls, categories, extras ->
                session.launchRemoteActivity(pkg, action, cls, categories, extras)
            },
            onEcgReceived = healthRepo::onEcgReceived,
            onBpReceived = healthRepo::onBpReceived,
            onBpConfigurationsReceived = healthRepo::onBpConfigurationsReceived,
            onEcgBatchReceived = healthRepo::onEcgBatchReceived,
            onBpBatchReceived = healthRepo::onBpBatchReceived,
            log = LogBus::log,
            onSyncFeedback = { UiNotify.show(it) },
        )
    private val startupSync: StartupSyncCoordinator =
        StartupSyncCoordinator(
            scope = backgroundScope,
            request = { target ->
                when (target) {
                    StartupSyncCoordinator.Target.WATCH_FACE -> requestActiveWatchface()
                    StartupSyncCoordinator.Target.DEVICE_INFO -> requestFeature()
                    StartupSyncCoordinator.Target.BATTERY -> requestBatteryDetails()
                    StartupSyncCoordinator.Target.WATCH_FACE_ORDER -> requestWatchfaceOrder()
                }
            },
            onPending = { pending, running ->
                _state.update {
                    it.copy(
                        startupSyncing = running,
                        watchfaceRefreshing =
                            running && StartupSyncCoordinator.Target.WATCH_FACE in pending,
                    )
                }
            },
            onLog = LogBus::log,
        )
    private var dayResetJob: Job? = null
    private val watchfaceController: WatchfaceController =
        WatchfaceController(
            scope = backgroundScope,
            state = _state,
            sendJson = session::sendJson,
            onWatchfaceConfirmed = {
                startupSync.confirm(StartupSyncCoordinator.Target.WATCH_FACE)
                refresh.confirm(RefreshCoordinator.Target.WATCH_FACE)
            },
            onOrderConfirmed = {
                startupSync.confirm(StartupSyncCoordinator.Target.WATCH_FACE_ORDER)
                refresh.confirm(RefreshCoordinator.Target.WATCH_FACE_ORDER)
            },
            onPersistSnapshot = ::persistDeviceSnapshot,
            onLog = LogBus::log,
            onDebug = LogBus::debug,
            onError = LogBus::error,
        )

    private fun deviceSnapshotPrefsName(): String? =
        when {
            DeviceScope.address(session.peerAddress) != null ->
                DeviceScope.preferences("watchfree_device", session.peerAddress)
            session.watchNode.isNotBlank() -> "watchfree_device_${session.watchNode}"
            else -> null
        }

    private fun restoreDeviceSnapshot() {
        val scopedName = deviceSnapshotPrefsName() ?: return
        val prefs = context.getSharedPreferences(scopedName, Context.MODE_PRIVATE)
        var encoded = prefs.getString("snapshot", null)
        if (encoded == null && session.watchNode.isNotBlank()) {
            val legacyName = "watchfree_device_${session.watchNode}"
            if (legacyName != scopedName) {
                encoded =
                    context
                        .getSharedPreferences(legacyName, Context.MODE_PRIVATE)
                        .getString("snapshot", null)
                if (encoded != null) {
                    prefs.edit().putString("snapshot", encoded).apply()
                }
            }
        }
        _state.update { DeviceSnapshot.restore(encoded, it) }
        watchfaceController.syncRestoredOrder(_state.value.watchfaceFavoriteIds)
    }

    private fun persistDeviceSnapshot() {
        val scopedName = deviceSnapshotPrefsName() ?: return
        context
            .getSharedPreferences(scopedName, Context.MODE_PRIVATE)
            .edit()
            .putString("snapshot", DeviceSnapshot.encode(_state.value))
            .apply()
    }

    @android.annotation.SuppressLint("MissingPermission")
    private fun readBluetoothAlias(peerAddress: String?): String? {
        if (peerAddress.isNullOrBlank()) return null
        return try {
            val adapter = android.bluetooth.BluetoothAdapter.getDefaultAdapter() ?: return null
            val device = adapter.getRemoteDevice(peerAddress)
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                device.alias
            } else {
                val method = device.javaClass.getMethod("getAlias")
                method.invoke(device) as? String
            }
        } catch (_: Throwable) {
            null
        }
    }

    @android.annotation.SuppressLint("MissingPermission")
    private fun writeBluetoothAlias(peerAddress: String?, alias: String): Boolean {
        if (peerAddress.isNullOrBlank()) return false
        return try {
            val adapter = android.bluetooth.BluetoothAdapter.getDefaultAdapter() ?: return false
            val device = adapter.getRemoteDevice(peerAddress)
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                device.setAlias(alias) == android.bluetooth.BluetoothStatusCodes.SUCCESS
            } else {
                val method = device.javaClass.getMethod("setAlias", String::class.java)
                (method.invoke(device, alias) as? Boolean) ?: true
            }
        } catch (_: Throwable) {
            false
        }
    }

    private fun getStoredAlias(): String {
        val prefs = context.getSharedPreferences("watchfree_aliases", Context.MODE_PRIVATE)
        val address = session.peerAddress.orEmpty().trim().uppercase()
        if (address.isBlank()) return ""
        return prefs.getString("watch_alias_$address", "").orEmpty()
    }

    private fun saveStoredAlias(alias: String) {
        val prefs = context.getSharedPreferences("watchfree_aliases", Context.MODE_PRIVATE)
        val address = session.peerAddress.orEmpty().trim().uppercase()
        if (address.isBlank()) return
        prefs.edit().putString("watch_alias_$address", alias).apply()
    }

    private fun loadWatchAlias(): String {
        val btAlias = readBluetoothAlias(session.peerAddress)?.takeIf { it.isNotBlank() }
        val storedAlias = getStoredAlias().takeIf { it.isNotBlank() }
        return storedAlias ?: btAlias ?: _state.value.watchAlias.takeIf { it.isNotBlank() } ?: ""
    }

    fun setWatchAlias(name: String) {
        if (!isActive()) return
        val trimmed = name.trim().take(32)
        if (trimmed.isBlank()) return
        saveStoredAlias(trimmed)
        writeBluetoothAlias(session.peerAddress, trimmed)
        watchNameSync.rename(trimmed)
    }

    init {
        queryPrefs.registerOnSharedPreferenceChangeListener(queryPreferenceListener)
        session.observer = this
        restoreDeviceSnapshot()
        val initialAlias = loadWatchAlias()
        if (initialAlias.isNotBlank()) {
            _state.update { it.copy(watchAlias = initialAlias) }
        }
        healthRepo.restore()
        healthRepo.scheduleSleepAnalysis()
        backgroundScope.launch {
            monitor.state.collect { mState -> _state.update { it.copy(monitorState = mState) } }
        }
    }

    /** 连接控制器释放旧会话时必须同时释放调度器和设备护理线程。 */
    // Do not hold this monitor while waiting for SHM: its persistence callbacks acquire it.
    internal fun deactivate() {
        closed.set(true)
        session.observer = null
        notificationRecovery.cancel()
        watchfaceController.cancelPending()
        watchNameSync.disconnect()
        watchDndControl.disconnect()
        watchFindControl.disconnect()
        _state.update { it.copy(connected = false, sessionReady = false) }
    }

    fun close() {
        deactivate()
        if (!resourcesClosed.compareAndSet(false, true)) return
        queryPrefs.unregisterOnSharedPreferenceChangeListener(queryPreferenceListener)
        session.observer = null
        monitor.disconnect()
        healthMeasurements.close()
        energyScoreSync.disconnect()
        vascularLoadControl.disconnect()
        lastEnergyAutoWriteAttemptAt = 0L
        lastVascularAutoActivateAttemptAt = 0L
        synchronized(this) {
            refresh.stop()
            startupSync.stop()
            healthRepo.stopSyncPhases()
            settingCommands.clear()
            autoQueries.stop()
            backgroundScope.cancel()
            refreshUsers.set(0)
            dcQueue.shutdownNow()
        }
        session.close()
    }

    fun healthExportSnapshot(): HealthExportSnapshot =
        healthRepo.exportSnapshot().copy(collectionSettings = healthMeasurements.exportSettings())

    suspend fun exerciseRoute(id: String): ExerciseRoute.Route = healthRepo.exerciseRoute(id)

    fun setStepGoal(value: Int?) = healthRepo.setStepGoal(value)

    fun saveEnergyProfile(age: Int, female: Boolean): Boolean =
        healthRepo.saveEnergyProfile(age, female)

    fun calculateEnergyScores(age: Int, female: Boolean): EnergyScoreCalculation? =
        healthRepo.calculateEnergyScores(age, female)

    fun writeEnergyScores(id: String): Boolean {
        val rows = healthRepo.energyScoreRowsForWatch(id)
        if (rows.isEmpty()) return false
        return energyScoreSync.push(rows, automatic = false)
    }

    private fun maybeAutoWriteEnergyScores(trigger: String) {
        if (!isActive()) return
        val today = java.time.LocalDate.now()
        val now = System.currentTimeMillis()
        val decision =
            EnergyScoreAutoWritePolicy.decide(
                records = _state.value.energyScores,
                today = today,
                lastPushedDay = healthRepo.energyScoreAutoPushedDay(),
                sessionReady = _state.value.sessionReady,
                syncInFlight = energyScoreSync.isPending,
                lastAttemptAt = lastEnergyAutoWriteAttemptAt,
                now = now,
            )
        when (decision) {
            is EnergyScoreAutoWritePolicy.Decision.SkipAlreadyAcknowledged -> {
                healthRepo.markEnergyScoreAutoPushedDay(decision.date)
            }
            is EnergyScoreAutoWritePolicy.Decision.Push -> {
                val rows = healthRepo.energyScoreRowsForWatch(decision.record.id, today)
                if (rows.isEmpty()) return
                lastEnergyAutoWriteAttemptAt = now
                LogBus.log("[能量] $trigger 后触发今日能量得分自动回写 date=${decision.record.date}")
                energyScoreSync.push(rows, automatic = true)
            }
            EnergyScoreAutoWritePolicy.Decision.SkipDisconnected,
            EnergyScoreAutoWritePolicy.Decision.SkipInFlight,
            EnergyScoreAutoWritePolicy.Decision.SkipNoTodayScore,
            EnergyScoreAutoWritePolicy.Decision.SkipAlreadyPushedToday,
            EnergyScoreAutoWritePolicy.Decision.SkipCooldown -> Unit
        }
    }

    fun addManualNap(startMillis: Long, endMillis: Long): Boolean =
        healthRepo.addManualNap(startMillis, endMillis)

    fun removeManualNap(startMillis: Long, endMillis: Long): Boolean =
        healthRepo.removeManualNap(startMillis, endMillis)

    fun manualNaps(): List<SleepParser.ManualNap> = healthRepo.manualNaps()

    fun requestHealthSync(): Boolean {
        val health = healthRepo.requestSync()
        if (_state.value.sessionReady) monitor.requestAllSync()
        return health
    }

    fun requestHealthModule(
        module: String,
        fromStartOfDay: Boolean = true,
        hours: Int = 0,
    ): Boolean = healthRepo.requestModule(module, fromStartOfDay, hours)

    fun requestHealthRecovery(): Boolean = healthRepo.requestRecovery()

    fun requestVascularLoadSync(): Boolean = healthRepo.requestVascularLoadSync()

    fun resetVascularLoadBaseline(): Boolean {
        if (!isActive() || !_state.value.sessionReady || !_state.value.vascularLoadSupported) {
            return false
        }
        return vascularLoadControl.activateOrReset(userInitiated = true, automatic = false)
    }

    private fun maybeAutoActivateVascularLoad(trigger: String) {
        if (!isActive()) return
        val current = _state.value
        val now = System.currentTimeMillis()
        val decision =
            VascularLoadAutoActivatePolicy.decide(
                supported = current.vascularLoadSupported,
                sessionReady = current.sessionReady,
                healthSyncIdle = current.healthSyncStatus == HealthSyncCoordinator.Status.IDLE,
                controlInFlight = vascularLoadControl.isPending,
                labSettingEnabled = healthMeasurements.state.value.vascularLoad.enabled,
                historyVerified = healthRepo.isVascularLoadHistoryVerified(),
                snapshot = current.vascularLoad,
                lastAttemptAt = lastVascularAutoActivateAttemptAt,
                now = now,
            )
        if (decision is VascularLoadAutoActivatePolicy.Decision.Activate) {
            lastVascularAutoActivateAttemptAt = now
            LogBus.log("[血管负荷] $trigger 后检测到当前手表尚未建立基线，自动初始化手表基线")
            vascularLoadControl.activateOrReset(userInitiated = true, automatic = true)
        }
    }

    private fun receiveHealthMessage(json: JSONObject) {
        healthRepo.confirmHealthIdentity()
        if (
            energyScoreSync.handleMessage(json) ||
                vascularLoadControl.handleMessage(json) ||
                healthMeasurements.handleMessage(json)
        )
            return
        val type = json.optString("type")
        val sender = json.optString("sender")
        val receiver = json.optString("receiver")
        val isSyncData =
            (type.isBlank() || type.equals(WcsPaths.HEALTH_TYPE_DATA, ignoreCase = true)) &&
                (sender.isBlank() ||
                    sender == WcsPaths.HEALTH_WATCH_SYNC ||
                    receiver.isBlank() ||
                    receiver == WcsPaths.HEALTH_PHONE_SYNC)
        if (!isSyncData) {
            LogBus.debug {
                "[健康] 忽略非同步辅助消息 type=$type sender=$sender receiver=$receiver seq=${json.optInt("sequence_num")}"
            }
            return
        }
        healthRepo.handleMessage(json, HealthPacket.Direction.FROM_WATCH)
    }

    fun onWearApiConnected(nodeName: String, nodeId: String) {
        onLog("WearApi: 已连上手表 $nodeName ($nodeId)")
    }

    fun onWearApiDisconnected(error: String? = null) {
        onLog("WearApi: 手表节点已断开${error?.let { ": $it" }.orEmpty()}")
    }

    fun handleWearApiMessage(path: String, data: ByteArray) {
        val payload = data.toString(Charsets.UTF_8)
        val json = runCatching { JSONObject(payload) }.getOrNull()
        if (json != null) {
            when (path) {
                WcsPaths.INTERNAL_FEATURE -> applyFeature(json)
                WcsPaths.INTERNAL_STATUS -> applyStatus(json)
                WcsPaths.STF -> applyStf(json)
                WcsPaths.INDICATOR_BATTERY,
                WcsPaths.INDICATOR_BATTERY_RSP -> applyIndicatorBattery(json)
                else ->
                    if (path.startsWith(WcsPaths.HEALTH_MESSAGE)) {
                        receiveHealthMessage(json)
                    }
            }
        }
        LogBus.debug { "[WearApi←] path=$path bytes=${data.size} parsed=${json != null}" }
    }

    override fun onSessionReady() {
        if (!isActive()) return
        _state.update { state ->
            state.copy(
                sessionReady = true,
                watchNode = session.watchNode,
                phoneNode = session.phoneNode,
                onboardingStatus = OnboardingStatus.VERIFYING_IDENTITY,
                onboardingMessage = "",
            )
        }
        LogBus.log("会话已就绪，优先查询表盘、设备资料和电池状态")
        startupSync.start()
        NotificationListenerRecovery.requestRebindIfNeeded(context)
        syncNotificationFeatures()
        watchNameSync.connect()
        watchDndControl.connect()
        watchFindControl.connect()
        backgroundScope.launch {
            delay(1500)
            if (_state.value.sessionReady) monitor.connect()
        }
        healthRepo.resetDayIfNeeded()
        if (dayResetJob?.isActive != true) {
            dayResetJob =
                backgroundScope.launch {
                    while (true) {
                        delay(60_000)
                        healthRepo.resetDayIfNeeded()
                    }
                }
        }
        healthRepo.startSyncPhases()
        lastEnergyAutoWriteAttemptAt = 0L
        lastVascularAutoActivateAttemptAt = 0L
        autoQueries.start()
    }

    override fun onIdentityRequired() {
        _state.update {
            it.copy(onboardingStatus = OnboardingStatus.IDENTITY_MISSING, onboardingMessage = "")
        }
        UiNotify.show(R.string.phone_node_required, long = true)
    }

    override fun onWatchNodeChanged(node: String) {
        settingTemplates.clear()
        lastPhoneWriteAt.clear()
        _state.update { state -> state.copy(watchNode = node) }
        restoreDeviceSnapshot()
    }

    override fun onLog(line: String) {
        LogBus.log(line)
    }

    override fun onHandshake(msg: WcsFrame.Incoming) {
        if (msg is WcsFrame.Incoming.SyncStart) syncNotificationFeatures()
        // NodeInfo 里带设备名
        if (msg is WcsFrame.Incoming.NodeInfo && !msg.deviceName.isNullOrBlank()) {
            val alias = loadWatchAlias()
            _state.update { state ->
                state.copy(
                    deviceName = msg.deviceName!!,
                    watchAlias = alias.ifBlank { state.watchAlias },
                )
            }
        }
    }

    override fun onWearPath(msg: WcsFrame.Incoming.WearPath) {
        if (!isActive()) return
        val (_, cleanPath) = WcsFrame.splitWearPath(msg.path)
        val dataMap = msg.dataMap
        LogBus.debug { "[仓库←] DataItem path=$cleanPath data=${LogBus.describe(dataMap)}" }
        if (dataMap.isEmpty()) return
        // Samsung's alternate DataClient carrier uses the same outer health JSON.
        if (cleanPath.startsWith(WcsPaths.HEALTH_MESSAGE + "/wearable_to_mobile")) {
            if (msg.deleted) return
            val payload = dataMap["data_payload_key"] as? String
            if (payload != null) {
                runCatching { receiveHealthMessage(JSONObject(payload)) }
                    .onFailure { LogBus.error("[健康] DataItem 消息解析失败", it) }
            } else if (dataMap["is_support_data_asset_key"] == true) {
                LogBus.debug { "[健康] 忽略手表调试导出 Asset 引用（仅用于导出 DB/日志，不影响正常健康同步）" }
            }
            return
        }
        val dataMapId = (dataMap["dataMapId"] as? Number)?.toInt() ?: 0

        // 1. 电池与设备护理 (c_devicecare/battery/...)
        if (cleanPath.startsWith("/c_devicecare/battery")) {
            if (dataMapId == WcsPaths.DC_MAP_BATTERY_SETTING) {
                applyBatterySetting(dataMap)
            } else {
                applyDeviceCareBattery(cleanPath, dataMapId, dataMap)
            }
            return
        }

        // 2. 内存 (c_devicecare/memory/...)
        if (cleanPath.startsWith("/c_devicecare/memory")) {
            applyDeviceCareMemory(dataMapId, dataMap)
            return
        }

        // 3. 手表系统设置 (w_module_sec_watch_setting/...)
        if (cleanPath.startsWith("/w_module_sec_watch_setting")) {
            applyWatchSetting(msg.path, dataMap)
            return
        }
    }

    /** 电池保护设置（dataMapId=206, key_battery_setting_status=[protect, chargingInfo, autoPowerOn]） */
    private fun applyBatterySetting(dataMap: Map<String, Any>) {
        val dataMapId = (dataMap["dataMapId"] as? Number)?.toInt() ?: 0
        @Suppress("UNCHECKED_CAST") val data = (dataMap["data"] as? Map<String, Any>) ?: dataMap
        val arr = data["key_battery_setting_status"]
        val values: List<Int> =
            when (arr) {
                is List<*> -> arr.mapNotNull { (it as? Number)?.toInt() }
                is Number -> listOf(arr.toInt())
                else -> emptyList()
            }
        if (values.isEmpty()) {
            LogBus.debug { "[电池设置] id=$dataMapId 无状态数组 data=${LogBus.describe(dataMap)}" }
            return
        }
        settingCommands.confirm(WcsPaths.DEVICECARE_BATTERY_SETTING, values[0] == 1)
        _state.update { state ->
            state.copy(
                batteryProtection = values.getOrElse(0) { -1 },
                showChargingInfo = values.getOrElse(1) { -1 },
                autoPowerOn = values.getOrElse(2) { -1 },
            )
        }
        LogBus.debug {
            "[电池设置] 保护=${values.getOrElse(0) { -1 }} 充电信息=${values.getOrElse(1) { -1 }} 自动开机=${values.getOrElse(2) { -1 }}"
        }
        refresh.confirm(RefreshCoordinator.Target.BATTERY_SETTING)
    }

    /**
     * DeviceCare 电池数据。
     *
     * 官方 schema（BatteryUsageResponseCmd.setBatteryUsageStatsData）： data.dartbattery_info =
     * {battery_level, status, time_remaining, rut_psm_off, rut_psm_on, psm_status,
     * time_since_charged, wearable_psm_control_restricted, wearable_protected_fully,
     * usage_time_for_full_charge} 部分推送（dataMapId=200 的 change 事件）会把这些字段直接平铺在 data 下。
     */
    private fun applyDeviceCareBattery(path: String, dataMapId: Int, dataMap: Map<String, Any>) {
        @Suppress("UNCHECKED_CAST") val data = (dataMap["data"] as? Map<String, Any>) ?: dataMap
        @Suppress("UNCHECKED_CAST") val info = (data["battery_info"] as? Map<String, Any>) ?: data

        if ((info["battery_level"] as? Number)?.toInt() in 0..100) {
            startupSync.confirm(StartupSyncCoordinator.Target.BATTERY)
            refresh.confirm(RefreshCoordinator.Target.BATTERY)
        }
        if (hasDeviceCareBatteryPayload(info)) {
            when (dataMapId) {
                WcsPaths.DC_MAP_BATTERY_BASE_INFO ->
                    refresh.confirm(RefreshCoordinator.Target.BATTERY_DETAILS)
                WcsPaths.DC_MAP_BATTERY_USAGE ->
                    refresh.confirm(RefreshCoordinator.Target.BATTERY_USAGE)
            }
        }
        (info["psm_status"] as? Boolean)?.let { settingCommands.confirm(PSM_COMMAND_KEY, it) }
        val before = _state.value
        _state.update { current ->
            var s = current
            (info["battery_level"] as? Number)?.toInt()?.let {
                if (it in 0..100) s = s.copy(batteryLevel = it)
            }
            (info["psm_status"] as? Boolean)?.let {
                s = s.copy(psmMode = it)
                psmKnown = true
            }
            (info["status"] as? Number)?.toInt()?.let {
                // Android BatteryManager：2=充电中 3=放电中 4=未充电 5=已充满
                s = s.copy(batteryStatus = it, charging = it == 2 || it == 5)
            }
            (info["time_remaining"] as? Number)?.toLong()?.let {
                s = s.copy(chargeTimeRemainingMs = it)
            }
            s = s.withBatteryEstimates(info)
            (info["wearable_psm_control_restricted"] as? Number)?.toInt()?.let {
                s = s.copy(psmControlRestricted = it != 0)
            }

            // 有可清理应用列表时顺带记下（dataMapId=200/202）
            @Suppress("UNCHECKED_CAST")
            val appList = data["app_usage_list"] as? List<Map<String, Any>>
            if (appList != null) {
                val apps = LinkedHashMap<String, Long>()
                val cleanable = ArrayList<String>()
                appList.forEach { a ->
                    val pkg = a["package"] as? String ?: return@forEach
                    apps[pkg] = ((a["memory_used"] as? Number)?.toLong() ?: 0L)
                    val isCleanable = (a["cleanable"] as? Boolean) ?: true
                    if (isCleanable && !isProtectedMemoryCleanPackage(pkg)) {
                        cleanable.add(pkg)
                    }
                }
                if (apps.isNotEmpty()) {
                    val fallback = apps.keys.filterNot(::isProtectedMemoryCleanPackage)
                    s = s.copy(ramApps = apps, ramCleanableApps = cleanable.ifEmpty { fallback })
                }
            }

            s
        }
        val s = _state.value
        if (s != before) {
            LogBus.debug {
                "[设备护理] $path id=$dataMapId 电量=${s.batteryLevel}% status=${s.batteryStatus} " +
                    "PSM=${s.psmMode} 常规=${s.remainingNormalMin}min 省电=${s.remainingPsmMin}min " +
                    "estimatesReceived=${s.normalBatteryEstimateReceived}/${s.psmBatteryEstimateReceived} " +
                    "rut_psm_off=${info["rut_psm_off"]}(${info["rut_psm_off"]?.javaClass?.simpleName ?: "missing"}) " +
                    "rut_psm_on=${info["rut_psm_on"]}(${info["rut_psm_on"]?.javaClass?.simpleName ?: "missing"}) " +
                    "keys=${info.keys}"
            }
        }
    }

    /**
     * DeviceCare 内存数据（MemoryUsageRespondCmd）。 data = {mem_total, mem_available,
     * memory_usage_list:[{package,name,uid,memory_used,cleanable}]}
     */
    private fun applyDeviceCareMemory(dataMapId: Int, dataMap: Map<String, Any>) {
        @Suppress("UNCHECKED_CAST") val data = (dataMap["data"] as? Map<String, Any>) ?: dataMap
        val total = (data["mem_total"] as? Number)?.toLong() ?: 0L
        val available = (data["mem_available"] as? Number)?.toLong() ?: 0L
        if (total <= 0) {
            LogBus.debug { "[设备护理] 内存响应无 mem_total data=${LogBus.describe(dataMap)}" }
            return
        }
        val mb = 1024L * 1024L
        val (apps, cleanable) = parseDeviceCareMemory(dataMap)
        _state.update { state ->
            state.copy(
                ramTotalMb = total / mb,
                ramAvailableMb = available / mb,
                ramUsedMb = (total - available) / mb,
                ramApps = apps,
                ramCleanableApps = cleanable,
            )
        }
        LogBus.debug {
            "[设备护理] 内存 id=$dataMapId 已用 ${(total - available) / mb}MB / 共 ${total / mb}MB，" +
                "应用数=${apps.size} data=${LogBus.describe(dataMap)}"
        }
        if (dataMapId == WcsPaths.DC_MAP_MEMORY_USAGE) {
            refresh.confirm(RefreshCoordinator.Target.MEMORY)
        }
    }

    /**
     * 系统设置同步（setting_info / 单项推送）。
     *
     * 手表推送的 DataMap 两种形态： 带元数据：{from=watch, key=intLevel, intLevel=103, type=1, time=...} 只有值：
     * {from=watch, booleanIsChecked=false, time=...}（accessibility 类） 两者都归一化为
     * SettingItem（path/key/type/value），供 UI 直接读写。
     */
    private fun applyWatchSetting(uri: String, dataMap: Map<String, Any>) {
        val (owner, path) = WcsFrame.splitWearPath(uri)
        if (path == WcsPaths.SET_INFO_WATCH_NAME) watchNameSync.receive(uri, dataMap)
        if (path == WcsPaths.SET_PHONE_DND_TURN_ON) {
            watchDndControl.receive(uri, dataMap)
            return
        }
        val cleanPath = path.trimStart('/')
        val isWatchOwned = !owner.isNullOrBlank() && owner == session.watchNode
        if (isWatchOwned) {
            settingTemplates[cleanPath] = SettingTemplate(uri, dataMap.toMap())
        }
        if (dataMap["from"] == "phone") {
            // Phone-originated echoes never confirm a pending write, but watch-owned items
            // replicated back from the watch or snapshot restore hydrate state for settings whose
            // watch handlers suppress `from=watch` echoes (e.g. wake_on_wrist_raised).
            if (isWatchOwned && !settingCommands.hasPending(cleanPath)) {
                val itemTime = (dataMap["time"] as? Number)?.toLong() ?: 0L
                val minTime = lastPhoneWriteAt[cleanPath] ?: 0L
                if (itemTime >= minTime) {
                    val item =
                        WatchSettingSchema.decode(path, dataMap, allowPhoneOrigin = true) ?: return
                    val spec = WatchSettingSchema.spec(item.path)
                    if (spec?.path == WcsPaths.SET_INFO_WATCH_NAME) {
                        _state.update {
                            it.copy(settingItems = it.settingItems + (item.path to item))
                        }
                        return
                    }
                    _state.update { state ->
                        val next =
                            state.copy(settingItems = state.settingItems + (item.path to item))
                        WatchSettingSchema.project(spec, next, item.value)
                    }
                }
            }
            return
        }
        val item = WatchSettingSchema.decode(path, dataMap) ?: return
        markSynced()
        val clean = item.path
        lastPhoneWriteAt.remove(clean)
        val rawValue = item.value
        val spec = WatchSettingSchema.spec(clean)
        if (spec?.path == WcsPaths.SET_INFO_WATCH_NAME) {
            _state.update { it.copy(settingItems = it.settingItems + (clean to item)) }
            return
        }
        if (settingCommands.hasPending(clean)) {
            LogBus.debug { "[设置] 手表反馈 $clean {${item.key}=$rawValue} from=${dataMap["from"]}" }
        }

        // 下发值与回包值类型可能不同（PSM 下发 Boolean、回包 0/1），归一后再确认一次
        if (!settingCommands.confirm(clean, rawValue)) {
            spec?.kind?.canonicalize(rawValue)?.let { settingCommands.confirm(clean, it) }
        }
        if (spec === WatchSettingSchema.PSM) psmKnown = true
        _state.update { state ->
            val next = state.copy(settingItems = state.settingItems + (clean to item))
            WatchSettingSchema.project(spec, next, rawValue)
        }
        if (clean == WcsPaths.SET_INFO.trimStart('/')) {
            refresh.confirm(RefreshCoordinator.Target.SETTINGS)
        }
    }

    override fun onMonitorChannel(path: String, payload: ByteArray) {
        if (!isActive()) return
        val channel = HealthMonitorProtocol.Channel.fromPath(path) ?: return
        try {
            val jobs =
                dev.ricky.galaxywatchmanagerfree.feature.monitor.MonitorChannelFrames.decode(
                    payload
                )
            LogBus.debug("[健康监测器] $path 收到 ${jobs.size} 个同步任务 bytes=${payload.size}")
            monitor.receiveSyncBatch(channel, jobs)
        } catch (error: Exception) {
            LogBus.error("[健康监测器] Channel 解码失败 bytes=${payload.size}", error)
        }
    }

    override fun onMessage(msg: WcsFrame.Incoming.Wearable) {
        if (!isActive()) return
        if (
            msg.path == HealthMonitorProtocol.PLAIN_CONNECTION ||
                HealthMonitorProtocol.Channel.fromPath(msg.path) != null
        ) {
            monitor.receive(msg.path, msg.payloadRaw)
            return
        }
        val json = runCatching { JSONObject(msg.payload) }.getOrNull() ?: return
        when (msg.path) {
            WcsPaths.INTERNAL_FEATURE ->
                if (msg.envType == WcsFrame.TYPE_RESPONSE) {
                    applyFeature(json)
                }
            WcsPaths.INTERNAL_STATUS ->
                if (msg.envType == WcsFrame.TYPE_RESPONSE) {
                    applyStatus(json)
                }
            WcsPaths.STF -> applyStf(json)
            WcsPaths.INDICATOR_BATTERY_RSP,
            WcsPaths.INDICATOR_BATTERY -> applyIndicatorBattery(json)
            WcsPaths.DEVICECARE_BATTERY_BASE -> {
                val lvl = json.optInt("battery_level", json.optInt("level", -1))
                if (lvl in 0..100) {
                    _state.update { state -> state.copy(batteryLevel = lvl) }
                    refresh.confirm(RefreshCoordinator.Target.BATTERY)
                    refresh.confirm(RefreshCoordinator.Target.BATTERY_DETAILS)
                }
            }
            WcsPaths.DEVICECARE_BATTERY_PSM -> {
                val psm = json.optInt("extraData", -1)
                if (psm >= 0) {
                    psmKnown = true
                    settingCommands.confirm(PSM_COMMAND_KEY, psm == 1)
                    _state.update { state -> state.copy(psmMode = (psm == 1)) }
                    LogBus.log("[PSM] 手表确认：${if (psm == 1) "已开启省电" else "已退出省电"}")
                }
            }
            WcsPaths.SYSUI_APPS -> applyApps(json)
            WcsPaths.WATCHFACE_SYSUI -> watchfaceController.handleMessage(json)
            WcsPaths.HEALTH_CAPABILITY -> healthRepo.handleCapability(json)
            WcsPaths.FIND_MY_WATCH -> watchFindControl.handleMessage(json)
            WcsPaths.NOTI_SETTINGS -> applyNotificationSettings(json)
            else -> {
                if (msg.path.startsWith(WcsPaths.HEALTH_MESSAGE)) {
                    receiveHealthMessage(json)
                }
            }
        }
    }

    private val refreshUsers = java.util.concurrent.atomic.AtomicInteger(0)
    var autoRefreshEnabled: Boolean
        get() = state.value.autoRefresh
        set(value) = updateQueryPolicy(enabled = value)

    fun setAutoQueryIntervalSeconds(value: Int) {
        require(value in AutoQueryPolicy.INTERVALS_SECONDS)
        updateQueryPolicy(intervalSeconds = value)
    }

    @Synchronized
    private fun updateQueryPolicy(enabled: Boolean? = null, intervalSeconds: Int? = null) {
        if (!isActive()) return
        val value =
            queryPolicy.copy(
                enabled = enabled ?: queryPolicy.enabled,
                intervalSeconds = intervalSeconds ?: queryPolicy.intervalSeconds,
            )
        applyQueryPolicy(value)
        queryPrefs
            .edit()
            .putBoolean("enabled", value.enabled)
            .putInt("interval_seconds", value.intervalSeconds)
            .apply()
    }

    @Synchronized
    private fun applyQueryPolicy(value: AutoQueryPolicy) {
        if (!isActive()) return
        queryPolicy = value
        LogBus.debug(
            "[自动查询] enabled=${value.enabled} intervalSeconds=${value.intervalSeconds} visibleUsers=${refreshUsers.get()}"
        )
        _state.update {
            it.copy(autoRefresh = value.enabled, autoQueryIntervalSeconds = value.intervalSeconds)
        }
        autoQueries.configure(value)
    }

    @Synchronized
    fun startAutoRefresh() {
        refreshUsers.incrementAndGet()
        autoQueries.setVisible(true)
    }

    @Synchronized
    fun stopAutoRefresh() {
        if (refreshUsers.decrementAndGet() <= 0) {
            refreshUsers.set(0)
            autoQueries.setVisible(false)
        }
    }

    /** 任意状态数据落地时更新时间戳 */
    private fun markSynced() {
        val now = System.currentTimeMillis()
        if (now - _state.value.lastSyncAt > 500) {
            _state.update { state -> state.copy(lastSyncAt = now) }
        }
    }

    fun onTransportState(connected: Boolean) {
        LogBus.debug(
            "[仓库] transport=$connected previousReady=${_state.value.sessionReady} active=${isActive()}"
        )
        _state.update { state ->
            state.copy(
                connected = connected,
                sessionReady = if (connected) state.sessionReady else false,
            )
        }
        if (connected) {
            session.onTransportConnected()
        } else {
            connectionGeneration = Any()
            notificationRecovery.cancel()
            watchfaceController.cancelPending()
            refresh.stop()
            settingCommands.clear()
            lastPhoneWriteAt.clear()
            watchNameSync.disconnect()
            watchDndControl.disconnect()
            watchFindControl.disconnect()
            monitor.disconnect()
            psmKnown = false
            startupSync.stop()
            autoQueries.stop()
            energyScoreSync.disconnect()
            vascularLoadControl.disconnect()
            lastEnergyAutoWriteAttemptAt = 0L
            lastVascularAutoActivateAttemptAt = 0L
            healthRepo.stopSyncPhases()
            dayResetJob?.cancel()
            dayResetJob = null
        }
    }

    fun refreshAll(): Boolean {
        if (closed.get() || !_state.value.canRefresh) return false
        return refresh.request { token ->
            fun deviceCare(target: RefreshCoordinator.Target, tag: String, send: () -> Unit) {
                val queued = dc(tag, isCurrent = { refresh.isPending(token, target) }, block = send)
                if (!queued) refresh.confirm(target)
            }
            requestFeature()
            requestStatus()
            requestBattery()
            deviceCare(RefreshCoordinator.Target.BATTERY_DETAILS, "battery/base_info") {
                session.sendBatteryBaseInfoReq()
            }
            deviceCare(RefreshCoordinator.Target.BATTERY_USAGE, "battery/refresh") {
                session.sendBatteryRefreshReq()
            }
            deviceCare(RefreshCoordinator.Target.BATTERY_SETTING, "battery/setting(read)") {
                session.sendBatterySettingReq()
            }
            deviceCare(RefreshCoordinator.Target.MEMORY, "memory/usage") {
                session.sendMemoryUsageReq()
            }
            requestSettingInfo()
            requestApps()
            requestWatchfaceOrder()
            if (
                !requestHealthSync() &&
                    _state.value.healthSyncStatus != HealthSyncCoordinator.Status.SYNCING
            ) {
                refresh.confirm(RefreshCoordinator.Target.HEALTH)
            }
            requestActiveWatchface()
        }
    }

    fun requestFeature() {
        session.sendJson(
            WcsPaths.INTERNAL_FEATURE,
            WcsPaths.MSG_FEATURE_EXCHANGE,
            2,
            session.buildPhoneFeature(),
        )
    }

    fun requestStatus() {
        session.sendJson(
            WcsPaths.INTERNAL_STATUS,
            WcsPaths.MSG_STATUS_EXCHANGE,
            2,
            session.buildPhoneStatus(),
        )
    }

    private fun applyFeature(json: JSONObject) {
        val d = json.optJSONObject("data") ?: json
        _state.update { state ->
            state.copy(
                modelNumber = d.optString("modelNumber", state.modelNumber),
                modelName = d.optString("modelName", state.modelName),
                deviceName = d.optString("deviceName", state.deviceName),
                firmware = d.optString("buildId", state.firmware),
                androidVersion = d.optString("androidVersion", state.androidVersion),
                batteryLevel = d.optInt("batteryLevel", state.batteryLevel),
                batteryCapacityMah = d.optString("batteryCapacity", state.batteryCapacityMah),
                esimSupported = d.optBoolean("esimSupport", state.esimSupported),
                eid = d.optString("eid", state.eid),
                actionButton = d.optBoolean("actionButton", state.actionButton),
                featureInfoReceived = true,
            )
        }
        if (_state.value.modelNumber.isNotBlank() || _state.value.modelName.isNotBlank()) {
            startupSync.confirm(StartupSyncCoordinator.Target.DEVICE_INFO)
            persistDeviceSnapshot()
        }
        if (d.optString("modelNumber").isNotBlank() || d.optString("modelName").isNotBlank()) {
            refresh.confirm(RefreshCoordinator.Target.FEATURE)
        }
    }

    private fun applyStatus(json: JSONObject) {
        val d = json.optJSONObject("data") ?: json
        _state.update { state ->
            state.copy(
                wearOs = d.optString("wearos", state.wearOs),
                wearing = d.optBoolean("wearingState", state.wearing),
                imei = d.optString("imei", state.imei),
                eid = d.optString("eid", state.eid).ifBlank { state.eid },
            )
        }
        _state.update { state -> state.copy(sessionReady = true) }
        persistDeviceSnapshot()
        if (listOf("wearos", "wearingState", "imei", "eid").any(d::has)) {
            refresh.confirm(RefreshCoordinator.Target.STATUS)
        }
    }

    fun requestBattery() {
        session.sendJson(WcsPaths.STF, "stf_battery_req", 1, JSONObject())
        session.sendEmpty(WcsPaths.BATTERY_STATE_REQUEST)
    }

    private val dcQueue: java.util.concurrent.ExecutorService =
        java.util.concurrent.Executors.newSingleThreadExecutor { r ->
            Thread(r, "devicecare-q").apply { isDaemon = true }
        }
    private val dcGapMs = 1500L
    @Volatile private var lastDcAt = 0L

    @Volatile private var psmKnown = false

    private fun dc(tag: String, isCurrent: () -> Boolean = { true }, block: () -> Unit): Boolean {
        if (dcQueue.isShutdown || !isActive() || !_state.value.sessionReady) return false
        val generation = connectionGeneration
        try {
            dcQueue.execute {
                try {
                    if (!isActive() || generation !== connectionGeneration || !isCurrent())
                        return@execute
                    val wait = dcGapMs - (System.currentTimeMillis() - lastDcAt)
                    LogBus.debug(
                        "[设备护理] queued=$tag throttleMs=${wait.coerceAtLeast(0)} ready=${_state.value.sessionReady}"
                    )
                    if (wait in 1..dcGapMs) Thread.sleep(wait)
                    if (
                        !isActive() ||
                            generation !== connectionGeneration ||
                            !_state.value.sessionReady ||
                            Thread.currentThread().isInterrupted ||
                            !isCurrent()
                    )
                        return@execute
                    lastDcAt = System.currentTimeMillis()
                    LogBus.debug("[设备护理→] $tag")
                    runCatching(block).onFailure { LogBus.error("[设备护理] $tag 失败", it) }
                } catch (_: InterruptedException) {
                    Thread.currentThread().interrupt()
                }
            }
            return true
        } catch (_: java.util.concurrent.RejectedExecutionException) {
            return false
        }
    }

    /** 主动刷新电池详细信息 (DeviceCare base_info) */
    fun requestBatteryDetails() {
        dc("battery/base_info") { session.sendBatteryBaseInfoReq() }
    }

    /** 拉取电池用量与续航估算 (dataMapId=202，含 rut_psm_off / rut_psm_on) */
    fun requestBatteryUsage() {
        dc("battery/refresh") { session.sendBatteryRefreshReq() }
    }

    /** 读取电池保护设置 (dataMapId=206) */
    fun requestBatterySetting() {
        dc("battery/setting(read)") { session.sendBatterySettingReq() }
    }

    /** 设置电池保护模式（充电上限 80% 等）；withSettings=false 时只改保护开关 */
    fun setBatteryProtection(enabled: Boolean) {
        val sent =
            settingCommands.submit(
                WcsPaths.DEVICECARE_BATTERY_SETTING,
                enabled,
                enqueue = { action -> dc("battery/setting(write)", block = action) },
            ) {
                session.sendBatterySetting(
                    protection = if (enabled) 1 else 0,
                    showChargingInfo = -1,
                    autoPowerOn = -1,
                )
            }
        if (sent) {
            _state.update { it.copy(batteryProtection = if (enabled) 1 else 0) }
            UiNotify.show(R.string.setting_sent_pending)
        }
    }

    /** 切换手表省电模式 (PSM) */
    fun setPowerSavingMode(enabled: Boolean) {
        if (!isActive() || !_state.value.sessionReady || _state.value.psmControlRestricted) return
        if (
            psmKnown &&
                _state.value.psmMode == enabled &&
                !settingCommands.hasPending(PSM_COMMAND_KEY)
        )
            return
        val previous = _state.value.psmMode
        val sent =
            settingCommands.submit(
                PSM_COMMAND_KEY,
                enabled,
                retries = 2,
                enqueue = { action -> dc("battery/psm=$enabled", block = action) },
                onFailure = { failure ->
                    _state.update { state ->
                        if (state.psmMode == enabled) state.copy(psmMode = previous) else state
                    }
                    if (failure == SettingCommands.Failure.UNCONFIRMED) {
                        UiNotify.show(R.string.psm_unconfirmed)
                    }
                },
            ) {
                session.sendPsmMode(enabled)
            }
        if (sent) {
            _state.update { it.copy(psmMode = enabled) }
        }
    }

    /** 请求内存信息 */
    fun requestMemory() {
        dc("memory/usage") { session.sendMemoryUsageReq() }
    }

    /** 一键清理手表后台应用内存 */
    fun cleanRam(apps: List<String>? = null) {
        val base =
            apps ?: _state.value.ramCleanableApps.ifEmpty { _state.value.ramApps.keys.toList() }
        val targets = base.filterNot(::isProtectedMemoryCleanPackage)
        if (targets.isEmpty()) {
            LogBus.log("[设备护理] 内存清理无有效目标（已过滤健康及保护应用）")
            return
        }
        val queued =
            dc("memory/clean") {
                val sent = session.sendMemoryClean(targets)
                if (!sent) {
                    UiNotify.show(R.string.request_send_failed)
                    return@dc
                }
                dcQueue.execute {
                    try {
                        Thread.sleep(1200)
                        if (_state.value.sessionReady) requestMemory()
                    } catch (_: InterruptedException) {
                        Thread.currentThread().interrupt()
                    }
                }
            }
        UiNotify.show(if (queued) R.string.memory_clean_sent else R.string.request_send_failed)
    }

    private fun applyStf(json: JSONObject) {
        if (json.optString("msg_id") != WcsPaths.MSG_STF_BATTERY_RSP) return
        val inner = runCatching { JSONObject(json.optString("data")) }.getOrNull() ?: return
        val level = inner.optInt("batteryLevel", -1)
        if (level in 0..100) {
            _state.update { state -> state.copy(batteryLevel = level) }
            markSynced()
            refresh.confirm(RefreshCoordinator.Target.BATTERY)
        }
    }

    private fun applyIndicatorBattery(json: JSONObject) {
        val level = json.optInt("batteryLevel", json.optInt("level", -1))
        if (level in 0..100) {
            _state.update { state -> state.copy(batteryLevel = level) }
            markSynced()
            refresh.confirm(RefreshCoordinator.Target.BATTERY)
        }
        val charging = json.optBoolean("charging", json.optBoolean("isCharging", false))
        _state.update { state -> state.copy(charging = charging) }
    }

    fun setAod(enabled: Boolean) {
        updateSetting("w_module_sec_watch_setting/display/always_on_display", enabled)
    }

    fun setWakeOnWrist(enabled: Boolean) {
        updateSetting("w_module_sec_watch_setting/display/wake_on_wrist_raised", enabled)
    }

    fun setBrightness(level: Int) {
        val clamped = level.coerceIn(0, 100)
        updateSetting("w_module_sec_watch_setting/display/brightness", clamped)
    }

    fun setOutdoorMode(enabled: Boolean) {
        updateSetting("w_module_sec_watch_setting/display/outdoor_mode", enabled)
    }

    fun setScreenTimeout(item: Int) {
        updateSetting("w_module_sec_watch_setting/display/screen_time_out/selected_item", item)
    }

    fun setGrayscale(enabled: Boolean) {
        updateSetting("w_module_sec_watch_setting_accessibility/grayscale", enabled)
    }

    fun setHighContrastFonts(enabled: Boolean) {
        updateSetting("w_module_sec_watch_setting_accessibility/high_contrast_fonts", enabled)
    }

    fun setMuteAllSounds(enabled: Boolean) {
        updateSetting("w_module_sec_watch_setting_accessibility/mute_all_sound", enabled)
    }

    fun setDndTurnOnNow(enabled: Boolean) {
        watchDndControl.setEnabled(enabled)
    }

    fun setWakeOnTouch(enabled: Boolean) {
        setBool(WcsPaths.SET_DISPLAY_WAKE_TOUCH, enabled)
    }

    fun setWakeOnBezel(enabled: Boolean) {
        setBool(WcsPaths.SET_DISPLAY_WAKE_BEZEL, enabled)
    }

    fun setTouchSound(enabled: Boolean) {
        setBool(WcsPaths.SET_SOUND_TOUCH, enabled)
    }

    fun setChargingSound(enabled: Boolean) {
        setBool(WcsPaths.SET_SOUND_CHARGING, enabled)
    }

    fun setGestureAnswer(enabled: Boolean) {
        setBool(WcsPaths.SET_ADV_GESTURE_ANSWER, enabled)
    }

    fun setGestureDismiss(enabled: Boolean) {
        setBool(WcsPaths.SET_ADV_GESTURE_DISMISS, enabled)
    }

    fun setQuickLaunch(enabled: Boolean) {
        setBool("w_module_sec_watch_setting/advanced/labs/quicklaunch/support", enabled)
    }

    fun setWristOrientation(rightWrist: Boolean) {
        setInt(WcsPaths.SET_GENERAL_WRIST, if (rightWrist) 1 else 0)
    }

    fun setNegativeColors(enabled: Boolean) {
        setBool("w_module_sec_watch_setting_accessibility/negative_colors", enabled)
    }

    fun setRemoveAnimations(enabled: Boolean) {
        setBool("w_module_sec_watch_setting_accessibility/remove_animations", enabled)
    }

    /** 找手表：响铃与振动 */
    fun startFindingWatch() {
        watchFindControl.start()
    }

    /** 停止找手表 */
    fun stopFindingWatch() {
        watchFindControl.stop()
    }

    /** 兼容旧接口 */
    fun findMyWatch() {
        watchFindControl.toggle()
    }

    fun syncNotificationFeatures() {
        val target = notificationSession ?: return
        notificationRecovery.start { index ->
            if (notificationSession !== target || !WatchController.forwardNotifications)
                return@start true
            val queued = sendNotificationFeatures()
            LogBus.log("[通知] 桥接特性和设置入队=$queued attempt=${index + 1}")
            // NodeInfo can mark the local session ready before the peer finishes SyncStart.
            index > 0 && queued
        }
    }

    private fun sendNotificationFeatures(): Boolean {
        val bridgeQueued =
            session.sendJson(
                WcsPaths.NOTI_BRIDGE,
                WcsPaths.MSG_NOTIFICATION_FEATURE_EXCHANGE,
                0,
                JSONObject()
                    .put("version", "1.0.0")
                    .put("voip", true)
                    .put("mutePending", true)
                    .put("multiUser", true)
                    .put("phoneActiveStatus", false),
            )
        val settingsFeatureQueued =
            session.sendJson(
                WcsPaths.NOTI_SETTINGS,
                WcsPaths.MSG_NOTIFICATION_SETTINGS_FEATURE_EXCHANGE,
                0,
                JSONObject()
                    .put("version", "1.0.0")
                    .put("enhancedPhoneAlertMute", 2)
                    .put("showDetails", true)
                    .put("showAppsManage", true)
                    .put("enhancedReadNotificationAloud", true),
                sender = "mobile",
            )
        val settingsQueued =
            session.sendJson(
                WcsPaths.NOTI_SETTINGS,
                WcsPaths.MSG_NOTIFICATION_SETTINGS,
                1,
                JSONObject()
                    .put(
                        "alerts_on_watch",
                        if (NotificationFilterPreferences.muteWhileUsingPhone.value) 0 else 1,
                    )
                    .put("alerts_on_phone", 1)
                    .put("notification_indicator", true)
                    .put("notification_aloud", false)
                    .put("read_notification_aloud_v2", 0)
                    .put("show_with_details", true)
                    .put("turn_on_screen", true)
                    .put("turn_on_for_new_apps", false),
                sender = "mobile",
            )
        return bridgeQueued && settingsFeatureQueued && settingsQueued
    }

    /** 同步“使用手机时不提醒手表”设置到手表 */
    fun syncAlertsOnWatch(muteWhileUsingPhone: Boolean) {
        val value = if (muteWhileUsingPhone) 0 else 1
        session.sendJson(
            WcsPaths.NOTI_SETTINGS,
            WcsPaths.MSG_SET_SETTINGS_ALERTS_ON_WATCH,
            0,
            JSONObject().put("value", value),
            sender = "mobile",
        )
        LogBus.log(
            "[通知] 同步使用手机时不提醒至手表: alerts_on_watch=$value (muteWhileUsingPhone=$muteWhileUsingPhone)"
        )
    }

    private fun applyNotificationSettings(json: JSONObject) {
        val d = json.optJSONObject("data") ?: json
        when (json.optString("msgId")) {
            WcsPaths.MSG_SET_SETTINGS_ALERTS_ON_WATCH -> {
                val value = d.optInt("value", -1)
                if (value == 0) {
                    NotificationFilterPreferences.setMuteWhileUsingPhone(true)
                    LogBus.log("[通知] 收到手表设置变更: alerts_on_watch=0 -> 使用手机时不提醒开启")
                } else if (value == 1) {
                    NotificationFilterPreferences.setMuteWhileUsingPhone(false)
                    LogBus.log("[通知] 收到手表设置变更: alerts_on_watch=1 -> 使用手机时不提醒关闭")
                }
            }
            WcsPaths.MSG_SET_SETTINGS_ALERTS_ON_WATCH_WHILE_USING_PHONE -> {
                if (d.has("value")) {
                    val enabled = d.optBoolean("value")
                    NotificationFilterPreferences.setMuteWhileUsingPhone(!enabled)
                    LogBus.log(
                        "[通知] 收到手表设置变更: alert_on_watch_while_using_phone=$enabled -> muteWhileUsingPhone=${!enabled}"
                    )
                }
            }
        }
    }

    /** 下发允许通知的应用白名单 */
    fun setAllowedPackages(packages: List<String>) {
        val arr = JSONArray()
        packages.forEach { pkg ->
            arr.put(
                JSONObject().put("userId", 0).put("packageName", pkg).put("packageType", "mobile")
            )
        }
        session.sendJson(
            WcsPaths.NOTI_SETTINGS,
            WcsPaths.MSG_NOTIFICATION_ALLOWED_PACKAGES,
            1,
            JSONObject().put("list", arr),
            sender = "mobile",
        )
    }

    @androidx.annotation.WorkerThread
    internal fun postNotification(
        packageName: String,
        title: String,
        body: String,
        tag: String = "",
        time: Long = System.currentTimeMillis(),
        appName: String? = null,
        appIcon: ByteArray? = null,
        smallIcon: ByteArray? = null,
        isSmallIconVector: Boolean = false,
        identity: NotificationIdentity = NotificationIdentity.generated(packageName, tag),
        allowTextFallback: Boolean = true,
        uploadAssets: Boolean = true,
    ): BridgerNotificationSender.Result? {
        val target = notificationSession ?: return BridgerNotificationSender.Result.REJECTED
        val resolvedAppName =
            appName?.takeIf { it.isNotBlank() }
                ?: NotificationAppCatalog.appName(context, packageName)
        val icon = appIcon ?: NotificationAppCatalog.forwardingIcon(context, packageName)
        if (notificationSession !== target) return BridgerNotificationSender.Result.REJECTED
        return session.writeBridgerNotification(
            title = title,
            text = body,
            identity = identity,
            appName = resolvedAppName,
            whenMillis = time,
            appIcon = icon,
            smallIcon = smallIcon,
            isSmallIconVector = isSmallIconVector,
            allowTextFallback = allowTextFallback,
            uploadAssets = uploadAssets,
        )
    }

    /** 诊断：向任意 path 发送任意消息体，用于协议探针实验 */
    fun probe(path: String, msgId: String, msgType: Int, data: JSONObject?) {
        session.sendJson(path, msgId, msgType, data)
        LogBus.debug {
            "[PROBE→] $path msgId=$msgId msgType=$msgType data=${LogBus.describe(data)}"
        }
    }

    @androidx.annotation.WorkerThread
    fun sendTestNotification(title: String? = null, text: String? = null): Boolean {
        val strings = dev.ricky.galaxywatchmanagerfree.core.AppLanguage.context(context).resources
        val ok =
            postNotification(
                    packageName = "dev.ricky.galaxywatchmanagerfree",
                    title = title ?: strings.getString(R.string.app_name),
                    body = text ?: strings.getString(R.string.test_notification_body),
                    tag = "test_${System.currentTimeMillis()}",
                    appName = "Galaxy Watch Manager Free",
                )
                ?.queued == true
        LogBus.log("[通知] 测试通知已排队=$ok")
        return ok
    }

    @androidx.annotation.WorkerThread
    fun sendBridgerNotification(
        packageName: String = "com.tencent.mm",
        title: String,
        text: String,
        appName: String? = null,
    ): Boolean {
        return postNotification(
                packageName = packageName,
                title = title,
                body = text,
                appName = appName,
            )
            ?.queued == true
    }

    /**
     * 诊断：用纯色图标走完整图标链路，判定手表端是否真正渲染 `app_icon` / `icon`。
     *
     * @param mode `app`（只下发 app_icon）、`small`（只下发 icon）、`both`（双资产）、`none`（无图标）
     */
    @androidx.annotation.WorkerThread
    fun sendIconProbeNotification(
        packageName: String,
        appName: String,
        color: String,
        mode: String,
    ): Boolean {
        val argb =
            try {
                android.graphics.Color.parseColor(color)
            } catch (_: IllegalArgumentException) {
                android.graphics.Color.MAGENTA
            }
        val appIcon =
            if (mode == "app" || mode == "both" || mode == "fetch") {
                NotificationAppCatalog.solidIcon(argb, NotificationAppCatalog.MAX_APP_ICON_SIZE)
            } else {
                null
            }
        val smallIcon =
            if (mode == "small" || mode == "both") {
                NotificationAppCatalog.solidIcon(argb, NotificationAppCatalog.MAX_SMALL_ICON_SIZE)
            } else {
                null
            }
        return postNotification(
                packageName = packageName,
                title = "图标探针",
                body = "mode=$mode color=$color",
                appName = appName,
                appIcon = appIcon,
                smallIcon = smallIcon,
                identity = NotificationIdentity.generated(packageName, "probe_$mode"),
                allowTextFallback = true,
                uploadAssets = mode != "fetch",
            )
            ?.queued == true
    }

    fun requestSettingInfo() {
        session.sendEmpty(WcsPaths.SET_INFO_REQ)
        session.sendJson(WcsPaths.SET_FEATURE, "feature", 0, JSONObject())
    }

    private val WRITE_RETRIES = 0

    fun settingItems(): Map<String, SettingItem> = _state.value.settingItems

    fun updateSetting(path: String, value: Any, keyHint: String? = null) {
        val clean = path.trimStart('/')
        val spec = WatchSettingSchema.spec(clean)
        if (clean == WcsPaths.SET_PHONE_DND_TURN_ON.trimStart('/')) {
            if (value is Boolean) setDndTurnOnNow(value)
            return
        }
        if (spec?.path == WcsPaths.SET_INFO_WATCH_NAME) {
            if (value is String) setWatchAlias(value)
            return
        }
        // 优先级：手表上报过的真实 key > 规格表 > 调用方提示 > 兜底猜测
        val item = _state.value.settingItems[clean]
        val key = item?.key ?: spec?.key ?: keyHint ?: guessKey(clean, value)
        val type =
            item?.type
                ?: when (value) {
                    is Boolean -> 0L
                    is Number -> 1L
                    is String -> 3L
                    is List<*> -> 5L
                    is Map<*, *> -> 9L
                    else -> 3L
                }
        val now = System.currentTimeMillis()
        val writeRequest =
            WatchSettingSchema.buildWrite(
                cleanPath = clean,
                key = key,
                type = type,
                value = value,
                watchNode = session.watchNode,
                phoneNode = session.phoneNode,
                template = settingTemplates[clean],
                now = now,
            )
        if (writeRequest == null) {
            UiNotify.show(R.string.settings_send_failed)
            return
        }
        val readBackAction: () -> Unit =
            if (spec?.supportsReadBack == true) ({ session.requestSettingValue(clean) }) else ({})
        val sent =
            settingCommands.submit(
                clean,
                value,
                retries = WRITE_RETRIES,
                readBack = readBackAction,
            ) {
                session.writeSettingItem(writeRequest.uri, writeRequest.dataMap)
            }
        if (sent) {
            lastPhoneWriteAt[clean] = now
            if (WcsFrame.splitWearPath(writeRequest.uri).first == session.watchNode) {
                settingTemplates[clean] = SettingTemplate(writeRequest.uri, writeRequest.dataMap)
            }
            val optimisticItem = SettingItem(clean, key, type, value)
            _state.update { state ->
                val next = state.copy(settingItems = state.settingItems + (clean to optimisticItem))
                WatchSettingSchema.project(spec, next, value)
            }
            UiNotify.show(R.string.setting_sent_to_watch)
        }
    }

    fun setBool(path: String, value: Boolean) = updateSetting(path, value)

    fun setInt(path: String, value: Int) = updateSetting(path, value)

    /** 未登记进 [WatchSettingSchema] 的路径才走到这里；新设置项应优先补表。 */
    private fun guessKey(path: String, value: Any): String =
        when {
            value is Boolean -> "booleanIsChecked"
            value is String -> "stringName"
            value is List<*> -> "arrayItemList"
            path.endsWith("selected_item") || path.contains("selected_") -> "intSelectedItem"
            path.endsWith("psm") -> "key_psm_status"
            else -> "intLevel"
        }

    fun requestApps() {
        session.sendJson(WcsPaths.SYSUI_APPS, WcsPaths.MSG_APPS_ORDER, 0, JSONObject())
    }

    private fun applyApps(json: JSONObject) {
        val d = json.optJSONObject("data") ?: return
        val arr = d.optJSONArray("apps") ?: return
        val out = ArrayList<String>()
        for (i in 0 until arr.length()) {
            val folder = arr.optJSONObject(i) ?: continue
            val items = folder.optJSONArray("items") ?: continue
            for (k in 0 until items.length()) {
                val it = items.optJSONObject(k) ?: continue
                val pkg = it.optString("packageName")
                if (pkg.isNotEmpty()) out.add(pkg)
            }
        }
        _apps.value = out
        refresh.confirm(RefreshCoordinator.Target.APPS)
    }

    fun requestWatchfaceOrder() = watchfaceController.requestOrder()

    /** 查询手表当前生效的活跃表盘 */
    fun requestActiveWatchface() = watchfaceController.requestActive()

    /** 设置手表当前活跃表盘（切换表盘） */
    fun setActiveWatchface(pkg: String, cls: String): Boolean =
        watchfaceController.setActive(pkg, cls)

    fun setActiveWatchface(preset: WatchFacePreset): Boolean =
        watchfaceController.setActive(preset.packageName, preset.className)

    fun setWatchfaceOrderType(mode: String): Boolean = watchfaceController.setOrderType(mode)

    /** 用户点了「在手表上编辑表盘」的引导（清掉标记） */
    fun clearWatchfaceEditRequest() = watchfaceController.clearEditRequest()

    fun requestMediaState() {
        session.sendBytes(WcsPaths.MEDIA_UPDATE, Proto.EMPTY_MEDIA_QUERY)
    }

    private companion object {
        const val DND_SUBMITTED_KEY = "submitted"
        val PSM_COMMAND_KEY = WcsPaths.SET_PSM.trimStart('/')
    }
}

internal fun WatchState.withBatteryEstimates(info: Map<String, Any>): WatchState {
    var state = this
    (info["rut_psm_off"] as? Number)?.toInt()?.let {
        state = state.copy(remainingNormalMin = it, normalBatteryEstimateReceived = true)
    }
    (info["rut_psm_on"] as? Number)?.toInt()?.let {
        state = state.copy(remainingPsmMin = it, psmBatteryEstimateReceived = true)
    }
    return state
}

private val DEVICE_CARE_BATTERY_PAYLOAD_FIELDS =
    setOf(
        "status",
        "time_remaining",
        "rut_psm_off",
        "rut_psm_on",
        "psm_status",
        "time_since_charged",
        "wearable_psm_control_restricted",
        "wearable_protected_fully",
        "usage_time_for_full_charge",
    )

/** Metadata-only DataMap frames must not complete a battery detail refresh. */
internal fun hasDeviceCareBatteryPayload(info: Map<String, Any>): Boolean =
    (info["battery_level"] as? Number)?.toInt() in 0..100 ||
        DEVICE_CARE_BATTERY_PAYLOAD_FIELDS.any { info[it] is Number || info[it] is Boolean }

/** 判断是否为不应在内存清理中终止的系统健康或受保护应用 */
internal fun isProtectedMemoryCleanPackage(pkg: String): Boolean {
    val lower = pkg.trim().lowercase()
    return lower.contains("shealth") || lower.contains("health")
}

/** 解析 DeviceCare 内存数据中的应用占用与可清理名单 */
internal fun parseDeviceCareMemory(
    dataMap: Map<String, Any>
): Pair<Map<String, Long>, List<String>> {
    @Suppress("UNCHECKED_CAST") val data = (dataMap["data"] as? Map<String, Any>) ?: dataMap
    val mb = 1024L * 1024L
    val apps = LinkedHashMap<String, Long>()
    val cleanable = ArrayList<String>()
    val rawList = data["memory_usage_list"]
    @Suppress("UNCHECKED_CAST")
    val list =
        when (rawList) {
            is List<*> -> rawList.filterIsInstance<Map<String, Any>>()
            is Map<*, *> -> listOf(rawList as Map<String, Any>)
            else -> emptyList()
        }
    list.forEach { a ->
        val pkg = a["package"] as? String ?: return@forEach
        val used = (a["memory_used"] as? Number)?.toLong() ?: 0L
        if (used > 0) {
            apps[pkg] = used / mb
            val isCleanable = (a["cleanable"] as? Boolean) ?: true
            if (isCleanable && !isProtectedMemoryCleanPackage(pkg)) {
                cleanable.add(pkg)
            }
        }
    }
    val fallback = apps.keys.filterNot(::isProtectedMemoryCleanPackage)
    return apps to cleanable.ifEmpty { fallback }
}

/** 媒体 RPC 用的最小 protobuf 载荷 */
private object Proto {
    /** /adaptive_media_bridging/rpc/media_update 的空查询（实测等价形态） */
    val EMPTY_MEDIA_QUERY: ByteArray = byteArrayOf(0x12, 0x00, 0x22, 0x02, 0x08, 0x01)
}
