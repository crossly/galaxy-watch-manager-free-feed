package dev.ricky.galaxywatchmanagerfree.wcs

import java.util.Locale
import java.util.TimeZone
import org.json.JSONObject

internal object PhoneFeature {
    fun build(
        bluetoothName: String,
        screenWidth: Int,
        screenHeight: Int,
        defaultSmsPackage: String,
        locale: Locale,
        timeZone: TimeZone,
        timeMillis: Long,
    ): JSONObject =
        JSONObject()
            .put("deviceBtName", bluetoothName)
            .put("screenWidth", screenWidth.toString())
            .put("screenHeight", screenHeight.toString())
            // Watch SHM gates ECG/BP on this companion identity; preserve non-Samsung support.
            .put("deviceName", "Galaxy S25 Ultra")
            .put("modelNumber", "SM-S938U1")
            .put("vender", "samsung")
            .put("isTablet", "false")
            .put("csc", "XAA")
            .put("locale", locale.toString())
            .put("timezone", timeZone.id)
            .put("time", timeMillis)
            .put("sepLiteDevice", "false")
            .put("defaultAppMessage", defaultSmsPackage)
}
