package dev.ricky.galaxywatchmanagerfree.feature

import dev.ricky.galaxywatchmanagerfree.wcs.BridgerNotificationSender.Result
import java.net.URLEncoder
import java.util.concurrent.atomic.AtomicInteger

internal class NotificationForwardingCache {
    private data class Submission(val content: String, val result: Result)

    private var session: Any? = null
    private val forwarded = mutableMapOf<String, Submission>()

    @Synchronized
    fun forward(
        target: Any,
        key: String,
        content: String,
        send: (allowTextFallback: Boolean) -> Result?,
    ): Result? {
        if (session !== target) {
            forwarded.clear()
            session = target
        }
        val previous = forwarded[key]
        val unchanged = previous?.content == content
        if (unchanged && previous?.result == Result.WITH_ICON) return null
        val result = send(!unchanged)
        if (result?.queued == true) forwarded[key] = Submission(content, result)
        return result
    }

    @Synchronized
    fun remove(key: String) {
        forwarded.remove(key)
    }
}

/** A notification update reuses its original Android identity, independent of its timestamp. */
data class NotificationIdentity(
    val packageName: String,
    val id: Int,
    val tag: String?,
    val userId: Int,
    val uid: Int,
) {
    val key: String
        get() = "$userId|$packageName|$id|${tag ?: "null"}|$uid"

    fun bridgerPath(authority: String): String =
        "bridger/stream_item:$authority:$packageName:$id:${tag?.let(::component) ?: "null_tag"}:${component(key)}"

    companion object {
        private val generatedIds = AtomicInteger()

        fun generated(packageName: String, tag: String? = null): NotificationIdentity =
            NotificationIdentity(packageName, generatedIds.incrementAndGet(), tag, 0, 1000)

        private fun component(value: String): String =
            URLEncoder.encode(value, "UTF-8").replace("+", "%20")
    }
}
