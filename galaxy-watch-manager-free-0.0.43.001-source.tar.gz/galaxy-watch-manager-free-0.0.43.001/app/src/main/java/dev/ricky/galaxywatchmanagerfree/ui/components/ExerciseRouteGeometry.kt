package dev.ricky.galaxywatchmanagerfree.ui.components

import dev.ricky.galaxywatchmanagerfree.feature.ExerciseRoute
import kotlin.math.PI
import kotlin.math.atan
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.tan

internal class ExerciseRouteGeometry(route: ExerciseRoute.Route) {
    data class Vertex(val longitude: Double, val latitude: Double) {
        val x = longitude / 360.0
        val y = -ln(tan(PI / 4 + Math.toRadians(latitude) / 2)) / (2 * PI)
    }

    private val longitudes = route.points.map { it.longitude }.distinct().sorted()
    private val west =
        longitudes.indices
            .maxByOrNull { index ->
                val next = longitudes[(index + 1) % longitudes.size]
                next + (if (index == longitudes.lastIndex) 360 else 0) - longitudes[index]
            }
            ?.let { longitudes[(it + 1) % longitudes.size] } ?: 0.0
    // Unwrap only the rendering copy across the largest empty longitude gap.
    val segments =
        route.segments.map { segment ->
            segment.map { point ->
                Vertex(
                    if (point.longitude < west) point.longitude + 360 else point.longitude,
                    point.latitude.coerceIn(-85.05112878, 85.05112878),
                )
            }
        }
    private val vertices = segments.flatten()
    val minX = vertices.minOfOrNull { it.x } ?: 0.0
    val maxX = vertices.maxOfOrNull { it.x } ?: 0.0
    val minY = vertices.minOfOrNull { it.y } ?: 0.0
    val maxY = vertices.maxOfOrNull { it.y } ?: 0.0
    val centerLongitude = (minX + maxX) * 180
    val centerLatitude = Math.toDegrees(2 * atan(exp(-(minY + maxY) * PI)) - PI / 2)
}
