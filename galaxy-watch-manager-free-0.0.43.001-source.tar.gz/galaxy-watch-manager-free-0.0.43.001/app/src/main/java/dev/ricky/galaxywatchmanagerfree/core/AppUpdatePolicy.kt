package dev.ricky.galaxywatchmanagerfree.core

import java.net.URI
import org.json.JSONObject

/**
 * Pure parser, endpoint planner, cache validator, and evaluator for remote force-update and
 * emergency app discontinuation (`policy.json`) hosted alongside the public update feed.
 *
 * Fail-open invariant: malformed payloads, unknown schema/modes, network timeouts, or missing
 * policy files MUST evaluate to [Decision.Allow]. Blocking only occurs when an explicitly valid
 * policy matches the running `versionCode`.
 */
object AppUpdatePolicy {
    const val SCHEMA_VERSION = 1
    const val EXPECTED_PACKAGE = "dev.ricky.galaxywatchmanagerfree"
    const val POLICY_FILE = "policy.json"
    const val DEFAULT_CACHE_TTL_MS = 24 * 3600_000L
    const val MIRROR_NOT_FOUND_QUORUM = 2

    private const val MAX_TITLE_CHARS = 200
    private const val MAX_MESSAGE_CHARS = 2000
    private val TRUSTED_ACTION_HOSTS = setOf("github.com", "raw.githubusercontent.com")

    enum class Mode(val id: String) {
        NONE("none"),
        FORCE_UPDATE("force_update"),
        BLOCK("block");

        companion object {
            fun fromId(raw: String?): Mode? = entries.firstOrNull { it.id == raw?.trim() }
        }
    }

    data class Policy(
        val mode: Mode,
        val minSupportedVersionCode: Int = 0,
        val blockedVersionCodes: Set<Int> = emptySet(),
        val targetVersionName: String? = null,
        val targetVersionCode: Int? = null,
        val title: String? = null,
        val titleZh: String? = null,
        val message: String? = null,
        val messageZh: String? = null,
        val actionUrl: String? = null,
        val updatedAt: String? = null,
    ) {
        fun localizedTitle(isChinese: Boolean): String? =
            if (isChinese) titleZh ?: title else title ?: titleZh

        fun localizedMessage(isChinese: Boolean): String? =
            if (isChinese) messageZh ?: message else message ?: messageZh
    }

    sealed interface Decision {
        data object Allow : Decision

        data class ForceUpdate(val policy: Policy) : Decision

        data class Block(val policy: Policy) : Decision
    }

    /**
     * Parses `policy.json`. Any schema mismatch, wrong package, unknown mode, or ambiguous
     * `force_update` without a version threshold/list returns `null` (fail-open).
     */
    fun parsePolicy(json: String, expectedPackage: String = EXPECTED_PACKAGE): Policy? {
        val root = runCatching { JSONObject(json) }.getOrNull() ?: return null
        if (root.optInt("schema_version", -1) != SCHEMA_VERSION) return null
        if (root.textOrNull("package") != expectedPackage) return null
        val mode = Mode.fromId(root.textOrNull("mode")) ?: return null
        val minSupported = root.optInt("min_supported_version_code", 0).coerceAtLeast(0)
        val blockedCodes = buildSet {
            val arr = root.optJSONArray("blocked_version_codes") ?: return@buildSet
            for (i in 0 until arr.length()) {
                val code = arr.optInt(i, -1)
                if (code > 0) add(code)
            }
        }
        if (mode == Mode.FORCE_UPDATE && minSupported <= 0 && blockedCodes.isEmpty()) {
            return null
        }
        val targetCode = root.optInt("target_version_code", 0).takeIf { it > 0 }
        return Policy(
            mode = mode,
            minSupportedVersionCode = minSupported,
            blockedVersionCodes = blockedCodes,
            targetVersionName =
                root.textOrNull("target_version_name")?.removePrefix("v")?.removePrefix("V"),
            targetVersionCode = targetCode,
            title = root.textOrNull("title")?.take(MAX_TITLE_CHARS),
            titleZh = root.textOrNull("title_zh")?.take(MAX_TITLE_CHARS),
            message = root.textOrNull("message")?.take(MAX_MESSAGE_CHARS),
            messageZh = root.textOrNull("message_zh")?.take(MAX_MESSAGE_CHARS),
            actionUrl = root.textOrNull("action_url")?.takeIf(::isTrustedActionUrl),
            updatedAt = root.textOrNull("updated_at"),
        )
    }

    /** Evaluates whether [currentVersionCode] is allowed, must force-update, or is blocked. */
    fun evaluate(policy: Policy?, currentVersionCode: Int): Decision {
        if (policy == null || currentVersionCode <= 0) return Decision.Allow
        val matchesTargeted =
            (policy.minSupportedVersionCode > 0 &&
                currentVersionCode < policy.minSupportedVersionCode) ||
                currentVersionCode in policy.blockedVersionCodes
        return when (policy.mode) {
            Mode.NONE -> Decision.Allow
            Mode.FORCE_UPDATE ->
                if (matchesTargeted) Decision.ForceUpdate(policy) else Decision.Allow
            Mode.BLOCK -> {
                val blocksAll =
                    policy.minSupportedVersionCode <= 0 && policy.blockedVersionCodes.isEmpty()
                if (blocksAll || matchesTargeted) Decision.Block(policy) else Decision.Allow
            }
        }
    }

    /**
     * Orders candidate endpoints for resilient fetching in regions where direct GitHub access is
     * unreliable:
     * - When the user chose a mirror, try that mirror first, then remaining mirrors, then direct.
     * - When mirror is OFF, try direct GitHub first (zero third-party traffic when reachable), then
     *   fall back to built-in mirrors automatically.
     */
    fun candidateMirrors(preferred: DownloadMirror): List<DownloadMirror> {
        val proxies = DownloadMirror.entries.filter { it != DownloadMirror.OFF }
        return if (preferred == DownloadMirror.OFF) {
            listOf(DownloadMirror.OFF) + proxies
        } else {
            listOf(preferred) + proxies.filter { it != preferred } + DownloadMirror.OFF
        }
    }

    /**
     * A cached confirmed policy only applies to the exact installed `versionCode` and expires after
     * [ttlMs], ensuring an app upgrade immediately clears it and an unreachable repo cannot brick
     * the app forever.
     */
    fun isCachedPolicyValid(
        cachedForVersionCode: Int,
        currentVersionCode: Int,
        fetchedAt: Long,
        now: Long,
        ttlMs: Long = DEFAULT_CACHE_TTL_MS,
    ): Boolean =
        cachedForVersionCode > 0 &&
            cachedForVersionCode == currentVersionCode &&
            fetchedAt > 0L &&
            now - fetchedAt in 0L until ttlMs

    /**
     * Decides whether HTTP 404 responses should clear an existing cached block. Direct GitHub 404
     * is authoritative; when direct GitHub is unreachable (e.g. China networks), requiring at least
     * [MIRROR_NOT_FOUND_QUORUM] independent built-in mirrors to return 404 prevents a single broken
     * mirror from bypassing a live policy while still unlocking users once `policy.json` is
     * deleted.
     */
    fun shouldTreatNotFoundAsCleared(
        directNotFound: Boolean,
        distinctMirrorNotFoundCount: Int,
    ): Boolean = directNotFound || distinctMirrorNotFoundCount >= MIRROR_NOT_FOUND_QUORUM

    /**
     * Returns true only when [candidate] provides a downloadable APK that is strictly newer than
     * the running app AND satisfies [policy] (so installing it will actually unlock the user).
     */
    fun isReleaseEligibleForForceUpdate(
        policy: Policy,
        currentVersionName: String,
        currentVersionCode: Int,
        candidate: AppUpdate.ReleaseInfo,
    ): Boolean {
        if (candidate.apkUrl.isNullOrBlank()) return false
        val candidateCode = candidate.versionCode ?: return false
        if (!AppUpdate.isNewer(currentVersionName, currentVersionCode, candidate)) return false
        return evaluate(policy, candidateCode) == Decision.Allow
    }

    internal fun isTrustedActionUrl(url: String): Boolean {
        val uri = runCatching { URI(url) }.getOrNull() ?: return false
        if (uri.scheme?.lowercase() != "https") return false
        val host = uri.host?.lowercase() ?: return false
        return host in TRUSTED_ACTION_HOSTS
    }

    private fun JSONObject.textOrNull(key: String): String? {
        if (!has(key) || isNull(key)) return null
        return optString(key).trim().ifBlank { null }?.takeUnless { it == "null" }
    }
}
