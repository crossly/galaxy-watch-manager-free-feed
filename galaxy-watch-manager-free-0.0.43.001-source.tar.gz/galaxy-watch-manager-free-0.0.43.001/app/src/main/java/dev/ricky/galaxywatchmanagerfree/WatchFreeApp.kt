package dev.ricky.galaxywatchmanagerfree

import android.app.Application
import dev.ricky.galaxywatchmanagerfree.core.WatchController

class WatchFreeApp : Application() {
    override fun onCreate() {
        super.onCreate()
        dev.ricky.galaxywatchmanagerfree.feature.LogBus.init(this)
        dev.ricky.galaxywatchmanagerfree.core.UiNotify.init(this)
        dev.ricky.galaxywatchmanagerfree.ui.PageLayoutController.init(this)
        dev.ricky.galaxywatchmanagerfree.feature.NotificationFilterPreferences.init(this)
        WatchController.init(this)
        dev.ricky.galaxywatchmanagerfree.feature.NotificationListenerRecovery.requestRebindIfNeeded(
            this
        )
        dev.ricky.galaxywatchmanagerfree.core.OnboardingController.initialize(this)
        dev.ricky.galaxywatchmanagerfree.core.AppPolicyChecker.restore(this)
        // 进程启动即尝试从已配对列表里找回手表；首次连接引导或生效的强更/下架策略拦截期间不要抢跑。
        if (
            !dev.ricky.galaxywatchmanagerfree.core.OnboardingController.isVisible &&
                !dev.ricky.galaxywatchmanagerfree.core.AppPolicyChecker.isBlocked
        ) {
            WatchController.resumeAutoConnect(this)
        }
    }
}
