package dev.ricky.galaxywatchmanagerfree.core

import android.content.res.Resources
import androidx.annotation.StringRes

/** Keeps state independent of the language selected when the event occurred. */
data class UiText(@StringRes val resource: Int, val arguments: List<Any> = emptyList()) {
    fun resolve(resources: Resources): String =
        if (arguments.isEmpty()) resources.getString(resource)
        else
            resources.getString(
                resource,
                *arguments.map { resolveArgument(it, resources) }.toTypedArray(),
            )

    private fun resolveArgument(value: Any, resources: Resources): Any =
        when (value) {
            is UiText -> value.resolve(resources)
            is List<*> ->
                value.joinToString("; ") { item ->
                    if (item is UiText) item.resolve(resources) else item.toString()
                }
            else -> value
        }
}

fun uiText(@StringRes resource: Int, vararg arguments: Any): UiText =
    UiText(resource, arguments.toList())

/** A validation failure with a localizable explanation and no private payload in its message. */
class UserFacingException(val reason: UiText) :
    IllegalArgumentException("Resource ${reason.resource}")

fun requireUser(condition: Boolean, reason: UiText) {
    if (!condition) throw UserFacingException(reason)
}
