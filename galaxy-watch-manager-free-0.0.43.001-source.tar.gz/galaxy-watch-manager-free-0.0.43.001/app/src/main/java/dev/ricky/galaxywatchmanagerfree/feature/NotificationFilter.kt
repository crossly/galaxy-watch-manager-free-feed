package dev.ricky.galaxywatchmanagerfree.feature

import android.content.Context
import android.content.SharedPreferences
import androidx.annotation.VisibleForTesting
import java.time.LocalTime
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class NotificationFilterMode {
    ALL,
    SELECTED,
}

/**
 * Daily forwarding window in device-local time.
 *
 * [startMinute] is inclusive and [endMinute] is exclusive. A start later than the end wraps across
 * midnight. Equal start and end mean all day; a disabled schedule also allows all day.
 */
data class NotificationSchedule(
    val enabled: Boolean = false,
    val startMinute: Int = DEFAULT_START_MINUTE,
    val endMinute: Int = DEFAULT_END_MINUTE,
) {
    fun allows(time: LocalTime): Boolean {
        if (!enabled) return true
        val start = startMinute.coerceIn(0, MINUTES_PER_DAY - 1)
        val end = endMinute.coerceIn(0, MINUTES_PER_DAY - 1)
        if (start == end) return true
        val current = time.hour * 60 + time.minute
        return if (start < end) current >= start && current < end
        else current >= start || current < end
    }

    companion object {
        const val MINUTES_PER_DAY = 24 * 60
        const val DEFAULT_START_MINUTE = 8 * 60
        const val DEFAULT_END_MINUTE = 22 * 60

        fun restore(enabled: Boolean, startMinute: Int, endMinute: Int): NotificationSchedule =
            NotificationSchedule(
                enabled = enabled,
                startMinute = startMinute.coerceIn(0, MINUTES_PER_DAY - 1),
                endMinute = endMinute.coerceIn(0, MINUTES_PER_DAY - 1),
            )
    }
}

data class NotificationFilterConfig(
    val mode: NotificationFilterMode = NotificationFilterMode.ALL,
    val packages: Set<String> = emptySet(),
) {
    fun allows(packageName: String): Boolean =
        mode == NotificationFilterMode.ALL || packageName in packages

    companion object {
        fun restore(
            savedMode: String?,
            packages: Set<String>,
            legacyPackages: Set<String> = emptySet(),
        ): NotificationFilterConfig =
            if (savedMode == null) {
                NotificationFilterConfig(
                    if (legacyPackages.isEmpty()) NotificationFilterMode.ALL
                    else NotificationFilterMode.SELECTED,
                    legacyPackages.toSet(),
                )
            } else {
                NotificationFilterConfig(
                    NotificationFilterMode.entries.firstOrNull { it.name == savedMode }
                        ?: NotificationFilterMode.SELECTED,
                    packages.toSet(),
                )
            }
    }
}

object NotificationFilterPreferences {
    private const val PREFS = "watchfree_notification_filter"
    private var prefs: SharedPreferences? = null
    private val _config = MutableStateFlow(NotificationFilterConfig())
    val config = _config.asStateFlow()
    private val _observedPackages = MutableStateFlow<Set<String>>(emptySet())
    val observedPackages = _observedPackages.asStateFlow()
    private val _schedule = MutableStateFlow(NotificationSchedule())
    val schedule = _schedule.asStateFlow()
    private val _muteWhileUsingPhone = MutableStateFlow(true)
    val muteWhileUsingPhone = _muteWhileUsingPhone.asStateFlow()

    @Synchronized
    fun init(context: Context) {
        if (prefs != null) return
        val store = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val savedMode = store.getString("mode", null)
        val legacy =
            if (savedMode == null) {
                context
                    .getSharedPreferences("watchfree", Context.MODE_PRIVATE)
                    .getStringSet("allowed_packages", emptySet())
                    .orEmpty()
            } else emptySet()
        val restored =
            NotificationFilterConfig.restore(
                savedMode,
                store.getStringSet("packages", emptySet()).orEmpty(),
                legacy,
            )
        if (savedMode == null) {
            store
                .edit()
                .putString("mode", restored.mode.name)
                .putStringSet("packages", restored.packages)
                .apply()
        }
        _config.value = restored
        _observedPackages.value = store.getStringSet("observed", emptySet()).orEmpty().toSet()
        _schedule.value =
            NotificationSchedule.restore(
                store.getBoolean("schedule_enabled", false),
                store.getInt("schedule_start_minute", NotificationSchedule.DEFAULT_START_MINUTE),
                store.getInt("schedule_end_minute", NotificationSchedule.DEFAULT_END_MINUTE),
            )
        _muteWhileUsingPhone.value = store.getBoolean("mute_while_using_phone", true)
        prefs = store
    }

    @Synchronized
    fun setMode(mode: NotificationFilterMode) {
        save(_config.value.copy(mode = mode))
    }

    @Synchronized
    fun setSelected(packageName: String, selected: Boolean) {
        val current = _config.value
        save(
            current.copy(
                packages =
                    if (selected) current.packages + packageName else current.packages - packageName
            )
        )
    }

    private fun save(config: NotificationFilterConfig) {
        val store = checkNotNull(prefs)
        store
            .edit()
            .putString("mode", config.mode.name)
            .putStringSet("packages", config.packages)
            .apply()
        _config.value = config
    }

    @Synchronized
    fun setScheduleEnabled(enabled: Boolean) {
        saveSchedule(_schedule.value.copy(enabled = enabled))
    }

    @Synchronized
    fun setScheduleStart(startMinute: Int) {
        saveSchedule(
            _schedule.value.copy(
                startMinute = startMinute.coerceIn(0, NotificationSchedule.MINUTES_PER_DAY - 1)
            )
        )
    }

    @Synchronized
    fun setScheduleEnd(endMinute: Int) {
        saveSchedule(
            _schedule.value.copy(
                endMinute = endMinute.coerceIn(0, NotificationSchedule.MINUTES_PER_DAY - 1)
            )
        )
    }

    private fun saveSchedule(schedule: NotificationSchedule) {
        val store = checkNotNull(prefs)
        store
            .edit()
            .putBoolean("schedule_enabled", schedule.enabled)
            .putInt("schedule_start_minute", schedule.startMinute)
            .putInt("schedule_end_minute", schedule.endMinute)
            .apply()
        _schedule.value = schedule
    }

    @Synchronized
    fun setMuteWhileUsingPhone(enabled: Boolean) {
        prefs?.edit()?.putBoolean("mute_while_using_phone", enabled)?.apply()
        _muteWhileUsingPhone.value = enabled
    }

    @Synchronized
    fun noteObserved(packageName: String) {
        val current = _observedPackages.value
        if (packageName in current || current.size >= 512) return
        val next = current + packageName
        checkNotNull(prefs).edit().putStringSet("observed", next).apply()
        _observedPackages.value = next
    }

    @VisibleForTesting
    internal fun resetForTest(
        config: NotificationFilterConfig = NotificationFilterConfig(),
        muteWhileUsingPhone: Boolean = true,
        schedule: NotificationSchedule = NotificationSchedule(),
        observed: Set<String> = emptySet(),
    ) {
        prefs = null
        _config.value = config
        _muteWhileUsingPhone.value = muteWhileUsingPhone
        _schedule.value = schedule
        _observedPackages.value = observed
    }
}
