package dev.ricky.galaxywatchmanagerfree.feature

import java.time.ZoneId
import org.json.JSONArray
import org.json.JSONObject

/**
 * Retained health records, shared by Message/Channel/DataItem ingestion. Upsert whole revisions
 * before deriving statistics; never merge already-aggregated averages.
 */
class HealthRecordStore(private val onRestoreFailure: (String) -> Unit = {}) {
    private val modules = linkedMapOf<String, LinkedHashMap<String, JSONObject>>()
    private val deletedTombstones = linkedMapOf<String, Long>()

    companion object {
        const val SCHEMA_VERSION = 1
        const val MODULE_DELETED_DATA = "deleted_data"
        const val MODULE_ACTIVITY_DAY_SUMMARY = "com.samsung.shealth.activity.day_summary"
        const val MODULE_EXERCISE_ROUTE = "com.samsung.shealth.exercise.route"
        private const val TOMBSTONE_RETENTION_DAYS = 60
        private const val TOMBSTONE_LIMIT = 8_000

        fun retentionDays(module: String): Int? =
            if (
                module in
                    setOf(
                        ExerciseLog.MODULE,
                        ExerciseLog.MODULE_ALIAS,
                        ExerciseLog.MODULE_ROUTINE,
                        ExerciseLog.MODULE_CUSTOM,
                        MODULE_EXERCISE_ROUTE,
                        VascularLoadLog.MODULE,
                    )
            )
                null
            else 30

        fun recordLimit(module: String): Int = if (module == HeartRateLog.MODULE) 20_000 else 8_000

        private val supported =
            setOf(
                HealthStepParser.MODULE_STEP_COUNT,
                HealthStepParser.MODULE_DAY_SUMMARY,
                MODULE_ACTIVITY_DAY_SUMMARY,
                "com.samsung.shealth.tracker.heart_rate",
                "com.samsung.shealth.stress",
                "com.samsung.shealth.stress.histogram",
                "com.samsung.shealth.alerted_stress",
                VascularLoadLog.MODULE,
                SleepParser.MODULE_SLEEP,
                SleepParser.MODULE_SLEEP_LEGACY,
                SleepParser.MODULE_SLEEP_DATA,
                SleepParser.MODULE_SLEEP_STAGE,
                SleepParser.MODULE_SLEEP_STAGE_LEGACY,
                SleepParser.MODULE_SLEEP_RAW,
                SleepParser.MODULE_SLEEP_COMBINED,
                "com.samsung.shealth.floors_climbed",
                "com.samsung.health.floors_climbed",
                "com.samsung.shealth.exercise",
                "com.samsung.health.exercise",
                ExerciseLog.MODULE_ROUTINE,
                ExerciseLog.MODULE_CUSTOM,
                MODULE_EXERCISE_ROUTE,
                "com.samsung.shealth.exercise.hr_zone",
                "com.samsung.shealth.exercise.recovery_heart_rate",
                "com.samsung.shealth.exercise.max_heart_rate",
                "com.samsung.shealth.exercise.weather",
                "com.samsung.shealth.exercise.periodization_training_result",
                "com.samsung.health.movement",
                "com.samsung.health.oxygen_saturation.raw",
                "com.samsung.health.antioxidant",
                "com.samsung.health.advanced_glycation_endproduct.raw",
                "com.samsung.shealth.preferences",
                "com.samsung.shealth.service_preferences",
                "com.samsung.shealth.tracker.pedometer_recommendation",
            ) + HealthMetric.entries.flatMap { it.moduleKeys }

        private fun canonicalDeleteGroup(module: String): String {
            if (module == ExerciseLog.MODULE || module == ExerciseLog.MODULE_ALIAS) {
                return ExerciseLog.MODULE
            }
            if (module == SleepParser.MODULE_SLEEP || module == SleepParser.MODULE_SLEEP_LEGACY) {
                return SleepParser.MODULE_SLEEP
            }
            if (
                module == SleepParser.MODULE_SLEEP_STAGE ||
                    module == SleepParser.MODULE_SLEEP_STAGE_LEGACY
            ) {
                return SleepParser.MODULE_SLEEP_STAGE
            }
            if (
                module == "com.samsung.shealth.floors_climbed" ||
                    module == "com.samsung.health.floors_climbed"
            ) {
                return "com.samsung.shealth.floors_climbed"
            }
            HealthMetric.entries
                .firstOrNull { module in it.moduleKeys }
                ?.let {
                    return it.moduleKeys.first()
                }
            return module
        }

        private fun tombstoneKey(module: String, uuid: String): String =
            "${canonicalDeleteGroup(module)}|$uuid"

        private fun deleteTimestamp(record: JSONObject): Long =
            listOf("delete_time", "update_time", "create_time").firstNotNullOfOrNull { key ->
                if (!record.has(key) || record.isNull(key)) null
                else record.optDouble(key, Double.NaN).takeIf { it.isFinite() }?.toLong()
            } ?: 0L

        private val identityFields =
            listOf(
                "datauuid",
                "deviceuuid",
                "start_time",
                "end_time",
                "day_time",
                "create_time",
                "update_time",
            )

        /**
         * All modules use the same normalized metadata before identity/revision/retention checks.
         */
        private fun normalized(record: JSONObject): JSONObject =
            JSONObject(record.toString()).apply {
                identityFields.forEach { name ->
                    if (has(name) && !isNull(name) && optString(name).isNotBlank()) return@forEach
                    val alias =
                        record
                            .keys()
                            .asSequence()
                            .filter { it.endsWith(".$name") }
                            .sorted()
                            .firstOrNull { !record.isNull(it) && record.optString(it).isNotBlank() }
                    if (alias != null) put(name, record.get(alias))
                }
            }

        fun identity(record: JSONObject): String {
            if (record.has("datauuid") && !record.isNull("datauuid")) {
                val direct = record.optString("datauuid")
                if (direct.isNotBlank()) return direct
            }
            return normalizedIdentity(normalized(record))
        }

        /** Callers that already normalized the row must not pay for another JSON round trip. */
        private fun normalizedIdentity(value: JSONObject): String {
            value
                .optString("datauuid")
                .takeIf { it.isNotBlank() }
                ?.let {
                    return it
                }
            if (!value.has("start_time") && value.optString("custom_id").isNotBlank())
                return "custom:${value.optString("custom_id")}"
            val parts =
                listOf("key", "deviceuuid", "start_time", "end_time", "day_time").map {
                    value.optString(it)
                }
            if (parts[0].isNotBlank() || parts.drop(2).any { it.isNotBlank() })
                return parts.joinToString("|")
            // Unidentified rows must not all overwrite one another under an empty key.
            return value.keys().asSequence().sorted().joinToString("|") { "$it=${value.opt(it)}" }
        }

        private fun revision(record: JSONObject): Long =
            listOf("update_time", "create_time").firstNotNullOfOrNull { key ->
                if (!record.has(key) || record.isNull(key)) null
                else record.optDouble(key, Double.NaN).takeIf { it.isFinite() }?.toLong()
            } ?: 0L

        /** Select whole revisions before expanding bins to discard stale alias bins. */
        fun newestRevisions(rows: List<Pair<String, JSONObject>>): List<Pair<String, JSONObject>> =
            rows
                .groupBy { identity(it.second) }
                .values
                .mapNotNull { revisions -> revisions.maxByOrNull { revision(it.second) } }

        private fun time(record: JSONObject): Long =
            listOf("end_time", "start_time", "day_time", "create_time", "update_time")
                .firstNotNullOfOrNull {
                    // `day_time` is often yyyyMMdd (e.g. 20261029), not epoch millis; a value
                    // below 2000-01-01 is not a usable retention timestamp.
                    record.optLong(it).takeIf { ts -> ts >= 946_684_800_000L }
                } ?: 0L
    }

    fun merge(chunks: Map<String, List<JSONObject>>, now: Long) {
        chunks[MODULE_DELETED_DATA].orEmpty().forEach { rawDeletion ->
            val deletion = normalized(rawDeletion)
            val uuid =
                deletion.optString("datauuid").ifBlank { deletion.optString("data_uuid") }.trim()
            if (uuid.isBlank()) return@forEach
            val dataType = deletion.optString("data_type").trim()
            val deleteTime = deleteTimestamp(deletion)
            if (dataType.isNotBlank()) {
                val group = canonicalDeleteGroup(dataType)
                val key = "$group|$uuid"
                val prev = deletedTombstones[key]
                if (prev == null || deleteTime >= prev) deletedTombstones[key] = deleteTime
                modules.forEach { (module, rows) ->
                    if (canonicalDeleteGroup(module) != group) return@forEach
                    val existing = rows[uuid] ?: return@forEach
                    if (revision(existing) <= deleteTime) rows.remove(uuid)
                }
            } else {
                modules.forEach { (module, rows) ->
                    val existing = rows[uuid] ?: return@forEach
                    if (revision(existing) <= deleteTime) {
                        rows.remove(uuid)
                        val key = tombstoneKey(module, uuid)
                        val prev = deletedTombstones[key]
                        if (prev == null || deleteTime >= prev) deletedTombstones[key] = deleteTime
                    }
                }
            }
        }
        chunks.forEach { (module, incoming) ->
            if (module == MODULE_DELETED_DATA || module !in supported) return@forEach
            val rows = modules.getOrPut(module) { linkedMapOf() }
            incoming.forEach { incomingRecord ->
                val record = normalized(incomingRecord)
                val id = normalizedIdentity(record)
                val key = tombstoneKey(module, id)
                val tombstone = deletedTombstones[key]
                val incomingRev = revision(record)
                if (tombstone != null) {
                    if (incomingRev <= tombstone) return@forEach
                    deletedTombstones.remove(key)
                }
                val old = rows[id]
                if (old == null || incomingRev >= revision(old)) rows[id] = record
            }
        }
        modules.forEach { (module, rows) ->
            retentionDays(module)?.let { days ->
                val cutoff = now - days * 24L * 3_600_000
                rows.entries.removeAll { time(it.value) in 1 until cutoff }
            }
            val cap = recordLimit(module)
            if (rows.size > cap)
                rows.entries
                    .sortedByDescending { time(it.value) }
                    .drop(cap)
                    .forEach { rows.remove(it.key) }
        }
        pruneTombstones(now)
    }

    private fun pruneTombstones(now: Long) {
        val cutoff = now - TOMBSTONE_RETENTION_DAYS * 24L * 3_600_000L
        deletedTombstones.entries.removeAll { it.value in 1 until cutoff }
        if (deletedTombstones.size > TOMBSTONE_LIMIT) {
            deletedTombstones.entries
                .sortedByDescending { it.value }
                .drop(TOMBSTONE_LIMIT)
                .forEach { deletedTombstones.remove(it.key) }
        }
    }

    fun deletedTombstoneCount(): Int = deletedTombstones.size

    fun deletedTombstones(): Map<String, Long> = deletedTombstones.toMap()

    fun hasModule(key: String): Boolean = modules.containsKey(key)

    fun records(vararg keys: String): List<JSONObject> =
        keys.flatMap { modules[it]?.values.orEmpty() }

    /**
     * Alias-aware read: keep only the newest whole revision per identity across the given modules.
     */
    fun recordsNewest(vararg keys: String): List<JSONObject> =
        newestRevisions(
                keys.flatMap { module -> modules[module]?.values.orEmpty().map { module to it } }
            )
            .map { it.second }

    fun recordsFor(metric: HealthMetric): List<JSONObject> =
        newestRevisions(
                metric.moduleKeys.flatMap { module ->
                    modules[module]?.values.orEmpty().map { module to it }
                }
            )
            .map { it.second }

    fun todaySteps(now: Long, zone: ZoneId = ZoneId.systemDefault()): List<JSONObject> =
        records(HealthStepParser.MODULE_STEP_COUNT).filter {
            HealthStepParser.isSameLocalDay(HealthStepParser.recordStartTime(it), now, zone)
        }

    fun replaceTodaySteps(
        records: List<JSONObject>,
        now: Long,
        zone: ZoneId = ZoneId.systemDefault(),
    ) {
        val rows = modules.getOrPut(HealthStepParser.MODULE_STEP_COUNT) { linkedMapOf() }
        rows.entries.removeAll {
            HealthStepParser.isSameLocalDay(HealthStepParser.recordStartTime(it.value), now, zone)
        }
        records.forEach { record ->
            val value = normalized(record)
            rows[normalizedIdentity(value)] = value
        }
    }

    fun encode(): String =
        JSONObject()
            .apply {
                put("version", SCHEMA_VERSION)
                put(
                    "modules",
                    JSONObject().apply {
                        modules.forEach { (module, rows) ->
                            put(module, JSONArray(rows.values.toList()))
                        }
                    },
                )
                if (deletedTombstones.isNotEmpty()) {
                    put(
                        "deleted_tombstones",
                        JSONObject().apply {
                            deletedTombstones.forEach { (key, deletedAt) -> put(key, deletedAt) }
                        },
                    )
                }
            }
            .toString()

    fun restore(raw: String?, now: Long): Boolean {
        if (raw.isNullOrBlank()) return true
        return try {
            val root = JSONObject(raw)
            require(root.optInt("version") == SCHEMA_VERSION) { "Unsupported health cache schema" }
            val data = root.getJSONObject("modules")
            val chunks =
                data.keys().asSequence().associateWith { module ->
                    val array = data.getJSONArray(module)
                    (0 until array.length()).mapNotNull(array::optJSONObject)
                }
            val restored = HealthRecordStore()
            root.optJSONObject("deleted_tombstones")?.let { tombstones ->
                tombstones.keys().forEach { key ->
                    val ts = tombstones.optLong(key, -1L)
                    if (ts >= 0L) restored.deletedTombstones[key] = ts
                }
            }
            restored.merge(chunks, now)
            modules.clear()
            modules.putAll(restored.modules)
            deletedTombstones.clear()
            deletedTombstones.putAll(restored.deletedTombstones)
            true
        } catch (error: Exception) {
            onRestoreFailure("健康缓存无法恢复：${error.javaClass.simpleName}")
            false
        }
    }
}
