package dev.ricky.galaxywatchmanagerfree.feature

import dev.ricky.galaxywatchmanagerfree.wcs.WcsPaths
import java.io.ByteArrayOutputStream
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import java.util.Base64
import java.util.concurrent.atomic.AtomicInteger
import java.util.zip.GZIPOutputStream
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

/**
 * Pure policy deciding whether today's phone-computed Energy Score should be automatically written
 * back to the watch at most once per local calendar day.
 */
object EnergyScoreAutoWritePolicy {
    const val DEFAULT_RETRY_COOLDOWN_MS = 5 * 60_000L

    sealed interface Decision {
        data class Push(val record: EnergyScoreLog.Record) : Decision

        data object SkipDisconnected : Decision

        data object SkipInFlight : Decision

        data object SkipNoTodayScore : Decision

        data object SkipAlreadyPushedToday : Decision

        data class SkipAlreadyAcknowledged(val date: LocalDate) : Decision

        data object SkipCooldown : Decision
    }

    fun decide(
        records: List<EnergyScoreLog.Record>,
        today: LocalDate,
        lastPushedDay: String?,
        sessionReady: Boolean,
        syncInFlight: Boolean,
        lastAttemptAt: Long,
        now: Long,
        retryCooldownMs: Long = DEFAULT_RETRY_COOLDOWN_MS,
    ): Decision {
        if (!sessionReady) return Decision.SkipDisconnected
        if (syncInFlight) return Decision.SkipInFlight
        val todayKey = today.toString()
        if (lastPushedDay == todayKey) return Decision.SkipAlreadyPushedToday
        val todayRecord =
            records.firstOrNull { it.date == todayKey && it.deviceUuid.isNotBlank() }
                ?: return Decision.SkipNoTodayScore
        if (todayRecord.acknowledged) return Decision.SkipAlreadyAcknowledged(today)
        if (lastAttemptAt > 0L && now - lastAttemptAt in 0L until retryCooldownMs) {
            return Decision.SkipCooldown
        }
        return Decision.Push(todayRecord)
    }

    /** Returns true when a pushed vitality batch contains the UTC-midnight row for [date]. */
    fun containsDate(rows: List<JSONObject>, date: LocalDate): Boolean {
        val targetDayTime = date.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
        return rows.any { row -> row.optLong("day_time", Long.MIN_VALUE) == targetDayTime }
    }
}

class EnergyScoreSync(
    private val scope: CoroutineScope,
    private val watchNode: () -> String,
    private val deviceModel: () -> String,
    private val send: (JSONObject) -> Boolean,
    private val onStatus: (Status) -> Unit,
    private val onAccepted: (List<JSONObject>, Long) -> Boolean,
    private val clock: () -> Long = System::currentTimeMillis,
    private val timeoutMillis: Long = 30_000L,
    private val onLog: (String) -> Unit = {},
    private val onError: (String) -> Unit = {},
) {
    enum class Status {
        IDLE,
        WAITING_ACK,
        ACCEPTED,
        SEND_FAILED,
        SAVE_FAILED,
        REJECTED,
        TIMED_OUT,
        DISCONNECTED,
    }

    private data class Pending(val sequence: Int, val rows: List<JSONObject>, var job: Job? = null)

    private val sequence = AtomicInteger(kotlin.random.Random.nextInt(100_000_000, 200_000_000))
    private var pending: Pending? = null

    val isPending: Boolean
        @Synchronized get() = pending != null

    @Synchronized
    fun push(rows: List<JSONObject>, automatic: Boolean = false): Boolean {
        if (rows.isEmpty()) return false
        pending?.job?.cancel()
        val request = Pending(sequence.getAndIncrement(), rows.map { JSONObject(it.toString()) })
        val dates = summarizeDates(request.rows)
        pending = request
        onStatus(Status.WAITING_ACK)
        val actionLabel = if (automatic) "自动写回手表" else "写回手表"
        onLog("[能量→] $actionLabel seq=${request.sequence} rows=${request.rows.size} dates=$dates")
        val sent = send(packet(request))
        if (!sent) {
            if (pending === request) {
                pending = null
                onStatus(Status.SEND_FAILED)
                onError("[能量] ${actionLabel}发送失败 seq=${request.sequence}")
            }
            return false
        }
        if (pending === request) {
            request.job =
                scope.launch {
                    delay(timeoutMillis)
                    synchronized(this@EnergyScoreSync) {
                        if (pending === request) {
                            pending = null
                            onStatus(Status.TIMED_OUT)
                            onError("[能量] ${actionLabel}等待应答超时 seq=${request.sequence}")
                        }
                    }
                }
        }
        return true
    }

    @Synchronized
    fun handleMessage(json: JSONObject): Boolean {
        val request = pending ?: return false
        if (
            json.optString("message") != WcsPaths.HEALTH_MSG_RESPONSE ||
                json.optString("type") != WcsPaths.HEALTH_TYPE_DATA ||
                json.optString("sender") != WcsPaths.HEALTH_WATCH_SYNC ||
                json.optString("receiver") != WcsPaths.HEALTH_PHONE_SYNC ||
                json.optInt("sequence_num") != request.sequence
        )
            return false
        val info =
            runCatching {
                    val entries = HealthJson.entries(json.optString("body"))
                    (0 until entries.length()).firstNotNullOfOrNull {
                        entries.optJSONObject(it)?.optJSONArray("message_info")?.optJSONObject(0)
                    }
                }
                .getOrNull() ?: return true
        if (info.optString("action") != WcsPaths.HEALTH_ACTION_SYNC_DATA) return true
        val result = info.optString("result")
        if (result.isBlank()) return true
        pending = null
        request.job?.cancel()
        val dates = summarizeDates(request.rows)
        if (result.equals("SUCCESS", ignoreCase = true)) {
            if (onAccepted(request.rows, clock())) {
                onStatus(Status.ACCEPTED)
                onLog("[能量←] 手表已应答 seq=${request.sequence} rows=${request.rows.size} dates=$dates")
            } else {
                onStatus(Status.SAVE_FAILED)
                onError("[能量] 手表已应答但本机保存确认状态失败 seq=${request.sequence}")
            }
        } else {
            onStatus(Status.REJECTED)
            onError("[能量] 手表拒绝写回 seq=${request.sequence} result=$result")
        }
        return true
    }

    @Synchronized
    fun disconnect() {
        val previous = pending
        previous?.job?.cancel()
        pending = null
        onStatus(Status.DISCONNECTED)
        if (previous != null) onError("[能量] 写回手表因断线中止 seq=${previous.sequence}")
    }

    private fun summarizeDates(rows: List<JSONObject>): String =
        rows
            .mapNotNull { row ->
                row.optLong("day_time", Long.MIN_VALUE)
                    .takeIf { it != Long.MIN_VALUE }
                    ?.let {
                        Instant.ofEpochMilli(it).atOffset(ZoneOffset.UTC).toLocalDate().toString()
                    }
            }
            .distinct()
            .sorted()
            .joinToString(",")
            .ifEmpty { "unknown" }

    private fun packet(request: Pending): JSONObject {
        val body =
            JSONArray()
                .put(
                    JSONObject()
                        .put(
                            "device_info",
                            JSONArray()
                                .put(
                                    JSONObject()
                                        .put("device", deviceModel())
                                        .put("device_type", 0)
                                        .put("version", 4.51)
                                        .put("last_sync_time", clock())
                                        .put("is_last_chunk", true)
                                ),
                        )
                )
                .put(
                    JSONObject()
                        .put(
                            "message_info",
                            JSONArray()
                                .put(JSONObject().put("action", WcsPaths.HEALTH_ACTION_SYNC_DATA)),
                        )
                )
                .put(JSONObject().put(MODULE, JSONArray(request.rows)))
        val output = ByteArrayOutputStream()
        GZIPOutputStream(output).use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        return JSONObject()
            .put("message", WcsPaths.HEALTH_MSG_REQUEST)
            .put("type", WcsPaths.HEALTH_TYPE_DATA)
            .put("sender", WcsPaths.HEALTH_PHONE_SYNC)
            .put("receiver", WcsPaths.HEALTH_WATCH_SYNC)
            .put("version", 5.03)
            .put("sequence_num", request.sequence)
            .put("source_node", WcsPaths.PKG_SHEALTH)
            .put("destination_node", watchNode())
            .put("body", Base64.getEncoder().encodeToString(output.toByteArray()))
    }

    companion object {
        const val MODULE = "com.samsung.shealth.vitality_score"
    }
}
