package dev.ricky.galaxywatchmanagerfree.feature

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.drawable.VectorDrawable
import android.service.notification.StatusBarNotification
import androidx.core.graphics.drawable.toBitmap
import androidx.vectordrawable.graphics.drawable.VectorDrawableCompat
import java.text.Collator

data class NotificationApp(val packageName: String, val label: String)

object NotificationAppCatalog {
    @Suppress("DEPRECATION")
    fun load(context: Context, extraPackages: Set<String>): List<NotificationApp> {
        val pm = context.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val packages =
            pm.queryIntentActivities(launcher, 0).map { it.activityInfo.packageName }.toSet() +
                extraPackages
        val collator = Collator.getInstance(context.resources.configuration.locales[0])
        return packages
            .filter { it != context.packageName }
            .map { packageName -> NotificationApp(packageName, appName(context, packageName)) }
            .sortedWith(compareBy(collator) { it.label })
    }

    fun appName(context: Context, packageName: String): String =
        try {
            val pm = context.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(packageName, 0)).toString()
        } catch (_: PackageManager.NameNotFoundException) {
            packageName
        }

    const val MAX_APP_ICON_SIZE = 56
    const val MAX_SMALL_ICON_SIZE = 40

    @androidx.annotation.WorkerThread
    fun forwardingIcon(context: Context, packageName: String): ByteArray? =
        try {
            val drawable =
                try {
                    context.packageManager.getApplicationIcon(packageName)
                } catch (_: PackageManager.NameNotFoundException) {
                    null
                }
            val bitmap = drawable?.let { scaleDrawable(it, MAX_APP_ICON_SIZE) }
            if (bitmap == null) {
                LogBus.debug { "[通知图标] 无法读取应用图标 package=$packageName" }
                null
            } else {
                val bytes = compressIcon(bitmap)
                if (bytes == null) {
                    LogBus.debug { "[通知图标] PNG 编码失败 package=$packageName" }
                }
                bytes
            }
        } catch (e: RuntimeException) {
            LogBus.debug { "[通知图标] 编码失败 package=$packageName type=${e.javaClass.simpleName}" }
            null
        }

    fun icon(context: Context, packageName: String): Bitmap? =
        try {
            context.packageManager.getApplicationIcon(packageName).toBitmap(96, 96)
        } catch (_: PackageManager.NameNotFoundException) {
            null
        }

    @androidx.annotation.WorkerThread
    fun forwardingSmallIcon(context: Context, sbn: StatusBarNotification): ByteArray? =
        try {
            val smallIcon = sbn.notification?.smallIcon ?: return null
            val drawable = smallIcon.loadDrawable(context) ?: return null
            val bitmap = scaleDrawable(drawable, MAX_SMALL_ICON_SIZE)
            if (bitmap == null) {
                LogBus.debug { "[通知图标] smallIcon 转位图失败 package=${sbn.packageName}" }
                null
            } else {
                val bytes = compressIcon(bitmap)
                if (bytes == null) {
                    LogBus.debug { "[通知图标] smallIcon PNG 编码失败 package=${sbn.packageName}" }
                }
                bytes
            }
        } catch (e: Throwable) {
            LogBus.debug {
                "[通知图标] 提取 smallIcon 失败 package=${sbn.packageName} err=${e.javaClass.simpleName}"
            }
            null
        }

    fun scaleDrawable(drawable: android.graphics.drawable.Drawable, maxEdge: Int): Bitmap? {
        val iw = drawable.intrinsicWidth.takeIf { it > 0 } ?: maxEdge
        val ih = drawable.intrinsicHeight.takeIf { it > 0 } ?: maxEdge
        val (w, h) =
            if (iw > maxEdge || ih > maxEdge) {
                val scale = maxEdge.toFloat()
                if (iw > ih) {
                    maxEdge to ((ih * (scale / iw)).toInt().coerceAtLeast(1))
                } else {
                    ((iw * (scale / ih)).toInt().coerceAtLeast(1)) to maxEdge
                }
            } else {
                iw to ih
            }
        if (w <= 0 || h <= 0) return null
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(bitmap)
        drawable.setBounds(0, 0, w, h)
        return try {
            drawable.draw(canvas)
            bitmap
        } catch (_: Throwable) {
            null
        }
    }

    /** 诊断用：生成纯色圆角方块图标，用于判定手表端是否真的渲染了下发的 Asset。 与真实图标完全相同的编码/尺寸路径（56/40 上限）。 */
    fun solidIcon(color: Int, maxEdge: Int): ByteArray? {
        val bitmap = Bitmap.createBitmap(maxEdge, maxEdge, Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(bitmap)
        val paint =
            android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                this.color = color
            }
        val radius = maxEdge / 4f
        canvas.drawRoundRect(0f, 0f, maxEdge.toFloat(), maxEdge.toFloat(), radius, radius, paint)
        return compressIcon(bitmap)
    }

    /**
     * 图标压缩：官方 Wear 手机端 `dxf.bb` 对图标一律使用 PNG（质量 100）， 只有 Samsung 手机插件的内部图片处理才用 WebP。资产解码端按 PNG 最稳妥。
     */
    fun compressIcon(bitmap: Bitmap): ByteArray? {
        val output = java.io.ByteArrayOutputStream()
        return if (bitmap.compress(Bitmap.CompressFormat.PNG, 100, output)) {
            output.toByteArray()
        } else {
            null
        }
    }

    fun isSmallIconVector(context: Context, sbn: StatusBarNotification): Boolean =
        try {
            val smallIcon = sbn.notification?.smallIcon ?: return false
            val drawable = smallIcon.loadDrawable(context) ?: return false
            drawable is VectorDrawable ||
                drawable is VectorDrawableCompat ||
                drawable.javaClass.name.contains("VectorDrawable")
        } catch (_: Throwable) {
            false
        }
}
