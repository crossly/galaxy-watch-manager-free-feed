package dev.ricky.galaxywatchmanagerfree.feature

import java.security.MessageDigest
import org.json.JSONObject

object ExerciseRoute {
    data class Point(
        val sourceIndex: Int,
        val latitude: Double,
        val longitude: Double,
        val startTime: Long?,
        val elapsedTime: Long?,
        val altitude: Double?,
        val accuracy: Double?,
        val segment: Int?,
        val version: Int?,
        val interval: Int?,
        val sourceType: Int?,
    )

    data class Route(
        val payloadPresent: Boolean,
        val sourceField: String?,
        val sourcePointCount: Int,
        val points: List<Point>,
        val decoded: Boolean = false,
    ) {
        val segments: List<List<Point>> by lazy {
            val result = mutableListOf<MutableList<Point>>()
            points.forEach { point ->
                val previous = result.lastOrNull()?.lastOrNull()
                val gap =
                    previous == null ||
                        point.sourceIndex != previous.sourceIndex + 1 ||
                        point.segment != previous.segment ||
                        (point.startTime != null &&
                            previous.startTime != null &&
                            point.startTime < previous.startTime) ||
                        (point.elapsedTime != null &&
                            previous.elapsedTime != null &&
                            point.elapsedTime < previous.elapsedTime)
                if (gap) result.add(mutableListOf())
                result.last().add(point)
            }
            result
        }
    }

    private fun value(record: JSONObject, field: String): Pair<String, Any>? =
        sequenceOf(field, "com.samsung.health.exercise.$field")
            .mapNotNull { key ->
                record.opt(key)?.takeUnless { it == JSONObject.NULL }?.let { key to it }
            }
            .firstOrNull { (_, value) -> value.toString().isNotBlank() && value.toString() != "[]" }

    fun parse(record: JSONObject): Route {
        val carriers =
            listOf("location_data", "location_data_internal", "location").mapNotNull {
                value(record, it)
            }
        var decoded: Route? = null
        carriers.forEach { (field, value) ->
            val array = HealthJson.array(value) ?: return@forEach
            val points =
                (0 until array.length()).mapNotNull { index ->
                    val row = array.optJSONObject(index) ?: return@mapNotNull null
                    fun number(key: String): Double? =
                        if (row.isNull(key)) null
                        else row.optDouble(key, Double.NaN).takeIf { it.isFinite() }
                    fun long(key: String): Long? =
                        number(key)?.takeIf { it >= 0 && it < Long.MAX_VALUE.toDouble() }?.toLong()
                    fun int(key: String): Int? =
                        number(key)?.takeIf { it >= 0 && it <= Int.MAX_VALUE }?.toInt()
                    val latitude = number("latitude") ?: return@mapNotNull null
                    val longitude = number("longitude") ?: return@mapNotNull null
                    if (
                        latitude !in -90.0..90.0 ||
                            longitude !in -180.0..180.0 ||
                            (latitude == 0.0 && longitude == 0.0)
                    )
                        return@mapNotNull null
                    Point(
                        index,
                        latitude,
                        longitude,
                        long("start_time")?.takeIf { it > 0 },
                        long("elapsed_time"),
                        number("altitude"),
                        number("accuracy")?.takeIf { it >= 0 },
                        int("segment"),
                        int("version"),
                        int("interval"),
                        int("source_type"),
                    )
                }
            val route = Route(true, field, array.length(), points, decoded = true)
            if (points.isNotEmpty()) return route
            if (decoded == null) decoded = route
        }
        return decoded
            ?: Route(carriers.isNotEmpty(), carriers.firstOrNull()?.first, 0, emptyList())
    }

    // Each repository owns a cache, so device changes cannot reuse another device's track.
    class Cache {
        private val routes = linkedMapOf<String, Route>()

        @Synchronized
        fun parse(record: JSONObject): Route {
            val bytes = record.toString().toByteArray(Charsets.UTF_8)
            val key =
                MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") {
                    "%02x".format(it)
                }
            routes.remove(key)?.let {
                routes[key] = it
                return it
            }
            val route = ExerciseRoute.parse(record)
            if (route.points.size <= 50_000) {
                routes[key] = route
                while (routes.size > 4 || routes.values.sumOf { it.points.size } > 50_000) routes
                    .remove(routes.keys.first())
            }
            return route
        }
    }
}
