package dev.ricky.galaxywatchmanagerfree.ui.components

import android.app.Activity
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import dev.ricky.galaxywatchmanagerfree.BuildConfig
import dev.ricky.galaxywatchmanagerfree.R
import dev.ricky.galaxywatchmanagerfree.core.ApkUpdater
import dev.ricky.galaxywatchmanagerfree.core.AppPolicyChecker
import dev.ricky.galaxywatchmanagerfree.core.DownloadMirror
import dev.ricky.galaxywatchmanagerfree.core.UpdateChecker
import dev.ricky.galaxywatchmanagerfree.ui.theme.AlertCrimson
import dev.ricky.galaxywatchmanagerfree.ui.theme.ElectricBlue
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextPrimary
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextSecondary
import dev.ricky.galaxywatchmanagerfree.ui.theme.TextTertiary

/**
 * Full-screen gate shown only when a verified remote policy explicitly requires updating
 * (`force_update`) or stops service for this version/app (`block`).
 *
 * In `force_update` mode, this reuses the exact same in-app update module as Settings
 * ([UpdateChecker], [ApkUpdater], [ApkDownloadProgressBlock], and [UpdateMirrorSelectorRow]): it
 * auto-downloads and verifies the eligible APK in-app without sending users to a browser unless
 * in-app download fails or no eligible APK is published in the feed yet.
 */
@Composable
fun AppPolicyGateScreen(gate: AppPolicyChecker.Gate, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val locale = LocalConfiguration.current.locales[0]
    val isChinese = locale.language.equals("zh", ignoreCase = true)

    val checking by AppPolicyChecker.checking.collectAsState()
    val update by ApkUpdater.state.collectAsState()

    val savedMirror = UpdateChecker.mirror(context)
    var activeMirror by
        remember(gate.suggestedMirror) {
            mutableStateOf(
                if (savedMirror != DownloadMirror.OFF) savedMirror else gate.suggestedMirror
            )
        }

    // Never allow back-navigation into blocked app content; move smoothly to launcher instead.
    BackHandler { (context as? Activity)?.moveTaskToBack(true) }

    val policy = gate.policy
    val release = gate.release
    val isForceUpdate = gate.isForceUpdate
    val downloadRelease =
        if (isForceUpdate) release?.takeIf { !it.apkUrl.isNullOrBlank() } else null
    val downloading = update.busy

    // Mirror Settings' UpdateChecker behavior: auto-download & verify an eligible APK in-app once
    // discovered so the user can install directly in one tap without leaving the app.
    LaunchedEffect(downloadRelease?.versionCode, downloadRelease?.apkUrl) {
        val target = downloadRelease ?: return@LaunchedEffect
        UpdateChecker.adoptDiscoveredRelease(context, target)
        if (ApkUpdater.state.value.phase == ApkUpdater.Phase.IDLE) {
            ApkUpdater.download(
                context = context,
                info = target,
                autoInstall = false,
                mirrorOverride = activeMirror,
            )
        }
    }

    val accent = if (isForceUpdate) ElectricBlue else AlertCrimson
    val title =
        policy.localizedTitle(isChinese)
            ?: stringResource(
                if (isForceUpdate) R.string.policy_force_update_title
                else R.string.policy_block_title
            )
    val body =
        policy.localizedMessage(isChinese)
            ?: stringResource(
                if (isForceUpdate) R.string.policy_force_update_message
                else R.string.policy_block_message
            )
    val targetVersion =
        release?.versionName?.takeIf { it.isNotBlank() }
            ?: policy.targetVersionName?.takeIf { it.isNotBlank() }
    val versionLine =
        if (isForceUpdate && targetVersion != null) {
            stringResource(R.string.policy_version_pair, BuildConfig.VERSION_NAME, targetVersion)
        } else {
            stringResource(R.string.policy_version_current, BuildConfig.VERSION_NAME)
        }

    fun openExternalUrl(url: String) {
        runCatching {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    Surface(
        modifier = modifier.fillMaxSize().testTag("policy_gate_screen"),
        color = MaterialTheme.colorScheme.background,
    ) {
        Box(
            modifier =
                Modifier.fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 24.dp, vertical = 32.dp),
            contentAlignment = Alignment.Center,
        ) {
            Column(
                modifier = Modifier.widthIn(max = 460.dp).fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                Box(
                    modifier =
                        Modifier.size(72.dp)
                            .clip(CircleShape)
                            .background(accent.copy(alpha = 0.14f)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector =
                            if (isForceUpdate) Icons.Default.SystemUpdate else Icons.Default.Block,
                        contentDescription = null,
                        tint = accent,
                        modifier = Modifier.size(34.dp),
                    )
                }

                Text(
                    text = title,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.testTag("policy_gate_title"),
                )

                Text(
                    text = versionLine,
                    style = MaterialTheme.typography.labelLarge,
                    color = TextSecondary,
                    textAlign = TextAlign.Center,
                )

                GroupedCard(innerPadding = 18.dp) {
                    Text(
                        text = body,
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextPrimary,
                    )
                    val notes = release?.notes?.takeIf { isForceUpdate && it.isNotBlank() }
                    if (notes != null) {
                        Spacer(Modifier.height(12.dp))
                        GroupedDivider()
                        Spacer(Modifier.height(12.dp))
                        Text(
                            text = notes,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            maxLines = 8,
                            overflow = TextOverflow.Ellipsis,
                        )
                    } else if (isForceUpdate && downloadRelease == null) {
                        Spacer(Modifier.height(12.dp))
                        GroupedDivider()
                        Spacer(Modifier.height(12.dp))
                        Text(
                            text = stringResource(R.string.policy_feed_unavailable_note),
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                        )
                    }
                }

                if (isForceUpdate) {
                    if (downloadRelease != null) {
                        Button(
                            onClick = {
                                triggerApkUpdateAction(
                                    context = context,
                                    info = downloadRelease,
                                    phase = update.phase,
                                    autoInstall = true,
                                    mirrorOverride = activeMirror,
                                )
                            },
                            enabled = !downloading,
                            shape = RoundedCornerShape(16.dp),
                            modifier =
                                Modifier.fillMaxWidth()
                                    .height(52.dp)
                                    .testTag("policy_update_action"),
                        ) {
                            if (downloading) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    strokeWidth = 2.dp,
                                    color = MaterialTheme.colorScheme.onPrimary,
                                )
                                Spacer(Modifier.width(8.dp))
                            }
                            Text(
                                text =
                                    stringResource(
                                        apkActionLabelRes(update.phase, R.string.policy_update_now)
                                    )
                            )
                        }

                        if (update.phase != ApkUpdater.Phase.IDLE) {
                            ApkDownloadProgressBlock(
                                update = update,
                                modifier = Modifier.fillMaxWidth(),
                            )
                        }
                    }

                    // Always expose Settings' mirror selector inside force-update so users can
                    // switch mirrors and stay inside the in-app updater without opening a browser.
                    GroupedCard(innerPadding = 0.dp) {
                        UpdateMirrorSelectorRow(
                            selected = activeMirror,
                            onSelect = { chosen ->
                                val changed = chosen != activeMirror
                                activeMirror = chosen
                                UpdateChecker.setMirror(context, chosen, restartDownload = false)
                                if (downloadRelease != null && changed) {
                                    if (update.busy) {
                                        ApkUpdater.cancel()
                                        ApkUpdater.download(
                                            context = context,
                                            info = downloadRelease,
                                            autoInstall = false,
                                            mirrorOverride = chosen,
                                        )
                                    } else if (
                                        update.phase == ApkUpdater.Phase.ERROR ||
                                            update.phase == ApkUpdater.Phase.IDLE
                                    ) {
                                        ApkUpdater.download(
                                            context = context,
                                            info = downloadRelease,
                                            autoInstall = false,
                                            mirrorOverride = chosen,
                                        )
                                    }
                                }
                            },
                        )
                    }

                    if (downloadRelease == null) {
                        Button(
                            onClick = {
                                AppPolicyChecker.maybeCheck(
                                    context,
                                    force = true,
                                    userInitiated = true,
                                )
                            },
                            enabled = !checking,
                            shape = RoundedCornerShape(16.dp),
                            modifier =
                                Modifier.fillMaxWidth().height(52.dp).testTag("policy_recheck"),
                        ) {
                            RecheckButtonLabel(checking = checking, onPrimary = true)
                        }
                    } else {
                        OutlinedButton(
                            onClick = {
                                AppPolicyChecker.maybeCheck(
                                    context,
                                    force = true,
                                    userInitiated = true,
                                )
                            },
                            enabled = !checking,
                            shape = RoundedCornerShape(16.dp),
                            modifier =
                                Modifier.fillMaxWidth().height(48.dp).testTag("policy_recheck"),
                        ) {
                            RecheckButtonLabel(checking = checking, onPrimary = false)
                        }
                    }

                    // Keep users inside the in-app updater; only show a subtle browser fallback if
                    // in-app download failed or no eligible package is available in the feed yet.
                    if (downloadRelease == null || update.phase == ApkUpdater.Phase.ERROR) {
                        val pageUrl =
                            release?.pageUrl ?: policy.actionUrl ?: UpdateChecker.RELEASES_URL
                        TextButton(
                            onClick = { openExternalUrl(pageUrl) },
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(stringResource(R.string.policy_open_download_page))
                        }
                    }
                } else {
                    policy.actionUrl?.let { url ->
                        Button(
                            onClick = { openExternalUrl(url) },
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth().height(52.dp),
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp),
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(stringResource(R.string.policy_open_notice))
                        }
                    }

                    OutlinedButton(
                        onClick = {
                            AppPolicyChecker.maybeCheck(context, force = true, userInitiated = true)
                        },
                        enabled = !checking,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("policy_recheck"),
                    ) {
                        RecheckButtonLabel(checking = checking, onPrimary = false)
                    }

                    TextButton(
                        onClick = { (context as? Activity)?.finishAffinity() },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text(stringResource(R.string.policy_exit_app), color = TextSecondary)
                    }
                }

                Text(
                    text = stringResource(R.string.policy_local_data_safe_note),
                    style = MaterialTheme.typography.bodySmall,
                    color = TextTertiary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 8.dp),
                )
            }
        }
    }
}

@Composable
private fun RecheckButtonLabel(checking: Boolean, onPrimary: Boolean) {
    if (checking) {
        CircularProgressIndicator(
            modifier = Modifier.size(16.dp),
            strokeWidth = 2.dp,
            color =
                if (onPrimary) MaterialTheme.colorScheme.onPrimary
                else MaterialTheme.colorScheme.primary,
        )
        Spacer(Modifier.width(8.dp))
        Text(stringResource(R.string.checking))
    } else {
        Icon(
            imageVector = Icons.Default.Refresh,
            contentDescription = null,
            modifier = Modifier.size(18.dp),
        )
        Spacer(Modifier.width(8.dp))
        Text(stringResource(R.string.policy_recheck_action))
    }
}
