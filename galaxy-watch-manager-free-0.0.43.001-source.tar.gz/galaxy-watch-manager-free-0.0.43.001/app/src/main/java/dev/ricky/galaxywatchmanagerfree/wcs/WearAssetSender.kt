package dev.ricky.galaxywatchmanagerfree.wcs

/**
 * Wear V1 资产下发：`SetAsset`（`hjo.f4 = hjw`）+ `FilePiece`（`hjo.f12 = hje`）。
 *
 * `hjw` 的结构（依据 Wear 传输层 proto `hjo` / `hjw` / `hid` / `hif` / `hje`）：
 * - f1：资产内容摘要（SHA-1，Base64URL 无填充，20 字节）
 * - f2：内联数据（分片流式发送时留空）
 * - f3：`hid`，拥有者列表，`hid.f1` 为重复的 `hif{f1 包名, f2 签名摘要}`
 *
 * 手表端按（包名, 签名摘要）做资产访问控制：拥有者缺失时资产虽被确认保存， 但 DataItem 中的资产引用不可解析，通知卡片只能回退到通用图标。
 */
internal object WearAssetSender {

    const val MAX_BYTES = 64 * 1024

    /** 官方 `hbk` 使用 12288 字节分片，减去 73 字节头部余量。 */
    const val PIECE_BYTES = 12288 - 73

    fun send(
        sendFrame: (ByteArray) -> Boolean,
        bytes: ByteArray,
        digest: String,
        owners: List<Pair<String, String>>,
    ): Boolean {
        val hid =
            owners.fold(ByteArray(0)) { acc, (packageName, signature) ->
                acc + Proto.bytes(1, Proto.string(1, packageName) + Proto.string(2, signature))
            }
        val asset = Proto.string(1, digest) + Proto.bytes(3, hid)
        val header = Proto.bytes(4, asset) + Proto.integer(13, 1)
        val messageId = WcsFrame.messageDigest(header)
        val queue = if (bytes.size <= 32768) 5L else 6L
        if (!sendFrame(WcsFrame.envelope(header, messageId, type = queue))) return false
        for (offset in bytes.indices step PIECE_BYTES) {
            val end = minOf(bytes.size, offset + PIECE_BYTES)
            val last = end == bytes.size
            val piece =
                Proto.string(1, messageId) +
                    Proto.integer(2, if (last) 1 else 0) +
                    Proto.bytes(3, bytes.copyOfRange(offset, end)) +
                    if (last) Proto.string(4, digest) else byteArrayOf()
            if (!sendFrame(WcsFrame.envelopeNoType(Proto.bytes(12, piece)))) return false
        }
        return true
    }
}
