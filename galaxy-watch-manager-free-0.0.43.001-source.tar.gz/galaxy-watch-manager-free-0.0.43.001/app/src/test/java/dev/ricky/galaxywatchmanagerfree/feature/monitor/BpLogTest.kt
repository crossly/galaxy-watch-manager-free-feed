package dev.ricky.galaxywatchmanagerfree.feature.monitor

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test

class BpLogTest {

    @Test
    fun `parse valid blood pressure record`() {
        val record =
            JSONObject()
                .put("datauuid", "bp-uuid-1")
                .put("start_time", 1793000000000L)
                .put("systolic", 118)
                .put("diastolic", 76)
                .put("heart_rate", 68)

        val parsed = BpRecord.parse(record)
        assertNotNull(parsed)
        assertEquals("bp-uuid-1", parsed!!.id)
        assertEquals(118, parsed.systolic)
        assertEquals(76, parsed.diastolic)
        assertEquals(68, parsed.heartRate)
        assertEquals(BpRecord.Classification.NORMAL, parsed.classification)
        assertEquals(
            dev.ricky.galaxywatchmanagerfree.R.string.bp_normal,
            parsed.classification.labelRes,
        )
    }

    @Test
    fun `blood pressure classification categories`() {
        assertEquals(BpRecord.Classification.NORMAL, BpRecord.classify(115, 75))
        assertEquals(BpRecord.Classification.ELEVATED, BpRecord.classify(125, 75))
        assertEquals(BpRecord.Classification.STAGE1, BpRecord.classify(135, 85))
        assertEquals(BpRecord.Classification.STAGE2, BpRecord.classify(145, 95))
        assertEquals(BpRecord.Classification.LOW, BpRecord.classify(85, 55))
    }

    @Test
    fun `higher pressure category wins when systolic and diastolic differ`() {
        for ((systolic, diastolic) in listOf(137 to 100, 150 to 85, 130 to 90, 140 to 80)) {
            assertEquals(
                "$systolic/$diastolic must use the higher category",
                BpRecord.Classification.STAGE2,
                BpRecord.classify(systolic, diastolic),
            )
        }
    }

    @Test
    fun `history keeps older measurements and updates duplicate ids across persistence`() {
        val older = BpRecord("older", 1793000000000L, 118, 76, 68)
        val newer = BpRecord("newer", 1793000060000L, 125, 78, 72)
        val corrected = newer.copy(heartRate = 73)

        val records = BpLog.merge(listOf(older, newer), listOf(corrected))
        val restored = BpLog.decode(BpLog.encode(records))

        assertEquals(listOf(corrected, older), restored)
        assertEquals(listOf(corrected), BpLog.merge(restored, emptyList(), maxKeep = 1))
    }

    @Test
    fun `bp log encodes and decodes round trip`() {
        val record =
            BpRecord(
                id = "bp-1",
                startTime = 1793000000000L,
                systolic = 120,
                diastolic = 80,
                heartRate = 72,
            )
        val encoded = BpLog.encode(listOf(record))
        val decoded = BpLog.decode(encoded)
        assertEquals(1, decoded.size)
        assertEquals(record, decoded[0])
    }

    @Test
    fun `merge keeps the newest revision by update time regardless of arrival order`() {
        val older = BpRecord("bp-shared", 1793000000000L, 118, 76, 68, updateTime = 1_000)
        val newer = BpRecord("bp-shared", 1793000000000L, 125, 78, 72, updateTime = 2_000)

        val merged = BpLog.merge(listOf(newer), listOf(older))

        assertEquals(1, merged.size)
        assertEquals(125, merged.single().systolic)
        assertEquals(2_000, merged.single().updateTime)
    }

    @Test
    fun `parse and round trip preserve update_time`() {
        val record =
            JSONObject()
                .put("datauuid", "bp-uuid-2")
                .put("start_time", 1793000000000L)
                .put("update_time", 1793000100000L)
                .put("systolic", 130)
                .put("diastolic", 85)
                .put("heart_rate", 70)

        val parsed = BpRecord.parse(record)!!
        assertEquals(1793000100000L, parsed.updateTime)
        val restored = BpLog.decode(BpLog.encode(listOf(parsed))).single()
        assertEquals(parsed, restored)
    }

    @Test
    fun `parse and round trip preserve calibration uuid offset and source metadata`() {
        val record =
            JSONObject()
                .put("datauuid", "bp-meta-1")
                .put("start_time", 1793000000000L)
                .put("create_time", 1793000010000L)
                .put("update_time", 1793000020000L)
                .put("time_offset", 28_800_000L)
                .put("systolic", 122)
                .put("diastolic", 78)
                .put("heart_rate", 68)
                .put("calibration_datauuid", "cal-uuid-99")
                .put("deviceuuid", "synthetic-watch-uuid")
                .put("pkg_name", "com.samsung.android.shealthmonitor")
                .put("comment", "morning")

        val parsed = BpRecord.parse(record)!!
        assertEquals("cal-uuid-99", parsed.calibrationDataUuid)
        assertEquals(28_800_000L, parsed.timeOffsetMs)
        assertEquals(1793000010000L, parsed.createTime)
        assertEquals("synthetic-watch-uuid", parsed.deviceUuid)
        assertEquals("com.samsung.android.shealthmonitor", parsed.pkgName)
        assertEquals("morning", parsed.comment)
        assertEquals(1_000, BpLog.DEFAULT_MAX_KEEP)

        val restored = BpLog.decode(BpLog.encode(listOf(parsed))).single()
        assertEquals(parsed, restored)
    }
}
