package dev.ricky.galaxywatchmanagerfree.wcs

import java.io.ByteArrayInputStream
import java.io.EOFException
import java.io.FilterInputStream
import java.io.IOException
import java.nio.ByteBuffer
import org.junit.Assert.*
import org.junit.Test

class FlowProtocolTest {
    @Test
    fun fragmentedAndCoalescedFramesKeepTheirBoundaries() {
        val payload = ByteArray(65535) { it.toByte() }
        val frames =
            listOf(
                ByteBuffer.allocate(13)
                    .put(1)
                    .putInt(42)
                    .put(byteArrayOf(127, 0, 0, 1))
                    .putShort(443)
                    .putShort(1000)
                    .array(),
                FlowProtocol.data(3, 42, payload),
                FlowProtocol.datagram(byteArrayOf(8, 8, 8, 8), 53, byteArrayOf(1, 2, 3)),
                FlowProtocol.datagramV2(
                    byteArrayOf(10, 0, 0, 2),
                    50000,
                    byteArrayOf(127, 0, 0, 1),
                    53,
                    1000,
                    payload,
                ),
                FlowProtocol.channel(5, -1),
                FlowProtocol.data(16, 5, byteArrayOf(1, 2)),
                FlowProtocol.data(17, 5, ByteArray(0)),
                FlowProtocol.data(18, 5, byteArrayOf(3)),
                FlowProtocol.networkState(1, false),
                FlowProtocol.channel(2, 42),
            )
        val input =
            object :
                FilterInputStream(
                    ByteArrayInputStream(frames.fold(ByteArray(0)) { a, b -> a + b })
                ) {
                override fun read(bytes: ByteArray, offset: Int, length: Int): Int =
                    super.read(bytes, offset, minOf(length, 3))
            }
        frames.forEach { assertArrayEquals(it, FlowProtocol.read(input)) }
        assertNull(FlowProtocol.read(input))
    }

    @Test
    fun everyLegacyControlFrameConsumesOnlyItsOwnBytes() {
        val frames =
            listOf(
                FlowProtocol.channel(6, 3),
                ByteBuffer.allocate(9).put(8).putInt(3).putInt(65535).array(),
                FlowProtocol.data(9, 3, byteArrayOf(1)),
                ByteBuffer.allocate(8)
                    .put(10)
                    .putShort(1000)
                    .putShort(3)
                    .put("app".toByteArray())
                    .array(),
                ByteBuffer.allocate(9).put(12).putInt(3).putInt(100).array(),
                FlowProtocol.data(13, 3, byteArrayOf(1, 2)),
                FlowProtocol.datagram(byteArrayOf(127, 0, 0, 1), 53, byteArrayOf(1)).also {
                    it[0] = 7
                },
                FlowProtocol.datagramV2(
                        byteArrayOf(10, 0, 0, 2),
                        40000,
                        byteArrayOf(127, 0, 0, 1),
                        53,
                        1000,
                        byteArrayOf(1),
                    )
                    .also { it[0] = 15 },
            )
        val input = ByteArrayInputStream(frames.fold(ByteArray(0)) { a, b -> a + b })
        frames.forEach { assertArrayEquals(it, FlowProtocol.read(input)) }
        assertNull(FlowProtocol.read(input))
    }

    @Test
    fun networkStateUsesBigEndianTypeAndSingleByteMetering() {
        assertArrayEquals(byteArrayOf(11, -1, -1, -1, -1, 0), FlowProtocol.networkState(-1, false))
        assertArrayEquals(byteArrayOf(11, 0, 0, 0, 0, 1), FlowProtocol.networkState(0, true))
    }

    @Test
    fun incompleteHeadersAndPayloadsFailWithoutDesynchronizing() {
        for (frame in
            listOf(FlowProtocol.channel(2, 1), FlowProtocol.data(3, 1, byteArrayOf(1, 2)))) {
            for (length in 1 until frame.size) {
                assertThrows(EOFException::class.java) {
                    FlowProtocol.read(ByteArrayInputStream(frame.copyOf(length)))
                }
            }
        }
    }

    @Test
    fun unknownTypesAndOversizedWritesAreRejected() {
        assertThrows(IOException::class.java) {
            FlowProtocol.read(ByteArrayInputStream(byteArrayOf(127)))
        }
        assertThrows(IllegalArgumentException::class.java) {
            FlowProtocol.data(3, 1, ByteArray(65536))
        }
    }
}
