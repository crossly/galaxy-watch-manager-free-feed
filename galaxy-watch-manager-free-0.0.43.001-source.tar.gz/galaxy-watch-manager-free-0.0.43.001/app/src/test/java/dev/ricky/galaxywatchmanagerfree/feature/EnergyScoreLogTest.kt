package dev.ricky.galaxywatchmanagerfree.feature

import java.time.LocalDate
import java.time.ZoneId
import java.time.ZoneOffset
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class EnergyScoreLogTest {
    private val day = LocalDate.of(2026, 10, 18)
    private val zone = ZoneId.of("Pacific/Auckland")

    private fun save(
        records: List<EnergyScoreLog.Record> = emptyList(),
        score: Double = 80.0,
        now: Long = 1000L,
    ) =
        EnergyScoreLog.upsert(
            records,
            day,
            zone,
            "synthetic_v1",
            JSONObject().put("total_score", score).put("skin_temp_score", JSONObject.NULL),
            JSONObject().put("sleep_rmssd_ms", 35.0),
            "synthetic-device",
            now,
        )

    @Test
    fun `same inputs are idempotent and changed inputs preserve identity and advance revision`() {
        val first = save()
        val accepted = EnergyScoreLog.accept(first, listOf(first.single().protocolRow()), 2000L)
        assertTrue(accepted.single().acknowledged)
        assertEquals(accepted, save(accepted, now = 3000L))
        val revised = save(accepted, score = 81.0, now = 500L).single()
        assertEquals(first.single().id, revised.id)
        assertEquals(first.single().createdAt, revised.createdAt)
        assertEquals(1001L, revised.updatedAt)
        assertFalse(revised.acknowledged)
        assertEquals(1000L, revised.acceptedRevision)
        assertEquals(accepted.single().acceptedAt, revised.acceptedAt)
    }

    @Test
    fun `a late acknowledgment never confirms a newer calculation`() {
        val first = save()
        val revised = save(first, score = 82.0, now = 3000L)
        val late = EnergyScoreLog.accept(revised, listOf(first.single().protocolRow()), 4000L)
        assertFalse(late.single().acknowledged)
        assertNull(late.single().acceptedAt)
        val matched = EnergyScoreLog.accept(late, listOf(revised.single().protocolRow()), 5000L)
        assertTrue(matched.single().acknowledged)
    }

    @Test
    fun `protocol uses UTC date identity and never includes database row id`() {
        val record = save().single()
        val row = record.protocolRow()
        assertEquals(
            day.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli(),
            row.getLong("day_time"),
        )
        assertEquals(record.id, row.getString("datauuid"))
        assertEquals("synthetic-device", row.getString("deviceuuid"))
        assertFalse(row.has("_id"))
        assertTrue(row.isNull("skin_temp_score"))
        assertTrue(record.json().isNull("watch_persistence_verified"))
        assertEquals("phone_computed", record.json().getString("source"))
    }

    @Test
    fun `newly available device identity revises an existing result and invalidates old acknowledgment`() {
        val first = save().single().copy(deviceUuid = "")
        val accepted = EnergyScoreLog.accept(listOf(first), listOf(first.protocolRow()), 2000L)
        val revised = save(accepted, now = 3000L).single()
        assertEquals(first.id, revised.id)
        assertEquals("synthetic-device", revised.deviceUuid)
        assertEquals(3000L, revised.updatedAt)
        assertFalse(revised.acknowledged)
    }

    @Test
    fun `storage restores historical values revisions inputs and nulls`() {
        val first = save()
        val records = EnergyScoreLog.accept(first, listOf(first.single().protocolRow()), 2000L)
        val restored = EnergyScoreLog.decode(EnergyScoreLog.encode(records))
        assertEquals(records, restored)
        assertEquals(records, save(restored, now = 3000L))
        assertEquals(zone.id, restored.single().zoneId)
        assertEquals(day.toString(), restored.single().date)
        assertTrue(JSONObject(restored.single().values).isNull("skin_temp_score"))
        assertEquals(35.0, JSONObject(restored.single().inputs).getDouble("sleep_rmssd_ms"), 0.0)
        assertTrue(EnergyScoreLog.decode("malformed").isEmpty())
    }

    @Test
    fun `unknown and invalid totals cannot be stored as measurements`() {
        listOf(-1.0, 101.0).forEach { score ->
            assertThrows(IllegalArgumentException::class.java) { save(score = score) }
        }
        assertThrows(IllegalArgumentException::class.java) {
            EnergyScoreLog.upsert(
                emptyList(),
                day,
                zone,
                "synthetic_v1",
                JSONObject(),
                JSONObject(),
                "synthetic-device",
                1L,
            )
        }
    }

    @Test
    fun `watchSyncRows bundles selected record with valid records in the 7-day watch window`() {
        val today = LocalDate.of(2026, 10, 25)
        var records = emptyList<EnergyScoreLog.Record>()
        listOf(
                LocalDate.of(2026, 10, 15) to "dev-1", // older than 7-day window
                LocalDate.of(2026, 10, 19) to "dev-1", // window start (today - 6)
                LocalDate.of(2026, 10, 22) to "", // blank deviceUuid -> excluded
                LocalDate.of(2026, 10, 24) to "dev-1", // yesterday
                LocalDate.of(2026, 10, 25) to "dev-1", // today
            )
            .forEachIndexed { index, (date, deviceUuid) ->
                records =
                    EnergyScoreLog.upsert(
                        records,
                        date,
                        zone,
                        "synthetic_v1",
                        JSONObject().put("total_score", 70.0 + index),
                        JSONObject(),
                        deviceUuid,
                        1000L + index,
                    )
            }
        val yesterdayRecord = records.first { it.date == "2026-10-24" }
        val olderRecord = records.first { it.date == "2026-10-15" }
        val blankDeviceRecord = records.first { it.date == "2026-10-22" }

        val windowRows = EnergyScoreLog.watchSyncRows(records, yesterdayRecord.id, today)
        assertEquals(
            listOf(
                    LocalDate.of(2026, 10, 19),
                    LocalDate.of(2026, 10, 24),
                    LocalDate.of(2026, 10, 25),
                )
                .map { it.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli() },
            windowRows.map { it.getLong("day_time") },
        )

        val olderPlusWindow = EnergyScoreLog.watchSyncRows(records, olderRecord.id, today)
        assertEquals(4, olderPlusWindow.size)
        assertEquals(olderRecord.id, olderPlusWindow.first().getString("datauuid"))

        assertTrue(EnergyScoreLog.watchSyncRows(records, blankDeviceRecord.id, today).isEmpty())

        val accepted = EnergyScoreLog.accept(records, windowRows, 9000L)
        assertTrue(accepted.first { it.date == "2026-10-19" }.acknowledged)
        assertTrue(accepted.first { it.date == "2026-10-24" }.acknowledged)
        assertTrue(accepted.first { it.date == "2026-10-25" }.acknowledged)
        assertFalse(accepted.first { it.date == "2026-10-15" }.acknowledged)
    }
}
