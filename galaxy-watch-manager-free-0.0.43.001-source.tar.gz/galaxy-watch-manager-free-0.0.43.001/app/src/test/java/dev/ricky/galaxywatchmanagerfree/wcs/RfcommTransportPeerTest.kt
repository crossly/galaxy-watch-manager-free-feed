package dev.ricky.galaxywatchmanagerfree.wcs

import android.bluetooth.BluetoothDevice
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RfcommTransportPeerTest {
    @Test
    fun acceptsOnlyBondedPeerMatchingSelectedMacCaseInsensitively() {
        assertTrue(
            RfcommTransport.isAcceptedPeer(
                targetAddress = "02:00:00:00:AA:BB",
                incomingAddress = "02:00:00:00:aa:bb",
                incomingBondState = BluetoothDevice.BOND_BONDED,
            )
        )
        assertFalse(
            RfcommTransport.isAcceptedPeer(
                targetAddress = null,
                incomingAddress = "02:00:00:00:AA:BB",
                incomingBondState = BluetoothDevice.BOND_BONDED,
            )
        )
        assertFalse(
            RfcommTransport.isAcceptedPeer(
                targetAddress = "02:00:00:00:AA:BB",
                incomingAddress = "02:00:00:00:AA:BC",
                incomingBondState = BluetoothDevice.BOND_BONDED,
            )
        )
        assertFalse(
            RfcommTransport.isAcceptedPeer(
                targetAddress = "02:00:00:00:AA:BB",
                incomingAddress = "02:00:00:00:AA:BB",
                incomingBondState = BluetoothDevice.BOND_NONE,
            )
        )
        assertFalse(
            RfcommTransport.isAcceptedPeer(
                targetAddress = "02:00:00:00:AA:BB",
                incomingAddress = "02:00:00:00:AA:BB",
                incomingBondState = BluetoothDevice.BOND_BONDING,
            )
        )
    }
}
