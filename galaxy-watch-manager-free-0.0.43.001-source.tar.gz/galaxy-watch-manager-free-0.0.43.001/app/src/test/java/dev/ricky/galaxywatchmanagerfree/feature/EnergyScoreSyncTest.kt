package dev.ricky.galaxywatchmanagerfree.feature

import dev.ricky.galaxywatchmanagerfree.wcs.WcsPaths
import java.io.ByteArrayOutputStream
import java.util.Base64
import java.util.zip.GZIPOutputStream
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class EnergyScoreSyncTest {
    @Test
    fun `sync preserves row identity nulls and revisions and waits for the matching response`() =
        runTest {
            val sent = mutableListOf<JSONObject>()
            val statuses = mutableListOf<EnergyScoreSync.Status>()
            val accepted = mutableListOf<JSONObject>()
            val sync =
                EnergyScoreSync(
                    this,
                    { "synthetic-watch" },
                    { "synthetic-phone" },
                    {
                        sent.add(it)
                        true
                    },
                    statuses::add,
                    { rows, _ ->
                        accepted.addAll(rows)
                        true
                    },
                    { 42L },
                )
            val row = row().put("shr_value", JSONObject.NULL)
            assertTrue(sync.push(listOf(row)))
            row.put("total_score", 1)
            val packet = sent.single()
            assertEquals(WcsPaths.HEALTH_PHONE_SYNC, packet.getString("sender"))
            assertEquals("synthetic-watch", packet.getString("destination_node"))
            val body = HealthJson.entries(packet.getString("body"))
            val written =
                body.getJSONObject(2).getJSONArray(EnergyScoreSync.MODULE).getJSONObject(0)
            assertEquals(81.5, written.getDouble("total_score"), 0.0)
            assertEquals("synthetic-score", written.getString("datauuid"))
            assertEquals(17L, written.getLong("update_time"))
            assertTrue(written.isNull("shr_value"))
            assertEquals(EnergyScoreSync.Status.WAITING_ACK, statuses.last())
            assertTrue(accepted.isEmpty())
            val sequence = packet.getInt("sequence_num")
            assertFalse(sync.handleMessage(ack(sequence + 1)))
            assertFalse(sync.handleMessage(ack(sequence).put("sender", "other-service")))
            assertFalse(sync.handleMessage(ack(sequence).put("receiver", "other-service")))
            assertTrue(sync.handleMessage(ack(sequence, action = "REQUEST_DATA")))
            assertTrue(accepted.isEmpty())
            assertTrue(sync.handleMessage(ack(sequence)))
            assertEquals(EnergyScoreSync.Status.ACCEPTED, statuses.last())
            assertEquals(81.5, accepted.single().getDouble("total_score"), 0.0)
            assertFalse(sync.handleMessage(ack(sequence)))
        }

    @Test
    fun `replaced request disconnect and timeout cannot accept a late response`() = runTest {
        val sent = mutableListOf<JSONObject>()
        val statuses = mutableListOf<EnergyScoreSync.Status>()
        var accepted = 0
        val sync =
            EnergyScoreSync(
                this,
                { "watch" },
                { "phone" },
                {
                    sent.add(it)
                    true
                },
                statuses::add,
                { _, _ ->
                    accepted++
                    true
                },
                timeoutMillis = 100,
            )
        assertTrue(sync.push(listOf(row())))
        runCurrent()
        val first = sent.last().getInt("sequence_num")
        assertTrue(sync.push(listOf(row().put("update_time", 18))))
        runCurrent()
        assertFalse(sync.handleMessage(ack(first)))
        val second = sent.last().getInt("sequence_num")
        advanceTimeBy(100)
        runCurrent()
        assertEquals(EnergyScoreSync.Status.TIMED_OUT, statuses.last())
        assertFalse(sync.handleMessage(ack(second)))
        assertTrue(sync.push(listOf(row())))
        runCurrent()
        val third = sent.last().getInt("sequence_num")
        sync.disconnect()
        assertFalse(sync.handleMessage(ack(third)))
        advanceTimeBy(100)
        runCurrent()
        assertEquals(EnergyScoreSync.Status.DISCONNECTED, statuses.last())
        assertEquals(0, accepted)
    }

    @Test
    fun `failed send rejection and malformed body never become accepted`() = runTest {
        val sent = mutableListOf<JSONObject>()
        val statuses = mutableListOf<EnergyScoreSync.Status>()
        var canSend = false
        var accepted = 0
        val sync =
            EnergyScoreSync(
                this,
                { "watch" },
                { "phone" },
                {
                    sent.add(it)
                    canSend
                },
                statuses::add,
                { _, _ ->
                    accepted++
                    true
                },
                timeoutMillis = 100,
            )
        assertFalse(sync.push(listOf(row())))
        assertEquals(EnergyScoreSync.Status.SEND_FAILED, statuses.last())
        canSend = true
        assertTrue(sync.push(listOf(row())))
        val sequence = sent.last().getInt("sequence_num")
        assertTrue(sync.handleMessage(ack(sequence).put("body", "malformed")))
        assertEquals(EnergyScoreSync.Status.WAITING_ACK, statuses.last())
        assertTrue(sync.handleMessage(ack(sequence, result = "FAIL")))
        assertEquals(EnergyScoreSync.Status.REJECTED, statuses.last())
        assertEquals(0, accepted)
    }

    @Test
    fun `diagnostic logging reports safe date summaries without leaking scores or device ids`() =
        runTest {
            val sent = mutableListOf<JSONObject>()
            val logs = mutableListOf<String>()
            val errors = mutableListOf<String>()
            val sync =
                EnergyScoreSync(
                    scope = this,
                    watchNode = { "watch" },
                    deviceModel = { "phone" },
                    send = {
                        sent.add(it)
                        true
                    },
                    onStatus = {},
                    onAccepted = { _, _ -> true },
                    timeoutMillis = 100,
                    onLog = logs::add,
                    onError = errors::add,
                )
            val row =
                row()
                    .put("deviceuuid", "secret-watch-uuid-12345")
                    .put("day_time", 1_795_478_400_000L) // 2026-11-24 UTC
            assertTrue(sync.push(listOf(row)))
            assertTrue(logs.last().contains("rows=1"))
            assertTrue(logs.last().contains("2026-11-24"))
            assertFalse(logs.last().contains("secret-watch-uuid"))
            assertFalse(logs.last().contains("81.5"))

            val seq = sent.last().getInt("sequence_num")
            assertTrue(sync.handleMessage(ack(seq)))
            assertTrue(logs.last().contains("手表已应答"))
            assertTrue(logs.last().contains("2026-11-24"))
            assertTrue(errors.isEmpty())

            assertTrue(sync.push(listOf(row), automatic = true))
            assertTrue(sync.isPending)
            assertTrue(logs.last().contains("自动写回手表"))
            val seq2 = sent.last().getInt("sequence_num")
            assertTrue(sync.handleMessage(ack(seq2, result = "VALIDATION_ERROR")))
            assertFalse(sync.isPending)
            assertTrue(errors.last().contains("VALIDATION_ERROR"))
        }

    @Test
    fun `auto write policy pushes today once per day and never repeats on same day`() {
        val today = java.time.LocalDate.of(2026, 11, 25)
        val yesterday = today.minusDays(1)
        val tomorrow = today.plusDays(1)
        val yesterdayRecord = recordFor(yesterday)
        val todayRecord = recordFor(today)
        val tomorrowRecord = recordFor(tomorrow)
        val now = 1_795_600_000_000L

        // Disconnected or in-flight skips without consuming the daily slot.
        assertEquals(
            EnergyScoreAutoWritePolicy.Decision.SkipDisconnected,
            EnergyScoreAutoWritePolicy.decide(
                listOf(todayRecord),
                today,
                lastPushedDay = null,
                sessionReady = false,
                syncInFlight = false,
                lastAttemptAt = 0L,
                now = now,
            ),
        )
        assertEquals(
            EnergyScoreAutoWritePolicy.Decision.SkipInFlight,
            EnergyScoreAutoWritePolicy.decide(
                listOf(todayRecord),
                today,
                lastPushedDay = null,
                sessionReady = true,
                syncInFlight = true,
                lastAttemptAt = 0L,
                now = now,
            ),
        )

        // Past-only scores do not consume today's automatic push slot.
        assertEquals(
            EnergyScoreAutoWritePolicy.Decision.SkipNoTodayScore,
            EnergyScoreAutoWritePolicy.decide(
                listOf(yesterdayRecord),
                today,
                lastPushedDay = null,
                sessionReady = true,
                syncInFlight = false,
                lastAttemptAt = 0L,
                now = now,
            ),
        )

        // Blank deviceUuid cannot be pushed.
        assertEquals(
            EnergyScoreAutoWritePolicy.Decision.SkipNoTodayScore,
            EnergyScoreAutoWritePolicy.decide(
                listOf(todayRecord.copy(deviceUuid = "")),
                today,
                lastPushedDay = null,
                sessionReady = true,
                syncInFlight = false,
                lastAttemptAt = 0L,
                now = now,
            ),
        )

        // Today's score eligible for automatic push once.
        assertEquals(
            EnergyScoreAutoWritePolicy.Decision.Push(todayRecord),
            EnergyScoreAutoWritePolicy.decide(
                listOf(yesterdayRecord, todayRecord),
                today,
                lastPushedDay = yesterday.toString(),
                sessionReady = true,
                syncInFlight = false,
                lastAttemptAt = 0L,
                now = now,
            ),
        )

        // Once today's push succeeded, even a recalculated unacknowledged revision today is NOT
        // auto-pushed again on the same day.
        val recalculatedToday = todayRecord.copy(updatedAt = todayRecord.updatedAt + 100L)
        assertEquals(
            EnergyScoreAutoWritePolicy.Decision.SkipAlreadyPushedToday,
            EnergyScoreAutoWritePolicy.decide(
                listOf(recalculatedToday),
                today,
                lastPushedDay = today.toString(),
                sessionReady = true,
                syncInFlight = false,
                lastAttemptAt = 0L,
                now = now + 3_600_000L,
            ),
        )

        // Already-acknowledged today record (e.g. upgraded from older version) skips cleanly.
        val ackedToday =
            todayRecord.copy(acceptedRevision = todayRecord.updatedAt, acceptedAt = now)
        assertEquals(
            EnergyScoreAutoWritePolicy.Decision.SkipAlreadyAcknowledged(today),
            EnergyScoreAutoWritePolicy.decide(
                listOf(ackedToday),
                today,
                lastPushedDay = null,
                sessionReady = true,
                syncInFlight = false,
                lastAttemptAt = 0L,
                now = now,
            ),
        )

        // Recent failed attempt respects retry cooldown, then retries after cooldown elapses.
        assertEquals(
            EnergyScoreAutoWritePolicy.Decision.SkipCooldown,
            EnergyScoreAutoWritePolicy.decide(
                listOf(todayRecord),
                today,
                lastPushedDay = yesterday.toString(),
                sessionReady = true,
                syncInFlight = false,
                lastAttemptAt = now - 60_000L,
                now = now,
            ),
        )
        assertEquals(
            EnergyScoreAutoWritePolicy.Decision.Push(todayRecord),
            EnergyScoreAutoWritePolicy.decide(
                listOf(todayRecord),
                today,
                lastPushedDay = yesterday.toString(),
                sessionReady = true,
                syncInFlight = false,
                lastAttemptAt = now - EnergyScoreAutoWritePolicy.DEFAULT_RETRY_COOLDOWN_MS,
                now = now,
            ),
        )

        // Next calendar day becomes eligible again automatically.
        assertEquals(
            EnergyScoreAutoWritePolicy.Decision.Push(tomorrowRecord),
            EnergyScoreAutoWritePolicy.decide(
                listOf(todayRecord, tomorrowRecord),
                tomorrow,
                lastPushedDay = today.toString(),
                sessionReady = true,
                syncInFlight = false,
                lastAttemptAt = 0L,
                now = now + 86_400_000L,
            ),
        )

        // containsDate verifies UTC-midnight day_time match for marking daily push completion.
        val batchWithToday =
            EnergyScoreLog.watchSyncRows(
                listOf(yesterdayRecord, todayRecord),
                todayRecord.id,
                today,
            )
        assertTrue(EnergyScoreAutoWritePolicy.containsDate(batchWithToday, today))
        assertFalse(EnergyScoreAutoWritePolicy.containsDate(batchWithToday, tomorrow))
        val yesterdayOnly = listOf(yesterdayRecord.protocolRow())
        assertFalse(EnergyScoreAutoWritePolicy.containsDate(yesterdayOnly, today))
    }

    private fun recordFor(date: java.time.LocalDate): EnergyScoreLog.Record =
        EnergyScoreLog.Record(
            id = "rec-$date",
            date = date.toString(),
            zoneId = "Asia/Shanghai",
            algorithm = "phone_vitality_v1",
            createdAt = 1_000L,
            updatedAt = 2_000L,
            deviceUuid = "synthetic-watch",
            values = """{"total_score":84.0}""",
            inputs = """{"profile_age":30,"profile_sex":"M"}""",
        )

    private fun row() =
        JSONObject()
            .put("datauuid", "synthetic-score")
            .put("update_time", 17L)
            .put("day_time", 1_700_006_400_000L)
            .put("total_score", 81.5)

    private fun ack(
        sequence: Int,
        result: String = "SUCCESS",
        action: String = "SYNC_DATA",
    ): JSONObject {
        val body =
            JSONArray()
                .put(
                    JSONObject()
                        .put(
                            "message_info",
                            JSONArray()
                                .put(JSONObject().put("action", action).put("result", result)),
                        )
                )
        val output = ByteArrayOutputStream()
        GZIPOutputStream(output).use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        return JSONObject()
            .put("sequence_num", sequence)
            .put("message", WcsPaths.HEALTH_MSG_RESPONSE)
            .put("type", WcsPaths.HEALTH_TYPE_DATA)
            .put("sender", WcsPaths.HEALTH_WATCH_SYNC)
            .put("receiver", WcsPaths.HEALTH_PHONE_SYNC)
            .put("body", Base64.getEncoder().encodeToString(output.toByteArray()))
    }
}
