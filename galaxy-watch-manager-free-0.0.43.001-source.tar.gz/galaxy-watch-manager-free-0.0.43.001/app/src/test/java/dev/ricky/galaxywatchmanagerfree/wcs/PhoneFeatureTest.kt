package dev.ricky.galaxywatchmanagerfree.wcs

import java.util.Locale
import java.util.TimeZone
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class PhoneFeatureTest {
    private fun feature(
        bluetoothName: String = "Synthetic non-Samsung phone",
        locale: Locale = Locale.US,
        timeZone: TimeZone = TimeZone.getTimeZone("UTC"),
        timeMillis: Long = 1_700_000_000_000L,
    ): JSONObject =
        PhoneFeature.build(
            bluetoothName = bluetoothName,
            screenWidth = 1080,
            screenHeight = 2400,
            defaultSmsPackage = "com.example.messages",
            locale = locale,
            timeZone = timeZone,
            timeMillis = timeMillis,
        )

    @Test
    fun `feature exchange retains the vendor accepted by watch Health Monitor`() {
        val frame =
            WcsFrame.jsonFrame(
                WcsPaths.INTERNAL_FEATURE,
                JSONObject()
                    .put("msgId", WcsPaths.MSG_FEATURE_EXCHANGE)
                    .put("msgType", 2)
                    .put("data", feature())
                    .toString(),
                CompanionProfile.WATCH7.packageName,
                WcsPaths.SIGNATURE_PLUGIN,
                destNode = "abcdef12",
                sourceNode = "12345678",
                code = 17,
                generation = 42,
            )
        val message =
            WcsFrame.decode(frame.copyOfRange(4, frame.size)) as WcsFrame.Incoming.Wearable
        val data = JSONObject(message.payload).getJSONObject("data")
        assertEquals("samsung", data.getString("vender"))
        assertFalse(data.has("vendor"))
    }

    @Test
    fun `phone compatibility identity keeps the previously working profile`() {
        val data = feature()
        assertEquals("Galaxy S25 Ultra", data.getString("deviceName"))
        assertEquals("SM-S938U1", data.getString("modelNumber"))
        assertEquals("false", data.get("isTablet"))
        assertEquals("XAA", data.getString("csc"))
    }

    @Test
    fun `runtime fields retain actual values and wire types on every exchange`() {
        val first = feature()
        assertEquals("Synthetic non-Samsung phone", first.getString("deviceBtName"))
        assertEquals("1080", first.get("screenWidth"))
        assertEquals("2400", first.get("screenHeight"))
        assertEquals("en_US", first.getString("locale"))
        assertEquals("UTC", first.getString("timezone"))
        assertEquals(1_700_000_000_000L, first.get("time"))
        assertEquals("false", first.get("sepLiteDevice"))
        assertEquals("com.example.messages", first.getString("defaultAppMessage"))
        first.put("vender", "modified")

        val next =
            feature(
                bluetoothName = "Synthetic renamed phone",
                locale = Locale.SIMPLIFIED_CHINESE,
                timeZone = TimeZone.getTimeZone("Asia/Shanghai"),
                timeMillis = 1_700_000_060_000L,
            )
        assertEquals("samsung", next.getString("vender"))
        assertEquals("Synthetic renamed phone", next.getString("deviceBtName"))
        assertEquals("zh_CN", next.getString("locale"))
        assertEquals("Asia/Shanghai", next.getString("timezone"))
        assertEquals(1_700_000_060_000L, next.get("time"))
    }
}
