package dev.ricky.galaxywatchmanagerfree.wcs

import java.util.Locale
import java.util.TimeZone
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class PhoneStatusTest {
    private fun status(
        locale: Locale = Locale.SIMPLIFIED_CHINESE,
        timeZone: TimeZone = TimeZone.getTimeZone("Asia/Shanghai"),
        timeMillis: Long = 1_700_000_000_000L,
        release: String = "15.0.0",
    ): JSONObject =
        PhoneStatus.build(
            locale = locale,
            timeZone = timeZone,
            timeMillis = timeMillis,
            release = release,
            sdkInt = 35,
            display = "SyntheticBuild",
            pluginVersion = "1.2.3",
        )

    @Test
    fun `status exchange keeps the US carrier profile consistent with the compatibility identity`() {
        val data = status()
        assertEquals("310", data.get("mcc"))
        assertEquals("410", data.get("mnc"))
        assertEquals("us", data.getString("simCountry"))
    }

    @Test
    fun `device platform version uses only the first dotted release segment`() {
        assertEquals("15", status(release = "15.0.0").getString("devicePlatformVersion"))
        assertEquals("16", status(release = "16").getString("devicePlatformVersion"))
    }

    @Test
    fun `runtime locale and time values stay actual`() {
        val data = status()
        assertEquals("zh", data.getString("localeLanguage"))
        assertEquals("CN", data.getString("localeRegion"))
        assertEquals("Asia/Shanghai", data.getString("timezone"))
        assertEquals(1_700_000_000_000L, data.get("time"))
        assertEquals("android", data.getString("devicePlatform"))
        assertEquals("35", data.get("SDKVersion"))
    }
}
