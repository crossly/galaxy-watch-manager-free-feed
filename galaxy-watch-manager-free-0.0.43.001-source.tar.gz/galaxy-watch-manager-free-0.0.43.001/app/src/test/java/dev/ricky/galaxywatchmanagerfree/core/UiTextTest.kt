package dev.ricky.galaxywatchmanagerfree.core

import android.content.res.Resources
import org.junit.Assert.assertEquals
import org.junit.Test

class UiTextTest {
    @Suppress("DEPRECATION")
    private val fakeResources =
        object : Resources(null, null, null) {
            private val strings =
                mapOf(
                    1 to "base %1\$s",
                    2 to "%1\$s; rollback failed for %2\$s",
                    3 to "item=%1\$s",
                    4 to "failures: %1\$s",
                )

            override fun getString(id: Int): String = strings.getValue(id)

            override fun getString(id: Int, vararg formatArgs: Any?): String =
                String.format(strings.getValue(id), *formatArgs)
        }

    @Test
    fun resolvesNestedUiTextAndListsOfUiText() {
        val nested = uiText(2, uiText(1, "pkg"), "a, b")
        assertEquals("base pkg; rollback failed for a, b", nested.resolve(fakeResources))

        val listText = uiText(4, listOf(uiText(3, "one"), uiText(3, "two")))
        assertEquals("failures: item=one; item=two", listText.resolve(fakeResources))
    }
}
