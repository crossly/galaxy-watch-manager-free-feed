package dev.ricky.galaxywatchmanagerfree.wcs

import dev.ricky.galaxywatchmanagerfree.feature.NotificationForwardingCache
import dev.ricky.galaxywatchmanagerfree.feature.NotificationIdentity
import dev.ricky.galaxywatchmanagerfree.wcs.BridgerNotificationSender.Result
import org.junit.Assert.*
import org.junit.Test

class BridgerNotificationSenderTest {
    private val identity = NotificationIdentity("test.app.one", 7, "synthetic", 0, 10001)
    private val icon =
        java.util.Base64.getDecoder()
            .decode(
                "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRZkAAAAASUVORK5CYII="
            )

    private fun send(
        frames: MutableList<ByteArray>,
        bytes: ByteArray? = icon,
        id: NotificationIdentity = identity,
        smallIconBytes: ByteArray? = null,
        isSmallIconVector: Boolean = false,
        appName: String? = "Synthetic app",
        phoneNode: String = "c0ffee12",
        allowTextFallback: Boolean = true,
        accept: (ByteArray) -> Boolean = { true },
    ): BridgerNotificationSender.Result? =
        BridgerNotificationSender { frame ->
                frames += frame
                accept(frame)
            }
            .send(
                phoneNode,
                id,
                "Synthetic title",
                "Synthetic body",
                appName,
                1234L,
                42L,
                bytes,
                smallIcon = smallIconBytes,
                isSmallIconVector = isSmallIconVector,
                allowTextFallback = allowTextFallback,
            )

    private fun inner(frame: ByteArray): Proto.Message =
        Proto.parse(Proto.parse(frame.copyOfRange(4, frame.size)).raw(1)!!)

    private fun data(frames: List<ByteArray>): WcsFrame.Incoming.WearPath =
        WcsFrame.decode(frames.last().let { it.copyOfRange(4, it.size) })
            as WcsFrame.Incoming.WearPath

    @Test
    fun `icon bytes and indexed asset reference resolve to the same digest`() {
        val frames = mutableListOf<ByteArray>()
        assertEquals(Result.WITH_ICON, send(frames))
        val asset = inner(frames.first()).nested(4)!!
        val digest = WcsFrame.messageDigest(icon)
        assertEquals(digest, asset.text(1))
        assertEquals(3, frames.size)
        assertEquals(1L, inner(frames.first()).num(13))
        assertFalse(asset.has(2))
        val owner = asset.nested(3)!!.nested(1)!!
        val piece = inner(frames[1]).nested(12)!!
        assertEquals(
            WcsFrame.messageDigest(Proto.parse(frames.first().drop(4).toByteArray()).raw(1)!!),
            piece.text(1),
        )
        assertEquals(1L, piece.num(2))
        assertArrayEquals(icon, piece.raw(3))
        assertEquals(digest, piece.text(4))
        assertEquals("com.samsung.android.wcs.extension", owner.text(1))
        assertEquals(WcsPaths.SIGNATURE_PLUGIN, owner.text(2))
        val reference = inner(frames.last()).nested(9)!!.nested(8)!!
        assertEquals("0", reference.text(1))
        assertEquals(digest, reference.nested(2)!!.text(4))
        assertEquals(4L, reference.num(3))
        val notification = data(frames)
        assertEquals(0, notification.dataMap["app_icon"])
        assertEquals(0, notification.dataMap["icon"])
        val entry =
            Proto.parse(notification.dataItems.single())
                .fields[1]!!
                .map { Proto.parse(it as ByteArray) }
                .single { it.text(1) == "app_icon" }
        assertEquals(13L, entry.nested(2)!!.num(1))
        assertEquals(0L, entry.nested(2)!!.nested(2)!!.num(13))
        assertEquals("Synthetic title", notification.dataMap["title_raw"])
        assertEquals("Synthetic body", notification.dataMap["text_raw"])
        assertEquals("Synthetic app", notification.dataMap["app_name"])
        assertEquals(1234L, notification.dataMap["when"])
        assertEquals("wear://c0ffee12/${identity.bridgerPath("c0ffee12")}", notification.path)
    }

    @Test
    fun `v1 file pieces make referenced assets available at chunk and queue boundaries`() {
        for (size in listOf(4097, 12215, 12216, 32768, 32769, 64 * 1024)) {
            val bytes = ByteArray(size) { (it * 31).toByte() }
            val frames = mutableListOf<ByteArray>()
            assertEquals(Result.WITH_ICON, send(frames, bytes))
            assertEquals(2 + (size + 12214) / 12215, frames.size)
            val header = inner(frames.first())
            val asset = header.nested(4)!!
            val digest = WcsFrame.messageDigest(bytes)
            assertEquals(digest, asset.text(1))
            assertEquals(1L, header.num(13))
            assertFalse(asset.has(2))
            val owner = asset.nested(3)!!.nested(1)!!
            assertEquals("com.samsung.android.wcs.extension", owner.text(1))
            assertEquals(WcsPaths.SIGNATURE_PLUGIN, owner.text(2))
            val headerEnvelope = Proto.parse(frames.first().copyOfRange(4, frames.first().size))
            assertEquals(if (size <= 32768) 5L else 6L, headerEnvelope.num(5))
            val headerId = headerEnvelope.text(2)
            val content = java.io.ByteArrayOutputStream()
            frames.dropLast(1).forEachIndexed { index, frame ->
                assertEquals(frame.size - 4, LengthPrefix.readLength(frame))
                val envelope = Proto.parse(frame.copyOfRange(4, frame.size))
                assertEquals(1L, envelope.num(3))
                assertEquals(1L, envelope.num(4))
                assertEquals(WcsFrame.messageDigest(envelope.raw(1)!!), envelope.text(2))
                if (index > 0) {
                    assertFalse(envelope.has(5))
                    val piece = inner(frame).nested(12)!!
                    assertEquals(headerId, piece.text(1))
                    assertTrue(piece.raw(3)!!.size <= 12215)
                    content.write(piece.raw(3)!!)
                    val last = index == frames.lastIndex - 1
                    assertEquals(if (last) 1L else 0L, piece.num(2))
                    if (last) {
                        assertEquals(digest, piece.text(4))
                        assertEquals(digest, WcsFrame.messageDigest(content.toByteArray()))
                    } else {
                        assertFalse(piece.has(4))
                    }
                }
            }
            assertArrayEquals(bytes, content.toByteArray())
            assertEquals(digest, inner(frames.last()).nested(9)!!.nested(8)!!.nested(2)!!.text(4))
        }
    }

    @Test
    fun `different applications and updated icons carry their own assets`() {
        val first = mutableListOf<ByteArray>()
        val second = mutableListOf<ByteArray>()
        val updated = mutableListOf<ByteArray>()
        val otherIcon = byteArrayOf(1, 2, 3)
        assertEquals(Result.WITH_ICON, send(first))
        assertEquals(
            Result.WITH_ICON,
            send(second, otherIcon, identity.copy(packageName = "test.app.two")),
        )
        assertEquals(Result.WITH_ICON, send(updated, otherIcon))
        assertNotEquals(data(first).path, data(second).path)
        assertEquals(data(first).path, data(updated).path)
        assertNotEquals(
            inner(first.first()).nested(4)!!.text(1),
            inner(second.first()).nested(4)!!.text(1),
        )
        assertEquals(
            inner(second.first()).nested(4)!!.text(1),
            inner(updated.first()).nested(4)!!.text(1),
        )
    }

    @Test
    fun `missing empty or oversized icons keep text without dangling references`() {
        for (bytes in listOf(null, byteArrayOf(), ByteArray(64 * 1024 + 1))) {
            val frames = mutableListOf<ByteArray>()
            assertEquals(Result.TEXT_ONLY, send(frames, bytes))
            assertEquals(1, frames.size)
            assertFalse(data(frames).dataMap.containsKey("app_icon"))
            assertFalse(inner(frames.single()).nested(9)!!.has(8))
            assertEquals("Synthetic body", data(frames).dataMap["text_raw"])
        }
    }

    @Test
    fun `rejected header or file piece stops transfer and falls back to text`() {
        for (rejected in 1..4) {
            val frames = mutableListOf<ByteArray>()
            assertEquals(
                Result.TEXT_ONLY,
                send(frames, ByteArray(24431)) { frames.size != rejected },
            )
            assertEquals(rejected + 1, frames.size)
            assertFalse(data(frames).dataMap.containsKey("app_icon"))
            assertFalse(inner(frames.last()).nested(9)!!.has(8))
            assertEquals("Synthetic body", data(frames).dataMap["text_raw"])
        }
    }

    @Test
    fun `text fallback can acquire its icon on an unchanged notification update`() {
        val cache = NotificationForwardingCache()
        val target = Any()
        val frames = mutableListOf<ByteArray>()
        fun forward(acceptAsset: Boolean) =
            cache.forward(target, identity.key, "same content") { allowTextFallback ->
                send(frames, allowTextFallback = allowTextFallback) {
                    acceptAsset || !inner(it).has(4)
                }
            }

        assertEquals(Result.TEXT_ONLY, forward(acceptAsset = false))
        val fallback = data(frames)
        assertFalse(fallback.dataMap.containsKey("app_icon"))
        frames.clear()

        assertNull(forward(acceptAsset = false))
        assertTrue(inner(frames.single()).has(4))
        frames.clear()

        assertEquals(Result.WITH_ICON, forward(acceptAsset = true))
        assertEquals(fallback.path, data(frames).path)
        assertEquals(0, data(frames).dataMap["app_icon"])
        frames.clear()
        assertNull(forward(acceptAsset = true))
        assertTrue(frames.isEmpty())
    }

    @Test
    fun `notification queue rejection is returned to caller`() {
        val frames = mutableListOf<ByteArray>()
        assertEquals(Result.REJECTED, send(frames) { !inner(it).has(9) })
    }

    @Test
    fun `missing phone identity sends no frame`() {
        val frames = mutableListOf<ByteArray>()
        assertEquals(Result.REJECTED, send(frames, phoneNode = ""))
        assertTrue(frames.isEmpty())
    }

    @Test
    fun `new connection resends asset rather than trusting previous peer state`() {
        val first = mutableListOf<ByteArray>()
        val reconnected = mutableListOf<ByteArray>()
        assertEquals(Result.WITH_ICON, send(first))
        assertEquals(Result.WITH_ICON, send(reconnected))
        assertTrue(inner(first.first()).has(4))
        assertTrue(inner(reconnected.first()).has(4))
    }

    @Test
    fun `dual icon assets map app_icon to 0 and icon to 1 with vector flag`() {
        val frames = mutableListOf<ByteArray>()
        val smallIconBytes = byteArrayOf(9, 8, 7, 6)
        assertEquals(
            Result.WITH_ICON,
            send(
                frames,
                bytes = icon,
                smallIconBytes = smallIconBytes,
                isSmallIconVector = true,
                appName = "QQ",
            ),
        )
        val notification = data(frames)
        assertEquals(0, notification.dataMap["app_icon"])
        assertEquals(1, notification.dataMap["icon"])
        assertEquals(true, notification.dataMap["is_small_icon_vector_drawable"])
        assertEquals("QQ", notification.dataMap["app_name"])

        val appDigest = WcsFrame.messageDigest(icon)
        val smallDigest = WcsFrame.messageDigest(smallIconBytes)
        val refs = inner(frames.last()).nested(9)!!.fields[8]!!.map { Proto.parse(it as ByteArray) }
        assertEquals(2, refs.size)
        assertEquals("0", refs[0].text(1))
        assertEquals(appDigest, refs[0].nested(2)!!.text(4))
        assertEquals("1", refs[1].text(1))
        assertEquals(smallDigest, refs[1].nested(2)!!.text(4))
    }

    @Test
    fun `custom app_name is preserved while blank or null falls back to packageName`() {
        val normalFrames = mutableListOf<ByteArray>()
        assertEquals(Result.WITH_ICON, send(normalFrames, appName = "QQ"))
        assertEquals("QQ", data(normalFrames).dataMap["app_name"])

        val blankFrames = mutableListOf<ByteArray>()
        assertEquals(Result.WITH_ICON, send(blankFrames, appName = "   "))
        assertEquals(identity.packageName, data(blankFrames).dataMap["app_name"])

        val nullFrames = mutableListOf<ByteArray>()
        assertEquals(Result.WITH_ICON, send(nullFrames, appName = null))
        assertEquals(identity.packageName, data(nullFrames).dataMap["app_name"])
    }

    @Test
    fun `when only small_icon is provided it maps to icon at asset 0 without app_icon`() {
        val frames = mutableListOf<ByteArray>()
        val smallBytes = byteArrayOf(1, 2, 3, 4)
        assertEquals(
            Result.WITH_ICON,
            send(frames, bytes = null, smallIconBytes = smallBytes, appName = "WeChat"),
        )
        val notification = data(frames)
        assertFalse(notification.dataMap.containsKey("app_icon"))
        assertEquals(0, notification.dataMap["icon"])
        assertEquals("WeChat", notification.dataMap["app_name"])
    }

    @Test
    fun `when both app_icon and small_icon are provided both assets are mapped`() {
        val frames = mutableListOf<ByteArray>()
        assertEquals(
            Result.WITH_ICON,
            send(frames, bytes = icon, smallIconBytes = icon.copyOf(), appName = "QQ"),
        )
        val notification = data(frames)
        assertEquals(0, notification.dataMap["app_icon"])
        assertEquals(1, notification.dataMap["icon"])
        val refs = inner(frames.last()).nested(9)!!.fields[8]!!.map { Proto.parse(it as ByteArray) }
        assertEquals(2, refs.size)
        assertEquals("0", refs[0].text(1))
        assertEquals("1", refs[1].text(1))
    }
}
