package dev.ricky.galaxywatchmanagerfree.feature

import dev.ricky.galaxywatchmanagerfree.wcs.WcsPaths
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WatchFindControlTest {

    @Test
    fun `connect syncs current state using official flat msg_id payload`() {
        val sent = mutableListOf<JSONObject>()
        val control =
            WatchFindControl(
                send = {
                    sent += JSONObject(it.toString())
                    true
                },
                onStatus = {},
            )

        control.connect()

        assertEquals(1, sent.size)
        val payload = sent.single()
        assertEquals(WcsPaths.MSG_FMW_CURRENT_STATE_REQ, payload.getString("msg_id"))
        assertEquals(0, payload.getInt("connection_type"))
        assertEquals(setOf("msg_id", "connection_type"), payload.keys().asSequence().toSet())
    }

    @Test
    fun `start and stop send only official minimal msg_id frames without extra fields or bogus fmw-find-req`() {
        val sent = mutableListOf<JSONObject>()
        val statuses = mutableListOf<FindWatchStatus>()
        val results = mutableListOf<WatchFindControl.Result>()
        val control =
            WatchFindControl(
                send = {
                    sent += JSONObject(it.toString())
                    true
                },
                onStatus = statuses::add,
                onResult = results::add,
            )

        control.connect()
        sent.clear()

        assertTrue(control.toggle())
        assertEquals(1, sent.size)
        assertEquals(WcsPaths.MSG_FMW_START_ALERT_REQ, sent.single().getString("msg_id"))
        assertEquals(setOf("msg_id"), sent.single().keys().asSequence().toSet())
        assertEquals(listOf(FindWatchStatus.RINGING), statuses)
        assertEquals(listOf(WatchFindControl.Result.STARTED), results)

        sent.clear()
        assertTrue(control.toggle())
        assertEquals(1, sent.size)
        assertEquals(WcsPaths.MSG_FMW_STOP_ALERT_REQ, sent.single().getString("msg_id"))
        assertEquals(setOf("msg_id"), sent.single().keys().asSequence().toSet())
        assertEquals(listOf(FindWatchStatus.RINGING, FindWatchStatus.IDLE), statuses)
        assertEquals(
            listOf(WatchFindControl.Result.STARTED, WatchFindControl.Result.STOPPED),
            results,
        )
    }

    @Test
    fun `send failures revert status and report SEND_FAILED`() {
        var allowSend = true
        var current = FindWatchStatus.IDLE
        val results = mutableListOf<WatchFindControl.Result>()
        val control =
            WatchFindControl(
                send = { allowSend },
                onStatus = { current = it },
                onResult = results::add,
            )

        control.connect()
        allowSend = false
        assertFalse(control.start())
        assertEquals(FindWatchStatus.IDLE, current)
        assertEquals(WatchFindControl.Result.SEND_FAILED, results.last())

        allowSend = true
        assertTrue(control.start())
        assertEquals(FindWatchStatus.RINGING, current)

        allowSend = false
        assertFalse(control.stop())
        assertEquals(FindWatchStatus.RINGING, current)
        assertEquals(WatchFindControl.Result.SEND_FAILED, results.last())
    }

    @Test
    fun `start and stop response rejections revert status and emit reason`() {
        var current = FindWatchStatus.IDLE
        val results = mutableListOf<WatchFindControl.Result>()
        val control =
            WatchFindControl(send = { true }, onStatus = { current = it }, onResult = results::add)

        control.connect()
        control.start()
        control.handleMessage(
            JSONObject()
                .put("msg_id", WcsPaths.MSG_FMW_START_ALERT_RSP)
                .put("result", false)
                .put("reason", "during_call")
        )
        assertEquals(FindWatchStatus.IDLE, current)
        assertEquals(WatchFindControl.Result.START_REJECTED_DURING_CALL, results.last())

        control.start()
        control.handleMessage(
            JSONObject().put("msg_id", WcsPaths.MSG_FMW_START_ALERT_RSP).put("result", false)
        )
        assertEquals(FindWatchStatus.IDLE, current)
        assertEquals(WatchFindControl.Result.START_REJECTED, results.last())

        control.start()
        control.stop()
        assertEquals(FindWatchStatus.IDLE, current)
        control.handleMessage(
            JSONObject().put("msg_id", WcsPaths.MSG_FMW_STOP_ALERT_RSP).put("result", false)
        )
        assertEquals(FindWatchStatus.RINGING, current)
        assertEquals(WatchFindControl.Result.STOP_REJECTED, results.last())
    }

    @Test
    fun `watch finish alert replies with official result boolean and no deviceId`() {
        val sent = mutableListOf<JSONObject>()
        var current = FindWatchStatus.IDLE
        val results = mutableListOf<WatchFindControl.Result>()
        val control =
            WatchFindControl(
                send = {
                    sent += JSONObject(it.toString())
                    true
                },
                onStatus = { current = it },
                onResult = results::add,
            )

        control.connect()
        control.start()
        sent.clear()

        control.handleMessage(
            JSONObject()
                .put("msg_id", WcsPaths.MSG_FMW_FINISH_ALERT_REQ)
                .put("type", "found_device")
        )
        assertEquals(FindWatchStatus.IDLE, current)
        assertEquals(WatchFindControl.Result.FINISHED_BY_WATCH, results.last())
        assertEquals(1, sent.size)
        assertEquals(WcsPaths.MSG_FMW_FINISH_ALERT_RSP, sent.single().getString("msg_id"))
        assertTrue(sent.single().getBoolean("result"))
        assertEquals(setOf("msg_id", "result"), sent.single().keys().asSequence().toSet())

        sent.clear()
        val resultsBeforeIdleFinish = results.size
        control.handleMessage(
            JSONObject().put("msg_id", WcsPaths.MSG_FMW_FINISH_ALERT_REQ).put("type", "time_over")
        )
        assertEquals(resultsBeforeIdleFinish, results.size)
        assertFalse(sent.single().getBoolean("result"))
        assertEquals(setOf("msg_id", "result"), sent.single().keys().asSequence().toSet())
    }

    @Test
    fun `disconnect resets active ringing state to IDLE`() {
        var current = FindWatchStatus.IDLE
        val control = WatchFindControl(send = { true }, onStatus = { current = it })

        control.connect()
        control.start()
        assertEquals(FindWatchStatus.RINGING, current)

        control.disconnect()
        assertEquals(FindWatchStatus.IDLE, current)
        assertFalse(control.start())
    }
}
