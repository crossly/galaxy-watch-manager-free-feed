package dev.ricky.galaxywatchmanagerfree.feature

import dev.ricky.galaxywatchmanagerfree.feature.monitor.BpLog
import dev.ricky.galaxywatchmanagerfree.feature.monitor.BpRecord
import dev.ricky.galaxywatchmanagerfree.feature.monitor.EcgLog
import dev.ricky.galaxywatchmanagerfree.feature.monitor.EcgRecord
import java.io.ByteArrayOutputStream
import java.security.MessageDigest
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.ZonedDateTime
import java.util.Locale
import java.util.zip.ZipInputStream
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class HealthArchiveTest {
    private fun archive(
        snapshot: HealthExportSnapshot,
        exportedAt: Long = 1_790_000_000_000,
        zone: ZoneId = ZoneId.of("Asia/Shanghai"),
    ): Map<String, ByteArray> {
        val output = ByteArrayOutputStream()
        HealthArchive.write(output, snapshot, exportedAt, zone)
        return buildMap {
            ZipInputStream(output.toByteArray().inputStream()).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    put(entry.name, zip.readBytes())
                }
            }
        }
    }

    @Test
    fun `archive exports every ECG sample and independent records with checksums`() {
        val ecg =
            EcgRecord(
                "ecg,\"id",
                1_790_000_000_000,
                75,
                1,
                waveform = floatArrayOf(.125f, -.25f, .5f),
            )
        val state =
            WatchState(
                ecgRecords = listOf(ecg),
                bpRecords = listOf(BpRecord("bp", ecg.startTime, 120, 80, 65)),
            )
        val files =
            archive(
                HealthExportSnapshot(
                    state,
                    JSONObject()
                        .put(
                            "modules",
                            JSONObject()
                                .put("stress", JSONArray().put(JSONObject().put("value", 30))),
                        ),
                )
            )
        val manifest = JSONObject(files.getValue("manifest.json").decodeToString())
        assertEquals(HealthArchive.SCHEMA, manifest.getString("schema"))
        assertEquals("Asia/Shanghai", manifest.getString("time_zone"))
        val listed = manifest.getJSONArray("files")
        assertEquals(files.size - 1, listed.length())
        for (i in 0 until listed.length()) {
            val row = listed.getJSONObject(i)
            val digest =
                MessageDigest.getInstance("SHA-256")
                    .digest(files.getValue(row.getString("path")))
                    .joinToString("") { "%02x".format(it) }
            assertEquals(digest, row.getString("sha256"))
        }
        val metadata = JSONArray(files.getValue("ecg.json").decodeToString()).getJSONObject(0)
        assertEquals(ecg.id, metadata.getString("record_id"))
        assertEquals(3, metadata.getInt("sample_count"))
        val csv =
            files.getValue(metadata.getString("waveform_file")).decodeToString().trim().lines()
        assertEquals(4, csv.size)
        assertTrue(csv.last().contains("0.004"))
        assertTrue(csv.last().contains("0.5"))
        val readings = JSONArray(files.getValue("measurements.json").decodeToString())
        assertEquals(3, readings.length())
        assertEquals("mm[Hg]", readings.getJSONObject(0).getString("unit"))
        assertEquals("bp", readings.getJSONObject(1).getString("record_id"))
        assertTrue(files.getValue("source_records.json").decodeToString().contains("stress"))
    }

    @Test
    fun `archive retains monitor revisions after persistence and rejects stale replay`() {
        val ts = 1_700_000_000_000L
        val bp = BpRecord("bp-revised", ts, 125, 82, 68, updateTime = ts + 200)
        val ecg =
            EcgRecord(
                "ecg-revised",
                ts,
                68,
                1,
                waveform = floatArrayOf(.25f),
                updateTime = ts + 200,
            )
        val savedBp = BpLog.decode(BpLog.encode(listOf(bp)))
        val savedEcg = EcgLog.decode(EcgLog.encode(listOf(ecg)))
        val bpRecords = BpLog.merge(savedBp, listOf(bp.copy(systolic = 140, updateTime = ts + 100)))
        val ecgRecords =
            EcgLog.merge(savedEcg, listOf(ecg.copy(heartRate = 90, updateTime = ts + 100)))
        val files =
            archive(
                HealthExportSnapshot(
                    WatchState(bpRecords = bpRecords, ecgRecords = ecgRecords),
                    JSONObject(),
                    retainedCache =
                        JSONObject()
                            .put("bp_records", BpLog.encode(bpRecords))
                            .put("ecg_records", EcgLog.encode(ecgRecords)),
                )
            )
        val cache = JSONObject(files.getValue("retained_cache.json").decodeToString())
        assertEquals(bp, BpLog.decode(cache.getString("bp_records")).single())
        assertEquals(ecg, EcgLog.decode(cache.getString("ecg_records")).single())
        assertEquals(
            125,
            JSONArray(files.getValue("blood_pressure.json").decodeToString())
                .getJSONObject(0)
                .getInt("systolic_mmHg"),
        )
        assertEquals(
            68,
            JSONArray(files.getValue("ecg.json").decodeToString())
                .getJSONObject(0)
                .getInt("average_heart_rate_bpm"),
        )
        val manifest = JSONObject(files.getValue("manifest.json").decodeToString())
        val datasets = manifest.getJSONObject("datasets")
        assertEquals(HealthArchive.SCHEMA, manifest.getString("schema"))
        assertEquals(1, datasets.getJSONObject("blood_pressure.json").getInt("record_count"))
        assertEquals(1, datasets.getJSONObject("ecg.json").getInt("record_count"))
    }

    @Test
    fun `archive excludes overlapping naps from merged sleep but retains every manual entry`() {
        val ts = 1_700_000_000_000L
        val watch =
            SleepParser.manualSession(SleepParser.ManualNap(ts, ts + 3_600_000))
                .copy(id = "watch-sleep", analysisSource = null)
        val overlap = SleepParser.ManualNap(ts + 600_000, ts + 1_800_000)
        val separate = SleepParser.ManualNap(ts + 7_200_000, ts + 9_000_000)
        val files =
            archive(
                HealthExportSnapshot(
                    WatchState(sleep = watch, sleepSessions = listOf(watch)),
                    JSONObject(),
                    manualNaps = listOf(overlap, separate),
                )
            )
        val sessions = JSONArray(files.getValue("sleep_sessions.json").decodeToString())
        val manual = JSONArray(files.getValue("manual_naps.json").decodeToString())
        assertEquals(
            setOf(watch.id, SleepParser.manualSession(separate).id),
            (0 until sessions.length())
                .map { sessions.getJSONObject(it).getString("record_id") }
                .toSet(),
        )
        assertEquals(
            setOf(SleepParser.manualSession(overlap).id, SleepParser.manualSession(separate).id),
            (0 until manual.length())
                .map { manual.getJSONObject(it).getString("record_id") }
                .toSet(),
        )
        val datasets =
            JSONObject(files.getValue("manifest.json").decodeToString()).getJSONObject("datasets")
        assertEquals(2, datasets.getJSONObject("sleep_sessions.json").getInt("record_count"))
        assertEquals(2, datasets.getJSONObject("manual_naps.json").getInt("record_count"))
        assertEquals(
            Instant.ofEpochMilli(ts).toString(),
            datasets.getJSONObject("sleep_sessions.json").getString("first_start_time"),
        )
    }

    @Test
    fun `numeric exports use dots independently of UI locale and unknowns remain null`() {
        val previous = Locale.getDefault()
        try {
            Locale.setDefault(Locale.GERMAN)
            val ecg = EcgRecord("id", 1_790_000_000_000, -1, 3, waveform = floatArrayOf(.125f))
            val files =
                archive(HealthExportSnapshot(WatchState(ecgRecords = listOf(ecg)), JSONObject()))
            assertTrue(files.getValue("ecg/record-1.csv").decodeToString().contains("0.125"))
            assertTrue(
                JSONObject(files.getValue("snapshot.json").decodeToString()).isNull("today_steps")
            )
            assertTrue(
                JSONArray(files.getValue("ecg.json").decodeToString())
                    .getJSONObject(0)
                    .isNull("average_heart_rate_bpm")
            )
        } finally {
            Locale.setDefault(previous)
        }
    }

    @Test
    fun `historical sleep and manual naps are exported beyond the latest displayed day`() {
        val old =
            SleepParser.manualSession(SleepParser.ManualNap(1_788_000_000_000, 1_788_003_600_000))
        val recent =
            SleepParser.manualSession(SleepParser.ManualNap(1_789_000_000_000, 1_789_003_600_000))
        val files =
            archive(
                HealthExportSnapshot(
                    WatchState(
                        sleep = recent,
                        sleepSessions = listOf(recent),
                        allSleepSessions = listOf(old, recent),
                    ),
                    JSONObject(),
                )
            )
        val sessions = JSONArray(files.getValue("sleep_sessions.json").decodeToString())
        assertEquals(2, sessions.length())
        assertEquals(old.id, sessions.getJSONObject(0).getString("record_id"))
        assertEquals("manual", sessions.getJSONObject(0).getString("source"))
    }

    @Test
    fun `normalization includes retained history outside display windows and preserves both HRV algorithms`() {
        val ts = 1_788_000_000_000L
        val modules =
            JSONObject()
                .put(
                    HeartRateLog.MODULE,
                    JSONArray()
                        .put(
                            JSONObject()
                                .put("datauuid", "heart-old")
                                .put("start_time", ts)
                                .put("heart_rate", 67)
                        ),
                )
                .put(
                    HealthMetric.HRV.moduleKeys.first(),
                    JSONArray()
                        .put(
                            JSONObject()
                                .put("datauuid", "hrv-old")
                                .put("start_time", ts)
                                .put("update_time", ts + 100)
                                .put("rmssd", 28.5)
                                .put("sdnn", 42.5)
                        ),
                )
        val files =
            archive(HealthExportSnapshot(WatchState(), JSONObject().put("modules", modules)))
        val rows = JSONArray(files.getValue("measurements.json").decodeToString())
        assertEquals(3, rows.length())
        val hrv =
            (0 until rows.length()).map(rows::getJSONObject).filter {
                it.getString("type") == "heart_rate_variability"
            }
        assertEquals(setOf("rmssd", "sdnn"), hrv.map { it.getString("method") }.toSet())
        assertEquals(2, hrv.map { it.getString("record_id") }.toSet().size)
        assertEquals(setOf(28.5, 42.5), hrv.map { it.getDouble("value") }.toSet())
        assertTrue(hrv.all { it.getLong("source_revision_epoch_ms") == ts + 100 })
    }

    @Test
    fun `alias revisions replace whole records before projecting samples and workouts`() {
        val ts = 1_700_000_000_000L
        val oldMetric =
            JSONObject()
                .put("datauuid", "revised-hrv")
                .put("start_time", ts)
                .put("update_time", ts + 1)
                .put(
                    "binning_data",
                    JSONArray()
                        .put(JSONObject().put("start_time", ts).put("rmssd", 20).put("sdnn", 40)),
                )
        val newMetric =
            JSONObject(oldMetric.toString())
                .put("update_time", ts + 2)
                .put(
                    "binning_data",
                    JSONArray().put(JSONObject().put("start_time", ts + 60_000).put("rmssd", 30)),
                )
        val oldWorkout =
            JSONObject()
                .put("datauuid", "revised-workout")
                .put("start_time", ts)
                .put("end_time", ts + 3_600_000)
                .put("update_time", ts + 1)
                .put("exercise_type", 1001)
                .put("calorie", 90)
        val newWorkout =
            JSONObject(oldWorkout.toString()).put("update_time", ts + 2).put("calorie", 100)
        val modules =
            JSONObject()
                .put(HealthMetric.HRV.moduleKeys[0], JSONArray().put(newMetric))
                .put(HealthMetric.HRV.moduleKeys[1], JSONArray().put(oldMetric))
                .put(ExerciseLog.MODULE, JSONArray().put(newWorkout))
                .put(ExerciseLog.MODULE_ALIAS, JSONArray().put(oldWorkout))
        val files =
            archive(HealthExportSnapshot(WatchState(), JSONObject().put("modules", modules)))
        val rows = JSONArray(files.getValue("measurements.json").decodeToString())
        assertEquals(1, rows.length())
        assertEquals(ts + 60_000, rows.getJSONObject(0).getLong("start_time_epoch_ms"))
        val workout = JSONArray(files.getValue("workouts.json").decodeToString()).getJSONObject(0)
        assertEquals(100, workout.getInt("energy_kcal"))
        assertEquals(ts + 2, workout.getLong("source_revision_epoch_ms"))
        assertEquals(ExerciseLog.MODULE, workout.getString("source_module"))
        val rawModules =
            JSONObject(files.getValue("source_records.json").decodeToString())
                .getJSONObject("modules")
        assertTrue(rawModules.has(HealthMetric.HRV.moduleKeys[1]))
        assertTrue(rawModules.has(ExerciseLog.MODULE_ALIAS))
    }

    @Test
    fun `actual store archive keeps alias revisions real dates unknown floors and long history`() {
        val zone = ZoneId.of("Asia/Shanghai")
        val exportedAt = Instant.parse("2026-11-10T12:00:00Z").toEpochMilli()
        fun at(day: String, hour: Int): Long =
            ZonedDateTime.of(LocalDate.parse(day), java.time.LocalTime.of(hour, 0), zone)
                .toInstant()
                .toEpochMilli()

        val oldMetric =
            JSONObject()
                .put("com.samsung.health.hrv.datauuid", "archive-revised")
                .put("com.samsung.health.hrv.start_time", at("2026-10-20", 8))
                .put("com.samsung.health.hrv.update_time", at("2026-10-20", 8) + 1)
                .put(
                    "binning_data",
                    JSONArray()
                        .put(JSONObject().put("start_time", at("2026-10-20", 8)).put("rmssd", 20))
                        .put(
                            JSONObject()
                                .put("start_time", at("2026-10-20", 8) + 600_000)
                                .put("rmssd", 25)
                        ),
                )
        val newMetric =
            JSONObject()
                .put("datauuid", "archive-revised")
                .put("start_time", at("2026-10-20", 8))
                .put("update_time", at("2026-10-20", 8) + 2)
                .put(
                    "binning_data",
                    JSONArray()
                        .put(
                            JSONObject()
                                .put("start_time", at("2026-10-20", 8) + 600_000)
                                .put("rmssd", 30)
                        ),
                )
        val oldHeart =
            JSONObject()
                .put("datauuid", "archive-old-heart")
                .put("start_time", at("2026-10-21", 9))
                .put("heart_rate", 67)
        val yesterdaySummary =
            JSONObject()
                .put("datauuid", "archive-yesterday")
                .put("day_time", 20261108)
                .put("update_time", exportedAt - 3_600_000)
                .put("step_count", 1111)
        val todaySummary =
            JSONObject()
                .put("datauuid", "archive-today")
                .put("day_time", 20261109)
                .put("update_time", exportedAt - 1_800_000)
                .put("step_count", 2222)
                .put("calorie", 100)
                .put("distance", 1400)
        val floors =
            JSONArray()
                .put(
                    JSONObject()
                        .put("datauuid", "archive-floors-zero")
                        .put("start_time", at("2026-11-09", 10))
                        .put("floor_count", 0)
                )
                .put(
                    JSONObject()
                        .put("datauuid", "archive-floors-unknown")
                        .put("start_time", at("2026-11-09", 11))
                )
        val store = HealthRecordStore()
        store.merge(
            mapOf(
                HealthMetric.HRV.moduleKeys[0] to listOf(newMetric),
                HealthMetric.HRV.moduleKeys[1] to listOf(oldMetric),
                HeartRateLog.MODULE to listOf(oldHeart),
                HealthStepParser.MODULE_DAY_SUMMARY to listOf(yesterdaySummary, todaySummary),
                "com.samsung.shealth.floors_climbed" to
                    listOf(floors.getJSONObject(0), floors.getJSONObject(1)),
            ),
            exportedAt,
        )

        val files =
            archive(
                HealthExportSnapshot(WatchState(), JSONObject(store.encode())),
                exportedAt,
                zone,
            )
        val measurements = JSONArray(files.getValue("measurements.json").decodeToString())
        val hrv =
            (0 until measurements.length()).map(measurements::getJSONObject).filter {
                it.getString("type") == "heart_rate_variability"
            }
        assertEquals(1, hrv.size)
        assertEquals(30.0, hrv.single().getDouble("value"), 0.0)
        assertEquals("archive-revised", hrv.single().getString("source_record_id"))
        assertEquals(HealthMetric.HRV.moduleKeys[0], hrv.single().getString("source_module"))
        assertEquals(at("2026-10-20", 8) + 2, hrv.single().getLong("source_revision_epoch_ms"))
        assertEquals(at("2026-10-20", 8) + 600_000, hrv.single().getLong("start_time_epoch_ms"))
        assertTrue(
            (0 until measurements.length()).map(measurements::getJSONObject).any {
                it.getString("type") == "heart_rate" && it.getInt("value") == 67
            }
        )
        val daily =
            JSONArray(files.getValue("daily_activity.json").decodeToString()).let { rows ->
                (0 until rows.length()).associate {
                    rows.getJSONObject(it).getString("local_date") to rows.getJSONObject(it)
                }
            }
        assertEquals(1111, daily.getValue("2026-11-08").getInt("steps"))
        assertEquals(2222, daily.getValue("2026-11-09").getInt("steps"))
        val exportedFloors = JSONArray(files.getValue("floors.json").decodeToString())
        assertEquals(0, exportedFloors.getJSONObject(0).getInt("floors"))
        assertTrue(exportedFloors.getJSONObject(1).isNull("floors"))
        val rawModules =
            JSONObject(files.getValue("source_records.json").decodeToString())
                .getJSONObject("modules")
        val rawOld = rawModules.getJSONArray(HealthMetric.HRV.moduleKeys[1]).getJSONObject(0)
        assertEquals(2, rawOld.getJSONArray("binning_data").length())
        assertTrue(rawOld.has("com.samsung.health.hrv.update_time"))
        assertEquals(1, rawModules.getJSONArray(HealthMetric.HRV.moduleKeys[0]).length())
        val manifest = JSONObject(files.getValue("manifest.json").decodeToString())
        assertEquals(HealthArchive.SCHEMA, manifest.getString("schema"))
        val datasets = manifest.getJSONObject("datasets")
        assertEquals(7, datasets.getJSONObject("source_records.json").getInt("record_count"))
        assertEquals(2, datasets.getJSONObject("measurements.json").getInt("record_count"))
        assertEquals(
            "2026-11-08",
            datasets.getJSONObject("daily_activity.json").getString("first_local_date"),
        )
        assertEquals(
            "2026-11-09",
            datasets.getJSONObject("daily_activity.json").getString("last_local_date"),
        )
    }

    @Test
    fun `long form HRV fields preserve both algorithms`() {
        val row =
            JSONObject()
                .put("datauuid", "long-hrv")
                .put("start_time", 1_700_000_000_000L)
                .put("com.samsung.health.hrv.rmssd", 25)
                .put("com.samsung.health.hrv.sdnn", 40)
        val modules = JSONObject().put(HealthMetric.HRV.moduleKeys.first(), JSONArray().put(row))
        val files =
            archive(HealthExportSnapshot(WatchState(), JSONObject().put("modules", modules)))
        val rows = JSONArray(files.getValue("measurements.json").decodeToString())
        assertEquals(
            setOf("rmssd", "sdnn"),
            (0 until rows.length()).map { rows.getJSONObject(it).getString("method") }.toSet(),
        )
    }

    @Test
    fun `daily heart statistics keep the measured date across a disconnected midnight`() {
        val stats = HeartRateLog.Stats(60, 100, 80, 5)
        val state =
            WatchState(
                heartRateDays = mapOf("2026-11-08" to stats),
                heartRateWeek = List(6) { null } + stats,
                todaySteps = 1234,
            )
        val cache = JSONObject().put("day", "2026-11-08")
        val files =
            archive(
                HealthExportSnapshot(state, JSONObject(), cache),
                java.time.Instant.parse("2026-11-09T12:00:00Z").toEpochMilli(),
                ZoneId.of("UTC"),
            )
        val rows = JSONArray(files.getValue("heart_rate_daily.json").decodeToString())
        assertEquals("2026-11-08", rows.getJSONObject(0).getString("local_date"))
        val snapshot = JSONObject(files.getValue("snapshot.json").decodeToString())
        assertEquals("2026-11-08", snapshot.getString("data_local_date"))
        assertTrue(snapshot.isNull("today_steps"))
        assertEquals(1234, snapshot.getInt("data_day_steps"))
    }

    @Test
    fun `workout unknowns stay null and routine children keep full details`() {
        val parent =
            ExerciseLog.Session(
                "routine",
                51005,
                1_789_000_000_000,
                1_789_003_600_000,
                60,
                -1,
                -1.0,
                -1,
                -1,
            )
        val child =
            parent.copy(
                id = "child",
                typeCode = 1001,
                routineId = "routine",
                title = "Synthetic workout",
                count = 12,
                countType = 30002,
                minHeartRate = 60,
                meanSpeed = 2.5,
                maxSpeed = 3.5,
                altitudeGain = 0.0,
                altitudeLoss = 2.0,
            )
        val files =
            archive(
                HealthExportSnapshot(WatchState(exercises = listOf(parent, child)), JSONObject())
            )
        val rows = JSONArray(files.getValue("workouts.json").decodeToString())
        val missing = rows.getJSONObject(0)
        assertTrue(missing.isNull("distance_m"))
        assertTrue(missing.isNull("energy_kcal"))
        val row = rows.getJSONObject(1)
        assertEquals("routine", row.getString("routine_id"))
        assertEquals(12, row.getInt("count"))
        assertEquals(60, row.getInt("min_heart_rate_bpm"))
        assertEquals(2.5, row.getDouble("mean_speed_m_per_s"), 0.0)
        assertEquals(0.0, row.getDouble("altitude_gain_m"), 0.0)
        assertFalse(row.getBoolean("is_top_level"))
    }

    @Test
    fun `route export retains history revisions aliases missing values and valid zeroes`() {
        val zone = ZoneId.of("Asia/Shanghai")
        val exportedAt = Instant.parse("2026-11-16T12:00:00Z").toEpochMilli()
        fun at(day: String, hour: Int): Long =
            ZonedDateTime.of(LocalDate.parse(day), java.time.LocalTime.of(hour, 0), zone)
                .toInstant()
                .toEpochMilli()
        fun point(
            latitude: Double,
            longitude: Double,
            time: Long? = null,
            extra: JSONObject.() -> Unit = {},
        ): JSONObject =
            JSONObject().put("latitude", latitude).put("longitude", longitude).apply {
                if (time != null) put("start_time", time)
                extra()
            }
        fun exercise(
            id: String,
            start: Long,
            end: Long,
            updateTime: Long,
            points: JSONArray? = null,
        ): JSONObject =
            JSONObject()
                .put("datauuid", id)
                .put("start_time", start)
                .put("end_time", end)
                .put("update_time", updateTime)
                .put("exercise_type", 1001)
                .apply { if (points != null) put("location_data", points) }

        val oldStart = at("2025-01-05", 7)
        val revisionStart = at("2026-11-01", 8)
        val unsupportedStart = at("2026-11-02", 9)
        val invalidStart = at("2026-11-03", 10)
        val oldRoute =
            JSONObject()
                .put("com.samsung.health.exercise.datauuid", "route-old")
                .put("com.samsung.health.exercise.start_time", oldStart)
                .put("com.samsung.health.exercise.end_time", oldStart + 3_600_000)
                .put("com.samsung.health.exercise.update_time", oldStart + 10)
                .put("com.samsung.health.exercise.exercise_type", 1001)
                .put(
                    "location_data",
                    JSONArray()
                        .put(
                            point(30.0, 110.0, oldStart) {
                                put("accuracy", 0)
                                put("altitude", -15.5)
                                put("elapsed_time", 0)
                                put("segment", 0)
                                put("version", 2)
                                put("interval", 0)
                                put("source_type", 0)
                            }
                        )
                        .put(point(30.001, 110.001, oldStart + 1000)),
                )
        val revisionOld =
            exercise(
                "route-revised",
                revisionStart,
                revisionStart + 3_600_000,
                revisionStart + 1,
                JSONArray().put(point(30.1, 110.1, revisionStart)),
            )
        val revisionNew =
            exercise(
                "route-revised",
                revisionStart,
                revisionStart + 3_600_000,
                revisionStart + 2,
                JSONArray()
                    .put(point(31.0, 110.0, revisionStart))
                    .put(point(0.0, 0.0, revisionStart + 1000))
                    .put(point(31.002, 110.002, revisionStart + 2000) { put("segment", 1) }),
            )
        val unsupported =
            exercise(
                    "route-unsupported",
                    unsupportedStart,
                    unsupportedStart + 3_600_000,
                    unsupportedStart + 1,
                )
                .put("location_data", "not-a-location-payload")
        val invalid =
            exercise(
                "route-invalid",
                invalidStart,
                invalidStart + 3_600_000,
                invalidStart + 1,
                JSONArray().put(point(0.0, 0.0, invalidStart)).put(point(91.0, 110.0, invalidStart)),
            )
        val noPayload =
            exercise(
                "route-none",
                invalidStart + 86_400_000,
                invalidStart + 90_000_000,
                invalidStart + 86_400_001,
            )
        val store = HealthRecordStore()
        store.merge(
            mapOf(
                ExerciseLog.MODULE to
                    listOf(oldRoute, revisionNew, unsupported, invalid, noPayload),
                ExerciseLog.MODULE_ALIAS to listOf(revisionOld),
            ),
            exportedAt,
        )

        val files =
            archive(
                HealthExportSnapshot(WatchState(), JSONObject(store.encode())),
                exportedAt,
                zone,
            )
        val routes = JSONArray(files.getValue("workout_routes.json").decodeToString())
        val byId =
            (0 until routes.length()).map(routes::getJSONObject).associateBy {
                it.getString("record_id")
            }
        assertEquals(
            setOf("route-old", "route-revised", "route-unsupported", "route-invalid"),
            byId.keys,
        )

        val old = byId.getValue("route-old")
        assertEquals(ExerciseLog.MODULE, old.getString("source_module"))
        assertEquals(oldStart + 10, old.getLong("source_revision_epoch_ms"))
        assertEquals("location_data", old.getString("source_field"))
        assertEquals("parsed", old.getString("status"))
        assertEquals(2, old.getInt("source_point_count"))
        assertEquals(2, old.getInt("point_count"))
        assertEquals(2, old.getInt("segment_count"))
        assertEquals("unknown", old.getString("coordinate_reference_system"))
        assertTrue(old.isNull("coordinate_transform"))
        assertEquals("source_continuity_v1", old.getString("segmentation_algorithm"))
        val oldPoints = old.getJSONArray("points")
        val zero = oldPoints.getJSONObject(0)
        assertEquals(0, zero.getInt("source_index"))
        assertEquals(0.0, zero.getDouble("accuracy_m"), 0.0)
        assertEquals(-15.5, zero.getDouble("altitude_m"), 0.0)
        assertEquals(0L, zero.getLong("elapsed_time_ms"))
        assertEquals(0, zero.getInt("segment"))
        assertEquals(2, zero.getInt("version"))
        assertEquals(0, zero.getInt("interval"))
        assertEquals(0, zero.getInt("source_type"))
        assertEquals(0, zero.getInt("display_segment_index"))
        val missing = oldPoints.getJSONObject(1)
        assertTrue(missing.isNull("accuracy_m"))
        assertTrue(missing.isNull("altitude_m"))
        assertTrue(missing.isNull("elapsed_time_ms"))
        assertTrue(missing.isNull("segment"))
        assertTrue(missing.isNull("version"))
        assertTrue(missing.isNull("interval"))
        assertTrue(missing.isNull("source_type"))
        assertEquals(1, missing.getInt("display_segment_index"))

        val revised = byId.getValue("route-revised")
        assertEquals(ExerciseLog.MODULE, revised.getString("source_module"))
        assertEquals(revisionStart + 2, revised.getLong("source_revision_epoch_ms"))
        assertEquals(3, revised.getInt("source_point_count"))
        assertEquals(2, revised.getInt("point_count"))
        assertEquals(2, revised.getInt("segment_count"))
        val revisedPoints = revised.getJSONArray("points")
        assertEquals(
            listOf(0, 2),
            (0 until revisedPoints.length()).map {
                revisedPoints.getJSONObject(it).getInt("source_index")
            },
        )
        assertEquals(
            listOf(0, 1),
            (0 until revisedPoints.length()).map {
                revisedPoints.getJSONObject(it).getInt("display_segment_index")
            },
        )
        assertEquals(
            setOf(31.0, 31.002),
            (0 until revisedPoints.length())
                .map { revisedPoints.getJSONObject(it).getDouble("latitude") }
                .toSet(),
        )

        assertEquals("unsupported", byId.getValue("route-unsupported").getString("status"))
        assertTrue(byId.getValue("route-unsupported").isNull("source_point_count"))
        assertEquals(0, byId.getValue("route-unsupported").getInt("point_count"))
        assertEquals("no_valid_points", byId.getValue("route-invalid").getString("status"))
        assertEquals(2, byId.getValue("route-invalid").getInt("source_point_count"))
        assertEquals(0, byId.getValue("route-invalid").getInt("point_count"))

        val workoutRows = JSONArray(files.getValue("workouts.json").decodeToString())
        val workouts =
            (0 until workoutRows.length()).map(workoutRows::getJSONObject).associateBy {
                it.getString("record_id")
            }
        assertFalse(workouts.getValue("route-none").getBoolean("location_payload_present"))
        assertTrue(workouts.getValue("route-revised").getBoolean("location_payload_present"))
        assertEquals(2, workouts.getValue("route-revised").getInt("location_point_count"))

        val rawAlias =
            JSONObject(files.getValue("source_records.json").decodeToString())
                .getJSONObject("modules")
                .getJSONArray(ExerciseLog.MODULE_ALIAS)
                .getJSONObject(0)
        assertEquals(
            30.1,
            rawAlias.getJSONArray("location_data").getJSONObject(0).getDouble("latitude"),
            0.0,
        )

        val manifest = JSONObject(files.getValue("manifest.json").decodeToString())
        assertEquals(4, manifest.getInt("workout_route_count"))
        assertEquals(4, manifest.getInt("workout_route_point_count"))
        assertEquals(4, manifest.getInt("workout_route_segment_count"))
        assertEquals("retained_raw_location_payloads", manifest.getString("workout_route_coverage"))
        val routeDataset = manifest.getJSONObject("datasets").getJSONObject("workout_routes.json")
        assertEquals(4, routeDataset.getInt("record_count"))
        assertEquals(HealthExportData.time(oldStart), routeDataset.getString("first_start_time"))
        assertEquals(HealthExportData.time(invalidStart), routeDataset.getString("last_end_time"))

        val schema = JSONObject(files.getValue("schema.json").decodeToString())
        assertEquals("urn:galaxy-watch-manager-free:health:v7", schema.getString("\$id"))
        assertEquals("Health archive v7 records", schema.getString("title"))
        assertEquals(
            "#/\$defs/workout_routes",
            schema.getJSONObject("files").getString("workout_routes.json"),
        )
        val listed =
            (0 until manifest.getJSONArray("files").length()).map {
                manifest.getJSONArray("files").getJSONObject(it)
            }
        val routeEntry = listed.first { it.getString("path") == "workout_routes.json" }
        assertEquals(
            MessageDigest.getInstance("SHA-256")
                .digest(files.getValue("workout_routes.json"))
                .joinToString("") { "%02x".format(it) },
            routeEntry.getString("sha256"),
        )
    }

    @Test
    fun `energy score export keeps all retained history ack metadata and official rows`() {
        val zone = ZoneId.of("America/New_York")
        val exportedAt = Instant.parse("2026-11-18T12:00:00Z").toEpochMilli()
        val older =
            EnergyScoreLog.Record(
                id = "energy-old",
                date = "2024-03-05",
                zoneId = "Asia/Shanghai",
                algorithm = "energy_score_v1",
                createdAt = 1_709_600_000_000,
                updatedAt = 1_709_600_000_500,
                deviceUuid = "synthetic-device",
                values =
                    JSONObject()
                        .put("total_score", 61.5)
                        .put("recovery_score", JSONObject.NULL)
                        .put("hrv_rmssd_ms", JSONObject.NULL)
                        .put("diagnostic_bucket", "synthetic")
                        .toString(),
                inputs =
                    JSONObject()
                        .put("sleep_minutes", 402.0)
                        .put("hrv_rmssd_ms", JSONObject.NULL)
                        .put("resting_heart_rate_bpm", 54.0)
                        .toString(),
            )
        val acceptedAt = 1_795_086_401_000L
        val recent =
            EnergyScoreLog.Record(
                id = "energy-recent",
                date = "2026-11-17",
                zoneId = "Asia/Shanghai",
                algorithm = "energy_score_v2",
                createdAt = 1_795_000_000_000,
                updatedAt = 1_795_086_400_000,
                deviceUuid = "synthetic-device",
                values =
                    JSONObject()
                        .put("total_score", 82.0)
                        .put("recovery_score", 74.0)
                        .put("hrv_rmssd_ms", 38.5)
                        .toString(),
                inputs =
                    JSONObject()
                        .put("sleep_minutes", 455.0)
                        .put("hrv_rmssd_ms", 38.5)
                        .put("resting_heart_rate_bpm", 51.0)
                        .toString(),
                acceptedRevision = 1_795_086_400_000,
                acceptedAt = acceptedAt,
            )
        val files =
            archive(
                HealthExportSnapshot(
                    WatchState(),
                    JSONObject(),
                    energyProfile = EnergyScoreProfile(42, false),
                    energyScores = listOf(older, recent),
                ),
                exportedAt,
                zone,
            )
        val scores = JSONArray(files.getValue("energy_scores.json").decodeToString())
        assertEquals(2, scores.length())
        val old = scores.getJSONObject(0)
        assertEquals("energy-old", old.getString("record_id"))
        assertEquals("2024-03-05", old.getString("date"))
        assertEquals("Asia/Shanghai", old.getString("time_zone"))
        assertEquals("phone_computed", old.getString("source"))
        assertEquals("energy_score_v1", old.getString("algorithm"))
        assertEquals("synthetic-device", old.getString("device_uuid"))
        assertEquals(1_709_600_000_000, old.getLong("created_at_epoch_ms"))
        assertEquals(1_709_600_000_500, old.getLong("updated_at_epoch_ms"))
        assertEquals(61.5, old.getJSONObject("values").getDouble("total_score"), 0.0)
        assertTrue(old.getJSONObject("values").isNull("recovery_score"))
        assertTrue(old.getJSONObject("values").isNull("hrv_rmssd_ms"))
        assertTrue(old.getJSONObject("inputs").isNull("hrv_rmssd_ms"))
        assertTrue(old.isNull("watch_accepted_revision_epoch_ms"))
        assertTrue(old.isNull("watch_accepted_at_epoch_ms"))
        assertTrue(old.isNull("watch_persistence_verified"))
        val recentJson = scores.getJSONObject(1)
        assertEquals("energy_score_v2", recentJson.getString("algorithm"))
        assertEquals(1_795_086_400_000, recentJson.getLong("watch_accepted_revision_epoch_ms"))
        assertEquals(acceptedAt, recentJson.getLong("watch_accepted_at_epoch_ms"))
        assertTrue(recentJson.isNull("watch_persistence_verified"))
        assertEquals(38.5, recentJson.getJSONObject("inputs").getDouble("hrv_rmssd_ms"), 0.0)

        val profile = JSONArray(files.getValue("energy_profile.json").decodeToString())
        assertEquals(1, profile.length())
        assertEquals(42, profile.getJSONObject(0).getInt("age"))
        assertEquals("M", profile.getJSONObject(0).getString("sex"))
        assertEquals("user_entered", profile.getJSONObject(0).getString("source"))

        val rows = JSONArray(files.getValue("energy_score_rows.json").decodeToString())
        assertEquals(2, rows.length())
        val oldRow = rows.getJSONObject(0)
        assertEquals(4, oldRow.getInt("data_version"))
        assertEquals("energy-old", oldRow.getString("datauuid"))
        assertEquals("synthetic-device", oldRow.getString("deviceuuid"))
        assertEquals("dev.ricky.galaxywatchmanagerfree", oldRow.getString("pkg_name"))
        assertEquals(1_709_600_000_000, oldRow.getLong("create_time"))
        assertEquals(1_709_600_000_500, oldRow.getLong("update_time"))
        assertEquals(
            LocalDate.parse("2024-03-05").atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli(),
            oldRow.getLong("day_time"),
        )
        assertEquals(61.5, oldRow.getDouble("total_score"), 0.0)
        assertTrue(oldRow.isNull("recovery_score"))
        assertTrue(oldRow.isNull("hrv_rmssd_ms"))
        assertEquals("synthetic", oldRow.getString("diagnostic_bucket"))

        val manifest = JSONObject(files.getValue("manifest.json").decodeToString())
        assertEquals(2, manifest.getInt("energy_score_count"))
        assertEquals("all_retained_phone_computed", manifest.getString("energy_score_coverage"))
        assertEquals(1, manifest.getInt("energy_profile_count"))
        assertEquals("current_device_user_entered", manifest.getString("energy_profile_coverage"))
        assertEquals("all_retained", manifest.getJSONObject("retention").getString("energy_scores"))
        assertEquals(
            "current_value_only",
            manifest.getJSONObject("retention").getString("energy_profile"),
        )
        listOf("energy_scores.json", "energy_score_rows.json").forEach { path ->
            val dataset = manifest.getJSONObject("datasets").getJSONObject(path)
            assertEquals("$path record count", 2, dataset.getInt("record_count"))
            assertEquals("$path first date", "2024-03-05", dataset.getString("first_local_date"))
            assertEquals("$path last date", "2026-11-17", dataset.getString("last_local_date"))
            val entry =
                (0 until manifest.getJSONArray("files").length())
                    .map { manifest.getJSONArray("files").getJSONObject(it) }
                    .first { it.getString("path") == path }
            assertEquals(
                "$path sha256",
                MessageDigest.getInstance("SHA-256").digest(files.getValue(path)).joinToString("") {
                    "%02x".format(it)
                },
                entry.getString("sha256"),
            )
        }

        val schema = JSONObject(files.getValue("schema.json").decodeToString())
        assertEquals("urn:galaxy-watch-manager-free:health:v7", schema.getString("\$id"))
        assertEquals("Health archive v7 records", schema.getString("title"))
        assertEquals(
            "#/\$defs/energy_scores",
            schema.getJSONObject("files").getString("energy_scores.json"),
        )
        assertEquals(
            "#/\$defs/energy_score_rows",
            schema.getJSONObject("files").getString("energy_score_rows.json"),
        )
        assertEquals(
            "#/\$defs/energy_profile",
            schema.getJSONObject("files").getString("energy_profile.json"),
        )
        val definitions = schema.getJSONObject("\$defs")
        val recordProperties =
            definitions
                .getJSONObject("energy_scores")
                .getJSONObject("items")
                .getJSONObject("properties")
        assertEquals("phone_computed", recordProperties.getJSONObject("source").getString("const"))
        listOf(
                "algorithm",
                "values",
                "inputs",
                "watch_accepted_revision_epoch_ms",
                "watch_accepted_at_epoch_ms",
                "watch_persistence_verified",
            )
            .forEach { name -> assertTrue(name, recordProperties.has(name)) }
        val rowDefinition = definitions.getJSONObject("energy_score_rows").getJSONObject("items")
        assertTrue(rowDefinition.getBoolean("additionalProperties"))
        listOf(
                "data_version",
                "day_time",
                "datauuid",
                "deviceuuid",
                "pkg_name",
                "create_time",
                "update_time",
            )
            .forEach { name ->
                assertTrue(name, rowDefinition.getJSONObject("properties").has(name))
            }
        val profileDefinition = definitions.getJSONObject("energy_profile").getJSONObject("items")
        assertEquals(
            18,
            profileDefinition.getJSONObject("properties").getJSONObject("age").getInt("minimum"),
        )
        assertEquals(
            99,
            profileDefinition.getJSONObject("properties").getJSONObject("age").getInt("maximum"),
        )
    }

    @Test
    fun `saved energy profile exports before any score can be calculated`() {
        val files =
            archive(
                HealthExportSnapshot(
                    WatchState(),
                    JSONObject(),
                    energyProfile = EnergyScoreProfile(30, true),
                )
            )
        val profiles = JSONArray(files.getValue("energy_profile.json").decodeToString())
        assertEquals(1, profiles.length())
        assertEquals(30, profiles.getJSONObject(0).getInt("age"))
        assertEquals("F", profiles.getJSONObject(0).getString("sex"))
        assertEquals("user_entered", profiles.getJSONObject(0).getString("source"))
        assertEquals(0, JSONArray(files.getValue("energy_scores.json").decodeToString()).length())
        val manifest = JSONObject(files.getValue("manifest.json").decodeToString())
        assertEquals(HealthArchive.SCHEMA, manifest.getString("schema"))
        assertEquals(1, manifest.getInt("energy_profile_count"))
        assertEquals(0, manifest.getInt("energy_score_count"))
        assertEquals(
            1,
            manifest
                .getJSONObject("datasets")
                .getJSONObject("energy_profile.json")
                .getInt("record_count"),
        )
        val entry =
            (0 until manifest.getJSONArray("files").length())
                .map { manifest.getJSONArray("files").getJSONObject(it) }
                .single { it.getString("path") == "energy_profile.json" }
        assertEquals(
            MessageDigest.getInstance("SHA-256")
                .digest(files.getValue("energy_profile.json"))
                .joinToString("") { "%02x".format(it) },
            entry.getString("sha256"),
        )
    }

    @Test
    fun `energy profile export is explicit and empty when no profile was saved`() {
        val files = archive(HealthExportSnapshot(WatchState(), JSONObject()))
        assertEquals(0, JSONArray(files.getValue("energy_profile.json").decodeToString()).length())
        val manifest = JSONObject(files.getValue("manifest.json").decodeToString())
        assertEquals(0, manifest.getInt("energy_profile_count"))
        assertEquals(
            "current_value_only",
            manifest.getJSONObject("retention").getString("energy_profile"),
        )
    }

    @Test
    fun `independent stores keep detached manual naps and all local analysis revisions`() {
        val nap = SleepParser.ManualNap(1_700_000_000_000, 1_700_003_600_000)
        val inferred =
            SleepParser.manualSession(nap).copy(id = "inferred", analysisSource = "local-model/v1")
        val original = JSONObject(SleepParser.encode(inferred)).put("future_model_field", 123)
        val revised = inferred.copy(analysisSource = "local-model/v2", reportedSleepMinutes = 45)
        val settings =
            JSONObject()
                .put(
                    "vascular_load",
                    JSONObject().put("enabled", true).put("desired", JSONObject.NULL),
                )
        val files =
            archive(
                HealthExportSnapshot(
                    WatchState(),
                    JSONObject(),
                    manualNaps = listOf(nap),
                    localSleepResults =
                        JSONObject()
                            .put("v1-cache", original)
                            .put("v2-cache", JSONObject(SleepParser.encode(revised))),
                    collectionSettings = settings,
                )
            )
        val sessions = JSONArray(files.getValue("sleep_sessions.json").decodeToString())
        assertEquals(1, sessions.length())
        assertEquals(
            SleepParser.manualSession(nap).id,
            sessions.getJSONObject(0).getString("record_id"),
        )
        assertEquals(1, JSONArray(files.getValue("manual_naps.json").decodeToString()).length())
        val analysis = JSONArray(files.getValue("local_sleep_analysis.json").decodeToString())
        assertEquals(2, analysis.length())
        assertEquals(
            123,
            analysis.getJSONObject(0).getJSONObject("retained_result").getInt("future_model_field"),
        )
        assertEquals(
            setOf("local-model/v1", "local-model/v2"),
            (0 until analysis.length())
                .map { analysis.getJSONObject(it).getJSONObject("session").getString("source") }
                .toSet(),
        )
        assertTrue(
            JSONObject(files.getValue("collection_settings.json").decodeToString())
                .getJSONObject("vascular_load")
                .getBoolean("enabled")
        )
    }

    @Test
    fun `interval without end time keeps null metadata and exports`() {
        val ts = 1_700_000_000_000L
        val modules =
            JSONObject()
                .put(
                    HealthStepParser.MODULE_STEP_COUNT,
                    JSONArray()
                        .put(
                            JSONObject()
                                .put("datauuid", "steps-1")
                                .put("start_time", ts)
                                .put("count", 10)
                        ),
                )
        val files =
            archive(HealthExportSnapshot(WatchState(), JSONObject().put("modules", modules)))
        val row =
            JSONArray(files.getValue("activity_intervals.json").decodeToString()).getJSONObject(0)
        assertTrue(row.isNull("end_time"))
        val metadata =
            JSONObject(files.getValue("manifest.json").decodeToString())
                .getJSONObject("datasets")
                .getJSONObject("activity_intervals.json")
        assertEquals(HealthExportData.time(ts), metadata.getString("first_start_time"))
        assertEquals(HealthExportData.time(ts), metadata.getString("last_end_time"))
    }

    @Test
    fun `explicitly null dataset text never becomes the spelling null`() {
        val android =
            object : JSONObject() {
                override fun optString(name: String): String =
                    if (has(name) && isNull(name)) "null" else super.optString(name)
            }
        android.put("record_id", "steps-1").put("end_time", JSONObject.NULL)
        assertNull(HealthArchive.datasetText(android, "end_time"))
        assertEquals("steps-1", HealthArchive.datasetText(android, "record_id"))
    }

    @Test
    fun `local analysis stages survive normalized sleep export after bound trimming`() {
        val start = 1_700_000_000_000L
        val end = start + 8 * 3_600_000L
        val analyzed =
            SleepParser.Session(
                startMillis = start + 10 * 60_000L,
                endMillis = end - 5 * 60_000L,
                segments =
                    listOf(
                        SleepParser.Segment(
                            start + 10 * 60_000L,
                            end - 5 * 60_000L,
                            SleepParser.Stage.LIGHT,
                        )
                    ),
                efficiency = null,
                score = null,
                id = "analyzed-night",
                analysisSource = SleepAnalysisResult.SOURCE,
                recordedEndMillis = end,
            )
        val files =
            archive(
                HealthExportSnapshot(
                    WatchState(sleep = analyzed, sleepSessions = listOf(analyzed)),
                    JSONObject()
                        .put(
                            "modules",
                            JSONObject()
                                .put(
                                    SleepParser.MODULE_SLEEP,
                                    JSONArray()
                                        .put(
                                            JSONObject()
                                                .put("datauuid", "analyzed-night")
                                                .put("start_time", start)
                                                .put("end_time", end)
                                        ),
                                ),
                        ),
                    JSONObject()
                        .put("sleep_sessions_json", SleepParser.encodeSessions(listOf(analyzed))),
                    localSleepResults =
                        JSONObject().put("analyzed-cache", JSONObject(SleepParser.encode(analyzed))),
                )
            )
        val sessions = JSONArray(files.getValue("sleep_sessions.json").decodeToString())
        assertEquals(1, sessions.length())
        val session = sessions.getJSONObject(0)
        assertEquals(SleepAnalysisResult.SOURCE, session.getString("source"))
        assertEquals(1, session.getJSONArray("stages").length())
        assertEquals(465, session.getInt("time_asleep_minutes"))
        val retainedAnalysis =
            JSONArray(files.getValue("local_sleep_analysis.json").decodeToString()).getJSONObject(0)
        val normalizedViews =
            listOf(session, retainedAnalysis.getJSONObject("session")) +
                listOf("latest_sleep.json", "latest_sleep_sessions.json").map { path ->
                    JSONArray(files.getValue(path).decodeToString()).getJSONObject(0)
                }
        normalizedViews.forEach { view ->
            assertEquals(58, view.getInt("computed_score"))
            assertEquals(SleepScore.SOURCE, view.getString("computed_score_algorithm"))
            assertEquals(SleepScore.SOURCE, view.getString("score_source"))
            assertTrue(view.isNull("score"))
        }
        assertFalse(retainedAnalysis.getJSONObject("retained_result").has("computed_score"))
        val manifest = JSONObject(files.getValue("manifest.json").decodeToString())
        assertEquals(HealthArchive.SCHEMA, manifest.getString("schema"))
        assertEquals(
            1,
            manifest
                .getJSONObject("datasets")
                .getJSONObject("sleep_sessions.json")
                .getInt("record_count"),
        )
    }

    @Test
    fun `raw binning exceeds UI caps without duplicating aggregate or alias revisions`() {
        val ts = 1_700_000_000_000L
        val bins =
            JSONArray(
                (0..700).map { i ->
                    JSONObject().put("start_time", ts + i * 60_000L).put("heart_rate", 60 + i % 10)
                }
            )
        val old =
            JSONObject()
                .put("datauuid", "same-hrv")
                .put("start_time", ts)
                .put("rmssd", 21)
                .put("update_time", ts + 1)
        val latest = JSONObject(old.toString()).put("rmssd", 30).put("update_time", ts + 2)
        val modules =
            JSONObject()
                .put(
                    HeartRateLog.MODULE,
                    JSONArray()
                        .put(
                            JSONObject()
                                .put("datauuid", "bins")
                                .put("start_time", ts)
                                .put("heart_rate", 150)
                                .put("binning_data", bins)
                        ),
                )
                .put(HealthMetric.HRV.moduleKeys[0], JSONArray().put(old))
                .put(HealthMetric.HRV.moduleKeys[1], JSONArray().put(latest))
        val state =
            WatchState(
                heartRatePoints = listOf(HeartRateLog.Point(ts, 70)),
                metricSamples =
                    mapOf(
                        HealthMetric.HRV to
                            listOf(
                                HealthMetricLog.Sample(ts, 21f),
                                HealthMetricLog.Sample(ts - 60_000, 25f),
                            )
                    ),
            )
        val rows =
            JSONArray(
                archive(HealthExportSnapshot(state, JSONObject().put("modules", modules)))
                    .getValue("measurements.json")
                    .decodeToString()
            )
        val heart =
            (0 until rows.length()).map(rows::getJSONObject).filter {
                it.getString("type") == "heart_rate"
            }
        assertEquals(701, heart.size)
        assertFalse(heart.any { it.getInt("value") == 150 })
        val hrv =
            (0 until rows.length()).map(rows::getJSONObject).filter {
                it.getString("type") == "heart_rate_variability"
            }
        assertEquals(2, hrv.size)
        assertEquals(30.0, hrv.first { it.getString("method") == "rmssd" }.getDouble("value"), 0.0)
        assertEquals(
            "unknown",
            hrv.first { it.getLong("start_time_epoch_ms") == ts - 60_000 }.getString("method"),
        )
    }

    @Test
    fun `stress floors vascular load and activity retain zero and distinguish missing values`() {
        val ts = 1_700_000_000_000L
        val modules =
            JSONObject()
                .put(
                    StressLog.MODULE,
                    JSONArray()
                        .put(
                            JSONObject()
                                .put("datauuid", "stress-zero")
                                .put("start_time", ts)
                                .put("score", 0)
                        ),
                )
                .put(
                    "com.samsung.shealth.floors_climbed",
                    JSONArray()
                        .put(
                            JSONObject()
                                .put("datauuid", "floors-zero")
                                .put("start_time", ts)
                                .put("floor_count", 0)
                        )
                        .put(
                            JSONObject().put("datauuid", "floors-unknown").put("start_time", ts + 1)
                        ),
                )
                .put(
                    VascularLoadLog.MODULE,
                    JSONArray()
                        .put(
                            JSONObject()
                                .put("datauuid", "reset")
                                .put("start_time", ts)
                                .put("type", 1)
                        )
                        .put(
                            JSONObject()
                                .put("datauuid", "baseline")
                                .put("start_time", ts + 1)
                                .put("type", 2)
                                .put("measurement", 0)
                        )
                        .put(
                            JSONObject()
                                .put("datauuid", "load")
                                .put("start_time", ts + 2)
                                .put("type", 3)
                                .put("measurement", -5.5)
                        ),
                )
                .put(
                    HealthStepParser.MODULE_STEP_COUNT,
                    JSONArray()
                        .put(
                            JSONObject()
                                .put("datauuid", "steps-zero")
                                .put("start_time", ts)
                                .put("count", 0)
                        )
                        .put(
                            JSONObject()
                                .put("datauuid", "steps-unknown")
                                .put("start_time", ts + 86_400_000L)
                        ),
                )
        val files =
            archive(HealthExportSnapshot(WatchState(), JSONObject().put("modules", modules)))
        val stress =
            JSONArray(files.getValue("measurements.json").decodeToString()).getJSONObject(0)
        assertEquals("stress", stress.getString("type"))
        assertEquals(0.0, stress.getDouble("value"), 0.0)
        val floors = JSONArray(files.getValue("floors.json").decodeToString())
        assertEquals(0, floors.getJSONObject(0).getInt("floors"))
        assertTrue(floors.getJSONObject(1).isNull("floors"))
        val load = JSONArray(files.getValue("vascular_load.json").decodeToString())
        assertEquals(3, load.length())
        assertTrue(load.getJSONObject(0).isNull("measurement"))
        assertEquals(-5.5, load.getJSONObject(2).getDouble("measurement"), 0.0)
        assertTrue(load.getJSONObject(0).isNull("band"))
        assertTrue(load.getJSONObject(1).isNull("band"))
        assertEquals("slightly_higher", load.getJSONObject(2).getString("band"))
        val datasets =
            JSONObject(files.getValue("manifest.json").decodeToString()).getJSONObject("datasets")
        assertEquals(
            "2023-11-14",
            datasets.getJSONObject("vascular_load.json").getString("first_local_date"),
        )
        assertEquals(
            "2023-11-15",
            datasets.getJSONObject("vascular_load.json").getString("last_local_date"),
        )
        val activity = JSONArray(files.getValue("daily_activity.json").decodeToString())
        assertEquals(0, activity.getJSONObject(0).getInt("steps"))
        assertTrue(activity.getJSONObject(0).isNull("active_energy_kcal"))
        assertTrue(activity.getJSONObject(1).isNull("steps"))
    }

    @Test
    fun `manifest counts and schema mappings cover every JSON dataset`() {
        val files = archive(HealthExportSnapshot(WatchState(), JSONObject()))
        val manifest = JSONObject(files.getValue("manifest.json").decodeToString())
        val schema = JSONObject(files.getValue("schema.json").decodeToString())
        val datasets = manifest.getJSONObject("datasets")
        files
            .filterKeys { it.endsWith(".json") && it !in setOf("schema.json", "manifest.json") }
            .forEach { (path, bytes) ->
                assertTrue("schema mapping missing: $path", schema.getJSONObject("files").has(path))
                assertTrue("dataset missing: $path", datasets.has(path))
                if (bytes.decodeToString().startsWith("["))
                    assertEquals(
                        JSONArray(bytes.decodeToString()).length(),
                        datasets.getJSONObject(path).getInt("record_count"),
                    )
            }
        assertEquals("unknown", manifest.getJSONObject("sync").getString("historical_completeness"))
        assertFalse(
            manifest.getJSONObject("retention").getBoolean("export_applies_additional_trimming")
        )
    }

    @Test
    fun `empty data exports a valid documented empty dataset`() {
        val files = archive(HealthExportSnapshot(WatchState(), JSONObject()))
        assertEquals(0, JSONArray(files.getValue("ecg.json").decodeToString()).length())
        assertEquals(0, JSONArray(files.getValue("measurements.json").decodeToString()).length())
        assertTrue(
            files.getValue("README.md").decodeToString().contains("NOT an Apple Health import")
        )
        assertFalse(files.keys.any { it.endsWith(".apk") || it.contains("credential") })
    }

    @Test
    fun `v7 archive exports ECG BP metadata deleted tombstones and filters respiratory outliers`() {
        val ts = 1_790_000_000_000L
        val store = HealthRecordStore()
        store.merge(
            mapOf(
                ExerciseLog.MODULE to
                    listOf(
                        JSONObject()
                            .put("datauuid", "ex-deleted")
                            .put("start_time", ts)
                            .put("end_time", ts + 1_800_000L)
                            .put("update_time", ts + 10L)
                            .put("exercise_type", 1001)
                    ),
                HealthMetric.RESPIRATORY.moduleKeys.first() to
                    listOf(
                        JSONObject()
                            .put("datauuid", "resp-outlier")
                            .put("start_time", ts)
                            .put("breath_rate", 48)
                            .put("is_outlier", 1),
                        JSONObject()
                            .put("datauuid", "resp-valid")
                            .put("start_time", ts + 60_000L)
                            .put("breath_rate", 14)
                            .put("is_outlier", 0),
                    ),
                "com.samsung.health.oxygen_saturation.raw" to
                    listOf(
                        JSONObject()
                            .put("datauuid", "spo2-raw-1")
                            .put("start_time", ts + 120_000L)
                            .put("spo2", 98)
                    ),
            ),
            ts + 1_000L,
        )
        store.merge(
            mapOf(
                HealthRecordStore.MODULE_DELETED_DATA to
                    listOf(
                        JSONObject()
                            .put("data_type", ExerciseLog.MODULE_ALIAS)
                            .put("datauuid", "ex-deleted")
                            .put("delete_time", ts + 20L)
                    )
            ),
            ts + 1_000L,
        )
        // Stale replay must not resurrect deleted exercise
        store.merge(
            mapOf(
                ExerciseLog.MODULE to
                    listOf(
                        JSONObject()
                            .put("datauuid", "ex-deleted")
                            .put("start_time", ts)
                            .put("end_time", ts + 1_800_000L)
                            .put("update_time", ts + 15L)
                            .put("exercise_type", 1001)
                    )
            ),
            ts + 1_000L,
        )
        assertTrue(store.records(ExerciseLog.MODULE).isEmpty())
        assertEquals(1, store.deletedTombstoneCount())

        val restoredStore = HealthRecordStore()
        assertTrue(restoredStore.restore(store.encode(), ts + 2_000L))
        assertEquals(1, restoredStore.deletedTombstoneCount())

        val ecg =
            EcgRecord(
                id = "ecg-v7",
                startTime = ts,
                heartRate = 72,
                classification = 1,
                waveform = floatArrayOf(0.1f, 0.2f),
                updateTime = ts + 50L,
                symptoms = listOf(1, 2),
                rawSymptoms = "[1,2]",
                ecgAppVersion = "1.3",
                timeOffsetMs = 28_800_000L,
                createTime = ts + 30L,
                deviceUuid = "watch-dev",
                pkgName = "com.samsung.android.shealthmonitor",
                comment = "post-walk",
            )
        val bp =
            BpRecord(
                id = "bp-v7",
                startTime = ts,
                systolic = 118,
                diastolic = 76,
                heartRate = 66,
                updateTime = ts + 40L,
                calibrationDataUuid = "cal-1",
                timeOffsetMs = 28_800_000L,
                createTime = ts + 20L,
                deviceUuid = "watch-dev",
                pkgName = "com.samsung.android.shealthmonitor",
                comment = "seated",
            )
        val files =
            archive(
                HealthExportSnapshot(
                    WatchState(ecgRecords = listOf(ecg), bpRecords = listOf(bp)),
                    JSONObject(restoredStore.encode()),
                ),
                exportedAt = ts + 2_000L,
            )

        val ecgJson = JSONArray(files.getValue("ecg.json").decodeToString()).getJSONObject(0)
        assertEquals("[1,2]", ecgJson.getString("raw_symptoms"))
        assertEquals(2, ecgJson.getJSONArray("symptoms").length())
        assertEquals("1.3", ecgJson.getString("ecg_app_version"))
        assertEquals(28_800_000L, ecgJson.getLong("time_offset_ms"))
        assertEquals(ts + 30L, ecgJson.getLong("create_time_epoch_ms"))
        assertEquals(ts + 50L, ecgJson.getLong("update_time_epoch_ms"))
        assertEquals("watch-dev", ecgJson.getString("device_uuid"))
        assertEquals("post-walk", ecgJson.getString("comment"))

        val bpJson =
            JSONArray(files.getValue("blood_pressure.json").decodeToString()).getJSONObject(0)
        assertEquals("cal-1", bpJson.getString("calibration_data_uuid"))
        assertEquals(28_800_000L, bpJson.getLong("time_offset_ms"))
        assertEquals(ts + 20L, bpJson.getLong("create_time_epoch_ms"))
        assertEquals(ts + 40L, bpJson.getLong("update_time_epoch_ms"))
        assertEquals("seated", bpJson.getString("comment"))

        val measurements =
            JSONArray(files.getValue("measurements.json").decodeToString()).let { arr ->
                (0 until arr.length()).map(arr::getJSONObject)
            }
        val resp = measurements.filter { it.getString("type") == "respiratory_rate" }
        assertEquals(1, resp.size)
        assertEquals(14.0, resp.single().getDouble("value"), 0.0)
        assertTrue(
            measurements.any {
                it.getString("type") == "oxygen_saturation" && it.getInt("value") == 98
            }
        )

        val manifest = JSONObject(files.getValue("manifest.json").decodeToString())
        val retention = manifest.getJSONObject("retention")
        assertEquals(1_000, retention.getInt("ecg_record_limit"))
        assertEquals(1_000, retention.getInt("bp_record_limit"))
        assertEquals(1, retention.getInt("deleted_tombstone_count"))
        assertEquals(60, retention.getInt("deleted_tombstone_days"))
    }

    @Test
    fun `v7 archive preserves multi-device vascular load history and daily energy push cache`() {
        val ts = 1_795_000_000_000L
        val oldReset =
            JSONObject()
                .put("datauuid", "vl-old-reset")
                .put("deviceuuid", "synthetic-watch-old")
                .put("start_time", ts - 86_400_000L * 10)
                .put("end_time", ts - 86_400_000L * 10)
                .put("type", 1)
        val oldMeasurement =
            JSONObject()
                .put("datauuid", "vl-old-meas")
                .put("deviceuuid", "synthetic-watch-old")
                .put("start_time", ts - 86_400_000L * 5)
                .put("end_time", ts - 86_400_000L * 5)
                .put("type", 3)
                .put("measurement", -3.5)
        val newReset =
            JSONObject()
                .put("datauuid", "vl-new-reset")
                .put("deviceuuid", "synthetic-watch-new")
                .put("start_time", ts)
                .put("end_time", ts)
                .put("type", 1)
        val store = HealthRecordStore()
        store.merge(
            mapOf(VascularLoadLog.MODULE to listOf(oldReset, oldMeasurement, newReset)),
            ts + 1_000L,
        )
        val snapshot =
            VascularLoadLog.project(
                store.records(VascularLoadLog.MODULE),
                now = ts + 1_000L,
                currentWatchDeviceUuid = "synthetic-watch-new",
            )
        val cache =
            JSONObject()
                .put("energy_score_auto_pushed_day", "2026-11-25")
                .put("vascular_load_watch_version", 1002)
        val files =
            archive(
                HealthExportSnapshot(
                    WatchState(vascularLoadSupported = true, vascularLoad = snapshot),
                    JSONObject(store.encode()),
                    retainedCache = cache,
                ),
                exportedAt = ts + 2_000L,
            )
        val vl = JSONArray(files.getValue("vascular_load.json").decodeToString())
        assertEquals(3, vl.length())
        val rawVl =
            JSONObject(files.getValue("source_records.json").decodeToString())
                .getJSONObject("modules")
                .getJSONArray(VascularLoadLog.MODULE)
        assertEquals(3, rawVl.length())
        val retainedCache = JSONObject(files.getValue("retained_cache.json").decodeToString())
        assertEquals("2026-11-25", retainedCache.getString("energy_score_auto_pushed_day"))
        assertEquals(1002, retainedCache.getInt("vascular_load_watch_version"))
    }

    @Test
    fun `v7 archive exports watch 7_x combined sleep linkage and 7-ACC local analysis without duplication`() {
        val zone = ZoneId.of("Asia/Shanghai")
        val exportedAt = Instant.parse("2026-11-27T12:00:00Z").toEpochMilli()
        val night1Start = Instant.parse("2026-11-25T15:00:00Z").toEpochMilli()
        val night1End = Instant.parse("2026-11-25T22:00:00Z").toEpochMilli()
        val night2Start = Instant.parse("2026-11-26T15:00:00Z").toEpochMilli()
        val night2End = Instant.parse("2026-11-26T21:00:00Z").toEpochMilli()

        val sleep1 =
            JSONObject()
                .put("datauuid", "s7-night-1")
                .put("combined_id", "c7-night-1")
                .put("start_time", night1Start)
                .put("end_time", night1End)
                .put("quality", 0)
        val combined1 =
            JSONObject()
                .put("datauuid", "c7-night-1")
                .put("start_time", night1Start)
                .put("end_time", night1End)
                .put("sleep_score", 87)
                .put("efficiency", 93.4)
        val stage1a =
            JSONObject()
                .put("datauuid", "st7-1a")
                .put("sleep_id", "c7-night-1")
                .put("start_time", night1Start)
                .put("end_time", night1Start + 3 * 3_600_000L)
                .put("stage", SleepParser.CODE_LIGHT)
        val stage1b =
            JSONObject()
                .put("datauuid", "st7-1b")
                .put("sleep_id", "c7-night-1")
                .put("start_time", night1Start + 3 * 3_600_000L)
                .put("end_time", night1End)
                .put("stage", SleepParser.CODE_DEEP)

        val sleep2 =
            JSONObject()
                .put("datauuid", "s7-night-2")
                .put("start_time", night2Start)
                .put("end_time", night2End)
                .put("has_sleep_data", -1)
        val local7AccSession =
            SleepParser.Session(
                startMillis = night2Start,
                endMillis = night2End,
                segments =
                    listOf(
                        SleepParser.Segment(
                            night2Start,
                            night2Start + 3 * 3_600_000L,
                            SleepParser.Stage.LIGHT,
                        ),
                        SleepParser.Segment(
                            night2Start + 3 * 3_600_000L,
                            night2Start + 5 * 3_600_000L,
                            SleepParser.Stage.DEEP,
                        ),
                        SleepParser.Segment(
                            night2Start + 5 * 3_600_000L,
                            night2End,
                            SleepParser.Stage.REM,
                        ),
                    ),
                efficiency = null,
                score = null,
                id = "s7-night-2",
                analysisSource = SleepAnalysisResult.SOURCE_7ACC,
                recordedEndMillis = night2End,
            )

        val store = HealthRecordStore()
        store.merge(
            mapOf(
                SleepParser.MODULE_SLEEP to listOf(sleep1, sleep2),
                SleepParser.MODULE_SLEEP_COMBINED to listOf(combined1),
                SleepParser.MODULE_SLEEP_STAGE_LEGACY to listOf(stage1a, stage1b),
            ),
            exportedAt,
        )
        val localResults =
            JSONObject().put("cache-7acc-key", JSONObject(SleepParser.encode(local7AccSession)))
        val files =
            archive(
                HealthExportSnapshot(
                    WatchState(
                        sleep = local7AccSession,
                        sleepSessions = listOf(local7AccSession),
                        allSleepSessions = listOf(local7AccSession),
                    ),
                    JSONObject(store.encode()),
                    localSleepResults = localResults,
                ),
                exportedAt = exportedAt,
                zone = zone,
            )

        val sessions = JSONArray(files.getValue("sleep_sessions.json").decodeToString())
        assertEquals(2, sessions.length())
        val byId =
            (0 until sessions.length()).map(sessions::getJSONObject).associateBy {
                it.getString("record_id")
            }
        val exported1 = byId.getValue("s7-night-1")
        assertEquals("watch", exported1.getString("source"))
        assertEquals(87, exported1.getInt("score"))
        assertEquals(93, exported1.getInt("efficiency_percent"))
        assertEquals(2, exported1.getJSONArray("stages").length())

        val exported2 = byId.getValue("s7-night-2")
        assertEquals(SleepAnalysisResult.SOURCE_7ACC, exported2.getString("source"))
        assertFalse(exported2.isNull("computed_score"))
        assertEquals(SleepScore.SOURCE, exported2.getString("score_source"))
        assertEquals(3, exported2.getJSONArray("stages").length())

        val localAnalysis = JSONArray(files.getValue("local_sleep_analysis.json").decodeToString())
        assertEquals(1, localAnalysis.length())
        assertEquals(
            SleepAnalysisResult.SOURCE_7ACC,
            localAnalysis.getJSONObject(0).getJSONObject("session").getString("source"),
        )

        val rawModules =
            JSONObject(files.getValue("source_records.json").decodeToString())
                .getJSONObject("modules")
        assertTrue(rawModules.has(SleepParser.MODULE_SLEEP_COMBINED))

        val manifest = JSONObject(files.getValue("manifest.json").decodeToString())
        assertEquals(HealthArchive.SCHEMA, manifest.getString("schema"))
        assertEquals(
            2,
            manifest
                .getJSONObject("datasets")
                .getJSONObject("sleep_sessions.json")
                .getInt("record_count"),
        )
    }
}
