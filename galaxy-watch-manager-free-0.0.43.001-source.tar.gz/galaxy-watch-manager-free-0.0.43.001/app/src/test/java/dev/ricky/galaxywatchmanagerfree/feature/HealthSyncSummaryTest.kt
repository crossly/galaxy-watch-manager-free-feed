package dev.ricky.galaxywatchmanagerfree.feature

import dev.ricky.galaxywatchmanagerfree.feature.monitor.HealthMonitorSession
import org.junit.Assert.assertEquals
import org.junit.Test

class HealthSyncSummaryTest {
    private fun state(
        sessionReady: Boolean = true,
        health: HealthSyncCoordinator.Status = HealthSyncCoordinator.Status.DISCONNECTED,
        monitor: HealthMonitorSession.SyncStatus = HealthMonitorSession.SyncStatus.WAITING,
    ) =
        WatchState(
            sessionReady = sessionReady,
            healthSyncStatus = health,
            monitorState =
                HealthMonitorSession.State(
                    connection = HealthMonitorSession.Connection.READY,
                    syncStatus = monitor,
                ),
        )

    @Test
    fun `disconnected session never claims a health result`() {
        assertEquals(
            HealthSyncSummary.DISCONNECTED,
            HealthSyncSummary.from(
                state(
                    sessionReady = false,
                    health = HealthSyncCoordinator.Status.IDLE,
                    monitor = HealthMonitorSession.SyncStatus.SYNCED,
                )
            ),
        )
    }

    @Test
    fun `both sources synced is the only full success`() {
        assertEquals(
            HealthSyncSummary.SYNCED,
            HealthSyncSummary.from(
                state(
                    health = HealthSyncCoordinator.Status.IDLE,
                    monitor = HealthMonitorSession.SyncStatus.SYNCED,
                )
            ),
        )
    }

    @Test
    fun `Samsung Health alone succeeds even when the monitor failed`() {
        assertEquals(
            HealthSyncSummary.SAMSUNG_HEALTH_ONLY,
            HealthSyncSummary.from(
                state(
                    health = HealthSyncCoordinator.Status.IDLE,
                    monitor = HealthMonitorSession.SyncStatus.FAILED,
                )
            ),
        )
        assertEquals(
            HealthSyncSummary.SAMSUNG_HEALTH_ONLY,
            HealthSyncSummary.from(
                state(
                    health = HealthSyncCoordinator.Status.IDLE,
                    monitor = HealthMonitorSession.SyncStatus.TIMED_OUT,
                )
            ),
        )
    }

    @Test
    fun `monitor alone succeeds even when Samsung Health failed`() {
        assertEquals(
            HealthSyncSummary.MONITOR_ONLY,
            HealthSyncSummary.from(
                state(
                    health = HealthSyncCoordinator.Status.TIMED_OUT,
                    monitor = HealthMonitorSession.SyncStatus.SYNCED,
                )
            ),
        )
        assertEquals(
            HealthSyncSummary.MONITOR_ONLY,
            HealthSyncSummary.from(
                state(
                    health = HealthSyncCoordinator.Status.TIMED_OUT,
                    monitor = HealthMonitorSession.SyncStatus.PARTIAL,
                )
            ),
        )
    }

    @Test
    fun `both sources failed reports the sync as failed`() {
        for (monitor in
            listOf(
                HealthMonitorSession.SyncStatus.FAILED,
                HealthMonitorSession.SyncStatus.TIMED_OUT,
            )) {
            assertEquals(
                HealthSyncSummary.FAILED,
                HealthSyncSummary.from(
                    state(health = HealthSyncCoordinator.Status.TIMED_OUT, monitor = monitor)
                ),
            )
        }
    }

    @Test
    fun `partial monitor results remain partial when health also synced`() {
        assertEquals(
            HealthSyncSummary.PARTIAL,
            HealthSyncSummary.from(
                state(
                    health = HealthSyncCoordinator.Status.IDLE,
                    monitor = HealthMonitorSession.SyncStatus.PARTIAL,
                )
            ),
        )
    }

    @Test
    fun `one source still working keeps the summary busy or waiting`() {
        assertEquals(
            HealthSyncSummary.SYNCING,
            HealthSyncSummary.from(
                state(
                    health = HealthSyncCoordinator.Status.SYNCING,
                    monitor = HealthMonitorSession.SyncStatus.FAILED,
                )
            ),
        )
        assertEquals(
            HealthSyncSummary.WAITING,
            HealthSyncSummary.from(
                state(
                    health = HealthSyncCoordinator.Status.WAITING,
                    monitor = HealthMonitorSession.SyncStatus.SYNCED,
                )
            ),
        )
    }
}
