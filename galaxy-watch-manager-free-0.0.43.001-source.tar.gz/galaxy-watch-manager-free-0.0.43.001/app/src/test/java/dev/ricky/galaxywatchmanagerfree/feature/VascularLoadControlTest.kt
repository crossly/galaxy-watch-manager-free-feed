package dev.ricky.galaxywatchmanagerfree.feature

import dev.ricky.galaxywatchmanagerfree.wcs.WcsPaths
import java.io.ByteArrayOutputStream
import java.time.ZoneId
import java.util.Base64
import java.util.zip.GZIPOutputStream
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class VascularLoadControlTest {

    @Test
    fun `v2 user-initiated activation encodes official compressed VlPushMessageV2 and handles created ACK`() =
        runTest {
            val sent = mutableListOf<JSONObject>()
            val statuses = mutableListOf<VascularLoadControl.Status>()
            val logs = mutableListOf<String>()
            val errors = mutableListOf<String>()
            var resetCreatedCallbacks = 0
            val now = 1_795_500_000_000L
            val control =
                VascularLoadControl(
                    scope = this,
                    watchNode = { "synthetic-watch-node" },
                    watchVersion = { 1002 },
                    send = {
                        sent.add(it)
                        true
                    },
                    onStatus = statuses::add,
                    onResetCreated = { resetCreatedCallbacks++ },
                    clock = { now },
                    zone = { ZoneId.of("Asia/Shanghai") },
                    timeoutMillis = 100L,
                    onLog = logs::add,
                    onError = errors::add,
                )

            assertFalse(control.isPending)
            assertTrue(control.activateOrReset(userInitiated = true))
            assertTrue(control.isPending)
            assertEquals(VascularLoadControl.Status.SENDING, statuses.last())

            val packet = sent.single()
            assertEquals(WcsPaths.HEALTH_MSG_REQUEST, packet.getString("message"))
            assertEquals(WcsPaths.HEALTH_TYPE_MESSAGE, packet.getString("type"))
            assertEquals(WcsPaths.HEALTH_PHONE_VASCULAR_LOAD, packet.getString("sender"))
            assertEquals(WcsPaths.HEALTH_WATCH_VASCULAR_LOAD, packet.getString("receiver"))
            assertEquals(WcsPaths.PKG_SHEALTH, packet.getString("source_node"))
            assertEquals("synthetic-watch-node", packet.getString("destination_node"))
            assertEquals(5.03, packet.getDouble("version"), 0.001)

            val body = HealthJson.entries(packet.getString("body")).getJSONObject(0)
            assertEquals(VascularLoadControl.CMD_V2_USER_INITIATED, body.getString("command"))
            assertEquals(now, body.getLong("utcTimestamp"))
            assertEquals(8L * 3_600_000L, body.getLong("timeOffset"))

            val seq = packet.getInt("sequence_num")
            // Mismatched envelope fields must be ignored.
            assertFalse(control.handleMessage(v2Ack(seq + 1)))
            assertFalse(control.handleMessage(v2Ack(seq).put("sender", "other-sender")))
            assertFalse(control.handleMessage(v2Ack(seq).put("receiver", "other-receiver")))
            assertFalse(control.handleMessage(v2Ack(seq).put("type", WcsPaths.HEALTH_TYPE_DATA)))
            assertTrue(control.isPending)
            assertEquals(0, resetCreatedCallbacks)

            // Valid ACK confirms and triggers readback callback.
            assertTrue(control.handleMessage(v2Ack(seq, VascularLoadControl.CMD_V2_CREATED_ACK)))
            assertFalse(control.isPending)
            assertEquals(VascularLoadControl.Status.CREATED, statuses.last())
            assertEquals(1, resetCreatedCallbacks)
            assertTrue(errors.isEmpty())
            assertFalse(logs.joinToString("\n").contains("synthetic-watch-node"))

            // Duplicate ACK is ignored; syncing rows clears transient CREATED status.
            assertFalse(control.handleMessage(v2Ack(seq, VascularLoadControl.CMD_V2_CREATED_ACK)))
            control.onRowsSynced()
            assertEquals(VascularLoadControl.Status.IDLE, statuses.last())
        }

    @Test
    fun `v1 watch version falls back to VlPushMessage RESET_EVENT and accepts RESET_EVENT_ACK`() =
        runTest {
            val sent = mutableListOf<JSONObject>()
            val statuses = mutableListOf<VascularLoadControl.Status>()
            var resetCreatedCallbacks = 0
            val now = 1_795_500_000_000L
            val control =
                VascularLoadControl(
                    scope = this,
                    watchNode = { "watch-v1" },
                    watchVersion = { 1000 },
                    send = {
                        sent.add(it)
                        true
                    },
                    onStatus = statuses::add,
                    onResetCreated = { resetCreatedCallbacks++ },
                    clock = { now },
                    zone = { ZoneId.of("UTC") },
                )

            assertTrue(control.activateOrReset(userInitiated = true))
            val packet = sent.single()
            val body = HealthJson.entries(packet.getString("body")).getJSONObject(0)
            assertEquals(0, body.getInt("version"))
            assertEquals(VascularLoadControl.CMD_V1_RESET_EVENT, body.getString("command"))
            assertEquals(now, body.getLong("timestamp"))
            assertFalse(body.getBoolean("testMode"))

            val seq = packet.getInt("sequence_num")
            assertTrue(control.handleMessage(v1Ack(seq)))
            assertEquals(VascularLoadControl.Status.CREATED, statuses.last())
            assertEquals(1, resetCreatedCallbacks)
        }

    @Test
    fun `not-created ACK, send failure, timeout, and disconnect do not trigger reset sync`() =
        runTest {
            val sent = mutableListOf<JSONObject>()
            val statuses = mutableListOf<VascularLoadControl.Status>()
            var resetCreatedCallbacks = 0
            var canSend = false
            val control =
                VascularLoadControl(
                    scope = this,
                    watchNode = { "watch" },
                    watchVersion = { 1002 },
                    send = {
                        sent.add(it)
                        canSend
                    },
                    onStatus = statuses::add,
                    onResetCreated = { resetCreatedCallbacks++ },
                    timeoutMillis = 100L,
                )

            // Send failure.
            assertFalse(control.activateOrReset(userInitiated = false))
            assertEquals(VascularLoadControl.Status.SEND_FAILED, statuses.last())
            assertFalse(control.isPending)

            // Automatic RESET_EVENT_NOT_CREATED_ACK.
            canSend = true
            assertTrue(control.activateOrReset(userInitiated = false))
            val autoPacket = sent.last()
            val autoBody = HealthJson.entries(autoPacket.getString("body")).getJSONObject(0)
            assertEquals(VascularLoadControl.CMD_V2_AUTOMATIC, autoBody.getString("command"))
            val autoSeq = autoPacket.getInt("sequence_num")
            assertTrue(
                control.handleMessage(v2Ack(autoSeq, VascularLoadControl.CMD_V2_NOT_CREATED_ACK))
            )
            assertEquals(VascularLoadControl.Status.NOT_CREATED, statuses.last())

            // Malformed body leaves pending; timeout cancels and rejects late ACK.
            assertTrue(control.activateOrReset(userInitiated = true))
            val timeoutSeq = sent.last().getInt("sequence_num")
            assertTrue(control.handleMessage(v2Ack(timeoutSeq).put("body", "malformed")))
            assertTrue(control.isPending)
            advanceTimeBy(100L)
            runCurrent()
            assertEquals(VascularLoadControl.Status.TIMED_OUT, statuses.last())
            assertFalse(control.handleMessage(v2Ack(timeoutSeq)))

            // Disconnect cancels in-flight request.
            assertTrue(control.activateOrReset(userInitiated = true))
            val discSeq = sent.last().getInt("sequence_num")
            control.disconnect()
            assertEquals(VascularLoadControl.Status.DISCONNECTED, statuses.last())
            assertFalse(control.handleMessage(v2Ack(discSeq)))

            // Idle disconnect resets to IDLE without spurious error state.
            control.disconnect()
            assertEquals(VascularLoadControl.Status.IDLE, statuses.last())
            assertEquals(0, resetCreatedCallbacks)
        }

    @Test
    fun `auto activate policy only activates uninitialized watches after history verification`() =
        runTest {
            val now = 1_795_600_000_000L
            val needsActivation =
                VascularLoadLog.Snapshot(
                    activeDeviceUuid = "synthetic-watch-new",
                    latestResetDeviceUuid = "synthetic-watch-old",
                    needsWatchActivation = true,
                )
            val alreadyBuilding =
                VascularLoadLog.Snapshot(
                    baselineNights = 1,
                    activeDeviceUuid = "synthetic-watch-new",
                    latestResetDeviceUuid = "synthetic-watch-new",
                    needsWatchActivation = false,
                )
            val established =
                VascularLoadLog.Snapshot(
                    baselineComplete = true,
                    baselineNights = 3,
                    activeDeviceUuid = "synthetic-watch-new",
                    latestResetDeviceUuid = "synthetic-watch-new",
                    needsWatchActivation = false,
                )

            // Safety gates before activation.
            assertEquals(
                VascularLoadAutoActivatePolicy.Decision.SkipUnsupported,
                VascularLoadAutoActivatePolicy.decide(
                    supported = false,
                    sessionReady = true,
                    healthSyncIdle = true,
                    controlInFlight = false,
                    labSettingEnabled = true,
                    historyVerified = true,
                    snapshot = needsActivation,
                    lastAttemptAt = 0L,
                    now = now,
                ),
            )
            assertEquals(
                VascularLoadAutoActivatePolicy.Decision.SkipDisconnected,
                VascularLoadAutoActivatePolicy.decide(
                    supported = true,
                    sessionReady = false,
                    healthSyncIdle = true,
                    controlInFlight = false,
                    labSettingEnabled = true,
                    historyVerified = true,
                    snapshot = needsActivation,
                    lastAttemptAt = 0L,
                    now = now,
                ),
            )
            assertEquals(
                VascularLoadAutoActivatePolicy.Decision.SkipSyncing,
                VascularLoadAutoActivatePolicy.decide(
                    supported = true,
                    sessionReady = true,
                    healthSyncIdle = false,
                    controlInFlight = false,
                    labSettingEnabled = true,
                    historyVerified = true,
                    snapshot = needsActivation,
                    lastAttemptAt = 0L,
                    now = now,
                ),
            )
            assertEquals(
                VascularLoadAutoActivatePolicy.Decision.SkipControlInFlight,
                VascularLoadAutoActivatePolicy.decide(
                    supported = true,
                    sessionReady = true,
                    healthSyncIdle = true,
                    controlInFlight = true,
                    labSettingEnabled = true,
                    historyVerified = true,
                    snapshot = needsActivation,
                    lastAttemptAt = 0L,
                    now = now,
                ),
            )
            assertEquals(
                VascularLoadAutoActivatePolicy.Decision.SkipDisabledByUser,
                VascularLoadAutoActivatePolicy.decide(
                    supported = true,
                    sessionReady = true,
                    healthSyncIdle = true,
                    controlInFlight = false,
                    labSettingEnabled = false,
                    historyVerified = true,
                    snapshot = needsActivation,
                    lastAttemptAt = 0L,
                    now = now,
                ),
            )
            // Never auto-activate before initial history backfill completes (protects active watch
            // baseline on phone reinstall).
            assertEquals(
                VascularLoadAutoActivatePolicy.Decision.SkipHistoryUnverified,
                VascularLoadAutoActivatePolicy.decide(
                    supported = true,
                    sessionReady = true,
                    healthSyncIdle = true,
                    controlInFlight = false,
                    labSettingEnabled = null,
                    historyVerified = false,
                    snapshot = needsActivation,
                    lastAttemptAt = 0L,
                    now = now,
                ),
            )
            // Never wipe an in-progress or completed baseline on the current watch.
            for (active in listOf(alreadyBuilding, established)) {
                assertEquals(
                    VascularLoadAutoActivatePolicy.Decision.SkipAlreadyActive,
                    VascularLoadAutoActivatePolicy.decide(
                        supported = true,
                        sessionReady = true,
                        healthSyncIdle = true,
                        controlInFlight = false,
                        labSettingEnabled = true,
                        historyVerified = true,
                        snapshot = active,
                        lastAttemptAt = 0L,
                        now = now,
                    ),
                )
            }

            // Eligible when labs setting is default-unknown (null) or explicitly true.
            for (labSetting in listOf(null, true)) {
                assertEquals(
                    VascularLoadAutoActivatePolicy.Decision.Activate("synthetic-watch-new"),
                    VascularLoadAutoActivatePolicy.decide(
                        supported = true,
                        sessionReady = true,
                        healthSyncIdle = true,
                        controlInFlight = false,
                        labSettingEnabled = labSetting,
                        historyVerified = true,
                        snapshot = needsActivation,
                        lastAttemptAt = 0L,
                        now = now,
                    ),
                )
            }

            // Cooldown prevents tight retry loops, then allows retry once elapsed.
            assertEquals(
                VascularLoadAutoActivatePolicy.Decision.SkipCooldown,
                VascularLoadAutoActivatePolicy.decide(
                    supported = true,
                    sessionReady = true,
                    healthSyncIdle = true,
                    controlInFlight = false,
                    labSettingEnabled = true,
                    historyVerified = true,
                    snapshot = needsActivation,
                    lastAttemptAt = now - 60_000L,
                    now = now,
                ),
            )
            assertEquals(
                VascularLoadAutoActivatePolicy.Decision.Activate("synthetic-watch-new"),
                VascularLoadAutoActivatePolicy.decide(
                    supported = true,
                    sessionReady = true,
                    healthSyncIdle = true,
                    controlInFlight = false,
                    labSettingEnabled = true,
                    historyVerified = true,
                    snapshot = needsActivation,
                    lastAttemptAt = now - VascularLoadAutoActivatePolicy.DEFAULT_RETRY_COOLDOWN_MS,
                    now = now,
                ),
            )

            // Automatic activation uses safe distinct log phrasing.
            val logs = mutableListOf<String>()
            val control =
                VascularLoadControl(
                    scope = this,
                    watchNode = { "synthetic-watch-node" },
                    watchVersion = { 1002 },
                    send = { true },
                    onStatus = {},
                    onResetCreated = {},
                    onLog = logs::add,
                )
            assertTrue(control.activateOrReset(userInitiated = true, automatic = true))
            assertTrue(logs.last().contains("自动初始化手表基线"))
            assertFalse(logs.last().contains("synthetic-watch-node"))
            control.disconnect()
        }

    private fun v2Ack(
        sequence: Int,
        command: String = VascularLoadControl.CMD_V2_CREATED_ACK,
    ): JSONObject =
        responseEnvelope(
            sequence,
            JSONObject()
                .put("command", command)
                .put("utcTimestamp", 1_795_500_001_000L)
                .put("timeOffset", 8L * 3_600_000L),
        )

    private fun v1Ack(sequence: Int): JSONObject =
        responseEnvelope(
            sequence,
            JSONObject()
                .put("version", 0)
                .put("command", VascularLoadControl.CMD_V1_RESET_ACK)
                .put("timestamp", 1_795_500_001_000L)
                .put("testMode", false),
        )

    private fun responseEnvelope(sequence: Int, body: JSONObject): JSONObject {
        val output = ByteArrayOutputStream()
        GZIPOutputStream(output).use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        return JSONObject()
            .put("message", WcsPaths.HEALTH_MSG_RESPONSE)
            .put("type", WcsPaths.HEALTH_TYPE_MESSAGE)
            .put("sender", WcsPaths.HEALTH_WATCH_VASCULAR_LOAD)
            .put("receiver", WcsPaths.HEALTH_PHONE_VASCULAR_LOAD)
            .put("sequence_num", sequence)
            .put("body", Base64.getEncoder().encodeToString(output.toByteArray()))
    }
}
