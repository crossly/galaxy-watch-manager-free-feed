package dev.ricky.galaxywatchmanagerfree.feature

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** 设置规格表：路径匹配、key/type 声明、回包值归一。 */
class WatchSettingSchemaTest {

    @Test
    fun `所有规格都声明了 key 与类型`() {
        val specs = WatchSettingSchema.all()
        assertTrue("规格表不应为空", specs.isNotEmpty())
        specs.forEach { spec ->
            assertTrue("${spec.path} 缺少 key", spec.key.isNotBlank())
            assertTrue("${spec.path} 的 match 不应为空", spec.match.isNotBlank())
        }
    }

    @Test
    fun `同一路径只登记一次`() {
        val duplicated =
            WatchSettingSchema.all()
                .groupBy { it.path.trimStart('/') }
                .filterValues { it.size > 1 }
                .keys
        assertTrue("重复登记的路径：$duplicated", duplicated.isEmpty())
    }

    @Test
    fun `常用设置项都能按后缀命中规格`() {
        val cases =
            mapOf(
                "w_module_sec_watch_setting/display/brightness" to "intLevel",
                "w_module_sec_watch_setting/display/always_on_display" to "booleanIsChecked",
                "w_module_sec_watch_setting/display/screen_time_out/selected_item" to
                    "intSelectedItem",
                "w_module_sec_watch_setting/advanced/gestures/answer_calls" to "booleanIsChecked",
                "w_module_sec_watch_setting/general/orientation/selected_wrist" to "intLevel",
                "setting_info/watch_name" to "stringName",
            )
        cases.forEach { (path, expectedKey) ->
            val spec = WatchSettingSchema.spec(path)
            assertNotNull("$path 未登记进规格表", spec)
            assertEquals(path, expectedKey, spec!!.key)
        }
    }

    @Test
    fun `无障碍设置兼容两种固件前缀`() {
        val legacy = WatchSettingSchema.spec("w_module_sec_watch_setting/accessibility/grayscale")
        val prefixed =
            WatchSettingSchema.spec("/w_module_sec_watch_setting_accessibility/grayscale")

        assertNotNull(legacy)
        assertNotNull(prefixed)
        assertEquals(legacy!!.path, prefixed!!.path)
        assertTrue(legacy.apply != null)
    }

    @Test
    fun `省电模式 spec 与外层路径对齐`() {
        val spec = WatchSettingSchema.spec("w_module_sec_watch_setting/psm")

        assertEquals(WatchSettingSchema.PSM, spec)
        assertEquals(SettingKind.BOOL, spec!!.kind)
    }

    @Test
    fun `手表免打扰立即开关解码并投影到状态`() {
        val path = "w_module_sec_watch_setting/phone/dnd/dnd_turn_on_now"
        val spec = WatchSettingSchema.spec(path)

        assertNotNull("$path 未登记进规格表", spec)
        assertEquals("booleanIsChecked", spec!!.key)
        assertEquals(SettingKind.BOOL, spec.kind)
        val item =
            WatchSettingSchema.decode(path, mapOf("from" to "watch", "booleanIsChecked" to true))!!
        assertEquals(true, item.value)
        assertTrue(spec.apply!!.invoke(WatchState(dndOn = false), item.value).dndOn)
        val off =
            WatchSettingSchema.decode(path, mapOf("from" to "watch", "booleanIsChecked" to 0))!!
        assertFalse(spec.apply!!.invoke(WatchState(dndOn = true), off.value).dndOn)
    }

    @Test
    fun `未登记路径返回 null 而不是瞎猜`() {
        assertNull(WatchSettingSchema.spec("w_module_sec_watch_setting/unknown/thing"))
    }

    @Test
    fun `回包数字归一为下发时的布尔值`() {
        assertEquals(true, SettingKind.BOOL.canonicalize(1))
        assertEquals(false, SettingKind.BOOL.canonicalize(0))
        assertEquals(true, SettingKind.BOOL.canonicalize("true"))
        assertEquals(true, SettingKind.BOOL.canonicalize(true))
        assertNull(SettingKind.BOOL.canonicalize(emptyMap<String, Any>()))
    }

    @Test
    fun `布尔回包归一为整数`() {
        assertEquals(1, SettingKind.INT.canonicalize(true))
        assertEquals(0, SettingKind.INT.canonicalize(false))
        assertEquals(42, SettingKind.INT.canonicalize(42.7))
        assertEquals(7, SettingKind.INT.canonicalize("7"))
    }

    @Test
    fun `a phone write echo is not a confirmed watch setting`() {
        val path = "w_module_sec_watch_setting/display/wake_on_wrist_raised"
        val phone = mapOf("from" to "phone", "booleanIsChecked" to false)
        assertNull(WatchSettingSchema.decode(path, phone))
        val watch = phone + ("from" to "watch")
        val item = WatchSettingSchema.decode(path, watch)!!
        assertEquals(false, item.value)
        assertFalse(
            WatchSettingSchema.spec(path)!!
                .apply!!
                .invoke(WatchState(wakeOnWrist = true), item.value)
                .wakeOnWrist
        )
    }

    @Test
    fun `metadata alone cannot confirm a setting`() {
        val path = "w_module_sec_watch_setting/display/wake_on_wrist_raised"
        assertNull(WatchSettingSchema.decode(path, mapOf("from" to "watch", "time" to 12L)))
    }

    @Test
    fun `a declared setting key takes priority over availability metadata`() {
        val path = "w_module_sec_watch_setting/display/wake_on_wrist_raised"
        val item =
            WatchSettingSchema.decode(
                path,
                linkedMapOf(
                    "booleanIsAvailable" to true,
                    "booleanIsChecked" to false,
                    "from" to "watch",
                ),
            )!!
        assertEquals("booleanIsChecked", item.key)
        assertEquals(false, item.value)
    }

    @Test
    fun `watch name readback cannot overwrite a saved custom alias`() {
        val path = "w_module_sec_watch_setting/info/setting_info/watch_name"
        val state = WatchState(watchAlias = "My watch")
        val item =
            WatchSettingSchema.decode(path, mapOf("from" to "watch", "stringName" to "Old name"))!!
        val next = WatchSettingSchema.spec(path)!!.apply?.invoke(state, item.value) ?: state

        assertEquals("My watch", next.watchAlias)
    }

    @Test
    fun `类型检查拒绝不匹配的回包`() {
        assertTrue(SettingKind.BOOL.accepts(true))
        assertFalse(SettingKind.BOOL.accepts("true"))
        assertTrue(SettingKind.INT.accepts(7))
        assertFalse(SettingKind.INT.accepts(true))
        assertTrue(SettingKind.STRING.accepts("Pixel"))
    }

    @Test
    fun `省电模式数字回包经 project 归一后正确更新 psmMode`() {
        val spec = WatchSettingSchema.spec("w_module_sec_watch_setting/psm")!!
        val on = WatchSettingSchema.project(spec, WatchState(psmMode = false), 1)
        val off = WatchSettingSchema.project(spec, WatchState(psmMode = true), 0)

        assertTrue(on.psmMode)
        assertFalse(off.psmMode)
    }

    @Test
    fun `抬腕亮屏与灰度显示按官方 DataOwner WATCH 写入手表节点并保留模板字段`() {
        val wakePath = "w_module_sec_watch_setting/display/wake_on_wrist_raised"
        val wakeTemplate =
            SettingTemplate(
                uri = "wear://7e57c0de/$wakePath",
                dataMap =
                    mapOf(
                        "from" to "watch",
                        "key" to "booleanIsChecked",
                        "type" to 0L,
                        "booleanIsChecked" to true,
                        "time" to 100L,
                    ),
            )
        val wakeWrite =
            WatchSettingSchema.buildWrite(
                cleanPath = wakePath,
                key = "booleanIsChecked",
                type = 0L,
                value = false,
                watchNode = "7e57c0de",
                phoneNode = "c0ffee12",
                template = wakeTemplate,
                now = 500L,
            )!!
        assertEquals("wear://7e57c0de/$wakePath", wakeWrite.uri)
        assertEquals(
            mapOf(
                "from" to "phone",
                "key" to "booleanIsChecked",
                "type" to 0L,
                "booleanIsChecked" to false,
                "time" to 500L,
            ),
            wakeWrite.dataMap,
        )

        val grayPath = "w_module_sec_watch_setting_accessibility/grayscale"
        val grayWrite =
            WatchSettingSchema.buildWrite(
                cleanPath = grayPath,
                key = "booleanIsChecked",
                type = 0L,
                value = true,
                watchNode = "7e57c0de",
                phoneNode = "c0ffee12",
                template = null,
                now = 600L,
            )!!
        assertEquals("wear://7e57c0de/$grayPath", grayWrite.uri)
        assertEquals(
            mapOf("booleanIsChecked" to true, "from" to "phone", "time" to 600L),
            grayWrite.dataMap,
        )

        assertNull(
            WatchSettingSchema.buildWrite(
                cleanPath = wakePath,
                key = "booleanIsChecked",
                type = 0L,
                value = false,
                watchNode = "",
                phoneNode = "c0ffee12",
            )
        )
    }

    @Test
    fun `allowPhoneOrigin 仅在显式允许时解码手机写入的快照回放`() {
        val path = "w_module_sec_watch_setting/display/wake_on_wrist_raised"
        val phoneMap = mapOf("from" to "phone", "booleanIsChecked" to true, "time" to 100L)

        assertNull(WatchSettingSchema.decode(path, phoneMap))
        val hydrated = WatchSettingSchema.decode(path, phoneMap, allowPhoneOrigin = true)!!
        assertEquals(true, hydrated.value)
        assertTrue(
            WatchSettingSchema.project(WatchSettingSchema.spec(path), WatchState(), hydrated.value)
                .wakeOnWrist
        )
    }

    @Test
    fun `仅声音设置声明支持 dataitem_value_req 回读`() {
        assertFalse(
            WatchSettingSchema.spec("w_module_sec_watch_setting/display/wake_on_wrist_raised")!!
                .supportsReadBack
        )
        assertFalse(
            WatchSettingSchema.spec("w_module_sec_watch_setting_accessibility/grayscale")!!
                .supportsReadBack
        )
        assertTrue(
            WatchSettingSchema.spec(
                    "w_module_sec_watch_setting/sound_settings/system_sounds/touch_sound"
                )!!
                .supportsReadBack
        )
        assertTrue(
            WatchSettingSchema.spec(
                    "w_module_sec_watch_setting/sound_settings/system_sounds/charging_sound"
                )!!
                .supportsReadBack
        )
    }
}
