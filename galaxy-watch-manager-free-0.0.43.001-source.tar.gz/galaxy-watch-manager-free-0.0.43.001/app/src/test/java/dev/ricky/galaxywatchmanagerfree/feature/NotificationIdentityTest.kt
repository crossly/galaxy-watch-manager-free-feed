package dev.ricky.galaxywatchmanagerfree.feature

import dev.ricky.galaxywatchmanagerfree.wcs.BridgerNotificationSender.Result
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test

class NotificationIdentityTest {
    @Test
    fun `deduplication belongs to the target connection and only accepted notifications`() {
        val cache = NotificationForwardingCache()
        val firstWatch = Any()
        val secondWatch = Any()
        val reconnected = Any()
        var sends = 0
        fun send(session: Any, result: Result = Result.WITH_ICON) =
            cache.forward(session, "synthetic-key", "synthetic-content") {
                sends++
                result
            }
        assertEquals(Result.WITH_ICON, send(firstWatch))
        assertEquals(null, send(firstWatch))
        assertEquals(Result.WITH_ICON, send(secondWatch))
        assertEquals(Result.REJECTED, send(reconnected, Result.REJECTED))
        assertEquals(Result.WITH_ICON, send(reconnected))
        assertEquals(null, send(reconnected))
        cache.remove("synthetic-key")
        assertEquals(Result.WITH_ICON, send(reconnected))
        assertEquals(5, sends)
    }

    @Test
    fun `updates keep their identity while different tags and users stay distinct`() {
        val first = NotificationIdentity("example.app", 7, "chat:a", 0, 10123)
        assertEquals(first.bridgerPath("phone"), first.copy().bridgerPath("phone"))
        assertNotEquals(first.bridgerPath("phone"), first.copy(tag = "chat:b").bridgerPath("phone"))
        assertNotEquals(first.bridgerPath("phone"), first.copy(userId = 10).bridgerPath("phone"))
        assertNotEquals(
            first.copy(tag = null).bridgerPath("phone"),
            first.copy(tag = "null").bridgerPath("phone"),
        )
        assertEquals("0|example.app|7|chat:a|10123", first.key)
    }
}
