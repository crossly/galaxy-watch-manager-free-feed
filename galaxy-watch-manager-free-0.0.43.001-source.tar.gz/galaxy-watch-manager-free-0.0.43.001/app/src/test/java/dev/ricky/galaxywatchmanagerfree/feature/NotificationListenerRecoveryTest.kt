package dev.ricky.galaxywatchmanagerfree.feature

import dev.ricky.galaxywatchmanagerfree.wcs.SessionReadiness
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class NotificationListenerRecoveryTest {
    @Test
    fun `reconnect recovers bridge after the first submission is rejected`() = runTest {
        val recovery = NotificationRecoveryAttempts(this)
        val watch = SessionReadiness()
        val submitted = mutableListOf<Int>()
        if (watch.onPeerNodeInfo(hasPhoneNode = true).notifyReady) {
            recovery.start { attempt ->
                if (attempt >= 1) submitted += attempt
                submitted.isNotEmpty()
            }
        }

        advanceUntilIdle()

        assertEquals(listOf(1), submitted)
    }

    @Test
    fun `foreground and session events share a retry while the listener is unbound`() = runTest {
        val recovery = NotificationRecoveryAttempts(this)
        val rebindTimes = mutableListOf<Long>()
        fun requestRecovery() {
            recovery.start {
                rebindTimes += testScheduler.currentTime
                false
            }
        }
        requestRecovery()
        requestRecovery()
        advanceTimeBy(2_100)
        assertEquals(listOf(0L, 2_000L), rebindTimes)

        recovery.cancel()
        advanceUntilIdle()
        assertEquals(listOf(0L, 2_000L), rebindTimes)
    }

    @Test
    fun `replacing the connection cancels the old retry and starts the new one`() = runTest {
        val recovery = NotificationRecoveryAttempts(this)
        val calls = mutableListOf<String>()
        recovery.start {
            calls += "old"
            false
        }
        runCurrent()
        recovery.cancel()
        recovery.start {
            calls += "new"
            true
        }
        advanceUntilIdle()
        assertEquals(listOf("old", "new"), calls)
    }

    @Test
    fun `persistent failure stops after the bounded retry window`() = runTest {
        val recovery = NotificationRecoveryAttempts(this)
        val attempts = mutableListOf<Int>()
        recovery.start {
            attempts += it
            false
        }
        advanceUntilIdle()
        assertEquals(listOf(0, 1, 2, 3), attempts)
    }
}
