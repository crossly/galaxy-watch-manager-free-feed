package dev.ricky.galaxywatchmanagerfree.feature

import java.io.ByteArrayOutputStream
import java.time.ZoneId
import java.util.zip.ZipInputStream
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class HealthRecordFileStoreTest {
    @Rule @JvmField val temp = TemporaryFolder()

    @Test
    fun writesReadsOverwritesAndIsolatesRecordsPerDeviceMac() {
        val dir = temp.newFolder("files")
        val first = HealthRecordFileStore(dir, "02:00:00:00:00:11")
        val second = HealthRecordFileStore(dir, "02:00:00:00:00:22")

        assertFalse(first.exists())
        assertNull(first.read())
        assertNull(first.readRecovery())

        val v1 =
            """{"schema":1,"modules":{"com.samsung.shealth.step_daily_trend":[{"count":100}]}}"""
        assertTrue(first.write(v1, durable = true))
        assertTrue(first.exists())
        assertEquals(v1, first.read())
        assertFalse(second.exists())
        assertNull(second.read())

        val v2 =
            """{"schema":1,"modules":{"com.samsung.shealth.step_daily_trend":[{"count":250}]}}"""
        assertTrue(first.write(v2, durable = false))
        assertEquals(v2, first.read())
        assertFalse(dir.listFiles().orEmpty().any { it.name.endsWith(".tmp") })
    }

    @Test
    fun recoveryBackupSurvivesAndExportsInRetainedCacheWithoutDuplicatingHealthRecords() {
        val dir = temp.newFolder("files_recovery")
        val store = HealthRecordFileStore(dir, "02:00:00:00:00:33")
        val corrupt = "{not-valid-json"
        assertTrue(store.writeRecovery(corrupt))
        assertEquals(corrupt, store.readRecovery())

        val records = HealthRecordStore()
        val now = 1_700_000_000_000L
        records.merge(
            mapOf(
                HeartRateLog.MODULE to
                    listOf(
                        JSONObject()
                            .put("datauuid", "synthetic-hr-1")
                            .put("start_time", now - 60_000L)
                            .put("heart_rate", 68)
                    )
            ),
            now,
        )
        assertTrue(store.write(records.encode(), durable = true))
        val encodedFromFile = store.read()!!

        val retainedCache =
            JSONObject()
                .put("health_records_schema", HealthRecordStore.SCHEMA_VERSION)
                .put("health_records_recovery", store.readRecovery())
        val snapshot =
            HealthExportSnapshot(
                state = WatchState(),
                sourceRecords = JSONObject(encodedFromFile),
                retainedCache = retainedCache,
            )
        val bytes = ByteArrayOutputStream()
        HealthArchive.write(bytes, snapshot, now, ZoneId.of("UTC"))
        val files = linkedMapOf<String, String>()
        ZipInputStream(bytes.toByteArray().inputStream()).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                files[entry.name] = zip.readBytes().decodeToString()
                zip.closeEntry()
            }
        }
        val exportedCache = JSONObject(files.getValue("retained_cache.json"))
        assertFalse(exportedCache.has("health_records"))
        assertEquals(corrupt, exportedCache.getString("health_records_recovery"))

        val exportedSource = JSONObject(files.getValue("source_records.json"))
        val hrRows = exportedSource.getJSONObject("modules").getJSONArray(HeartRateLog.MODULE)
        assertEquals(1, hrRows.length())
        assertEquals("synthetic-hr-1", hrRows.getJSONObject(0).getString("datauuid"))

        val measurements = JSONArray(files.getValue("measurements.json"))
        assertEquals(1, measurements.length())
        assertEquals(68.0, measurements.getJSONObject(0).getDouble("value"), 0.001)
    }
}
