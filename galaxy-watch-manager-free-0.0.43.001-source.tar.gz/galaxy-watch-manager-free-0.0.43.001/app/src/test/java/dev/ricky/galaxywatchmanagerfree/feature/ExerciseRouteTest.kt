package dev.ricky.galaxywatchmanagerfree.feature

import java.io.ByteArrayOutputStream
import java.util.Base64
import java.util.zip.GZIPOutputStream
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class ExerciseRouteTest {
    private fun point(lat: Double = 30.0, lon: Double = 110.0, time: Long = 1000) =
        JSONObject().put("latitude", lat).put("longitude", lon).put("start_time", time)

    @Test
    fun `bad first carrier does not hide compressed coordinates in next carrier`() {
        val points = JSONArray().put(point(0.0, 110.0)).put(point(30.0, 0.0))
        val bytes = ByteArrayOutputStream()
        GZIPOutputStream(bytes).use { it.write(points.toString().toByteArray()) }
        val route =
            ExerciseRoute.parse(
                JSONObject()
                    .put("location_data", "unsupported")
                    .put(
                        "location_data_internal",
                        Base64.getEncoder().encodeToString(bytes.toByteArray()),
                    )
            )
        assertEquals("location_data_internal", route.sourceField)
        assertEquals(2, route.points.size)
        assertEquals(0.0, route.points[0].latitude, 0.0)
        assertNull(route.points[0].accuracy)
        assertNull(route.points[0].version)
    }

    @Test
    fun `invalid rows and segment or clock changes break lines without sorting`() {
        val route =
            ExerciseRoute.parse(
                JSONObject()
                    .put(
                        "location_data",
                        JSONArray()
                            .put(point(time = 1000))
                            .put(point(time = 1000))
                            .put(point(0.0, 0.0))
                            .put(point(time = 2000))
                            .put(point(time = 1500))
                            .put(point(time = 3000).put("segment", 1))
                            .put(point(time = 4000).put("segment", 1)),
                    )
            )
        assertEquals(listOf(0, 1, 3, 4, 5, 6), route.points.map { it.sourceIndex })
        assertEquals(listOf(2, 1, 1, 2), route.segments.map { it.size })
    }

    @Test
    fun `optional zero values and below sea level altitude are retained`() {
        val route =
            ExerciseRoute.parse(
                JSONObject()
                    .put(
                        "com.samsung.health.exercise.location_data",
                        JSONArray()
                            .put(
                                point()
                                    .put("accuracy", 0)
                                    .put("altitude", -15.5)
                                    .put("elapsed_time", 0)
                                    .put("segment", 0)
                                    .put("version", 2)
                                    .put("source_type", 0)
                                    .put("interval", 0)
                            ),
                    )
            )
        assertEquals(0.0, route.points.single().accuracy!!, 0.0)
        assertEquals(-15.5, route.points.single().altitude!!, 0.0)
        assertEquals(0L, route.points.single().elapsedTime)
        assertEquals("com.samsung.health.exercise.location_data", route.sourceField)
    }

    @Test
    fun `missing unsupported invalid and single point states stay distinct`() {
        assertFalse(ExerciseRoute.parse(JSONObject()).payloadPresent)
        assertFalse(ExerciseRoute.parse(JSONObject().put("location", "bad")).decoded)
        val invalid =
            ExerciseRoute.parse(JSONObject().put("location", JSONArray().put(point(91.0))))
        assertTrue(invalid.decoded)
        assertEquals(1, invalid.sourcePointCount)
        assertTrue(invalid.points.isEmpty())
        assertEquals(
            1,
            ExerciseRoute.parse(JSONObject().put("location", JSONArray().put(point())))
                .segments
                .single()
                .size,
        )
    }

    @Test
    fun `content and revisions invalidate bounded per repository cache`() {
        val cache = ExerciseRoute.Cache()
        val record =
            JSONObject()
                .put("datauuid", "synthetic-route")
                .put("update_time", 1)
                .put("location_data", JSONArray().put(point()))
        val first = cache.parse(record)
        assertSame(first, cache.parse(JSONObject(record.toString())))
        record.put("location_data", JSONArray().put(point(31.0)))
        assertEquals(31.0, cache.parse(record).points.single().latitude, 0.0)
        assertEquals(30.0, first.points.single().latitude, 0.0)
        assertNotSame(
            first,
            ExerciseRoute.Cache().parse(JSONObject().put("location", JSONArray().put(point()))),
        )
    }

    @Test
    fun `large track preserves every point and source order`() {
        val points = JSONArray()
        repeat(12020) { points.put(point(30.0 + it * .000001, 110.0, 1000L + it)) }
        val route = ExerciseRoute.parse(JSONObject().put("location_data", points))
        assertEquals(12020, route.points.size)
        assertEquals(12019, route.segments.single().last().sourceIndex)
    }
}
