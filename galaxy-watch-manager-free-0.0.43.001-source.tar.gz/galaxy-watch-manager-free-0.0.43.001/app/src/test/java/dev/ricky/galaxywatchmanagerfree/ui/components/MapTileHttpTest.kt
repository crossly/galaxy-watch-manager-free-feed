package dev.ricky.galaxywatchmanagerfree.ui.components

import java.io.BufferedReader
import java.io.Closeable
import java.io.InputStreamReader
import java.net.InetAddress
import java.net.ServerSocket
import java.net.SocketException
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference
import kotlin.concurrent.thread
import okhttp3.Dispatcher
import okhttp3.Request
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class MapTileHttpTest {
    @Rule @JvmField val temp = TemporaryFolder()

    private class LocalTileServer(
        private val extraHeaders: List<String>,
        private val body: ByteArray,
    ) : Closeable {
        val server = ServerSocket(0, 8, InetAddress.getLoopbackAddress())
        val hits = AtomicInteger(0)
        val lastUserAgent = AtomicReference<String?>()
        @Volatile private var running = true

        private val worker =
            thread(isDaemon = true, name = "map-tile-test-server") {
                while (running) {
                    val socket =
                        try {
                            server.accept()
                        } catch (_: SocketException) {
                            break
                        }
                    socket.use { client ->
                        client.soTimeout = 3000
                        val reader = BufferedReader(InputStreamReader(client.getInputStream()))
                        val requestLine = reader.readLine() ?: return@use
                        if (requestLine.isEmpty()) return@use
                        while (true) {
                            val line = reader.readLine() ?: break
                            if (line.isEmpty()) break
                            if (line.startsWith("User-Agent:", ignoreCase = true)) {
                                lastUserAgent.set(line.substringAfter(':').trim())
                            }
                        }
                        hits.incrementAndGet()
                        val headerText = buildString {
                            append("HTTP/1.1 200 OK\r\n")
                            append("Content-Type: image/png\r\n")
                            for (header in extraHeaders) {
                                append(header).append("\r\n")
                            }
                            append("Content-Length: ").append(body.size).append("\r\n")
                            append("Connection: close\r\n")
                            append("\r\n")
                        }
                        val out = client.getOutputStream()
                        out.write(headerText.toByteArray(Charsets.US_ASCII))
                        out.write(body)
                        out.flush()
                    }
                }
            }

        fun url(path: String): String = "http://127.0.0.1:${server.localPort}$path"

        override fun close() {
            running = false
            runCatching { server.close() }
            worker.join(2000)
        }
    }

    @Test
    fun cachesSuccessfulTilesWithoutOriginCacheHeadersAndSharesDiskCacheAcrossDerivedClients() {
        val tileBytes = byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 1, 2, 3, 4)
        LocalTileServer(extraHeaders = listOf("Pragma: no-cache"), body = tileBytes).use { server ->
            val base = MapTileHttp.createClient(temp.newFolder("map_tiles"))
            val derivedDispatcher = Dispatcher()
            val derived = base.newBuilder().dispatcher(derivedDispatcher).build()
            try {
                val tileUrl = server.url("/tile/15/100/200.png")

                base.newCall(Request.Builder().url(tileUrl).build()).execute().use { first ->
                    assertTrue(first.isSuccessful)
                    assertNull(first.cacheResponse)
                    assertNotNull(first.networkResponse)
                    assertEquals("public, max-age=604800", first.header("Cache-Control"))
                    assertNull(first.header("Pragma"))
                    assertArrayEquals(tileBytes, first.body!!.bytes())
                }
                assertEquals(1, server.hits.get())
                assertTrue(
                    server.lastUserAgent.get().orEmpty().startsWith("GalaxyWatchManagerFree/")
                )

                base.newCall(Request.Builder().url(tileUrl).build()).execute().use { second ->
                    assertTrue(second.isSuccessful)
                    assertNotNull(second.cacheResponse)
                    assertNull(second.networkResponse)
                    assertArrayEquals(tileBytes, second.body!!.bytes())
                }
                assertEquals(1, server.hits.get())

                derived.newCall(Request.Builder().url(tileUrl).build()).execute().use { third ->
                    assertTrue(third.isSuccessful)
                    assertNotNull(third.cacheResponse)
                    assertNull(third.networkResponse)
                    assertArrayEquals(tileBytes, third.body!!.bytes())
                }
                assertEquals(1, server.hits.get())

                // Closing a derived dialog dispatcher must leave the shared base client and cache
                // usable.
                derivedDispatcher.cancelAll()
                derivedDispatcher.executorService.shutdown()

                base.newCall(Request.Builder().url(tileUrl).build()).execute().use { cached ->
                    assertTrue(cached.isSuccessful)
                    assertNotNull(cached.cacheResponse)
                    assertNull(cached.networkResponse)
                    assertArrayEquals(tileBytes, cached.body!!.bytes())
                }
                assertEquals(1, server.hits.get())

                base
                    .newCall(Request.Builder().url(server.url("/tile/15/100/201.png")).build())
                    .execute()
                    .use { fresh ->
                        assertTrue(fresh.isSuccessful)
                        assertNotNull(fresh.networkResponse)
                        assertArrayEquals(tileBytes, fresh.body!!.bytes())
                    }
                assertEquals(2, server.hits.get())
            } finally {
                derivedDispatcher.cancelAll()
                derivedDispatcher.executorService.shutdown()
                base.dispatcher.executorService.shutdown()
                base.connectionPool.evictAll()
                base.cache?.close()
            }
        }
    }

    @Test
    fun preservesExplicitOriginCacheControlHeaders() {
        val tileBytes = byteArrayOf(1, 3, 5, 7)
        LocalTileServer(extraHeaders = listOf("Cache-Control: no-store"), body = tileBytes).use {
            server ->
            val client = MapTileHttp.createClient(temp.newFolder("map_tiles_nostore"))
            try {
                val tileUrl = server.url("/tile/15/1/1.png")
                repeat(2) {
                    client.newCall(Request.Builder().url(tileUrl).build()).execute().use { response
                        ->
                        assertTrue(response.isSuccessful)
                        assertEquals("no-store", response.header("Cache-Control"))
                        assertNull(response.cacheResponse)
                        assertNotNull(response.networkResponse)
                        assertArrayEquals(tileBytes, response.body!!.bytes())
                    }
                }
                assertEquals(2, server.hits.get())
            } finally {
                client.dispatcher.executorService.shutdown()
                client.connectionPool.evictAll()
                client.cache?.close()
            }
        }
    }
}
