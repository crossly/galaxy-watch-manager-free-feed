package dev.ricky.galaxywatchmanagerfree.wcs

import java.util.concurrent.atomic.AtomicLong
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class WearAssetStoreTest {
    @Rule @JvmField val temp = TemporaryFolder()

    @Test
    fun rejectsUnsafeDigestsAndVerifiesPersistedDigest() {
        val dir = temp.newFolder("assets")
        val store = WearAssetStore(dir)
        val payload = "synthetic-asset-bytes".toByteArray()
        val digest = WcsFrame.messageDigest(payload)

        assertFalse(store.persist("../escape", payload))
        assertFalse(store.persist("sub/path", payload))
        assertFalse(store.persist("", payload))
        assertFalse(store.contains("../escape"))

        assertTrue(store.persist(digest, payload))
        assertTrue(store.contains(digest))
        assertFalse(store.contains("missingDigest123"))
    }

    @Test
    fun prunesLeastRecentlyUsedAssetsWhenFileOrByteLimitExceeded() {
        val dir = temp.newFolder("assets_prune")
        val clock = AtomicLong(1_000_000L)
        val store =
            WearAssetStore(
                directory = dir,
                maxFiles = 2,
                maxTotalBytes = 100L,
                nowMillis = { clock.addAndGet(1_000L) },
            )
        val a = ByteArray(40) { 1 }
        val b = ByteArray(40) { 2 }
        val c = ByteArray(40) { 3 }
        val digestA = WcsFrame.messageDigest(a)
        val digestB = WcsFrame.messageDigest(b)
        val digestC = WcsFrame.messageDigest(c)

        assertTrue(store.persist(digestA, a))
        assertTrue(store.persist(digestB, b))
        // Touch A so B becomes least-recently-used.
        assertTrue(store.contains(digestA))
        assertTrue(store.persist(digestC, c))

        assertTrue(store.contains(digestA))
        assertFalse(store.contains(digestB))
        assertTrue(store.contains(digestC))

        // Payload larger than total budget is rejected cleanly.
        val oversized = ByteArray(101) { 9 }
        assertFalse(store.persist(WcsFrame.messageDigest(oversized), oversized))
    }
}
