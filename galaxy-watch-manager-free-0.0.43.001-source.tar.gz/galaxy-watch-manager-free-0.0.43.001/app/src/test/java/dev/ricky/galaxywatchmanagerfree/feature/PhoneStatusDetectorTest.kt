package dev.ricky.galaxywatchmanagerfree.feature

import dev.ricky.galaxywatchmanagerfree.wcs.WcsPaths
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class PhoneStatusDetectorTest {

    @Before
    fun setUp() {
        PhoneStatusDetector.setOverrideForTest(null)
        NotificationFilterPreferences.resetForTest()
    }

    @After
    fun tearDown() {
        PhoneStatusDetector.setOverrideForTest(null)
        NotificationFilterPreferences.resetForTest()
    }

    @Test
    fun phoneIsActiveOnlyWhenScreenIsInteractiveAndKeyguardIsUnlocked() {
        // 屏幕亮起且已解锁 -> 手机处于活跃使用中
        assertTrue(
            PhoneStatusDetector.isPhoneActive(isInteractive = true, isKeyguardLocked = false)
        )

        // 屏幕亮起但锁屏未解锁 -> 处于锁屏展示，非活跃使用
        assertFalse(
            PhoneStatusDetector.isPhoneActive(isInteractive = true, isKeyguardLocked = true)
        )

        // 屏幕关闭且已解锁 -> 息屏状态，非活跃使用
        assertFalse(
            PhoneStatusDetector.isPhoneActive(isInteractive = false, isKeyguardLocked = false)
        )

        // 屏幕关闭且锁屏未解锁 -> 息屏锁定，非活跃使用
        assertFalse(
            PhoneStatusDetector.isPhoneActive(isInteractive = false, isKeyguardLocked = true)
        )
    }

    @Test
    fun testOverrideControlsActiveState() {
        PhoneStatusDetector.setOverrideForTest { true }
        assertTrue(PhoneStatusDetector.isPhoneActive(context = null))

        PhoneStatusDetector.setOverrideForTest { false }
        assertFalse(PhoneStatusDetector.isPhoneActive(context = null))
    }

    @Test
    fun shouldSkipNotificationDueToPhoneActiveDecision() {
        // 开启了“使用手机时不提醒”且手机正在使用 -> 跳过
        assertTrue(
            NotificationBridgeService.shouldSkipDueToPhoneActive(
                muteWhileUsingPhone = true,
                isPhoneActive = true,
            )
        )

        // 未开启“使用手机时不提醒”，即使手机在使用也正常转发
        assertFalse(
            NotificationBridgeService.shouldSkipDueToPhoneActive(
                muteWhileUsingPhone = false,
                isPhoneActive = true,
            )
        )

        // 手机未使用（如息屏或锁屏），即便开启了设置也不跳过
        assertFalse(
            NotificationBridgeService.shouldSkipDueToPhoneActive(
                muteWhileUsingPhone = true,
                isPhoneActive = false,
            )
        )

        // 未开启且未使用 -> 不跳过
        assertFalse(
            NotificationBridgeService.shouldSkipDueToPhoneActive(
                muteWhileUsingPhone = false,
                isPhoneActive = false,
            )
        )
    }

    @Test
    fun muteWhileUsingPhonePreferenceDefaultsToTrueAndCanBeToggled() {
        // 默认值与官方三星一致，为 true（即使用手机时手表静音/不提醒）
        assertTrue(NotificationFilterPreferences.muteWhileUsingPhone.value)

        NotificationFilterPreferences.setMuteWhileUsingPhone(false)
        assertFalse(NotificationFilterPreferences.muteWhileUsingPhone.value)

        NotificationFilterPreferences.setMuteWhileUsingPhone(true)
        assertTrue(NotificationFilterPreferences.muteWhileUsingPhone.value)
    }

    @Test
    fun alertsOnWatchProtocolMappingMatchesSamsungConvention() {
        // 官方映射：whenPhoneNotInUse = true (即 muteWhileUsingPhone = true) 对应 alerts_on_watch = 0
        // whenPhoneNotInUse = false (即 muteWhileUsingPhone = false) 对应 alerts_on_watch = 1
        fun alertsOnWatchValue(muteWhileUsingPhone: Boolean): Int =
            if (muteWhileUsingPhone) 0 else 1

        assertEquals(0, alertsOnWatchValue(muteWhileUsingPhone = true))
        assertEquals(1, alertsOnWatchValue(muteWhileUsingPhone = false))
    }

    @Test
    fun wcsPathsIncludeAlertsOnWatchConstants() {
        assertEquals("set_settings_alerts_on_watch", WcsPaths.MSG_SET_SETTINGS_ALERTS_ON_WATCH)
        assertEquals(
            "set_settings_alerts_on_watch_while_using_phone",
            WcsPaths.MSG_SET_SETTINGS_ALERTS_ON_WATCH_WHILE_USING_PHONE,
        )
    }
}
