package dev.ricky.galaxywatchmanagerfree.wcs

import java.time.Instant
import java.time.ZoneId
import java.util.TimeZone
import java.util.concurrent.TimeUnit
import org.junit.Assert.*
import org.junit.Test

class PhoneTimeSyncTest {

    private class Capture {
        val sends = mutableListOf<Pair<String, ByteArray>>()

        fun sender(): (String, ByteArray) -> Boolean = { path, payload ->
            sends.add(path to payload)
            true
        }
    }

    private fun timesync(
        capture: Capture,
        clock: () -> Long = { FIXED_NOW },
        zone: () -> TimeZone = { TimeZone.getTimeZone("UTC") },
    ): PhoneTimeSync = PhoneTimeSync(send = capture.sender(), clock = clock, timeZone = zone)

    private fun watchRequest(): ByteArray =
        DataMapEncoder.encode(
            linkedMapOf(
                PhoneTimeSync.KEY_COMMAND to 1,
                "settings.CORRELATION_ID" to "req-123",
                "settings.ELAPSED_REALTIME" to 987_654_321L,
                "settings.WATCH_REQUEST_ID" to 42,
            )
        )

    /** 直接解析 DataMap 字节，返回每个 key 的 hqc 类型标签（6=int32，5=int64，2=string）。 */
    private fun wireTypes(payload: ByteArray): Map<String, Long> {
        val out = LinkedHashMap<String, Long>()
        for (entry in Proto.parse(payload).fields[1].orEmpty()) {
            val item = Proto.parse(entry as ByteArray)
            val key = item.text(1) ?: continue
            val value = item.nested(2) ?: continue
            out[key] = value.num(1) ?: DataMapEncoder.TYPE_BYTES
        }
        return out
    }

    @Test
    fun `start sends command zero on settings rpc`() {
        val capture = Capture()
        assertTrue(timesync(capture).start())
        assertEquals(listOf(PhoneTimeSync.PATH_SETTINGS_RPC), capture.sends.map { it.first })
        val decoded = DataMapDecoder.decode(capture.sends.single().second)
        assertTrue(decoded[PhoneTimeSync.KEY_COMMAND] is Int)
        assertEquals(PhoneTimeSync.COMMAND_START, decoded[PhoneTimeSync.KEY_COMMAND])
    }

    @Test
    fun `command one replies companion time and timezone preserving every watch field`() {
        val capture = Capture()
        assertTrue(timesync(capture).receive(PhoneTimeSync.PATH_SETTINGS_RPC, watchRequest()))
        assertEquals(2, capture.sends.size)
        assertEquals(PhoneTimeSync.PATH_SETTINGS_RPC, capture.sends[0].first)
        assertEquals(PhoneTimeSync.PATH_TIMEZONE_RPC, capture.sends[1].first)

        val reply = DataMapDecoder.decode(capture.sends[0].second)
        assertTrue(reply[PhoneTimeSync.KEY_COMMAND] is Int)
        assertEquals(PhoneTimeSync.COMMAND_RESPONSE, reply[PhoneTimeSync.KEY_COMMAND])
        assertTrue(reply[PhoneTimeSync.KEY_COMPANION_TIME] is Long)
        assertEquals(FIXED_NOW, reply[PhoneTimeSync.KEY_COMPANION_TIME])
        assertEquals("req-123", reply["settings.CORRELATION_ID"])
        assertEquals(987_654_321L, reply["settings.ELAPSED_REALTIME"])
        assertEquals(42, reply["settings.WATCH_REQUEST_ID"])

        val timezone = DataMapDecoder.decode(capture.sends[1].second)
        assertEquals("UTC", timezone[PhoneTimeSync.KEY_TIME_ZONE])
        assertEquals(0, timezone[PhoneTimeSync.KEY_CURRENT_UTC_OFFSET])
        assertEquals(0, timezone[PhoneTimeSync.KEY_RAW_UTC_OFFSET])
        assertEquals(FIXED_NOW, timezone[PhoneTimeSync.KEY_OFFSET_CALC_DATE])
        assertEquals(Long.MAX_VALUE, timezone[PhoneTimeSync.KEY_TIME_CHANGE_DATE])
        assertEquals(0, timezone[PhoneTimeSync.KEY_OFFSET_AFTER_TIME_CHANGE])
    }

    @Test
    fun `reply preserves null unknown and array entries without decoding their values`() {
        val entries =
            listOf(
                Proto.string(1, "settings.NULL") + Proto.bytes(2, Proto.integer(1, 14)),
                Proto.string(1, "settings.UNKNOWN") +
                    Proto.bytes(2, Proto.integer(1, 99) + Proto.bytes(2, byteArrayOf(1, 2, 3))),
                DataMapEncoder.entry("settings.NAMES", arrayOf("synthetic-a", "synthetic-b")),
            )
        val payload =
            entries.fold(watchRequest()) { bytes, entry -> bytes + Proto.bytes(1, entry) } +
                Proto.bytes(1, DataMapEncoder.entry(PhoneTimeSync.KEY_COMPANION_TIME, 123L))
        val capture = Capture()
        assertTrue(timesync(capture).receive(PhoneTimeSync.PATH_SETTINGS_RPC, payload))
        val replyEntries = Proto.parse(capture.sends[0].second).fields[1].orEmpty()
        for (entry in entries) {
            val key = Proto.parse(entry).text(1)
            val actual = replyEntries.single { Proto.parse(it as ByteArray).text(1) == key }
            assertArrayEquals(entry, actual as ByteArray)
        }
        assertEquals(
            1,
            replyEntries.count {
                Proto.parse(it as ByteArray).text(1) == PhoneTimeSync.KEY_COMPANION_TIME
            },
        )
        assertEquals(
            FIXED_NOW,
            DataMapDecoder.decode(capture.sends[0].second)[PhoneTimeSync.KEY_COMPANION_TIME],
        )
    }

    @Test
    fun `reply bytes carry int32 command and int64 companion time`() {
        val capture = Capture()
        timesync(capture).receive(PhoneTimeSync.PATH_SETTINGS_RPC, watchRequest())
        val reply = capture.sends.first { it.first == PhoneTimeSync.PATH_SETTINGS_RPC }.second
        val types = wireTypes(reply)
        assertEquals(DataMapEncoder.TYPE_INT32, types[PhoneTimeSync.KEY_COMMAND])
        assertEquals(DataMapEncoder.TYPE_INT64, types[PhoneTimeSync.KEY_COMPANION_TIME])
    }

    @Test
    fun `timezone rpc bytes carry int32 offsets and int64 dates`() {
        val capture = Capture()
        timesync(capture).receive(PhoneTimeSync.PATH_SETTINGS_RPC, watchRequest())
        val timezone = capture.sends.first { it.first == PhoneTimeSync.PATH_TIMEZONE_RPC }.second
        val types = wireTypes(timezone)
        assertEquals(DataMapEncoder.TYPE_STRING, types[PhoneTimeSync.KEY_TIME_ZONE])
        assertEquals(DataMapEncoder.TYPE_INT32, types[PhoneTimeSync.KEY_CURRENT_UTC_OFFSET])
        assertEquals(DataMapEncoder.TYPE_INT32, types[PhoneTimeSync.KEY_RAW_UTC_OFFSET])
        assertEquals(DataMapEncoder.TYPE_INT64, types[PhoneTimeSync.KEY_OFFSET_CALC_DATE])
        assertEquals(DataMapEncoder.TYPE_INT64, types[PhoneTimeSync.KEY_TIME_CHANGE_DATE])
        assertEquals(DataMapEncoder.TYPE_INT32, types[PhoneTimeSync.KEY_OFFSET_AFTER_TIME_CHANGE])
    }

    @Test
    fun `command zero two and unknown never loop back`() {
        for (command in listOf(PhoneTimeSync.COMMAND_START, PhoneTimeSync.COMMAND_RESPONSE, 5)) {
            val capture = Capture()
            val payload = DataMapEncoder.encode(mapOf(PhoneTimeSync.KEY_COMMAND to command))
            assertTrue(timesync(capture).receive(PhoneTimeSync.PATH_SETTINGS_RPC, payload))
            assertTrue("command $command must not trigger a reply", capture.sends.isEmpty())
        }
    }

    @Test
    fun `non settings rpc paths are ignored`() {
        val capture = Capture()
        val sync = timesync(capture)
        assertFalse(sync.receive(PhoneTimeSync.PATH_TIMEZONE_RPC, watchRequest()))
        assertFalse(sync.receive("/other/rpc", watchRequest()))
        assertTrue(capture.sends.isEmpty())
    }

    @Test
    fun `malformed and mistyped payloads are rejected without throwing`() {
        val capture = Capture()
        val sync = timesync(capture)
        assertFalse(sync.receive(PhoneTimeSync.PATH_SETTINGS_RPC, ByteArray(0)))
        assertFalse(sync.receive(PhoneTimeSync.PATH_SETTINGS_RPC, byteArrayOf(0x0A, 0x7F.toByte())))
        assertFalse(sync.receive(PhoneTimeSync.PATH_SETTINGS_RPC, ByteArray(64) { it.toByte() }))
        assertFalse(
            sync.receive(
                PhoneTimeSync.PATH_SETTINGS_RPC,
                DataMapEncoder.encode(mapOf(PhoneTimeSync.KEY_COMMAND to "one")),
            )
        )
        assertFalse(
            sync.receive(
                PhoneTimeSync.PATH_SETTINGS_RPC,
                DataMapEncoder.encode(mapOf(PhoneTimeSync.KEY_COMMAND to 1L)),
            )
        )
        assertTrue(capture.sends.isEmpty())
    }

    @Test
    fun `oversized payload is rejected without throwing`() {
        val capture = Capture()
        val oversized = ByteArray(PhoneTimeSync.MAX_PAYLOAD_BYTES + 1)
        assertFalse(timesync(capture).receive(PhoneTimeSync.PATH_SETTINGS_RPC, oversized))
        assertTrue(capture.sends.isEmpty())
    }

    @Test
    fun `dst zone reports next transition and official ten day after offset`() {
        val zoneId = ZoneId.of("America/New_York")
        val transition = zoneId.rules.nextTransition(Instant.parse("2023-01-01T00:00:00Z"))!!
        val now = TimeUnit.SECONDS.toMillis(transition.toEpochSecond()) - TimeUnit.DAYS.toMillis(3)
        val capture = Capture()
        timesync(capture, clock = { now }, zone = { TimeZone.getTimeZone(zoneId.id) })
            .receive(PhoneTimeSync.PATH_SETTINGS_RPC, watchRequest())

        val timezone =
            DataMapDecoder.decode(
                capture.sends.single { it.first == PhoneTimeSync.PATH_TIMEZONE_RPC }.second
            )
        assertEquals(zoneId.id, timezone[PhoneTimeSync.KEY_TIME_ZONE])
        assertEquals(-18_000_000, timezone[PhoneTimeSync.KEY_CURRENT_UTC_OFFSET])
        assertEquals(-18_000_000, timezone[PhoneTimeSync.KEY_RAW_UTC_OFFSET])
        assertEquals(-14_400_000, timezone[PhoneTimeSync.KEY_OFFSET_AFTER_TIME_CHANGE])
        assertEquals(
            TimeUnit.SECONDS.toMillis(transition.toEpochSecond()),
            timezone[PhoneTimeSync.KEY_TIME_CHANGE_DATE],
        )
    }

    @Test
    fun `fixed offset zone reports max value transition`() {
        val capture = Capture()
        timesync(capture, zone = { TimeZone.getTimeZone("Etc/UTC") })
            .receive(PhoneTimeSync.PATH_SETTINGS_RPC, watchRequest())
        val timezone =
            DataMapDecoder.decode(
                capture.sends.single { it.first == PhoneTimeSync.PATH_TIMEZONE_RPC }.second
            )
        assertEquals("Etc/UTC", timezone[PhoneTimeSync.KEY_TIME_ZONE])
        assertEquals(Long.MAX_VALUE, timezone[PhoneTimeSync.KEY_TIME_CHANGE_DATE])
        assertEquals(0, timezone[PhoneTimeSync.KEY_OFFSET_AFTER_TIME_CHANGE])
    }

    @Test
    fun `changed timezone is honored`() {
        val tokyo = TimeZone.getTimeZone("Asia/Tokyo")
        val capture = Capture()
        timesync(capture, zone = { tokyo }).receive(PhoneTimeSync.PATH_SETTINGS_RPC, watchRequest())
        val timezone =
            DataMapDecoder.decode(
                capture.sends.single { it.first == PhoneTimeSync.PATH_TIMEZONE_RPC }.second
            )
        assertEquals("Asia/Tokyo", timezone[PhoneTimeSync.KEY_TIME_ZONE])
        assertEquals(32_400_000, timezone[PhoneTimeSync.KEY_CURRENT_UTC_OFFSET])
        assertEquals(32_400_000, timezone[PhoneTimeSync.KEY_RAW_UTC_OFFSET])
        assertEquals(Long.MAX_VALUE, timezone[PhoneTimeSync.KEY_TIME_CHANGE_DATE])
        assertEquals(32_400_000, timezone[PhoneTimeSync.KEY_OFFSET_AFTER_TIME_CHANGE])
    }

    private companion object {
        const val FIXED_NOW = 1_700_000_000_000L
    }
}
