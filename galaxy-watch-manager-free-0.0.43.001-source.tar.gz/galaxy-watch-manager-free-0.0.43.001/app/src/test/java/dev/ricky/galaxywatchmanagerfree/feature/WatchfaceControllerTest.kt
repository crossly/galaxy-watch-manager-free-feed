package dev.ricky.galaxywatchmanagerfree.feature

import dev.ricky.galaxywatchmanagerfree.wcs.WcsPaths
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject
import org.junit.After
import org.junit.Assert.*
import org.junit.Test

class WatchfaceControllerTest {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Unconfined)

    @After
    fun tearDown() {
        scope.cancel()
    }

    @Test
    fun confirmsActiveWatchfaceAndOrderMessagesAndPersistsSnapshot() {
        val state = MutableStateFlow(WatchState(sessionReady = true))
        val sent = mutableListOf<Triple<String, Int, JSONObject>>()
        var watchfaceConfirmed = 0
        var orderConfirmed = 0
        var persisted = 0
        val controller =
            WatchfaceController(
                scope = scope,
                state = state,
                sendJson = { _, msgId, msgType, data ->
                    sent += Triple(msgId, msgType, data)
                    true
                },
                onWatchfaceConfirmed = { watchfaceConfirmed++ },
                onOrderConfirmed = { orderConfirmed++ },
                onPersistSnapshot = { persisted++ },
                nowMillis = { 12_345L },
                activateConfirmDelayMs = 60_000L,
                orderConfirmDelayMs = 60_000L,
            )

        assertTrue(controller.setActive("com.example.face", "com.example.face.Main"))
        assertEquals(1, sent.size)
        assertEquals(WcsPaths.MSG_CHANGE_ACTIVE_WATCHFACE, sent[0].first)
        assertEquals(1, sent[0].second)

        // Set-command ack without identity must not mark watchface confirmed or erase state.
        controller.handleMessage(
            JSONObject()
                .put("msgId", WcsPaths.MSG_CHANGE_ACTIVE_WATCHFACE)
                .put("msgType", 3)
                .put("result", 0)
        )
        assertEquals(0, watchfaceConfirmed)
        assertEquals(0, persisted)

        controller.handleMessage(
            JSONObject()
                .put("msgId", WcsPaths.MSG_CHANGE_ACTIVE_WATCHFACE)
                .put("msgType", 3)
                .put("result", 0)
                .put(
                    "data",
                    JSONObject()
                        .put("packageName", "com.example.face")
                        .put("className", "com.example.face.Main")
                        .put("favoriteId", 7),
                )
        )
        assertEquals(1, watchfaceConfirmed)
        assertEquals(1, persisted)
        assertEquals("com.example.face", state.value.activeWatchfacePkg)
        assertEquals(7, state.value.activeWatchfaceFavoriteId)

        controller.handleMessage(
            JSONObject()
                .put("msgId", WcsPaths.MSG_WATCHFACE_ORDER)
                .put("msgType", 3)
                .put(
                    "data",
                    JSONObject()
                        .put("favoriteIdOrderList", JSONArray(listOf(7, 3, 1)))
                        .put("WatchFaceOrderType", WcsPaths.ORDER_TYPE_RECENT),
                )
        )
        assertEquals(1, orderConfirmed)
        assertEquals(2, persisted)
        assertEquals(listOf(7, 3, 1), controller.order.value)
        assertEquals(WcsPaths.ORDER_TYPE_RECENT, state.value.watchfaceOrderType)

        controller.handleMessage(
            JSONObject().put("msgId", WcsPaths.MSG_WATCHFACE_LAUNCH).put("msgType", 1)
        )
        assertTrue(state.value.watchfaceEditRequested)
        controller.clearEditRequest()
        assertFalse(state.value.watchfaceEditRequested)
        controller.cancelPending()
    }

    @Test
    fun rejectsActivationWhenSessionIsNotReady() {
        val state = MutableStateFlow(WatchState(sessionReady = false))
        var sends = 0
        val controller =
            WatchfaceController(
                scope = scope,
                state = state,
                sendJson = { _, _, _, _ ->
                    sends++
                    true
                },
                onWatchfaceConfirmed = {},
                onOrderConfirmed = {},
                onPersistSnapshot = {},
            )
        assertFalse(controller.setActive("com.example.face", "com.example.face.Main"))
        assertEquals(0, sends)
    }
}
