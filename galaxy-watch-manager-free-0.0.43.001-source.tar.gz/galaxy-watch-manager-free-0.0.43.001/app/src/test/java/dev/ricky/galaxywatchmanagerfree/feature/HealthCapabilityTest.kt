package dev.ricky.galaxywatchmanagerfree.feature

import dev.ricky.galaxywatchmanagerfree.wcs.WcsPaths
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class HealthCapabilityTest {

    @Test
    fun `buildResponse produces complete official capability payload matching watch expectations`() {
        val payload = HealthCapability.buildResponse("test-phone-node", "Pixel 9 Pro")

        assertEquals(
            HealthCapability.PROTOCOL_VERSION,
            payload.getDouble("protocol_version"),
            0.001,
        )
        assertEquals(HealthCapability.SHEALTH_VERSION, payload.getInt("shealth_version"))
        assertEquals(HealthCapability.MESSAGE_TYPE_RESPONSE, payload.getString("message_type"))
        assertEquals(HealthCapability.RESPONSE_CAPABILITY, payload.getString("capability_type"))
        assertEquals("shealth", payload.getString("sender"))
        assertEquals("wearable", payload.getString("receiver"))
        assertEquals("Pixel 9 Pro", payload.getString("model_name"))
        assertEquals("test-phone-node", payload.getString("device_id"))
        assertEquals("test-phone-node", payload.getString("connection_id"))
        assertEquals(HealthCapability.DEVICE_TYPE_PHONE, payload.getInt("device_type"))
        assertEquals(7010053, payload.getInt("shealth_version"))
        assertEquals(50001, payload.getInt("device_type"))

        val config = payload.getJSONObject("config")
        assertEquals("android", config.getString("os"))
        assertTrue(config.getString("os_version").all(Char::isDigit))
        assertEquals(-1, config.getInt("one_ui_version"))

        val tracker = payload.getJSONObject("tracker_feature")
        val vascularLoad = tracker.getJSONObject("vascular_load_feature")
        assertEquals(1002, vascularLoad.getInt("version"))
        assertTrue(vascularLoad.getBoolean("vascular_load_support"))
        val ages = tracker.getJSONObject("ages_feature")
        assertEquals(1000, ages.getInt("version"))
        assertTrue(ages.getBoolean("ages_support"))
        assertTrue(ages.getBoolean("ages_score_processing_support"))
        val antioxidant = tracker.getJSONObject("antioxidant")
        assertEquals(1, antioxidant.getInt("version"))
        assertTrue(antioxidant.getBoolean("is_supported"))
        assertTrue(tracker.getJSONObject("pedometer_sync").getBoolean("support_wearable_all_step"))
        assertTrue(tracker.getJSONObject("deep_link").getBoolean("is_support"))
        val dashboard = tracker.getJSONObject("dashboard_config_sync")
        assertEquals(1000, dashboard.getInt("version"))
        assertTrue(dashboard.getBoolean("is_support"))
        val sleepMessage = tracker.getJSONObject("sleep_message")
        assertEquals(
            HealthCapability.SLEEP_MESSAGE_VERSION,
            sleepMessage.getInt("sleep_message_version"),
        )
        assertEquals(
            HealthCapability.SLEEP_LIBRARY_VERSION,
            sleepMessage.getInt("sleep_library_version"),
        )
        assertTrue(sleepMessage.getInt("sleep_library_version") > 110500)
        assertFalse(sleepMessage.getBoolean("sleep_snore_detection_support"))
        assertFalse(sleepMessage.getBoolean("sleep_snore_detection_option_support"))
        assertFalse(sleepMessage.getBoolean("sleep_coaching_tile_support"))
        assertEquals(
            HealthCapability.SLEEP_COACHING_SOLUTION_VERSION,
            sleepMessage.getInt("sleep_coaching_current_solution_version"),
        )
        assertTrue(tracker.getJSONObject("sleep_sync").getBoolean("support"))

        val binning = payload.getJSONObject("binning")
        assertEquals(4, binning.getInt("pedometer"))
        assertEquals(10, binning.getInt("sleep"))

        val protocolFeature = payload.getJSONObject("protocol_feature")
        assertTrue(protocolFeature.getBoolean("wearable_messaging"))
        assertTrue(protocolFeature.getBoolean("compression"))
        assertEquals(30, protocolFeature.getInt("sync_duration"))
        assertEquals(10000, protocolFeature.getInt("wm_chunk_size"))
        assertTrue(protocolFeature.getBoolean("blob_compression"))

        assertEquals("gzip", payload.getJSONObject("compression").getString("format"))
        assertEquals(
            WcsPaths.HEALTH_PHONE_SYNC,
            payload.getJSONObject("sync_address").getString("common_sync"),
        )

        val wm = payload.getJSONObject("wearable_message")
        assertEquals(5.03, wm.getDouble("message_version"), 0.001)
        assertTrue(wm.getBoolean("message_support"))
        assertTrue(wm.getBoolean("message_compression"))
        assertEquals("gzip", wm.getString("message_compression_format"))
        assertEquals(10000, wm.getInt("message_size"))
    }

    @Test
    fun `isRequest and isResponse accurately classify capability JSON messages`() {
        val req = JSONObject().put("capability_type", HealthCapability.REQUEST_CAPABILITY)
        val resp = JSONObject().put("capability_type", HealthCapability.RESPONSE_CAPABILITY)
        val other = JSONObject().put("capability_type", "unknown")

        assertTrue(HealthCapability.isRequest(req))
        assertFalse(HealthCapability.isResponse(req))

        assertTrue(HealthCapability.isResponse(resp))
        assertFalse(HealthCapability.isRequest(resp))

        assertFalse(HealthCapability.isRequest(other))
        assertFalse(HealthCapability.isResponse(other))
    }

    @Test
    fun `vascularLoadSupported follows the official category version and support gate`() {
        assertTrue(HealthCapability.vascularLoadSupported(watchCapability()))
        assertEquals(1001, HealthCapability.vascularLoadVersion(watchCapability()))
        assertTrue(HealthCapability.vascularLoadSupported(watchCapability(version = 1000)))
        assertEquals(1000, HealthCapability.vascularLoadVersion(watchCapability(version = 1000)))
        assertFalse(HealthCapability.vascularLoadSupported(watchCapability(version = 999)))
        assertEquals(0, HealthCapability.vascularLoadVersion(watchCapability(version = 999)))
        assertFalse(HealthCapability.vascularLoadSupported(watchCapability(support = false)))
        assertFalse(HealthCapability.vascularLoadSupported(watchCapability(category = 40003)))
        assertFalse(HealthCapability.vascularLoadSupported(watchCapability(category = null)))
        assertTrue(
            HealthCapability.vascularLoadSupported(
                watchCapability(category = null).put("device_type", 10063)
            )
        )
        assertFalse(
            HealthCapability.vascularLoadSupported(
                watchCapability(category = null).put("device_type", 10020)
            )
        )
        assertFalse(HealthCapability.vascularLoadSupported(watchCapability(version = null)))
        assertFalse(HealthCapability.vascularLoadSupported(watchCapability(support = null)))
    }

    @Test
    fun `vascularLoadSupported rejects absent or malformed capability data`() {
        assertFalse(HealthCapability.vascularLoadSupported(JSONObject()))
        assertFalse(HealthCapability.vascularLoadSupported(JSONObject().put("category", 40001)))
        assertFalse(
            HealthCapability.vascularLoadSupported(
                JSONObject().put("category", 40001).put("tracker_feature", JSONObject())
            )
        )
        assertFalse(
            HealthCapability.vascularLoadSupported(
                JSONObject()
                    .put("category", 40001)
                    .put("tracker_feature", JSONObject().put("vascular_load_feature", "malformed"))
            )
        )
        assertFalse(
            HealthCapability.vascularLoadSupported(
                watchCapability(category = null).put("device_category", 40001)
            )
        )
        assertFalse(
            HealthCapability.vascularLoadSupported(watchCapability().put("category", "invalid"))
        )
        val malformedVersion = watchCapability()
        malformedVersion
            .getJSONObject("tracker_feature")
            .getJSONObject("vascular_load_feature")
            .put("version", "invalid")
        assertFalse(HealthCapability.vascularLoadSupported(malformedVersion))
        val malformedSupport = watchCapability()
        malformedSupport
            .getJSONObject("tracker_feature")
            .getJSONObject("vascular_load_feature")
            .put("vascular_load_support", "invalid")
        assertFalse(HealthCapability.vascularLoadSupported(malformedSupport))
    }

    @Test
    fun `buildRequest includes official phone vascular load capability`() {
        val request = HealthCapability.buildRequest("test-phone-node", "Pixel 9 Pro")
        assertEquals(HealthCapability.REQUEST_CAPABILITY, request.getString("capability_type"))
        assertEquals(
            "com.samsung.android.app.shealth.REQUEST_CAPABILITY",
            request.getString("message_type"),
        )
        assertTrue(HealthCapability.isRequest(request))
        assertFalse(HealthCapability.isResponse(request))
        val vascularLoad =
            request.getJSONObject("tracker_feature").getJSONObject("vascular_load_feature")
        assertEquals(1002, vascularLoad.getInt("version"))
        assertTrue(vascularLoad.getBoolean("vascular_load_support"))
        val sleepMessage = request.getJSONObject("tracker_feature").getJSONObject("sleep_message")
        assertEquals(1001, sleepMessage.getInt("sleep_message_version"))
        assertEquals(130500, sleepMessage.getInt("sleep_library_version"))
    }

    @Test
    fun `isWatchCategory accepts Watch 7_1_4 device types when category is absent`() {
        for (deviceType in listOf(10061, 10062, 10065, 10066, 10067, 10068)) {
            assertTrue(
                "Expected device_type=$deviceType to be recognized as watch",
                HealthCapability.isWatchCategory(JSONObject().put("device_type", deviceType)),
            )
            assertTrue(
                "Expected vascularLoadSupported for device_type=$deviceType",
                HealthCapability.vascularLoadSupported(
                    watchCapability(category = null).put("device_type", deviceType)
                ),
            )
        }
    }

    private fun watchCapability(
        category: Int? = 40001,
        version: Int? = 1001,
        support: Boolean? = true,
    ): JSONObject {
        val feature = JSONObject()
        if (version != null) feature.put("version", version)
        if (support != null) feature.put("vascular_load_support", support)
        return JSONObject().apply {
            if (category != null) put("category", category)
            put("tracker_feature", JSONObject().put("vascular_load_feature", feature))
        }
    }
}
