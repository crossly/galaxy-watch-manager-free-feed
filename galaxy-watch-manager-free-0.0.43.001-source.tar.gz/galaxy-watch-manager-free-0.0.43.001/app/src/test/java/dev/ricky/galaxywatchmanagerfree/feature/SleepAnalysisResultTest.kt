package dev.ricky.galaxywatchmanagerfree.feature

import java.io.ByteArrayOutputStream
import java.time.ZoneId
import java.util.Base64
import java.util.zip.GZIPOutputStream
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class SleepAnalysisResultTest {
    private val fixture: JSONObject
        get() = JSONObject(javaClass.getResource("/health/sleep-local-analysis.json")!!.readText())

    @Test
    fun `pending captured night has a known interval but no invented zero sleep or efficiency`() {
        val session = SleepParser.sessions(listOf(fixture.getJSONObject("record"))).single()
        assertEquals(325, session.inBedMinutes)
        assertEquals(325, session.displayMinutes)
        assertFalse(session.hasSleepDuration)
        assertNull(session.efficiencyPercent)
        assertTrue(session.segments.isEmpty())
    }

    @Test
    fun `verified half minute result produces all four stages and real sleep duration`() {
        val input = fixture
        val original = SleepParser.sessions(listOf(input.getJSONObject("record"))).single()
        val session = SleepAnalysisResult.apply(original, input.getJSONObject("result"))
        assertEquals(301, session.asleepMinutes)
        assertEquals(318, session.inBedMinutes)
        assertEquals(95, session.efficiencyPercent)
        assertEquals(
            mapOf(
                SleepParser.Stage.LIGHT to 130,
                SleepParser.Stage.DEEP to 86,
                SleepParser.Stage.REM to 85,
                SleepParser.Stage.AWAKE to 17,
            ),
            session.stageMinutes,
        )
        assertEquals(original.endMillis, session.recordedEndMillis)
        assertEquals(61, session.segments.size)
        assertEquals(SleepAnalysisResult.SOURCE, session.analysisSource)
        assertEquals(session, SleepParser.decode(SleepParser.encode(session)))
    }

    @Test
    fun `projection uses local analysis only when received stage records are absent`() {
        val input = fixture
        val record = input.getJSONObject("record")
        val source = SleepParser.sessions(listOf(record)).single()
        val local = SleepAnalysisResult.apply(source, input.getJSONObject("result"))
        val store = HealthRecordStore()
        val now = source.endMillis + 60_000
        store.merge(mapOf(SleepParser.MODULE_SLEEP to listOf(record)), now)
        val zone = ZoneId.of("Asia/Shanghai")
        val unresolved = HealthDataProjection.build(store, now, zone)
        assertTrue(unresolved.sleepHistory.isEmpty())
        val resolved = HealthDataProjection.build(store, now, zone, mapOf(source.id to local))
        assertEquals(301, resolved.sleepHistory["2026-10-28"])
        assertEquals(local, resolved.sleepSessions.single())
        store.merge(
            mapOf(
                SleepParser.MODULE_SLEEP_STAGE_LEGACY to
                    listOf(
                        JSONObject()
                            .put("datauuid", "watch-stage")
                            .put("sleep_id", source.id)
                            .put("start_time", source.startMillis)
                            .put("end_time", source.endMillis)
                            .put("stage", 40003)
                    )
            ),
            now,
        )
        val received =
            HealthDataProjection.build(store, now, zone, mapOf(source.id to local))
                .sleepSessions
                .single()
        assertNull(received.analysisSource)
        assertEquals(325, received.stageMinutes[SleepParser.Stage.DEEP])
    }

    @Test
    fun `invalid inferred stage never becomes an apparently complete report`() {
        val input = fixture
        val source = SleepParser.sessions(listOf(input.getJSONObject("record"))).single()
        input.getJSONObject("result").getJSONArray("stages").getJSONArray(0).put(1, 99)
        assertTrue(
            runCatching { SleepAnalysisResult.apply(source, input.getJSONObject("result")) }
                .isFailure
        )
    }

    @Test
    fun `analysis cache export preserves detached history and original result fields`() {
        val earlier =
            SleepParser.Session(
                startMillis = 1_700_000_000_000L,
                endMillis = 1_700_003_600_000L,
                segments = emptyList(),
                efficiency = 90,
                score = null,
                reportedSleepMinutes = 54,
                id = "earlier-night",
                analysisSource = "local-engine/v1",
            )
        val later =
            earlier.copy(
                startMillis = earlier.startMillis + 86_400_000L,
                endMillis = earlier.endMillis + 86_400_000L,
                id = "later-night",
                analysisSource = "local-engine/v2",
            )
        val encodedEarlier = JSONObject(SleepParser.encode(earlier)).put("model_revision", 1)
        val values =
            linkedMapOf(
                "earlier-key" to encodedEarlier.toString(),
                "later-key" to SleepParser.encode(later),
            )
        val exported = LocalSleepAnalyzer.retainedResults(values)
        values.clear()
        assertEquals(setOf("earlier-key", "later-key"), exported.keys().asSequence().toSet())
        val first = exported.getJSONObject("earlier-key")
        assertEquals(earlier, SleepParser.decode(first.toString()))
        assertEquals(1, first.getInt("model_revision"))
        assertEquals(later, SleepParser.decode(exported.getJSONObject("later-key").toString()))
    }

    @Test
    fun `analysis cache export skips preference bookkeeping and unreadable values`() {
        val session =
            SleepParser.Session(
                startMillis = 1_700_000_000_000L,
                endMillis = 1_700_003_600_000L,
                segments = emptyList(),
                efficiency = null,
                score = null,
                reportedSleepMinutes = 54,
                id = "cached-night",
            )
        val exported =
            LocalSleepAnalyzer.retainedResults(
                linkedMapOf(
                    "cached-key" to SleepParser.encode(session),
                    "device_cache_initialized" to true,
                    "legacy-key" to "not-json",
                )
            )
        assertEquals(setOf("cached-key"), exported.keys().asSequence().toSet())
        assertEquals(session, SleepParser.decode(exported.getJSONObject("cached-key").toString()))
    }

    @Test
    fun `raw sensor rows survive record store restart instead of being silently dropped`() {
        val record = fixture.getJSONObject("record")
        val raw =
            JSONObject()
                .put("datauuid", "raw-night")
                .put("sleep_uuid", "pending-night")
                .put("data", "test-payload")
                .put("create_time", record.getLong("end_time"))
        val store = HealthRecordStore()
        store.merge(
            mapOf(
                SleepParser.MODULE_SLEEP to listOf(record),
                SleepParser.MODULE_SLEEP_RAW to listOf(raw),
            ),
            record.getLong("end_time"),
        )
        val restored = HealthRecordStore()
        restored.restore(store.encode(), record.getLong("end_time"))
        assertEquals(
            "test-payload",
            restored.records(SleepParser.MODULE_SLEEP_RAW).single().getString("data"),
        )
    }

    @Test
    fun `sixty second 7-ACC analysis result applies with SOURCE_7ACC and computes SleepScore`() {
        val start = 1_793_125_440_000L
        val epochMs = SleepAnalysisResult.EPOCH_MS_7ACC
        val totalMinutes = 360
        val record =
            JSONObject()
                .put("datauuid", "night-7acc")
                .put("start_time", start)
                .put("end_time", start + totalMinutes * epochMs)
                .put("has_sleep_data", -1)
        val stages = JSONArray()
        for (i in 0 until totalMinutes) {
            val code =
                when {
                    i < 10 -> 2 // AWAKE
                    i < 190 -> 1 // LIGHT (180m)
                    i < 280 -> 0 // DEEP (90m)
                    else -> 3 // REM (80m)
                }
            stages.put(JSONArray().put(start + i * epochMs).put(code))
        }
        val result =
            JSONObject()
                .put("native_efficiency", 97)
                .put("epoch_ms", epochMs)
                .put("source", SleepAnalysisResult.SOURCE_7ACC)
                .put("stages", stages)
        val source = SleepParser.sessions(listOf(record)).single()
        val applied = SleepAnalysisResult.apply(source, result)
        assertEquals(SleepAnalysisResult.SOURCE_7ACC, applied.analysisSource)
        assertEquals(350, applied.asleepMinutes)
        assertEquals(360, applied.inBedMinutes)
        assertEquals(4, applied.segments.size)
        assertEquals(90, applied.stageMinutes[SleepParser.Stage.DEEP])
        assertEquals(80, applied.stageMinutes[SleepParser.Stage.REM])
        assertEquals(180, applied.stageMinutes[SleepParser.Stage.LIGHT])
        assertEquals(10, applied.stageMinutes[SleepParser.Stage.AWAKE])
        assertNotNull(applied.computedScore)
        assertEquals(SleepScore.SOURCE, applied.displayScoreSource)
        assertEquals(applied, SleepParser.decode(SleepParser.encode(applied)))
    }

    @Test
    fun `decodeRawPayload handles gzipped base64 plain JSON and JSONObject with size bound`() {
        val plain = """{"version":1,"data":[]}"""
        val bos = ByteArrayOutputStream()
        GZIPOutputStream(bos).use { it.write(plain.toByteArray(Charsets.UTF_8)) }
        val encoded = Base64.getEncoder().encodeToString(bos.toByteArray())

        assertEquals(plain, LocalSleepAnalyzer.decodeRawPayload(JSONObject().put("data", encoded)))
        assertEquals(plain, LocalSleepAnalyzer.decodeRawPayload(JSONObject().put("data", plain)))
        assertEquals(
            1,
            JSONObject(
                    LocalSleepAnalyzer.decodeRawPayload(JSONObject().put("data", JSONObject(plain)))
                )
                .getInt("version"),
        )

        val oversized = "{" + " ".repeat(8 * 1024 * 1024 + 16) + "}"
        assertTrue(
            runCatching { LocalSleepAnalyzer.decodeRawPayload(JSONObject().put("data", oversized)) }
                .isFailure
        )
    }

    @Test
    fun `analyze7Acc executes 7-ACC preprocessing alignment trailing wake trim and four-stage gate`() {
        val start = 1_793_125_440_000L
        val epochMs = SleepAnalysisResult.EPOCH_MS_7ACC
        val session =
            JSONObject()
                .put("datauuid", "watch-714-v1")
                .put("start_time", start)
                .put("end_time", start + 25 * epochMs)
                .put("bedtime_detection_delay", 2 * epochMs)
                .put("wakeup_time_detection_delay", 0L)

        val dataArray = JSONArray()
        for (i in 0 until 20) {
            val acc = JSONArray(listOf(0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7))
            val rri =
                JSONArray()
                    .put(JSONArray(listOf(0, 100, 820)))
                    .put(JSONArray(listOf(0, 920, 65535)))
            dataArray.put(JSONObject().put("acc", acc).put("rri_info", rri))
        }
        val raw = JSONObject().put("version", 1).put("data", dataArray)

        var initCalled = false
        val fedAcc = mutableListOf<DoubleArray>()
        val fedRri = mutableListOf<DoubleArray>()
        var efficiencyInputSize = 0
        val fakeNative =
            object : LocalSleepAnalyzer.Sleep7AccNative {
                override fun init() {
                    initCalled = true
                }

                override fun feedEpoch(acc: DoubleArray, rri: DoubleArray) {
                    fedAcc.add(acc)
                    fedRri.add(rri)
                }

                override fun predictStages(): IntArray =
                    // 13 non-wake epochs + 7 trailing wake epochs (> 5 -> trim keeping 2)
                    IntArray(20) { idx ->
                        when {
                            idx < 5 -> 1 // LIGHT
                            idx < 10 -> 0 // DEEP
                            idx < 13 -> 3 // REM
                            else -> 2 // AWAKE
                        }
                    }

                override fun efficiency(stages: IntArray): Int {
                    efficiencyInputSize = stages.size
                    return 91
                }
            }

        val result = LocalSleepAnalyzer.analyze7Acc(session, raw, fakeNative)
        assertTrue(initCalled)
        assertEquals(20, fedAcc.size)
        assertTrue(fedAcc.all { it.size == 7 })
        // Packed RRI: [4.0, 100.0, 820.0, 920.0, -1.0]
        assertArrayEquals(doubleArrayOf(4.0, 100.0, 820.0, 920.0, -1.0), fedRri.first(), 0.001)
        assertEquals(epochMs, result.getLong("epoch_ms"))
        assertEquals(SleepAnalysisResult.SOURCE_7ACC, result.getString("source"))
        assertEquals(91, result.getInt("native_efficiency"))

        val stages = result.getJSONArray("stages")
        assertEquals(efficiencyInputSize, stages.length())
        // 25 target epochs, 2 leading LIGHT padding from bedtime_detection_delay,
        // and trailing wake (>5) trimmed so at most 2 trailing wake epochs remain.
        assertTrue(stages.length() < 25)
        assertEquals(1, stages.getJSONArray(0).getInt(1))
        assertEquals(1, stages.getJSONArray(1).getInt(1))
        var trailingWake = 0
        for (i in stages.length() - 1 downTo 0) {
            if (stages.getJSONArray(i).getInt(1) == 2) trailingWake++ else break
        }
        assertEquals(2, trailingWake)

        val sourceSession = SleepParser.sessions(listOf(session)).single()
        val applied = SleepAnalysisResult.apply(sourceSession, result)
        assertEquals(SleepAnalysisResult.SOURCE_7ACC, applied.analysisSource)
        assertEquals(sourceSession.endMillis, applied.recordedEndMillis)
        assertTrue(applied.segments.isNotEmpty())
        assertNotNull(applied.computedScore)
    }

    @Test
    fun `analyze7Acc rejects session when more than 70 percent of valid RRIs are zero`() {
        val start = 1_793_125_440_000L
        val epochMs = SleepAnalysisResult.EPOCH_MS_7ACC
        val session =
            JSONObject()
                .put("datauuid", "watch-714-zero-rri")
                .put("start_time", start)
                .put("end_time", start + 10 * epochMs)
        val dataArray = JSONArray()
        for (i in 0 until 10) {
            val acc = JSONArray(listOf(0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7))
            val rriValue = if (i < 8) 0 else 800
            val rri = JSONArray().put(JSONArray(listOf(0, 100, rriValue)))
            dataArray.put(JSONObject().put("acc", acc).put("rri_info", rri))
        }
        val raw = JSONObject().put("version", 1).put("data", dataArray)
        val fakeNative =
            object : LocalSleepAnalyzer.Sleep7AccNative {
                override fun init() = Unit

                override fun feedEpoch(acc: DoubleArray, rri: DoubleArray) = Unit

                override fun predictStages(): IntArray = IntArray(10) { 1 }

                override fun efficiency(stages: IntArray): Int = 100
            }
        assertTrue(
            runCatching { LocalSleepAnalyzer.analyze7Acc(session, raw, fakeNative) }.isFailure
        )
    }
}
