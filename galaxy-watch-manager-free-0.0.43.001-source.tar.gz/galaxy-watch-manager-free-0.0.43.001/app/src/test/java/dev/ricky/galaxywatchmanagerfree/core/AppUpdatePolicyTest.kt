package dev.ricky.galaxywatchmanagerfree.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AppUpdatePolicyTest {

    @Test
    fun `invalid, unknown schema, wrong package, or ambiguous force update fail open`() {
        assertNull(AppUpdatePolicy.parsePolicy("not json"))
        assertNull(AppUpdatePolicy.parsePolicy("<html>502 Bad Gateway</html>"))
        assertNull(AppUpdatePolicy.parsePolicy("{}"))
        assertNull(
            AppUpdatePolicy.parsePolicy(
                """{"schema_version":2,"package":"dev.ricky.galaxywatchmanagerfree","mode":"block"}"""
            )
        )
        assertNull(
            AppUpdatePolicy.parsePolicy(
                """{"schema_version":1,"package":"com.other.app","mode":"block"}"""
            )
        )
        assertNull(
            AppUpdatePolicy.parsePolicy(
                """{"schema_version":1,"package":"dev.ricky.galaxywatchmanagerfree","mode":"unknown"}"""
            )
        )
        // Ambiguous force_update without threshold or targeted versions must never block users.
        assertNull(
            AppUpdatePolicy.parsePolicy(
                """{"schema_version":1,"package":"dev.ricky.galaxywatchmanagerfree","mode":"force_update"}"""
            )
        )
        assertEquals(AppUpdatePolicy.Decision.Allow, AppUpdatePolicy.evaluate(null, 42000))
    }

    @Test
    fun `mode none always allows`() {
        val policy =
            AppUpdatePolicy.parsePolicy(
                """
                {
                  "schema_version": 1,
                  "package": "dev.ricky.galaxywatchmanagerfree",
                  "mode": "none",
                  "min_supported_version_code": 999999
                }
                """
                    .trimIndent()
            )!!
        assertEquals(AppUpdatePolicy.Decision.Allow, AppUpdatePolicy.evaluate(policy, 42000))
    }

    @Test
    fun `force update matches versions below threshold or explicitly blocked`() {
        val policy =
            AppUpdatePolicy.parsePolicy(
                """
                {
                  "schema_version": 1,
                  "package": "dev.ricky.galaxywatchmanagerfree",
                  "mode": "force_update",
                  "min_supported_version_code": 43000,
                  "blocked_version_codes": [43001],
                  "target_version_name": "v0.0.44",
                  "target_version_code": 44000,
                  "title": "Update required",
                  "title_zh": "请更新应用",
                  "message": "Critical bug fix.",
                  "message_zh": "修复了重要问题，请更新。",
                  "action_url": "https://github.com/crossly/galaxy-watch-manager-free-feed"
                }
                """
                    .trimIndent()
            )!!

        assertEquals("0.0.44", policy.targetVersionName)
        assertEquals("请更新应用", policy.localizedTitle(isChinese = true))
        assertEquals("Update required", policy.localizedTitle(isChinese = false))
        assertEquals("修复了重要问题，请更新。", policy.localizedMessage(isChinese = true))
        assertEquals("https://github.com/crossly/galaxy-watch-manager-free-feed", policy.actionUrl)

        assertTrue(AppUpdatePolicy.evaluate(policy, 42000) is AppUpdatePolicy.Decision.ForceUpdate)
        assertTrue(AppUpdatePolicy.evaluate(policy, 43001) is AppUpdatePolicy.Decision.ForceUpdate)
        assertEquals(AppUpdatePolicy.Decision.Allow, AppUpdatePolicy.evaluate(policy, 43000))
        assertEquals(AppUpdatePolicy.Decision.Allow, AppUpdatePolicy.evaluate(policy, 44000))
    }

    @Test
    fun `block mode supports both full kill-switch and targeted version blocking`() {
        val killSwitchAll =
            AppUpdatePolicy.parsePolicy(
                """
                {
                  "schema_version": 1,
                  "package": "dev.ricky.galaxywatchmanagerfree",
                  "mode": "block",
                  "title_zh": "应用已下架",
                  "message_zh": "服务已暂停"
                }
                """
                    .trimIndent()
            )!!
        assertTrue(AppUpdatePolicy.evaluate(killSwitchAll, 42000) is AppUpdatePolicy.Decision.Block)
        assertTrue(
            AppUpdatePolicy.evaluate(killSwitchAll, 999999) is AppUpdatePolicy.Decision.Block
        )

        val targetedBlock =
            AppUpdatePolicy.parsePolicy(
                """
                {
                  "schema_version": 1,
                  "package": "dev.ricky.galaxywatchmanagerfree",
                  "mode": "block",
                  "blocked_version_codes": [42000]
                }
                """
                    .trimIndent()
            )!!
        assertTrue(AppUpdatePolicy.evaluate(targetedBlock, 42000) is AppUpdatePolicy.Decision.Block)
        assertEquals(AppUpdatePolicy.Decision.Allow, AppUpdatePolicy.evaluate(targetedBlock, 43000))
    }

    @Test
    fun `untrusted action urls and literal null strings are stripped safely`() {
        val policy =
            AppUpdatePolicy.parsePolicy(
                """
                {
                  "schema_version": 1,
                  "package": "dev.ricky.galaxywatchmanagerfree",
                  "mode": "block",
                  "title": "null",
                  "title_zh": null,
                  "message": "  ",
                  "action_url": "https://evil.example/redirect"
                }
                """
                    .trimIndent()
            )
        assertNotNull(policy)
        assertNull(policy!!.title)
        assertNull(policy.titleZh)
        assertNull(policy.message)
        assertNull(policy.actionUrl)
        assertFalse(AppUpdatePolicy.isTrustedActionUrl("http://github.com/crossly/feed"))
        assertFalse(AppUpdatePolicy.isTrustedActionUrl("https://github.com.evil.example/feed"))
        assertTrue(
            AppUpdatePolicy.isTrustedActionUrl(
                "https://github.com/crossly/galaxy-watch-manager-free-feed"
            )
        )
    }

    @Test
    fun `candidate mirrors prioritize user choice and fall back across China-accessible mirrors`() {
        assertEquals(
            listOf(
                DownloadMirror.OFF,
                DownloadMirror.GH_PROXY,
                DownloadMirror.GH_PROXY_NET,
                DownloadMirror.GH_FAST,
            ),
            AppUpdatePolicy.candidateMirrors(DownloadMirror.OFF),
        )
        assertEquals(
            listOf(
                DownloadMirror.GH_FAST,
                DownloadMirror.GH_PROXY,
                DownloadMirror.GH_PROXY_NET,
                DownloadMirror.OFF,
            ),
            AppUpdatePolicy.candidateMirrors(DownloadMirror.GH_FAST),
        )
    }

    @Test
    fun `cached policy expires after TTL and clears immediately after upgrading versionCode`() {
        val now = 1_795_700_000_000L
        assertTrue(
            AppUpdatePolicy.isCachedPolicyValid(
                cachedForVersionCode = 42000,
                currentVersionCode = 42000,
                fetchedAt = now - 3_600_000L,
                now = now,
            )
        )
        // Upgraded app version invalidates old cached block immediately.
        assertFalse(
            AppUpdatePolicy.isCachedPolicyValid(
                cachedForVersionCode = 42000,
                currentVersionCode = 43000,
                fetchedAt = now - 1_000L,
                now = now,
            )
        )
        // Expired cache fails open instead of bricking offline users forever.
        assertFalse(
            AppUpdatePolicy.isCachedPolicyValid(
                cachedForVersionCode = 42000,
                currentVersionCode = 42000,
                fetchedAt = now - AppUpdatePolicy.DEFAULT_CACHE_TTL_MS,
                now = now,
            )
        )
    }

    @Test
    fun `not-found clearing accepts direct 404 or independent mirror quorum without single-mirror bypass`() {
        assertTrue(
            AppUpdatePolicy.shouldTreatNotFoundAsCleared(
                directNotFound = true,
                distinctMirrorNotFoundCount = 0,
            )
        )
        assertFalse(
            AppUpdatePolicy.shouldTreatNotFoundAsCleared(
                directNotFound = false,
                distinctMirrorNotFoundCount = 0,
            )
        )
        assertFalse(
            AppUpdatePolicy.shouldTreatNotFoundAsCleared(
                directNotFound = false,
                distinctMirrorNotFoundCount = 1,
            )
        )
        assertTrue(
            AppUpdatePolicy.shouldTreatNotFoundAsCleared(
                directNotFound = false,
                distinctMirrorNotFoundCount = 2,
            )
        )
        assertTrue(
            AppUpdatePolicy.shouldTreatNotFoundAsCleared(
                directNotFound = false,
                distinctMirrorNotFoundCount = 3,
            )
        )
    }

    @Test
    fun `force-update only auto-offers an APK that is newer and satisfies the active policy`() {
        val policy =
            AppUpdatePolicy.Policy(
                mode = AppUpdatePolicy.Mode.FORCE_UPDATE,
                minSupportedVersionCode = 43000,
                blockedVersionCodes = setOf(43001),
            )
        fun release(name: String, code: Int?, apkUrl: String? = "https://github.com/r/app.apk") =
            AppUpdate.ReleaseInfo(
                versionName = name,
                versionCode = code,
                pageUrl = "https://github.com/r",
                notes = "",
                publishedAt = null,
                apkName = "app.apk",
                sha256 = "a".repeat(64),
                apkUrl = apkUrl,
                apkSize = 1024L,
                channel = AppUpdate.Channel.STABLE,
            )

        assertFalse(
            AppUpdatePolicy.isReleaseEligibleForForceUpdate(
                policy,
                "0.0.42",
                42000,
                release("0.0.42", 42000),
            )
        )
        assertFalse(
            AppUpdatePolicy.isReleaseEligibleForForceUpdate(
                policy,
                "0.0.41",
                41000,
                release("0.0.42", 42000),
            )
        )
        assertFalse(
            AppUpdatePolicy.isReleaseEligibleForForceUpdate(
                policy,
                "0.0.42",
                42000,
                release("0.0.43.001", 43001),
            )
        )
        assertFalse(
            AppUpdatePolicy.isReleaseEligibleForForceUpdate(
                policy,
                "0.0.42",
                42000,
                release("0.0.43", 43000, apkUrl = null),
            )
        )
        assertTrue(
            AppUpdatePolicy.isReleaseEligibleForForceUpdate(
                policy,
                "0.0.42",
                42000,
                release("0.0.43", 43000),
            )
        )
    }
}
