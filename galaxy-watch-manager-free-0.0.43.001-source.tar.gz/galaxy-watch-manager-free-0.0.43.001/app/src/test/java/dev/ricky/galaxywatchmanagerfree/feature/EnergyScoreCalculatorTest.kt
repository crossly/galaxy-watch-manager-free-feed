package dev.ricky.galaxywatchmanagerfree.feature

import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import kotlin.math.exp
import kotlin.math.ln
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class EnergyScoreCalculatorTest {
    private val date = LocalDate.of(2026, 11, 18)
    private val zone = ZoneId.of("Asia/Shanghai")
    private val now = date.atTime(18, 0).atZone(zone).toInstant().toEpochMilli()

    private fun millis(time: LocalDateTime) = time.atZone(zone).toInstant().toEpochMilli()

    private fun session(
        day: LocalDate = date,
        id: String = "synthetic-sleep",
        startHour: Int = 23,
        hours: Long = 8,
    ): SleepParser.Session {
        val start = (if (startHour == 23) day.minusDays(1) else day).atTime(startHour, 0)
        val end = start.plusHours(hours)
        return SleepParser.Session(
            millis(start),
            millis(end),
            listOf(SleepParser.Segment(millis(start), millis(end), SleepParser.Stage.LIGHT)),
            null,
            null,
            id = id,
        )
    }

    private fun sleep(
        day: LocalDate = date,
        hour: Int = 1,
        hours: Long = 8,
        nap: Boolean = false,
    ): EnergyScoreCalculator.Sleep {
        val start = day.atTime(hour, 0)
        val end = start.plusHours(hours)
        return EnergyScoreCalculator.Sleep(
            "synthetic-$day-$hour",
            day,
            millis(start),
            millis(end),
            start,
            end,
            listOf(start to end),
            "synthetic-device",
            nap,
        )
    }

    private fun store(
        sessions: List<SleepParser.Session> = listOf(session()),
        hrv: Boolean = true,
        active: Long? = 90 * 60_000L,
    ): HealthRecordStore {
        val data =
            linkedMapOf(
                SleepParser.MODULE_SLEEP to
                    sessions.map { s ->
                        JSONObject()
                            .put("datauuid", s.id)
                            .put("deviceuuid", "synthetic-device")
                            .put("start_time", s.startMillis)
                            .put("end_time", s.endMillis)
                            .put("update_time", now)
                    },
                HeartRateLog.MODULE to
                    sessions.flatMap { s ->
                        listOf(
                            JSONObject()
                                .put("datauuid", "hr-${s.id}-a")
                                .put("start_time", s.startMillis)
                                .put("end_time", s.startMillis + 2 * 3_600_000L)
                                .put("heart_rate", 50),
                            JSONObject()
                                .put("datauuid", "hr-${s.id}-b")
                                .put("start_time", s.startMillis + 2 * 3_600_000L)
                                .put("end_time", s.endMillis)
                                .put("heart_rate", 70),
                        )
                    },
            )
        if (hrv)
            data[HealthMetric.HRV.moduleKeys.first()] =
                sessions.map { s ->
                    JSONObject()
                        .put("datauuid", "hrv-${s.id}")
                        .put("start_time", s.startMillis)
                        .put("end_time", s.endMillis)
                        .put("rmssd", 40)
                }
        if (active != null)
            data[HealthStepParser.MODULE_DAY_SUMMARY] =
                listOf(
                    JSONObject()
                        .put("datauuid", "synthetic-activity")
                        .put("day_time", date.minusDays(1).toString())
                        .put("active_time", active)
                        .put("update_time", now)
                )
        return HealthRecordStore().apply { merge(data, now) }
    }

    @Test
    fun `grade and total use piecewise scales and official factor weights`() {
        listOf(1f to 1f, 70f to 60f, 80f to 75f, 90f to 85f, 100f to 100f).forEach { (raw, scaled)
            ->
            assertEquals(scaled, EnergyScoreCalculator.grade(raw), 0.0001f)
            assertEquals(raw, EnergyScoreCalculator.ungrade(scaled), 0.0001f)
        }
        assertEquals(78.2f, EnergyScoreCalculator.total(100f, 85f, 75f, 60f)!!, 0.0001f)
        assertEquals(1f, EnergyScoreCalculator.grade(0f), 0f)
        assertEquals(-1f, EnergyScoreCalculator.grade(Float.NaN), 0f)
        assertNull(EnergyScoreCalculator.total(100f, -1f, 75f, 60f))
        assertNull(EnergyScoreCalculator.total(100f, Float.NaN, 75f, 60f))
    }

    @Test
    fun `activity needs yesterday and truncates subminute loads before EMA`() {
        assertNull(
            EnergyScoreCalculator.activityScore(mapOf(date.minusDays(2) to 3_600_000L), date, false)
        )
        assertNull(EnergyScoreCalculator.activityScore(mapOf(date.minusDays(1) to 0L), date, false))
        val minute =
            EnergyScoreCalculator.activityFactors(
                mapOf(date.minusDays(1) to 60_000L),
                date,
                false,
            )!!
        val extra =
            EnergyScoreCalculator.activityFactors(
                mapOf(date.minusDays(1) to 119_999L),
                date,
                false,
            )!!
        assertEquals(minute.score, extra.score, 0f)
        assertEquals(minute.longTerm, extra.longTerm, 0f)
        assertEquals(119_999L, extra.activeMillis)
        assertNotEquals(
            minute.score,
            EnergyScoreCalculator.activityFactors(
                    mapOf(date.minusDays(1) to 120_000L),
                    date,
                    false,
                )!!
                .score,
        )
    }

    @Test
    fun `HRV baseline uses logarithms and low baseline penalty without conflating SDNN`() {
        val single = EnergyScoreCalculator.hrvFactors(40f, listOf(40f), 30, false)
        assertEquals(exp((3.68f + ln(40f)) / 2f), single.baseline, 0.0001f)
        val geometric = EnergyScoreCalculator.hrvFactors(80f, listOf(20f, 80f), 30, true)
        assertEquals(40f, geometric.baseline, 0.0001f)
        val low = EnergyScoreCalculator.hrvFactors(10f, listOf(10f, 10f), 30, false)
        assertTrue(low.penalty)
        assertEquals(75f, low.score, 0.0001f)
        assertEquals(100f, low.balanceScale, 0.0001f)
    }

    @Test
    fun `main sleep is longest per wake date while explicit and manual naps stay naps`() {
        val main = session()
        val shorter = session(id = "synthetic-short", startHour = 12, hours = 1)
        val manual =
            shorter.copy(
                id = "manual:synthetic",
                startMillis = shorter.startMillis + 7_200_000L,
                endMillis = shorter.endMillis + 7_200_000L,
                segments = emptyList(),
            )
        val result =
            EnergyScoreCalculator.sleeps(
                store(listOf(main, shorter)),
                zone,
                listOf(main, shorter, manual),
            )
        assertFalse(result.first { it.id == main.id }.isNap)
        assertTrue(result.first { it.id == shorter.id }.isNap)
        assertTrue(result.first { it.id == manual.id }.isNap)
        val explicit = store(listOf(main, shorter))
        explicit.merge(
            mapOf(
                SleepParser.MODULE_SLEEP to
                    listOf(
                        JSONObject()
                            .put("datauuid", main.id)
                            .put("start_time", main.startMillis)
                            .put("end_time", main.endMillis)
                            .put("is_nap", true)
                            .put("update_time", now + 1)
                    )
            ),
            now,
        )
        val classified = EnergyScoreCalculator.sleeps(explicit, zone, listOf(main, shorter))
        assertTrue(classified.first { it.id == main.id }.isNap)
        assertFalse(classified.first { it.id == shorter.id }.isNap)
    }

    @Test
    fun `main sleep selection uses recorded wake date when phone timezone changes`() {
        val main = session()
        val shorter = session(id = "synthetic-late", startHour = 22, hours = 1)
        val sessions = listOf(main, shorter)
        val records = store(sessions)
        records.merge(
            mapOf(
                SleepParser.MODULE_SLEEP to
                    sessions.map { s ->
                        JSONObject()
                            .put("datauuid", s.id)
                            .put("start_time", s.startMillis)
                            .put("end_time", s.endMillis)
                            .put("time_offset", 28_800_000)
                            .put("update_time", now + 1)
                    }
            ),
            now,
        )
        val result =
            EnergyScoreCalculator.sleeps(records, ZoneId.of("America/Los_Angeles"), sessions)
        assertEquals(setOf(date), result.map { it.date }.toSet())
        assertFalse(result.first { it.id == main.id }.isNap)
        assertTrue(result.first { it.id == shorter.id }.isNap)
    }

    @Test
    fun `recorded offset keeps sleep owning date across phone timezone changes`() {
        val s =
            session()
                .copy(
                    startMillis = millis(date.atTime(23, 0)),
                    endMillis = millis(date.plusDays(1).atTime(7, 0)),
                    segments = emptyList(),
                )
        val records = store(listOf(s))
        records.merge(
            mapOf(
                SleepParser.MODULE_SLEEP to
                    listOf(
                        JSONObject()
                            .put("datauuid", s.id)
                            .put("start_time", s.startMillis)
                            .put("end_time", s.endMillis)
                            .put("time_offset", 28_800_000)
                            .put("update_time", now + 1)
                    )
            ),
            now,
        )
        val result =
            EnergyScoreCalculator.sleeps(records, ZoneId.of("America/Los_Angeles"), listOf(s))
                .single()
        assertEquals(date.plusDays(1), result.date)
        assertEquals(23, result.localStart.hour)
        assertEquals(7, result.localEnd.hour)
    }

    @Test
    fun `sleep factors preserve unavailable single day statistics and exclude unstaged naps`() {
        val main = sleep()
        val only = EnergyScoreCalculator.sleepFactors(listOf(main), date)!!
        assertEquals(8 * 3_600_000L, only.duration)
        assertEquals(100f, only.durationScale, 0.0001f)
        assertEquals(-1f, only.balance, 0f)
        assertEquals(-1f, only.regularity, 0f)
        val regular =
            EnergyScoreCalculator.sleepFactors(listOf(sleep(date.minusDays(1)), main), date)!!
        assertEquals(0f, regular.balance, 0f)
        assertEquals(100f, regular.balanceScale, 0.0001f)
        val nap = sleep(hour = 14, hours = 1, nap = true)
        assertEquals(
            only,
            EnergyScoreCalculator.sleepFactors(listOf(main, nap.copy(stages = emptyList())), date),
        )
        val withNap = EnergyScoreCalculator.sleepFactors(listOf(main, nap), date)!!
        assertEquals(1, withNap.napDeltas.size)
        assertTrue(withNap.napDeltas.single().isFinite())
        assertEquals(0f, EnergyScoreCalculator.napBonus(80f, -3f), 0f)
        assertEquals(
            EnergyScoreCalculator.napBonus(80f, 10f),
            EnergyScoreCalculator.napBonus(80f, 100f),
            0f,
        )
        assertNull(
            EnergyScoreCalculator.sleepFactors(listOf(main.copy(stages = emptyList())), date)
        )
    }

    @Test
    fun `regularity compares retained distinct dates with inclusive minute boundaries`() {
        assertEquals(-1f, EnergyScoreCalculator.sleepRegularity(listOf(sleep())), 0f)
        assertEquals(
            100f,
            EnergyScoreCalculator.sleepRegularity(listOf(sleep(date.minusDays(2)), sleep())),
            0.0001f,
        )
        val shifted =
            EnergyScoreCalculator.sleepRegularity(
                listOf(sleep(date.minusDays(1), hour = 1), sleep(hour = 2))
            )
        assertEquals(100f - 200f * 120f / 1440f, shifted, 0.0001f)
    }

    @Test
    fun `full calculation captures weighted sleep physiology provenance and unknown optional fields`() {
        val sessions = listOf(session(date.minusDays(1), "synthetic-previous"), session())
        val results =
            EnergyScoreCalculator.calculate(store(sessions), 30, false, date, zone, sessions)
        val result = results.single()
        assertEquals(date, result.date)
        assertEquals("synthetic-device", result.deviceUuid)
        assertEquals(65.0, result.values.getDouble("shr_value"), 0.0001)
        assertEquals(40.0, result.values.getDouble("shrv_value"), 0.0001)
        assertEquals(8 * 3_600_000L, result.values.getLong("sleep_duration"))
        assertEquals(0.0, result.values.getDouble("sleep_balance"), 0.0001)
        assertTrue(result.values.getDouble("total_score") in 1.0..100.0)
        listOf("mvpa_time", "mvpa_impulse", "avg_mid_sleep_time").forEach {
            assertTrue(it, result.values.isNull(it))
        }
        assertFalse(result.inputs.getBoolean("official_equivalence_verified"))
        assertEquals(
            "retained_intervals_overlapping_non_nap_sleep",
            result.inputs.getString("physiology_input"),
        )
        assertEquals(2, result.inputs.getJSONArray("sleep_ids").length())
        val saved =
            EnergyScoreLog.upsert(
                    emptyList(),
                    date,
                    zone,
                    EnergyScoreCalculator.ALGORITHM,
                    result.values,
                    result.inputs,
                    result.deviceUuid,
                    now,
                )
                .single()
        assertEquals(4, saved.protocolRow().getInt("data_version"))
        assertEquals(-1, saved.protocolRow().getInt("mvpa_impulse"))
        assertTrue(JSONObject(saved.values).isNull("mvpa_impulse"))
        assertEquals(saved, EnergyScoreLog.decode(EnergyScoreLog.encode(listOf(saved))).single())
    }

    @Test
    fun `calculation report lists missing factors and ignores unrelated activity-only dates`() {
        val complete =
            EnergyScoreCalculator.calculateWithReport(
                store(),
                30,
                false,
                date,
                zone,
                listOf(session()),
            )
        assertEquals(1, complete.results.size)
        assertEquals(1, complete.report.sleepRecordCount)
        assertEquals(1, complete.report.mainSleepDateCount)
        assertEquals(1, complete.report.candidateDateCount)
        assertEquals(1, complete.report.calculatedDateCount)
        assertTrue(complete.report.missing.isEmpty())

        val missing =
            EnergyScoreCalculator.calculateWithReport(
                store(hrv = false, active = null),
                30,
                false,
                date,
                zone,
                listOf(session()),
            )
        assertEquals(0, missing.results.size)
        val entry = missing.report.missing.single()
        assertEquals(date, entry.date)
        assertEquals(
            setOf(
                EnergyScoreCalculator.MissingReason.MISSING_PREVIOUS_DAY_ACTIVITY,
                EnergyScoreCalculator.MissingReason.NO_RMSSD,
            ),
            entry.reasons,
        )

        val zero =
            EnergyScoreCalculator.calculateWithReport(
                store(active = 0L),
                30,
                false,
                date,
                zone,
                listOf(session()),
            )
        assertEquals(
            setOf(EnergyScoreCalculator.MissingReason.ZERO_PREVIOUS_DAY_ACTIVITY),
            zero.report.missing.single().reasons,
        )

        val unstaged =
            EnergyScoreCalculator.calculateWithReport(
                store(),
                30,
                false,
                date,
                zone,
                listOf(session().copy(segments = emptyList())),
            )
        assertEquals(
            setOf(EnergyScoreCalculator.MissingReason.NO_SLEEP_STAGES),
            unstaged.report.missing.single().reasons,
        )
    }

    @Test
    fun `calculation report flags nap-only dates as having no main sleep`() {
        val nap = session(id = "manual:synthetic-nap", startHour = 14, hours = 1)
        val calculation =
            EnergyScoreCalculator.calculateWithReport(
                store(listOf(nap)),
                30,
                false,
                date,
                zone,
                listOf(nap),
            )
        assertEquals(0, calculation.results.size)
        assertEquals(1, calculation.report.sleepRecordCount)
        assertEquals(0, calculation.report.mainSleepDateCount)
        assertEquals(1, calculation.report.candidateDateCount)
        assertEquals(
            setOf(EnergyScoreCalculator.MissingReason.NO_MAIN_SLEEP),
            calculation.report.missing.single().reasons,
        )
    }

    @Test
    fun `recent denominator counts candidate sleep days even when inputs are incomplete`() {
        val current = session(id = "synthetic-current")
        val previous = session(date.minusDays(1), "synthetic-previous")
        val sessions = listOf(previous, current)
        // Only the current day's previous-day activity exists, so the earlier night's
        // own preceding day has no activity and that candidate cannot be scored.
        val calculation =
            EnergyScoreCalculator.calculateWithReport(
                store(sessions),
                30,
                false,
                date,
                zone,
                sessions,
            )
        assertEquals(1, calculation.results.size)
        assertEquals(1, calculation.report.calculatedDateCount)
        assertEquals(2, calculation.report.candidateDateCount)
        val entry = calculation.report.missing.single()
        assertEquals(date.minusDays(1), entry.date)
        assertEquals(
            setOf(EnergyScoreCalculator.MissingReason.MISSING_PREVIOUS_DAY_ACTIVITY),
            entry.reasons,
        )
    }

    @Test
    fun `missing physiology stages or previous activity never produces a total`() {
        val s = session()
        assertTrue(
            EnergyScoreCalculator.calculate(store(hrv = false), 30, false, date, zone, listOf(s))
                .isEmpty()
        )
        assertTrue(
            EnergyScoreCalculator.calculate(store(active = null), 30, false, date, zone, listOf(s))
                .isEmpty()
        )
        assertTrue(
            EnergyScoreCalculator.calculate(store(active = 0L), 30, false, date, zone, listOf(s))
                .isEmpty()
        )
        assertTrue(
            EnergyScoreCalculator.calculate(
                    store(),
                    30,
                    false,
                    date,
                    zone,
                    listOf(s.copy(segments = emptyList())),
                )
                .isEmpty()
        )
        assertTrue(
            EnergyScoreCalculator.calculate(store(), 30, false, date.minusDays(1), zone, listOf(s))
                .isEmpty()
        )
        val sdnn = store(hrv = false)
        sdnn.merge(
            mapOf(
                HealthMetric.HRV.moduleKeys.first() to
                    listOf(
                        JSONObject()
                            .put("datauuid", "synthetic-sdnn")
                            .put("start_time", s.startMillis)
                            .put("end_time", s.endMillis)
                            .put("sdnn", 40)
                    )
            ),
            now,
        )
        assertTrue(
            EnergyScoreCalculator.calculate(sdnn, 30, false, date, zone, listOf(s)).isEmpty()
        )
    }

    @Test
    fun `synthesizes daily active time from step durations and non-overlapping exercises without double counting`() {
        val yesterday = date.minusDays(1)
        val walkStart = millis(yesterday.atTime(9, 0))
        val runStart = millis(yesterday.atTime(18, 0))
        val records = store(active = null)
        records.merge(
            mapOf(
                HealthStepParser.MODULE_STEP_COUNT to
                    listOf(
                        // 15-minute morning walk (no overlapping exercise)
                        JSONObject()
                            .put("datauuid", "step-walk")
                            .put("start_time", walkStart)
                            .put("end_time", walkStart + 15 * 60_000L)
                            .put("duration", 15 * 60_000L)
                            .put("count", 1500),
                        // 10-minute bucket completely inside the 30-minute run (must not double
                        // count)
                        JSONObject()
                            .put("datauuid", "step-run-overlap")
                            .put("start_time", runStart)
                            .put("end_time", runStart + 10 * 60_000L)
                            .put("duration", 10 * 60_000L)
                            .put("count", 1200),
                    ),
                ExerciseLog.MODULE to
                    listOf(
                        // 30-minute run
                        JSONObject()
                            .put("datauuid", "ex-run")
                            .put("start_time", runStart)
                            .put("end_time", runStart + 30 * 60_000L)
                            .put("duration", 30 * 60_000L)
                            .put("exercise_type", 1002)
                    ),
            ),
            now,
        )
        val calculation =
            EnergyScoreCalculator.calculateWithReport(
                records,
                30,
                false,
                date,
                zone,
                listOf(session()),
            )
        assertEquals(1, calculation.results.size)
        val result = calculation.results.single()
        // 15 min walk + 30 min run = 45 min (NOT 55 min)
        assertEquals(45 * 60_000L, result.values.getLong("active_time"))
        assertEquals(
            "day_summary_or_synthesized_step_and_exercise_duration",
            result.inputs.getString("activity_input"),
        )
        assertEquals(
            yesterday.toString(),
            result.inputs.getJSONArray("activity_synthesized_dates").getString(0),
        )
    }

    @Test
    fun `watch main sleep with nap_score zero stays main sleep while positive nap_score is nap`() {
        val main = session(id = "sleep-main")
        val nap = session(id = "sleep-nap", startHour = 13, hours = 1)
        val records = store(listOf(main, nap))
        records.merge(
            mapOf(
                SleepParser.MODULE_SLEEP to
                    listOf(
                        JSONObject()
                            .put("datauuid", main.id)
                            .put("start_time", main.startMillis)
                            .put("end_time", main.endMillis)
                            .put("sleep_type", 1)
                            .put("nap_score", 0)
                            .put("update_time", now + 1),
                        JSONObject()
                            .put("datauuid", nap.id)
                            .put("start_time", nap.startMillis)
                            .put("end_time", nap.endMillis)
                            .put("nap_score", 85)
                            .put("update_time", now + 1),
                    )
            ),
            now,
        )
        val classified = EnergyScoreCalculator.sleeps(records, zone, listOf(main, nap))
        assertFalse(classified.first { it.id == main.id }.isNap)
        assertTrue(classified.first { it.id == nap.id }.isNap)
    }
}
