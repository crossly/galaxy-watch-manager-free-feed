package dev.ricky.galaxywatchmanagerfree.wcs

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class WearAssetSenderTest {

    @Test
    fun `set asset carries owners in hid at field three`() {
        val bytes = ByteArray(64) { (it * 7).toByte() }
        val digest = WcsFrame.messageDigest(bytes)
        val frames = mutableListOf<ByteArray>()
        assertTrue(
            WearAssetSender.send(
                sendFrame = {
                    frames += it
                    true
                },
                bytes = bytes,
                digest = digest,
                owners =
                    listOf(
                        "com.example.watch" to "signature-a",
                        "com.samsung.android.wcs.extension" to WcsPaths.SIGNATURE_PLUGIN,
                    ),
            )
        )
        val header = Proto.parse(frames.first().drop(4).toByteArray()).raw(1)!!.let(Proto::parse)
        val asset = header.nested(4)!!
        assertEquals(digest, asset.text(1))
        // f2 必须是内联数据：流式发送时留空
        assertTrue(!asset.has(2))
        val hid = asset.nested(3)!!
        val owners = hid.fields[1]!!.map { Proto.parse(it as ByteArray) }
        assertEquals(2, owners.size)
        assertEquals("com.example.watch", owners[0].text(1))
        assertEquals("signature-a", owners[0].text(2))
        assertEquals("com.samsung.android.wcs.extension", owners[1].text(1))
        assertEquals(WcsPaths.SIGNATURE_PLUGIN, owners[1].text(2))
        assertEquals(1L, header.num(13))
    }

    @Test
    fun `file pieces reference the header digest and carry the full digest only on the last piece`() {
        val bytes = ByteArray(WearAssetSender.PIECE_BYTES + 10) { it.toByte() }
        val digest = WcsFrame.messageDigest(bytes)
        val frames = mutableListOf<ByteArray>()
        WearAssetSender.send(
            {
                frames += it
                true
            },
            bytes,
            digest,
            listOf("pkg" to "sig"),
        )
        assertEquals(3, frames.size)
        val headerDigest =
            WcsFrame.messageDigest(Proto.parse(frames.first().drop(4).toByteArray()).raw(1)!!)
        val first =
            Proto.parse(Proto.parse(frames[1].drop(4).toByteArray()).raw(1)!!)
                .raw(12)!!
                .let(Proto::parse)
        val last =
            Proto.parse(Proto.parse(frames[2].drop(4).toByteArray()).raw(1)!!)
                .raw(12)!!
                .let(Proto::parse)
        assertEquals(headerDigest, first.text(1))
        assertEquals(0L, first.num(2))
        assertTrue(!first.has(4))
        assertEquals(1L, last.num(2))
        assertEquals(digest, last.text(4))
        assertEquals(bytes.size, first.raw(3)!!.size + last.raw(3)!!.size)
    }

    @Test
    fun `fetch asset request parses package digest urgency and signature`() {
        val fetch =
            Proto.string(1, "com.example.watch") +
                Proto.string(2, "digest-abc") +
                Proto.integer(3, 1) +
                Proto.string(4, "signature-xyz")
        val parsed = WcsFrame.parseFetchAsset(Proto.parse(Proto.bytes(6, fetch)))
        assertEquals("com.example.watch", parsed!!.packageName)
        assertEquals("digest-abc", parsed.digest)
        assertTrue(parsed.urgent)
        assertEquals("signature-xyz", parsed.signature)
    }

    @Test
    fun `fetch asset without digest is not answerable`() {
        val fetch = Proto.string(1, "com.example.watch")
        assertNull(WcsFrame.parseFetchAsset(Proto.parse(Proto.bytes(6, fetch))))
        assertNull(WcsFrame.parseFetchAsset(Proto.parse(ByteArray(0))))
    }
}
