package dev.ricky.galaxywatchmanagerfree.feature

import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class EnergyScoreProfileTest {
    @Test
    fun `profile round trips age and biological sex`() {
        listOf(EnergyScoreProfile(18, true), EnergyScoreProfile(99, false)).forEach { profile ->
            assertEquals(profile, EnergyScoreProfile.decode(profile.encode()))
        }
        val encoded = JSONObject(EnergyScoreProfile(30, true).encode())
        assertEquals(30, encoded.getInt("age"))
        assertEquals("F", encoded.getString("sex"))
    }

    @Test
    fun `profile decoding rejects malformed or out of range values`() {
        listOf(
                null,
                "",
                "not json",
                "{}",
                "{\"age\":17,\"sex\":\"F\"}",
                "{\"age\":100,\"sex\":\"M\"}",
                "{\"age\":30,\"sex\":\"X\"}",
                "{\"age\":\"30\",\"sex\":\"F\"}",
            )
            .forEach { assertNull(it, EnergyScoreProfile.decode(it)) }
    }

    @Test
    fun `legacy result inputs restore profile without requiring successful current result`() {
        val inputs = org.json.JSONObject().put("profile_age", 42).put("profile_sex", "M").toString()
        assertEquals(EnergyScoreProfile(42, false), EnergyScoreProfile.fromResultInputs(inputs))
        assertEquals(
            EnergyScoreProfile(18, true),
            EnergyScoreProfile.fromResultInputs("""{"profile_age":18,"profile_sex":"F"}"""),
        )
        assertNull(EnergyScoreProfile.fromResultInputs("{}"))
        assertNull(EnergyScoreProfile.fromResultInputs("broken"))
    }

    @Test
    fun `profile store keeps a value independently of calculation results`() {
        var stored: String? = null
        val store =
            EnergyScoreProfileStore(
                read = { stored },
                write = {
                    stored = it
                    true
                },
            )
        assertNull(store.load())
        assertTrue(store.save(EnergyScoreProfile(35, true)))
        assertEquals(EnergyScoreProfile(35, true), store.load())
        assertTrue(store.save(EnergyScoreProfile(36, false)))
        assertEquals(EnergyScoreProfile(36, false), store.load())
    }

    @Test
    fun `profile store reports write failure without inventing a value`() {
        var stored: String? = EnergyScoreProfile(50, false).encode()
        val store = EnergyScoreProfileStore(read = { stored }, write = { false })
        assertFalse(store.save(EnergyScoreProfile(51, true)))
        assertEquals(EnergyScoreProfile(50, false), store.load())
        assertTrue(stored != null)
    }
}
