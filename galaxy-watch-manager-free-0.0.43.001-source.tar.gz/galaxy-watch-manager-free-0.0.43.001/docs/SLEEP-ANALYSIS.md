# 睡眠时长、效率与分期分析修复

## 根因与证据

2026-10-28 手机收到最新睡眠会话：02:24–07:49（325 分钟），`has_sleep_data=-1`，无 `sleep_duration`、`efficiency`、`sleep_score`。本地当时保存的 56 条 sleep_stage 属于历史睡眠，通过 `sleep_id` 关联不到新会话。

手表的 `TSleepDataDao`（反编译类 `C0575Fd2.c`）插入初始睡眠检测记录。当前固件将原始加速度特征和心跳间隔以 `com.samsung.shealth.sleep_raw_data` 发给手机，由手机端的 SleepAnalyzer 完成四分期；并不是所有固件都会在手表上先完成深浅睡分析。

原 App 存在两处缺口：

1. `HealthRecordStore` 忽略 sleep_raw_data；即使后续已确认同步成功，原始数据也没有保留。
2. 只有起止时间、无报告总时长/分期时，`asleepMinutes=0`，效率又被推算为 0%，UI 没有区分“尚未分析”和“真的没有睡眠”。

诊断对当前手机做历史回补，取回与最新会话关联的 version=2 原始 blob，共 626 个采样窗。数据与临时探针保存在未跟踪目录 `private/sleep-investigation/`。

## 实现

- 保存 `sleep_raw_data` 与 `sleep_combined` 原始记录，原始 blob 在 RecordStore 中随修订保留。发现最近会话缺少原始数据时，为该会话发起一次历史回补。
- `LocalSleepAnalyzer` 在默认公开构建中加载随包离线分析组件；无账号、无网络请求、无 Root，也不调用手机上安装的三星健康 App。从 version=2 `sleep_raw_data` 生成四阶段分期，已有手表分期优先，原有分析缓存、评分与导出继续保留。
- 离线组件来源及重建方式有明确记录：`app/src/main/assets/sleep/NOTICE.md`、`scripts/sleep-engine/` 和随包 `app/src/main/assets/sleep/manifest.json`。这是厂商来源的模型和预处理运行时，不是自行训练的模型。
- 运行前校验组件摘要，解包到私有只读代码缓存；同进程共享一个类加载器，分析串行执行，避免多个 Repository 重复加载 JNI 库。结果按输入修订和算法版本缓存，重启直接恢复。
- 公开源码与 APK 默认保留 `engine.jar`、双 ABI JNI、清单及许可/来源说明；模型与分位表位于 JAR 的 `assets/` 中。构建与发布检查验证文件完整性、摘要及内嵌载荷，不需要 `-PvendorAssetsDir` 或私有目录。第三方权利归属见 `THIRD-PARTY.md`。
- `packaging.jniLibs.useLegacyPackaging = true` 使 APK 中的 `.so` 使用 DEFLATE，包括 `assets/sleep/` 的四个 JNI 文件；发布检查拒绝未压缩的睡眠 JNI。`LocalSleepAnalyzer` 仍通过 `AssetManager.open` 读取解压后的原始字节、核验同一摘要并写入代码缓存，无需更改文件名、模型或算法。常规 `lib/` 下的 JNI 同时改为安装时解压（`extractNativeLibs=true`）；这是安装包体积优化，解压后的睡眠运行时大小不变。
- 四分期输出通过 `SleepAnalysisResult` 转成统一 `SleepParser.Session`；首页、详情、周历史采用同一数据投影。收到有效的手表分期时，优先采用收到的分期。
- 尚未分析时，已知的起止差显示为“睡眠记录区间”，效率显示“待分析”；缺少分期时不画虚构图表，也不报 0% 或 100%。
- 数据源标注“本机离线分析”，不回写手表或冒充手表已完成的结果。

## 本条实机结果

| 指标 | 结果 |
| --- | --- |
| 原始检测区间 | 02:24–07:49，325 分钟 |
| 分期分析区间 | 02:24–07:42，318 分钟 |
| 实际睡眠 | **301 分钟（5 小时 1 分）** |
| 清醒 | 17 分钟 |
| 浅睡 | 130 分钟（2 小时 10 分） |
| 深睡 | 86 分钟（1 小时 26 分） |
| REM | 85 分钟（1 小时 25 分） |
| 效率 | **95%**，按 301 / 318 × 100 四舍五入 |
| 最终分期窗 | 636 个半分钟窗，合并为 61 段 |

626 个原始窗与 636 个最终窗并不矛盾：参考实现还执行床时间延迟对齐、边界填充与尾部清醒裁剪。07:49 是检测醒来时间，07:42 是分期分析后的结束时间，UI 同时解释两个口径。

JNI 参考接口自身返回的整数效率为 94（截断口径），App 沿用统一的睡眠时长/分析区间比例并四舍五入到 95；不会把不同口径混作同一个值。睡眠评分见下方「睡眠评分（本机计算）」：手表 `quality` 优先，无手表评分时由 `SleepScore` 用本机持有的分期透明计算，不自行捏造。

## 睡眠评分（本机计算）

官方 Samsung Health 的 JNI 桥接是 `com.samsung.sleepscore.SleepScoreAlgorithm`。2026-11-13 用 REA / Ghidra 核查 ARM64 `libsleepscore.so`，库版本为 **1.4.24**，SHA-256 为 `6ced549ad82deb57e8e933d4c05158b2fbea9c06ec3a5dba34aa3dbaf2ac2b36`。已追踪 `__calcSleepScore`、五个评分 kernel、阶段汇总、入睡耗时和 JNI 总分限幅；先前仅依据 Java 层、认为权重不可见的结论不再成立。

旧 `computed_v1` 是本项目自行选定的线性近似，权重为 25/20/20/20/15，并以深睡/REM 连续段数近似周期；它不等于原库算法。本次改为独立 Kotlin 实现原库 **夜间总分路径**，算法标识为 `computed_shealth_1_4_24`，不将该原生评分库加入安装包。

| 因子 | 旧权重 → 原库权重 | 本次计算依据 |
| --- | --- | --- |
| 总睡眠时长 | 25 → 34 | 实际睡眠不足 420 分钟时使用 sigmoid，420–540 分钟平台，超过 540 分钟使用高斯衰减；乘睡眠效率 |
| 安稳度 | 20 → 6 | 入睡后全部清醒占比与连续 ≥3 分钟清醒占比分别经同一 sigmoid 曲线，再取平均 |
| 身体恢复（深睡） | 20 → 18 | 深睡 / 实际睡眠，双 sigmoid 包络、上限归一化，再乘睡眠效率 |
| 精神恢复（REM） | 20 → 26 | REM / 实际睡眠，另一组双 sigmoid 包络、上限归一化，再乘睡眠效率 |
| 入睡耗时 | 替代周期 15 → 16 | 起点至首个深睡/浅睡/REM 的前导清醒时间，双 sigmoid 包络；零耗时按原库记满贡献 |

评分使用未舍入的半分钟精度：`T=深睡+浅睡+REM`，`W=入睡后清醒`，`L=前导清醒`，`P=T+W`，`E=100*T/(P+L)`。这份内部效率不读取手表报告的效率，也不使用界面已舍入的整数效率。原库连续清醒累加器只在下一个非清醒窗到来时结算，因此末尾清醒计入 W，但不计入连续 ≥3 分钟清醒量；实现保留该行为。

用 `S(x,a,b)=1/(1+exp(-(x-b)/a))` 表示 sigmoid，原库 kernel 的常数与计算为：

```text
F_time = E * ((S(T,45,340)+0.06)/0.912652)                       T < 420
         E                                                    420 ≤ T ≤ 540
         E * (2.71828^(-(T-480)^2/64800)*0.0022163468/0.002093) T > 540
F_deep = min(min(S(d,1.8,5), (1-S(d,10,34))*0.3+0.7),0.94)/0.94 * E
F_rem  = min(min(S(r,4,11.3), (1-S(r,15,58.5))*0.77+0.23),0.9)/0.9 * E
K_wake(w) = min(1-S(w,8,20),0.7773)/0.7773 * 100
F_rest = (K_wake(100*W/P) + K_wake(100*W3/P))/2
F_latency = min(min(S(L,2,0)-0.425,1-S(L,30,30)),0.5)/0.5 * 100
```

`d/r` 为深睡/REM 占 T 的百分比，`W3` 为已结算的连续 ≥3 分钟清醒分钟数；L=0 时直接使用 100。每项以 Float 运算，先将 `kernel*权重/100` **各自向零截断**再求和，最终限于 **1–99**；不能把界面四舍五入到 0–100 的因子分数再加权，否则可能相差一分。

手表 `quality` 始终优先展示；无可用手表评分且分期完整、连续、每段为 30 秒整数倍时才展示本机评分和分解。只有区间/报告时长、分期间断、未知阶段被移除或没有实际睡眠时，不补造分期或评分。阶段码映射为 0=深睡、1=浅睡、2=清醒、3=REM；当前模型没有使用原库另支持的 5（清醒）。

健康归档升级为 **v3**：所有标准化会话表示同时保留 `score`（手表）、`computed_score`（1–99 或 null）、`computed_score_algorithm`（新算法标识或 null）及 `score_source`（`watch` / 新算法标识 / null）。即使展示手表评分，仍保留可计算的本机评分及其版本；原始记录与模型缓存原文保持原样，不将评分算法版本混作分期模型版本。

### 原库对照与适用范围

原始 ARM64 指令在 Unicorn 中执行，内存分配和 `expf`/`powf`/`cosf` 使用宿主实现；346 组合成输入与 Kotlin 的总分、五项整数贡献全部一致。覆盖固定参考夜、随机序列、半分钟边界、420/540 分钟转折、前导/末尾清醒及 30/60 秒输入窗。合成参考例中，5 小时睡眠加 20 分钟末尾清醒得 74，8 小时且深睡/REM 各 20% 得 99；旧实现分别为 77 和 85。

这是特定库版本夜间路径的一致性证据，不代表所有 Samsung Health 版本、上层输入预处理或手表 `quality` 都相同；原库另行输出的旧 `score_logic_v1_3_275` 小睡分数、周期/首周期指标未接入本机总分。模拟执行不是手机原生执行，宿主数学库与 Android 数学库的极端浮点边界仍需设备核查。反编译、目标库、探针及完整对照保存在被忽略的 `private/sleepscore-re-20261112/`；无在线设备，本次未验收评分界面、手机保存/分享或设备持久化。

## 验证与边界

1. 在手机上独立执行完整来源 APK 的分析入口，再执行精简组件；最新记录 636 个最终窗逐窗一致。
2. 对一条已有结果的旧记录重算：728 个窗与完整入口一致，且与此前从三星健康同步的分期 **728/728 完全一致**。
3. App 实机无结果缓存运行：生成 301 分钟、95%、61 段并落盘；原型约 193ms，冷执行复测约 360ms（不含加载）；首页及详情的 UIAutomator 检查确认了全部四阶段、效率和时长。
4. 单元测试覆盖未分析记录不能推导假效率、四阶段汇总、半分钟窗边界、持久化、周历史、手表分期优先和原始记录重启恢复。

## 同一天多段睡眠（夜间 + 午休）

- 状态里新增 `sleepSessions`：按「醒来日期」（`nightKey`）归集最近睡眠日的全部会话，`sleep` 仍取其中最长的一段作为主睡眠；投影、持久化（`sleep_sessions_json`，兼容旧 `sleep_json`）与恢复都使用同一份列表。
- 睡眠卡片显示当天**总睡眠时长**，并在存在小睡时补充「含小睡 X」；详情面板在顶部给合计，再按会话列出「主睡眠 / 小睡」的起止与时长。分区选择器仍只对主睡眠展开阶段结构，避免把两段不同的分析拼成一条假时间线。
- 导出 ZIP 增加 `latest_sleep_sessions.json`（逐段），`latest_sleep.json` 保持主睡眠不变。
- 2026-10-30 对当前手表做 48 小时 `SLEEP` 模块定向回补（`forceRecovery`，`last_sync_time=0`）：只返回 10-23、10-28、10-29 三段夜间会话，没有午休记录；`sleep_raw_data` 同样只有三段。因此「10-29 午休未显示」不是界面过滤，而是手表侧没有把该次小睡同步出来；本版修复保证一旦手表上报午休会话，它会与同一天夜间睡眠一起展示并计入合计，不允许用推断补造记录。


## Watch Samsung Health 7.1.x 兼容（2026-11-27 逆向核对）

1. **协议变化根因（Watch `7.1.4.001` / `7014001`）**：
   - 在 Watch `6.30.7.008`（`C0891Ie2`）中，手表硬编码输出 `version=2`（SRBR 8-ACC，30 秒窗）；升级至 Watch `7.1.4.001` 后，`xtc` 正式启用 `wfc.b()`（`SHW - TSleepAnalyzerSettingHelper`），读取手机能力协商中的 `tracker_feature.sleep_message.sleep_library_version`（`unc.java`），仅当 `> 110500` 时才启用 SRBR 8-ACC，否则降级生成 `version=1`（7-ACC，60 秒窗）的 `sleep_raw_data`。
   - 此前本应用能力协商仅携带 `sleep_sync`、缺少 `sleep_message`，导致 Watch `7.1.4` 收到 `0 <= 110500` 后降级录制 `version=1`，而被本应用旧版 `LocalSleepAnalyzer`（仅接受 `version=2`）拒绝分析。
   - 同时 7.x 增加了 `sleep` (`combined_id`) ↔ `sleep_combined` (`datauuid`) 的关联，分期可挂载在 `combined_id` 下，`sleep_score` 可在 `quality=0` 时承载官方评分，`efficiency` 可为 `REAL` 浮点，且 `blob_compression=false` 时允许未压缩 JSON 载荷。
2. **双层修复**：
   - **协商源头修复**：`HealthCapability` 补齐官方 `tracker_feature.sleep_message`（`sleep_message_version=1001`、`sleep_library_version=130500`、`sleep_coaching_current_solution_version=4`，并将当前未实现的鼾声与睡眠教练开关如实置 `false`），同时保留旧 `sleep_sync` 兼容 6.x。重新握手后 Watch `7.1.4+` 恢复生成高精度 `version=2`（8-ACC / 30 秒）数据。
   - **已降级历史数据抢救（`version=1` / 7-ACC / 60 秒）**：`LocalSleepAnalyzer` 在保持 `version=2` 路径不变的前提下，新增 `analyze7Acc()`，通过随包 `engine.jar` 已保留的 `com.samsung.msleepstagelib.stages.SleepInterface`（`i()`、`c(double[], double[])`、`h()`、`a(int[])`）与 `libmobilesleepjni.so` 复现官方 `tk.o(..., modelVersion=0)` 7-ACC 管线，输出 `epoch_ms=60000`、`source=local_sensor_7acc_v1`，直接接入 `SleepAnalysisResult.apply()` 与 `SleepScore`（1.4.24 夜间路径，60 秒为 30 秒整倍数）。
   - **7.x 睡眠解析与导出同步**：`SleepParser`、`HealthDataProjection`、`HealthRepository` 与 `HealthExportData` 统一接入 `com.samsung.shealth.sleep_combined` / `combined_id` 关联、`sleep_score` / 浮点 `efficiency` 与未压缩 JSON 负载。
3. **验证与边界**：
   - 本地 JVM 单测已覆盖 `sleep_message` 能力协商、Watch 7.1.4 设备类型、7.x `sleep_combined`/`combined_id`/`sleep_score`/未压缩 blob 解析、`LocalSleepAnalyzer.decodeRawPayload()`、`analyze7Acc()`（以桩对象验证 7 特征、RRI 打包与 `65535 -> -1`、重采样、延迟对齐、尾部清醒 `> 5` 裁剪与 70% 零 RRI 门控）、60 秒 `SleepAnalysisResult.apply()` 与 `SleepScore`，以及 `HealthArchive.write` v7 导出回归。
   - **真机边界**：本轮无在线 Watch `7.1.4` 真机，**手机能力握手后手表切换回 `version=2`** 以及 **Android ARM64/ARMv7 真机上 `SleepInterface` 原生 JNI 执行 `version=1` 7-ACC 推理与落盘**尚未在真机实测，需后续在升级至 7.x 三星健康的手表上验收。

该分析组件现已接入 `version=2`（8-ACC / 30 秒，`local_sensor_v1`）与 `version=1`（7-ACC / 60 秒，`local_sensor_7acc_v1`）传感器数据，默认公开构建已随包提供。上文 ARM64 实机结果采用与当前随包文件相同的运行时（覆盖 `version=2`）；2026-11-14 的本机自用包恢复也验证了 `version=2` 新记录可生成分期并落盘，`version=1` 7-ACC 原生执行与默认公开构建的独立验收见本节与 `docs/OPTIMIZATION-PROGRESS.md`。ARMv7 文件已随包提供但未做实机验证；其他 CPU 或不支持的原始版本保留已收到的记录并显示分析未完成。此实现不覆盖全部三星睡眠功能（睡眠教练、呼吸暂停等）；评分独立按上节 1.4.24 夜间路径计算，其原库对照范围与分期组件实机验证范围分开记录。厂商组件的权利归属与许可说明见 `THIRD-PARTY.md`。
